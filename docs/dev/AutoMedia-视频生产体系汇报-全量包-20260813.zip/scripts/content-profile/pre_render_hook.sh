#!/bin/bash
# pre_render_hook.sh — Hermes Shell Hook for pre_tool_call
# Blocks render commands if video-track gates are not all passed.
# Also auto-runs Composition QA (V6) check.
#
# Wire protocol (via stdin JSON):
#   {hook_event_name, tool_name, tool_input: {command, ...}, cwd, ...}
# stdout: {"action": "block", "message": "..."}  to veto
#         <empty>                                  to allow

set -euo pipefail

# ── Parse stdin ──────────────────────────────────────────────────
INPUT=$(cat)
COMMAND=$(echo "$INPUT" | python3 -c "
import json, sys
d = json.load(sys.stdin)
tool_input = d.get('tool_input', {}) or {}
cmd = tool_input.get('command', tool_input.get('python_code', ''))
print(cmd)
" 2>/dev/null || echo "")

CWD=$(echo "$INPUT" | python3 -c "
import json, sys
d = json.load(sys.stdin)
print(d.get('cwd', ''))
" 2>/dev/null || echo "")

# ── Only intercept hyperframes render commands ───────────────────
if ! echo "$COMMAND" | grep -qE 'hyperframes\s+render'; then
    exit 0
fi

# ── Find project root (first ancestor with index.html) ───────────
PROJECT_DIR="$CWD"
while [ "$PROJECT_DIR" != "/" ] && [ ! -f "$PROJECT_DIR/index.html" ]; do
    PROJECT_DIR=$(dirname "$PROJECT_DIR")
done
if [ "$PROJECT_DIR" = "/" ]; then
    PROJECT_DIR="$CWD"
fi

# ── Script paths ─────────────────────────────────────────────────
SCRIPTS_DIR="/home/renanzai/.hermes/profiles/content/scripts"
CHECK_SCRIPT="$SCRIPTS_DIR/check_composition_qa.py"
SIGNOFF_SCRIPT="$SCRIPTS_DIR/signoff_gate.sh"

# ── Check gate status file ───────────────────────────────────────
GATES_FILE="$PROJECT_DIR/.gates_status.json"
REQUIRED_GATES=("V0" "VQ" "V4" "V5" "V1" "V3" "V6")

if [ ! -f "$GATES_FILE" ]; then
    echo '{"action": "block", "message": "❌ Render blocked: no gate status file found. Run `signoff_gate.sh` for each gate first."}'
    exit 0
fi

MISSING=""
for gate in "${REQUIRED_GATES[@]}"; do
    STATUS=$(python3 -c "
import json
with open('$GATES_FILE') as f:
    d = json.load(f)
g = d.get('gates', {}).get('$gate', {})
print(g.get('status', 'missing'))
" 2>/dev/null || echo "missing")

    if [ "$STATUS" != "pass" ]; then
        MISSING="$MISSING $gate"
    fi
done

# ── If V6 is missing, auto-run the Composition QA check ───────────
HAS_V6_MISSING=false
for g in $MISSING; do
    if [ "$g" = "V6" ]; then HAS_V6_MISSING=true; fi
done

if [ "$HAS_V6_MISSING" = true ]; then
    COMPOSITION_FILE="$PROJECT_DIR/index.html"
    if [ -f "$COMPOSITION_FILE" ] && [ -f "$CHECK_SCRIPT" ]; then
        if python3 "$CHECK_SCRIPT" "$COMPOSITION_FILE" > /dev/null 2>&1; then
            # Auto-sign V6
            if [ -f "$SIGNOFF_SCRIPT" ]; then
                bash "$SIGNOFF_SCRIPT" --project "$PROJECT_DIR" --gate V6 --note "auto-pass by pre_render_hook" 2>/dev/null || true
            fi
            MISSING=$(echo "$MISSING" | sed 's/ V6//g' | sed 's/^ *//')
        fi
    fi
fi

# Trim leading space
MISSING=$(echo "$MISSING" | sed 's/^ *//')

if [ -n "$MISSING" ]; then
    echo "{\"action\": \"block\", \"message\": \"❌ Render blocked — missing gates:$MISSING\"}"
    exit 0
fi

# All gates passed
exit 0
