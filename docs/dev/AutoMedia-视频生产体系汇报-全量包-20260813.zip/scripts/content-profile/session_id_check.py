#!/usr/bin/env python3
"""
session_id_check.py — 跨 session 写文件防抢活 hook（6-05 v11 复盘新增）

触发场景:
  - 2 个 session 同时改一个项目目录（multisession 抢活）
  - 6-05 实测: session 103322 + session 113223 + 14:00 第三次同时改

机制:
  - 每个项目目录加 .session_id 标记（agent session_id）
  - 写文件前必先 check_lock(project_dir)
  - 如果 .session_id 存在且 ≠ 当前 session → raise LockError
  - 写入成功后必 mark_session(project_dir, session_id)

用法:
  from session_id_check import check_lock, mark_session
  check_lock("/path/to/project")   # 写文件前
  ... 写文件 ...
  mark_session("/path/to/project", "current_session_id")  # 写文件后
"""
import os, sys
import json
from datetime import datetime
from pathlib import Path

# 桎梏 #6 修复：env var 化（不写死 .session_id 防撞名）
LOCK_FILE = os.environ.get("SESSION_LOCK_FILENAME", ".session_id_hermes_lock")


def check_lock(project_dir: str | Path, current_session_id: str = "default") -> None:
    """
    写文件前必跑：如果 .session_id 存在且 ≠ 当前 session → raise LockError

    桎梏 #14 修复：锁文件坏了不再静默 return（会 raise LockError 警告 + 自动重建）
    """
    proj = Path(project_dir)
    lock = proj / LOCK_FILE
    if not lock.exists():
        return  # 无锁 = 可写
    try:
        lock_data = json.loads(lock.read_text(encoding="utf-8"))
    except Exception as e:
        # 桎梏 #14 修复：锁文件坏了不静默，raise 警告（不阻塞，但给用户可见警告）
        # 自动删除损坏的锁文件（让 mark_session 重建）
        try:
            lock.unlink()
        except Exception:
            pass
        import sys as _sys
        print(f"[WARN] 锁文件损坏已删除重建: {lock} ({type(e).__name__})", file=_sys.stderr)
        return
    locked_session = lock_data.get("session_id", "")
    if locked_session and locked_session != current_session_id:
        locked_at = lock_data.get("locked_at", "未知时间")
        raise LockError(
            f"项目 {proj.name} 被 session `{locked_session}` 在 {locked_at} 锁定。"
            f"当前 session `{current_session_id}` 不能写入。\n"
            f"  解除方法: 1) 等待对方 session 结束  2) 删除 {LOCK_FILE}（不推荐）"
        )


def mark_session(project_dir: str | Path, session_id: str) -> None:
    """
    写文件后必跑：标记当前 session 持有该项目的写锁
    """
    proj = Path(project_dir)
    lock = proj / LOCK_FILE
    lock.write_text(
        json.dumps(
            {
                "session_id": session_id,
                "locked_at": datetime.now().isoformat(timespec="seconds"),
                "note": "此锁仅作提示，不是硬阻塞。误删不会损坏数据。",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def release_session(project_dir: str | Path, session_id: str) -> None:
    """
    session 结束时跑：解除锁（只解除自己加的锁）
    """
    proj = Path(project_dir)
    lock = proj / LOCK_FILE
    if not lock.exists():
        return
    try:
        lock_data = json.loads(lock.read_text(encoding="utf-8"))
    except Exception:
        return
    if lock_data.get("session_id") == session_id:
        lock.unlink()


class LockError(Exception):
    """跨 session 抢活错误"""

    pass


# CLI 入口
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="session_id_check.py — 跨 session 写文件防抢活")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_check = sub.add_parser("check", help="写文件前检查")
    p_check.add_argument("project_dir")
    p_check.add_argument("--session-id", default="default")

    p_mark = sub.add_parser("mark", help="写文件后标记")
    p_mark.add_argument("project_dir")
    p_mark.add_argument("--session-id", required=True)

    p_release = sub.add_parser("release", help="session 结束解除锁")
    p_release.add_argument("project_dir")
    p_release.add_argument("--session-id", required=True)

    args = parser.parse_args()
    if args.cmd == "check":
        try:
            check_lock(args.project_dir, args.session_id)
            print(f"[OK] 无锁或同 session，可写 {args.project_dir}")
        except LockError as e:
            print(f"[BLOCK] {e}")
            exit(1)
    elif args.cmd == "mark":
        mark_session(args.project_dir, args.session_id)
        print(f"[OK] 标记 session {args.session_id} 持有 {args.project_dir}")
    elif args.cmd == "release":
        release_session(args.project_dir, args.session_id)
        print(f"[OK] 解除 {args.project_dir} 的 session 锁")
