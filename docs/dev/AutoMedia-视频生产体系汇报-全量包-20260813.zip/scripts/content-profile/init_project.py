#!/usr/bin/env python3
"""
AutoMedia 项目初始化 — 新建项目的唯一标准入口。

每次开始一个新话题生产时，必须通过此脚本初始化项目目录。
禁止手动 mkdir + 直接 R0 跳过此步骤。

用法:
  python3 init_project.py \\
    --topic-title "OpenAI IPO前连下两城" \\
    --topic-slug "openai-ipo-hiring-shazeer-ball" \\
    --category "引流款"

  python3 init_project.py --topic-title "xxx" --topic-slug "xxx" --category "引流款"

流程:
  1. 建标准项目目录（含 00_project_info/）
  2. 写 project_info.json
  3. 调用 pool_sync.py 改 pool.db status → selected
  4. 输出项目根目录路径

返回:
  exit 0 = 初始化完成
  exit 1 = 失败
  stdout 最后一行 = 项目根目录路径（供脚本链调用）
"""

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

BASE = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects"
POOL_SYNC = os.path.expanduser("~/.hermes/profiles/content/scripts/pool_sync.py")

PROJECT_STRUCTURE = [
    "00_research",
    "00_project_info",
    "01_content/drafts/wechat",
    "01_content/drafts/zhihu",
    "01_content/drafts/xiaohongshu",
    "01_content/drafts/tiktok",
    "01_content/drafts/bilibili",
    "02_images/cover",
    "02_images/assets",
    "03_video",
    "04_review",
    "05_publish",
]


def create_project_dir(project_root: Path) -> bool:
    """创建标准项目目录结构"""
    for subdir in PROJECT_STRUCTURE:
        os.makedirs(os.path.join(project_root, subdir), exist_ok=True)
    print(f"  ✅ 目录结构: {len(PROJECT_STRUCTURE)} 个子目录已创建")
    return True


def write_project_info(project_root: Path, info: dict) -> bool:
    """写入 project_info.json"""
    path = project_root / "00_project_info" / "project_info.json"
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(info, f, indent=2, ensure_ascii=False)
        print(f"  ✅ project_info.json 已写入")
        return True
    except Exception as e:
        print(f"  ❌ project_info.json 写入失败: {e}", file=sys.stderr)
        return False


def run_pool_sync(project_root: Path, topic_title: str) -> bool:
    """调用 pool_sync.py 同步 pool.db"""
    cmd = [
        sys.executable, POOL_SYNC,
        "--project-dir", str(project_root),
        "--topic-title", topic_title,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    for line in result.stdout.strip().split("\n"):
        if line.strip():
            print(f"     {line.strip()}")
    if result.stderr.strip():
        print(f"     stderr: {result.stderr.strip()}", file=sys.stderr)

    if result.returncode != 0:
        # pool_sync 返回 0 即使未匹配（manual 话题），所以非 0 才是真失败
        print(f"  ⚠️ pool_sync 返回码 {result.returncode}")
        return False

    # 检查输出中是否有"已匹配"或"未匹配"
    if "✅ 匹配" in result.stdout:
        print(f"  ✅ pool.db 同步完成：topic → selected")
        return True
    elif "未匹配" in result.stdout:
        print(f"  ℹ️ pool.db 未匹配（manual 话题，已标注 source=manual）")
        return True
    else:
        print(f"  ⚠️ pool_sync 输出无法解析，请手动确认", file=sys.stderr)
        return True  # 不阻断流程


def main():
    parser = argparse.ArgumentParser(
        description="AutoMedia 项目初始化 — 新建项目的唯一标准入口"
    )
    parser.add_argument("--topic-title", required=True, help="话题标题（必填）")
    parser.add_argument("--topic-slug", required=True, help="URL-safe slug（必填）")
    parser.add_argument(
        "--category", required=True,
        choices=["引流款", "业务款"],
        help="话题类型（引流款 / 业务款）"
    )
    parser.add_argument(
        "--project-dir", default="",
        help="项目目录名（可选，默认按时间戳 + slug 自动生成）"
    )
    parser.add_argument("--dry-run", action="store_true", help="只检查不写入")
    args = parser.parse_args()

    topic_title = args.topic_title
    topic_slug = args.topic_slug
    category = args.category

    # 生成项目目录名
    if args.project_dir:
        project_name = args.project_dir
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        project_name = f"{timestamp}_{topic_slug}"

    project_root = Path(BASE) / project_name

    print(f"🚀 init_project: 初始化项目")
    print(f"   标题: {topic_title[:60]}")
    print(f"   目录: {project_root}")
    print(f"   类型: {category}")
    print()

    # Step 1: 检查是否已存在
    if project_root.exists():
        print(f"  ⚠️ 项目目录已存在: {project_root}")
        # 补建缺失的子目录（如 00_project_info/）
        if not args.dry_run:
            missing = 0
            for subdir in PROJECT_STRUCTURE:
                d = project_root / subdir
                if not d.exists():
                    d.mkdir(parents=True, exist_ok=True)
                    missing += 1
            if missing > 0:
                print(f"  📁 补建了 {missing} 个缺失子目录")
    else:
        if args.dry_run:
            print(f"  🔸 dry-run: 跳过目录创建")
        else:
            print(f"  📁 创建目录结构...")
            create_project_dir(project_root)

    # Step 2: 写 project_info.json
    if args.dry_run:
        print(f"  🔸 dry-run: 跳过 project_info.json 写入")
    else:
        info = {
            "project_id": project_name,
            "topic_id": "",  # pool_sync 会补
            "source": "",    # pool_sync 会补 (pool/manual)
            "topic": topic_title,
            "topic_slug": topic_slug,
            "category": category,
            "created_at": datetime.now().isoformat(),
            "status": "initialized",
            "videos": {},
            "articles": {},
        }
        if not write_project_info(project_root, info):
            return 1

    # Step 3: 同步 pool.db
    if args.dry_run:
        print(f"  🔸 dry-run: 跳过 pool_sync 调用")
    else:
        print(f"  🔗 同步 pool.db...")
        run_pool_sync(project_root, topic_title)

    print()
    print(f"✅ 初始化完成: {project_root}")
    # 标准输出最后一行 = 项目路径（供脚本链调用）
    print(project_root)

    return 0


if __name__ == "__main__":
    sys.exit(main())
