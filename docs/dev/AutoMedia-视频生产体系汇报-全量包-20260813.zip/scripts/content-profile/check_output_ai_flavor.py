#!/usr/bin/env python3
"""
check_output_ai_flavor.py — Post-generation Gate
===============================================
初稿生成后、进 humanizer 之前执行。扫描输出内容的 AI 味指标，
包括禁令词、句长标准差、段尾升华句、平台特有指标。
exit code 拦截不合格内容。

用法:
  python3 check_output_ai_flavor.py < output.txt
  python3 check_output_ai_flavor.py --file output.txt
  python3 check_output_ai_flavor.py --file output.txt --platform xiaohongshu

退出码:
  0 = 通过，可以进入 humanizer
  1 = 告警（存在少量问题但可继续）
  2 = 失败（必须修改后重试）
"""

import sys
import re
import statistics
import argparse


# === Ban word lists ===
BAN_WORDS = {
    '排序词': ['首先', '其次', '最后', '第一、', '第二、', '第三、',
               '第一，', '第二，', '第三，'],
    '总结词': ['综上所述', '总而言之', '基于以上分析', '总体而言', '归结起来'],
    'AI连接词': ['值得注意的是', '不难发现', '毋庸置疑', '从这个角度看'],
    '段尾升华词': ['代表着', '标志着', '意味着', '彰显着', '诠释着', '折射出'],
    '万能开头': ['在当今社会', '众所周知', '不可否认'],
}

# Severity: some ban words are critical even once
CRITICAL_BAN_PATTERNS = ['综上所述', '总而言之', '基于以上分析']

PLATFORM_SPECIFIC = {
    'gongzhonghao': {
        'forbidden_words': ['我们应当', '我们必须', '我们不得不', '我们需要思考'],
        'max_we_count': 3,  # 全文"我们"出现次数上限
        'title_number_pattern': r'^[一二三四五六七八九十]+[、.．]',  # 一、二、三 小标题
    },
    'zhihu': {
        'forbidden_openings': ['先说结论'],
        'forbidden_endings': ['欢迎在评论区补充讨论'],
    },
    'xiaohongshu': {
        'forbidden_words': ['姐妹们', '家人们', '宝子们', '集美们', '你知道吗'],
        'max_emoji_per_para': 2,
        'max_questions': 3,
        'min_paragraphs': 3,
        'max_paragraphs': 7,
    },
}


def count_ban_words(text):
    """Count occurrences of each banned word category."""
    results = {}
    for category, words in BAN_WORDS.items():
        count = 0
        found = []
        for w in words:
            occ = len(re.findall(re.escape(w), text))
            count += occ
            if occ > 0:
                found.append((w, occ))
        results[category] = {'count': count, 'found': found}
    return results


def check_sentence_rhythm(text):
    """Analyze sentence length rhythm."""
    # Split by Chinese sentence-ending punctuation
    sentences = [s.strip() for s in re.split(r'[。！？!?\n]', text) 
                 if s.strip() and len(s.strip()) > 3 
                 and not s.strip().startswith('===')]
    
    if len(sentences) < 3:
        return {
            'sentences': len(sentences),
            'mean_len': 0,
            'std_dev': 0,
            'warning': '句子数太少，无法有效分析节奏'
        }
    
    sent_lens = [len(s) for s in sentences]
    std_dev = statistics.stdev(sent_lens) if len(sent_lens) > 1 else 0
    mean_len = statistics.mean(sent_lens)
    
    # Count consecutive similar-length sentences
    similar_runs = 0
    max_run = 0
    current_run = 1
    for i in range(1, len(sent_lens)):
        if abs(sent_lens[i] - sent_lens[i-1]) < 5:
            current_run += 1
        else:
            max_run = max(max_run, current_run)
            current_run = 1
    max_run = max(max_run, current_run)
    
    return {
        'sentences': len(sentences),
        'mean_len': round(mean_len, 1),
        'std_dev': round(std_dev, 1),
        'max_similar_run': max_run,
        'longest_sentence': max(sent_lens),
        'shortest_sentence': min(sent_lens),
        'warning': None,
    }


def check_paragraph_structure(text):
    """Analyze paragraph structure."""
    paras = [p.strip() for p in text.split('\n\n') 
             if p.strip() and not p.strip().startswith('===') and len(p.strip()) > 10]
    
    if len(paras) < 2:
        return {'paragraphs': len(paras), 'warning': '段落数太少'}
    
    para_lens = [len(p) for p in paras]
    std_dev = statistics.stdev(para_lens) if len(para_lens) > 1 else 0
    
    # Check if all paragraphs are similar length (too uniform = AI flavour)
    uniformity_ratio = std_dev / statistics.mean(para_lens) if statistics.mean(para_lens) > 0 else 0
    
    return {
        'paragraphs': len(paras),
        'para_lens': para_lens,
        'std_dev': round(std_dev, 1),
        'uniformity_ratio': round(uniformity_ratio, 3),
        'warning': None,
    }


def check_paragraph_endings(text):
    """Check if paragraphs end with summary/elevation sentences."""
    paras = [p.strip() for p in text.split('\n\n') 
             if p.strip() and not p.strip().startswith('===')]
    
    problematic_endings = []
    for i, p in enumerate(paras):
        lines = [l.strip() for l in p.split('\n') if l.strip()]
        if not lines:
            continue
        last_line = lines[-1]
        # Check if last line contains summary markers
        if re.search(r'这意味着|这标志着|这代表着|这彰显着|由此可见|综上|总而言之', last_line):
            problematic_endings.append((i+1, last_line[:50]))
    
    return problematic_endings


def check_platform_rules(text, platform):
    """Platform-specific checks."""
    issues = []
    rules = PLATFORM_SPECIFIC.get(platform, {})
    
    if not rules:
        return issues
    
    # Forbidden words
    for w in rules.get('forbidden_words', []):
        if w in text:
            count = len(re.findall(re.escape(w), text))
            issues.append(f"[禁止词] 出现「{w}」{count}次")
    
    # Title numbering
    if 'title_number_pattern' in rules:
        matches = re.findall(rules['title_number_pattern'], text, re.MULTILINE)
        if matches:
            issues.append(f"[小标题编号] 发现 {len(matches)} 处编号小标题: {matches}")
    
    # "我们" count
    if 'max_we_count' in rules:
        we_count = len(re.findall(r'我们(?!的)(?!在)', text))
        if we_count > rules['max_we_count']:
            issues.append(f"[我们节制] 「我们」出现{we_count}次，上限{rules['max_we_count']}次")
    
    # 知乎 forbidden endings
    if 'forbidden_endings' in rules:
        for ending in rules['forbidden_endings']:
            # Check if the ending appears in the last 200 characters
            if ending in text[-200:]:
                issues.append(f"[结尾模板] 末尾出现「{ending}」")
    
    # 知乎 forbidden openings
    if 'forbidden_openings' in rules:
        first_200 = text[:200]
        for opening in rules['forbidden_openings']:
            if opening in first_200:
                issues.append(f"[开头模板] 开头出现「{opening}」")
    
    # 小红书 question count
    if 'max_questions' in rules:
        q_count = len(re.findall(r'？', text))
        if q_count > rules['max_questions']:
            issues.append(f"[设问过多] 问句{q_count}个，上限{rules['max_questions']}个")
    
    # 小红书 paragraph count
    if 'min_paragraphs' in rules or 'max_paragraphs' in rules:
        paras = [p.strip() for p in text.split('\n\n') if p.strip() and not p.strip().startswith('===')]
        if 'min_paragraphs' in rules and len(paras) < rules['min_paragraphs']:
            issues.append(f"[段落数] 仅{len(paras)}段，建议至少{rules['min_paragraphs']}段")
        if 'max_paragraphs' in rules and len(paras) > rules['max_paragraphs']:
            issues.append(f"[段落数] {len(paras)}段，建议不超过{rules['max_paragraphs']}段")
    
    return issues


def check_output(text, platform=None):
    """Full check. Returns (exit_code, messages)."""
    exit_code = 0
    messages = []
    
    # 1. Ban words
    ban_results = count_ban_words(text)
    total_ban_words = sum(r['count'] for r in ban_results.values())
    
    if total_ban_words > 0:
        messages.append(f"🚫 禁令词检测: 共发现 {total_ban_words} 处违禁词")
        for category, result in ban_results.items():
            if result['count'] > 0:
                details = ', '.join(f"「{w}」×{c}" for w, c in result['found'])
                messages.append(f"   {category}: {details}")
        
        # Critical: check for severe ban words
        for w in CRITICAL_BAN_PATTERNS:
            if w in text:
                count = len(re.findall(re.escape(w), text))
                messages.append(f"   ❌ 严重违规: 「{w}」出现{count}次 — 必须修改")
                exit_code = max(exit_code, 2)
            elif exit_code < 1:
                exit_code = 1  # Non-critical ban words trigger warning
    else:
        messages.append("✅ 禁令词检测: 未发现违禁词")
    
    # 2. Sentence rhythm
    rhythm = check_sentence_rhythm(text)
    if rhythm.get('warning'):
        messages.append(f"⚠️ {rhythm['warning']}")
        exit_code = max(exit_code, 1)
    else:
        messages.append(f"📐 句子节奏: {rhythm['sentences']}句, 平均{rhythm['mean_len']}字, "
                       f"标准差{rhythm['std_dev']}")
        
        if rhythm['std_dev'] < 6:
            messages.append(f"   ⚠️ 句长标准差{rhythm['std_dev']} < 6 — 节奏偏均匀，建议加入更多长短变化")
            exit_code = max(exit_code, 1)
        elif rhythm['std_dev'] < 4:
            messages.append(f"   ❌ 句长标准差{rhythm['std_dev']} < 4 — 节奏过度均匀，必须调整")
            exit_code = max(exit_code, 2)
        else:
            messages.append(f"   ✅ 句长标准差{rhythm['std_dev']} > 6 — 节奏合理")
        
        if rhythm['max_similar_run'] >= 4:
            messages.append(f"   ⚠️ 存在{rhythm['max_similar_run']}句相邻句长相近，建议打断节奏")
            exit_code = max(exit_code, 1)
    
    # 3. Paragraph structure
    para = check_paragraph_structure(text)
    if para.get('warning'):
        messages.append(f"⚠️ {para['warning']}")
    else:
        messages.append(f"📐 段落结构: {para['paragraphs']}段, 标准差{para['std_dev']}, "
                       f"均匀度{para['uniformity_ratio']}")
        
        if para['uniformity_ratio'] < 0.3 and para['paragraphs'] >= 3:
            messages.append(f"   ⚠️ 段落均匀度{para['uniformity_ratio']} < 0.3 — 各段长度过于接近")
            exit_code = max(exit_code, 1)
        elif para['uniformity_ratio'] > 0.8:
            messages.append(f"   ✅ 段落长度差异大 — 结构自然")
        else:
            messages.append(f"   ✅ 段落长度分布合理")
    
    # 4. Paragraph endings
    bad_endings = check_paragraph_endings(text)
    if bad_endings:
        messages.append(f"📐 段尾检测: {len(bad_endings)}段以总结/升华句式结尾")
        for idx, ending in bad_endings[:3]:
            messages.append(f"   第{idx}段: 「{ending}...」")
        exit_code = max(exit_code, 1)
    else:
        messages.append("✅ 段尾检测: 无总结/升华句式结尾")
    
    # 5. Platform-specific
    if platform:
        platform_issues = check_platform_rules(text, platform)
        if platform_issues:
            messages.append(f"📐 {platform} 平台特有检测:")
            for issue in platform_issues:
                messages.append(f"   {issue}")
                exit_code = max(exit_code, 2)  # Platform violations are critical
        else:
            messages.append(f"✅ {platform} 平台特有检测通过")
    
    # 6. 字数检查（平台硬约束，exit=2 违规）
    content_len = len(text.strip())
    
    # Platform word count limits
    platform_limits = {
        'gongzhonghao': {'min': 1200, 'max': 4000, 'name': '公众号'},
        'zhihu': {'min': 800, 'max': 4000, 'name': '知乎'},
        'xiaohongshu': {'min': 300, 'max': 500, 'name': '小红书'},
    }
    
    if platform and platform in platform_limits:
        limits = platform_limits[platform]
        if content_len < limits['min']:
            messages.append(f"📐 字数检查: {content_len}字 < {limits['name']}下限{limits['min']}字 — 内容偏短")
            exit_code = max(exit_code, 1)
        elif content_len > limits['max']:
            messages.append(f"❌ [字数超标] {content_len}字 > {limits['name']}上限{limits['max']}字 — 必须压缩")
            exit_code = max(exit_code, 2)
        else:
            messages.append(f"✅ 字数检查: {content_len}字（{limits['name']}标准范围 {limits['min']}-{limits['max']}字）")
    else:
        # No platform specified - generic check
        if content_len < 200:
            messages.append(f"⚠️ 内容过短（{content_len}字），可能信息量不足")
            exit_code = max(exit_code, 1)
    
    return exit_code, messages


def main():
    parser = argparse.ArgumentParser(
        description='Post-generation gate: check output for AI flavor')
    parser.add_argument('--file', '-f', type=str, help='Path to output file')
    parser.add_argument('--platform', '-p', type=str,
                        choices=['gongzhonghao', 'zhihu', 'xiaohongshu'],
                        help='Target platform for platform-specific checks')
    args = parser.parse_args()
    
    if args.file:
        with open(args.file, 'r', encoding='utf-8') as f:
            text = f.read()
    else:
        text = sys.stdin.read()
    
    if not text.strip():
        print("❌ [失败] 内容为空，无法检查")
        sys.exit(2)
    
    exit_code, messages = check_output(text, args.platform)
    
    print(f"\n{'='*50}")
    print("Post-generation Gate — AI 味检测报告")
    print(f"{'='*50}\n")
    for msg in messages:
        print(msg)
    print(f"\n{'='*50}")
    print(f"结果: {'✅ 通过' if exit_code == 0 else '⚠️ 警告' if exit_code == 1 else '❌ 未通过'}")
    print(f"exit={exit_code}")
    if exit_code >= 2:
        print("请修改后再进 humanizer，不要跳过此检查。")
    print(f"{'='*50}")
    
    sys.exit(exit_code)


if __name__ == '__main__':
    main()
