#!/usr/bin/env python3
"""
check_prompt_quality.py — Pre-generation Gate
==============================================
在提交 prompt 给 LLM 之前执行，检查 prompt 是否包含必要的注入块内容。

用法:
  python3 check_prompt_quality.py < prompt.txt
  python3 check_prompt_quality.py --file prompt.txt
  python3 check_prompt_quality.py --platform gongzhonghao < prompt.txt

退出码:
  0 = 通过，可以提交
  1 = 告警（缺少部分内容，但可继续）
  2 = 失败（缺少关键内容，禁止提交）
"""

import sys
import re
import argparse

# === Required keywords that MUST appear in the prompt ===
# These are markers from the 通用注入块
REQUIRED_GENERAL_KEYWORDS = [
    ('节奏', '通用写作原则/节奏'),
    ('长短句交替', '通用写作原则/节奏'),
    ('禁止词', '通用写作原则/词汇'),
    ('结论前置', '通用写作原则/密度'),
    ('不要用「挑战与展望」', '通用写作原则/收尾'),
]

# Platform-specific required keywords
PLATFORM_KEYWORDS = {
    'gongzhonghao': [
        ('禁止用「一/二/三」做小标题', '公众号平台层/标题'),
        ('「我们」在全文出现不超过', '公众号平台层/我们节制'),
        ('每段不要等长', '公众号平台层/段落'),
        ('设问后允许「悬着」', '公众号平台层/句尾'),
    ],
    'zhihu': [
        ('禁止「先说结论」', '知乎平台层/开头'),
        ('分点', '知乎平台层/分点'),
        ('引用必须有具体来源', '知乎平台层/引用'),
        ('不要以「欢迎在评论区补充讨论」', '知乎平台层/结尾'),
    ],
    'xiaohongshu': [
        ('情绪', '人设'),  # 小红书必须有情绪设定
        ('禁止每段固定 1-2 个 emoji', '小红书平台层/格式'),
        ('全篇设问不超过 2 个', '小红书平台层/设问'),
        ('禁止「姐妹们', '小红书平台层/人称'),
    ],
}

# Optional but recommended: persona + style reference
RECOMMENDED_KEYWORDS = [
    ('持「', '人设——态度定义'),
    ('语气像', '人设——语气定义'),
    ('[参考范例]', 'Few-shot 风格参考'),
]


def check_prompt(prompt, platform=None):
    """Run all checks on the prompt. Return (exit_code, messages)."""
    exit_code = 0
    messages = []
    
    # Level 1: Essential — general injection block
    missing_essential = []
    for keyword, desc in REQUIRED_GENERAL_KEYWORDS:
        if keyword not in prompt:
            missing_essential.append(f"  缺少通用注入块内容: [{desc}] 未找到「{keyword}」")
    
    if missing_essential:
        exit_code = max(exit_code, 2)  # 关键内容缺失
        messages.append("❌ [失败] 通用注入块检测未通过:")
        messages.extend(missing_essential)
    else:
        messages.append("✅ 通用注入块检测通过")
    
    # Level 1: Essential — platform-specific
    if platform and platform in PLATFORM_KEYWORDS:
        missing_platform = []
        for keyword, desc in PLATFORM_KEYWORDS[platform]:
            if keyword not in prompt:
                missing_platform.append(f"  缺少平台层内容: [{desc}] 未找到「{keyword}」")
        
        if missing_platform:
            exit_code = max(exit_code, 2)
            messages.append(f"❌ [失败] {platform} 平台层注入块检测未通过:")
            messages.extend(missing_platform)
        else:
            messages.append(f"✅ {platform} 平台层注入块检测通过")
    elif platform:
        messages.append(f"⚠️ 未知平台「{platform}」，跳过平台层检查")
    
    # Level 2: Warning — recommended content
    missing_rec = []
    for keyword, desc in RECOMMENDED_KEYWORDS:
        if keyword not in prompt:
            missing_rec.append(f"  缺少推荐内容: [{desc}] 未找到「{keyword}」")
    
    if missing_rec:
        exit_code = max(exit_code, 1)
        messages.append("⚠️ [告警] 推荐内容检测未通过（不会拦截但建议补充）:")
        messages.extend(missing_rec)
    else:
        messages.append("✅ 推荐内容（人设+范例）检测通过")
    
    # Level 2: Warning — check prompt length
    if len(prompt) < 300:
        exit_code = max(exit_code, 1)
        messages.append("⚠️ [告警] Prompt 长度过短（<300字），可能缺少必要内容")
    elif len(prompt) > 8000:
        messages.append(f"⚠️ Prompt 较长（{len(prompt)}字），注意模型可能忽略尾部规则")
    else:
        messages.append(f"✅ Prompt 长度合理（{len(prompt)}字）")
    
    return exit_code, messages


def main():
    parser = argparse.ArgumentParser(description='Pre-generation gate: check prompt quality')
    parser.add_argument('--file', '-f', type=str, help='Path to prompt file')
    parser.add_argument('--platform', '-p', type=str, 
                        choices=['gongzhonghao', 'zhihu', 'xiaohongshu'],
                        help='Target platform for platform-specific checks')
    args = parser.parse_args()
    
    if args.file:
        with open(args.file, 'r', encoding='utf-8') as f:
            prompt = f.read()
    else:
        prompt = sys.stdin.read()
    
    if not prompt.strip():
        print("❌ [失败] Prompt 为空，无法检查")
        sys.exit(2)
    
    exit_code, messages = check_prompt(prompt, args.platform)
    
    print(f"\n{'='*50}")
    print("Pre-generation Gate 检测报告")
    print(f"{'='*50}\n")
    for msg in messages:
        print(msg)
    print(f"\n{'='*50}")
    print(f"结果: {'通过' if exit_code == 0 else '有条件通过' if exit_code == 1 else '未通过'} (exit={exit_code})")
    print(f"{'='*50}")
    
    sys.exit(exit_code)


if __name__ == '__main__':
    main()
