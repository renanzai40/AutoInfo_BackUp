#!/usr/bin/env python3
"""
gen_srt_from_mp3.py — 用 Whisper word_timestamps 自动生成 SRT（6-05 v11 复盘新增）

v7 silencedetect 漏短停顿 → v8 用 Whisper word_timestamps 校准 → 0.00s 偏差（9/9 entries）
本脚本固化 v8 经验：Whisper tiny 转写 + word_timestamps + 短句合并 + 真实句尾

用法:
  python3 gen_srt_from_mp3.py /path/to/mp3.mp3 --output /path/to/output.srt
  python3 gen_srt_from_mp3.py /path/to/mp3.mp3 --output /path/to/output.srt --max-chars 30

参数:
  --max-chars  N: 短句最大字符数（超过自动合并到下一条）
  --min-dur    N: 短句最小时长秒（小于自动合并到下一条）
  --language   zh: 语言（默认中文）

输出:
  写入 SRT 文件（HH:MM:SS,mmm --> HH:MM:SS,mmm 格式）
"""
import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

WHISPER_BIN = Path(os.environ.get("WHISPER_BIN", str(Path.home() / ".hermes" / "hermes-agent" / "venv" / "bin" / "whisper")))


def run_whisper(mp3_path: Path, language: str = "zh") -> dict:
    """跑 Whisper word_timestamps 转写"""
    out_dir = Path("/tmp/whisper_gen_srt")
    out_dir.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        [
            str(WHISPER_BIN),
            str(mp3_path),
            f"--language",
            language,
            "--model",
            "tiny",
            "--output_format",
            "json",
            "--output_dir",
            str(out_dir),
            "--word_timestamps",
            "True",
        ],
        capture_output=True,
        text=True,
        timeout=120,
    )
    if result.returncode != 0:
        raise RuntimeError(f"Whisper 失败: {result.stderr[:300]}")
    json_files = list(out_dir.glob(f"{mp3_path.stem}*.json"))
    if not json_files:
        raise RuntimeError(f"Whisper 未生成 json: {out_dir}")
    return json.loads(json_files[0].read_text(encoding="utf-8"))


def segments_to_srt(segments: list, max_chars: int = 30, min_dur: float = 0.5) -> str:
    """
    Whisper segments → SRT 文本
    max_chars: 单条最大字符（超了合并到下一条）
    min_dur: 单条最小时长（小于合并到下一条）
    """
    # Whisper 默认 5 秒一段，先按 max_chars 拆
    srt_entries = []
    idx = 1
    for seg in segments:
        text = seg.get("text", "").strip()
        if not text:
            continue
        start = seg.get("start", 0.0)
        end = seg.get("end", 0.0)
        # Whisper segments 通常 5s/段，可能含多句，按中文标点拆
        for piece in re.split(r"(?<=[。！？!?])", text):
            piece = piece.strip()
            if not piece:
                continue
            srt_entries.append({"idx": idx, "start": start, "end": end, "text": piece})
            idx += 1
    # 合并过短的 entry
    merged = []
    for e in srt_entries:
        if merged and (len(e["text"]) < max_chars // 2 or (e["end"] - e["start"]) < min_dur):
            prev = merged[-1]
            prev["end"] = e["end"]
            prev["text"] = prev["text"] + e["text"]
        else:
            merged.append(dict(e))
    # 格式化 SRT
    lines = []
    for e in merged:
        lines.append(str(e["idx"]))
        lines.append(f"{fmt_srt_time(e['start'])} --> {fmt_srt_time(e['end'])}")
        lines.append(e["text"])
        lines.append("")
    return "\n".join(lines)


def fmt_srt_time(sec: float) -> str:
    """秒 → HH:MM:SS,mmm"""
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = sec - h * 3600 - m * 60
    si = int(s)
    ms = int((s - si) * 1000)
    return f"{h:02d}:{m:02d}:{si:02d},{ms:03d}"


def main():
    parser = argparse.ArgumentParser(description="gen_srt_from_mp3.py — Whisper 自动生成 SRT")
    parser.add_argument("mp3", help="mp3 文件路径")
    parser.add_argument("--output", "-o", required=True, help="输出 SRT 路径")
    parser.add_argument("--max-chars", type=int, default=30, help="单条最大字符（超了合并）")
    parser.add_argument("--min-dur", type=float, default=0.5, help="单条最小时长秒（小于合并）")
    parser.add_argument("--language", default="zh", help="Whisper 语言")
    args = parser.parse_args()

    mp3 = Path(args.mp3)
    if not mp3.exists():
        print(f"[FAIL] mp3 不存在: {mp3}")
        sys.exit(1)

    print(f"🔄 Whisper 转写 {mp3}...")
    data = run_whisper(mp3, args.language)
    segments = data.get("segments", [])
    if not segments:
        print(f"[FAIL] Whisper 未返回 segments")
        sys.exit(1)

    print(f"✅ Whisper 转写完成: {len(segments)} 段")
    srt = segments_to_srt(segments, args.max_chars, args.min_dur)
    Path(args.output).write_text(srt, encoding="utf-8")
    entries = srt.count("\n\n") + 1
    print(f"✅ SRT 写入 {args.output}: {entries} entries")


if __name__ == "__main__":
    main()
