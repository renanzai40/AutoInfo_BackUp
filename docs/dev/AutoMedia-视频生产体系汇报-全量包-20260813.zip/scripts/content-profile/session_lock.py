#!/usr/bin/env python3
"""
session_lock.py — 防止多 session 并行抢活（2026-06-05 P0-4 新增）

触发：cron 8:30 推送前、Pre-production 启动前、Remotion 渲染前——
任一时间点防止 2+ 个 session 同时跑同一任务。

设计原则：
- 跨 session 互斥（不是跨进程）
- 抢不到锁静默退出（不报错）——其他 session 已在跑
- 锁文件在 /tmp（重启系统自动清，避免死锁）
- 5s timeout 防止永久阻塞
- 2026-06-06 P0：lock 文件 max_age 自动清理（防历史 lock 残留）
  当锁文件 mtime 超过 max_age_sec（默认 3600s = 1h）且 flock 抢不到时，
  视为僵尸 lock，自动 unlink 后重抢。安全：unlink 不影响持锁进程的
  fcntl flock（Linux 设计，inode 删除但 flock 仍有效），新进程重新
  打开新文件 + flock 成功。

使用：
  # 1. CLI（cron 8:30 prompt 里调用）
  python3 ~/.hermes/profiles/content/scripts/session_lock.py \\
      --name auto_media_top3_push
  # exit 0 = 抢到锁或抢不到都正常退出（看 stdout）
  # exit 1 = 参数错或严重错误

  # 2. Python import（cron script 或 subagent 内）
  from session_lock import session_lock
  with session_lock("auto_media_top3_push") as got:
      if not got:
          print("其他 session 已在跑，静默退出")
          sys.exit(0)
      # 跑推送逻辑

设计反模式（永久禁止）：
- ❌ 加 retry 机制（3 个 session 抢锁更糟）
- ❌ 加重试 + backoff（仍然多 session 抢活）
- ❌ 锁不放（fcntl 自动放，必须 with 模式）
- ❌ 锁文件放 /var/lock（权限问题）
- ❌ 主动 unlink 正在用的 lock 文件（max_age 机制只在 flock 失败后兜底）
"""
import fcntl
import os
import sys
import argparse
import time
from contextlib import contextmanager

LOCK_DIR = "/tmp"
# 2026-06-06 P0：lock 文件最大存活时间。cron 8:30 推送典型 5-10 分钟，3D 渲染最多
# 1-2 小时。设 1 小时（3600s）作为兜底，超过则视为僵尸 lock 自动清理。
DEFAULT_MAX_AGE_SEC = 3600


@contextmanager
def session_lock(name="auto_media", timeout_sec=5, max_age_sec=DEFAULT_MAX_AGE_SEC):
    """跨 session 互斥锁（2026-06-06 P0 加 max_age 自动清理）。

    Args:
        name: 锁名（不同任务用不同锁名，避免误锁）
        timeout_sec: 等待锁的最长时间
        max_age_sec: lock 文件最大存活时间。flock 抢不到时若 lock 文件 mtime
            超过这个值，视为僵尸 lock，自动 unlink 后重抢。默认 3600s。
            设为 0 禁用此功能。

    Yields:
        bool: True=抢到锁，False=抢不到
    """
    if not name.replace("_", "").isalnum():
        raise ValueError(f"锁名只能含字母数字下划线: {name!r}")

    lock_path = os.path.join(LOCK_DIR, f"session_lock_{name}.lock")

    def _try_acquire_once():
        """尝试抢一次锁。返回 (acquired: bool, lock_age: float or None)。"""
        # 检查 lock 文件是否存在（mtime 检查）
        lock_age = None
        if os.path.exists(lock_path):
            try:
                lock_age = time.time() - os.path.getmtime(lock_path)
            except OSError:
                lock_age = None

        fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o644)
        try:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return True, lock_age
            except (IOError, OSError):
                os.close(fd)
                return False, lock_age
        except Exception:
            try:
                os.close(fd)
            except Exception:
                pass
            raise

    def _reap_zombie_lock(lock_age):
        """flock 抢不到且 lock 文件超过 max_age 时，unlink 后重试一次。"""
        if max_age_sec <= 0 or lock_age is None:
            return False
        if lock_age <= max_age_sec:
            return False
        try:
            os.unlink(lock_path)
            print(
                f"⚠️ 锁文件 mtime={lock_age:.0f}s 超过 max_age={max_age_sec}s，"
                f"unlink 后重抢: {lock_path}",
                file=sys.stderr, flush=True,
            )
            return True
        except OSError as e:
            print(f"⚠️ unlink 僵尸 lock 失败: {e}", file=sys.stderr, flush=True)
            return False

    # 主循环：先尝试一次，若失败则等 timeout_sec 重试
    acquired, lock_age = _try_acquire_once()
    if not acquired and _reap_zombie_lock(lock_age):
        # 重试一次（unlink 后 flock 一定能抢到）
        acquired, lock_age = _try_acquire_once()

    if acquired:
        try:
            yield True
        finally:
            try:
                os.unlink(lock_path)
            except OSError:
                pass
        return

    # 抢不到锁（lock 存在但未过期），等 timeout_sec 重试
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o644)
    try:
        start = time.time()
        got = False
        while time.time() - start < timeout_sec:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                got = True
                break
            except (IOError, OSError):
                time.sleep(0.5)
        if got:
            try:
                yield True
            finally:
                try:
                    os.unlink(lock_path)
                except OSError:
                    pass
        else:
            yield False
    finally:
        try:
            os.close(fd)
        except Exception:
            pass


def main():
    p = argparse.ArgumentParser(description="session_lock.py — 防止多 session 并行抢活")
    p.add_argument("--name", default="auto_media", help="锁名（不同任务用不同名）")
    p.add_argument("--hold", type=int, default=0,
                   help="持锁时长（秒）。0=默认 60s。cron 8:30 推送典型 < 60s 足够。")
    p.add_argument("--wait-timeout", type=int, default=5,
                   help="等待锁的最长时间（秒），抢不到锁时重试。默认 5s。")
    p.add_argument("--max-age", type=int, default=DEFAULT_MAX_AGE_SEC,
                   help="锁文件最大存活秒数。flock 抢不到且 mtime 超过这个值视为僵尸，"
                        f"自动 unlink 后重抢。默认 {DEFAULT_MAX_AGE_SEC}s（1h）。0=禁用。")
    p.add_argument("--check-only", action="store_true", help="只检查锁状态，不抢锁")
    args = p.parse_args()

    if args.check_only:
        # 只检查
        lock_path = os.path.join(LOCK_DIR, f"session_lock_{args.name}.lock")
        if os.path.exists(lock_path):
            age = time.time() - os.path.getmtime(lock_path)
            print(f"⚠️ 锁存在: {lock_path} (mtime {age:.0f}s ago)")
            sys.exit(1)
        else:
            print(f"✅ 锁不存在: {lock_path}")
            sys.exit(0)

    # 抢锁模式：持锁一段时间（防 cron 推送期间其他 session 抢活）
    # hold = 0 → 默认 60s（cron 推送安全窗口）
    # hold = N → 持锁 N 秒
    hold_sec = max(60, args.hold) if args.hold <= 0 else args.hold
    if args.hold > 0:
        hold_sec = args.hold  # user 显式指定就用 user 的

    with session_lock(args.name, timeout_sec=args.wait_timeout, max_age_sec=args.max_age) as got:
        if got:
            print(f"✅ 抢到 lock: {args.name}（持锁 {hold_sec}s, max_age={args.max_age}s）")
            try:
                time.sleep(hold_sec)
            except KeyboardInterrupt:
                print(f"⚠️ 收到 SIGINT，立即释放 lock")
            sys.exit(0)
        else:
            print(f"⚠️ 抢不到 lock（其他 session 已在跑），静默退出")
            sys.exit(0)  # 静默退出，不报错


if __name__ == "__main__":
    main()
