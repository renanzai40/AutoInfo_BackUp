#!/usr/bin/env python3
"""
HyperFrames Composition QA Checker — Gate V6

Usage:
    python3 check_composition_qa.py <path/to/index.html> [--verbose]

Checks:
  [V6-1] Font-size floor  — all visible text ≥ 20px
  [V6-2] Top spacing      — foreground elements top ≥ 300px
  [V6-3] Bottom spacing   — foreground elements top ≤ 1620px (1920-300)
  [V6-4] Duplicate class  — no two class="..." in same tag
  [V6-5] CSS syntax       — no prop=value (should be prop:value) in style="..."

Exit: 0 if all pass, 1 if any fail.
"""

import re
import sys


def check(path, verbose=False):
    with open(path, encoding="utf-8") as f:
        html = f.read()

    errors = []

    # ── V6-1: Font-size floor ─────────────────────────────────────
    font_sizes = re.findall(r"font-size:(\d+)px", html)
    for s in font_sizes:
        val = int(s)
        if val < 20:
            ctx = _find_context(html, f"font-size:{s}px", 50)
            errors.append(f"[V6-1] font-size {val}px < 20px …{ctx}")

    # ── V6-5: CSS syntax (prop=value instead of prop:value) ──────
    for m in re.finditer(r'"([^"]*)"', html):
        style_val = m.group(1)
        if not style_val.startswith("position:") and not style_val.startswith("display:"):
            if ":" not in style_val[:20]:
                continue  # not a style attribute, skip
        for bad in re.finditer(r"([a-z-]+)=(\d+px)", style_val):
            prop, val = bad.groups()
            start = max(0, m.start() - 20)
            ctx = html[start : m.end() + 10].replace("\n", " ")
            errors.append(
                f"[V6-5] CSS syntax error '{prop}={val}' → should be '{prop}:{val}' "
                f"…{ctx}…"
            )

    # ── V6-4: Duplicate HTML attributes ──────────────────────────
    for attr in ["class", "id", "style"]:
        # Pattern: <tag ... attr="..." ... attr="..." >
        pat = re.compile(
            rf'<(\w+)(?:[^>]*?)\s+{attr}="([^"]*)"(?:[^>]*?)\s+{attr}="([^"]*)"',
            re.DOTALL,
        )
        for m in pat.finditer(html):
            tag = m.group(1)
            v1, v2 = m.group(2), m.group(3)
            # highlight 80 char window
            start = max(0, m.start())
            ctx = html[start : start + 90].replace("\n", " ")
            if v1 != v2:
                errors.append(
                    f"[V6-4] Duplicate '{attr}=' in <{tag}> "
                    f"(1='{v1}', 2='{v2}') …{ctx}…"
                )

    # ── V6-6 / V6-7 / V6-8: Clip metadata attributes ────────────
    # Every element with class="clip ..." must have data-start, data-duration, data-track-index
    # (skipped for elements inside <style>/<script>/<audio>)
    clip_re = re.compile(r'<(\w+)(?:\s[^>]*?class=\"[^\"]*\bclip\b[^\"]*\")([^>]*)>', re.DOTALL)
    for m in clip_re.finditer(html):
        tag = m.group(1)
        attrs = m.group(2)
        start_ok = 'data-start=' in attrs or 'data-start =' in attrs
        dur_ok   = 'data-duration=' in attrs or 'data-duration =' in attrs
        track_ok = 'data-track-index=' in attrs or 'data-track-index =' in attrs
        if not start_ok:
            ctx = html[max(0,m.start()):m.end()+30].replace('\n',' ')
            errors.append(f"[V6-6] <{tag} class=\"clip\"> missing data-start …{ctx}…")
        if not dur_ok:
            ctx = html[max(0,m.start()):m.end()+30].replace('\n',' ')
            errors.append(f"[V6-7] <{tag} class=\"clip\"> missing data-duration …{ctx}…")
        if not track_ok:
            ctx = html[max(0,m.start()):m.end()+30].replace('\n',' ')
            errors.append(f"[V6-8] <{tag} class=\"clip\"> missing data-track-index …{ctx}…")

    # ── V6-2 / V6-3: Top / bottom spacing ────────────────────────
    TOP_MIN = 300
    TOP_MAX = 1620  # 1920 - 300

    for m in re.finditer(
        r'style="[^"]*position:absolute[^"]*top:(\d+)px[^"]*"', html
    ):
        top = int(m.group(1))
        style_ctx = m.group(0)

        # Skip full-screen backgrounds (top:0 + left:0 + full size)
        is_bg = (
            "left:0" in style_ctx
            and (
                "width:1080px;height:1920px" in style_ctx
                or "width:1920px;height:1080px" in style_ctx
            )
        )
        if top == 0 and is_bg:
            continue

        if top < TOP_MIN:
            start = max(0, m.start() - 20)
            ctx = html[start : m.end() + 10].replace("\n", " ")
            errors.append(f"[V6-2] Foreground top:{top}px < {TOP_MIN}px …{ctx}…")
        elif top > TOP_MAX:
            start = max(0, m.start() - 20)
            ctx = html[start : m.end() + 10].replace("\n", " ")
            errors.append(f"[V6-3] Foreground top:{top}px > {TOP_MAX}px (too close to bottom) …{ctx}…")

    # ── Report ────────────────────────────────────────────────────
    if not errors:
        print(f"✅ {path} — Composition QA passed")
        return True

    print(f"❌ {path} — {len(errors)} composition QA error(s):")
    for e in errors:
        print(f"  • {e}")
    return False


def _find_context(html, needle, width=60):
    """Return context around needle in html."""
    idx = html.find(needle)
    if idx < 0:
        return needle
    start = max(0, idx - width)
    end = min(len(html), idx + len(needle) + width)
    return html[start:end].replace("\n", " ")


if __name__ == "__main__":
    verbose = "--verbose" in sys.argv
    paths = [a for a in sys.argv[1:] if not a.startswith("--")]

    if not paths:
        print("Usage: python3 check_composition_qa.py <path/to/index.html> [--verbose]")
        sys.exit(1)

    ok = all(check(p, verbose) for p in paths)
    sys.exit(0 if ok else 1)
