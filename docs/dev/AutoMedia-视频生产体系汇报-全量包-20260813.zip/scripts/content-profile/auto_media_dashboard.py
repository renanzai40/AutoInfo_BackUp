#!/usr/bin/env python3
"""
auto_media_dashboard.py — 每天 23:00 cron 自动生成 pipeline 状态报告（2026-06-06 P0-5）

触发：cron_2330_dashboard（每天 23:00 CST）
输出：stdout markdown 报告，cron 自动 deliver 到飞书

报告内容：
- 今日入库 / 审 / 判 m3 / 推送 各几条
- 池里 growth/business 比例、angle_score 分布
- cron 任务健康度（last_status / last_error / next_run_at）
- lock 残留数 / output 目录大小

设计原则：
- 不调 LLM，纯 SQL 查 + 文件 glob
- 单文件无外部依赖（仅 sqlite3 + json + pathlib）
- 失败时 stderr 报错，exit 1；输出空报告时仍 exit 0
"""
import json
import os
import sqlite3
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

# === 配置 ===
POOL_DB = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db"
JOBS_JSON = "/home/renanzai/.hermes/profiles/content/cron/jobs.json"
OUTPUT_DIR = "/home/renanzai/.hermes/profiles/content/cron/output"
LOCK_DIR = "/tmp"
CRON_JOB_IDS = {
    "143d19e69a7c": "08:00 热点采集",
    "audit_08x05": "08:05 语义审核",
    "judge_angles_08x10": "08:10 m3 角度分判定",
    "7671da210b69": "08:30 话题池汇总推送",
    "maintenance_01": "07:30 新鲜度维护",
    "wdog_auto_media": "09:30 watchdog 健康检查",
    "judge_angles_12x00": "12:00 m3 角度分判定",
    "judge_angles_16x00": "16:00 m3 角度分判定",
}


def get_today_cst():
    """今天 CST 00:00 到 24:00 的 ISO 范围"""
    cst = timezone(timedelta(hours=8))
    now = datetime.now(cst)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=1)
    return start.isoformat(), end.isoformat()


def safe_query(sql, params=()):
    """跑 SQL，失败返回 None 不崩"""
    try:
        if not os.path.exists(POOL_DB):
            return None
        c = sqlite3.connect(POOL_DB)
        c.row_factory = sqlite3.Row
        rows = c.execute(sql, params).fetchall()
        c.close()
        return rows
    except Exception as e:
        print(f"⚠️ SQL fail: {e}", file=sys.stderr)
        return None


def safe_load_jobs():
    try:
        with open(JOBS_JSON) as f:
            return json.load(f).get("jobs", [])
    except Exception as e:
        print(f"⚠️ jobs.json load fail: {e}", file=sys.stderr)
        return []


def fmt_age(iso):
    """把 ISO 时间转成 'X 分钟前' / 'X 小时前' / 'X 天前'"""
    if not iso:
        return "—"
    try:
        cst = timezone(timedelta(hours=8))
        then = datetime.fromisoformat(iso)
        if then.tzinfo is None:
            then = then.replace(tzinfo=cst)
        now = datetime.now(cst)
        delta = now - then
        s = int(delta.total_seconds())
        if s < 0:
            return "future"
        if s < 60:
            return f"{s}s ago"
        if s < 3600:
            return f"{s // 60}m ago"
        if s < 86400:
            return f"{s // 3600}h ago"
        return f"{s // 86400}d ago"
    except Exception:
        return "?"


def section_pool_stats(start_iso, end_iso):
    """池子统计：今日入库/审/m3/推 + 整体分布"""
    lines = ["## 📊 话题池统计", ""]

    # 今日入库
    rows = safe_query(
        "SELECT source, COUNT(*) AS n FROM topics WHERE created_at >= ? AND created_at < ? GROUP BY source ORDER BY n DESC",
        (start_iso, end_iso),
    )
    if rows is not None:
        if rows:
            total = sum(r["n"] for r in rows)
            lines.append(f"**今日入库**: {total} 条")
            for r in rows:
                lines.append(f"  - {r['source']}: {r['n']}")
        else:
            lines.append("**今日入库**: 0 条")
    else:
        lines.append("**今日入库**: ⚠️ DB 读失败")
    lines.append("")

    # 池里分布
    rows = safe_query(
        "SELECT category, COUNT(*) AS n FROM topics GROUP BY category"
    )
    if rows:
        lines.append("**池子总量**（按 category）:")
        for r in rows:
            lines.append(f"  - {r['category']}: {r['n']}")
    lines.append("")

    # angle_score 分布
    rows = safe_query(
        "SELECT "
        "  SUM(CASE WHEN angle_score IS NULL THEN 1 ELSE 0 END) AS null_n, "
        "  SUM(CASE WHEN angle_score >= 7 THEN 1 ELSE 0 END) AS high_n, "
        "  SUM(CASE WHEN angle_score >= 4 AND angle_score < 7 THEN 1 ELSE 0 END) AS mid_n, "
        "  SUM(CASE WHEN angle_score < 4 THEN 1 ELSE 0 END) AS low_n "
        "FROM topics"
    )
    if rows:
        r = rows[0]
        lines.append("**angle_score 分布**:")
        lines.append(f"  - NULL（未判）: {r['null_n'] or 0}")
        lines.append(f"  - ≥ 7（高分）: {r['high_n'] or 0}")
        lines.append(f"  - 4-7（中分）: {r['mid_n'] or 0}")
        lines.append(f"  - < 4（低分）: {r['low_n'] or 0}")
    lines.append("")

    # 推送池
    rows = safe_query(
        "SELECT category, COUNT(*) AS n FROM topics "
        "WHERE status='pending' AND review_status='approved' "
        "AND angle_score IS NOT NULL AND angle_score >= 7 "
        "GROUP BY category"
    )
    if rows is not None:
        lines.append("**推送池**（angle ≥ 7 + pending + approved）:")
        if rows:
            for r in rows:
                lines.append(f"  - {r['category']}: {r['n']}")
        else:
            lines.append("  - （空）")
    return "\n".join(lines)


def section_cron_health(jobs):
    """cron 任务健康度"""
    lines = ["", "## ⚙️ cron 任务健康度", ""]
    lines.append("| 任务 | 状态 | last_run | next_run |")
    lines.append("|------|------|----------|----------|")
    for j in jobs:
        jid = j.get("id") or j.get("job_id") or "?"
        name = j.get("name", "?")[:40]
        # 取名字里时间标识（08:00 / 08:10 等）
        import re
        m = re.search(r"\d{1,2}:\d{2}", name)
        time_label = m.group() if m else "—"
        # 取 task 简称
        if "热点采集" in name:
            short = "📥 热点采集"
        elif "审核" in name:
            short = "🔍 审核"
        elif "m3 角度分" in name:
            short = "🎯 m3 判定"
        elif "推送" in name:
            short = "📤 推送"
        elif "维护" in name:
            short = "🔧 维护"
        elif "watchdog" in name.lower() or "Watchdog" in name:
            short = "🐕 watchdog"
        else:
            short = name[:30]
        status = j.get("last_status", "—") or "—"
        status_icon = {"ok": "✅", "error": "❌", "—": "—"}.get(status, "❓")
        last_age = fmt_age(j.get("last_run_at"))
        next_at = j.get("next_run_at", "—")
        if next_at and next_at != "—":
            next_short = next_at[:16].replace("T", " ")
        else:
            next_short = "—"
        lines.append(f"| {time_label} {short} | {status_icon} {status} | {last_age} | {next_short} |")
        # 错误行
        if j.get("last_error"):
            err = str(j.get("last_error"))[:80]
            lines.append(f"|  | ⚠️ _{err}_ | | |")
    return "\n".join(lines)


def section_lock_status():
    """lock 残留 + output 目录"""
    lines = ["", "## 🔒 lock 残留 & output", ""]
    locks = []
    for p in Path(LOCK_DIR).glob("session_lock_*.lock"):
        if not p.is_file():
            continue
        try:
            age = time.time() - p.stat().st_mtime
            locks.append((p.name, age))
        except OSError:
            pass
    if locks:
        lines.append(f"**{len(locks)} 个 session_lock 残留**:")
        # 只列超过 1 分钟的（刚抢到的锁正常）
        for name, age in sorted(locks, key=lambda x: -x[1]):
            if age > 60:
                lines.append(f"  - ⚠️ `{name}` ({fmt_age(int(age))})")
            else:
                lines.append(f"  - ✅ `{name}` ({fmt_age(int(age))})")
    else:
        lines.append("**session_lock 残留**: 无 ✅")
    lines.append("")

    # output 目录大小
    try:
        total = 0
        n_files = 0
        for p in Path(OUTPUT_DIR).rglob("*.md"):
            try:
                total += p.stat().st_size
                n_files += 1
            except OSError:
                pass
        mb = total / 1024 / 1024
        lines.append(f"**output/ 目录**: {n_files} 个 .md 文件, {mb:.1f} MB")
    except Exception as e:
        lines.append(f"**output/ 目录**: ⚠️ {e}")
    return "\n".join(lines)


def main():
    start_iso, end_iso = get_today_cst()
    cst = timezone(timedelta(hours=8))
    now_str = datetime.now(cst).strftime("%Y-%m-%d %H:%M CST")

    jobs = safe_load_jobs()

    parts = [
        f"# 🌙 AutoMedia 每日 dashboard ({now_str})",
        "",
        section_pool_stats(start_iso, end_iso),
        section_cron_health(jobs),
        section_lock_status(),
        "",
        "---",
        "由 `auto_media_dashboard.py` 自动生成（cron_2330_dashboard 任务触发）",
    ]
    print("\n".join(parts))
    sys.exit(0)


if __name__ == "__main__":
    main()
