#!/usr/bin/env python3
"""
ComfyUI batch image generator for AutoMedia projects.
Generates inline images + covers for a given project, based on its research notes.
Uses direct ComfyUI REST API.
"""

import json
import os
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

COMFY_HOST = "http://127.0.0.1:8188"
SD15_WORKFLOW = {
    "3": {"class_type": "KSampler", "inputs": {"seed": 42, "steps": 20, "cfg": 7, "sampler_name": "euler", "scheduler": "normal", "denoise": 1,
        "model": ["4", 0], "positive": ["6", 0], "negative": ["7", 0], "latent_image": ["5", 0]}},
    "4": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": "v1-5-pruned-emaonly.safetensors"}},
    "5": {"class_type": "EmptyLatentImage", "inputs": {"width": 512, "height": 512, "batch_size": 1}},
    "6": {"class_type": "CLIPTextEncode", "inputs": {"text": "", "clip": ["4", 1]}},
    "7": {"class_type": "CLIPTextEncode", "inputs": {"text": "blurry, low quality, distorted, watermark, text, signature", "clip": ["4", 1]}},
    "8": {"class_type": "VAEDecode", "inputs": {"samples": ["3", 0], "vae": ["4", 2]}},
    "9": {"class_type": "SaveImage", "inputs": {"filename_prefix": "output", "images": ["8", 0]}},
}


def submit_prompt(workflow):
    """Submit a prompt to ComfyUI and return the prompt_id."""
    payload = json.dumps({"prompt": workflow}).encode("utf-8")
    req = urllib.request.Request(f"{COMFY_HOST}/prompt", data=payload,
                                 headers={"Content-Type": "application/json"})
    resp = json.loads(urllib.request.urlopen(req).read())
    return resp["prompt_id"]


def wait_for_completion(prompt_id, timeout=120):
    """Wait for a prompt to complete and return the output filename."""
    start = time.time()
    while time.time() - start < timeout:
        try:
            req = urllib.request.Request(f"{COMFY_HOST}/history/{prompt_id}")
            resp = json.loads(urllib.request.urlopen(req).read())
            data = resp.get(prompt_id, {})
            if data.get("status", {}).get("completed"):
                # Get output filenames
                outputs = data.get("outputs", {})
                for node_id, node_out in outputs.items():
                    for media_type, files in node_out.items():
                        for f in files:
                            filename = f.get("filename", "")
                            if filename:
                                return filename
                return None
        except (urllib.error.URLError, json.JSONDecodeError):
            pass
        time.sleep(2)
    raise TimeoutError(f"Prompt {prompt_id} did not complete in {timeout}s")


def copy_to_project(src_filename, dest_path):
    """Copy generated file from ComfyUI output to project directory."""
    src = Path.home() / "comfy" / "ComfyUI" / "output" / src_filename
    if src.exists():
        dest = Path(dest_path)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(src.read_bytes())
        print(f"  ✅ Copied to {dest}")
        return True
    else:
        print(f"  ❌ Source not found: {src}")
        return False


def generate_image(prompt, seed, prefix):
    """Generate one image and return the output filename."""
    wf = json.loads(json.dumps(SD15_WORKFLOW))
    wf["6"]["inputs"]["text"] = prompt
    wf["3"]["inputs"]["seed"] = seed
    wf["9"]["inputs"]["filename_prefix"] = prefix
    pid = submit_prompt(wf)
    print(f"  Submitted: {pid[:8]}... (seed={seed})")
    filename = wait_for_completion(pid)
    print(f"  Generated: {filename}")
    return filename


def main():
    if len(sys.argv) < 2:
        print("Usage: gen_ui_images.py <project_dir>")
        sys.exit(1)

    project_dir = Path(sys.argv[1])
    print(f"\n=== Generating images for {project_dir.name} ===")

    output_root = project_dir / "01_content" / "drafts" / "wechat" / "images"
    cover_dir = project_dir / "02_images" / "cover"
    output_root.mkdir(parents=True, exist_ok=True)
    cover_dir.mkdir(parents=True, exist_ok=True)

    # Read research notes for context
    research_file = project_dir / "00_research" / "research_notes.md"
    topic_context = ""
    if research_file.exists():
        topic_context = research_file.read_text()[:300]

    # Read script for visual cues
    script_file = project_dir / "03_video" / "script.txt"
    if script_file.exists():
        topic_context += "\n" + script_file.read_text()[:200]

    print(f"Topic context: {topic_context[:100]}...")
    print()

    # ── Generate inline images ──
    inline_prompts = [
        f"Professional office desk with modern technology equipment, clean lighting, minimal style, {topic_context[:100]}",
        f"Business team collaborating around a digital screen, modern office, warm lighting, professional atmosphere, {topic_context[:100]}",
        f"Abstract technology concept, glowing blue digital lines representing AI and data flow, dark background, elegant design, {topic_context[:100]}",
    ]

    print("--- Inline Images (wechat) ---")
    for i, prompt in enumerate(inline_prompts, 1):
        print(f"[{i}/3] Generating wechat_img_{i}...")
        prefix = f"wechat_img_{i}"
        filename = generate_image(prompt, seed=100 + i, prefix=prefix)
        copy_to_project(filename, output_root / f"wechat_img_{i}.png")

    # ── Generate cover images ──
    cover_prompts = {
        "16x9": f"Wide banner, modern technology concept, blue and gold gradient, professional business style, clean typography space, {topic_context[:80]}",
        "9x16": f"Vertical poster, modern technology style, blue theme, professional business aesthetic, text space at top and bottom, {topic_context[:80]}",
        "3x4": f"Square format, technology and business concept, clean modern design, blue and dark theme, centered composition, {topic_context[:80]}",
    }

    print("\n--- Cover Images ---")
    for size, prompt in cover_prompts.items():
        print(f"Generating cover_{size}...")
        wf = json.loads(json.dumps(SD15_WORKFLOW))
        wf["6"]["inputs"]["text"] = prompt
        wf["3"]["inputs"]["seed"] = hash(size) % 10000 + 200
        prefix = f"cover_{size}"
        wf["9"]["inputs"]["filename_prefix"] = prefix
        # Adjust size based on aspect ratio
        if size == "16x9":
            wf["5"]["inputs"]["width"] = 640
            wf["5"]["inputs"]["height"] = 360
        elif size == "9x16":
            wf["5"]["inputs"]["width"] = 360
            wf["5"]["inputs"]["height"] = 640
        else:
            wf["5"]["inputs"]["width"] = 512
            wf["5"]["inputs"]["height"] = 512
        pid = submit_prompt(wf)
        print(f"  Submitted: {pid[:8]}...")
        filename = wait_for_completion(pid)
        print(f"  Generated: {filename}")
        copy_to_project(filename, cover_dir / f"cover_{size}.png")

    print("\n✅ Done!")


if __name__ == "__main__":
    main()
