#!/usr/bin/env python3
"""AutoMedia 漏采补偿采集器 — catchup_collection.py

场景：关机/故障导致采集错过窗口（0 入库日），开机后把漏采窗口内
「有信号的重要事件」定向找回来。本次目标：验证能否用通用机制
挖出漏采窗口内错过的重大发布（闭卷：脚本不写死任何具体事件）。

核心原则：
- 不写死任何具体新闻/实体事件，信号全部来自：
  A. 池子里 archived 的「预告/即将发布」类话题 → 提取实体 → 定向搜索
  B. 通用实体表 × 动作词组合查询（Tavily week-range 扫漏采窗口）
- 不做全量 7 天回扫（噪声大），只追有信号的
- 结果先报告给人，挑中才写入池子（--apply），不污染自动流程

用法：
  python3 catchup_collection.py              # 检测 + 补偿候选（只报告，不入库）
  python3 catchup_collection.py --apply N    # 把候选 N 写入池子（正常 pending 流程）
  python3 catchup_collection.py --window 7   # 指定漏采检测窗口天数
"""
import os
import sys
import re
import json
import sqlite3
import hashlib
import subprocess
import argparse
from datetime import datetime, timedelta
from pathlib import Path

# ============================================================================
# 常量
# ============================================================================
DB_PATH = '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db'
ENV_FILE = '/home/renanzai/.hermes/profiles/content/.env'
EXEC_DB = os.path.expanduser('~/.hermes/profiles/content/cron/executions.db')
COLLECT_JOB_ID = '143d19e69a7c'
OUTPUT_DIR = os.path.expanduser('~/.hermes/profiles/content/cron/output')

# ============================================================================
# 通用实体表（与主采集脚本 INFO_ENTITIES 同源，非本次事件定制）
# ============================================================================
ENTITY_MASTER = [
    'DeepSeek', 'OpenAI', 'Anthropic', 'Google', 'Meta', 'Microsoft', '微软',
    '字节', '字节跳动', '小米', '华为', '腾讯', '阿里', '百度', 'MiniMax',
    'GPT', 'Claude', 'Gemini', 'Qwen', '千问', 'Kimi', '豆包', '文心', '混元',
    '苹果', 'Apple', '英伟达', 'NVIDIA', '英伟达', 'OpenRouter', 'Perplexity',
    '蚂蚁', '阶跃', '智谱', '商汤', '科大讯飞', '京东', '拼多多',
]

# 预告类话题标题信号（池子里 archived 话题的跟进依据）
PREVIEW_TITLE_PATTERNS = [
    r'即将发布', r'将发布', r'预告', r'何时发布', r'正式版', r'计划发布',
    r'有望发布', r'即将推出', r'将推出', r'即将上线', r'马上到来', r'将至',
    r'coming', r'expected', r'rumored', r'传闻',
]

# 动作词（信号段 B 组合用）
ACTION_WORDS = ['正式版', '发布', '开源', '上线', '融资', '收购', '降价']

# 内容农场标题正则（复用主采集脚本 TITLE_BLOCK_PATTERNS 子集）
TITLE_BLOCK_PATTERNS = [
    r'AI工具导航', r'什么值得买', r'\(2026年最新\)', r'，\w+技巧$',
    r'^如何\w+', r'点点资讯', r'雷峰网', r'^\#\w+\s',
]

# ============================================================================
# 工具
# ============================================================================

def get_tavily_key():
    with open(ENV_FILE) as f:
        for line in f:
            if line.startswith('TAVILY_API_KEY=') and not line.startswith('#'):
                return line.split('=', 1)[1].strip()
    return None


def tavily_search(query, time_range='week', max_results=10):
    key = get_tavily_key()
    if not key:
        print(f"  [FATAL] TAVILY_API_KEY not found in {ENV_FILE}")
        return []
    env = {**os.environ, 'TAVILY_API_KEY': key}
    try:
        result = subprocess.run(
            ['tvly', 'search', query, '--time-range', time_range,
             '--max-results', str(max_results), '--json'],
            capture_output=True, text=True, timeout=60, env=env
        )
        data = json.loads(result.stdout)
        return [{'title': item.get('title', ''),
                 'url': item.get('url', ''),
                 'score': item.get('score', 0),
                 'content': item.get('content', '')[:300]}
                for item in data.get('results', [])]
    except Exception as e:
        print(f"  [tavily] {query[:25]}... 失败: {type(e).__name__}: {e}")
        return []


def extract_entities(title):
    """从标题提取实体（命中 ENTITY_MASTER 的返回实体列表）"""
    hits = []
    for ent in ENTITY_MASTER:
        if ent in title:
            hits.append(ent)
    return hits


def parse_date_from_text(text):
    """从正文提取日期 YYYY-MM-DD 或 YYYY年MM月DD日，无则 None"""
    m = re.search(r'(20\d{2})[-/年](\d{1,2})[-/月](\d{1,2})', text or '')
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    return None


def info_density_pass(title):
    """简化信息密度：实体 + 动作（Tavily 已按相关度排序，够用）"""
    if any(re.search(p, title) for p in TITLE_BLOCK_PATTERNS):
        return False
    has_ent = len(extract_entities(title)) > 0
    has_act = any(a in title for a in ACTION_WORDS)
    return has_ent and has_act


# ============================================================================
# ① 检测段：近 N 天漏采/异常窗口
# ============================================================================

def detect_missing_days(window_days):
    """返回 (漏采日列表, 异常日列表, 每日入库 dict)"""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    since = (datetime.now() - timedelta(days=window_days)).strftime('%Y-%m-%d')
    cur.execute("""
        SELECT substr(created_at,1,10) d, COUNT(*)
        FROM topics WHERE created_at >= ? GROUP BY d
    """, (since,))
    daily = {r[0]: r[1] for r in cur.fetchall()}
    conn.close()

    missing, abnormal = [], []
    for i in range(window_days - 1, -1, -1):
        day = (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d')
        cnt = daily.get(day, 0)
        if cnt == 0:
            missing.append(day)
        elif cnt < 5:
            abnormal.append((day, cnt))
    return missing, abnormal, daily


# ============================================================================
# ② 信号段 A：池子 archived 预告话题 → 实体 → 定向查询
# ============================================================================

def preview_topic_signals():
    """从池子 archived 话题里找预告类，返回 [(实体, 原话题标题)]"""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    like_conds = ' OR '.join([f"title LIKE '%{p.strip('r')}%'" for p in []])  # placeholder
    # 直接按正则匹配内存过滤（标题量不大）
    cur.execute("""
        SELECT topic_id, title FROM topics
        WHERE status = 'archived'
        ORDER BY created_at DESC LIMIT 500
    """)
    rows = cur.fetchall()
    conn.close()

    signals = []
    for tid, title in rows:
        if any(re.search(p, title) for p in PREVIEW_TITLE_PATTERNS):
            for ent in extract_entities(title):
                signals.append((ent, title[:60]))
                break  # 每个话题取第一个实体即可
    return signals


# ============================================================================
# ③ 信号段 B：通用实体 × 动作词
# ============================================================================

def generic_signals(max_queries=25):
    """实体×动作组合，截断控制成本"""
    queries = []
    # 优先「正式版/发布/开源」这类高价值动作，且优先常见实体
    for ent in ENTITY_MASTER[:20]:
        for act in ['正式版', '开源', '上线']:
            queries.append(f"{ent} {act}")
        if len(queries) >= max_queries:
            break
    return queries[:max_queries]


# ============================================================================
# ④ 候选生成
# ============================================================================

def build_candidates():
    """返回候选列表 [{title,url,score,query,signal_type,entity,event_date}]"""
    # 信号段 A
    preview_signals = preview_topic_signals()
    queries_a = []
    for ent, src_title in preview_signals:
        queries_a.append((f"{ent} 正式版 发布", ent, src_title))

    # 信号段 B
    queries_b = [(q, None, None) for q in generic_signals()]

    # 合并（去重查询）
    seen_q = set()
    all_queries = []
    for q, ent, src in queries_a + queries_b:
        if q not in seen_q:
            seen_q.add(q)
            all_queries.append((q, ent, src))

    print(f"\n=== 信号查询（共 {len(all_queries)} 组）===")
    candidates = []
    for q, ent, src_title in all_queries:
        results = tavily_search(q, time_range='week', max_results=8)
        for r in results:
            title = r['title']
            if not info_density_pass(title):
                continue
            candidates.append({
                'title': title, 'url': r['url'], 'score': r['score'],
                'query': q, 'entity': ent,
                'signal_type': '预告话题跟进' if src_title else '通用实体扫描',
                'preview_src': src_title,
                'event_date': parse_date_from_text(r.get('content', '')),
            })

    # 去重（URL）
    seen_url = set()
    uniq = []
    for c in candidates:
        if c['url'] and c['url'] not in seen_url:
            seen_url.add(c['url'])
            uniq.append(c)
    # 排序：score 降序，取 top 30
    uniq.sort(key=lambda x: x['score'], reverse=True)
    return uniq[:30]


# ============================================================================
# ⑤ 报告输出
# ============================================================================

def render_report(missing, abnormal, daily, candidates):
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    lines = []
    lines.append(f"# 漏采补偿报告 — {now}")
    lines.append("")
    lines.append(f"检测窗口：{len(daily)} 天（近 {max(len(daily), 1)} 天入库分布）")
    if missing:
        lines.append(f"**⛔ 漏采日（0 入库）：{', '.join(missing)}**")
    if abnormal:
        lines.append(f"**⚠️ 异常日（<5 条）：{', '.join(f'{d}({c}条)' for d, c in abnormal)}**")
    if not missing and not abnormal:
        lines.append("✅ 近窗口无漏采/异常。")
    lines.append("")
    lines.append(f"## 补偿候选（{len(candidates)} 条，按相关度排序）")
    if not candidates:
        lines.append("（未找到有信号的重要事件候选）")
    for i, c in enumerate(candidates, 1):
        lines.append(f"{i}. **{c['title']}**")
        lines.append(f"   信号：{c['signal_type']} | 实体：{c['entity'] or '-'} | 查询：{c['query']}")
        if c.get('preview_src'):
            lines.append(f"   跟进自预告话题：{c['preview_src']}")
        if c.get('event_date'):
            lines.append(f"   事件日期：{c['event_date']}")
        lines.append(f"   来源：{c['url']}")
    lines.append("")
    lines.append("用法：`python3 catchup_collection.py --apply N` 把候选 N 写入话题池（正常 pending 流程）")
    return '\n'.join(lines)


# ============================================================================
# ⑥ --apply：候选写入池子
# ============================================================================

def apply_candidate(candidates, idx):
    if idx < 1 or idx > len(candidates):
        print(f"候选序号无效：{idx}（有效 1-{len(candidates)}）")
        return 1
    c = candidates[idx - 1]
    topic_id = hashlib.md5(c['title'].encode()).hexdigest()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
    # category：业务实体→business，其余 growth（简化：DeepSeek 类模型实体归 business）
    biz_ents = ['DeepSeek', 'OpenAI', 'Anthropic', 'Google', 'Meta', 'Microsoft',
                '微软', 'MiniMax', 'GPT', 'Claude', 'Gemini', 'Qwen', '千问',
                'Kimi', '豆包', '文心', '混元', '英伟达', 'NVIDIA']
    is_biz = any(e in c['title'] for e in biz_ents)
    category = 'business' if is_biz else 'growth'
    event_date = c.get('event_date')
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        INSERT OR IGNORE INTO topics
        (topic_id, title, category, heat_score, source, status,
         correlation_score, freshness_score, created_at, updated_at,
         review_status, source_url, event_date)
        VALUES (?, ?, ?, ?, 'Tavily', 'pending', ?, 8.0, ?, ?, 'pending', ?, ?)
    """, (topic_id, c['title'], category, 0.7, 8, now_str, now_str, c['url'], event_date))
    conn.commit()
    inserted = cur.rowcount
    conn.close()
    if inserted:
        print(f"✅ 已写入池子（pending）：{c['title']}")
        print(f"   topic_id={topic_id} | category={category} | event_date={event_date}")
        print(f"   url={c['url']}")
    else:
        print(f"⚠️ 该话题已在池子中（md5 相同），跳过。title={c['title']}")
    return 0


# ============================================================================
# main
# ============================================================================

def main():
    ap = argparse.ArgumentParser(description='AutoMedia 漏采补偿采集器')
    ap.add_argument('--apply', type=int, default=0, help='把候选 N 写入话题池')
    ap.add_argument('--window', type=int, default=7, help='漏采检测窗口天数')
    args = ap.parse_args()

    print("=== ① 漏采检测 ===")
    missing, abnormal, daily = detect_missing_days(args.window)
    for d in sorted(daily):
        mark = ' ⛔漏采' if d in missing else (' ⚠️异常' if any(x[0] == d for x in abnormal) else '')
        print(f"  {d}: {daily.get(d, 0)} 条{mark}")
    if not missing and not abnormal:
        print("  近窗口无漏采/异常 —— 无需补偿")
        # 仍生成候选（用户可能想手动追重大事件），但报告标注正常
    else:
        print(f"  漏采日: {missing or '无'} | 异常日: {abnormal or '无'}")

    print("\n=== ② 信号查询 ===")
    candidates = build_candidates()

    report = render_report(missing, abnormal, daily, candidates)
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_path = os.path.join(OUTPUT_DIR, f"catchup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md")
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(report)
    print("\n" + report)
    print(f"\n报告已写入：{out_path}")

    if args.apply > 0:
        print("\n=== ③ 写入池子 ===")
        rc = apply_candidate(candidates, args.apply)
        return rc
    return 0


if __name__ == '__main__':
    sys.exit(main())
