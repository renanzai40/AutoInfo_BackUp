#!/usr/bin/env python3
"""
audit_pipeline.py — AutoMedia Pipeline Completeness Audit

Scans a project directory and checks every gate's artifacts.
Run after each Track (文案/视频/生命周期) to self-check completeness.

Usage:
    python3 audit_pipeline.py --project <project_dir>
    python3 audit_pipeline.py --project <project_dir> --track copy
    python3 audit_pipeline.py --project <project_dir> --track video
    python3 audit_pipeline.py --project <project_dir> --track lifecycle

Exit code:
    0 = all required gates passed
    1 = one or more gates missing
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path


def check_research(project_dir: Path, results: dict):
    """Gate R0: Research"""
    track = "文案前"
    paths = [
        project_dir / "00_research" / "sources.json",
        project_dir / "00_research" / "research_notes.md",
    ]
    existing = [p for p in paths if p.exists()]
    missing = [p for p in paths if not p.exists()]

    status = "✅" if len(existing) >= 1 else "❌"
    detail = f"00_research/ 下 {len(existing)}/{len(paths)} 文件存在"
    if missing:
        detail += f"，缺: {', '.join(p.name for p in missing)}"
    results["gates"]["R0"] = {"track": track, "status": status, "detail": detail}


def check_template_selection(results: dict):
    """Gate PT: Template Selection — relies on agent process, hard to verify statically."""
    # Weak check: if content exists, likely went through template selection
    results["gates"]["PT"] = {
        "track": "文案前",
        "status": "⚠️",
        "detail": "无静态产物可验 - 仅 agent 流程约束",
    }


def check_platform_diff(project_dir: Path, results: dict):
    """Gate PD: Platform Differentiation — 5 platform drafts exist"""
    track = "文案前"
    draft_dir = project_dir / "01_content" / "drafts"
    if not draft_dir.exists():
        results["gates"]["PD"] = {
            "track": track,
            "status": "❌",
            "detail": "01_content/drafts/ 目录不存在",
        }
        return

    platforms = ["wechat", "xiaohongshu", "zhihu", "bilibili", "tiktok"]
    found = []
    missing = []
    for p in platforms:
        pf = draft_dir / p
        files = list(pf.glob("*"))
        if files:
            found.append(p)
        else:
            missing.append(p)

    status = "✅" if len(found) >= 4 else "❌"  # at least 4 of 5
    results["gates"]["PD"] = {
        "track": track,
        "status": status,
        "detail": f"5平台草稿: 有({', '.join(found)}) / 缺({', '.join(missing)})",
    }


def check_prompt_quality(project_dir: Path, results: dict):
    """Gate PQ: Prompt Quality — verify content-generation-prompt was used"""
    track = "文案"
    review_dir = project_dir / "04_review"
    files = list(review_dir.glob("*prompt*")) + list(review_dir.glob("*Prompt*")) + list(review_dir.glob("*PQ*"))
    
    if files:
        content = files[0].read_text()
        has_content = len(content.strip()) > 50
        status = "✅" if has_content else "⚠️"
        detail = f"存在 {files[0].name}（{'有实质内容' if has_content else '内容过短'}）"
    else:
        # Fallback: check if output passes AI flavor gate (indirect evidence)
        af_file = project_dir / "04_review" / "ai_flavor_report.md"
        if af_file.exists():
            status = "⚠️"
            detail = "无独立 PQ 报告（由 AF gate 间接覆盖）"
        else:
            status = "❌"
            detail = "04_review/ 下无 Prompt Quality 报告 — 可能未使用 content-generation-prompt skill"
    results["gates"]["PQ"] = {"track": track, "status": status, "detail": detail}


def check_ai_flavor(project_dir: Path, results: dict):
    """Gate AF: AI Flavor — verify check_output_ai_flavor.py passed"""
    track = "文案"
    review_dir = project_dir / "04_review"
    files = list(review_dir.glob("*flavor*")) + list(review_dir.glob("*Flavor*")) + \
            list(review_dir.glob("*AI味*")) + list(review_dir.glob("*ai_flavor*"))
    
    if files:
        content = files[0].read_text()
        has_content = len(content.strip()) > 50
        # Check for pass indicators
        passed = "exit=0" in content or "✅" in content[:200]
        if has_content and passed:
            status = "✅"
            detail = f"存在 {files[0].name}（检查通过）"
        elif has_content:
            status = "⚠️"
            detail = f"存在 {files[0].name}（有报告但未明确通过）"
        else:
            status = "❌"
            detail = f"存在 {files[0].name}（内容过短）"
    else:
        status = "❌"
        detail = "04_review/ 下无 AI 味检测报告"
    results["gates"]["AF"] = {"track": track, "status": status, "detail": detail}


def check_fact_check(project_dir: Path, results: dict):
    """Gate C0: Fact Check"""
    track = "文案"
    review_dir = project_dir / "04_review"
    fact_check_files = list(review_dir.glob("*fact*")) + list(review_dir.glob("*Fact*")) + list(review_dir.glob("*事实核查*"))

    if fact_check_files:
        # Check content is non-trivial
        content = fact_check_files[0].read_text()
        has_content = len(content.strip()) > 50
        status = "✅" if has_content else "⚠️"
        detail = f"存在 {fact_check_files[0].name}（{'有实质内容' if has_content else '内容过短'}）"
    else:
        status = "❌"
        detail = "04_review/ 下无事实核查报告"
    results["gates"]["C0"] = {"track": track, "status": status, "detail": detail}


def check_humanizer(project_dir: Path, results: dict):
    """Gate C1: Humanizer"""
    track = "文案"
    review_dir = project_dir / "04_review"
    files = list(review_dir.glob("*human*")) + list(review_dir.glob("*Human*")) + list(review_dir.glob("*AI*"))

    if files:
        content = files[0].read_text()
        has_content = len(content.strip()) > 50
        status = "✅" if has_content else "⚠️"
        detail = f"存在 {files[0].name}（{'有实质内容' if has_content else '内容过短'}）"
    else:
        status = "❌"
        detail = "04_review/ 下无人类化报告"
    results["gates"]["C1"] = {"track": track, "status": status, "detail": detail}


def check_copy_review(project_dir: Path, results: dict):
    """Gate C2: Copy Review — check report exists and has actual edits"""
    track = "文案"
    review_dir = project_dir / "04_review"
    files = list(review_dir.glob("*copy*")) + list(review_dir.glob("*Copy*")) + list(review_dir.glob("*review*"))

    if files:
        content = files[0].read_text()
        # Check for actual modifications (edit markers like +/- or 修改)
        has_edits = any(marker in content for marker in ["- ", "+ ", "修改", "替换", "删除", "添加"])
        has_content = len(content.strip()) > 100
        status = "✅" if (has_content and has_edits) else ("⚠️" if has_content else "❌")
        detail = f"存在 {files[0].name}（{'有实质修改' if has_edits else '内容可能为空洞通过'}）"
    else:
        status = "❌"
        detail = "04_review/ 下无 Copy Review 报告"
    results["gates"]["C2"] = {"track": track, "status": status, "detail": detail}


def check_brand_cta(project_dir: Path, results: dict):
    """Gate C3: Brand CTA — check brand name in content"""
    track = "文案"
    draft_dir = project_dir / "01_content" / "drafts"
    brand = "壹目贯维"

    html_files = list(draft_dir.rglob("*.html")) + list(draft_dir.rglob("*.md"))
    if not html_files:
        results["gates"]["C3"] = {
            "track": track,
            "status": "❌",
            "detail": "drafts 目录下无内容文件",
        }
        return

    brand_count = sum(1 for f in html_files if brand in f.read_text())
    total = len(html_files)
    found_in = []

    for f in html_files:
        if brand in f.read_text():
            found_in.append(f.parent.name)

    status = "✅" if brand_count >= total * 0.5 else "❌"
    detail = f"品牌名出现在 {len(found_in)}/{total} 文件（{', '.join(set(found_in)) if found_in else '无'}）"
    results["gates"]["C3"] = {"track": track, "status": status, "detail": detail}


def check_inline_images(project_dir: Path, results: dict):
    """Gate II: Inline Images"""
    track = "文案"
    img_dir = project_dir / "01_content" / "drafts" / "wechat" / "images"
    if not img_dir.exists():
        results["gates"]["II"] = {
            "track": track,
            "status": "❌",
            "detail": "wechat/images/ 目录不存在",
        }
        return

    images = list(img_dir.glob("*.png")) + list(img_dir.glob("*.jpg"))
    status = "✅" if len(images) >= 1 else "❌"
    results["gates"]["II"] = {
        "track": track,
        "status": status,
        "detail": f"内文配图 {len(images)} 张: {', '.join(i.name for i in images[:5])}",
    }


def check_vq(project_dir: Path, results: dict):
    """Gate VQ: Design Quality Layout Validation"""
    track = "视频"
    # Check for layout validation output
    vq_paths = list(project_dir.rglob("validate_layout*")) + list(project_dir.rglob("VQ/*"))
    if vq_paths:
        status = "✅"
        detail = f"VQ 产物存在: {vq_paths[0].relative_to(project_dir)}"
    else:
        # Check gate status file
        gates_file = project_dir / ".gates_status.json"
        if gates_file.exists():
            try:
                data = json.loads(gates_file.read_text())
                vq_status = data.get("gates", {}).get("VQ", {}).get("status", "missing")
                status = "✅" if vq_status == "pass" else "❌"
                detail = f".gates_status.json 中 VQ = {vq_status}"
            except Exception:
                status = "❌"
                detail = "无 VQ 布局验证记录"
        else:
            status = "❌"
            detail = "无 VQ 布局验证产物"
    results["gates"]["VQ"] = {"track": track, "status": status, "detail": detail}


def check_vision_qa(project_dir: Path, results: dict):
    """Gate V1: Vision QA screenshots"""
    track = "视频"
    v1_paths = list(project_dir.rglob("V1/*")) + list(project_dir.rglob("*screenshot*")) + list(project_dir.rglob("*vision*"))
    if v1_paths:
        screenshots = [p for p in v1_paths if p.suffix in (".png", ".jpg", ".webp")]
        status = "✅" if len(screenshots) >= 3 else "⚠️"
        detail = f"Vision QA: {len(screenshots)} 张截图（≥3 为通过）"
    else:
        gates_file = project_dir / ".gates_status.json"
        if gates_file.exists():
            try:
                data = json.loads(gates_file.read_text())
                v1_status = data.get("gates", {}).get("V1", {}).get("status", "missing")
                status = "✅" if v1_status == "pass" else "❌"
                detail = f".gates_status.json 中 V1 = {v1_status}"
            except Exception:
                status = "❌"
                detail = "无 V1 Vision QA 记录"
        else:
            status = "❌"
            detail = "无 Vision QA 截图"
    results["gates"]["V1"] = {"track": track, "status": status, "detail": detail}


def check_tts(project_dir: Path, results: dict):
    """Gate V4+V4.5: TTS Brand Voice"""
    track = "视频"
    # Find audio files
    audio_files = list(project_dir.rglob("*.mp3")) + list(project_dir.rglob("*.wav"))
    has_audio = len(audio_files) > 0

    # Check TTS source signature (from tts_produce.py)
    tts_source = list(project_dir.rglob("tts_source*")) + list(project_dir.rglob("V4/*"))

    if has_audio:
        # Check for brand in TTS input
        brand_in_tts = any("壹目贯维" in (f.read_text() if f.is_file() else "") for f in tts_source) if tts_source else False
        status = "✅" if brand_in_tts else ("⚠️" if has_audio else "❌")
        detail = f"TTS 音频 {len(audio_files)} 个，品牌留痕{'有' if brand_in_tts else '无（需检查）'}"
    else:
        # Check gate status
        gates_file = project_dir / ".gates_status.json"
        if gates_file.exists():
            try:
                data = json.loads(gates_file.read_text())
                v4_status = data.get("gates", {}).get("V4", {}).get("status", "missing")
                status = "✅" if v4_status == "pass" else "❌"
                detail = f".gates_status.json 中 V4 = {v4_status}"
            except Exception:
                status = "❌"
                detail = "无 TTS 文件"
        else:
            status = "❌"
            detail = "无 TTS 音频文件"
    results["gates"]["V4"] = {"track": track, "status": status, "detail": detail}


def check_srt(project_dir: Path, results: dict):
    """Gate V5+V6.5: Subtitle/Alignment"""
    track = "视频"
    srt_files = list(project_dir.rglob("*.srt")) + list(project_dir.rglob("*subtitle*"))
    mp3_vs_srt = list(project_dir.rglob("mp3_vs_srt*")) + list(project_dir.rglob("V5/*"))

    if srt_files or mp3_vs_srt:
        has_srt = len(srt_files) > 0
        has_match_report = len(mp3_vs_srt) > 0
        status = "✅" if (has_srt and has_match_report) else ("⚠️" if has_srt else "❌")
        detail_parts = []
        if srt_files:
            detail_parts.append(f"SRT {len(srt_files)} 个")
        if mp3_vs_srt:
            detail_parts.append(f"匹配报告 {len(mp3_vs_srt)} 个")
        detail = "，".join(detail_parts) if detail_parts else "无"
    else:
        status = "❌"
        detail = "无 SRT 字幕 / 匹配报告"
    results["gates"]["V5"] = {"track": track, "status": status, "detail": detail}


def check_gate_status_file(project_dir: Path, results: dict):
    """Gate Status File — central gate tracking"""
    track = "视频"
    gates_file = project_dir / ".gates_status.json"
    if gates_file.exists():
        try:
            data = json.loads(gates_file.read_text())
            gates = data.get("gates", {})
            all_pass = all(
                g.get("status") == "pass"
                for name, g in gates.items()
                if name in ("V0", "VQ", "V4", "V5", "V1", "V3")
            )
            # Check if marker mtime is recent
            mtime = os.path.getmtime(gates_file)
            age_hours = (datetime.now().timestamp() - mtime) / 3600
            age_str = f"{age_hours:.1f}h 前更新"

            if not all_pass:
                # Report which are not pass
                failing = [n for n, g in gates.items() if g.get("status") != "pass"]
                status = "❌"
                detail = f"视频 Gate 未全通过（缺: {', '.join(failing)}），{age_str}"
            else:
                status = "✅"
                detail = f"视频 Gate 全部 pass，{age_str}"
        except (json.JSONDecodeError, KeyError) as e:
            status = "⚠️"
            detail = f"gate 状态文件解析失败: {e}"
    else:
        status = "❌"
        detail = "无 .gates_status.json（未使用 Gate 签入流程）"
    results["gates"]["gate_status_file"] = {"track": track, "status": status, "detail": detail}


def check_publish_log(project_dir: Path, results: dict):
    """Gate L1: Publish Log"""
    track = "生命周期"
    # Check various publish log locations
    for p in [project_dir / "05_publish" / "publish_log.json",
              project_dir / "04_publish" / "publish_log.json",
              project_dir / "publish_log.json"]:
        if p.exists():
            try:
                data = json.loads(p.read_text())
                has_platforms = len(data.get("platforms", data.get("publish", []))) > 0
                status = "✅" if has_platforms else "⚠️"
                detail = f"存在 {p.relative_to(project_dir)}, {'有发布记录' if has_platforms else '发布记录为空'}"
            except json.JSONDecodeError:
                status = "⚠️"
                detail = f"存在 {p.relative_to(project_dir)} 但 JSON 解析失败"
            results["gates"]["L1"] = {"track": track, "status": status, "detail": detail}
            return

    results["gates"]["L1"] = {"track": track, "status": "❌", "detail": "无 publish_log.json"}


def check_covers(project_dir: Path, results: dict):
    """Cover images — 3 required sizes"""
    track = "生命周期"
    cover_dir = project_dir / "02_images" / "cover"
    if not cover_dir.exists():
        results["gates"]["covers"] = {
            "track": track,
            "status": "❌",
            "detail": "02_images/cover/ 目录不存在",
        }
        return

    sizes = ["16x9", "9x16", "3x4"]
    found = []
    for s in sizes:
        if list(cover_dir.glob(f"*{s}*")):
            found.append(s)
    status = "✅" if len(found) == 3 else "❌"
    results["gates"]["covers"] = {
        "track": track,
        "status": status,
        "detail": f"封面图规格: {', '.join(found) if found else '无'}（需 {', '.join(sizes)}）",
    }


def check_composition(project_dir: Path, results: dict):
    """Check composition files exist (prerequisite for V0 lint)"""
    track = "视频"
    has_index = (project_dir / "index.html").exists()
    has_composition = (project_dir / "composition.html").exists()
    comp_dir = project_dir / "compositions"
    has_comp_dir = comp_dir.exists() and len(list(comp_dir.glob("*.html"))) > 0

    if has_index or has_composition or has_comp_dir:
        part_count = len(list(comp_dir.glob("*.html"))) if comp_dir.exists() else 1
        status = "✅"
        detail = f"Composition 存在（{'index.html' if has_index else ''}{' composition.html' if has_composition else ''} + {part_count} 场景）"
    else:
        status = "❌"
        detail = "无 composition 文件"
    results["gates"]["composition"] = {"track": track, "status": status, "detail": detail}


def run_audit(project_dir: Path) -> dict:
    """Run full audit on project directory. Returns results dict."""
    results = {
        "project": str(project_dir),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "gates": {},
        "summary": {},
    }

    # 文案前
    check_research(project_dir, results)
    check_template_selection(results)
    check_platform_diff(project_dir, results)

    # 文案
    check_prompt_quality(project_dir, results)
    check_ai_flavor(project_dir, results)
    check_fact_check(project_dir, results)
    check_humanizer(project_dir, results)
    check_copy_review(project_dir, results)
    check_brand_cta(project_dir, results)
    check_inline_images(project_dir, results)

    # 视频
    check_composition(project_dir, results)
    check_vq(project_dir, results)
    check_vision_qa(project_dir, results)
    check_tts(project_dir, results)
    check_srt(project_dir, results)
    check_gate_status_file(project_dir, results)

    # 生命周期
    check_publish_log(project_dir, results)
    check_covers(project_dir, results)

    # Summary
    gates = results["gates"]
    total = len(gates)
    passed = sum(1 for g in gates.values() if g["status"] == "✅")
    warn = sum(1 for g in gates.values() if g["status"] == "⚠️")
    failed = sum(1 for g in gates.values() if g["status"] == "❌")

    results["summary"] = {
        "total": total,
        "passed": passed,
        "warning": warn,
        "failed": failed,
        "score": f"{passed}/{total}",
        "verdict": "✅ ALL CLEAR" if failed == 0 else f"❌ {failed} 项未通过",
    }

    return results


def print_report(results: dict):
    """Pretty-print audit report to stdout."""
    print(f"\n{'='*60}")
    print(f"  📋 AutoMedia Pipeline Audit")
    print(f"  项目: {results['project']}")
    print(f"  时间: {results['timestamp']}")
    print(f"{'='*60}")

    # Group by track
    tracks = {}
    for name, gate in results["gates"].items():
        track = gate.get("track", "其他")
        tracks.setdefault(track, []).append((name, gate))

    for track_name in ["文案前", "文案", "视频", "生命周期", "其他"]:
        if track_name not in tracks:
            continue
        print(f"\n  📁 {track_name} Track")
        print(f"  {'─'*56}")
        for name, gate in tracks[track_name]:
            emoji = gate["status"]
            print(f"  {emoji} {name:25s} {gate['detail']}")

    s = results["summary"]
    print(f"\n{'='*60}")
    print(f"  📊 总计: {s['total']} 项 | ✅ {s['passed']} | ⚠️ {s['warning']} | ❌ {s['failed']}")
    print(f"  {s['verdict']}")
    print(f"{'='*60}\n")


def main():
    parser = argparse.ArgumentParser(description="AutoMedia Pipeline Completeness Audit")
    parser.add_argument("--project", "-p", required=True, help="Project directory path")
    parser.add_argument("--track", "-t", choices=["copy", "video", "lifecycle", "all"],
                        default="all", help="Audit track (default: all)")
    parser.add_argument("--json", action="store_true", help="Output JSON instead of formatted report")
    parser.add_argument("--exit-code", action="store_true", help="Exit with 1 on failure")

    args = parser.parse_args()
    project_dir = Path(args.project).resolve()

    if not project_dir.exists():
        print(f"❌ Project directory not found: {project_dir}", file=sys.stderr)
        sys.exit(1)

    results = run_audit(project_dir)

    if args.json:
        print(json.dumps(results, indent=2, ensure_ascii=False))
    else:
        print_report(results)

    if args.exit_code:
        sys.exit(results["summary"]["failed"])


if __name__ == "__main__":
    main()
