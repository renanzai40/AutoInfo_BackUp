#!/usr/bin/env python3
"""
AutoMedia 08:00 热点采集脚本
双流采集 -> rank归一化 -> 写入pool.db

用法: python3 auto_media_hot_collection.py

依赖: curl, python3 (标准库: json, subprocess, sqlite3, hashlib, re, urllib)
# API 密钥从 ~/.hermes/.env 读取 (OPENCODE_GO_API_KEY, TAVILY_API_KEY)
"""
import os
import sys
import json
import sqlite3
import hashlib
import subprocess
import re
import time
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlencode

# ============================================================================
# 工具函数
# ============================================================================
def parse_hot(raw):
    """解析热度值，支持纯数字(int/float)和'2636 万热度'混合格式"""
    m = re.search(r'[\d.]+', str(raw))
    return float(m.group()) if m else 0

def curl_fetch(url, params=None):
    """用subprocess curl请求，返回解析后的JSON数据（比Python requests更稳定）"""
    cmd = ['curl', '-s', '--max-time', '15']
    if params:
        url_with_params = url + '?' + urlencode(params)
    else:
        url_with_params = url
    cmd.append(url_with_params)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return json.loads(result.stdout)
    except Exception as e:
        print(f"    curl失败: {e}, stdout: {result.stdout[:100]}")
        return {}

# ============================================================================
# 0. 加载API密钥（2026-06-08: 从 MiniMax-M3 切换到 DeepSeek-v4-flash via opencode-go）
# ============================================================================
ENV_FILE = '/home/renanzai/.hermes/profiles/content/.env'
LLM_API_KEY = None
TAVILY_KEY = None
LLM_BASE_URL = "https://opencode.ai/zen/go/v1"
LLM_MODEL = "deepseek-v4-flash"

if os.path.exists(ENV_FILE):
    with open(ENV_FILE) as f:
        for line in f:
            line = line.strip()
            if line.startswith('OPENCODE_GO_API_KEY=') and not line.startswith('#'):
                LLM_API_KEY = line.split('=', 1)[1].strip()
            elif line.startswith('TAVILY_API_KEY=') and not line.startswith('#'):
                TAVILY_KEY = line.split('=', 1)[1].strip()

# ============================================================================
# 1. 流1: 4平台热搜采集
# ============================================================================
print("=== 流1: 4平台热搜采集 ===")
flow1_raw = []

# 微博
data = curl_fetch('https://uapis.cn/api/v1/misc/hotboard', {'type': 'weibo'})
for rank, item in enumerate(data.get('list', [])[:15], 1):
    title = item.get('title') or item.get('word', '')
    hot = parse_hot(item.get('hot_value', '0'))
    if title and hot:
        flow1_raw.append({'title': title, 'source': '微博', 'rank': rank, 'raw_score': hot})
print(f"  微博: {len(data.get('list', []))}条")

# 知乎
data = curl_fetch('https://uapis.cn/api/v1/misc/hotboard', {'type': 'zhihu'})
for rank, item in enumerate(data.get('list', [])[:15], 1):
    title = item.get('title') or item.get('word', '')
    hot = parse_hot(item.get('hot_value', '0'))
    if title and hot:
        flow1_raw.append({'title': title, 'source': '知乎', 'rank': rank, 'raw_score': hot})
print(f"  知乎: {len(data.get('list', []))}条")

# 抖音
data = curl_fetch('https://uapis.cn/api/v1/misc/hotboard', {'type': 'douyin'})
for rank, item in enumerate(data.get('list', [])[:15], 1):
    title = item.get('title') or item.get('word', '')
    hot = parse_hot(item.get('hot_value', '0'))
    if title and hot:
        flow1_raw.append({'title': title, 'source': '抖音', 'rank': rank, 'raw_score': hot})
print(f"  抖音: {len(data.get('list', []))}条")

# B站 (B站API从WSL调用返回-352错误，跳过)
# data = curl_fetch('https://api.bilibili.com/x/web-interface/ranking/v2', {'rid': '0', 'day': '3'})
# for rank, item in enumerate(data.get('list', [])[:15], 1):
#     title = item.get('title', '')
#     if title:
#         flow1_raw.append({'title': title, 'source': 'B站', 'rank': rank, 'raw_score': 15 - rank})

print(f"流1原始: {len(flow1_raw)}条")

# ============================================================================
# 2. 流1 内各平台 rank 归一化
# ============================================================================
def rank_normalize(raw_list, n=15):
    """按raw_score排序，rank1=1.0, rank15=0.06"""
    sorted_items = sorted(raw_list, key=lambda x: x['raw_score'], reverse=True)
    step = 0.93 / (n - 1)
    for i, item in enumerate(sorted_items):
        item['heat_score'] = 1.0 - i * step
    return sorted_items

flow1_by_source = {}
for item in flow1_raw:
    src = item['source']
    flow1_by_source.setdefault(src, []).append(item)

flow1_normalized = []
for src, items in flow1_by_source.items():
    ranked = rank_normalize(items)
    for it in ranked:
        flow1_normalized.append(it)

print(f"流1归一化: {len(flow1_normalized)}条")

# ============================================================================
# 3. 流2: Tavily AI搜索
# ============================================================================
TAVILY_QUERIES = [
    # 原 8 组 (2026-05-24 验证过)
    'AI 大模型 最新进展 新闻',
    'AI视频生成 行业资讯',
    'AI配音 语音合成 新闻',
    'AIGC 创作平台 新闻',
    'AI营销内容 工具动态',
    'AI 研究突破 最新资讯',
    'AI 大模型 行业动态 最新',
    '中国AI大模型 周调用量最新',
    # 招 2 新增 8 组 (2026-06-05) — 扩源到 AI 业务款核心赛道
    'AI Agent 商业化 最新',                    # Tier 1 关键词 + 2026 大热门
    'AI 数字人 商业应用 新闻',                 # Tier 1 关键词
    'AI 配音 工具 评测 2026',                  # 业务款核心赛道
    'AI 短视频 批量生产 案例',                 # 壹目贯维业务直接对位
    'Sora 可灵 即梦 Runway 对比 2026',         # 竞品动态
    '国内大模型 商业化 进展',                  # 业务款核心
    'AI 内容生产 ROI 案例',                    # 业务款核心
    'AI 多模态 发布 2026',                     # 业务款核心
]

def tavily_search(query, max_results=15):
    env = {**os.environ}
    if TAVILY_KEY:
        env['TAVILY_API_KEY'] = TAVILY_KEY
    try:
        result = subprocess.run(
            ['tvly', 'search', query,
             '--time-range', 'day',
             '--max-results', str(max_results),
             '--json'],
            capture_output=True, text=True, timeout=30, env=env
        )
        data = json.loads(result.stdout)
        return [{'title': item['title'], 'score': item['score'], 'source_url': item.get('url', '')}
                for item in data.get('results', [])]
    except Exception as e:
        print(f"  Tavily [{query[:15]}...]: {e}")
        return []

print("\n=== 流2: Tavily AI搜索 ===")
flow2_raw = []
# 招 2 (2026-06-05): max_workers 8 → 12（16 组并发 12 兜底，避免 Tavily 限流）
with ThreadPoolExecutor(max_workers=12) as ex:
    futures = {ex.submit(tavily_search, q): q for q in TAVILY_QUERIES}
    for future in as_completed(futures):
        q = futures[future]
        try:
            results = future.result()
            print(f"  [{q[:20]}...]: {len(results)}条")
            flow2_raw.extend(results)
        except Exception as e:
            print(f"  [{q[:20]}]: 异常 {e}")

# 去重
seen = set()
flow2_unique = []
for item in flow2_raw:
    title = item['title'][:80]
    if title and title not in seen:
        seen.add(title)
        flow2_unique.append(item)

# ============================================================================
# ============================================================================
# Layer 1: Domain 黑名单过滤（Tavily 爬取前拦截，避免浪费后续计算）
# ============================================================================
DB_PATH_BLOCK = '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db'
conn_blk = sqlite3.connect(DB_PATH_BLOCK)
cur_blk = conn_blk.cursor()
cur_blk.execute("SELECT domain FROM blocked_domains")
blocked_domains = {row[0] for row in cur_blk.fetchall()}
conn_blk.close()

# ============================================================================
# Layer 1.5: 标题正则黑名单（拦截无URL但标题含站点名的内容农场）
# ============================================================================
TITLE_BLOCK_PATTERNS = [
    r'AI快讯网',
    r'AI工具网',
    r'AI工具导航',
    r'什么值得买',
    r'\(2026年最新\)',
    r'，\w+技巧$',
    r'^如何\w+',
    r'^AIGC?\w*[资工具导]',
    r'\| ?AI工具导航',
    # 2026-06-01 精准堵漏
    r'点点资讯',       # 聚合内容农场
    r'雷峰网',         # 聚合内容农场
    r'^我的.*AIGC',    # UGC标记类标题（如"我的第一支AIGC短片"）
    r'^#\w+\s',        # 纯hashtag开头（如"#ai #aiart"）
]

flow2_prefiltered = []
flow2_blocked_domain = 0
flow2_blocked_title = 0
for item in flow2_unique:
    src_url = item.get('source_url', '')
    domain = ''
    if src_url and '://' in src_url:
        domain = src_url.split('/')[2]
        if domain and domain in blocked_domains:
            flow2_blocked_domain += 1
            continue
    title = item.get('title', '')
    if any(re.search(p, title) for p in TITLE_BLOCK_PATTERNS):
        flow2_blocked_title += 1
        continue
    flow2_prefiltered.append(item)

flow2_unique = flow2_prefiltered
if flow2_blocked_domain or flow2_blocked_title:
    print(f"  Layer1 域名拦截: {flow2_blocked_domain}条 | Layer1.5 标题拦截: {flow2_blocked_title}条")

print(f"流2去重后: {len(flow2_unique)}条")

# ============================================================================
# 流3: AIHOT API（新增）
# ============================================================================
AIHOT_CATEGORIES = {
    'ai-models': 'business',
    'ai-products': 'business',
    'industry': 'growth',
    'paper': 'growth',
    'tip': 'business',
}

def aihot_fetch(since_iso: str, take: int = 30):
    """拉取 AIHOT 精选条目"""
    ua = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
          "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
    url = "https://aihot.virxact.com/api/public/items"
    params = {"mode": "selected", "since": since_iso, "take": take}
    cmd = [
        'curl', '-s', '--max-time', '15',
        '-H', f'User-Agent: {ua}',
        url + '?' + urlencode(params)
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        data = json.loads(result.stdout)
        return data.get('items', [])
    except Exception as e:
        print(f"  AIHOT 请求失败: {e}")
        return []

print("\n=== 流3: AIHOT 精选 ===")
now_ts = datetime.now()
since_iso = (now_ts - timedelta(days=1)).strftime('%Y-%m-%dT%H:%M:%S.000Z')
flow3_raw = aihot_fetch(since_iso, take=30)
print(f"  API 返回 {len(flow3_raw)} 条")

flow3_with_cat = []
for item in flow3_raw:
    title = item.get('title', '')
    if title:
        flow3_with_cat.append({
            'title': title,
            'source': 'AIHOT',
            'aihot_category': item.get('category', ''),
            'source_url': item.get('url', ''),
            'raw_score': item.get('publishedAt', ''),
        })

# AIHOT 本身已精选，但标题可能含站点名/hashtag，补上Layer 1.5过滤
flow3_prefiltered = []
flow3_blocked = 0
for item in flow3_with_cat:
    title = item.get('title', '')
    if any(re.search(p, title) for p in TITLE_BLOCK_PATTERNS):
        flow3_blocked += 1
        continue
    flow3_prefiltered.append(item)

if flow3_blocked:
    print(f"  Flow3 Layer1.5拦截: {flow3_blocked}条")

flow3_with_cat = flow3_prefiltered
seen = set()
flow3_unique = []
for item in flow3_with_cat:
    key = item['title'][:80]
    if key and key not in seen:
        seen.add(key)
        flow3_unique.append(item)

# AIHOT 评分：按 publishedAt 倒序，越新分越高
flow3_unique.sort(key=lambda x: x['raw_score'], reverse=True)
step = 0.93 / max(len(flow3_unique) - 1, 1)
for i, item in enumerate(flow3_unique):
    item['heat_score'] = 1.0 - i * step

flow3_normalized = flow3_unique[:15]
print(f"  去重后 {len(flow3_normalized)} 条")

# Tavily score rank归一化
flow2_unique.sort(key=lambda x: x['score'], reverse=True)
step = 0.93 / max(len(flow2_unique) - 1, 1)
for i, item in enumerate(flow2_unique):
    item['heat_score'] = 1.0 - i * step
    item['source'] = 'Tavily'

flow2_normalized = flow2_unique[:15]
print(f"流2归一化后: {len(flow2_normalized)}条")

# ============================================================================
# 4. LLM SEO/广告过滤 (Tavily结果清洗)
# ============================================================================
def llm_seo_filter(items, api_key):
    """用LLM过滤SEO内容农场/广告软文，返回清洗后的标题列表"""
    if not items:
        return []
    titles = [it['title'] for it in items]
    prompt_lines = '\n'.join([f'{i+1}. {t}' for i, t in enumerate(titles)])
    payload = json.dumps({
        'model': LLM_MODEL,
        'messages': [{
            'role': 'user',
            'content': f'''以下是从AI/科技新闻源搜索到的标题列表。请识别并剔除【SEO内容农场/广告软文/明显付费推广】，只保留真正的新闻报道或行业分析。

标题列表：
{prompt_lines}

输出JSON格式（严格，不能有其他内容）：
{{"keep": [序号列表], "drop_reasons": {{"序号": "原因", ...}}}}

判断标准：
- 【保留】真实新闻报道：记者撰写、有具体事件/数据/采访
- 【保留】行业分析：深度解读、有观点
- 【剔除】SEO内容农场：CSDN、什么值得买(zdm/smzdm)、IT之家、4399等平台的教程/导航/排行榜文章
- 【剔除】广告软文：含"立即体验"、"点击查看"、"限时"、"免费领取"、"扫码"等营销话术
- 【剔除】SEO标题特征：含"(2026年最新)"、"，xxx技巧"、"如何xxx"等教程类标题
- 【剔除】转载/摘录类：无原创观点，堆砌关键词
'''
        }],
        'temperature': 0.01,
        'max_tokens': 16000
    })
    cmd = [
        'curl', '-s', '--max-time', '150',
        '-X', 'POST',
        '-H', 'Content-Type: application/json',
        '-H', f'Authorization: Bearer {api_key}',
        '-d', payload,
        f'{LLM_BASE_URL}/chat/completions'
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        raw = result.stdout
        if not raw:
            print(f"  LLM SEO过滤返回空，保留全部{len(titles)}条")
            return items
        data = json.loads(raw)
        content = data.get('choices', [{}])[0].get('message', {}).get('content', '')
        try:
            parsed = json.loads(content)
        except:
            match = re.search(r'\{[\s\S]*\}', content)
            if match:
                parsed = json.loads(match.group())
            else:
                print(f"  LLM SEO过滤解析失败，保留全部{len(titles)}条")
                return items
        keep_indices = parsed.get('keep', [])
        drop_reasons = parsed.get('drop_reasons', {})
        dropped = len(titles) - len(keep_indices)
        print(f"  LLM SEO过滤: {len(titles)}条 -> {len(keep_indices)}条 (排除{dropped}条SEO/广告)")
        # debug: 打印每个被过滤条目的原因
        if drop_reasons:
            for idx_str, reason in drop_reasons.items():
                idx = int(idx_str) - 1  # 转0-index
                if 0 <= idx < len(titles):
                    print(f"    ✗ 排除[{idx+1}]: {titles[idx][:60]} | 原因: {reason}")
        return [items[i-1] for i in keep_indices if 1 <= i <= len(items)]
    except Exception as e:
        print(f"  LLM SEO过滤异常 ({type(e).__name__})，保留全部{len(titles)}条")
        return items

print("\n=== 流2 Layer 2 LLM 相关性预审 ===")

# ============================================================================
def llm_layer2_gate(items, api_key):
    """
    用 LLM 判断话题是否与 AI 内容生产行业真正相关。
    
    判断标准：
    - related: AI 模型/产品发布、AI行业分析、AI工具应用、大模型技术、AI创作工作流
    - unrelated: 游戏发布、娱乐综艺、体育赛事、社会新闻、纯商业财经（无AI元素）
    - uncertain: 边界情况，需要 Layer 3 细审
    
    输入：items 列表，每个含 title + 可选 source_url / source
    输出：filtered_items（只保留 related + uncertain）
    """
    if not items:
        return []
    
    # 2026-06-20 修复：大batch超模型推理预算 → 拆40条一批分批处理
    BATCH_SIZE = 40
    if len(items) > BATCH_SIZE:
        print(f"  ⚠️ Layer2批处理: {len(items)}条拆为多批 (每批{BATCH_SIZE}条)")
        all_filtered = []
        for chunk_start in range(0, len(items), BATCH_SIZE):
            chunk = items[chunk_start:chunk_start + BATCH_SIZE]
            chunk_result = _layer2_process_batch(chunk, api_key)
            all_filtered.extend(chunk_result)
            time.sleep(0.5)  # 2026-07-21: batch间隔防opencode-go限流
        return all_filtered
    
    return _layer2_process_batch(items, api_key)


def _layer2_process_batch(items, api_key):
    """实际执行Layer2单批处理（40条以内）"""
    if not items:
        return []
    
    # 构造每条记录的输入行
    lines = []
    for i, item in enumerate(items):
        title = item.get('title', '')
        source_url = item.get('source_url', '')
        source = item.get('source', '')
        
        if source_url:
            ctx = f"[{source}] {source_url}"
        else:
            ctx = source or '无来源'
        
        lines.append(f"{i+1}. 标题：{title}\n   来源：{ctx}")
    
    prompt_lines = '\n'.join(lines)
    payload = json.dumps({
        'model': LLM_MODEL,
        'messages': [{
            'role': 'user',
            'content': f'''你是内容相关性审核员。判断以下标题+来源是否【与 AI 内容生产行业真正相关】。

判断标准：
- 【相关 related】AI 模型/产品发布、AI 行业分析、AI 工具应用案例、大模型技术解读、AI 创作工作流
- 【不相关 unrelated】游戏发布、娱乐综艺、体育赛事、社会新闻、纯商业财经（无 AI 元素）、生活技巧
- 【不确定 uncertain】边界情况，标题含 AI 关键词但可能是误匹配，需要细审

输入：
{prompt_lines}

输出JSON格式（严格，无其他内容）：
{{"decisions": {{"序号": "related" | "unrelated" | "uncertain", ...}}}}

规则：
- unrelated → 不入库（直接丢弃）
- related / uncertain → 入库，review_status='pending'（交给 Layer 3 细审）
- 只输出 JSON，不解释'''
        }],
        'temperature': 0.01,
        'max_tokens': 16000
    })
    cmd = [
        'curl', '-s', '--max-time', '150',
        '-X', 'POST',
        '-H', 'Content-Type: application/json',
        '-H', f'Authorization: Bearer {api_key}',
        '-d', payload,
        f'{LLM_BASE_URL}/chat/completions'
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        raw = result.stdout
        if not raw:
            print(f"  Layer2 返回空，保留全部 {len(items)} 条")
            return items
        data = json.loads(raw)
        content = data.get('choices', [{}])[0].get('message', {}).get('content', '')
        if not content:
            # 2026-07-21: 记录空响应debug信息
            with open('/tmp/llm_layer2_debug.json', 'w') as _f:
                json.dump({
                    'batch_size': len(items),
                    'fn': '_layer2_process_batch',
                    'response_keys': list(data.keys()),
                    'choices_keys': list(data.get('choices', [{}])[0].keys()) if data.get('choices') else [],
                    'finish_reason': data.get('choices', [{}])[0].get('finish_reason', ''),
                }, _f)
        try:
            parsed = json.loads(content)
        except:
            match = re.search(r'\{[\s\S]*\}', content)
            if match:
                parsed = json.loads(match.group())
            else:
                print(f"  Layer2 解析失败，保留全部 {len(items)} 条")
                return items
        
        decisions = parsed.get('decisions', {})
        filtered = []
        unrelated_cnt = 0
        
        for i, item in enumerate(items):
            idx = str(i + 1)
            decision = decisions.get(idx, 'uncertain')
            if decision == 'unrelated':
                unrelated_cnt += 1
                continue
            # related 或 uncertain 都入库，由 Layer 3 最终判断
            filtered.append(item)
        
        print(f"  Layer2 相关性过滤: {len(items)}条 -> {len(filtered)}条 (排除{unrelated_cnt}条不相关)")
        if unrelated_cnt > 0:
            for i, item in enumerate(items):
                idx = str(i + 1)
                if decisions.get(idx) == 'unrelated':
                    print(f"    ✗ 不相关: {item['title'][:55]}")
        
        return filtered
        
    except Exception as e:
        print(f"  Layer2 调用失败 ({type(e).__name__})，保留全部 {len(items)} 条")
        return items


# ============================================================================
# 5. LLM 语义去重 (curl subprocess)
# ============================================================================
def llm_dedup(titles, api_key):
    """用LLM判断同事件，返回去重后的标题列表（curl subprocess版，比requests稳定）"""
    if not titles:
        return []

    # 2026-06-28: batch splitting → ≤10 条/批（DeepSeek-v4-flash O(n²) 配对比较的 reasoning_content 在 20 条时就吃光 max_tokens=6000，实测 10 条 OK）
    BATCH_SIZE = 10
    if len(titles) > BATCH_SIZE:
        batched = [titles[i:i+BATCH_SIZE] for i in range(0, len(titles), BATCH_SIZE)]
        print(f"  ⚠️ LLM去重批处理: {len(titles)}条拆为 {len(batched)} 批 (每批{BATCH_SIZE}条)")
        all_kept = []
        for chunk in batched:
            all_kept.extend(llm_dedup(chunk, api_key))
            time.sleep(0.5)  # 2026-07-21: batch间隔防opencode-go限流
        # 跨批最终 hash 去重（防止不同批间残留近精确重复）
        seen, deduped = set(), []
        for t in all_kept:
            k = t[:50].lower().strip()
            if k not in seen:
                seen.add(k)
                deduped.append(t)
        inter = len(all_kept) - len(deduped)
        if inter > 0:
            print(f"  LLM去重跨批去重: 消除{inter}条跨批重复")
        return deduped

    prompt_lines = '\n'.join([f'{i+1}. {t}' for i, t in enumerate(titles)])
    payload = json.dumps({
        'model': LLM_MODEL,
        'messages': [{
            'role': 'user',
            'content': f'''判断以下标题哪些说的是【同一事件】，同事件的只保留一个。

标题列表：
{prompt_lines}

输出JSON格式（严格，不能有其他内容）：
{{"groups": [["事件A代表标题", "重复标题1"], ["事件B代表标题"], ...]}}

规则：
- 同事件：说的是同一件事/同一个人/同一个话题
- 保留：热度排名最靠前（列表中位置最靠前）的那个
- groups里每个子数组第一个是保留项，其余是重复项'''
        }],
        'temperature': 0.01,
        'max_tokens': 16000
    })

    cmd = [
        'curl', '-s', '--max-time', '150',
        '-X', 'POST',
        '-H', 'Content-Type: application/json',
        '-H', f'Authorization: Bearer {api_key}',
        '-d', payload,
        f'{LLM_BASE_URL}/chat/completions'
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        raw = result.stdout
        if not raw:
            print(f"  LLM返回空，保留全部{len(titles)}条")
            return titles
        try:
            result_data = json.loads(raw)
        except:
            print(f"  LLM JSON解析失败，保留全部{len(titles)}条 (raw: {raw[:100]})")
            return titles

        content = result_data.get('choices', [{}])[0].get('message', {}).get('content', '')
        if not content:
            # 2026-07-21: 记录空响应debug信息
            with open('/tmp/llm_dedup_debug.json', 'w') as _f:
                json.dump({
                    'batch_size': len(titles),
                    'response_keys': list(result_data.keys()),
                    'choices_keys': list(result_data.get('choices', [{}])[0].keys()) if result_data.get('choices') else [],
                    'finish_reason': result_data.get('choices', [{}])[0].get('finish_reason', ''),
                }, _f)
        try:
            parsed = json.loads(content)
        except:
            match = re.search(r'\{[\s\S]*\}', content)
            if match:
                parsed = json.loads(match.group())
            else:
                print(f"  ⚠️ LLM去重解析失败 (content空/无JSON)，本地 hash 兜底去重")
                seen = set()
                local_kept = []
                for t in titles:
                    key = t[:50].lower().strip()
                    if key not in seen:
                        seen.add(key)
                        local_kept.append(t)
                dropped = len(titles) - len(local_kept)
                print(f"  本地去重: {len(titles)}条 -> {len(local_kept)}条 (排除{dropped}条)")
                return local_kept

        groups = parsed.get('groups', [])
        kept = []
        for group in groups:
            if group:
                kept.append(group[0])

        dropped = sum(len(g) - 1 for g in groups)
        print(f"  LLM去重: {len(titles)}条 -> {len(kept)}条 (排除{dropped}条)")
        return kept
    except Exception as e:
        # 2026-06-08 修复: LLM 失败时本地 hash 兜底去重（按 title 前 50 字符做简单去重）
        print(f"  ⚠️ LLM去重异常 ({type(e).__name__})，本地 hash 兜底去重")
        seen = set()
        local_kept = []
        for t in titles:
            key = t[:50].lower().strip()
            if key not in seen:
                seen.add(key)
                local_kept.append(t)
        dropped = len(titles) - len(local_kept)
        print(f"  本地去重: {len(titles)}条 -> {len(local_kept)}条 (排除{dropped}条)")
        return local_kept

# 流1去重 → Layer2 相关性过滤 → INSERT(review_status='pending')
# 2026-06-08 修复 P0: 之前 `item['title'] in flow1_related` 永远 False（flow1_related 是 list of dict）
#   → 流1 入库永远 0 条（持续 N 天没被发现）
# 修法: flow1_related 是 list of dict (Layer2 输出), 提取 title 集合做 in 判断
flow1_titles = list({item['title']: item for item in flow1_raw}.keys())

# Layer 1.5: hash 近精确预去重（2026-06-25 前置过滤 + LLM 兜底）
if flow1_titles:
    _seen = set()
    _hashed = []
    for _t in flow1_titles:
        _k = _t[:50].lower().strip()
        if _k not in _seen:
            _seen.add(_k)
            _hashed.append(_t)
    _dropped = len(flow1_titles) - len(_hashed)
    if _dropped > 0:
        print(f"  hash预去重: {len(flow1_titles)}条 -> {len(_hashed)}条 (排除{_dropped}条)")
    flow1_titles = _hashed

flow1_kept = llm_dedup(flow1_titles, LLM_API_KEY) if flow1_titles else []
# 修复: 用 hash-key 查找避免 LLM 输出与原标题差异导致 StopIteration
flow1_source_map = {it['title'][:50].lower().strip(): it['source'] for it in flow1_raw}
flow1_related = llm_layer2_gate(
    [{'title': t, 'source': flow1_source_map.get(t[:50].lower().strip(), '')} for t in flow1_kept],
    LLM_API_KEY
)
flow1_related_titles = {r['title'] for r in flow1_related}  # 修复: 提取 title 集合
flow1_for_db = [item for item in flow1_raw if item['title'] in flow1_related_titles]
flow1_for_db.sort(key=lambda x: x['heat_score'], reverse=True)
flow1_top20 = flow1_for_db[:20]

# 流2去重 → Layer2 相关性过滤 → INSERT(review_status='pending')
flow2_titles = list({item['title']: item for item in flow2_unique}.keys())

# Layer 1.5: hash 近精确预去重（2026-06-25 前置过滤 + LLM 兜底）
if flow2_titles:
    _seen = set()
    _hashed = []
    for _t in flow2_titles:
        _k = _t[:50].lower().strip()
        if _k not in _seen:
            _seen.add(_k)
            _hashed.append(_t)
    _dropped = len(flow2_titles) - len(_hashed)
    if _dropped > 0:
        print(f"  hash预去重: {len(flow2_titles)}条 -> {len(_hashed)}条 (排除{_dropped}条)")
    flow2_titles = _hashed

flow2_kept = llm_dedup(flow2_titles, LLM_API_KEY) if flow2_titles else []
# 修复: 用 hash-key 查找避免 LLM 输出与原标题差异导致 StopIteration
flow2_url_map = {it['title'][:50].lower().strip(): it['source_url'] for it in flow2_unique}
flow2_related = llm_layer2_gate(
    [{'title': t, 'source_url': flow2_url_map.get(t[:50].lower().strip(), ''), 'source': 'Tavily'}
     for t in flow2_kept],
    LLM_API_KEY
)
flow2_related_titles = {r['title'] for r in flow2_related}  # 修复: 提取 title 集合
flow2_top15 = [item for item in flow2_unique if item['title'] in flow2_related_titles][:15]

print(f"\n流1去重后: {len(flow1_top20)}条, 流2: {len(flow2_top15)}条")

# ============================================================================
# Layer 2: 信息密度过滤器（2026-06-01新增）
# ============================================================================
# 内容生产价值：判断标题是否包含具体事件信息
# 实体词表：具体公司/人/机构名
INFO_ENTITIES = [
    '字节', '豆包', 'Qwen', 'DeepSeek', 'OpenAI', 'Anthropic',
    '谷歌', 'Google', '微软', 'Microsoft', 'MiniMax', '黄仁勳', '英伟达', 'NVIDIA',
    '华为', '阿里', '腾讯', '百度', '比亚迪', '理想', '小米', '苹果', 'Apple',
    '李开复', '奥尔特曼', 'Altman', '布罗克曼', 'Brockman',
    '俄银', '美国', '中国', 'OpenAI', 'Anthropic', 'Meta', 'Facebook',
    'NUS', '牛津', '清华', '北大', '斯坦福', '哈佛', 'MIT',
    '字节跳动', '抖音', '火山引擎', '商汤', '旷视', '云从',
    '科大讯飞', '阶跃', '星辰', '明略', '吉宏', '吉利',
    '奥特曼', '苏箐', '王耀恒', '尹希',
    'GPT', 'Claude', 'Gemini', '千问', '通义', '文心', '混元',
    'iOS', 'Android', '三星', '索尼', '特斯拉',
    '字节', '百度', '京东', '拼多多', '小红书',
]
INFO_ACTIONS = [
    '融资', '降价', '发布', '收购', '采购', '登顶', '超越', '封印',
    '跑通', '合作', '开源', '入选', '夺冠', '获批', '投资', '入股',
    '突破', '拿下', '攻克', '加速', '出货', '亏损', '盈利', '增长',
    '扩张', '入职', '爆入', '推出', '跑出', '免费', '白送',
    '共建', '达成', '上线', '下架', '裁员', '暴涨', '跌落',
]
INFO_NUMBERS = [
    r'\d+[%亿万兆千万百万万亿倍]', r'\d+\.\d+', r'\d+亿', r'\d+万', r'\d+元',
]

def info_density_pass(title):
    """
    判断标题是否通过信息密度审查。
    好的自媒体话题 = 有具体主体(实体) + 有具体动作/结果
    返回 True = 通过，False = 过滤掉
    """
    t = title

    # 先做黑名单拦截
    if any(re.search(p, t) for p in TITLE_BLOCK_PATTERNS):
        return False

    # 实体检测
    has_entity = any(kw in t for kw in INFO_ENTITIES)
    # 动作检测
    has_action = any(kw in t for kw in INFO_ACTIONS)
    # 数字检测（排除纯年份）
    has_number = False
    for pattern in INFO_NUMBERS:
        m = re.search(pattern, t)
        if m and not re.match(r'^20\d{2}$', m.group()):
            has_number = True
            break

    # 通过条件：有实体+有动作，或 有实体+有数字，或 有动作+有数字
    if has_entity and has_action:
        return True
    if has_entity and has_number:
        return True
    if has_action and has_number:
        return True
    # 无实体无动作无数字 → 过滤
    if not has_entity and not has_action and not has_number:
        return False
    # 兜底：平台话题（微博/知乎/抖音）给更高容忍度
    return False  # 默认不通过，除非明确匹配以上条件


# ============================================================================
# Layer 3: 同事件去重（2026-06-01新增）
# ============================================================================
# 核心策略：同事件只保留热度最高的那条
DEDUP_KEYWORDS = [
    ('Mythos大模型封印', ['Mythos', '封印']),
    ('MiniMax跑通', ['MiniMax', '跑通']),
    ('DeepSeek降价', ['DeepSeek', '降价']),
    ('Anthropic融资', ['Anthropic', '融资']),
    ('AI大模型调用量', ['大模型', '调用量', 'Token']),
    ('文博会', ['文博会']),
    ('比亚迪发布会', ['比亚迪', '发布会', '新技术']),
    ('牛津微软综述', ['牛津', '微软', '综述']),
]

def extract_dedup_key(title):
    """提取用于去重的核心关键词"""
    t = title
    for name, kws in DEDUP_KEYWORDS:
        if all(kw in t for kw in kws):
            return name
    return None

def dedup_filter(items):
    """
    对话题列表做同事件去重。
    同事件只保留第一条（已按热度排序），其余标记为drop。
    items: list of dict，每个含 title + source
    返回: (kept_indices, drop_indices)
    """
    kept = []
    drop = []
    dedup_groups = {}  # key -> [indices]

    for i, item in enumerate(items):
        key = extract_dedup_key(item['title'])
        if key:
            if key not in dedup_groups:
                dedup_groups[key] = []
            dedup_groups[key].append(i)
        else:
            kept.append(i)

    for key, indices in dedup_groups.items():
        # 只保留第1条，其余drop
        kept.append(indices[0])
        for idx in indices[1:]:
            drop.append(idx)

    return sorted(kept), sorted(drop)


# ============================================================================
# 5. 写入数据库
# ============================================================================
DB_PATH = '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db'
now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()

# ============================================================================
# 业务关联度评分函数（基于关键词分级，0-10分）
# 壹目贯维核心业务：AI内容生产（AIGC/大模型/视频生成/文案/配音/TTS/AI营销）
# ============================================================================
def score_correlation(title, category):
    """
    基于关键词分级计算业务关联度评分 (0-10)。
    业务款(business)基础分比引流款(growth)高2分，保证业务款排序正确。
    """
    t = title.lower()

    # Tier 1: 直接AI创作核心 (business=10, growth=9)
    tier1 = ['aigc', 'ai内容', 'ai生成', 'ai创作', 'ai文案', 'ai配音', 'ai语音',
             'ai视频', 'ai绘图', 'ai写作', 'ai脚本', 'ai主播', 'ai营销', 'ai爆款',
             '内容生产', '自媒体工具', 'ai助手', 'copilot',
             'deepseek', 'kimi', '豆包', '智谱', '文心', '混元', '跃问', '百川',
             'minimax', 'sora', '可灵', '即梦', 'vidu', 'runway', 'pika',
             'stable video', 'lora', '微调', 'rlhf', 'dpo', '羊驼',
             'ai agent', 'ai智能体', '数字人', '虚拟人', '大模型训练', '模型微调']
    for kw in tier1:
        if kw in t:
            return 10 if category == 'business' else 9

    # Tier 2: AI/模型相关 (business=8, growth=7)
    tier2 = ['人工智能', 'ai模型', 'ai应用', 'ai产品', 'ai行业', 'ai生态',
             'ai工具', 'ai平台', 'ai发布', 'ai开源', 'ai训练', 'ai推理',
             'ai芯片', 'npu', 'gpu', '英伟达', '华为ai', 'ai手机', 'ai pc',
             '机器学习', '深度学习', '神经网络', 'transformer', '注意力机制',
             '视频生成', '文生视频', '图生视频', '配音', '语音合成', 'tts', 'asr',
             '大模型', '大模型发布', '模型发布', 'ai新品', '国产ai',
             'gpt', 'chatgpt', 'claude', 'openai', 'anthropic', 'gemini',
             'langchain', 'dspy', 'rag', '向量数据库', 'embedding']
    for kw in tier2:
        if kw in t:
            return 8 if category == 'business' else 7

    # Tier 3: 泛科技/商业 (business=6, growth=5)
    tier3 = ['科技', '互联网', '芯片', '半导体', '新能源', '电动汽车', '智能驾驶',
             '自动驾驶', '电池', '光伏', '储能', '风电', '碳中和', '碳达峰',
             '汽车', '手机', '电脑', '小米', '华为', '苹果', '谷歌', '微软',
             'meta', '腾讯', '阿里', '字节', '百度', '京东', '拼多多', '抖音',
             '电商', '直播', '短视频', '内容平台', '社交媒体',
             '数字化', '智能化', '转型升级', '出海', '全球化',
             'ipo', '融资', '投资', '并购', '上市', '市值', '股价', '财报',
             '经济', '市场', '关税', '出口', '贸易', '中美', '特朗普']
    for kw in tier3:
        if kw in t:
            return 6 if category == 'business' else 5

    # Tier 4: 大众话题 (business=3, growth=2)
    tier4 = ['体育', '足球', '篮球', '世界杯', 'cba', 'nba', '明星', '网红',
             '电影', '电视剧', '综艺', '音乐', '演唱会', '游戏', '电竞',
             '天气', '地震', '暴雨', '台风', '灾害', '事故', '火灾',
             '国际', '外交', '政治', '战争', '社会', '教育', '校园',
             '旅游', '美食', '健康', '美容', '时尚', '娱乐', '八卦',
             '清明上河园', '动物园', '景区', '网红打卡', '热搜', '霸榜']
    for kw in tier4:
        if kw in t:
            return 3 if category == 'business' else 2

    # Default: 通用话题
    return 5 if category == 'business' else 4


# 业务关键词（用于流1的business判断）
# 招 3 (2026-06-05): 已 deprecated——流1 强制 cat='growth'，不再用 BIZ_KW 判定
# 保留定义是避免破坏其他可能引用的代码，**不删除**
BIZ_KW = ['经济', '汽车', '股价', '市场', '销量', '手机', '电脑', '科技',
          'ai', '模型', '芯片', '新能源', '电动', '电池', '能源', '出口', '关税',
          '互联网', '电商', '投资', '金融', '创业', '融资', 'ipo']

# ============================================================================
# 信息密度过滤 + 去重 → 最终入库列表
# ============================================================================
print(f"\n=== 信息密度过滤 ===")

# 流1过滤
flow1_passed = []
flow1_killed_density = []
for item in flow1_top20:
    if info_density_pass(item['title']):
        flow1_passed.append(item)
    else:
        flow1_killed_density.append(item['title'])
print(f"  流1: {len(flow1_top20)}条 → 信息密度通过{len(flow1_passed)}条 (reject {len(flow1_killed_density)}条)")
if flow1_killed_density:
    for t in flow1_killed_density[:5]:
        print(f"    ✗ {t[:50]}")

# 流2过滤
flow2_passed = []
flow2_killed_density = []
for item in flow2_top15:
    if info_density_pass(item['title']):
        flow2_passed.append(item)
    else:
        flow2_killed_density.append(item['title'])
print(f"  流2: {len(flow2_top15)}条 → 信息密度通过{len(flow2_passed)}条 (reject {len(flow2_killed_density)}条)")
if flow2_killed_density:
    for t in flow2_killed_density[:5]:
        print(f"    ✗ {t[:50]}")

# 流1去重
if flow1_passed:
    flow1_deduped = [flow1_passed[i] for i in range(len(flow1_passed))]
    k1, d1 = dedup_filter(flow1_passed)
    flow1_final = [flow1_passed[i] for i in k1]
    print(f"  流1去重: {len(flow1_passed)}条 → 最终{len(flow1_final)}条 (reject {len(d1)}条重复)")
else:
    flow1_final = []

# 流2去重
if flow2_passed:
    k2, d2 = dedup_filter(flow2_passed)
    flow2_final = [flow2_passed[i] for i in k2]
    print(f"  流2去重: {len(flow2_passed)}条 → 最终{len(flow2_final)}条 (reject {len(d2)}条重复)")
else:
    flow2_final = []

# 流3过滤（AIHOT本身已精选，但标题仍需过信息密度）
# 2026-06-08 修复 P1: AIHOT 跳过信息密度过滤 (trust source selection)
# 修前: 8 条入 → 信息密度拒 7 条 → 剩 1 条 angle=2 垃圾 ("ChatGPT 要变 AgentGPT" "OpenAI 超级应用" 全被拦)
# 修后: AIHOT 源 100% 通过信息密度 (源已精选, 二次过滤反而误杀好题)
flow3_passed = list(flow3_normalized)
print(f"  流3: {len(flow3_normalized)}条 → AIHOT 跳过信息密度，全部{len(flow3_passed)}条入库")

# 流3去重
if flow3_passed:
    k3, d3 = dedup_filter(flow3_passed)
    flow3_final = [flow3_passed[i] for i in k3]
    print(f"  流3去重: {len(flow3_passed)}条 → 最终{len(flow3_final)}条")
else:
    flow3_final = []

print(f"\n=== 最终入库统计 ===")
print(f"  流1(热搜): {len(flow1_final)}条 | 流2(Tavily): {len(flow2_final)}条 | 流3(AIHOT): {len(flow3_final)}条")

# 流1入库（信息密度+去重过滤后，review_status='pending'）
# 2026-06-08 修复: 改用 title 单独 hash（去掉 source），跨 source 同标题只入库一次
# 修前: md5(title+source) → 微博+抖音同名热搜会重复入库
# 修后: md5(title) → 跨 source 唯一，OR IGNORE 真正生效
for item in flow1_final:
    topic_id = hashlib.md5(item['title'].encode()).hexdigest()
    # 招 3 (2026-06-05 user 拍板): 流1 热搜源强制 cat='growth'
    # 原逻辑: cat = 'business' if any(kw.lower() in item['title'].lower() for kw in BIZ_KW) else 'growth'
    # 改后: 热搜源 100% 进 growth
    # 原因: 热搜源含大量娱乐/民生/财经话题，BIZ_KW 命中 "汽车/融资" 等词容易误分类为 business
    #       这些"热搜伪 business" m3 角度判定 99% 判低分（v1 实测）
    #       改 cat 不影响 8:30 推送（angle>=7 的 2 条知乎伪 business 改 cat 仍入选），
    #       但让 pool.db category 字段语义更准
    cat = 'growth'  # 招 3：流1 强制 growth（原: BIZ_KW 判定）
    corr = score_correlation(item['title'], cat)
    cur.execute("""INSERT OR IGNORE INTO topics
        (topic_id, title, category, heat_score, source, status, correlation_score, freshness_score, created_at, updated_at, review_status)
        VALUES (?, ?, ?, ?, ?, 'pending', ?, 8.0, ?, ?, 'pending')""",
        (topic_id, item['title'], cat, item['heat_score'], item['source'], corr, now_str, now_str))

# 流2入库（信息密度+去重过滤后，含source_url）
# 2026-06-08 修复: 同上，去掉 'Tavily' 后缀
for item in flow2_final:
    topic_id = hashlib.md5(item['title'].encode()).hexdigest()
    corr = score_correlation(item['title'], 'business')
    source_url = item.get('source_url', '')
    cur.execute("""INSERT OR IGNORE INTO topics
        (topic_id, title, category, heat_score, source, status, correlation_score, freshness_score, created_at, updated_at, review_status, source_url)
        VALUES (?, ?, 'business', ?, 'Tavily', 'pending', ?, 8.0, ?, ?, 'pending', ?)""",
        (topic_id, item['title'], item['heat_score'], corr, now_str, now_str, source_url))

# 流3入库：AIHOT（信息密度+去重过滤后）
# 2026-06-08 修复: 同上，去掉 'AIHOT' 后缀
for item in flow3_final:
    topic_id = hashlib.md5(item['title'].encode()).hexdigest()
    aihot_cat = item.get('aihot_category', '')
    biz_cat = AIHOT_CATEGORIES.get(aihot_cat, 'growth')
    corr = score_correlation(item['title'], biz_cat)
    source_url = item.get('source_url', '')
    cur.execute("""INSERT OR IGNORE INTO topics
        (topic_id, title, category, heat_score, source, status, correlation_score, freshness_score, created_at, updated_at, source_url)
        VALUES (?, ?, ?, ?, ?, 'pending', ?, 8.0, ?, ?, ?)""",
        (topic_id, item['title'], biz_cat, item['heat_score'], 'AIHOT', corr, now_str, now_str, source_url))

conn.commit()

# 统计（排除selected状态，只统计pending）
cur.execute("SELECT COUNT(*) FROM topics WHERE status != 'selected'")
total = cur.fetchone()[0]
cur.execute("SELECT COUNT(*) FROM topics WHERE category='business' AND status != 'selected'")
biz = cur.fetchone()[0]
cur.execute("SELECT COUNT(*) FROM topics WHERE category='growth' AND status != 'selected'")
growth = cur.fetchone()[0]

print(f"\n=== 入库完成 ===")
print(f"流1(热搜): {len(flow1_final)}条 | 流2(Tavily): {len(flow2_final)}条 | 流3(AIHOT): {len(flow3_final)}条")
print(f"总话题: {total}条 (growth:{growth} + business:{biz})")

# 打印business TOP5（排除selected）
print(f"\n=== business TOP5 (归一化后) ===")
cur.execute("SELECT title, heat_score, source FROM topics WHERE category='business' AND status != 'selected' ORDER BY heat_score DESC LIMIT 5")
for i, row in enumerate(cur.fetchall(), 1):
    print(f"{i}. [{row[2]}] {row[1]:.4f} | {row[0][:50]}")

conn.close()
print("\n✅ 采集入库完成")
