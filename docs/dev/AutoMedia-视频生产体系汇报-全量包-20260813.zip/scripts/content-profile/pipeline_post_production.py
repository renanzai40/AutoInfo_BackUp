#!/usr/bin/env python3
"""
pipeline_post_production.py — AutoMedia 后生产发布脚本

管线出口 Gate。在文案 Track + 视频 Track 全部锁定后执行。

功能:
  1. WeChat 公众号草稿上传（阻塞级别：尝试并记录结果，不 exit 1）
  2. 官网博客 MDX 生成（非阻塞：仅写文件不做 git push）
  3. publish_log + project_info 状态更新

用法:
  python3 pipeline_post_production.py <project_dir>
  python3 pipeline_post_production.py <project_dir> --dry-run

Gate 关联:
  - Gate B0（博客自动发布）：本脚本 Step 2
  - WeChat 上传：本脚本 Step 1
  - 两者都不是「保证成功」而是「保证执行+失败有记录」
"""

import argparse
import json
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path

# ── 外部脚本路径 ──
WEBSKILL = "/home/renanzai/.hermes/profiles/content/skills/wechat-official-account-publisher/scripts"
UPLOAD_DRAFT = os.path.join(WEBSKILL, "upload_draft.py")
UPLOAD_THUMB = os.path.join(WEBSKILL, "upload_thumb.py")
AUTO_BLOG = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/auto_blog_publish.py"

# ── 辅助函数 ──

def read_json(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str, data: dict):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def truncate_title(text: str, max_len: int = 9) -> str:
    """提取纯文本截断到 max_len 字，用于 WeChat 标题"""
    clean = re.sub(r"<[^>]+>", "", text).strip()
    # 只保留中英文+数字
    clean = re.sub(r"[^\u4e00-\u9fffA-Za-z0-9 ]", "", clean)
    return clean[:max_len]


def truncate_digest(text: str, max_len: int = 20) -> str:
    """提取纯文本前 max_len 字作为 WeChat 摘要"""
    clean = re.sub(r"<[^>]+>", "", text).strip()
    # 只保留中文+标点
    clean = re.sub(r"\s+", "", clean)
    return clean[:max_len]


def extract_title_from_html(html_path: str) -> str:
    """从 wechat_draft.html 提取标题（取 <h1> 内容，或前导文本）"""
    with open(html_path, encoding="utf-8") as f:
        html = f.read()
    # 先移除 <style> 块
    html = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL)
    # 尝试 <h1>
    m = re.search(r"<h1[^>]*>(.*?)</h1>", html, re.DOTALL)
    if m:
        return truncate_title(m.group(1))
    # 尝试第一个 <p> 或 <strong>
    m = re.search(r"<(p|strong)[^>]*>(.*?)</\1>", html, re.DOTALL)
    if m:
        return truncate_title(m.group(2))
    # 失败 fallback
    return truncate_title(html)


def extract_digest_from_html(html_path: str) -> str:
    """从 wechat_draft.html 提取摘要（正文前 20 字）"""
    with open(html_path, encoding="utf-8") as f:
        html = f.read()
    # 先移除 <style> 块
    html = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL)
    # 再移除所有 HTML 标签
    clean = re.sub(r"<[^>]+>", "", html).strip()
    return truncate_digest(clean)


# ── WeChat 上传 ──

def publish_wechat(project_dir: str, log: dict, dry_run: bool = False) -> dict:
    """
    上传公众号草稿。
    返回 {"status": "ok"|"skipped"|"failed", "media_id": str|None, "error": str|None}。
    """
    platforms = log.get("platforms", {})
    wechat_platform = platforms.get("wechat", {})
    
    # 幂等检查
    if wechat_platform.get("status") == "draft_uploaded":
        return {"status": "skipped", "reason": "已在 publish_log 中标记为已上传", "media_id": wechat_platform.get("content_id")}
    
    # 文件存在性检查
    draft_path = os.path.join(project_dir, "01_content", "drafts", "wechat", "wechat_draft.html")
    cover_path = os.path.join(project_dir, "02_images", "cover", "cover_9x16.jpg")
    
    if not os.path.isfile(draft_path):
        return {"status": "failed", "error": f"wechat_draft.html 不存在: {draft_path}"}
    
    if not os.path.isfile(cover_path):
        return {"status": "failed", "error": f"封面不存在: {cover_path}"}
    
    # 提取标题+摘要
    title = extract_title_from_html(draft_path)
    digest = extract_digest_from_html(draft_path)
    
    if not title:
        return {"status": "failed", "error": "无法从 wechat_draft.html 提取标题"}
    
    if len(title) > 9:
        print(f"  ⚠️ 标题 {len(title)}字 > 9字，截断为: {title}")
    
    if dry_run:
        print(f"  🟡 [dry-run] 标题={title} ({len(title)}字) | 摘要={digest} ({len(digest)}字)")
        return {"status": "dry_run", "title": title, "digest": digest}
    
    # Step A: 上传封面 → 拿到 media_id
    print(f"  📤 上传封面图...")
    try:
        result = subprocess.run(
            ["python3", UPLOAD_THUMB, cover_path],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            err = result.stderr.strip() or result.stdout.strip()[:100]
            return {"status": "failed", "error": f"封面上传失败: {err}"}
        thumb_media_id = result.stdout.strip()
    except subprocess.TimeoutExpired:
        return {"status": "failed", "error": "封面上传超时"}
    except FileNotFoundError:
        return {"status": "failed", "error": f"upload_thumb.py 未找到: {UPLOAD_THUMB}"}
    
    print(f"  ✅ 封面 media_id: {thumb_media_id[:20]}...")
    
    # Step B: 上传草稿
    print(f"  📤 上传草稿...")
    try:
        result = subprocess.run(
            ["python3", UPLOAD_DRAFT,
             "--title", title,
             "--html", draft_path,
             "--thumb-media-id", thumb_media_id,
             "--author", "",
             "--digest", digest],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            err = result.stderr.strip() or result.stdout.strip()[:200]
            return {"status": "failed", "error": f"草稿上传失败: {err}"}
        media_id = result.stdout.strip()
    except subprocess.TimeoutExpired:
        return {"status": "failed", "error": "草稿上传超时"}
    except FileNotFoundError:
        return {"status": "failed", "error": f"upload_draft.py 未找到: {UPLOAD_DRAFT}"}
    
    return {"status": "ok", "media_id": media_id}


# ── 博客发布 ──

def publish_blog(project_dir: str, log: dict, dry_run: bool = False) -> dict:
    """
    生成博客 MDX（不做 git push）。
    返回 {"status": "ok"|"skipped"|"failed", "error": str|None}。
    """
    category = log.get("category", "")
    
    # 仅业务款
    if category not in ("business", "业务款"):
        return {"status": "skipped", "reason": f"category={category}，非业务款不迁移"}
    
    # 幂等检查
    blog_info = log.get("blog", {})
    if blog_info.get("status") == "published":
        return {"status": "skipped", "reason": "博客已在 publish_log 中标记为已发布"}
    
    # 内容深度检查
    zhihu_path = os.path.join(project_dir, "01_content", "drafts", "zhihu", "zhihu_article.md")
    if not os.path.isfile(zhihu_path):
        return {"status": "skipped", "reason": "zhihu_article.md 不存在，无内容可迁移"}
    
    if os.path.getsize(zhihu_path) < 2000:
        return {"status": "skipped", "reason": f"zhihu_article.md 仅 {os.path.getsize(zhihu_path)}B，不足 2000B"}
    
    if dry_run:
        print(f"  🟡 [dry-run] 符合博客资格，将调用 auto_blog_publish.py")
        return {"status": "dry_run"}
    
    # 执行
    try:
        result = subprocess.run(
            ["python3", AUTO_BLOG, project_dir],
            capture_output=True, text=True, timeout=60
        )
        if result.returncode != 0:
            err = result.stderr.strip() or result.stdout.strip()[:200]
            return {"status": "failed", "error": f"博客生成失败: {err}"}
        return {"status": "ok"}
    except subprocess.TimeoutExpired:
        return {"status": "failed", "error": "博客生成超时"}
    except FileNotFoundError:
        return {"status": "failed", "error": f"auto_blog_publish.py 未找到: {AUTO_BLOG}"}


# ── publish_log 更新 ──

def update_publish_log(log_path: str, log: dict, wechat_result: dict, blog_result: dict):
    """将 WeChat/Blog 结果写回 publish_log.json"""
    # 更新 WeChat
    if wechat_result["status"] == "ok":
        log.setdefault("platforms", {})["wechat"] = {
            "status": "draft_uploaded",
            "content_id": wechat_result.get("media_id", ""),
            "uploaded_at": datetime.now().isoformat(),
        }
    elif wechat_result["status"] == "failed":
        log.setdefault("known_issues", []).append({
            "gate": "post_production_wechat",
            "error": wechat_result.get("error", "unknown"),
            "timestamp": datetime.now().isoformat(),
        })
    
    # 更新 Blog
    if blog_result["status"] == "ok":
        log["blog"] = {
            "status": "staging",  # MDX 已写入，未 git push
            "published_at": datetime.now().isoformat(),
        }
    elif blog_result["status"] == "failed":
        log.setdefault("known_issues", []).append({
            "gate": "post_production_blog",
            "error": blog_result.get("error", "unknown"),
            "timestamp": datetime.now().isoformat(),
        })
    
    write_json(log_path, log)


def update_project_status(project_dir: str, status: str):
    """更新 project_info.json 的 status"""
    info_path = os.path.join(project_dir, "00_project_info", "project_info.json")
    if os.path.isfile(info_path):
        info = read_json(info_path)
        info["status"] = status
        info["updated_at"] = datetime.now().isoformat()
        write_json(info_path, info)


# ── 入口 ──

def main():
    parser = argparse.ArgumentParser(
        description="pipeline_post_production.py — AutoMedia 后生产发布脚本"
    )
    parser.add_argument("project_dir", help="项目目录路径")
    parser.add_argument("--dry-run", action="store_true", help="预览模式，不执行 API 调用")
    args = parser.parse_args()
    
    project_dir = os.path.abspath(args.project_dir)
    
    if not os.path.isdir(project_dir):
        print(f"❌ 项目目录不存在: {project_dir}")
        sys.exit(1)
    
    # 读 publish_log
    log_path = os.path.join(project_dir, "05_publish", "publish_log.json")
    if os.path.isfile(log_path):
        log = read_json(log_path)
    else:
        print(f"⚠️ publish_log.json 不存在，创建新文件")
        log = {
            "project_id": os.path.basename(project_dir),
            "status": "content_ready",
            "platforms": {},
        }
    
    topic = log.get("topic", os.path.basename(project_dir))
    print(f"\n{'='*60}")
    print(f"pipeline_post_production: {topic[:40]}...")
    print(f"{'='*60}")
    
    # ── Step 1: WeChat ──
    print(f"\n--- Step 1: WeChat 公众号草稿 ---")
    wechat_result = publish_wechat(project_dir, log, args.dry_run)
    print(f"  → {wechat_result}")
    
    # ── Step 2: Blog ──
    print(f"\n--- Step 2: 博客 MDX 生成 ---")
    blog_result = publish_blog(project_dir, log, args.dry_run)
    print(f"  → {blog_result}")
    
    # ── Step 3: 更新日志 ──
    if not args.dry_run:
        print(f"\n--- Step 3: 更新 publish_log ---")
        update_publish_log(log_path, log, wechat_result, blog_result)
        print(f"  ✅ publish_log 已更新")
        
        # 如果 WeChat 成功，更新项目状态
        if wechat_result["status"] == "ok" or wechat_result["status"] == "skipped":
            update_project_status(project_dir, "published")
            print(f"  ✅ project_info.status → published")
        elif wechat_result["status"] == "failed":
            update_project_status(project_dir, "post_production_pending")
            print(f"  ⚠️ project_info.status → post_production_pending")
    
    # ── 机器可读报告 ──
    print(f"\n{'='*60}")
    print(f"报告")
    print(f"{'='*60}")
    print(f"WECHAT_STATUS={wechat_result['status']}")
    if wechat_result.get("error"):
        print(f"WECHAT_ERROR={wechat_result['error']}")
    if wechat_result.get("media_id"):
        print(f"WECHAT_MEDIA_ID={wechat_result['media_id']}")
    print(f"BLOG_STATUS={blog_result['status']}")
    if blog_result.get("error"):
        print(f"BLOG_ERROR={blog_result['error']}")
    print(f"PROJECT_STATUS=published" if wechat_result['status'] in ('ok', 'skipped') else f"PROJECT_STATUS=post_production_pending")
    
    # exit 0 无论失败——不阻塞管线
    sys.exit(0)


if __name__ == "__main__":
    main()
