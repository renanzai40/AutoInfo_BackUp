#!/usr/bin/env python3
"""
G0.5 Production Init Check — 生产前初始化预检 + 自动修复。

每次进入生产链路（R0 调研前）必须跑此检查。

检查项:
  1. 00_project_info/project_info.json 存在 + 非空
  2. project_info.json 中 source 字段非空（pool/manual）
  3. pool.db 中对应 topic 的 status 是否为 selected（仅 pool 来源需要检查）

自动修复:
  - 缺少 project_info.json → 尝试从已有目录结构推断参数，调用 init_project.py 补
  - 缺少 topic_id/status 不对 → 调用 pool_sync.py 同步

用法:
  python3 check_production_init.py --project-dir /path/to/project

返回码:
  0 = 全部通过（含自动修复后通过）
  1 = 无法修复（需人工介入）
  2 = 跳过（非 pool 项目，不适用）
"""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

DB_PATH = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db"
SCRIPTS = os.path.expanduser("~/.hermes/profiles/content/scripts")
INIT_SCRIPT = os.path.join(SCRIPTS, "init_project.py")
POOL_SYNC = os.path.join(SCRIPTS, "pool_sync.py")


def check_pool_status(topic_id: str) -> tuple[bool, str]:
    """检查 pool.db 中 topic 的状态"""
    import sqlite3
    if not os.path.exists(DB_PATH):
        return False, f"pool.db 不存在: {DB_PATH}"

    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute(
            "SELECT status FROM topics WHERE topic_id=?",
            (topic_id,)
        )
        row = cur.fetchone()
        conn.close()
        if row is None:
            return False, f"topic_id={topic_id[:16]}... 在 pool.db 中不存在"
        if row[0] == "selected":
            return True, f"pool.db status=selected ✅"
        else:
            return False, f"pool.db status={row[0]} (应为 selected)"
    except Exception as e:
        return False, f"查询 pool.db 失败: {e}"


def find_topic_title_in_dir(project_dir: Path) -> str | None:
    """从项目目录中推断话题标题"""
    candidates = [
        project_dir / "00_research" / "research_notes.md",
    ]
    for fpath in candidates:
        if fpath.exists():
            text = fpath.read_text(encoding="utf-8", errors="replace")
            # 取第一个 # 标题
            for line in text.split("\n"):
                line = line.strip()
                if line.startswith("# "):
                    return line[2:].strip()
    return None


def extract_slug_from_dirname(project_name: str) -> str:
    """从目录名提取 slug（去掉时间戳前缀）"""
    # 格式: YYYYMMDD_HHMMSS_slug 或 YYYYMMDD_slug
    parts = project_name.split("_", 2)
    if len(parts) >= 3 and parts[0].isdigit() and len(parts[0]) == 8:
        return parts[2]
    if len(parts) >= 2 and parts[0].isdigit() and len(parts[0]) == 8:
        return parts[1]
    return project_name


def auto_fix_init(project_dir: Path, project_name: str) -> bool:
    """尝试自动修复缺失的初始化"""
    print(f"  🔧 尝试自动修复...")

    # 从 research_notes.md 推断标题
    title = find_topic_title_in_dir(project_dir)
    if not title:
        # 从目录名推断
        title = project_name.replace("_", " ").replace("-", " ")
        print(f"  ⚠️ 无法从 research_notes.md 推断标题，使用目录名: {title[:40]}")

    slug = extract_slug_from_dirname(project_name)

    # 推断 category
    category = "引流款"  # 默认
    # 检查 project root 下有没有提示
    gates_file = project_dir / ".gates_status.json"
    if not gates_file.exists():
        # 看看目录里有没有文章内容可以推断
        for draft_dir in [
            project_dir / "01_content" / "drafts" / "wechat",
        ]:
            if draft_dir.exists():
                for f in draft_dir.iterdir():
                    if f.is_file() and f.stat().st_size > 100:
                        text = f.read_text(encoding="utf-8", errors="replace")
                        if "业务" in text or "企业" in text or "B2B" in text:
                            category = "业务款"
                            break

    # 调用 init_project.py 补初始化
    cmd = [
        sys.executable, INIT_SCRIPT,
        "--topic-title", title,
        "--topic-slug", slug,
        "--category", category,
        "--project-dir", project_name,
    ]
    print(f"  运行: init_project.py --topic-title \"{title[:40]}...\" --topic-slug {slug} --category {category}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    for line in result.stdout.strip().split("\n"):
        if line.strip() and not line.startswith("/mnt/"):
            print(f"    {line.strip()}")
    if result.stderr.strip():
        print(f"    stderr: {result.stderr.strip()}", file=sys.stderr)
    return result.returncode == 0


def auto_fix_pool_sync(project_dir: Path, title: str) -> bool:
    """尝试自动修复 pool.db 状态"""
    print(f"  🔧 自动修复 pool.db 同步...")
    cmd = [
        sys.executable, POOL_SYNC,
        "--project-dir", str(project_dir),
        "--topic-title", title,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    for line in result.stdout.strip().split("\n"):
        if line.strip():
            print(f"    {line.strip()}")
    if result.stderr.strip():
        print(f"    stderr: {result.stderr.strip()}")
    return result.returncode == 0


def main():
    parser = argparse.ArgumentParser(description="G0.5 生产初始化预检")
    parser.add_argument("--project-dir", required=True, help="项目根目录")
    parser.add_argument("--skip-auto-fix", action="store_true", help="跳过自动修复，只报告不修")
    args = parser.parse_args()

    project_dir = Path(args.project_dir)
    project_name = project_dir.name

    if not project_dir.exists():
        print(f"❌ G0.5 FAIL: 项目目录不存在: {project_dir}")
        return 1

    print(f"🔍 G0.5 生产初始化预检: {project_name}")
    issues = []
    fixes_applied = 0

    # === Check 1: project_info.json ===
    info_path = project_dir / "00_project_info" / "project_info.json"
    info_ok = False
    source = ""
    topic_title = ""

    if info_path.exists() and info_path.stat().st_size > 2:
        try:
            info = json.loads(info_path.read_text(encoding="utf-8"))
            source = info.get("source", "")
            topic_title = info.get("topic", "")
            if info.get("topic_id"):
                info_ok = True
                print(f"  ✅ project_info.json: 存在 + topic_id 非空")
            else:
                issues.append("project_info.json topic_id 为空")
                print(f"  ⚠️ project_info.json: 存在但 topic_id 为空")
                # 尝试从池中反查标题
                if not topic_title:
                    topic_title = find_topic_title_in_dir(project_dir) or project_name
        except json.JSONDecodeError:
            issues.append("project_info.json 格式错误")
            print(f"  ❌ project_info.json: 格式错误")
    else:
        issues.append("00_project_info/project_info.json 缺失")
        print(f"  ❌ 00_project_info/project_info.json: 缺失")
        topic_title = find_topic_title_in_dir(project_dir) or project_name

    # 自动修复 Check 1
    if not info_ok and not args.skip_auto_fix:
        if auto_fix_init(project_dir, project_name):
            fixes_applied += 1
            # 重新读取
            if info_path.exists() and info_path.stat().st_size > 2:
                try:
                    info = json.loads(info_path.read_text(encoding="utf-8"))
                    source = info.get("source", "")
                    topic_title = info.get("topic", "")
                    info_ok = bool(info.get("topic_id"))
                except Exception:
                    pass

    # === Check 2: source 非空 ===
    if info_ok:
        if source:
            print(f"  ✅ source = {source}")
        else:
            issues.append("project_info.json 中 source 为空")
            print(f"  ⚠️ source 为空")
            # 尝试修复：调用 pool_sync 补 source
            if not args.skip_auto_fix and topic_title:
                if auto_fix_pool_sync(project_dir, topic_title):
                    fixes_applied += 1
                    # 重新读取
                    try:
                        info = json.loads(info_path.read_text(encoding="utf-8"))
                        source = info.get("source", "")
                    except Exception:
                        pass

    # === Check 3: pool.db 状态（仅 pool 来源） ===
    if info_ok and source == "pool":
        tid = info.get("topic_id", "")
        if tid:
            ok, msg = check_pool_status(tid)
            if ok:
                print(f"  ✅ {msg}")
            else:
                issues.append(msg)
                print(f"  ❌ {msg}")
                if not args.skip_auto_fix:
                    if auto_fix_pool_sync(project_dir, topic_title):
                        fixes_applied += 1
    elif info_ok:
        print(f"  ℹ️ source={source}，跳过 pool.db 状态检查")

    # === 结果 ===
    if issues and fixes_applied == 0:
        print()
        print(f"❌ G0.5 FAIL: 发现 {len(issues)} 个问题，无法自动修复")
        for i, issue in enumerate(issues, 1):
            print(f"   {i}. {issue}")
        return 1
    elif issues:
        print()
        print(f"⚠️ G0.5 FIXED: {fixes_applied} 个问题已自动修复，{len(issues) - fixes_applied} 个残留")
        for issue in issues:
            print(f"   ⚠️ {issue}")
        return 0 if len(issues) == fixes_applied else 1
    else:
        print()
        print(f"✅ G0.5 PASS: 初始化检查全部通过")
        return 0


if __name__ == "__main__":
    sys.exit(main())
