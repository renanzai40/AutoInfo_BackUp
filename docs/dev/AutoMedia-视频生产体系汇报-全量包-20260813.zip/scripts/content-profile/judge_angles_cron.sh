#!/bin/bash
# judge_angles_cron.sh — cron 调 LLM 角度分判定的 wrapper
# 触发：judge_angles_08x10 / judge_angles_12x00 / judge_angles_16x00 3 个 cron job
# 原因：hermes cron scheduler 把 script 字段当纯路径，不支持命令行参数
#       所以包一层 bash 脚本，固定传 --limit 200
# 2026-06-06 增强：显式传 --source 全 5 个 source（防御 LLM 脚本默认值被改坏导致
#                 cron 静默漏跑中文平台话题——8:30 推送会全靠旧数据）
# 注：当前 LLM 为 DeepSeek-v4-flash (opencode-go)，2026-06-08 从 MiniMax M3 迁移
set -e
exec /home/renanzai/.hermes/hermes-agent/venv/bin/python3 \
    /home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py \
    --limit 200 \
    --source 微博,知乎,抖音,Tavily,AIHOT
