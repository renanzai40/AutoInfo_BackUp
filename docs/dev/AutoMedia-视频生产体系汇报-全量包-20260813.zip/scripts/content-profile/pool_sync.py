#!/usr/bin/env python3
"""AutoMedia 项目初始化 — pool.db 同步脚本。

在项目创建时调用，将选中话题的 pool.db status 从 pending 改为 selected，
并把真实的 topic_id 写回 project_info.json。

从而从源头杜绝「已选的话题仍在池子里重新出现」。

用法:
  python3 pool_sync.py --project-dir /path/to/project --topic-title "话题标题"

匹配策略（优先级递减）:
  1. topic_id 精确匹配（如果 project_info.json 已有 topic_id）
  2. 标题去空格归一化精确匹配
  3. 标题子串匹配（池中标题包含项目标题关键词或反之）
  4. 关键词交集匹配（提取数字+中英文词，交集 >= 2 个）
  5. 找不到则跳过（manual 话题不在池中，属于正常情况）
"""

import argparse
import json
import re
import sqlite3
import sys
from pathlib import Path

DB_PATH = Path("/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db")


def normalize(s: str) -> str:
    """去掉所有空白字符和常见标点"""
    s = s.lower()
    s = re.sub(r'[\s\u3000\u2000-\u200f\u3000\u3001-\u303f\uff00-\uffef'
               r'.,。、，、;:!?！？()（）「」『』【】《》""""''·…—\-]', '', s)
    return s


def extract_kws(s: str) -> set:
    """提取关键词：数字-量词组合 + 中文词(>=2字) + 英文词(>=3字符) + 中文2-gram"""
    s = s.lower()
    kws = set()
    # 数字（含千亿等量级）
    nums = re.findall(r'\d+[\u4e00-\u9fff]*|[\u4e00-\u9fff]*\d+', s)
    kws.update(nums)
    # 中文词 >= 2 字
    cjk = re.findall(r'[\u4e00-\u9fff]{2,}', s)
    stopwords = {'一个', '可以', '这个', '那个', '什么', '怎么', '如何',
                 '我们', '他们', '你们', '没有', '不是', '就是', '但是',
                 '还是', '因为', '所以', '如果', '虽然', '已经', '通过',
                 '进行', '以及', '之后', '之前', '其中', '由于', '为了',
                 '发布', '推出', '上线', '新增', '宣布', '上线', '推出',
                 '最新', '首次', '正式', '全面', '开始', '实现', '打造'}
    kws.update(t for t in cjk if t not in stopwords)
    # 中文2-gram（滑动窗口，解决不同标题用词差异问题）
    # 例: "年营收130亿"的2-gram = {"年营", "营收", "收1", "13", "30", "0亿"}
    all_cjk = ''.join(re.findall(r'[\u4e00-\u9fff]+', s))
    for i in range(len(all_cjk) - 1):
        kws.add(all_cjk[i:i+2])
    # 英文词 >= 3 字符
    eng = re.findall(r'[a-zA-Z]{3,}', s)
    kws.update(eng)
    return kws


def match_in_pool(title: str) -> dict | None:
    """在 pool.db 中查找匹配的话题，返回匹配信息或 None"""
    if not DB_PATH.exists():
        print(f"[WARN] pool.db 不存在: {DB_PATH}", file=sys.stderr)
        return None

    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    norm_title = normalize(title)
    kw_title = extract_kws(title)

    # 读取所有 pending 话题
    cur.execute("""
        SELECT topic_id, title, status, review_status, angle_score
        FROM topics
        WHERE status = 'pending'
        ORDER BY created_at DESC
    """)
    all_pending = cur.fetchall()
    conn.close()

    candidates = []

    for row in all_pending:
        db_norm = normalize(row["title"])

        # P1: 归一化精确匹配
        if db_norm == norm_title:
            candidates.append((1, row))
            continue

        # P2: 子串匹配（带长度差约束）
        if norm_title in db_norm or db_norm in norm_title:
            max_len = max(len(norm_title), len(db_norm))
            min_len = min(len(norm_title), len(db_norm))
            if min_len / max_len > 0.3:  # 短的是长的至少30%长度
                candidates.append((2, row))
                continue

        # P3: 关键词交集匹配（不含2-gram，防止金融/科技常见词误匹配）
        db_kw = extract_kws(row["title"])
        overlap = kw_title & db_kw
        # 只统计 >=3字符的关键词（排除2-gram，如"亿美元"这种通用词只算1个）
        meaningful_overlap = {w for w in overlap if len(w) >= 3}
        if len(meaningful_overlap) >= 2:
            candidates.append((3, row, overlap))

    if not candidates:
        return None

    # 按优先级 + angle_score 排序（angle 可能为 NULL）
    def sort_key(item):
        priority = item[0]
        row = item[1]
        angle = row["angle_score"] if row["angle_score"] is not None else 0
        return (priority, -angle)
    candidates.sort(key=sort_key)
    priority, best = candidates[0][0], candidates[0][1]

    return {
        "topic_id": best["topic_id"],
        "title": best["title"],
        "match_priority": priority,
        "angle_score": best["angle_score"],
        "review_status": best["review_status"],
    }


def update_pool_db(topic_id: str) -> bool:
    """将 pool.db 中话题 status 改为 selected"""
    conn = sqlite3.connect(str(DB_PATH))
    cur = conn.cursor()
    cur.execute("""
        UPDATE topics
        SET status='selected', updated_at=CURRENT_TIMESTAMP
        WHERE topic_id=? AND status='pending'
    """, (topic_id,))
    affected = cur.rowcount
    conn.commit()
    conn.close()
    return affected > 0


def update_project_info(project_dir: Path, topic_id: str):
    """将 topic_id 和 source 写回 project_info.json"""
    for info_candidate in [
        project_dir / "00_project_info" / "project_info.json",
        project_dir / "00_project_info.json",
    ]:
        if info_candidate.exists() and info_candidate.stat().st_size > 2:
            try:
                info = json.loads(info_candidate.read_text(encoding="utf-8"))
                changed = False
                if info.get("topic_id") != topic_id:
                    info["topic_id"] = topic_id
                    changed = True
                if info.get("source") != "pool":
                    info["source"] = "pool"
                    changed = True
                if changed:
                    info_candidate.write_text(
                        json.dumps(info, indent=2, ensure_ascii=False),
                        encoding="utf-8",
                    )
                print(f"  ✅ project_info.json 已更新: topic_id={topic_id[:16]}... source=pool")
                return True
            except Exception as e:
                print(f"  ❌ 更新 project_info.json 失败: {e}", file=sys.stderr)
    return False


def main():
    parser = argparse.ArgumentParser(description="项目初始化时同步 pool.db")
    parser.add_argument("--project-dir", required=False, default="", help="项目根目录（可选，不提供则只更新 pool.db）")
    parser.add_argument("--topic-title", required=True, help="话题标题")
    parser.add_argument("--dry-run", action="store_true", help="只检查不写入")
    args = parser.parse_args()

    title = args.topic_title
    has_project_dir = bool(args.project_dir)
    project_dir = Path(args.project_dir) if has_project_dir else None

    if has_project_dir and not project_dir.exists():
        print(f"  ⚠️ 项目目录不存在，跳过 project_info.json 写入: {project_dir}")
        has_project_dir = False
        project_dir = None

    print(f"🔍 pool_sync: 查找「{title[:60]}」")
    match = match_in_pool(title)

    if match:
        print(f"  ✅ 匹配 (优先级 {match['match_priority']})")
        print(f"     池中标题: {match['title'][:60]}")
        print(f"     topic_id: {match['topic_id']}")
        print(f"     angle={match['angle_score']} | review={match['review_status']}")

        if not args.dry_run:
            if update_pool_db(match["topic_id"]):
                print(f"  ✅ pool.db: pending → selected")
            else:
                print(f"  ⚠️ pool.db 未更新（可能已 selected/archived）")
            if has_project_dir and project_dir:
                update_project_info(project_dir, match["topic_id"])
        else:
            print(f"  🔸 dry-run 模式，未写入")

        return 0
    else:
        print(f"  ⚠️ pool.db 未匹配（manual 话题，正常跳过）")
        # 对于 manual 项目，在 project_info.json 标注 source=manual
        if not args.dry_run and has_project_dir and project_dir:
            for info_candidate in [
                project_dir / "00_project_info" / "project_info.json",
                project_dir / "00_project_info.json",
            ]:
                if info_candidate.exists():
                    try:
                        info = json.loads(info_candidate.read_text(encoding="utf-8"))
                        if info.get("source") != "manual":
                            info["source"] = "manual"
                            info_candidate.write_text(
                                json.dumps(info, indent=2, ensure_ascii=False),
                                encoding="utf-8",
                            )
                            print(f"  ✅ source=manual 已标注")
                    except Exception:
                        pass
                    break
        return 0


if __name__ == "__main__":
    sys.exit(main())
