#!/usr/bin/env python3
"""
tts_produce.py — TTS 生产脚本（品牌资产声音 · 唯一入口）

品牌声音资产固定为 edge-tts zh-CN-YunjianNeural（男声）。
任何其他路径生成 TTS（text_to_speech 工具、其他 voice 等）均为违反 Gate V4。

用法:
  python3 tts_produce.py \
    --script 01_content/drafts/tiktok/script.txt \
    --text "$(cat 01_content/drafts/tiktok/tts_input.txt)" \
    --output 03_video/audio_voiceover.mp3

功能:
  1. Gate C3.5: 脚本结构检查（--script 参数提供的原始脚本）
  2. Gate V4.5: TTS 输入品牌核验（--text / --file 中的文本）
  3. edge-tts 生成音频 + 自动 fallback 链
  4. Gate V4: Whisper 音频内容验证（关键词命中率 ≥ 30%）
  5. exit 0 = 全部通过 / exit 1 = Pipeline STOP

Gate 关联:
  - Gate V4（TTS 声音品牌资产）：本脚本的 Whisper 验证是 V4 的执行主体
  - Gate V4.5（TTS 输入品牌核验）：本脚本前置品牌 grep
  - Gate C3.5（视频脚本结构）：本脚本前置结构检查（--script 参数）
  - Gate V5（mp3 vs SRT 核验）：本脚本的 Whisper 验证是 V5 的前置步骤
"""

import argparse
import subprocess
import sys
import re
import os
import tempfile

# ── 品牌资产 voice 链（按优先级） ──
VOICE_CHAIN = [
    "zh-CN-YunjianNeural",   # 用户指定的默认 voice（2026-06-24 确认）
    "zh-CN-YunxiNeural",     # 男声备选（默认 voice 服务端不可用时）
    "zh-CN-XiaoxiaoNeural",  # 女声备选（前两个均不可用时的兜底）
]

VOICE_LABELS = {
    "zh-CN-YunjianNeural": "✅ 用户指定的默认 voice",
    "zh-CN-YunxiNeural":   "⚠️ 男声备选（原默认 voice 不可用）",
    "zh-CN-XiaoxiaoNeural": "⚠️ 女声备选（前两个均不可用时的兜底）",
}

# ── 核心函数 ──

def generate_audio(text: str, output_path: str, voice: str) -> tuple[bool, str]:
    """Run edge-tts 生成音频。返回 (success, error_message)。"""
    cmd = [
        "edge-tts",
        "--voice", voice,
        "--text", text,
        "--write-media", output_path,
    ]
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=120
        )
        if result.returncode != 0:
            return False, result.stderr.strip()
        return True, ""
    except subprocess.TimeoutExpired as e:
        return False, f"TimeoutExpired: {e}"
    except FileNotFoundError:
        return False, "edge-tts 命令未找到，请确认已安装"


def get_audio_duration(path: str) -> float | None:
    """ffprobe 获取音频时长（秒）。失败时返回 None。"""
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=nw=1:nk=1", path],
        capture_output=True, text=True, timeout=10,
    )
    if result.returncode == 0 and result.stdout.strip():
        return float(result.stdout.strip())
    return None


def whisper_verify(audio_path: str, original_text: str) -> tuple[bool, float, list[str]]:
    """
    Whisper tiny 验证音频内容是否匹配输入文本。

    提取原文中的关键词（中文词、数字、英文词），
    在 Whisper 转写结果中匹配。命中率 ≥ 30% 为通过。

    返回 (passed, hit_rate_percent, missing_keywords)。
    """
    # 提取关键词
    keywords = set()
    # 中文词（≥2 字）
    keywords.update(re.findall(r'[\u4e00-\u9fff]{2,}', original_text))
    # 数字（含单位）
    keywords.update(re.findall(r'\d+\.?\d*[万亿%]*', original_text))
    # 英文/数字组合（含标点符号）
    keywords.update(re.findall(r'[A-Za-z0-9_.-]{2,}', original_text))
    # 过滤过短的
    keywords = {k for k in keywords if len(k) >= 2}

    if not keywords:
        return True, 100.0, []  # 无可提取关键词，跳过验证

    # 运行 Whisper
    with tempfile.TemporaryDirectory(prefix="tts_verify_") as tmpdir:
        result = subprocess.run(
            ["whisper", audio_path, "--language", "zh", "--model", "tiny",
             "--output_format", "txt", "--output_dir", tmpdir],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode != 0:
            # Whisper 失败不阻塞（可能是工具链环境问题）
            return True, 0.0, []

        # 读取转写结果
        base = os.path.basename(audio_path).rsplit(".", 1)[0]
        txt_path = os.path.join(tmpdir, f"{base}.txt")
        if not os.path.exists(txt_path):
            # 尝试 .wav.txt（whisper 有时改后缀）
            alt = os.path.join(tmpdir, f"{base}.wav.txt")
            if os.path.exists(alt):
                txt_path = alt
            else:
                return True, 0.0, []

        with open(txt_path, encoding="utf-8") as f:
            whisper_text = f.read()

    # 匹配
    missing = [kw for kw in sorted(keywords, key=len, reverse=True)
               if kw not in whisper_text]
    hit = len(keywords) - len(missing)
    rate = (hit / len(keywords)) * 100

    if rate >= 30:
        return True, rate, missing[:5]
    else:
        return False, rate, missing[:5]


def main():
    parser = argparse.ArgumentParser(
        description="tts_produce.py — TTS 生产脚本（品牌资产声音 · 唯一入口）"
    )
    parser.add_argument(
        "--text", help="要朗读的文本（与 --file 二选一）"
    )
    parser.add_argument(
        "--file", help="从文件读取文本（与 --text 二选一）"
    )
    parser.add_argument(
        "--output", required=True, help="输出音频文件路径（.mp3）"
    )
    parser.add_argument(
        "--script", help="原始脚本文件路径（含分段标记，用于 Gate C3.5 结构检查）"
    )
    parser.add_argument(
        "--skip-preflight", action="store_true",
        help="跳过 Gate V4.5 + C3.5 前置检查（仅调试用，生产路径不可跳过）"
    )
    parser.add_argument(
        "--skip-verify", action="store_true",
        help="跳过 Whisper 验证（仅调试用，生产路径不可跳过）"
    )
    args = parser.parse_args()

    # ── 读取输入文本 ──
    if args.file:
        with open(args.file, encoding="utf-8") as f:
            text = f.read().strip()
    elif args.text:
        text = args.text
    else:
        parser.error("需要 --text 或 --file 之一")

    if not text.strip():
        print("❌ tts_produce: 输入文本为空")
        sys.exit(1)

    # ── Gate V4.5: TTS 输入品牌核验 ──
    if not args.skip_preflight:
        if "壹目贯维" not in text:
            print("❌ Gate V4.5 未通过: TTS 输入文本不含品牌名「壹目贯维」")
            print("   请检查 tts_input.txt 是否包含品牌 CTA 段")
            print("   Pipeline STOP")
            sys.exit(1)
        print("✅ Gate V4.5 通过: 输入文本含品牌名")

    # ── Gate C3.5: 视频脚本结构检查（仅当提供了 --script） ──
    if not args.skip_preflight and args.script:
        script_path = args.script
        if os.path.isfile(script_path):
            with open(script_path, encoding="utf-8") as sf:
                script_content = sf.read()
            
            # 检查是否有分段结构（【...】标记）
            sections = re.findall(r'【[^】]+】', script_content)
            
            # 检查最后一段是否含品牌 CTA 意图
            last_section_text = script_content.strip()
            has_cta_intent = (
                "壹目贯维" in script_content
                or "关注" in re.findall(r'[^。]*$', script_content)[0] if re.findall(r'[^。]*$', script_content) else False
            )
            
            # 更准确的：取最后一个【】段的内容
            last_seg_match = re.findall(r'【([^】]+)】\s*([^【]*)', script_content)
            if last_seg_match:
                last_title, last_body = last_seg_match[-1]
                has_cta = "壹目贯维" in last_body or "关注" in last_body or "CTA" in last_title.upper()
            else:
                has_cta = "壹目贯维" in script_content
            
            if len(sections) < 3:
                print("❌ Gate C3.5 未通过: 脚本分段不足（建议 5 段式结构）")
                print(f"   检测到 {len(sections)} 个分段标记")
                print("   Pipeline STOP")
                sys.exit(1)
            
            n = len(sections)
            if n >= 5:
                print(f"  ✅ 脚本结构: {n} 段式结构完整")
            else:
                print(f"  ⚠️ 脚本结构: {n} 段（建议 5 段式）")
            
            if not has_cta:
                print("❌ Gate C3.5 未通过: 脚本最后一段缺少品牌 CTA")
                print("   最后一段应含「壹目贯维」或关注引导")
                print("   Pipeline STOP")
                sys.exit(1)
            print(f"  ✅ 品牌段: 最后一段含品牌 {last_title if last_seg_match else ''}")
            print("✅ Gate C3.5 通过: 脚本结构含品牌 CTA")
        else:
            print(f"  ⚠️ --script 文件不存在: {script_path}（跳过 C3.5 检查）")
    
    # ── 确保输出目录存在 ──
    out_dir = os.path.dirname(args.output)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    # ── 尝试 voice 链 ──
    success = False
    used_voice = None
    last_error = ""

    for voice in VOICE_CHAIN:
        # 每 voice 最多重试 1 次（服务端临时问题）
        for attempt in range(2):
            ok, err = generate_audio(text, args.output, voice)
            if ok:
                success = True
                used_voice = voice
                break
            if "NoAudioReceived" in err and attempt == 0:
                print(f"  ⚠️ {voice}: NoAudioReceived，重试一次...")
                continue
            last_error = err
            print(f"  ❌ {voice}: {err[:120]}")
            break
        if success:
            break

    if not success:
        print(f"\n❌ tts_produce: 所有 voice 均不可用")
        print(f"   最后错误: {last_error[:200]}")
        print(f"   Pipeline STOP — 建议等 30 秒后重试")
        sys.exit(1)

    print(f"✅ 音频生成成功")
    print(f"   输出: {args.output}")
    print(f"   voice: {used_voice}")

    # voice 说明
    label = VOICE_LABELS.get(used_voice, "⚠️ 非标准 voice")
    print(f"           ({label})")

    # 输出时长
    dur = get_audio_duration(args.output)
    if dur is not None:
        print(f"   时长: {dur:.1f}s")
    else:
        print(f"   ⚠️ 无法获取时长（文件可能损坏）")

    # ── Whisper 验证（除非 --skip-verify） ──
    if not args.skip_verify:
        print(f"   --- Whisper 验证 ---")
        passed, rate, missing = whisper_verify(args.output, text)
        if passed:
            print(f"   ✅ 关键词命中率: {rate:.0f}% (≥30%)")
        else:
            print(f"   ❌ 关键词命中率: {rate:.0f}% (< 30%)")
            print(f"      缺失关键词: {missing}")
            print(f"      音频内容与输入文本不匹配，Pipeline STOP")
            # 清理失败产物
            if os.path.exists(args.output):
                os.remove(args.output)
            sys.exit(1)

    # ── 机器可读输出 ──
    print(f"TTS_VOICE={used_voice}")
    if dur is not None:
        print(f"TTS_DURATION={dur:.3f}")

    sys.exit(0)


if __name__ == "__main__":
    main()
