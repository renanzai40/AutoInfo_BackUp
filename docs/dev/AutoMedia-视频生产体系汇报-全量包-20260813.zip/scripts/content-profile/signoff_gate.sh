#!/bin/bash
# signoff_gate.sh — Mark a gate as passed in the project's gate status file.
#
# Usage:
#   signoff_gate.sh --project /path/to/project --gate VQ [--status pass|skip]
#
# This creates/updates <project>/.gates_status.json

set -euo pipefail

PROJECT=""
GATE=""
STATUS="pass"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --project) PROJECT="$2"; shift 2 ;;
        --gate)    GATE="$2"; shift 2 ;;
        --status)  STATUS="$2"; shift 2 ;;
        *) echo "Unknown: $1"; exit 1 ;;
    esac
done

if [ -z "$PROJECT" ] || [ -z "$GATE" ]; then
    echo "Usage: signoff_gate.sh --project DIR --gate GATE [--status pass|skip]"
    exit 1
fi

GATES_FILE="$PROJECT/.gates_status.json"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# Read existing or create new
if [ -f "$GATES_FILE" ]; then
    python3 -c "
import json
with open('$GATES_FILE') as f:
    d = json.load(f)
gates = d.get('gates', {})
gates['$GATE'] = {'status': '$STATUS', 'timestamp': '$TIMESTAMP'}
d['gates'] = gates
with open('$GATES_FILE', 'w') as f:
    json.dump(d, f, indent=2)
" 2>/dev/null || {
    # Fallback on parse failure
    echo "{\"gates\": {\"$GATE\": {\"status\": \"$STATUS\", \"timestamp\": \"$TIMESTAMP\"}}}" > "$GATES_FILE"
}
else
    echo "{\"gates\": {\"$GATE\": {\"status\": \"$STATUS\", \"timestamp\": \"$TIMESTAMP\"}}}" > "$GATES_FILE"
fi

echo "✅ Gate $GATE → $STATUS ($PROJECT)"
