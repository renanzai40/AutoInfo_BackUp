# AutoMedia 视频生产体系汇报

> 汇报时间：2026-08-13 ｜ 汇报人：壹目贯维内容总监（content profile）
> 范围：技术栈 / 工作流 / Skills 体系 / Gate 门控 / 脚本硬化 / 项目现状

---

## 一、总览（30 秒版）

AutoMedia 视频生产已全面切换到 **HyperFrames 管线（HTML + GSAP → MP4）**，替代早期 Remotion 方案。全链路从热点采集 → 选题评分 → 文案 → 视频 → QA → 发布，由 **25 个强制 Gate + 三层自强化架构（TODO 纪律 / Shell Hook 拦截 / Audit 自检）** 保证质量。核心执行脚本全部硬化为 exit code 强制，TTS 走唯一入口 `tts_produce.py`，渲染被 `pre_render_hook.sh` 自动拦截未过 Gate 的命令。

---

## 二、技术栈

| 层 | 组件 | 版本/规格 | 用途 |
|---|---|---|---|
| 渲染核心 | **HyperFrames CLI** | v0.7.98（bun 1.3.14） | HTML + GSAP 动画 → MP4，`bun x hyperframes lint / render` |
| 合成方案 | HTML + GSAP | 根 composition + 每场景子 composition | 场景化动画视频，CSS 终态 + GSAP 动效 |
| 视频处理 | **FFmpeg** | 8.1.1 | 字幕烧录（wqy-zenhei.ttc CJK 字体）、音频处理、concat |
| 语音验证 | **Whisper** | venv 内（faster-whisper） | 全音频转写验证（Gate V2/V4/V5）、SRT 生成与校准 |
| TTS 声音 | **edge-tts** | `zh-CN-YunjianNeural`（男声，品牌资产） | 唯一 TTS 路径 `tts_produce.py`，带 fallback 链 |
| 内文配图 | **ComfyUI 本地** | SD1.5（1660Ti 6GB REST API） | `gen_ui_images.py` / `gen_inline_images.py` 一键生成（禁用 MiniMax 生图） |
| 多模态 | **MiniMax** | 仅音乐/视频（MTV 类项目） | `minimax_music.py` / `minimax_video.py` |
| 脚本层 | Python 3.11.15 | content profile venv | 全部 Gate 脚本 / 采集 / 发布 |
| 数据层 | SQLite | `Pool/pool.db` | 话题池、选题评分、状态流转 |
| 工作区 | `/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/` | 67 个项目 + HyperFrames 子目录 | 项目 registry / 交付包 / 指南 |

**HyperFrames 项目三位置**（扫描时必须全查）：
1. `~/HyperFrames-Projects/<slug>/`（6/29 起，独立目录，当前 9 个项目）
2. `<project>/03_video/hyperframes/`（6/13-6/28 内嵌期）
3. `~/automedia/<项目名>/03_video/hyperframes/`（6/25 前后过渡期）

---

## 三、工作流（全链路）

### 3.1 每日自动化采集链（cron，9 个 job 全部 enabled）

| 时间 | Job | 职责 |
|---|---|---|
| 07:30 | 新鲜度维护 | `freshness_maintenance.py`（event_date 衰减，Layer 3 旧闻拦截） |
| 08:00 | 热点采集 | `auto_media_hot_collection_v3_20260525.py`（微博/知乎/抖音/B站，LLM 去重 BATCH=10, Layer2 BATCH=40） |
| 08:05 | 语义审核 + 黑名单 | Layer 3 语义过滤 + Domain 黑名单更新 |
| 08:10 | 角度分判定 | `judge_topics_angle.py`（8:30 推送前） |
| 08:30 | 话题池汇总推送 | LLM agent 推送，双锁模式 + session_lock |
| 09:30 | Watchdog 健康检查 | cron 巡检 + `wdog_auto_retry.py` 漏采告警 |
| 12:00 / 16:00 | 角度分兜底 | 清历史 NULL + 新进库话题补判 |
| 23:00 | Daily dashboard | `auto_media_dashboard.py` |

漏采补偿：`catchup_collection.py`（0 入库日检测 + 池子预告话题跟进 + 通用实体扫描 → `--apply N` 转正入池）。

### 3.2 视频生产链路（HyperFrames）

```
话题确认（用户选择）
  ↓  G0.5 生产前双重检查（话题去重 + 项目初始化完整性）
automedia 文案链路
  short-video-script → humanizer → copy-review → brand-cta（G1）
  ↓
outline.md（内容规划 + Info Pool）
  ↓  G0 Checkpoint Plan（脚本/outline/主题/素材/开发模式 6 项对齐）
选主题（theme-palettes.json 36 主题 / od-themes.json 8 品牌主题）→ Gate VQ
  ↓
TTS 音频（tts_produce.py 唯一入口，edge-tts 品牌声音）→ 时长测量 → 场景帧边界
  ↓
选场景模式（scene-patterns.md：5段/3段/3段/4段 按视频类型）
  ↓
写 index.html（根 composition + 音频轨道）
  ↓
写 compositions/scene-*.html（每场景一子 composition，手动设计，禁止自动生成）
  ↓  G2 用户接受 Ch1（首个场景效果确认）
bun x hyperframes lint（G3）→ render --quality draft → render standard（两阶段渲染门控）
  ↓
post-render QA（G4：时长验证 + 视觉审查 + 反 AI 指纹 + 场景-旁白覆盖）
  ↓
delivery（G5）→ pipeline_post_production.py（公众号上传 + 博客 MDX + 状态更新）
```

### 3.3 管线演进时间线

| 时间 | 事件 |
|---|---|
| 5/11 → 6/9 | Remotion 为主力视频管线 |
| 6/10 | Remotion skill 归档（不再推荐） |
| 6/13 | HyperFrames 启用（首个项目：豆包AI误导、Perplexity哈佛） |
| 6/13 → 6/28 | HyperFrames 内嵌 project/03_video/hyperframes/ |
| 6/29 | 独立目录 ~/HyperFrames-Projects/ 启用 |
| 6/30 | 两阶段渲染（Draft → Standard）门控固化 |

---

## 四、Gate 门控体系（25 个强制 Gate）

### 三层自强化架构（V13，2026-06-25）

```
层1: TODO 工具（纪律层）   → 每段开工前列 7-10 步 TODO，逐项标记
层2: Shell Hook（拦截层）  → pre_render_hook.sh 自动拦截未签入 Gate 的 render
层3: Audit（检测层）       → audit_pipeline.py 扫描 16 项 Gate 产物，缺口暴露
```

### Gate 全景

| 组 | Gate | 职责 | 硬化级别 |
|---|---|---|---|
| 生产前 | **G0.5** | 话题去重查重 + 项目初始化完整性（init_project.py 唯一入口） | L2 脚本 |
| 文案前 3 | **R0** Research | 查 source_url → web_extract 原文 → sources.json | L3 doc |
| | **PT** Template | 话题类型判定 → content-prompt-templates 选模板 | L3 doc |
| | **PD** Platform | 5 平台差异化写稿方向 | L3 doc |
| 文案 9 | **PQ** Prompt Quality | check_prompt_quality.py | L2 脚本 |
| | **AF** AI Flavor | check_output_ai_flavor.py（9 类 AI 模式） | L2 脚本 |
| | **C0** Fact Check | 5 步自动化事实核查（数字/日期/引文/实体） | L3 doc |
| | **C1** Humanizer | 去 AI 味 | L3 doc |
| | **C2** Copy Review | 五轮结构审查 | L3 doc |
| | **C3** Brand CTA | 零容忍项：品牌身份/CTA/禁止词/多平台同步/小红书标签 | L3 doc |
| | **C3.5** 脚本结构 | tiktok/bilibili script 必含品牌 CTA 段 | L1（并入 tts_produce.py） |
| | **C4/G5** Wechat | 标题 ≤9 字 / digest ≤20 字 / HTML 硬门控 | L2 脚本 |
| | **II** Inline Image | 公众号 ≥3 / 知乎 ≥2 / 小红书 ≥1，>5KB | L2 脚本 |
| | **B0** 博客 | 业务款 → auto_blog_publish.py MDX（非阻塞） | L2 脚本 |
| 视频 11 | **VQ** Design Quality | 选主题 + 定布局 + 多样性（5 段 ≥4 布局、easing ≥2、CSS 变量 ≥6） | L2 脚本 validate_layout.py |
| | **V0** Lint | hyperframes lint 0 errors | L1 代码拦 |
| | **V6** Composition QA | check_composition_qa.py：字号 ≥20px / top ≥300 / ≤1620 / 无重复 class / CSS 格式 | L1（Hook 自动） |
| | **V4** TTS 声音资产 | 品牌 voice 核验（YunjianNeural 锁定） | L1（tts_produce.py 内） |
| | **V4.5** TTS 输入品牌 | 输入文本必含「壹目贯维」≥1 | L1（tts_produce.py 内） |
| | **V5** mp3 vs SRT | Whisper 转写 diff，容忍 ASR ±20% | L1（verify_mp3_vs_srt.py） |
| | **V1** Vision QA | 逐 Entry 帧级视觉审查 | L3 doc |
| | **V2** Pre-send Whisper | 全音频验证 + MD5 追踪 | L1 脚本 |
| | **V3** Content Match | SRT + 转写 + OCR 比对 topic 关键词 | L3 doc |
| | **V6.5** 字幕实际渲染 | PIL 像素亮度法验证字幕区域（8 帧） | L2 脚本 |
| 生命周期 3 | **L1-L3** | 项目生命周期 / 新鲜度 / 归档 | L3 doc |

### 硬化方法论（2026-06-24 固化）

> 事故根因模式：doc 写了「强制/自动」，agent 跳过 = 0。修复不是再写一行 doc，而是把 Gate 变成独立脚本 + exit code。
> 级别：**L1 代码拦**（exit code 硬阻断，如 tts_produce.py / hyperframes lint / pre_render_hook）→ **L2 脚本可调**（validate_layout / upload_draft）→ **L3 doc 依赖**（靠 agent 自觉）。持续硬化目标：L3 → L2 → L1。

---

## 五、Skills 体系

### 视频生产核心
| Skill | 版本 | 职责 |
|---|---|---|
| `video-production/hyperframes-workflow` | 当前主力 | HTML+GSAP→MP4 全链路 + Gate 链 G0-G5 + 36 主题 + 场景模式 + 两阶段渲染 |
| `productivity/automedia-production-guard` | v1.9 | 25 Gate 总纲 + 三层自强化 + 硬化方法论（82 个 references） |
| `productivity/automedia` | v1.10 | 热点采集/选题/文案链路 + Pre-production 强制门 + 打包完整性检查 |
| `productivity/subtitle-production` | — | 字幕 SRT 生产与烧录全流程（TTS 音频 → SRT → 烧录） |
| `productivity/subtitle-srt-generation` | — | SRT 生成标准工作流（Whisper 验证与重校准） |
| `whisper-postprocess` | — | Whisper 转写后处理（断句/标点） |
| `media/video-redo` | — | 视频重做触发规范（问题层判断 + 精准修复，禁止重建） |

### 文案链路（视频脚本上游）
| Skill | 职责 |
|---|---|
| `short-video-script` | 短视频脚本框架（开场钩子/5 段式/平台差异/B2B 优化） |
| `humanizer` | 9 类 AI 写作模式消除 |
| `copy-review` | 五轮中文 B2B 内容审查 |
| `brand-cta-review` | 品牌 CTA 零容忍审核 |
| `content-generation-prompt` | 注入块 + 人设 + 范例的 prompt 工程（平台字数硬限） |
| `content-prompt-templates` | 4 种话题类型差异化框架 |
| `platform-differentiation` | 5 平台内容适配原则 |
| `automedia-research` / `automedia-fact-check` | R0 调研 / C0 事实核查 |

### 生产基建
| Skill | 职责 |
|---|---|
| `automedia-project-init` | init_project.py 唯一入口 |
| `automedia-topic-pool` | 话题池采集评分（三层过滤漏斗） |
| `wechat-official-account-publisher` | 公众号草稿上传（upload_draft.py） |
| `wechat-upload-checklist` | 公众号上传前安全检查清单 |
| `xiaohongshu-publisher` / `douyin-publisher` / `multi-platform-publisher` | 多平台发布 |
| `publish-log-schema` | publish_log.json v2.1 |
| `delivery-packaging` | 交付 zip 完整性检查 |
| `cron-watchdog` | cron 健康巡检标准工作流 |
| `brand/yimuguanwei-persona` | 品牌人设（所有对外内容生产前必加载） |

### 归档（历史方案）
| Skill | 说明 |
|---|---|
| `archived/remotion-workflow` / `remotion` | 6/10 归档，不再推荐 |
| `archived/remotion/tts-voice-asset` | TTS 声音品牌资产库（YunjianNeural 锁定依据） |
| `archived/automedia-m3-upgrade` | 旧 M3 迁移记录 |

---

## 六、关键脚本 / 硬化机制

### 唯一入口（exit code 强制）
| 脚本 | 位置 | 功能 |
|---|---|---|
| `tts_produce.py` | ~/.hermes/profiles/content/scripts/ | TTS 唯一入口：C3.5 → V4.5 → 生成 → V4 Whisper 验证，exit 0/1 |
| `pipeline_post_production.py` | 同上 | 管线出口：公众号上传 + 博客 MDX + 状态更新 |
| `pre_render_hook.sh` | 同上 | Shell Hook：拦截缺 Gate 的 hyperframes render，V6 缺失自动跑 |
| `signoff_gate.sh` | 同上 | Gate 签入写入 .gates_status.json |
| `audit_pipeline.py` | 同上 | 16 项 Gate 产物扫描 |

### Gate 检查脚本
`check_composition_qa.py`（V6）/ `check_output_ai_flavor.py`（AF）/ `check_prompt_quality.py`（PQ）/ `check_production_init.py`（G0.5 自动修复）/ `validate_layout.py`（VQ）/ `verify_mp3_vs_srt.py`（V5）/ `gen_inline_images.py`（II 配图）/ `gen_ui_images.py`（UI 图）/ `burn_subtitles.py`（烧录）

### 采集与维护
`auto_media_hot_collection_v3_20260525.py`（三副本 + md5sum）/ `catchup_collection.py`（漏采补偿）/ `freshness_maintenance.py` / `judge_topics_angle.py` / `pool_sync.py` / `wdog_auto_retry.py` / `auto_blog_publish.py`

---

## 七、项目现状

- **AutoMedia 工作区项目**：67 个（registry 自动生成于 Scripts/regen_project_registry.py）
- **独立 HyperFrames 项目**：9 个（ai-model-profit-test、automedia-v1-launch、deepseek-bill-crisis、deepseek-dspark、fable-export-control、runway-ad-localization、seedance-25、shengshu-vidu-s1-realtime、zuckerberg-ai-agent-slow）
- **主题库**：theme-palettes.json 36 主题 + od-themes.json 8 品牌主题
- **Cron**：9 个 AutoMedia job 全部 enabled

---

## 八、质量底线（用户强制固化）

1. **Token 不是约束，时间才是；出错重做才是最大成本** — 全量 QA 消耗 10 倍 token 也接受
2. **所有质量门控不能偷懒** — 自推广/内部话题不豁免（G0-G3 完整走）
3. **报告里出现「⚠️ 本轮没做」= 必做项缺失**，绝不允许发含占位符的中间态
4. **做错比做慢更浪费信任** — 不接受「先快速出版本再补 Gate」
5. **已交付项目不改进铁律** — 交付后冻结，除非用户明确要求
6. **备份优先铁律** — 脚本修改前必备份（.bak 带时间戳）
