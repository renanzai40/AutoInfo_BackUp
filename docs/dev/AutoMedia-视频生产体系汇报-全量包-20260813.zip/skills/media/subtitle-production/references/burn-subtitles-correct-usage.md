# burn_subtitles.py 正确调用方式（2026-05-17 重大更新）

### burn_subtitles.py 正确调用方式（2026-05-17 重大更新）

**Python 解释器**：必须用 hermes-agent venv
`/home/renanzai/.hermes/hermes-agent/venv/bin/python3`
**禁止**：mamba ffmpeg env 的 Python（3.14，无 PIL）

**FFmpeg 路径**：`/home/renanzai/mamba/envs/ffmpeg/bin/ffmpeg`（不在 PATH，必须显式）
**FFprobe 路径**：`/home/renanzai/bin/ffprobe`

**调用方式（2026-05-17 新版）**：

```bash
PYPIL=/home/renanzai/.hermes/hermes-agent/venv/bin/python3
BURN=/home/renanzai/.hermes/skills/media/subtitle-production/scripts/burn_subtitles.py

$PYPIL $BURN \
  video_raw.mp4 \
  audio_voiceover.mp3 \
  subtitle.srt \
  output_final.mp4 \
  62.7 \
  --title "为什么你总错过AI红利"
```

| 位置参数 | 说明 |
|---------|------|
| 1 | 输入视频（含音频，concat后的裸视频） |
| 2 | TTS 音频文件 |
| 3 | SRT 字幕文件 |
| 4 | 输出路径 |
| 5（可选） | safe_upper（秒），超过此值则 seek clamp 到该值 |
| `--title`（可选） | 视频大标题（黄色黑边，全片持续显示） |

**新增功能（2026-05-17）**：

1. **自动 gap fill**：SRT entries 之间有 >150ms 间隙时，自动插入 hold-frame（取当前 entry 末尾帧作背景的静止画面），确保 concat 视频时长 ≈ 音频时长。不再出现"视频比音频短几秒"的问题。

2. **视频大标题**：`--title "文本"` 参数在画面上1/3处渲染黄色大标题，全片持续显示。

3. **口播字幕位置**：MarginV = H/6 = 320px（底部偏上离边缘1/6），不再是固定120px。

**已知错误写法（永久禁止）**：
- `--srt /path/to/srt` → `unrecognized arguments: --srt`
- `--segs-json` → 旧版参数，新版已移除
- `--font-size` / `--margin-v` → 硬编码，不可外部覆盖

---
