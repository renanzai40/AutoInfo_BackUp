# 策略 A：逐条 TTS（推荐，碎片率低）

### 策略 A：逐条 TTS（推荐，碎片率低）

每个 script entry 独立生成一段 TTS 音频，用 MiniMax TTS 分别生成 6 个独立的 wav 文件。Whisper 在**各自音频**上跑，得到干净的 6 组时间轴。然后拼接音频 + 合并 SRT。

**优势**：Whisper 不受其他 entry 干扰，碎片少，时间轴精准
**适合**：entry 之间有明显语义断点的情况

```python
# 逐条 TTS → 各自 Whisper → 拼接
entries = [
    "小米刚发布的MiMo，性能直接登顶全球开源榜。",
    "但问题是——这些大模型，普通人在哪儿能用上？",
    ...
]
for i, text in enumerate(entries):
    # TTS 生成 audio_i.wav
    # Whisper 跑 audio_i.wav → whisper_i.json
    # 提取时间轴，生成 entry_i.srt
# 拼接音频：ffmpeg -i "concat:a1.wav|a2.wav|..." -c:a copy audio_concat.wav
```
