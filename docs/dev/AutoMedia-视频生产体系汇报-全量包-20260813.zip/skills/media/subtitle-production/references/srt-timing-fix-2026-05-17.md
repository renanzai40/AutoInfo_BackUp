# SRT时间戳分配算法修正记录 (2026-05-17)

## 问题现象

**引流款**（特朗普访华）：用户反馈"音画不同步"——听到的语音和看到的字幕文字不匹配。

## 根因分析

早期版本用「Whisper总时长 ÷ 脚本句子数」估算每句话时长，生成均匀分割的SRT时间轴：

```python
# ❌ 错误做法：总时长均分
total_dur = 62.6  # Whisper最后segment end
n_sent = 10        # 脚本句子数
avg_dur = total_dur / n_sent  # 6.26s/句

# 第1句起止：[0.00, 6.26]
# 实际Whisper对应：[0.00, 8.08]  ← 差2秒！
```

42个Whisper segments 均分给10个脚本句子：`segs_per_sent = 42/10 = 4.2`

问题：Whisper每段实际长度4-8秒不等，均分导致时间轴系统性偏移。

## 修复方案

改用「Whisper真实segment区间映射」：

```python
# ✅ 正确做法：Whisper segment区间直接作为entry时间戳
segs_per_sent = n_seg / n_sent  # 4.2，仍用于确定区间范围

for i, sent in enumerate(sentences):
    start_idx = int(i * segs_per_sent)
    end_idx   = int((i + 1) * segs_per_sent)
    if i == n_sent - 1:
        end_idx = n_seg  # 最后一个句子取到末尾
    
    start = segments[start_idx]['start']    # ← 直接用真实Whisper值
    end   = segments[end_idx - 1]['end']    # ← 直接用真实Whisper值
    text  = sent                             # ← MiniMax脚本原文
```

验证结果（引流款）：
| 时间点 | 旧版字幕（错误） | 新版字幕（正确） |
|--------|-----------------|-----------------|
| t=1s | `2535亿美元，签完了——但你知道这2535亿里...` ✅ | `2535亿美元，签完了——但你知道这2535亿里，有多少是真正能落地的吗？` ✅ |
| t=17s | `特朗普访华期间...` ✅ | `特朗普访华期间，全网都在刷2535亿大单。` ✅ |

## 为什么这次算法错误没被发现

burn_subtitles.py 用FPS=2抽帧，`t = (frame_num-1)/2.0` 计算时间。当帧落在错误区间的重叠部分时，VLM会看到看起来合理的字幕，导致QA通过但实际不对齐。

## 修复后的验证矩阵（2026-05-17）

**引流款**：16 entries，max_chars=43
**业务款**：15 entries，max_chars=45

三帧QA全部通过：
- t=1s：✅ 字幕行≤3，无乱码，与脚本一致
- t=中段：✅ 字幕行≤3，与脚本一致
- t=末尾前5s：✅ 品牌名"壹目贯维"正确出现

## 关键教训

1. **Whisper segment是时间真相**：任何估算时间轴的方法（字数÷语速、总时长均分）都会产生系统性偏差
2. **脚本句子数和Whisper segment数通常不成比例**：TTS把一句完整的话切成多个Whisper segments（逗号/停顿时），反之亦然
3. **帧抽验有盲区**：当时间轴整体偏移但相邻entry有重叠时，帧截图可能显示"看起来对"的内容，实际已错位

## 预防措施

每次SRT生成后，打印所有entry的时间戳+首句文字，自查：
```python
for i, (start, end, text) in enumerate(entries):
    print(f"  [{start:.2f}-{end:.2f}] {text[:40]}")
    assert end > start, f"entry {i}: end <= start!"
    assert end - start < 15, f"entry {i}: duration > 15s，疑似时间轴错误"
```