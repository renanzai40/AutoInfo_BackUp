# burn_subtitles.py 重大修复记录（2026-05-17）

## 问题：concat 后视频时长 << 音频时长

**症状**：
- AI-era 项目：音频 64.008s，concat 后视频 55.1s（差 8.9s）
- Trump 项目：音频 62.748s，concat 后视频 62.23s（差 0.5s）

**根因**：SRT entries 之间有大量 300-600ms 的静音间隙。
Whisper ASR 在句子间有自然停顿（如"结果呢"之后 0.4s，"时机过去了"之后 0.2s）。
concat 时每段视频时长 = entry 时长（end-start），不填 gap → 总时长 << 音频时长。

AI-era 项目 27 个 entries，间隙总和 8.8s → 最终视频比音频短 8.8s。
Trump 项目 42 个 entries，仅一个 0.32s gap → 最终视频差 0.5s（基本正常）。

**错误假设**：以为 concat 视频时长 ≈ Σ(entry_durations)。实际上 Σ(entry_durations) 不等于音频时长，因为 Whisper 的 start 不从 0 开始且 entries 之间有 gap。

## 修复：自动 gap-fill 插入 hold-frame

burn_subtitles.py 在 concat 前遍历 SRT entries，对每一对相邻 entry：
- 计算 gap = entries[i+1][0] - entries[i][1]
- 如果 gap > 150ms：提取当前 entry 末尾帧 + 持续 gap 时长的静止画面段，插入 seg 列表

```python
all_segs = []
for idx, (start, end, text) in enumerate(entries):
    all_segs.append(seg_files[idx])   # 主字幕段
    if idx < len(entries) - 1:
        gap = entries[idx + 1][0] - end
        if gap > 0.15:
            # 取末尾帧作背景，插入 gap 时长的静止画面
            frame_to_video(hold_frame_jpg, gap, black_seg)
            all_segs.append(black_seg)
```

**效果**（AI-era 重做）：
- 27 entries → 53 segments（含 26 个 gap hold frames）
- concat 后视频 63.6s ≈ 音频 64.008s ✅

## 其他修复（同步）

### 1. 口播字幕新位置（MarginV = H/6）
用户要求：口播字幕固定在画面底部偏上，离最底端 1/6 画面高度。
- 旧值：MarginV = 120px（固定）
- 新值：MarginV = int(H/6) = 320px（1080x1920）

### 2. 视频大标题（--title 参数）
用户要求：视频开头有大标题（黄色黑边，位于画面上1/3处）
- 字号：72pt，颜色 #FFD700，描边黑色
- 位置：Y = H/3 ≈ 640px（画面上1/3处）
- 全片持续显示，不随字幕切换

### 3. safe_upper 参数改用数字判断
旧版：`safe_upper = float(sys.argv[5]) if len(sys.argv) > 5 else None`
问题是第5个参数可能是 `--title`（字符串）导致 ValueError

新版：
```python
_idx = 5
safe_upper = None
if len(sys.argv) > _idx:
    if sys.argv[_idx].replace('.','',1).isdigit():
        safe_upper = float(sys.argv[_idx])
        _idx += 1
if '--title' in sys.argv:
    ti = sys.argv.index('--title')
    title_text = sys.argv[ti+1]
```

## 验证方法

```bash
# 检查视频时长是否 ≈ 音频时长（误差 < 1s）
ffprobe -v quiet -show_entries format=duration -of csv=p=0 output.mp4
# 63.600000

ffprobe -v quiet -show_entries format=duration -of csv=p=0 audio_voiceover.mp3
# 64.008000

# 误差 0.408s < 1s ✅
```

## 教训

1. **SRT entries 之和 ≠ 音频时长**：Whisper 输出的 segments 有静音间隙，必须 gap-fill
2. **合并音频前必须验证 concat 视频时长**：ffprobe sub_video.mp4 时长 ≈ 音频时长才能继续
3. **gap-fill 用 hold-frame 不用黑帧**：黑帧会造成视觉跳动感，用最后一句的画面作背景更连贯