# burn_subtitles.py Bug Fix Record (2026-05-16)

## Bug 1: ffprobe 不在 PATH，get_dur() 返回空字符串

**文件**：`scripts/burn_subtitles.py`

**原代码**：
```python
def get_dur(path):
    r = subprocess.run([FFMPEG, '-v','error','-show_entries','format=duration','-of','csv=p=0',path],
        capture_output=True, text=True)
    return float(r.stdout.strip())  # FFMPEG 不是 ffprobe，stdout 被 DEVNULL 截断 → ValueError
```

**问题**：
- 调用的是 `FFMPEG` 变量（指向 ffmpeg 二进制），不是 ffprobe
- 即使指向 ffprobe，stdout 也被 DEVNULL 重定向截断
- 实际表现：`ValueError: could not convert string to float: ''`

**修复后**：
```python
FFPROBE = "/home/renanzai/bin/ffprobe"  # 显式绝对路径

def get_dur(path):
    try:
        r = subprocess.run(
            [FFPROBE, '-v', 'quiet', '-show_entries', 'format=duration', '-of', 'csv=p=0', path],
            capture_output=True, text=True, timeout=10
        )
        val = r.stdout.strip()
        if val:
            return float(val)
    except Exception:
        pass
    return None
```

---

## Bug 2: extract_frame seek 超界导致空帧

**原代码**：
```python
def extract_frame(path, ts, out):
    subprocess.run([...'-ss', str(ts), ...])  # ts 可能超出视频实际范围 → 空文件
```

**问题**：
- concat 生成的 raw 视频，ffprobe 报 54.5s，但实际最后一帧在 ~53.9s
- seek 到 53.9s+ 时 ffmpeg 返回空帧（"nothing was encoded"）
- 空帧传给 PIL → `FileNotFoundError`
- burn_subtitles.py 静默失败（DEVNULL 吞掉了错误）

**修复**：新增 `safe_upper` 参数 + `safe_seek_ts()` + fallback 到 `sseof -0.2`

```python
def safe_seek_ts(raw_ts, safe_upper):
    return min(raw_ts, safe_upper - 0.05)

def extract_frame(path, ts, out, safe_upper=None):
    vid_dur = get_dur(path)
    upper = safe_upper if safe_upper is not None else (vid_dur if vid_dur else float('inf'))
    ts = safe_seek_ts(ts, upper)
    r = subprocess.run([...'-ss', str(ts), ...])
    if r.returncode != 0 or os.path.getsize(out) < 1000:
        # fallback: 取视频末尾前 0.2s 的帧
        fallback_ts = (vid_dur - 0.2) if vid_dur else 0.1
        subprocess.run([...'-sseof', '-0.2', ...])
```

**调用方式**：
```bash
# safe_upper 实测值
$PYPIL $BURN video.mp4 audio.wav srt output.mp4 53.9   # 引流款 raw 视频
$PYPIL $BURN video.mp4 audio.wav srt output.mp4 35.0   # 业务款 raw 视频
```

---

## Bug 3: main() 无 safe_upper 参数传递

**原代码**：
```python
# 只接收 4 个位置参数，safe_upper 根本没有
video, audio, srt, output = sys.argv[1:5]
```

**修复**：新增第 5 个可选参数
```python
video, audio, srt, output = sys.argv[1:5]
safe_upper = float(sys.argv[5]) if len(sys.argv) > 5 else None
# 传递给 extract_frame
extract_frame(video, mid, bg, safe_upper=safe_upper)
```

---

## 验证方法

```bash
# 1. 验证 ffprobe 路径可用
/home/renanzai/bin/ffprobe -v quiet -show_entries format=duration -of csv=p=0 audio.wav

# 2. 验证 safe_upper 有效（不返回空帧）
ffmpeg -y -ss 53.9 -i raw_video.mp4 -vframes 1 /tmp/test.jpg
# 确认输出有文件大小（非 0）

# 3. 验证脚本语法
/home/renanzai/.hermes/hermes-agent/venv/bin/python3 -m py_compile burn_subtitles.py
```
