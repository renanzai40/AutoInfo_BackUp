# Gotchas（高频踩坑，高价值必读）

## Gotchas（高频踩坑，高价值必读）

### ⚠️ burn_subtitles.py re-encode 输出时长错误（2026-05-19 致命）

**症状**：音频 36s → burn_subtitles.py 输出 59.5s → 用户听到"30s 后还有噪音"

**根因**：`re-encode` 步骤使用 `-shortest` 约束输出时长，但 `-shortest` 对图像序列源视频 + 音频的合并行为不符合预期

**已 patch**（`scripts/burn_subtitles.py` Line 313）：
```python
# 替换：
# 旧："-shortest",
# 新：
"-frames:v", str(len(frames)),  # 强制精确帧数
```

### ⚠️ FFmpeg concat demuxer 对图片序列时长不精确（2026-05-19）

**症状**：`duration 4.5` 声明 4.5s，实际 4.0s

**解法**：concat filter + 每段显式 `-t` 时长，不要用 concat demuxer

### ⚠️ ASS Dialogue Text 字段索引是 8 不是 9

**症状**：ASS 解析时 text 字段为空，所有字幕内容丢失

```python
# 错误：
parts = line[9:].split(',', 8)
text = parts[9]   # IndexError 或空

# 正确：
parts = line[9:].split(',', 8)
text = parts[8]   # 索引8=Text字段（9个字段0-8）
```

`burn_subtitles.py` 用 segments JSON 直接渲染，不走 ASS 解析，不受此 bug 影响。

### ⚠️ ASS `\N` 换行导致格式字段混入字幕（2026-05-19 实测）



### ⚠️ Vision QA 不可靠——必须像素级验证（2026-05-19 实测）

详见：`references/ass-subtitle-bugs-2026-05-19.md`

### ⚠️ FFmpeg 图片拼接——TS Concat 是唯一可靠方案（2026-05-19）

详见：`references/video-concat-correct-2026-05-19.md`

concat demuxer 和 concat filter 对单帧图片序列都会产生时长错误。正确方案：MPEG-TS 分段 + concat protocol。

### ⚠️ burn_subtitles.py fps 参数 bug（2026-05-19 已修复）

详见：`references/ass-subtitle-bugs-2026-05-19.md`

### ⚠️ 多行字幕 Entry 导致 Vision QA 失败（2026-05-15 新增）

**症状**：PIL 烧录后 Vision QA 发现某些帧字幕 3-4 行叠加（如 E6 五行、E7 四行同时显示），画面底部堆满文字。

**根因**：SRT Entry 内含多行文字（每行独立一句），PIL 把整个 entry 作为整体渲染，视觉上多行叠加。45字/entry 限制对多行场景无效。

**正确做法**：**每 Entry 只含一行文字**，即每个 SRT entry = 一句完整语音。

**操作方法**：在生成 SRT 时，把含多行的 entry 按语义拆成独立的单行 entry，时间轴按比例分配：
```
# 原始 E6（含5行，5句）：
Entry 6: 33.80-40.80s, "这就是工具升级的意义——/一个人的团队，/能干以前二三十人的活。/不是更拼命，/是找对了工具。"

# 拆成5个独立Entry：
Entry 16: 33.80-35.20s, "这就是工具升级的意义——"
Entry 17: 35.20-36.60s, "一个人的团队，"
Entry 18: 36.60-38.00s, "能干以前二三十人的活。"
Entry 19: 38.00-39.40s, "不是更拼命，"
Entry 20: 39.40-40.80s, "是找对了工具。"
```
时间分配：总时长 / 行数 = 每行时长。

**验证**：烧录后对 t=1s / 中段 / 末尾三帧做 Vision QA，字幕行数必须 ≤ 2（1行最佳）。

### ⚠️ 重建 vs 精准修复：永远只修出问题的那一层（2026-05-15 新增）

**症状**：脚本/SRT 有问题 → 重建视频资产 → 新问题引入 → 连续重做多轮。百度一镜案例：v1 SRT 多行 entry → 重建视频 → img 重生成 → 重新拼接 → PIL bug → 修了 4 轮。

**根因**：把"修复脚本问题"和"重建视频资产"混为一谈，用最大暴力手段修复只需要精准手术的问题。

**正确原则**：
```
问题在哪层 → 只修那一层
SRT 文字/时间轴错 → 重建 SRT → PIL 重新烧录（视频/音频/图片 零重建）
图片有乱码/敏感素材 → 重新生成该张图片 → 重新拼接（音频/其他图片/SRT 不动）
视频时长差 > 1s → 重建视频资产
```

**禁止行为**：
- ❌ SRT 有问题 → 重新生成图片
- ❌ 图片有问题 → 重新 TTS
- ❌ 脚本有错 → 重新 Whisper（时间轴本身没错的话）

**验证**：修复后只验证被修改的那层。比如修了 SRT → 只验证字幕行数和时间轴；图片重生成 → 只验证该张图片的 Vision QA。

**症状**：`execute_code` 内 subprocess 调用 ffmpeg 报错 `FileNotFoundError: [Errno 2] No such file or directory: 'ffmpeg'`。

**根因**：`execute_code` 的 Python sandbox 没有继承 WSL 的 PATH 环境变量，ffmpeg 不在默认搜索路径中。

**解法**：烧录等需要 FFmpeg 的步骤，必须用 `terminal` 工具执行（terminal 有完整 PATH）。`execute_code` 只用于纯 Python 计算（解析 SRT、计算时间戳、PIL 绘图等）。

### ⚠️ 字体路径（2026-05-15 确认）

WSL 正确路径：`/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc`

常见错误路径：`/usr/share/fonts/truetype/wenquanyi/WenQuanYiZenHei.ttf`（不存在）

**v9 教训**：Whisper 跑在旧音频（74.5s），视频用新音频（59.7s），字幕时间轴和音频完全错位。
解法：音频是唯一真相，所有步骤用同一份文件。

**v10 教训**：SRT 文本直接用 Whisper ASR，"只能"而非"智能"。
解法：文本 = MiniMax 脚本，Whisper 只取时间戳。

**v11 教训**：Entry 8 凭感觉拆成三段，但语音和字幕不一致（8a 结束 44.6s 但语音到 45.2s 才完）。
解法：amplitude scan 找静音断点，不得凭感觉估算。

**burn_subtitles.py 输出时长误判**：ffprobe 报 64.5s，实际 59.7s。
解法：用 `frame=` 行中的 `time=` 值验证，截断到精确音频时长。

> ⚠️ **2026-05-16 新增**：Human Eye QA 是提交前的强制检查节点，不是可选项。"技术合格"但"人眼不合格" = 不合格。

### ⚠️ burn_subtitles.py draw() 的 textbbox 陷阱（2026-05-16 新增）

**症状**：字幕烧录后 Vision QA 找不到字幕——画面底部一片空白，没有任何文字。

**根因**：`PIL.ImageDraw.textbbox()` 返回 `(x0, y0, x1, y1)`：

| 字段 | 含义 | 示例值 |
|------|------|--------|
| `x0` | 文本左边界 | -1 |
| `y0` | 文本顶部（baseline 以上的 ascent） | 6 |
| `x1` | 文本右边界 | 330 |
| `y1` | **文本 descent（baseline 以下）**，不是高度 | **62** |

**错误代码**：
```python
dims = [(draw.textbbox((0,0), l, font=font)[2], draw.textbbox((0,0), l, font=font)[3]) for l in lines]
# dims[i] = (x1, y1) = (330, 62) — 把 descent 当高度！
total_h = sum(d[1] for d in dims)  # total_h = 62，但实际文本高度 = 62-6 = 56
```

**后果**：`total_h` 被严重低估，导致 `y = H - MarginV - total_h` 计算出的字幕 Y 坐标超出画面范围，文字被画到 1920 以外，完全不可见。

**正确代码**：
```python
dims = [draw.textbbox((0,0), l, font=font) for l in lines]
total_h = sum(d[3] - d[1] for d in dims)  # height = y1 - y0
y = H - MARGIN_V - total_h
for i, (line, bbox) in enumerate(zip(lines, dims)):
    x0, y0, x1, y1 = bbox
    lw, lh = x1 - x0, y1 - y0
    x = (W - lw) // 2
    y_cur = y + sum((dims[j][3] - dims[j][1]) + 8 for j in range(i))
    for dx in [-1,1]:
        for dy in [-1,1]:
            draw.text((x+dx, y_cur+dy), line, font=font, fill=(0,0,0))
    draw.text((x, y_cur), line, font=font, fill=(255,255,255))
```

### ⚠️ drawtext 换行符转义：\\\\n 会导致换行失效（2026-06-19 实测）

**根因**：Python 字符串 `'\\\\n'` 在 drawtext filter 中产生 `\\n`（双反斜杠+n），不是换行。
drawtext 需要 `\\n`（单反斜杠+n）才识别为换行。

```python
# ❌ 错误：换行符不可见
txt.replace('\\n', '\\\\n')  # Python 代码中意味着 '\\\\\\\\n' 但等价的写法
# 实际效果：drawtext 收到 \\n → 渲染为两个字符反斜杠+n，不是换行

# ✅ 正确：drawtext 收到 \n → 换行
txt.replace('\\n', '\\n')
```

**验证方法**：FFmpeg 日志搜索 `Parsed_drawtext_`，如果看到 `text='...\\n...'`（双反斜杠），换行失效。
如果看到 `text='...\n...'`（单反斜杠），换行生效。

**修复检查**：`grep "replace.*\\\\n" burn_subtitles.py` → 确认是 `'\\n'` 结尾（1反斜杠+n），不是 `'\\\\n'`（2反斜杠+n）。

### ⚠️ 字幕重烧必须用无字幕原片（2026-06-19 实测）

**根因**：第二次烧录时用了已烧过字幕的 `video_final.mp4` 作为输入源 → 新字幕叠加在旧字幕上 → 双层重叠。

**正确流程**：
```
HyperFrames render → out/video.mp4 → cp 到 03_video/video_clean.mp4（保留无字幕原片）
  → 所有重烧字幕从 video_clean.mp4 取源
  → 输出到 video_subbed.mp4 → cp 到 video_final.mp4
```

**永远不要在已烧过字幕的文件上再烧一遍字幕。**

**症状**：字幕位置完全错误，Vision QA 找不到字幕。

**根因**：`ffmpeg -loop 1 -i cover.png` 如果封面图尺寸不是 1080×1920 且无 scale+pad 滤镜，raw 视频会保持原图尺寸（720×1280）。burn_subtitles.py 硬编码 W=1080/H=1920，导致 PIL 坐标全错。

**正确做法**：
```bash
ffmpeg -y -loop 1 -i cover.png \
  -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2" \
  -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p -r 30 \
  -c:a aac -b:a 192k -t 音频时长 \
  raw_video.mp4

# 验证
ffprobe -v quiet -show_streams raw_video.mp4 | grep -E "width=|height="
# 必须 width=1080 / height=1920
```

### ⚠️ Vision QA 发现"字幕在中间"——可能是视频资产层问题（2026-05-16 新增）

**现象**：Vision QA 发现画面中间有大字/标题文字，底部也有小字幕。

**判断标准**：
- 底部小字 = 字幕烧录层（正确）
- 中间大字 = **视频资产层的问题**（封面图/帧图本身就带文字）
  - 封面图里写了 "AI"、"涉诈APP" 等文字 → 违反"禁止文字"规范
  - 帧图里嵌入了巨大的标题文字 → 帧图设计问题

**正确的修复路径**：
```
Vision QA 发现中间有大字
  → 检查封面图/帧图是否有文字
  → 是 → 视频资产层问题 → 重新生成图片（无文字）→ 重新拼接
  → 否 → 检查帧图是否有文字嵌入
```

**禁止**：因为中间有大字就怪字幕烧录、重新做 SRT、重新 TTS。问题在图片层，不在字幕层。

### ⚠️ GAP Hold Frame 必须画大标题——Flicker Bug（2026-05-17）

GAP hold frame 必须同时调用 `draw_subtitle()` + `draw_title()`。只画口播字幕而漏画大标题 → 标题在静音间隙帧消失 → 人眼看到"闪烁"。详见 `references/burn-subtitles-title-flicker-fix-2026-05-17.md`。

### ⚠️ Vision QA 文件 = 发送文件（2026-05-16 新增）

**症状**：`/tmp` 里堆了 `video1_final.mp4`、`video1_final_v4.mp4`、`video1_v3.mp4` 等多个版本，文件名相似。导致 Vision QA 检查了文件 A，但发送了文件 B；用户指出"有字"后仍反复发同一个错误文件。

**强制要求（Hard Gate）**：
1. **QA 路径 = 发送路径**。Vision QA 完成后，立即记录被检文件的绝对路径，发送时必须发同一个文件。
2. **禁止 QA 完成后改名再发**。不得 QA 完 `video1_final_v4.mp4` 后，把它改名叫 `video_final_v4.mp4` 再发。
3. **发前自检**：发送前用 Whisper 采样确认发出的文件内容与项目话题匹配。

**文件管理原则**：
- `/tmp` 里同一项目只保留 **1 个最终版视频**，命名格式 `{topic}_final.mp4`
- 每次重新烧录后，用新输出覆盖旧文件，不要产生 `v1/v2/v3` 堆叠
- 如果必须保留旧版，用明确后缀如 `{topic}_before_fix.mp4`

**错误流程（禁止）**：
```
burn → Vision QA → 通过
  → 文件改名（video_v4.mp4 → video_final.mp4）← 路径变了
  → 发给用户 ← 发的不是 QA 过的那个文件
```

**正确流程**：
```
burn → Vision QA（记录：/tmp/video1_final.mp4）
  → 直接发 /tmp/video1_final.mp4
  → 发送路径 = QA 路径，完全一致
```
