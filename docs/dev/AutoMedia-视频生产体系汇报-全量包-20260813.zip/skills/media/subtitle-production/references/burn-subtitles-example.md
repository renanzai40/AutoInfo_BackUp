# burn_subtitles.py 调用示例

### burn_subtitles.py 调用示例

```bash
# 无大标题（老方式）
python3 burn_subtitles.py video.mp4 audio.wav subtitle.srt output.mp4

# 有大标题
python3 burn_subtitles.py video.mp4 audio.wav subtitle.srt output.mp4 62.7 --title "为什么你总错过AI红利"

# 有大标题 + safe_upper
python3 burn_subtitles.py video.mp4 audio.wav subtitle.srt output.mp4 53.9 --title "特朗普访华"
```
