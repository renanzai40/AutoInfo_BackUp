# ⚠️ SRT Entry 字数限制与 PIL 渲染（2026-05-15 新增）

### ⚠️ SRT Entry 字数限制与 PIL 渲染（2026-05-15 新增）

**45字/entry 是硬上限，但还不够——PIL auto-wrap 可能把 35-45 字的 entry 渲染成 3 行。**

根因：PIL `draw.text()` 在 `max_w` 约束下按字符逐个放入行，当单行放不下时自动换行。即使 entry 总字数 < 45，PIL 的字符级 wrap 仍可能在语义中点断裂，导致 3 行。

**解法一（推荐）：显式 `\n` 控制换行**

在 JSON segments 中用 `\n` 显式指定换行位置：

```json
[
    [0.0, 6.0, "还在为直播带货绞尽脑汁？\n手机加工具，升级了。"],
    [6.0, 12.56, "百度最近出了大招，叫一镜……"]
]
```

`\n` 必须是真正的换行符。用 `repr()` 验证：
```python
import json
with open("segs.json") as f:
    segs = json.load(f)
assert '\n' in segs[0][2]  # 必须是 True
```

**2026-05-15 已修复**：burn_subtitles.py 的 `add_subtitle_to_frame()` 现已支持显式 `\n`——遇到 `\n` 时先按其切分每行，再对超宽行做 auto-wrap。

**解法二：缩短单 entry 字数**

经验值：PIL 渲染下单行 ≤ 35 字符可有效避免 3 行。超过 35 字的 entry 必须拆或用显式 `\n`。
