# GAP Hold Frame 缺失大标题 — Flicker Bug（2026-05-17）

## 问题现象

用户反馈：视频大标题出现"闪烁"——某些帧里没有大标题，画面上只有口播字幕，大标题消失了几帧然后又出现。

## 根因分析

2026-05-17 v3 版 burn_subtitles.py 实现 gap-fill 时，在 SRT entries 之间的静音间隙插入 hold-frame（取当前 entry 末尾帧作背景的静止画面）。

**旧代码只画了口播字幕，没画大标题：**

```python
# 旧代码（错误）：
bg_gap = f"{tmp}/bg_gap_{idx:03d}.jpg"
extract_frame(video, end + 0.01, bg_gap, safe_upper=safe_upper)
draw_subtitle(bg_gap, text, sub)           # ← 只有口播字幕
frame_to_video(bg_gap, gap, black)          # ← 标题没画
```

结果：GAP 段（300-600ms 的静音间隙）里，口播字幕是最后一刻的那句（正确），但大标题是空白的。concat 后视频在这些位置没有标题 → 人眼看到"闪烁"。

## 正确做法

GAP hold frame 必须同时画：
1. 口播字幕（保持最后一句，不切换）
2. 大标题（全片持续，标题不变）

```python
# 正确代码：
bg_gap = f"{tmp}/bg_gap_{idx:03d}.jpg"
extract_frame(video, end + 0.01, bg_gap, safe_upper=safe_upper)
draw_subtitle(bg_gap, text, sub)            # 保持最后一句字幕
draw_title(sub, title_text, bg_gap)         # 大标题也画上（修复 flicker）
frame_to_video(bg_gap, gap, black)
all_segs.append(black)
```

## 技术细节

| 项目 | 值 |
|------|-----|
| gap 阈值 | > 150ms 才插入 hold frame |
| hold frame 内容 | 当前 entry 末尾帧 + 最后一句口播字幕 + 全片标题 |
| 背景提取时间点 | `end + 0.01s`（entry 结束后 10ms） |

## 教训

**"持续显示"的元素（标题）在任何帧里都不能缺席。**
GAP hold frame 不是"填充空白"，而是"延续当前画面状态"。口播字幕延续上一句，标题延续整个视频的封面标题。两者都必须画。