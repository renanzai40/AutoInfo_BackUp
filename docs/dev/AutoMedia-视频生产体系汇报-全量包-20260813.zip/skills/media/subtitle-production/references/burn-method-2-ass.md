# 方式 2：FFmpeg ASS subtitles（仅预览）

### 方式 2：FFmpeg ASS subtitles（仅预览）

```bash
ffmpeg -i video_raw.mp4 -vf "subtitles=srt_file.srt:force_style='FontName=WenQuanYi\ Zen\ Hei,FontSize=55,MarginV=120'" -c:v libx264 preview.mp4
```

**用途**：QA 抽帧前快速验证时间轴是否对齐。**不用于最终成片**。

---
