# 视频图片拼接正确链路 — FFmpeg TS Concat（2026-05-19）

## 背景

本 session 引流款生产过程中，concat demuxer 和 concat filter 两种方案都产生了不可预期的时长错误：

- **concat demuxer + fps filter**：产生 46s 视频（音频 32s）
- **concat filter + fps in scale**：产生 8 帧（每张图 0.27s）

最终验证了 **MPEG-TS 分段拼接**是唯一可靠的精确时长控制方案。

## 完整正确链路（已验证）

```bash
WORKDIR="项目/03_video"
IMGS=("c_1s.png" "c_3s.png" "c_6s.png" "c_10s.png" "c_13s.png" "c_16s.png" "c_20s.png" "c_22s.png")
DURS=(4 4 4 4 4 4 4 2)  # 每张图持续秒数，最后一张 = 总时长-28

# Step 1: 每张图片 → 独立 MPEG-TS（30fps，精确时长）
for i in 0 1 2 3 4 5 6 7; do
  IMG="${IMGS[$i]}"
  DUR="${DURS[$i]}"
  ffmpeg -y -loop 1 -i "$WORKDIR/$IMG" -t "$DUR" \
    -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1" \
    -pix_fmt yuv420p -c:v libx264 -preset fast -r 30 \
    "/tmp/seg_$(printf '%02d' $((i+1))).ts" 2>/dev/null
done

# Step 2: concat TS 文件（无损拼接，保持精确时长）
ffmpeg -y -i "concat:/tmp/seg_01.ts|/tmp/seg_02.ts|/tmp/seg_03.ts|/tmp/seg_04.ts|/tmp/seg_05.ts|/tmp/seg_06.ts|/tmp/seg_07.ts|/tmp/seg_08.ts" \
  -c copy \
  "$WORKDIR/video_32s_raw.mp4"

# Step 3: 检查时长
VID_DUR=$(ffprobe -v quiet -show_entries format=duration -of csv=p=0 "$WORKDIR/video_32s_raw.mp4")
echo "Video: $VID_DUR seconds"  # 必须是 32.000

# Step 4: 烧录字幕（用 burn_subtitles.py 或 PIL）
# burn_subtitles.py re-encode 时必须加 -r 2 -frames:v N（见 ass-subtitle-bugs-2026-05-19.md Bug 2）

# Step 5: 合并音频（-shortest 让视频对齐音频）
ffmpeg -y -i "$WORKDIR/video_with_subtitles.mp4" -i "$WORKDIR/audio.wav" \
  -c:v copy -c:a aac -shortest \
  "$WORKDIR/video_final.mp4"
```

## 已知错误链路（永久禁止）

| 方法 | 问题 |
|------|------|
| concat demuxer + fps filter | 时长不精确（32s audio → 46s video） |
| concat filter + fps in scale per input | 每段变 1 帧（0.27s total） |
| concat filter 之后加 -vf fps=2 | 每张图变成 0.5s，总时长 4s |
| concat demuxer 不用 TS 格式 | duration directive 精度丢失 |

## burn_subtitles.py re-encode 关键参数

re-encode 命令必须包含 `-r FPS -frames:v N`，否则 h264 默认 25fps：

```bash
# CORRECT（60帧 × 2fps = 30s）
ffmpeg -y -framerate 2 -i frames_%04d.png \
  -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p \
  -r 2 -frames:v 60 \
  output_30s.mp4

# WRONG（60帧 × 25fps = 52.5s）
ffmpeg -y -framerate 2 -i frames_%04d.png \
  -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p \
  output_52.5s.mp4  # ← 没有 -r，h264 默认 25fps 输出
```

## 品牌 CTA 完整性检查（在 TTS 之前必须执行）

**引流款脚本常见缺失**：`评论区聊聊～` 结尾，没有品牌 CTA。

brand-cta-review 零容忍项（任一存在则禁止调用 TTS）：
- [ ] 品牌身份未锚定：全文无"壹目贯维是 AI 内容生产公司"类似表述
- [ ] 无 CTA：尾部无关注/扫码等行动引导
- [ ] 品牌名未出现：全文无"壹目贯维"
- [ ] 功能描述缺失：热点追踪/文案生成/多平台发布三选一以上未出现

引流款脚本以"评论区聊聊"结尾 = 脚本本身内容缺失，不是视频工艺问题。需要先重建脚本，再执行 TTS。禁止跳过 brand-cta-review 直接调用 TTS。
