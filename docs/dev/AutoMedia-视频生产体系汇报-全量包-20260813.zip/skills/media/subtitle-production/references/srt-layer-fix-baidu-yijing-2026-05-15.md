# 百度一镜 SRT 层精准修复实录（2026-05-15）

## 背景

百度一镜视频 v1：脚本通过 humanizer + copy-review + brand-cta-review，但字幕多行叠加违反铁律（E2/E3 均为4-5行 entry）。

## 失败路径（不要照搬）

```
问题脚本 → 重建 SRT → 重新生成5张图 → 重新拼接 → PIL bug →修了4轮
```

每次重建视频资产都引入新问题：图片重生成时 img_4 有地图（敏感素材），img_3/img_5 有乱码文字（Vision 未检查）。

## 正确路径（SRT-only Fix）

### Step 1：诊断 — 确认问题在哪一层

- **SRT 时间轴错** → 只修 SRT，不重建视频
- **图片有乱码/敏感素材** → 只重新生成该张图片，不重建音频/SRT
- **视频本身有问题** → 才重建视频

### Step 2：SRT-only Fix 执行路径

```python
# Step 1：加载 Whisper JSON（已有）
with open("whisper.json") as f:
    data = json.load(f)
segments = data["segments"]  # 真实时间轴，忠实反映音频中每个语音段的起止

# Step 2：生成 SRT — 每个 segment → 1 个 entry
# 文本用原始脚本（MiniMax 输出），Whisper ASR 只提供时间戳
# 文字对照：Whisper 把"一镜"听成"遗静"，把"壹目贯维"听成"一目关为"
# → 替换回正确文字，但时间戳完全不动

# Step 3：逐 entry 检查 — 单行原则
# 每个 entry 的文字必须：字数 ≤ 20 字（≤14字最佳）
# 时长 > 3s + 字数 > 20 → 必然多行 → 必须拆分
# 拆分基准：Whisper segment 边界，按比例分配时长

# Step 4：写入 subtitle_v3.srt
# 使用 Whisper 真实时间戳 + 脚本正确文字
```

### Step 3：只烧录字幕层

```python
# 不重建 video_with_audio.mp4
# 不重新生成 img_*.png
# 不重新拼接 seg_*.mp4

# 只替换 SRT 并重新 PIL 烧录
VIDEO = "video_with_audio.mp4"   # 原始拼接视频，零修改
AUDIO = "audio.wav"              # 原始 TTS，零修改
SRT = "subtitle_v3.srt"          # 新 SRT，单行 entries
OUTPUT = "video_final.mp4"       # 覆盖烧录

# PIL burn_v3.py：逐 entry 提取帧 → 画字幕 → 转 segment → concat → 合并音频
```

## 关键数据（百度一镜）

| 指标 | 值 |
|------|-----|
| Whisper segments | 29 个（48.72s） |
| 最终 SRT entries | 29 个（逐 segment 单行） |
| 最大 entry 字数 | 14 字（E11"百度最近出了个大招，叫一镜。"） |
| Vision QA | 9 帧全部 1 行 ✅ |

## 教训

1. **Whisper 真实时间轴是基准**：不要按比例估算时间轴，估算会漂移
2. **单行 entry 是通过 QA 的唯一保证**：45 字 entry 仍然会多行（PIL wrap），每 entry ≤ 20 字才能保证 1 行
3. **SRT-only Fix 节省 4 轮重做**：只动了 SRT 文件，未触碰图片/音频/拼接逻辑
