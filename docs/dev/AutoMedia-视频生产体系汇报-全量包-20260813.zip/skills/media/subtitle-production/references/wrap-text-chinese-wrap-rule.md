# ⚠️ wrap_text 中文换行铁律（2026-05-14 新增）

### ⚠️ wrap_text 中文换行铁律（2026-05-14 新增）

**错误做法（空格分词对中文无效）**：
```python
# ❌ WRONG — 中文没有空格，split(' ') 永远返回整个字符串
words = text.split(' ')
current = ''
for w in words:  # w = 整个句子，永远不进入 else 分支
    ...
```

**正确做法（按字符数硬截断）**：
```python
# ✅ CORRECT — 中文按字符数截断，与语言无关
def wrap_text(text, max_chars=18):
    lines = []
    for segment in text.split('\n'):
        if len(segment) <= max_chars:
            lines.append(segment)
        else:
            chars = list(segment)
            current = ''
            for c in chars:
                if len(current) < max_chars:
                    current += c
                else:
                    lines.append(current)
                    current = c
            if current:
                lines.append(current)
    return lines
```

**验证**：每个 entry 的 wrap_text 结果必须满足：
1. 每行字符数 ≤ max_chars（18）
2. 渲染宽度 ≤ 屏幕宽度（用 `textbbox` 验证，`x=(W-text_w)//2 ≥ 0`）
3. 断行位置不能切断品牌名（如"壹目贯维"必须完整不断行）

**如果断行切断品牌名**：在 SRT 层面把 entry 拆分到 Whisper 自然断点，保证品牌名完整。

---
