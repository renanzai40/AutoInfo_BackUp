# Vision QA 失败记录（2026-05-17）

## 场景：视频帧图含敏感内容导致 VLM 拒绝分析

### 现象
对两个项目的最终视频做 Vision QA 时，`mcp_minimax_understand_image` 报错：
```
API Error: 1026-input new_sensitive, input image sensitive
```

视频内容为政治话题（特朗普访华），VLM 将视频帧识别为敏感内容。

### 解法
不分析视频文件，改为：
1. 用 ffmpeg 抽取关键帧（t=1s / t=30s / t=55s）保存为 JPG
2. 对 JPG 做 Vision QA（图片敏感度阈值比视频低）

```bash
ffmpeg -y -ss 1 -i video_final.mp4 -vframes 1 -q:v 2 /tmp/frame_t1.jpg
ffmpeg -y -ss 30 -i video_final.mp4 -vframes 1 -q:v 2 /tmp/frame_t30.jpg
ffmpeg -y -ss 55 -i video_final.mp4 -vframes 1 -q:v 2 /tmp/frame_t55.jpg
```

## 场景：帧图含可辨识人脸（img_4 需重生成）

### 现象
引流款 img_4（高潮/观点帧）Vision QA 检测到男性脸部（戴墨镜，但可辨识）。

### 根因
Prompt `data streams converging into an abstract silhouette figure with backlit glow` 被 AI 解析为"人物剪影"并生成了真实人脸。

### 解法
重写 prompt，强制去除人：
```
data streams converging into purely geometric light sculpture without any human figures
```

### 教训
帧图 prompt 出现 `silhouette figure` / `backlit glow` / `figure` 等词时，AI 几乎必然生成人物。
避免方案：高潮帧用抽象光效/几何图形代替人物剪影。

## 场景：封面图 Vision QA 发现乱码文字

### 常见乱码位置
- 科技感 `data visualization panels` → 面板上有乱码英文
- `floating UI panels` → 面板有乱码符号
- 任何 prompt 带"shield"（盾牌）→ 盾牌上可能有 "AI" 字母

### 解法
- 封面图 prompt 末尾加反嵌入声明：`NO large text in center, NO title text, NO big characters overlaid on the image`
- 盾牌/面板类概念换掉：`shattered display panel with glowing fragments`（破碎无乱码）