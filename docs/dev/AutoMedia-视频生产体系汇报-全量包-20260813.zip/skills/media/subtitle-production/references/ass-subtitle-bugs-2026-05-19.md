# ASS Subtitle Rendering Bugs (2026-05-19, updated 2026-05-19 evening)

## Bug 1: \N newline causes format fields to appear in subtitle text

Symptom: After burning subtitles, Vision QA finds `,0,0,,` appended to subtitle text.

Root cause: ASS Dialogue format is `Layer,Start,End,Style,MarginL,MarginR,MarginV,Effect,Text`. When Text contains `\N` newline, FFmpeg ASS filter sometimes renders the Effect field (empty "") as visible text.

**Error**:
```python
text_escaped = text.replace('\n', '\\N')
ass_lines.append(f"Dialogue: 0,...,{text_escaped}")
# FFmpeg sometimes outputs: ",0,0,,朋友跟我说..."
```

**Fix**: Use single-line subtitles only, no `\N`. 55pt single line fits ~18-20 Chinese chars in 920px width.

## Bug 2: burn_subtitles.py re-encode uses h264 default 25fps (fixed 2026-05-19 evening)

The re-encode step uses libx264 which defaults to 25fps OUTPUT frame rate. This means 60 frames at 2fps source becomes 60 frames at 25fps → 52.5s instead of 30s. The `--fps` argument was already fixed in Bug 2, but the output frame rate ALSO needs forcing.

**Fix applied**: re-encode command now includes `-r str(fps) -frames:v N` to force exact output frame rate:
```bash
ffmpeg -y -framerate 2 -i frames_%04d.png \
  -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p \
  -r 2 -frames:v 64 \   # ← CRITICAL: forces exact 2fps output
  output_raw.mp4
```

## Bug 3: PIL ASS Dialogue text field extraction uses parts[9] instead of parts[8]

Symptom: All subtitle text appears empty or wrong — burned frames show no subtitle text at all, or show entry N's text at entry N+1's time.

Root cause: ASS Dialogue has 9 fields (indices 0-8). The text is at index 8, not 9.

```python
# WRONG — splits into 9 parts (indices 0-8), text is at index 8, not 9
parts = line[9:].split(',', 8)
text = parts[9].strip()   # IndexError or empty string

# CORRECT
text = parts[8].strip()   # 9th field (0-indexed)
```

## Bug 4: FFmpeg concat precision — TS concat is the only reliable method

Two FFmpeg concat approaches both fail with single-frame image sequences:

**Method A: concat demuxer with duration directives + fps filter** — produces wrong duration
```bash
# WRONG: produces video longer than audio (32s audio → 46s video)
ffmpeg -y -f concat -safe 0 -i concat.txt \
  -vf "...,fps=2" -r 2 video_raw.mp4
```

**Method B: concat filter with fps in scale** — produces single-frame output (8 images → 8 frames at 30fps = 0.27s each)
```bash
# WRONG: each segment becomes 1 frame, total duration = 8 * (1/30) = 0.27s
```

**CORRECT: MPEG-TS segments + concat protocol**
```bash
# Step 1: each image → MPEG-TS at 30fps
for i in 1 2 3 4 5 6 7 8; do
  ffmpeg -y -loop 1 -i "img_${i}.png" -t 4 \
    -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2" \
    -pix_fmt yuv420p -c:v libx264 -preset fast -r 30 \
    "/tmp/seg_${i}.ts"
done

# Step 2: concat TS files (lossless, preserves exact timing)
ffmpeg -y -i "concat:seg_01.ts|seg_02.ts|...|seg_08.ts" \
  -c copy video_raw.mp4
```

## Bug 5: FFmpeg ASS filter does not support \N newlines or multi-line Layer approaches

Two techniques for multi-line subtitles both fail in FFmpeg's ASS filter:
- `\N` in Dialogue Text → format fields leak (Bug 1)
- Layer 5 multi-line → only first Dialogue renders

**Correct approach for multi-line**: Use PIL (burn_subtitles.py or custom) for per-frame rendering. FFmpeg ASS filter only reliable for single-line subtitles.

## Correct ASS Dialogue format

```python
def fmt_ass(ts):
    h = int(ts // 3600)
    m = int((ts % 3600) // 60)
    s = int(ts % 60)
    cs = int((ts - int(ts)) * 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"

# 9-field Dialogue: Layer,Start,End,Style,MarginL,MarginR,MarginV,Effect,Text
for start, end, text in entries:
    ass_lines.append(f"Dialogue: 0,{fmt_ass(start)},{fmt_ass(end)},Default,0,0,120,,{text}")
```

Note: Text is at index 8 (9th field, 0-indexed), NOT index 9.

## Pixel-level QA (mandatory pre-send check)

Vision QA is unreliable for CJK characters (random per-query answers). Use pixel analysis instead:

```python
from PIL import Image
img = Image.open(frame_path).convert("RGB")
w, h = img.size
# Subtitle region: bottom 1/6 of screen
bright = sum(1 for y in range(int(h*5/6), h) for x in range(w)
            if sum(img.getpixel((x, y))[:3]) / 3 > 50)
has_subtitle = bright > 100
# Title region: top 1/3, yellow pixels (R>150, G>150, B<80)
yellow = sum(1 for y in range(80, int(h/3)) for x in range(w)
            p = img.getpixel((x,y))
            if p[0] > 150 and p[1] > 150 and p[2] < 80)
has_title = yellow > 20
```

**Pre-send checklist** (all must be True before sending):
- [ ] Audio duration ≈ Video duration (< 1s difference)
- [ ] Pixel QA: subtitle region has bright pixels during speech
- [ ] Pixel QA: title region has yellow pixels throughout video
- [ ] Whisper audio verification: brand name + CTA confirmed in audio
- [ ] No cross-topic content leaking into wrong video
