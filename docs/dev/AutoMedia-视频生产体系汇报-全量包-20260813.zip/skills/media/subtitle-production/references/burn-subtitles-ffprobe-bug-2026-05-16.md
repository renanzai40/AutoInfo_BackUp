# burn_subtitles.py ffprobe bug + safe_seek workaround

## burn_subtitles.py get_dur() bug（2026-05-16 实测）

**文件**：`skills/media/subtitle-production/scripts/burn_subtitles.py`

**问题**：`get_dur()` 函数内部调用 `subprocess.run([FFMPEG, ...])`（注意变量名是 `FFMPEG` 即 ffmpeg 路径，不是 ffprobe），且 `stdout=subprocess.DEVNULL` 导致 ffprobe/ffmpeg 的 duration 输出被吞掉，函数返回空字符串，外层 `float("")` 抛出 ValueError。

**影响**：直接运行 `python3 burn_subtitles.py ...` 会 crash。

**临时绕过**：在调用 `burn()` 时传入 `audio_dur_override=float` 参数，函数会跳过 `get_dur()` 调用。

**彻底修复**：修改 `get_dur()` 使用 ffprobe 绝对路径，移除 DEVNULL：

```python
def get_dur(path):
    # 使用 ffprobe 绝对路径，不用 FFMPEG 变量（那是 ffmpeg 不是 ffprobe）
    r = subprocess.run(
        ["/home/renanzai/bin/ffprobe", "-v", "error",
         "-show_entries", "format=duration", "-of", "csv=p=0", path],
        capture_output=True, text=True  # 不是 DEVNULL！
    )
    return float(r.stdout.strip())
```

---

## safe_seek：解决视频比音频短的问题

FFmpeg concat 生成的 raw 视频，时长经常比音频短几秒（如音频 54.864s，raw 视频 54.5s，实际最后一帧约 53.9s）。

`extract_frame()` 必须 clamp seek 时间：

```python
VIDEO_SAFE_UPPER = 53.9  # 首次运行前用 ffmpeg -ss 最大时间点 测试得到

def safe_seek(raw_ts, safe_upper=VIDEO_SAFE_UPPER):
    """确保 seek 时间在视频有效范围内，避免提取空帧"""
    return min(raw_ts, safe_upper - 0.05)

def extract_frame(video_path, seek_ts, out_path, safe_upper=VIDEO_SAFE_UPPER):
    ts = safe_seek(seek_ts, safe_upper)
    r = subprocess.run(
        [FFMPEG, "-y", "-ss", str(ts), "-i", video_path,
         "-vframes", "1", "-q:v", "2", "-f", "image2", out_path],
        capture_output=True, text=True
    )
    # 检查是否真的写出了帧
    if r.returncode != 0 or os.path.getsize(out_path) < 1000:
        # fallback：用视频末尾附近的安全时间点
        subprocess.run(
            [FFMPEG, "-y", "-sseof", "-0.2", "-i", video_path,
             "-vframes", "1", "-q:v", "2", "-f", "image2", out_path],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
```

**测试最大安全时间点**：
```bash
ffmpeg -y -ss 54.0 -i video.mp4 -vframes 1 /tmp/test.jpg
# 如果 "video:0KiB" → 超出范围，往前调
ffmpeg -y -ss 53.5 -i video.mp4 -vframes 1 /tmp/test.jpg
# 重复直到找到能出帧的最大时间 → 记为 VIDEO_SAFE_UPPER
```

---

## 完整调用示例（2026-05-16 验证通过）

```python
import subprocess, shutil, os, re
from PIL import Image, ImageDraw, ImageFont

FFMPEG = "/home/renanzai/mamba/envs/ffmpeg/bin/ffmpeg"
FONT_PATH = "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"
FONT_SIZE = 55
MARGIN_V = 120
W, H = 1080, 1920

AUDIO_DUR = 54.864      # 从 ffprobe 查到
VIDEO_SAFE = 53.9       # 从 ffmpeg -ss 试探到

# Step 1: 从已烧录视频提取无字幕 raw 视频
subprocess.run([
    FFMPEG, "-y", "-i", "video_with_subs.mp4",
    "-c:v", "copy", "-an", "video_raw.mp4"
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Step 2: 转 wav（burn 需要）
subprocess.run([
    FFMPEG, "-y", "-i", "audio.mp3",
    "-vn", "-acodec", "pcm_s16le", "-ar", "44100", "-ac", "1", "audio.wav"
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Step 3: burn（传 audio_dur_override 绕过 ffprobe bug）
burn(video_path="video_raw.mp4",
     audio_path="audio.wav",
     srt_path="subtitle.srt",
     output_path="video_final.mp4",
     audio_dur_override=AUDIO_DUR)
```

---

## PIL 字幕烧录为什么用 frame-to-video 而非 overlay

原脚本策略：对每个 SRT entry，在该 entry 的中点时间提取一帧，叠加字幕后转成短 mp4，最后 concat 所有短 mp4。

**优势**：渲染可靠，无 ASS 滤镜各种诡异 bug（只显示半句、居中而非底部、多行叠加）

**缺点**：每帧重新编码，画质有轻微损失（CRF=23 控制在可接受范围）

**对比 ASS overlay**：ffmpeg `-vf subtitles=srt` 默认字幕居中、字体/大小控制复杂、跨环境渲染不一致。PIL 方案结果可预期。
