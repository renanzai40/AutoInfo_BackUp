#!/usr/bin/env python3
"""
PIL字幕烧录 — 逐Entry独立帧+concat策略

新增（2026-05-17）：
  --title <文本>    视频大标题（黄色黑边，置于画面上1/3处）
  口播字幕位置：离底部1/6画面高度（MarginV=320 @ 1080x1920）

用法:
  python3 burn_subtitles.py <video_with_audio.mp4> <audio.wav> <subtitle.srt> <output.mp4> [safe_upper] [--title "大标题文本"]

字体: WenQuanYi Zen Hei → /usr/share/fonts/truetype/wqy/wqy-zenhei.ttc
Python: 必须用 hermes-agent venv: /home/renanzai/.hermes/hermes-agent/venv/bin/python3
FFmpeg: /home/renanzai/mamba/envs/ffmpeg/bin/ffmpeg
"""
import subprocess, shutil, os, re, sys
from PIL import Image, ImageDraw, ImageFont

FFMPEG = "/home/renanzai/mamba/envs/ffmpeg/bin/ffmpeg"
FFPROBE = "/home/renanzai/bin/ffprobe"
FONT_PATH = "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"

# 竖屏 9:16 1080x1920
W, H = 1080, 1920

# 口播字幕参数（小字白底黑边，底部）
SUB_FONT_SIZE = 55
SUB_MARGIN_V = int(H / 6)   # 离底部1/6 = 320px
SUB_MARGIN_H = 80

# 视频大标题参数（大字黄底黑边，顶部上1/3）
TITLE_FONT_SIZE = 72
TITLE_MARGIN_V = int(H / 3)  # 画面上1/3处 ≈ 640px

def parse_srt(path):
    with open(path, encoding='utf-8') as f:
        content = f.read()
    entries = []
    blocks = re.split(r'\n\n+', content.strip())
    for block in blocks:
        lines = block.strip().split('\n')
        if len(lines) < 3:
            continue
        times = lines[1]
        start_str, end_str = times.split('-->')
        start = parse_time(start_str.strip())
        end = parse_time(end_str.strip())
        text = '\n'.join(l for l in lines[2:] if l.strip())
        entries.append((start, end, text))
    return entries

def parse_time(s):
    s = s.replace(',', '.')
    p = s.split(':')
    return float(p[0])*3600 + float(p[1])*60 + float(p[2])

def get_dur(path):
    """Get duration using ffprobe (not ffmpeg). Returns None if unavailable."""
    try:
        r = subprocess.run(
            [FFPROBE, '-v', 'quiet', '-show_entries', 'format=duration', '-of', 'csv=p=0', path],
            capture_output=True, text=True, timeout=10
        )
        val = r.stdout.strip()
        if val:
            return float(val)
    except Exception:
        pass
    return None

def safe_seek_ts(raw_ts, safe_upper):
    """确保 seek 时间点在视频有效范围内"""
    return min(raw_ts, safe_upper - 0.05)

def extract_frame(path, ts, out, safe_upper=None):
    """提取帧，seek 超界时 fallback 到视频末尾前一帧"""
    vid_dur = get_dur(path)
    upper = safe_upper if safe_upper is not None else (vid_dur if vid_dur else float('inf'))
    ts = safe_seek_ts(ts, upper)
    r = subprocess.run(
        [FFMPEG, '-y', '-ss', str(ts), '-i', path,
         '-vframes', '1', '-q:v', '2', '-f', 'image2', out],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )
    if r.returncode != 0 or os.path.getsize(out) < 1000:
        # fallback: 取视频末尾前 0.2s 的帧
        fallback_ts = (vid_dur - 0.2) if vid_dur else 0.1
        subprocess.run(
            [FFMPEG, '-y', '-sseof', '-0.2', '-i', path,
             '-vframes', '1', '-q:v', '2', '-f', 'image2', out],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )

def draw_subtitle(frame_path, text, out_path):
    """口播字幕：小字白底黑边，固定底部离边缘1/6高度"""
    font = ImageFont.truetype(FONT_PATH, SUB_FONT_SIZE)
    img = Image.open(frame_path).convert('RGB')
    draw = ImageDraw.Draw(img)

    # ── 文本分词：支持显式\n + 宽度超限自动拆行 ─────────────
    raw_lines = text.split('\n')
    final_lines = []
    for raw in raw_lines:
        raw = raw.strip()
        if not raw:
            continue
        # 检查这行是否需要拆
        bbox = draw.textbbox((0, 0), raw, font=font)
        max_w = W - 2 * SUB_MARGIN_H
        if bbox[2] - bbox[0] <= max_w:
            final_lines.append(raw)
        else:
            # 按字符硬截拆行
            cur = ''
            for c in raw:
                test = cur + c
                b = draw.textbbox((0, 0), test, font=font)
                if b[2] - b[0] <= max_w:
                    cur = test
                else:
                    if cur:
                        final_lines.append(cur)
                    cur = c
            if cur:
                final_lines.append(cur)

    dims = [(draw.textbbox((0, 0), l, font=font)) for l in final_lines]
    total_h = sum(d[3] - d[1] for d in dims) + (len(final_lines) - 1) * 8
    y = H - SUB_MARGIN_V - total_h  # 从底部往上1/6处开始
    for i, (line, bbox) in enumerate(zip(final_lines, dims)):
        x0, y0, x1, y1 = bbox
        lw, lh = x1 - x0, y1 - y0
        x = (W - lw) // 2
        y_cur = y + sum((dims[j][3]-dims[j][1])+8 for j in range(i))
        # 黑边
        for dx in [-1,1]:
            for dy in [-1,1]:
                draw.text((x+dx, y_cur+dy), line, font=font, fill=(0,0,0))
        # 白字
        draw.text((x, y_cur), line, font=font, fill=(255,255,255))
    img.save(out_path)

def draw_title(frame_path, title_text, out_path):
    """视频大标题：白字黑边+深色半透明背景框，置画面上1/3处，居中偏上"""
    font = ImageFont.truetype(FONT_PATH, TITLE_FONT_SIZE)
    img = Image.open(frame_path).convert('RGB')
    draw = ImageDraw.Draw(img)

    # ── 文本分词：按字符硬截，每行不超过屏幕宽度 ─────────────
    chars = list(title_text)
    lines = []
    current = ''
    for c in chars:
        test = current + c
        bbox = draw.textbbox((0, 0), test, font=font)
        if bbox[2] - bbox[0] <= W - 160:
            current = test
        else:
            if current:
                lines.append(current)
            current = c
    if current:
        lines.append(current)

    # ── 计算布局：从画面顶部1/3处往下排 ──────────────────────
    line_h = int(TITLE_FONT_SIZE * 1.5)
    total_h = len(lines) * line_h
    y = TITLE_MARGIN_V  # Y = H/3 ≈ 640px

    # ── 深色半透明背景框，提升可读性 ────────────────────────
    box_pad = 16
    box_h = total_h + box_pad * 2
    box_w = max(draw.textbbox((0, 0), l, font=font)[2] for l in lines) + box_pad * 2
    box_x = (W - box_w) // 2
    box_y = y - box_pad
    draw.rectangle([box_x, box_y, box_x + box_w, box_y + box_h],
                   fill=(0, 0, 0, 160))

    # ── 白色粗描边 + 实心白字 ───────────────────────────────
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        lw = bbox[2] - bbox[0]
        lh_bbox = bbox[3] - bbox[1]
        x = (W - lw) // 2
        # 3px 描边（8方向）
        for dx in range(-3, 4):
            for dy in range(-3, 4):
                if dx != 0 or dy != 0:
                    draw.text((x + dx, y + dy), line, font=font, fill=(0, 0, 0))
        # 实心白字
        draw.text((x, y), line, font=font, fill=(255, 255, 255))
        y += line_h

    img.save(out_path)

def frame_to_video(img_path, dur, out_path):
    subprocess.run([FFMPEG, '-y','-loop','1','-i',img_path,'-t',str(dur),
        '-vf',f'scale={W}:{H}','-c:v','libx264','-preset','fast','-crf','23',
        '-pix_fmt','yuv420p','-r','30','-an',out_path],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def main():
    if len(sys.argv) < 5:
        print("用法: python3 burn_subtitles.py <video.mp4> <audio.wav> <subtitle.srt> <output.mp4> [safe_upper] [--title \"大标题文本\"]")
        sys.exit(1)

    video = sys.argv[1]
    audio = sys.argv[2]
    srt = sys.argv[3]
    output = sys.argv[4]
    # safe_upper: 第5个位置参数，可能是数字或--title
    _idx = 5
    safe_upper = None
    title_text = None
    if len(sys.argv) > _idx:
        if sys.argv[_idx].replace('.','',1).isdigit():
            safe_upper = float(sys.argv[_idx])
            _idx += 1
    if '--title' in sys.argv:
        ti = sys.argv.index('--title')
        title_text = sys.argv[ti+1] if ti+1 < len(sys.argv) else None

    audio_dur = get_dur(audio)
    if audio_dur is None:
        print("ERROR: 无法获取音频时长，使用 fallback 估算", file=sys.stderr)
        entries = parse_srt(srt)
        audio_dur = max(e for _, e, _ in entries)
    print(f"音频时长: {audio_dur:.3f}s")

    entries = parse_srt(srt)
    print(f"SRT entries: {len(entries)}, title={repr(title_text)}")

    tmp = os.path.dirname(output) + "/_burn_tmp"
    os.makedirs(tmp, exist_ok=True)

    seg_files = []
    all_segs = []  # 含 GAP hold frames 的完整片段列表
    for idx, (start, end, text) in enumerate(entries):
        mid = (start + end) / 2
        bg = f"{tmp}/bg_{idx:03d}.jpg"
        sub = f"{tmp}/sub_{idx:03d}.jpg"
        seg = f"{tmp}/seg_{idx:03d}.mp4"
        extract_frame(video, mid, bg, safe_upper=safe_upper)
        draw_subtitle(bg, text, sub)
        if title_text:
            titled = f"{tmp}/titled_{idx:03d}.jpg"
            draw_title(sub, title_text, titled)
            frame_to_video(titled, end - start, seg)
        else:
            frame_to_video(sub, end - start, seg)
        seg_files.append(seg)
        all_segs.append(seg)  # 主字幕段
        print(f"  E{idx+1}: {start:.2f}-{end:.2f}s ({end-start:.2f}s) | {text[:25]}...")

        # ── GAP hold frame: 标题也必须持续显示 ─────────────────
        if idx < len(entries) - 1:
            gap = entries[idx + 1][0] - end
            if gap > 0.15:
                black = f"{tmp}/black_{idx:03d}.mp4"
                bg_gap = f"{tmp}/bg_gap_{idx:03d}.jpg"
                extract_frame(video, end + 0.01, bg_gap, safe_upper=safe_upper)
                draw_subtitle(bg_gap, text, sub)           # 保持最后一句字幕
                draw_title(sub, title_text, bg_gap)        # 标题也画上
                frame_to_video(bg_gap, gap, black)
                all_segs.append(black)
                print(f"  [GAP] {end:.2f}s-{entries[idx+1][0]:.2f}s ({gap:.2f}s) — insert hold frame")

    # concat once
    inputs = []
    for s in all_segs:
        inputs.extend(['-i', s])
    n = len(all_segs)
    vs = '[' + ']['.join([f'{i}:v' for i in range(n)]) + ']'
    flt = vs + f'concat=n={n}:v=1:a=0[outv]'
    sub_video = f"{tmp}/sub_video.mp4"
    r = subprocess.run([FFMPEG,'-y'] + inputs + ['-filter_complex',flt,'-map','[outv]',
        '-c:v','libx264','-preset','fast','-crf','23',sub_video],
        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
    print(f"concat ({n} segs): {'OK' if r.returncode==0 else 'FAIL '+r.stderr[-200:]}")

    # merge audio
    final_raw = f"{tmp}/final_raw.mp4"
    r = subprocess.run([FFMPEG,'-y','-i',sub_video,'-i',audio,
        '-map','0:v','-map','1:a','-c:v','libx264','-preset','fast','-crf','18',
        '-c:a','aac','-b:a','192k','-shortest',final_raw],
        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
    print(f"merge: {'OK' if r.returncode==0 else 'FAIL'}")

    # trim to exact audio duration
    subprocess.run([FFMPEG,'-y','-i',final_raw,'-t',str(audio_dur),
        '-c:v','copy','-c:a','copy',output],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    final_dur = get_dur(output)
    print(f"最终时长: {final_dur:.3f}s ✅")
    shutil.rmtree(tmp, ignore_errors=True)
    print("完成!")

if __name__ == '__main__':
    main()
