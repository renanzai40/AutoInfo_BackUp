---
name: subtitle-production
description: "视频字幕SRT生产与烧录完整流水线——从TTS音频到可发布视频的全流程。解决字幕与语音不同步、字幕过长被截断、烧录后视频时长不准等问题。 触发：生成/烧录字幕 SRT 前必加载；不用于视频场景文字设计（归 hyperframes-workflow）。"
version: 1.1
author: Hermes Agent for renan
license: MIT
tags: [subtitle, SRT, Whisper, FFmpeg, video-production]
---
## 强制触发节点

**开始写 SRT 字幕之前** → 立即加载本 skill

**执行 burn_subtitles.py 或 ffmpeg 字幕烧录之前** → 立即加载本 skill

**生成引流款视频 TTS 之前** → 立即加载 brand-cta-review skill，确认脚本通过零容忍项检查。引流款脚本以"评论区聊聊"结尾 = 脚本内容缺失，不得跳过 CTA 审核直接调用 TTS。

---

## 音频身份铁律（第一条也是最后一条）

> 音频是唯一真相。Whisper、SRT、视频必须使用同一份音频文件。

**绝对禁止**：用旧版本音频跑 Whisper，再把新音频塞进视频。  
**正确顺序**：
```
TTS 生成音频 → 在该音频上跑 Whisper → 拿时间轴建 SRT → 建视频时用同一份音频
```

**验证**：Whisper 最后一个 segment 的 end 时间 ≈ 音频总时长（误差 < 1s）。不等则说明音频版本错了。

---

## SRT 生产标准流程

### Step 1 — 确认音频路径

TTS 生成音频后，立即将音频文件复制到项目文件夹：
```
cp /tmp/trump_radio_host.mp3 项目/03_video/audio_voiceover.wav
```
之后所有步骤（Whisper / SRT / 视频）都用这个路径。

### Step 2 — Whisper 提取时间轴

```bash
export PATH=/home/renanzai/mamba/envs/ffmpeg/bin:$PATH
WHISPER_PY=/home/renanzai/mamba/envs/whisper/bin/python3

$WHISPER_PY -c "
import whisper, json
model = whisper.load_model('base', device='cpu')
result = model.transcribe('项目/03_video/audio_voiceover.wav', language='zh', task='transcribe')
with open('项目/03_video/whisper_result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(f'Done: {len(result[\"segments\"])} segments, ends at {result[\"segments\"][-1][\"end\"]:.2f}s')
"
```

## SRT 生产三条铁律（2026-05-17 固化，永久标准）

同时满足，缺一不可：

**① 断句：Whisper segment = SRT entry**
每个 Whisper ASR segment = 一个独立 SRT entry，不合并、不拆分。不做字数均分估算，不做 segment 合并。

**② 时间轴：Whisper 真实 start/end**
时间戳直接取 Whisper JSON segments 的 `start`/`end` 值，不二次估算。Whisper 输出几个 segment，就生成几个 entry。

**③ 文本：Whisper原文 + 繁→简 + 纠错**
- 文本来源 = Whisper ASR 输出原文（非 MiniMax 脚本，但需繁→简转换）
- 繁→简转换：Whisper 输出繁体（如"2535億"、"簽完了"、"幫你"）→ 简体
- 纠错：Whisper 常错词（见下方清单）→ 修正后写入 SRT
- 品牌名"壹目贯维"如被听成"壹目惯为"/"壹目贯为"→ 必须修正

**繁→简 + 纠错函数（每次生成 SRT 必须调用）：**

```python
import re

TC2SC = {
    '億':'亿','簽':'签','嗎':'吗','們':'们','來':'来','開':'开',
    '過':'过','業':'业','時':'时','國':'国','會':'会','為':'为',
    '麼':'么','讓':'让','見':'见','這':'这','說':'说','書':'书',
    '與':'与','認':'认','間':'间','題':'题','從':'从','義':'义',
    '經':'经','當':'当','場':'场','僅':'仅','響':'响','處':'处',
    '總':'总','點':'点','號':'号','變':'变','環':'环','復':'复',
    '運':'运','據':'据','層':'层','線':'线','數':'数','網':'网',
    '機':'机','樣':'样','報':'报','東':'东','選':'选','關':'关',
    '動':'动','實':'实','類':'类','標':'标','觀':'观','達':'达',
    '長':'长','電':'电','體':'体','員':'员','制':'制','單':'单',
    '無':'无','產':'产','熱':'热','價':'价','難':'难','學':'学',
    '種':'种','戰':'战','爭':'争','備':'备','穩':'稳','構':'构',
    '研':'研','發':'发','裝':'装','籤':'签','內':'内','驗':'验',
    '顯':'显','滿':'满','確':'确','範':'范','圍':'围',
}

def fix_srt_text(text):
    """Whisper ASR 输出文本修正：繁→简 + 纠错"""
    for tc, sc in TC2SC.items():
        text = text.replace(tc, sc)
    text = re.sub(r'感搞', '赶稿', text)
    text = re.sub(r'熱鬥|熱斗', '热度', text)
    text = re.sub(r'搞子', '稿子', text)
    text = re.sub(r'戰比', '占比', text)
    text = re.sub(r'秘樂期', '蜜月期', text)
    text = re.sub(r'穩定氣', '稳定器', text)
    text = re.sub(r'外交磁力', '外交辞令', text)
    text = re.sub(r'排大腿', '拍大腿', text)
    text = re.sub(r'是而不见', '视而不见', text)
    text = re.sub(r'牛是', '牛市', text)
    text = re.sub(r'丁热点', '盯热点', text)
    text = re.sub(r'深沉', '生成', text)
    text = re.sub(r'使得的', '时代的', text)
    text = re.sub(r'淘宝星期', '淘宝兴起', text)
    text = re.sub(r'实险贵', '实际贵', text)
    return text.strip()
```

**Whisper 常错词对照表（必须修正）：**

| 原文 | Whisper 常见错误 |
|------|----------------|
| 壹目贯维 | 壹目惯为/壹目贯为/一目贯为 |
| 智能发布 | 只能发布 |
| 热度已经过了 | 熱鬥已經過了 |
| 调整排期 | 調整排期 |

### Step 3 — 生成 SRT（两条铁律）

**铁律一**：文本 = MiniMax 脚本原文，Whisper ASR 只提供时间戳  
**铁律二**：时间戳 = Whisper JSON 真实 segment 的 start/end 值，不得估算（2026-05-17教训：总时长均分估算导致用户反馈"音画不同步"，见 `references/srt-timing-fix-2026-05-17.md`）

**Whisper 易错的词（必须对照脚本逐字核对）**：
- 壹目贯维 → Whisper 听成"壹目惯为"/"壹目贯为"/"一目贯为"
- 智能发布 → Whisper 听成"只能发布"
- 2535亿美元 → Whisper 听成"2535億美元"/"2535亿美元"

**SRT 每 Entry = 一个完整句子**：逗号/顿号结尾的 Whisper 碎片 → 合并到前一句或后一句，形成句号/问号/感叹号结尾的完整 entry。

**⚠️ 单行 Entry 设计原则（2026-05-15 固化）**：
- **每个 SRT entry 只含一行文字**。多行 entry（含多句）在 PIL 渲染时会导致多行叠加，Vision QA 失败。
- 45字/entry 是必要条件但不够——即使用 `\\n` 分行，超过3行的 entry 仍会在 Vision QA 报4-5行叠加。
- **设计目标：每个 entry = 一句完整语音，字数 5-20 字。**
- 超过2行的 entry 必须拆分成独立的单行 entry，时间轴按比例分配。

### Step 4 — 长 Entry amplitude scan（>10s 必须执行）

Entry 超过 10 秒时**必须** amplitude scan 找静音断点，不得跳过。

```bash
# 截取目标音频段
ffmpeg -y -ss T_START -t T_DUR -i 音频.wav -vn -ac 1 -ar 16000 /tmp/section.wav

# amplitude scan
python3 -c "
import struct, math
with open('/tmp/section.wav','rb') as f:
    f.read(44); data = f.read()
samples = struct.unpack('<{len(data)//2}h', data)
window = 1600  # 16kHz x 0.1s
for i in range(0, len(samples)-window, window):
    rms = math.sqrt(sum(x*x for x in samples[i:i+window]) / window)
    t = i/window * 0.1
    sil = 'SILENCE' if rms < 200 else ''
    bar = '#' * int(rms/500)
    print(f't={t:.1f}s: {rms:6.0f} {bar} {sil}')
"
```

静音阈值：RMS < 200 连续 > 0.3s → 断点。  
Trump 实测断点：44.6-45.2s（静音 0.6s）、54.4-55.9s（静音 1.5s）。

---

## TTS 策略选择（2026-05-14 新增）

## 字幕烧录方式选择（2026-05-14 新增）

## 烧录后截断（必须执行）

burn_subtitles.py 重新编码后，视频时长经常偏离音频（实测：音频 59.7s → ffprobe 报 64.5s）。

**验证方法**：以 `frame=` 行中 `time=` 值为准，不是 ffprobe Duration：
```bash
ffmpeg -i burned.mp4 -f null - 2>&1 | grep "frame=.*time=00:00:59"
```

**截断到精确音频时长**：
```bash
ffmpeg -y -i burned.mp4 -t 59.688 -c:v copy -c:a copy output.mp4
```
`t` 后面跟精确到毫秒的音频时长。

---

## 竖屏字幕标准（720x1280 / 1080x1920）

## 🚨 铁律：每句语音存在的时间内，有且仅有这一句的文字

> 本 skill 为字幕生产与视频验收的底层逻辑。违反此铁律的视频不得提交。
>
> **判定标准**：任意时刻画面上出现的字幕行数 > 1，即为不合格。
>
> **通过标准**：任意时刻画面上出现 1 行字幕，且该行字幕的内容 = 该时刻正在被念的那句语音的文字。
>
> 不接受"2行是设计意图/品牌露出"的解释。行数 > 1 = 叠加 = 违反铁律。

### 单行铁律的自检方法

每个 entry 的文字必须满足：

```
该 entry 的字幕文字 ÷ 该 entry 的时长 = 一行能读完
```

具体操作：
1. Whisper 跑完后，看每个 segment 的时长
2. 时长 > 3s 的 segment 如果文本超过 20 字符 → 必然多行 → 必须拆分
3. 拆分基准：Whisper segment 边界，不是"我觉得这里可以断开"
4. 如果 Whisper 把一个语义完整的句子切成两个 segment，以**短的那段**的时长为准，判断长的那段是否需要拆分

### SRT 层问题修复_protocol（SRT-only Fix，重要）

**问题发生时，判断问题在哪一层：**

```
脚本有错？
  → 重建 SRT（文字替换），视频资产不变
  → PIL 烧录字幕层（不重建视频）

视频资产有错（画面/构图/分辨率/时长本身）？
  → 重建视频资产
```

**SRT-only Fix 的正确路径：**

```
问题发现 → 仅替换 SRT 文件 → PIL 重新烧录字幕 → 完成
     ↓
绝对不重新生成图片
绝对不重新拼接视频
绝对不重新合并音频
```

**SRT 层问题只修 SRT 的判断标准：**
- 画面内容/构图/分辨率没有问题 → 不重建视频
- 音频没有问题 → 不重建音频
- 只修字幕文字错误、时间轴错位、行数超标

**重建视频的判断标准（必须同时满足）：**
- 画面构图有硬伤（竖屏里出现 1:1 裁切黑边）
- 分辨率不对（不是 1080×1920）
- 视频时长和音频时长差 > 1s
- 上述问题有一个存在 → 重建视频

> **2026-05-14 新增。核心标准：一段语音在念的同时，画面上也只有这段语音对应的文字作为字幕。画面上不堆叠、不错位、不同时显示两句以上。这是人类观感层面的音画同步，不是技术层面的时长对齐。**

烧录完成后、提交之前，**必须**执行此检查。

### 检查方法（三帧）

```bash
# 抽取三帧：t=1s、中段（MID=总时长/2）、末尾（END=总时长-2s）
TOTAL=$(ffprobe -v error -show_entries format=duration -of csv=p=0 video.mp4)
ffmpeg -y -ss 1 -i video.mp4 -vframes 1 /tmp/qa_frame_1s.jpg
ffmpeg -y -ss $(python3 -c "print($TOTAL/2)") -i video.mp4 -vframes 1 /tmp/qa_frame_mid.jpg
ffmpeg -y -ss $(python3 -c "print($TOTAL-2)") -i video.mp4 -vframes 1 /tmp/qa_frame_end.jpg
```

用 vision 工具逐帧检查 `/tmp/qa_frame_*.jpg`。

### 通过标准

| 检查项 | 标准 |
|--------|------|
| **字幕行数** | 任何帧上**不超过一行**字幕 |
| **字幕内容** | 与该帧语音**完全对应**（用原始脚本对照） |
| **换行时机** | 语音结束时字幕才切换，不提前不滞后 |
| 无双重字幕 | 没有新旧字幕叠加 |
| 无字幕截断 | 字幕文字在画面宽度内，无左右裁切 |

### 不合格典型表现

- 两行字幕同时显示（FFmpeg ASS concat bug，PIL方案不会出现）
- 字幕提前出现（语音开始前就显示了）
- 字幕滞留（语音结束后字幕仍显示）
- 画面对应错误（这段语音配了下一句字幕）

> ⚠️ 技术时长对齐 ≠ 人眼感受。ffprobe 报告时长与音频完全一致，不等于人眼看到的是音画同步。即使音频60s、视频60s，如果字幕和语音错位半句，画面仍然不合格。

---

## 强制执行项（本 session 新增，2026-05-16）

### 0. burn_subtitles.py fps 参数（2026-05-19 新增，已修复）

> ⚠️ **调用 burn_subtitles.py 必须加 `--fps 2`**，否则时间戳计算错误。详见 `references/ass-subtitle-bugs-2026-05-19.md`。

### 0. burn_subtitles.py gap-fill 修复（2026-05-17 重大更新）

> ⚠️ **AI-era 项目教训**：SRT entries 之间的静音间隙会导致 concat 视频时长远小于音频时长。
> AI-era：音频 64.0s，concat 视频 55.1s（差 8.9s）。

**根因**：Whisper ASR 在句子间有自然停顿（300-600ms）。concat 每段视频时长 = entry 时长，entries 之和 ≠ 音频时长（含静音 gap）。

**解法**：burn_subtitles.py 在 concat 前自动对 gap > 150ms 的位置插入 hold-frame 段（取当前 entry 末尾帧作背景的静止画面）。

**效果**：AI-era 重做后 63.6s ≈ 音频 64.0s ✅

**验证**：音频时长 - ffprobe 视频时长 < 1s 才算合格。
```bash
AUDIO_DUR=$(ffprobe -v quiet -show_entries format=duration -of csv=p=0 audio_voiceover.mp3)
VIDEO_DUR=$(ffprobe -v quiet -show_entries format=duration -of csv=p=0 output.mp4)
python3 -c "print(abs($AUDIO_DUR - $VIDEO_DUR) < 1.0)"
```

### 1. Whisper 必须用 CPU（--device cpu）

**禁止**：在 GPU 上跑 Whisper（WSL 环境 GPU 有 NaN 问题，导致全段输出 nan）

**正确**：`whisper ... --device cpu`

```bash
# 正确
whisper audio.wav --model small --language zh --output_format srt \
  --output_dir /tmp/ --device cpu

# 错误（默认走 GPU → nan 输出）
whisper audio.wav --model small --language zh
```

Memory 里记了 GPU 有 NaN，但 subagent 不读 memory。**必须在 delegation 和 skill 里双重显式声明 `--device cpu`**。

### 2. SRT 时间戳禁止估算——必须用 Whisper 真实输出

**禁止**：用脚本字数 ÷ 总时长 估算每个 entry 的时间戳。

**正确**：Whisper 输出 JSON 的 `segments[].start/end` 就是真实时间轴，直接用，不二次估算。

```python
# 正确
for seg in whisper_result["segments"]:
    start, end = seg["start"], seg["end"]
    text = original_script_text  # 文本用原文，不信任 Whisper ASR 文本

# 错误（严格禁止）
per_entry = total_duration / num_entries  # 纯估算，与实际语音节奏无关
```

### 3. Whisper ASR 特定词必错——必须 post-edit

以下词汇 Whisper small 模型识别错误率极高，**必须对照原文逐字核对后写入 SRT**：

| 原文 | Whisper 常见错误 |
|------|----------------|
| 元首 | 援手 |
| 会晤 | 会务 |
| 峰会 | 会务 |
| 达成重要共识 | 达成重要共合 |

**操作流程**：Whisper 输出只取时间戳 → 文本替换为 MiniMax 脚本原文 → 写入 SRT。

### 4. burn_subtitles.py 的 ffprobe bug（2026-05-16）

脚本内 `get_dur()` 调用 ffprobe 查音频时长，但 ffprobe 不在 PATH 且 stdout 被 DEVNULL 截断，返回空字符串导致 ValueError。**使用前手动确认音频时长**：

```bash
# 先查好音频时长
ffprobe -v quiet -show_entries format=duration -of csv=p=0 audio.wav
# 35.496

# 调用时传入 audio_dur_override
burn(video, audio, srt, output, audio_dur_override=35.496)
```

**后续行动**：更新 `scripts/burn_subtitles.py` 的 `get_dur()` 使用 ffprobe 绝对路径 `/home/renanzai/bin/ffprobe` 或 `/usr/bin/ffprobe`，并移除 DEVNULL 重定向。

### 5. raw 视频时长 < 音频时长——seek 时间必须 clamp

FFmpeg concat 生成的 raw 视频，时长经常比音频短几秒（concat 拼接段时产生截断）。提取帧烧录时，**seek 时间不能超过视频安全上限**：

```python
VIDEO_SAFE_UPPER = 53.9  # 实测：54.5s 视频实际最后一帧约 53.9s
def safe_seek(raw_ts, safe_upper=VIDEO_SAFE_UPPER):
    return min(raw_ts, safe_upper - 0.05)
```

**检测方法**：
```bash
ffmpeg -y -ss 54.4 -i raw_video.mp4 -vframes 1 /tmp/test.jpg
# 如果输出 "video:0KiB" "nothing was encoded" → 该时间点已超出视频范围
```

### 6. Vision QA 必须覆盖封面图——禁止显式文字

封面图生成后，Vision QA 必须明确检查"图片中是否有文字"。案例：国家反诈中心 APP 封面，盾牌上显式写着 "AI" 字母，违反"禁止文字"规范，但 subagent 未检查直接使用。

**封面图 Vision QA 四项必查**：
1. 文字（中文/英文/符号）—— 禁止任何文字
2. 地图/地球仪/大陆轮廓
3. 品牌 Logo（YouTube/OYO/OpenAI/百度等）
4. 政治人物/明星清晰肖像

---


---

## 章节导航（JiT Loading）

> 主文件保留核心流程。以下章节已移至 references/，按需加载：

| 章节 | Reference | 行数 |
|------|-----------|------|
| Gotchas（高频踩坑，高价值必读） | `references/gotchas.md` | 266 |
| burn_subtitles.py 正确调用方式（2026-05-17 重大更新） | `references/burn-subtitles-correct-usage.md` | 48 |
| 视频大标题生成规范（2026-05-17 新增） | `references/video-title-generation-spec.md` | 44 |
| ⚠️ wrap_text 中文换行铁律（2026-05-14 新增） | `references/wrap-text-chinese-wrap-rule.md` | 42 |
| ⚠️ SRT Entry 字数限制与 PIL 渲染（2026-05-15 新增） | `references/srt-entry-char-limit.md` | 31 |
| 策略 A：逐条 TTS（推荐，碎片率低） | `references/tts-strategy-a-per-entry.md` | 21 |
| 视频大标题（封面/开头醒目大字）2026-05-17 新增 | `references/portrait-video-title.md` | 15 |
| 方式 1：PIL 逐帧烧录（推荐，渲染可靠） | `references/burn-method-1-pil.md` | 13 |
| 口播字幕（说话台词小字） | `references/portrait-subtitle-small.md` | 13 |
| burn_subtitles.py 调用示例 | `references/burn-subtitles-example.md` | 13 |
| 方式 2：FFmpeg ASS subtitles（仅预览） | `references/burn-method-2-ass.md` | 10 |
| 策略 B：全量拼接后 Whisper（备用，有碎片风险） | `references/tts-strategy-b-concat-whisper.md` | 8 |
| 碎片根因 | `references/fragment-root-causes.md` | 8 |
| 参数对照表 | `references/portrait-params-table.md` | 7 |
| ⚠️ 视频大标题设计原则 | `references/video-title-design-principles.md` | 7 |
