---
name: video-redo
description: "视频重做触发规范——当用户说「重新做/修复/修正」时必须加载。强制执行问题层判断 + 精准修复，禁止从头重建整个项目。修复后必须三帧 Vision QA 通过才算完成。"
tags: [video, redo, fix, subtitle, production-pipeline]
---

# Video Redo Skill · 视频重做触发规范

> ⚠ **2026-06-13 更新**：以下命令和路径为 Remotion 旧规范。视频生产已迁移至 HyperFrames（`video-production/hyperframes-workflow`）。
>
> 如果用户要求重做的是 HyperFrames 视频，执行：
> ```bash
> # 1. 编辑 HTML composition 文件
> # 2. bun x hyperframes lint
> # 3. bun x hyperframes render --quality standard
> ```
>
> 下方 Remotion 特定命令仅供参考（已归档至 `archived/`），不再执行。

> **触发条件（满足任一即触发）**：用户说"重新做"、"重做"、"修复"、"修正"、"再改"、"还是不对"、"不行"任意关键词。
>
> **本 skill 强制加载。禁止在未加载本 skill 的情况下给 subagent 写 redo 任务描述。**

## 核心原则

### 重做 ≠ 从头生产

重做的目标是**精准修复问题层**，不是用更大火力把整件事重新做一遍。

错误思路：
- "SRT 有错字" → 重建视频 → 图片也重建 → TTS 重建 → 修了 4 轮引入 4 组新问题

正确思路：
- "SRT 有错字" → 只换 SRT → PIL 重新烧录 → 验证字幕层 → 完成

### 用户反映现象，不反映层

> 用户说"视频中间有字"，不是说"字幕层有问题"。用户描述的是现象，不是层定位。
>
> 不要反问"是字幕层还是视频资产层"——先检查视频资产层（封面图本身就带字是最高频原因），再查字幕层。

**现象优先原则**：

| 用户描述 | 默认假设（先查） | 备选 |
|----------|-----------------|------|
| "视频中间有大字" | 封面图本身就带了字（最高频） | 帧图里有嵌入文字 |
| "底部字幕位置不对" | burn_subtitles.py 烧录失败（检查脚本 + raw 视频尺寸） | SRT 时间轴错 |
| "字幕不对" | 文字错 → SRT 层 | 时间轴错 → SRT 层 |
| "视频有黑边" | 视频资产拼接问题 | 分辨率不对 |

**禁止**：因为用户说"有字幕问题"就先入为主认为字幕层有问题。"有字"和"字幕错"是两回事。

## 问题定位判断树

## 问题定位判断树

遇到视频问题，按以下顺序判断问题在哪一层：

```
问题现象
  ↓
是不是字幕文字/时间轴错？
  → 是 → SRT 层问题
  ↓ 不是
是不是视频画面/构图/分辨率有硬伤？
  → 是 → 视频资产层问题
  ↓ 不是
是不是音频本身有问题（音色/内容/节奏）？
  → 是 → 音频层问题
  ↓ 不是
是不是 Composition 渲染代码本身有错（5 段同时渲染/视觉残留/段边界硬编码）？
  → 是 → Composition 代码层问题（**🆕 第 4 层，2026-06-05 Alphabet/Codex 案例固化**）
  ↓ 不是
其他 → 未知层，逐层排查
```

---

## 各层修复标准工作流

### SRT 层问题（文字错 / 时间轴错 / 行数超标）

**症状**：字幕有错字、时间轴不对、某 entry 超过 3 行

**修复路径**：
```
1. 在原音频文件上重新跑 Whisper CPU（--device cpu）
   → 拿到真实时间轴
2. 用 TTS 脚本原文替换 Whisper ASR 文本（Whisper 只管时间轴，不管文字）
3. 生成新的 SRT（每 entry = 一行文字，不超 45 字）
4. 用 burn_subtitles.py（PIL 方式）重新烧录字幕
   → 必须用 hermes-agent venv 的 Python：
     /home/renanzai/.hermes/hermes-agent/venv/bin/python3
   → 必须用 ffmpeg 绝对路径：
     /home/renanzai/mamba/envs/ffmpeg/bin/ffmpeg
5. 三帧 Vision QA（t=1s / 中段 / 末尾）
6. 音频/视频资产/封面图 零改动
```

**禁止**：
- ❌ SRT 有错字 → 重新生成封面图
- ❌ SRT 有错字 → 重新 TTS
- ❌ 用字数估算时间轴（必须用 Whisper 真实时间戳）

---

### 音频层问题（音色不对 / 节奏不对 / 内容错）

**症状**：音频本身有问题（不是字幕问题）

**修复路径**：
```
1. 重新 TTS（用原脚本）
2. 新音频生成后，立即将音频文件复制到项目目录
3. 在新音频上跑 Whisper CPU → 拿到新的真实时间轴
4. 用脚本原文替换 Whisper ASR 文本 → 生成新 SRT
5. 用新音频 + 新 SRT + 原封面图 + 原视频资产 → 重新拼接
6. 三帧 Vision QA
```

禁止：
- ❌ 新音频 + 旧 SRT（时间轴和音频不匹配）
- ❌ 新音频 + 旧 Whisper JSON（时间轴是旧音频的）

---

### 🆕 Composition 代码层问题（5 段同屏渲染 / 视觉残留 / 段边界硬编码）

**症状**（2026-06-05 Alphabet/Codex 实测）：
- 用户反馈"视频内容不对"或 vision QA 看到"美容 SCENE" / "护肤品" / "v10 模板视觉"
- 5 段视频但 **5 段 AbsoluteFill 同时渲染**（不是顺序切换）→ 看到 5 个 frame 重叠
- **v10 视觉残留**：字幕底 `rgba(7,197,95,0.92)` 绿色 / 标题 `#07c55f` 品牌色
- 段边界用 50s 占位（不依赖 SRT 真实时间戳）→ 视频末 11s/10s 无字幕
- assertTotalFrames 用占位时长（不基于 mp3 实测）→ render panic 或 A/V 错位

**根因**（3 层叠加）：
1. **Composition 用了错的导入路径**：`import { TransitionSeries } from "remotion"` ❌ → 应是 `import { TransitionSeries, linearTiming } from "@remotion/transitions"` ✅
2. **用了字符串 API**：`presentation="fade" timing="linear"` ❌ → 应是函数 API `presentation={fade()} timing={linearTiming({ durationInFrames: N })}` ✅
3. **5 段顺序切换的 Composition 写成了 AbsoluteFill 同屏堆叠**：导致视频看起来是"5 帧图同时显示"而不是"5 段顺序切换"

**修复路径**（精准修复，**禁止**重做 SRT/音频/视频资产）：
```
1. 备份旧 Composition.tsx 到 out/<topic>_v1_known_visual_bug.tsx.bak
2. 用 vision_analyze 看 5 张 frame 图本身
   → 如果图本身质量 9/10+ → 保留图，不重做
   → 如果图本身有问题 → 重新 ComfyUI 生成
3. 改 src/<Topic>Composition.tsx：
   a. 修 import 路径（@remotion/transitions + @remotion/transitions/fade）
   b. 改 Transition API 为函数形式
   c. 5 段用 <TransitionSeries.Sequence> 顺序切换
   d. 段边界用 srtTimeToFrame("HH:MM:SS,mmm") 算（从 SRT 真实 entry 起止）
   e. assertTotalFrames 时长用 ffprobe 实测 mp3 时长（不是文件大小估算）
   f. SubtitleCard 字幕底改黑色半透（rgba(0,0,0,0.72)）—— 禁绿色
   g. SceneBlock 标题改白色 + 深阴影 —— 禁绿色品牌色
4. 跑 linter：python3 ~/.hermes/profiles/content/skills/remotion-timecode-anti-pattern/scripts/check_composition_timecode.py src/<Topic>Composition.tsx
   → exit 0 才放行
5. 跑 render_with_qa.sh wrapper（**不要直接 bunx remotion render**）：
   bash scripts/render_with_qa.sh <TopicComposition> out/<topic>.mp4 <tts.mp3> <subtitle.srt>
6. 5 帧 Vision QA（5 段中点帧各 1 张）→ user 验收

禁止：
- ❌ 视觉残留 → 重新 TTS
- ❌ 5 段同屏 → 重新 SRT
- ❌ 占位时长错 → 重新生成 frame 图
- ❌ 任何层问题 → 都用 Composition 重写整套（违反"精准修复"原则）

关键反模式（**Composition 修复专项，2026-06-05 实测**）：
- ❌ 跳过 linter 直接渲染 → mp3 实际时长 ≠ assertTotalFrames 期望 → render panic
- ❌ 用 `bunx remotion render` 直接渲染 → 绕开 render_with_qa.sh 的 step 1 时长对齐 → 视频和 mp3 长度差 16.57s
- ❌ TransitionSeries 从 "remotion" 导入 → 渲染第一帧 `Cannot read properties of undefined (reading 'Sequence')` panic
- ❌ `presentation="fade"` 字符串 API → TypeScript 编译失败或运行时无 transition 效果
- ❌ 用 srtTimeToFrame("00:00:40,400") 估 mp3 末 → 实际 mp3 是 56.95s → 视频 16.57s 静音尾巴

完整 6-05 实测记录 + 6 个 Composition.tsx 代码段 + Vision QA 5 帧图：见 `references/2026-06-05-alphabet-codex-v10-to-v3-redo.md`
```

---

### 视频资产层问题（封面图有文字/地图/Logo / 分辨率不对 / 画面构图硬伤）

**症状**：图片有乱码/禁用元素，分辨率不是 1080×1920，构图有黑边

**修复路径**：
```
1. 重新生成该张图片（ComfyUI SD 1.5，旧方案 MiniMax image-01 已停用）
2. Vision QA 必须通过（文字/地图/Logo/人脸）
3. 用新图片替换对应帧
4. 音频/字幕/SRT 零改动
```

**禁止**：
- ❌ 图片有问题 → 重新 Whisper
- ❌ 图片有问题 → 重新 TTS

---

## 工具使用规范（重做场景）

### burn_subtitles.py 调用

必须用 terminal 工具执行（不是 execute_code）：
```bash
PYPIL=/home/renanzai/.hermes/hermes-agent/venv/bin/python3
FFMPEG=/home/renanzai/mamba/envs/ffmpeg/bin/ffmpeg

$PYPIL /home/renanzai/.hermes/skills/media/subtitle-production/scripts/burn_subtitles.py \
  /path/to/video_raw.mp4 \
  /path/to/audio.wav \
  /path/to/subtitle.srt \
  /path/to/output.mp4
```

### Whisper 必须 CPU

```bash
whisper /path/to/audio.wav \
  --model small --language zh \
  --output_format json \
  --output_dir /tmp/whisper_out/ \
  --device cpu
```

### 三帧 Vision QA（重做后必须执行）

```bash
TOTAL=$(ffprobe -v error -show_entries format=duration -of csv=p=0 video.mp4)
ffmpeg -y -ss 1 -i video.mp4 -vframes 1 /tmp/qa_1s.jpg
ffmpeg -y -ss $(python3 -c "print($TOTAL/2)") -i video.mp4 -vframes 1 /tmp/qa_mid.jpg
ffmpeg -y -ss $(python3 -c "print($TOTAL-2)") -i video.mp4 -vframes 1 /tmp/qa_end.jpg
```

---

## Redo 任务描述写法

给 subagent 写 redo 任务时，**禁止只描述 symptom**。必须同时加载 `subtitle-production` skill（它包含完整的正确工作流），并向 subagent 传递：

1. **问题层判断**（SRT / 音频 / 视频资产）
2. **禁止事项**（这层修复不涉及哪些层）
3. **完整工作流**（引用 subtitle-production 的标准步骤，不是重新发明）
4. **验收标准**（三帧 Vision QA 通过）

**错误写法**：
> "SRT 有错字，重新修正一下"

**正确写法**：
> "SRT 层问题：文字错（'援手'应为'元首'）。只修 SRT，不动音频/视频资产/封面图。
> 完整流程（见 subtitle-production skill）：
> 1. Whisper CPU 拿时间轴（--device cpu）
> 2. 原文替换文字（Whisper 只管时间轴，文本用 TTS 脚本原文）
> 3. burn_subtitles.py PIL 烧录（传 safe_upper 参数）
> 4. 三帧 Vision QA
> 禁止：重新生成封面图 / 重新 TTS / 用字数估算时间轴"

**subagent 不读 skill**——delegation 里必须显式写出关键约束（--device cpu、safe_upper、必须用 terminal 不是 execute_code），不能假设 subagent 会去查 skill。

---

## 问题定位自检清单（重做前必填）

| 问题 | 层 | 修复 |
|------|----|------|
| 字幕文字错 | SRT | 换 SRT → PIL 烧录 |
| 字幕时间轴错 | SRT | 换 SRT → PIL 烧录 |
| 字幕行数超标 | SRT | 换 SRT → PIL 烧录 |
| 字幕位置在中间 | SRT | 换 SRT → PIL 烧录（检查 burn_subtitles.py 是否失败） |
| 音画不同步（字幕对但语音错） | 音频 | 重新 TTS → 新音频跑 Whisper → 新 SRT |
| 封面图有文字/Logo | 视频资产 | 重生成该图 → Vision QA → 替换 |
| 分辨率不是 1080×1920 | 视频资产 | 重建视频拼接 |
| 视频有黑边/构图硬伤 | 视频资产 | 重建视频拼接 |

## ⚠️ Redo 后的文件发送铁律（2026-05-16 新增）
## ⚠️ FFmpeg concat demuxer + fps filter 时长 Bug（2026-05-19 实测）

**症状**：图片序列视频烧录后，音频结束但视频继续播放（"后半段没声音但有画面"）。

**根因**：`ffmpeg -f concat -safe 0 -i imgs.txt -vf "fps=2" -t 30 video.mp4` —— concat demuxer 的 `duration` directives + 全局 `fps` filter 无法精确控制每张图的显示时长，导致输出视频 ≠ 音频时长。

**正确链路**：
```bash
# 每张图独立片段：fps=1 + -t 精确秒数
for i in $(seq 1 8); do
  ffmpeg -y -loop 1 -i "img_${i}.png" -t $PER_IMG \
    -vf "fps=1,scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2" \
    -c:v libx264 -preset fast -crf 23 -pix_fmt yuv420p -an \
    "/tmp/segs/seg_$(printf %02d $i).mp4"
done

# concat filter（不用 demuxer）
FILTER="[0:v]"
for i in $(seq 1 7); do FILTER="${FILTER}[${i}:v]"; done
FILTER="${FILTER}concat=n=8:v=1:a=0[outv]"
BUILD="-i /tmp/segs/seg_01.mp4"
for i in $(seq 2 8); do BUILD="$BUILD -i /tmp/segs/seg_$(printf %02d $i).mp4"; done
ffmpeg -y $BUILD -filter_complex "$FILTER" -map "[outv]" \
  -c:v libx264 -preset fast -crf 23 -pix_fmt yuv420p /tmp/video_only.mp4

# 合并音频
ffmpeg -y -i /tmp/video_only.mp4 -i /tmp/audio.wav \
  -map 0:v -map 1:a -c:v copy -c:a aac -b:a 128k -shortest /tmp/video_audio.mp4
```

详见：`references/ffmpeg-image-sequence-timing-2026-05-19.md`

---

## ⚠️ burn_subtitles.py NoneType Bug（2026-05-19 实测已修）

**症状**：`Processed 46/47 frames` 或 `Processed 53/63 frames` —— 有帧处理失败。

**根因**：`add_subtitle_to_frame` 中 `if '\n' in active_text` —— 当某帧不在任何字幕时间段时 `active_text=None`，`None in str` 抛出 `TypeError: argument of type 'NoneType' is not iterable`。

**已在脚本层修复**（加 `if not active_text: img.save(); return True` guard），但重做时如果复现，检查 `active_text` 是否在访问前做了 `None` 检查。

---

## ⚠️ Redo 后的文件发送铁律（2026-05-16 新增）

**最常见的 redo 失败模式**：修复完成 → 重新烧录 → Vision QA 通过 → **发给了用户旧文件**（路径变了但以为没变）。

典型路径混淆：
```
/tmp/video1_final.mp4   ← Vision QA 检查的是这个
     ↓ rename after QA
/tmp/video_final.mp4   ← 发给用户的是这个（不是 QA 过的！）
```

**强制要求**：

1. Vision QA 完成后，立即把输出文件路径写死到任务状态里，发送时必须发**同一个文件**
2. 重新烧录时，**覆盖旧文件**而不是生成新文件（`output.mp4` 覆盖 `output.mp4`，不是 `output_v4.mp4`）
3. 如果必须保留旧版做对比，文件名必须能明确区分：`{topic}_final.mp4` vs `{topic}_before_fix.mp4`

**禁止**：Vision QA 通过后改名再发。发的必须是 QA 时检过的同一个二进制文件。
**禁止**：Vision QA 通过后改名再发。发的必须是 QA 时检过的同一个二进制文件。
