# 2026-06-05 Alphabet/Codex v10 → v3 重做实录

> **触发场景**：6-05 早上 8:30 cron 推送 Alphabet + OpenAI Codex 话题 → 主 agent 渲染 → user 反馈"两个视频生产出来的质量如此离谱"（codex 5s 帧看到"护肤品"）。
> **根因**：Composition 代码层有 4 个反模式叠加，不是 SRT/音频/视频资产问题。

## 背景

| 维度 | v1 (v10 残留) | v3 (重做后) |
|------|--------------|------------|
| 渲染代码 | 5 段 AbsoluteFill 同时渲染 | 5 段 TransitionSeries 顺序切换 |
| 字幕底 | `rgba(7,197,95,0.92)` 绿色 v10 残留 | `rgba(0,0,0,0.72)` 黑色半透 |
| 标题 | `#07c55f` 绿色品牌色 v10 残留 | `#fff` 白色 + 深阴影 |
| 段边界 | `srtTimeToFrame("00:00:56,951")` 占位 50s | 从 session 113223 SRT 真实 entry 算 |
| assertTotalFrames | `56.95` 占位估算 | ffprobe 实测 mp3 56.95s |
| S5 末字幕 | 16.57s 静音尾巴 | S5 段从 996 帧到 1708 帧（包含 CTA 字幕后 11s 视频停留） |
| TTS 实际时长 | 56.95s (1.4MB mp3, ffprobe) | 同上 |
| 视频最终时长 | 40.4s（v1 占位）| 56.9s（v3 = mp3 实际） |
| Frame 图 | 5 张 MiniMax m3 image-01 (86-110KB jpg) | 保留原图（vision QA 9.5/10，无 v10 残留）|

## 4 个根因（叠加而非独立）

### 根因 1：Composition 用了 `import { TransitionSeries } from "remotion"` ❌

**实际报错**：
```
An error occurred while rendering frame 1:
 TypeError  Cannot read properties of undefined (reading 'Sequence')
   at src/AlphabetAnthropicComposition.tsx:230
```

**正确 import**：
```typescript
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
```

**坑 2：字符串 API vs 函数 API**

```typescript
// ❌ 错（字符串）
<TransitionSeries.Transition
  durationInFrames={TRANSITION_DUR}
  timing="linear"
  presentation="fade"
/>

// ✅ 对（函数）
<TransitionSeries.Transition
  presentation={fade()}
  timing={linearTiming({ durationInFrames: TRANSITION_DUR })}
/>
```

**M3Composition.tsx 现有正确写法**（项目里的 reference）：
```typescript
<TransitionSeries.Transition
  presentation={fade()}
  timing={linearTiming({ durationInFrames: TRANSITION_DUR })}
/>
```

### 根因 3：5 段 AbsoluteFill 同屏堆叠（不是 TransitionSeries 顺序切换）

v1 错误写法（5 段同屏）：
```tsx
export const Composition = () => (
  <AbsoluteFill>
    <Audio src={...} />
    <SceneBlock image={SCENE_IMAGES[0]} ... />  {/* 5 段同时存在 */}
    <SceneBlock image={SCENE_IMAGES[1]} ... />
    <SceneBlock image={SCENE_IMAGES[2]} ... />
    <SceneBlock image={SCENE_IMAGES[3]} ... />
    <SceneBlock image={SCENE_IMAGES[4]} ... />
  </AbsoluteFill>
);
```

v3 正确写法（顺序切换）：
```tsx
export const Composition = () => (
  <AbsoluteFill>
    <Audio src={...} />
    <TransitionSeries>
      <TransitionSeries.Sequence durationInFrames={S1_DUR}>
        <SceneBlock image={SCENE_IMAGES[0]} ... />
      </TransitionSeries.Sequence>
      <TransitionSeries.Transition presentation={fade()} timing={linearTiming({ durationInFrames: TRANSITION_DUR })} />
      <TransitionSeries.Sequence durationInFrames={S2_DUR}>
        <SceneBlock image={SCENE_IMAGES[1]} ... />
      </TransitionSeries.Sequence>
      {/* ... 4 个 transition + 5 段 ... */}
    </TransitionSeries>
  </AbsoluteFill>
);
```

### 根因 4：占位时长 vs 实际 mp3 时长

**v1 错误（占位估算）**：
```typescript
// 5 段边界按 50s 占位
const S1_FROM = srtTimeToFrame("00:00:00,050");
const S1_TO   = srtTimeToFrame("00:00:04,509");  // 估算值
// ...
const S5_TO   = srtTimeToFrame("00:00:56,951");  // 占位 50s

assertTotalFrames(ALPHABET_TOTAL_FRAMES_RAW, 56.95, 30, 60);
```

**v3 正确（ffprobe 实测 mp3）**：
```bash
# 必须先跑这个
$ ffprobe -v error -show_entries format=duration -of csv=p=0 /path/to/audio.mp3
56.950000  # 实际 mp3 时长
```

```typescript
// S5_TO = mp3 实测末（不是 SRT 末）
const S5_TO = srtTimeToFrame("00:00:56,950");  // 56.95s
assertTotalFrames(ALPHABET_TOTAL_FRAMES_RAW, 56.95, 30, 8);
```

**关键发现**（srtTimeToFrame 输入是 mp3 末，不是 SRT 末）：
- session 113223 SRT 末 = 41.36s（10 entries）
- mp3 实测 = 56.95s
- **SRT 末 ≠ mp3 末**（session 113223 时代 SRT-mp3 不同步 bug）
- 视频末 15.55s 是 S5 段（CTA 字幕后 11s 视频停留，无字幕）
- **S5 末无字幕 = m3 precedent 视频收尾段，可接受**（m3Composition v10 也有这个模式）

## 5 Gate 验证结果

| Gate | v1 (坏) | v3 (修后) |
|------|--------|----------|
| 1. 时长对齐 | 视频 40.4s vs mp3 56.95s, 差 16.57s 🔴 | 视频 56.9s vs mp3 56.95s, 差 0.05s ✅ |
| 2. linter R1+R2+R3 | 跑整个 src/ 老 Composition FAIL | 单独跑新文件 PASS（linter 命令是 `check_composition_timecode.py src/<File>.tsx` 不是 `src/`）|
| 3. 5 段顺序切换 | 5 段同屏 | 顺序切换 + fade transition |
| 4. SRT 时序 | 7 entry 偏差 > 0.7s 🔴 (session 113223 SRT-mp3 末不同步) | 6 entry 偏差 > 0.7s 🔴 (同 session 113223 bug，**不是 Composition bug**)|
| 5. Vision QA 5 段 | 帧看到"护肤品" | 帧正常（保留原 9.5/10 frame 图）|

**Gate 4 BLOCK 根因**：session 113223 时代 SRT 末 41.36s vs mp3 末 56.95s 固有 15.55s 偏差，**不在本次重做范围**。根治需重生成 SRT + mp3（用户没要求）。

## 5 个 P0 改造（这次同时固化的）

虽然 d 选项只重做视频，但本次 session 还落地了 5 个 P0 工作流改造（写入 5 个 skill）：

| P0 | 改造内容 | 落地位置 |
|----|---------|---------|
| P0-1 | Selection Reuse Decision Gate（4 维相似度 ≥70 才考虑复用） | `automedia-production-guard` Gate V0 + `references/workflow-p0-refactor-2026-06-05.md` |
| P0-2 | Reuse Boundary Checklist（复用前必查清单） | 同上 |
| P0-3 | SRT 必存在 Gate（渲染前 SRT 文件必须存在） | `remotion-pre-render-gate` |
| P0-4 | session_lock.py（fcntl 防多 session 抢活） | `~/.hermes/profiles/content/scripts/session_lock.py` |
| P0-5 | V3 Content Semantic Match（关键词 80% 覆盖率，动态从 pool.db 提取） | `automedia-production-guard` Gate V3 |

## 关键决策树（重做时）

```
发现视频"内容不对"
  ↓
看 5 张 frame 图（mcp_minimax_understand_image）
  ├─ 图本身有问题（错图/乱码/分辨率错）→ 视频资产层 → 重生 frame 图
  ├─ 图 OK 但视觉是 v10 模板 → Composition 代码层（v10 残留）
  ├─ 图 OK 但 5 段同屏 → Composition 代码层（5 段渲染错）
  └─ 图 OK + 5 段顺序 + v3 视觉 → 视频正常，问题在 SRT/音频/视觉外
```

## 反模式清单（Composition 代码层）

| ❌ 反模式 | ✅ 正确做法 |
|---------|----------|
| `import { TransitionSeries } from "remotion"` | `import { TransitionSeries, linearTiming } from "@remotion/transitions"` |
| `import { fade } from "@remotion/transitions/fade"` 缺失 | 必须单独 import |
| `<TransitionSeries.Transition durationInFrames={N} presentation="fade" />` 字符串 | `<TransitionSeries.Transition presentation={fade()} timing={linearTiming({ durationInFrames: N })} />` 函数 |
| 5 段 AbsoluteFill 同屏 | 5 段 TransitionSeries.Sequence + Transition 顺序切换 |
| S5_TO 用 srtTimeToFrame("00:00:50,000") 占位 | 用 ffprobe 实测 mp3 末 + srtTimeToFrame |
| 跳过 linter 直接 bunx remotion render | 先跑 check_composition_timecode.py + 用 render_with_qa.sh wrapper |
| 修 Composition 时重做 frame 图 | 5 段视觉图保留（除非 vision QA 发现图本身有问题）|
| 字幕底 `rgba(7,197,95,0.92)` 绿色 v10 残留 | `rgba(0,0,0,0.72)` 黑色半透 |
| 标题 `#07c55f` 绿色 v10 残留 | `#fff` 白色 + 深阴影 |

## 完整修复代码段（Composition.tsx v3 关键 3 块）

### 1. import 块

```typescript
import "./index.css";
import {
  AbsoluteFill,
  useCurrentFrame,
  interpolate,
  spring,
  useVideoConfig,
  Img,
  staticFile,
} from "remotion";
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import { Audio } from "@remotion/media";
import { srtTimeToFrame, assertTotalFrames } from "./timecode";
```

### 2. 主 Composition 渲染块

```typescript
export const Composition: React.FC = () => {
  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>
      <Audio src={staticFile("audio/<topic>.mp3")} />
      <TransitionSeries>
        <TransitionSeries.Sequence durationInFrames={S1_DUR}>
          <SceneBlock image={SCENE_IMAGES[0]} subtitles={SCENE_SUBTITLES[0]} titleText={TITLE_TEXT} showTitle />
        </TransitionSeries.Sequence>
        <TransitionSeries.Transition presentation={fade()} timing={linearTiming({ durationInFrames: TRANSITION_DUR })} />
        <TransitionSeries.Sequence durationInFrames={S2_DUR}>
          <SceneBlock image={SCENE_IMAGES[1]} subtitles={SCENE_SUBTITLES[1]} titleText="" />
        </TransitionSeries.Sequence>
        <TransitionSeries.Transition presentation={fade()} timing={linearTiming({ durationInFrames: TRANSITION_DUR })} />
        <TransitionSeries.Sequence durationInFrames={S3_DUR}>
          <SceneBlock image={SCENE_IMAGES[2]} subtitles={SCENE_SUBTITLES[2]} titleText="" />
        </TransitionSeries.Sequence>
        <TransitionSeries.Transition presentation={fade()} timing={linearTiming({ durationInFrames: TRANSITION_DUR })} />
        <TransitionSeries.Sequence durationInFrames={S4_DUR}>
          <SceneBlock image={SCENE_IMAGES[3]} subtitles={SCENE_SUBTITLES[3]} titleText="" />
        </TransitionSeries.Sequence>
        <TransitionSeries.Transition presentation={fade()} timing={linearTiming({ durationInFrames: TRANSITION_DUR })} />
        <TransitionSeries.Sequence durationInFrames={S5_DUR}>
          <SceneBlock image={SCENE_IMAGES[4]} subtitles={SCENE_SUBTITLES[4]} titleText="" />
        </TransitionSeries.Sequence>
      </TransitionSeries>
    </AbsoluteFill>
  );
};
```

### 3. assertTotalFrames 用 ffprobe 实测

```typescript
// render 前必跑（Python 3）
import subprocess
mp3_dur = float(subprocess.check_output([
    "ffprobe", "-v", "error", "-show_entries", "format=duration",
    "-of", "csv=p=0", "/path/to/audio.mp3"
]).decode().strip())
# mp3_dur 传给 assertTotalFrames
```

## 完整 5 步执行流程（6-05 Alphabet/Codex 实测）

1. **备份旧版本**：`cp out/<topic>.mp4 out/20260605_143000_backup/<topic>_v1_session113223.mp4`
2. **看 frame 图**（mcp_minimax_understand_image 5 张）→ 9.5/10 质量，保留
3. **写新 Composition.tsx**（修 3 块：import / 5 段顺序 / 占位时长 → ffprobe）
4. **跑 linter**：`check_composition_timecode.py src/<File>.tsx` → exit 0
5. **跑 render_with_qa.sh wrapper**（不是 bunx 直接 render）：
   ```bash
   bash scripts/render_with_qa.sh <Comp> out/<file>.mp4 <tts.mp3> <srt>
   ```
6. **5 Gate 验证**：
   - Gate 1 时长对齐（视频 ≈ mp3, < 0.5s）→ PASS
   - Gate 4 SRT 时序偏差（注意区分 session 113223 时代 bug vs 本次 Composition bug）

## 教训（永久固化）

- **Composition 代码层问题 ≠ SRT/音频/视频资产问题** → 不能"重新做整套"（违反"精准修复"原则）
- **mp3 实际时长必须 ffprobe 实测**，不能用文件大小估算（1.4MB @ 128kbps ≠ 40.4s，可能是 56.95s）
- **TransitionSeries 在 @remotion/transitions 包**，不在 remotion 主包
- **Transition API 用函数（`fade()`, `linearTiming()`）**，不用字符串
- **跑 render_with_qa.sh wrapper**，不直接 bunx remotion render（wrapper 强制走 linter + 时长对齐）
- **linter 默认扫整个 src/ 目录**会因老 Composition FAIL → 单独跑新文件
- **5 段视觉图保留**（vision QA 9.5/10），不重做（节省时间 + 避免引入新问题）
- **S5 末无字幕 = m3 precedent 视频收尾段**，可接受（根治需重生成 SRT + mp3）
