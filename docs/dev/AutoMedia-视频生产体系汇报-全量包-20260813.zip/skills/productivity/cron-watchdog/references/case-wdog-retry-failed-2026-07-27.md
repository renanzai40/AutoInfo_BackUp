# Case: Auto-Retry Failed Completely — audit_08x05 (2026-07-27)

## Session Summary

Watchdog detected `audit_08x05` (AutoMedia 08:05 语义审核) had failed with `last_status=error`. Pre-check script `wdog_auto_retry.py` attempted auto-retry using `hermes cron run audit_08x05`, but the retry **failed to execute** within the 300s watchdog timeout window.

## Job Properties

| Field | Value |
|-------|-------|
| job_id | `audit_08x05` |
| name | AutoMedia 08:05 语义审核（Layer 3）+ 黑名单更新 |
| type | LLM agent job (`no_agent=false`) |
| schedule | `5 8 * * *` |
| depends_on | `["143d19e69a7c"]` (08:00 热点采集) |
| downstream depends | **none** (sidecar — no job has `depends_on` pointing to audit_08x05) |
| idle_timeout | 600s (implicit default) |
| script_timeout | not applicable (LLM agent, not script) |

## Error Details

**last_error:**
```
TimeoutError: Cron job 'AutoMedia 08:05 语义审核（Layer 3）+ 黑名单更新' idle for 602s (limit 600s) — last activity: waiting for non-streaming API response
```

**Error classification:**
- This is a **genuine LLM provider timeout** — unlike no_agent script jobs (where "provider timeout" is a misclassification), LLM agent jobs with "waiting for non-streaming API response" actually hung on a provider API call.
- The agent was blocked for 602s on a non-streaming completion call, exceeding the 600s idle limit.
- Root cause hypothesis: opencode-go provider-side latency or network interruption.

## Auto-Retry Outcome

| Verification Step | Result |
|-------------------|--------|
| Pre-check output | `⚠️ audit_08x5 auto-retry timed out after 300s` |
| jobs.json `last_status` | Still `error` (unchanged) |
| jobs.json `last_run_at` | Still `2026-07-27T08:15:52` (unchanged) |
| jobs.json `fire_claim` | Present (watchdog claimed at 09:30:18) |
| Output directory | No new file after the original `2026-07-27_08-15-52.md` |
| Running process (`ps aux`) | No audit_08x05 process found |
| **Conclusion** | **Retry did NOT execute** — `hermes cron run` queued the job to the async scheduler but it never ran before the 300s watchdog window expired |

**Why retry failed:** `audit_08x05` is an LLM agent job (`no_agent=false`). For LLM jobs, `hermes cron run` updates `next_run_at` to "now" and relies on the scheduler's tick cycle (typically ~60s) to pick up and execute. The watchdog pre-check script waited 300s, which was insufficient — the job may have been stuck behind other queued agent jobs, or the scheduler hadn't reached it yet.

## Pipeline Impact

```
09:30 │ watchdog runs ──────────┐
      │                        ├─ confirms audit still failed
      │                        └─ writes alarm
      │
08:30 │ 7671da210b69 (push) ✅ ─ pushes TOP3 from previously approved topics
      │
08:10 │ judge_angles_08x10 ✅ ── normal (independent of audit)
      │
08:05 │ audit_08x05 ❌ ───────── semantic audit hung, killed at 602s
      │
08:00 │ 143d19e69a7c (collect) ✅ ─ collected new topics (still pending review)
      │
07:30 │ maintenance_01 ✅
```

- **Sidecar**: audit_08x05 has `depends_on: ["143d19e69a7c"]` but **no downstream job depends on it**. The main production pipeline (08:00 → 08:10 → 08:30) continued unaffected.
- **Data quality impact**: Topics collected by today's 08:00 hot collection remain `review_status='pending'`. They won't appear in any 08:30 push until audit runs successfully and sets them to `review_status='approved'`.
- **08:30 push content**: Still had 35 business + 14 growth topics from prior approved topics. Delivery normal.

## Historical Pattern

audit_08x05 has a recurring timeout pattern. Output directory shows prior retry files:

| Date | Original Run | Retry File | Outcome |
|------|-------------|------------|---------|
| 2026-07-06 | 08:05:38 (FAILED) | 09:38:48 | Retry succeeded (1 approved, 0 rejected) |
| 2026-07-08 | 08:10:24 (FAILED?) | 09:42:51 | Manual retry needed |
| 2026-07-27 | 08:15:52 (FAILED) | **no retry file** | Auto-retry failed (this case) |

This suggests audit_08x05 has a latent provider-side issue that manifests intermittently.

## Key Lessons for Future Watchdogs

1. **LLM agent job auto-retry needs more time**: Unlike script jobs (which execute immediately on `hermes cron run`), LLM agent jobs are asynchronously scheduled. The 300s watchdog window is often too short. If the pre-check reports LLM agent job retry timeout, expect `last_status` to still be `error` and no new output file, even if the retry eventually succeeds after the watchdog finishes.

2. **Sidecar failures degrade data quality, not delivery**: When a sidecar job (no downstream depends_on) fails, downstream jobs look healthy but fresh data flow is interrupted. The alarm should note this partial degradation rather than treating it as an isolated job failure.

3. **Recurring timeouts on the same job deserve structural attention**: Three occurrences in 21 days (7/06, 7/08, 7/27) suggest the idle_timeout limit may be too tight for this job's LLM provider response profile, or the provider has intermittent latency.

## Recommended Actions

1. Manual retry: `hermes cron run audit_08x05 --profile content`
2. After retry succeeds, verify pool.db:
   ```sql
   SELECT count(*) FROM topics WHERE review_status='pending' AND status='pending';
   ```
   Should see the count decrease as topics become approved.
3. If recurring, consider increasing idle_timeout from 600s to 900s for this job, or investigating opencode-go provider latency.
