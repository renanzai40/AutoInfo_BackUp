# 通过 output 目录验证 Auto-Retry 完成状态

## 场景

预检查脚本 `wdog_auto_retry.py` 报告 `✅ auto-retry triggered successfully` 后，watchdog agent 需要确认 retry 是否**实际完成**，而非仅仅被触发排队。

## 验证步骤

### 1. 检查 job 在 content profile 的真实状态

```python
from pathlib import Path
import json

jobs_path = Path.home() / ".hermes" / "profiles" / "content" / "cron" / "jobs.json"
jobs = json.loads(jobs_path.read_text()).get("jobs", [])
job_map = {j["id"]: j for j in jobs}

# 检查被 retry 的 job
for job_id in ["audit_08x05", "judge_angles_08x10", "7671da210b69"]:
    job = job_map.get(job_id)
    if job:
        print(f"{job_id}: status={job.get('last_status')}, last_run={job.get('last_run_at')}, error={job.get('last_error')}")
```

### 2. 检查 output 目录

```python
output_base = Path.home() / ".hermes" / "profiles" / "content" / "cron" / "output"

for job_id in ["audit_08x05", "judge_angles_08x10", "7671da210b69"]:
    job_dir = output_base / job_id
    if not job_dir.exists():
        print(f"⚠️ {job_id}: no output directory")
        continue

    files = sorted(job_dir.glob("*.md"))
    if not files:
        print(f"⚠️ {job_id}: no output files")
        continue

    newest = files[-1]
    # 文件名格式: YYYY-MM-DD_HH-MM-SS.md
    print(f"\n📄 {job_id}: 最新 output = {newest.name}")

    content = newest.read_text()
    if "(FAILED)" in content:
        print("   ❌ 本次执行失败（文件含 FAILED 标记）")
    elif "## Response" in content:
        # LLM-driven job — 检查是否有实际内容输出
        resp_section = content.split("## Response", 1)[1].strip() if "## Response" in content else ""
        if resp_section and len(resp_section) > 50:
            print(f"   ✅ Retry 成功 — Response 正文 {len(resp_section)} 字符")
        else:
            print(f"   ⚠️ Retry 可能为空输出（Response 仅 {len(resp_section)} 字符）")
    else:
        # no_agent script job — 检查是否有执行日志
        exec_lines = [l for l in content.split("\n") if l.strip() and not l.startswith("#")]
        if exec_lines:
            print(f"   ✅ Retry 成功 — 脚本有 {len(exec_lines)} 行非注释输出")
        else:
            print(f"   ⚠️ Retry 没有产生实质性输出")
```

### 3. 交叉验证：hermes cron list vs content profile jobs.json

```bash
echo "=== hermes cron list 视图（default profile） ==="
hermes cron list 2>&1 | grep -E "Last run|^  (audit_08x05|judge_angles|7671da210b69)"

echo ""
echo "=== content profile jobs.json 视图 ==="
python3 -c "
import json
from pathlib import Path
j = json.loads((Path.home() / '.hermes/profiles/content/cron/jobs.json').read_text())
for job in j['jobs']:
    if job['id'] in ('audit_08x05','judge_angles_08x10','7671da210b69'):
        print(f\"  {job['id']}: last_run={job.get('last_run_at','?')}, status={job.get('last_status','?')}\")
"
```

### 4. 结果判断

| content profile jobs.json | output 目录最新文件 | 结论 |
|--------------------------|-------------------|------|
| `last_status=ok`, `last_run_at` 更新 | 有文件，无 FAILED 标记，有内容 | ✅ Retry 完成 |
| `last_status=error` 仍为旧 | 有新文件但有 FAILED 标记 | ❌ Retry 也失败 |
| `last_status=error` 仍为旧 | 无新 output 文件 | 🔁 Retry 未执行或仍在排队 |
| `last_status=ok` 但 `last_run_at` = 原始失败时间 | 无新 output 文件 | 🤔 jobs.json 未更新（罕见），需人工确认 |

### 2026-07-06 实战案例

```python
# content profile jobs.json:
#   audit_08x05:       last_status=ok, last_run_at=2026-07-06T09:38:49.794481+08:00
#   judge_angles_08x10: last_status=ok, last_run_at=2026-07-06T09:32:30.591036+08:00
#   7671da210b69:       last_status=ok, last_run_at=2026-07-06T09:35:15.842327+08:00
#
# hermes cron list (default profile):
#   audit_08x05:       2026-07-06T08:05:38  error (STALE — 不是 source of truth)
#   7671da210b69:       2026-07-06T08:30:49  error (STALE)
#
# output 目录:
#   audit_08x05/2026-07-06_09-38-48.md        — 成功（1条通过，0条剔除）
#   judge_angles_08x10/2026-07-06_09-32-30.md — 成功（6/6 完成）
#   7671da210b69/2026-07-06_09-35-14.md       — 成功（TOP3推送产出完整）
#
# 结论：全部 3 个 retry 成功。`hermes cron list` 显示的是默认 profile 的陈旧状态。
```
