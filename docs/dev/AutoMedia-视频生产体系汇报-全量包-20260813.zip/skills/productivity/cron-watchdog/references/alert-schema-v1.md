# automedia.wdog_alert.v1 Schema

watchdog job 写出的告警 JSON 固定 schema。cron delivery 端按此 schema 解析、投递、归档。

## 顶层字段

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `schema` | string | ✓ | 固定 `"automedia.wdog_alert.v1"`，delivery 端用它识别 |
| `generated_at` | string (ISO 8601) | ✓ | 写文件的本地时间戳，例：`2026-06-01T18:23:50.916632+08:00` |
| `watchdog_job_id` | string | ✓ | watchdog 自身在 jobs.json 里的 `id`，例：`wdog_auto_media` |
| `watchdog_run_at` | string | ✓ | watchdog 启动时间（不带秒），例：`2026-06-01T18:23+08:00` |
| `is_recheck` | bool | ✓ | 距上次告警 < 24h 且同一故障域时为 `true`；新故障用 `false` |
| `previous_alert_generated_at` | string or null | ✓ | 上次告警的 `generated_at`；首次告警填 `null` |
| `state_changed_since_last_alert` | bool | ✓ | 故障的 job 集合是否变化；用于「是新问题还是老问题」 |
| `summary` | object | ✓ | 见下 |
| `jobs_monitored` | array | ✓ | prompt 字面要求的 job 列表（结构见下） |
| `jobs_extra` | array | ✓ | 同链路、prompt 未列的 job 列表；可空 `[]` |
| `diagnosis` | object | ✓ | 根因归因；healthy 时可省，但建议保留 `null` 占位 |
| `recommended_actions` | array of string | ✓ | 用户可执行的下一步；healthy 时填 `["无需操作"]` |
| `actionable_command_suggestion` | string | ✗ | 一条命令就能复现/验证；纯建议 |

## summary 字段

```json
{
  "total_monitored": 3,        // jobs_monitored 长度（不含 jobs_extra）
  "healthy": 1,                // 4 分类计数
  "delivery_failed": 2,
  "execution_failed": 0,
  "missing": 0
}
```

`healthy + delivery_failed + execution_failed + missing` 必须等于 `total_monitored`，否则 schema 校验失败。

## 单个 job 条目结构

```json
{
  "id": "143d19e69a7c",
  "name": "AutoMedia 08:00 热点采集",
  "schedule": "0 8 * * *",
  "last_run_at": "2026-06-01T17:31:44.561669+08:00",
  "last_status": "ok",
  "last_error": null,
  "last_delivery_error": "delivery error: Feishu send failed: [230002] ...",
  "deliver": "feishu:oc_xxx,feishu:oc_yyy",
  "health": "delivery_failed",   // healthy / execution_failed / delivery_failed / missing
  "issue": "feishu_230002_bot_not_in_chat",   // 标准化 issue 标签
  "severity": "high",             // none / low / medium / high / critical
  "comment": "..."                // 可选，给用户的额外说明
}
```

`issue` 字段建议用 `feishu_<error_code>_<reason>` 这种机器可读标签，下游脚本可 grep 聚合。`severity` 与 `health` 的对应：

| health | severity 建议 |
|--------|---------------|
| healthy | none |
| execution_failed | high（脚本挂了，影响数据生产）|
| delivery_failed | high（脚本 OK 但用户没收到，影响可见性）|
| missing | critical（job 没了或没跑过）|

## diagnosis 字段

健康时填 `null`；有故障时：

```json
{
  "primary_error_code": "230002",
  "error_meaning_zh": "Bot/User can NOT be out of the chat（机器人不在该群聊中，或应用无 im:message 权限）",
  "secondary_error_code": "230001",
  "error_meaning_zh_2": "invalid receive_id（receive_id 格式错或对应会话已解散）",
  "affected_chat_ids": ["oc_23809420584b118ca6df5c514067045b"],
  "intermittent_chat_id": "oc_xxx — 偶发成功，提示问题在飞书侧/单次失败",
  "root_cause_hypothesis": "脚本侧 ok，集中在飞书侧：机器人被移出群 / token 临近过期 / 权限被回收"
}
```

## 真实样本（2026-06-01 命中）

```json
{
  "schema": "automedia.wdog_alert.v1",
  "generated_at": "2026-06-01T18:23:50.916632+08:00",
  "watchdog_job_id": "wdog_auto_media",
  "watchdog_run_at": "2026-06-01T18:23+08:00",
  "is_recheck": true,
  "previous_alert_generated_at": "2026-06-01T17:55:54.615802+08:00",
  "state_changed_since_last_alert": false,
  "summary": {
    "total_monitored": 3,
    "healthy": 1,
    "delivery_failed": 2,
    "execution_failed": 0,
    "missing": 0
  },
  "jobs_monitored": [/* ... */],
  "jobs_extra": [/* ... */],
  "diagnosis": { "primary_error_code": "230002", ... },
  "recommended_actions": [
    "1. 飞书后台 → 应用 → 权限管理：确认 im:message、im:message:send_as_bot 仍在启用。",
    "2. 用飞书 app 打开高频失败 chat_id 对应群，确认 AutoMedia 机器人是否还在；不在则重新邀请入群。",
    "3. 修复后用 `hermes cron run 143d19e69a7c` 重跑 08:00 验证。",
    "4. 短期绕过：hermes cron edit 143d19e69a7c --deliver feishu:<一个可达的 chat_id>。"
  ],
  "actionable_command_suggestion": "hermes cron run 143d19e69a7c   # 重跑 08:00 验证 delivery 是否恢复"
}
```

## 归档约定

写新告警前，把上一份 `wdog_alert.json` 改名归档：

```bash
ts=$(jq -r .generated_at ~/.hermes/cron/wdog_alert.json | tr -d ':+' | cut -c1-13)
mv ~/.hermes/cron/wdog_alert.json ~/.hermes/cron/wdog_alert.json.history.${ts}
# 例：wdog_alert.json.history.20260601_1823
```

文件名时间戳取 `generated_at` 前 13 字符（年月日_时分），便于按时间排序。
