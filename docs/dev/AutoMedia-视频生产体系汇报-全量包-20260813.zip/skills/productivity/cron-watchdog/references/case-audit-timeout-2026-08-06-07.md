# Case: audit_08x05 第 5 次同类超时（2026-08-06 失败 / 08-07 手动重跑也卡住）

## 触发

用户从 daily dashboard（c8a7228fe4bc，23:00 生成）看到：`08:05 🔍 审核 ❌ error`，
`TimeoutError: Cron job 'AutoMedia 08:05 语义审核（Layer 3）+ 黑名单更新' idle for 603s (limit 600s) — last activity: waiting for non-streaming API response`。

## 调查路径（本次实际走通的顺序）

1. `cronjob action='list'` 确认 `audit_08x05` `last_status=error`，`last_error` 为 idle 超时。
2. `~/.hermes/profiles/content/cron/jobs.json`（source of truth）确认 `last_run_at=2026-08-06T08:20:15`。
3. output 目录 `~/.hermes/profiles/content/cron/output/audit_08x05/` 最新文件 `2026-08-06_08-20-14.md`（FAILED），
   说明昨天 08:05 原始运行在 08:20 被杀（idle 603s > 600s）。
4. `~/.hermes/cron/wdog_alert.json` 已由 09:30 watchdog 写过告警：`auto_retried=[audit_08x05]`，
   `auto_retry_failed=[audit_08x05]`，诊断为 `LLM_PROVIDER_IDLE_TIMEOUT`，pipeline_impact=partial（sidecar 降级）。
5. **pool.db 影响评估**（新步骤，值得固化）：
   - `SELECT COUNT(*) FROM topics WHERE review_status='pending' AND status='pending'` → 仅 1 条积压（08-05 入库的知乎话题，heat 0.93）。
   - 08-06 采集的 15 条 AIHOT 话题 `created_at=updated_at=08:30:50`，`review_status='approved'`——是采集脚本直接标 approved 的，**不依赖** audit job，不受本次失败影响。
   - `blocked_domains` 最近新增停在 07-23，说明 08-05/08-06 的 audit 都没跑到写库阶段。
   - **结论**：影响面小——主链路（08:00/08:10/08:30）正常，仅语义审核/黑名单更新延迟。

## 手动重跑验证（关键观察）

- `hermes cron run audit_08x05` 第一次调用被 terminal 60s 超时打断（命令本身在等待调度）。
- 再次调用返回：`Job is already being fired by the scheduler; not run again.`
- jobs.json 出现 `fire_claim: {at: 2026-08-07T02:00:01, by: Agent:211183}` → 调度器在下一 tick（60s）接管执行。
- agent.log 显示 `cron_audit_08x05_20260807_020001` 的 `OpenAI client created` 后，**23 分钟无 "API call #N ... latency=..." 完成日志** → 重跑同样卡在 provider 响应上。
- 但当前对话 session（同 provider opencode-go/deepseek-v4-flash）API 调用正常（latency 4-18s）→ 疑为 cron 请求体过大（加载 102KB skill）触发 provider 间歇性慢响应。
- fire_claim TTL=300s，02:00:01 的 claim 在 02:05:01 过期 → **今天 08:05 自动调度不受阻塞**（next_run_at 仍为 08:05）。

## 历史模式（第 5 次）

| 日期 | 原始运行 | retry | 结果 |
|------|---------|-------|------|
| 07-06 | 08:05:38 FAILED | 09:38:48 | retry 成功（1 approved, 0 rejected） |
| 07-08 | 08:10:24 FAILED | 09:42:51 | 需手动 retry |
| 07-27 | 08:15:52 FAILED | 无 retry 文件 | auto-retry 完全失败（见 case-wdog-retry-failed-2026-07-27.md） |
| 08-06 | 08:20:15 FAILED | 09:30 auto-retry 部分执行 | agent 跑了 skill_view + 2 次 API call（latency 100s+）后第三次 API call 卡住，无 output |
| 08-07 | 02:00 手动重跑 | — | agent 卡在第一个 API call 23+ 分钟，无 output；fire_claim 过期不阻塞 08:05 |

## 结构性修复建议（第 6 次前必须动手）

1. 单独调大 audit_08x05 的 idle_timeout（600s → 900s）。
2. 减小 cron 请求体：audit prompt 里避免加载 102KB skill，或精简 prompt。
3. 错峰调度或切换 provider。
4. 把 prompt 第四步的 execute_code 改成 terminal 写法（cron 环境 execute_code 被 BLOCKED）。
5. 考虑在 audit 失败后由 watchdog/别的 job 补跑审核逻辑，而不是依赖下次 08:05。

## 教训

- **不要**因为 `hermes cron run` 返回 "already being fired" 就认为 job 在正常执行——要查 agent.log 的 API call 完成日志。
- **不要**反复手动重跑同一个 LLM agent job——每次都会刷新 fire_claim，且可能同样卡在 provider 上。等下次自动调度或先修请求体。
- **手动重跑验证 LLM job 的等待窗口**：agent.log 是唯一可靠的进度来源（API call #N + latency），output 目录只有跑完才更新。
