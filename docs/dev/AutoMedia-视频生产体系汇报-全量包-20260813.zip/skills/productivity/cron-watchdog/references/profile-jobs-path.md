# jobs.json 真实路径定位

Hermes cron 状态在多 profile 体系下，**实际路径 ≠ prompt 给的默认路径**。这是 watchdog 实战踩中的最常见坑。

## 路径规则

Hermes 把 jobs.json 按 profile 分目录存放：

```
~/.hermes/cron/jobs.json                        # 默认 profile 镜像（不一定是 source）
~/.hermes/profiles/<active-profile>/cron/jobs.json   # 实际 source of truth
```

`active-profile` 取自 `~/.hermes/profiles/<name>/` 下有 `state.db` 的那个；当前活动 profile 由 `hermes profile current` 给出。

## 3 个 fallback（按优先级）

### 1. `hermes cron list` 看 `Profile:` 行

```bash
hermes cron list 2>&1 | grep -A 2 "Profile:"
```

每个 job 条目下都有 `Profile: <name>`，从这能直接看到所有 job 真正归属的 profile。

**注意**：`hermes cron list` 已知有 bug，当 jobs.json 里有 `repeat: null` 的 job（如 `self-packaging`）会触发 `AttributeError: 'NoneType' object has no attribute 'get'`。**不要**误判为 cron 挂了——`hermes cron status` 看 PID/active count 才稳。

### 2. 直接 glob profile 目录

```bash
ls -la ~/.hermes/profiles/*/cron/jobs.json
```

多数情况下 `content` profile 是 active 那个。

### 3. 反向查 default profile 路径

`~/.hermes/cron/jobs.json` 有时候是个「默认 profile 的 jobs.json 镜像」，job 数远少于 `hermes cron list` 输出的总数——这时它就是过时的，别信。

## 实战：2026-06-07 wdog_auto_media 命中

| 路径 | job 数 | 实际意义 |
|------|-------|---------|
| `~/.hermes/cron/jobs.json` | 2 | 只有 `context-sync 01:00` + `self-packaging weekly audit` |
| `~/.hermes/profiles/content/cron/jobs.json` | 9 | 4 AutoMedia 链 + 1 wdog + 4 其他 |

如果只看 prompt 给的 `~/.hermes/cron/jobs.json`，会以为 AutoMedia job 全部消失、误报「missing: 4」。正确做法是去 `content` profile 找——4 个 job 全在，今天都 ok。

## 怎么判断「该信哪边」

1. 先 `wc -l` 两个 jobs.json，**size 大 / job 数多** 那个更可能是真源
2. `hermes cron list | wc -l` 数一下真实 job 数（注意：list 命令 bug 可能在中间 traceback 不影响前面的 job 输出）
3. 监控目标如果在 prompt 路径里**完全找不到**，100% 是路径错位

## 多 profile 环境的额外提醒

- `~/.hermes/cron/` 顶层目录可能属于 default profile（autonomous-ai-agents），但你监控的 AutoMedia job 在 `content` profile 下
- 跨 profile 共享的脚本（很少见）才会出现在多份 jobs.json
- 改 jobs.json 时也只改 active profile 那份，写到默认路径会被下次 sync 覆盖
