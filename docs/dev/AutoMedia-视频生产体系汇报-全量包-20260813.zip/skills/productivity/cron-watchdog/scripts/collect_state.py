#!/usr/bin/env python3
"""
collect_state.py — 一次性提取所有监控 job 的 health 字段

给 cron-watchdog agent 用：在写告警 JSON 前快速收集全量状态，省去
手写 json.dumps + 多处 read_file。

用法：
    python3 collect_state.py \\
        --jobs-json ~/.hermes/profiles/content/cron/jobs.json \\
        --watched-ids 143d19e69a7c maintenance_01 7671da210b69 \\
        --extra-ids audit_08x05 \\
        --out /tmp/wdog_state.json

输出：JSON 到 --out（stdout 也 dump 一次便于 pipe）。
字段：每个 watched/extra job 一个 dict，含 id/name/schedule/last_run_at/
last_status/last_error/last_delivery_error/deliver/state/health/severity。
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from datetime import datetime, timezone, timedelta


CST = timezone(timedelta(hours=8))


def classify(job: dict) -> tuple[str, str, str | None]:
    """Return (health, severity, issue_tag) per cron-watchdog rules."""
    state = job.get("state")
    if state != "scheduled":
        return ("missing_or_paused", "critical", f"state_{state}")
    if job.get("last_error"):
        return ("execution_failed", "high", "script_error")
    if job.get("last_delivery_error"):
        # 提取首个 [error_code] 作为 issue tag
        err = str(job["last_delivery_error"])
        tag = "delivery_error"
        for code in ("230002", "230001", "230020", "230021"):
            if code in err:
                tag = f"feishu_{code}"
                break
        return ("delivery_failed", "high", tag)
    if job.get("last_status") == "ok":
        return ("healthy", "none", None)
    return ("unknown", "medium", "unknown_state")


def extract(job: dict) -> dict:
    health, severity, issue = classify(job)
    schedule = job.get("schedule") or {}
    expr = schedule.get("expr") or schedule.get("display") or job.get("schedule_display", "")
    return {
        "id": job["id"],
        "name": job["name"],
        "schedule": expr,
        "last_run_at": job.get("last_run_at"),
        "last_status": job.get("last_status"),
        "last_error": job.get("last_error"),
        "last_delivery_error": job.get("last_delivery_error"),
        "deliver": job.get("deliver"),
        "state": job.get("state"),
        "health": health,
        "issue": issue,
        "severity": severity,
    }


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--jobs-json", required=True, help="absolute path to active profile's jobs.json")
    p.add_argument("--watched-ids", nargs="+", required=True, help="job ids the prompt says to monitor")
    p.add_argument("--extra-ids", nargs="*", default=[], help="same-pipeline extras, surfaced under jobs_extra")
    p.add_argument("--out", help="write JSON here; if omitted, stdout only")
    args = p.parse_args()

    jobs_path = Path(args.jobs_json).expanduser()
    if not jobs_path.exists():
        print(f"FATAL: {jobs_path} not found", file=sys.stderr)
        return 2

    with jobs_path.open() as f:
        data = json.load(f)
    jobs = {j["id"]: j for j in data.get("jobs", [])}

    missing = [jid for jid in args.watched_ids + args.extra_ids if jid not in jobs]
    if missing:
        print(f"WARN: ids not found in jobs.json: {missing}", file=sys.stderr)

    monitored = [extract(jobs[jid]) for jid in args.watched_ids if jid in jobs]
    extra = [extract(jobs[jid]) for jid in args.extra_ids if jid in jobs]

    summary = {
        "total_monitored": len(monitored),
        "healthy": sum(1 for j in monitored if j["health"] == "healthy"),
        "delivery_failed": sum(1 for j in monitored if j["health"] == "delivery_failed"),
        "execution_failed": sum(1 for j in monitored if j["health"] == "execution_failed"),
        "missing": sum(1 for j in monitored if j["health"] in ("missing_or_paused", "unknown")),
        "generated_at": datetime.now(CST).isoformat(timespec="seconds"),
    }

    payload = {
        "summary": summary,
        "jobs_monitored": monitored,
        "jobs_extra": extra,
    }

    out = json.dumps(payload, ensure_ascii=False, indent=2)
    if args.out:
        Path(args.out).write_text(out)
    print(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
