"""
SRT 修复 v3：用 silencedetect 严格对齐 entry 边界，处理 silences < entries 的连续朗读情况

v1 算法（已弃用）：min(srt.end+0.5, silence_start-0.05) - 只推 0.5s 不够
v2 算法：严格用静音点 silences[i+1] - 0.05 作为 entry.end - 适用于 silences == entries
v3 算法（2026-06-05 6-05 v7 实测）：处理 silences < entries（TTS 短 entry 连续朗读无停顿）
  - 用 d=0.15 更细 silencedetect
  - 仍 < entries 时：连续朗读段内按字符等分切

用法：
  python3 fix_srt_silencedetect.py <SRT_path> <audio_path> [out_srt_path] [--d 0.15] [--allow-char-proportional]
"""
import sys, os, re, json, subprocess, argparse


def get_silences(mp3: str, d: float = 0.15) -> list:
    """ffmpeg silencedetect 拿 TTS 静音点"""
    cmd = ["ffmpeg", "-i", mp3, "-af", f"silencedetect=noise=-30dB:d={d}", "-f", "null", "-"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    silences = []
    for line in result.stderr.split("\n"):
        if "silence_start" in line:
            t = float(line.split("silence_start: ")[1].strip())
            silences.append(t)
    return silences


def sec_to_srt(t: float) -> str:
    """秒数 → SRT 时间格式 'HH:MM:SS,mmm'"""
    t = max(0, t)
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    ms = int((t - int(t)) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def srt_to_sec(s: str) -> float:
    """SRT 时间格式 'HH:MM:SS,mmm' → 秒数"""
    h, m, rest = s.split(":")
    s, ms = rest.split(",")
    return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000


def parse_srt(path: str) -> list:
    """读 SRT 文件返回 [{idx, start, end, text}, ...]"""
    with open(path) as f:
        text = f.read()
    entries = []
    blocks = text.strip().split("\n\n")
    for b in blocks:
        lines = b.split("\n")
        if len(lines) >= 3:
            idx = int(lines[0])
            m = re.match(r'(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})', lines[1])
            if m:
                entries.append({
                    "idx": idx,
                    "start": m.group(1),
                    "end": m.group(2),
                    "text": "\n".join(lines[2:])
                })
    return entries


def fix_srt_v2(entries: list, silences: list, audio_dur: float) -> list:
    """v2 算法：严格用静音点对齐 entry 边界（要求 silences == entries）"""
    fixed = []
    for i, e in enumerate(entries):
        if i + 1 < len(silences):
            new_start = silences[i] + 0.05
            new_end = silences[i+1] - 0.05
        else:
            new_start = silences[i] + 0.05
            new_end = audio_dur - 0.05
        # 防御: 不能超过下一条 entry.start (字幕重叠)
        if i + 1 < len(entries):
            next_start = srt_to_sec(entries[i+1]["start"])
            new_end = min(new_end, next_start - 0.05)
        new_end = max(new_end, srt_to_sec(e["start"]) + 0.05)
        fixed.append({**e, "start": sec_to_srt(new_start), "end": sec_to_srt(new_end)})
    return fixed


def fix_srt_v3(entries: list, silences: list, audio_dur: float) -> list:
    """v3 算法：处理 silences < entries（TTS 连续朗读）的情况

    策略：
    1. 对齐能直接对齐的 entry（silence_start 落在 entry 起止范围内）
    2. 对连续朗读段（多 entry 共享 1 silence）：按字符等分切
    """
    if len(silences) >= len(entries):
        return fix_srt_v2(entries, silences, audio_dur)

    # 把每个 entry 映射到它"应该"的 silence 索引
    # 简化：假设每个 silence 对应 1 或多个 entry（连续朗读）
    fixed = []
    silence_idx = 0
    i = 0
    while i < len(entries):
        if silence_idx >= len(silences):
            # 剩余 entry 用字符等分在最后 silence 之后
            remaining = entries[i:]
            if remaining:
                last_silence = silences[-1] if silences else 0
                remaining_chars = sum(len(e["text"]) for e in remaining)
                t = last_silence + 0.05
                for e in remaining:
                    end_t = t + (len(e["text"]) / remaining_chars) * (audio_dur - last_silence - 0.05)
                    fixed.append({**e, "start": sec_to_srt(t), "end": sec_to_srt(end_t)})
                    t = end_t
            break

        # 当前 entry 从 silences[silence_idx] 开始
        start_t = silences[silence_idx] + 0.05

        # 找下一个 silence 之前有几个 entry
        # 简化：基于字符数估算，假设 0.3s/字
        chars_so_far = 0
        j = i
        while j < len(entries):
            chars_so_far += len(entries[j]["text"])
            # 估算这个 entry 朗读到下一个 silence 的时间
            if silence_idx + 1 < len(silences):
                next_silence = silences[silence_idx + 1]
                # 如果这些 entry 字符数对应的时间超过 next_silence, 停止
                if chars_so_far * 0.3 > (next_silence - start_t):
                    break
            j += 1
            if j - i >= 3:  # 最多连续 3 个 entry 合并
                break

        # 从 i 到 j 是连续朗读段（1 个 silence 对应多个 entry）
        continuous_entries = entries[i:j] if j > i else entries[i:i+1]
        n_entries = len(continuous_entries)
        if n_entries == 0:
            n_entries = 1
            continuous_entries = [entries[i]]
        next_silence = silences[silence_idx + 1] - 0.05 if silence_idx + 1 < len(silences) else audio_dur - 0.05
        end_window = next_silence - start_t
        total_chars = sum(len(e["text"]) for e in continuous_entries)

        t = start_t
        for e in continuous_entries:
            end_t = t + (len(e["text"]) / total_chars) * end_window
            # 防御：不能超过下一条 entry.start
            if i + 1 < len(entries):
                next_entry_start = srt_to_sec(entries[i + 1]["start"])
                end_t = min(end_t, next_entry_start - 0.05)
            end_t = max(end_t, t + 0.05)
            fixed.append({**e, "start": sec_to_srt(t), "end": sec_to_srt(end_t)})
            t = end_t

        i += n_entries
        silence_idx += 1

    return fixed


def write_srt(entries: list, path: str):
    with open(path, "w", encoding="utf-8") as f:
        for e in entries:
            f.write(f"{e['idx']}\n{e['start']} --> {e['end']}\n{e['text']}\n\n")


def get_audio_dur(mp3: str) -> float:
    p = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", mp3],
        capture_output=True, text=True
    )
    return float(json.loads(p.stdout)["format"]["duration"])


def main():
    parser = argparse.ArgumentParser(description="SRT 修复 v3: silencedetect 严格对齐 + 连续朗读字符等分")
    parser.add_argument("srt_path")
    parser.add_argument("audio_path")
    parser.add_argument("out_path", nargs="?", default=None, help="默认覆盖 SRT")
    parser.add_argument("--d", type=float, default=0.15, help="silencedetect duration 阈值（默认 0.15）")
    parser.add_argument("--allow-char-proportional", action="store_true",
                        help="silences < entries 时启用字符等分切分（v3 算法）")
    args = parser.parse_args()

    srt_path = args.srt_path
    audio_path = args.audio_path
    out_path = args.out_path or srt_path

    silences = get_silences(audio_path, d=args.d)
    audio_dur = get_audio_dur(audio_path)
    entries = parse_srt(srt_path)

    print(f"[v3] 读取 {len(entries)} entries, {len(silences)} silences (d={args.d}), audio={audio_dur:.2f}s")

    if len(silences) >= len(entries):
        fixed = fix_srt_v2(entries, silences, audio_dur)
        print(f"[v3] silences >= entries, 走 v2 算法")
    elif args.allow_char_proportional:
        fixed = fix_srt_v3(entries, silences, audio_dur)
        print(f"[v3] silences < entries, 走 v3 算法（连续朗读字符等分）")
    else:
        print(f"[v3] ⚠️ silences ({len(silences)}) < entries ({len(entries)}) - 缺少 --allow-char-proportional flag")
        print(f"[v3] 重跑: python3 {sys.argv[0]} {srt_path} {audio_path} --allow-char-proportional")
        sys.exit(1)

    write_srt(fixed, out_path)

    # 验证偏差
    max_diff = 0
    for e in fixed:
        end_sec = srt_to_sec(e["end"])
        next_sil = next((s for s in silences if s > end_sec), None)
        if next_sil:
            diff = end_sec - next_sil
            max_diff = max(max_diff, abs(diff))

    print(f"[v3] ✅ 修复后 SRT 写入: {out_path}")
    print(f"[v3] max_diff = {max_diff:.3f}s (阈值 0.3s = PASS, 0.7s = BLOCK)")


if __name__ == "__main__":
    main()
