"""
subtitle_review.py — SRT 字幕 LLM 校对脚本

调用 MiniMax M2.7 对照原始脚本，一次性全局校对 Whisper ASR 近音字错误。
不接受正则替换方案——近音字错误无法穷举，LLM 一次性对照是唯一可靠方案。

用法：
    from subtitle_review import review_srt
    reviewed = review_srt(
        srt_path="/path/to/subtitle.srt",       # 当前 SRT（Whisper 输出，可能有错）
        script_path="/path/to/script.txt"        # 原始脚本（对照依据）
    )
    write_reviewed_srt(reviewed, output_srt_path)
"""

import re, json, sys, os

# 2026-06-09: 原 MiniMax API 已迁移到 opencode-go DeepSeek-v4-flash\n# API endpoint 和 key 由 hermes-agent provider 配置管理，不走硬编码\n# subtitle_review.py 已不再通过此 MiniMax API 调用
MODEL = "deepseek-v4-flash"

def load_srt_entries(srt_path):
    """解析 SRT 文件，返回 [(index, start, end, text), ...]"""
    entries = []
    with open(srt_path, encoding="utf-8") as f:
        content = f.read()
    blocks = re.split(r'\n\n+', content.strip())
    for block in blocks:
        lines = block.strip().split('\n')
        if len(lines) >= 3:
            idx = int(lines[0])
            times = lines[1].split(' --> ')
            start = times[0].strip()
            end = times[1].strip()
            text = '\n'.join(lines[2:])
            entries.append((idx, start, end, text))
    return entries

def load_script_text(script_path):
    """加载原始脚本文本（只取口播部分，去掉【】标记）"""
    with open(script_path, encoding="utf-8") as f:
        content = f.read()
    # 去掉【】标记的行，保留纯口播文本
    lines = []
    for line in content.split('\n'):
        line = re.sub(r'【[^】]*】', '', line).strip()
        if line:
            lines.append(line)
    return '\n'.join(lines)

def build_review_prompt(srt_entries, script_text):
    """构造校对 prompt"""
    # SRT entries 格式化
    srt_lines = []
    for idx, start, end, text in srt_entries:
        srt_lines.append(f"[{idx}] {start} --> {end}")
        srt_lines.append(f"  字幕: {text}")
    srt_formatted = '\n'.join(srt_lines)

    prompt = f"""你是字幕校对专家。对照原始脚本，逐条检查 SRT 字幕中的 ASR 识别错误。

【原始脚本】
{script_text}

【SRT 字幕（ Whisper ASR 输出，可能有错误）】
{srt_formatted}

【校对要求】
1. 逐条对照原始脚本和 SRT 字幕
2. 修正所有近音字错误（如"壹目贯维"→"壹目贯维"，"热斗"→"热度"，"战比"→"占比"，"稳定气"→"稳定器"，"满院父母"→"埋怨父母"等）
3. 保持时间轴不变，只修正文字
4. 标点可以补全（Whisper 可能漏标点），但不能改变句意
5. 返回 JSON 格式（严格，无 markdown 标记）：
{{"corrections": [{{"index": N, "original": "...", "corrected": "...", "reason": "..."}}, ...]}}

注意：index 从 1 开始，与 SRT entry 编号一致。只返回有错误的条目，无错误的条目不返回。"""
    return prompt

def call_minimax(prompt, retries=2, timeout=120):
    """调用 MiniMax M2.7 进行校对"""
    import requests
    url = "https://api.minimaxi.com/v1/text/chatcompletion_v2"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 8192,
        "temperature": 0.1
    }
    last_err = None
    for attempt in range(retries):
        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=timeout)
            if resp.status_code != 200:
                raise Exception(f"MiniMax API error: {resp.status_code} {resp.text}")
            result = resp.json()
            content = result['choices'][0]['message']['content']
            if not content or len(content.strip()) == 0:
                raise Exception("Empty response from MiniMax")
            return content
        except Exception as e:
            last_err = e
            print(f"[subtitle_review] MiniMax call attempt {attempt+1} failed: {e}")
            if attempt < retries - 1:
                import time
                time.sleep(3)
    raise Exception(f"MiniMax call failed after {retries} attempts: {last_err}")

def parse_corrections(response_text):
    """解析 LLM 返回的 JSON 修正结果（容错：截断时取最大完整部分）"""
    import json
    # 尝试找 JSON 对象
    json_match = re.search(r'\{[\s\S]*\}', response_text)
    if not json_match:
        raise Exception(f"No JSON found in response: {response_text[:500]}")
    raw = json_match.group()
    # 如果JSON不完整（截断），尝试截到最后一个 '}' 
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        # 截断修复：找最后一个 ']' 闭合处
        # 先找到 corrections 数组的 '[' 位置
        arr_start = raw.find('"corrections":')
        if arr_start == -1:
            raise Exception(f"No corrections key in JSON: {raw[:300]}")
        bracket_pos = raw.find('[', arr_start)
        # 从后往前找最外层的 ']'
        search = raw[bracket_pos:]
        last_close = search.rfind(']')
        if last_close == -1:
            raise Exception(f"Cannot find closing bracket in truncated JSON: {raw[:300]}")
        fixed = raw[:bracket_pos + last_close + 1] + '}'
        try:
            data = json.loads(fixed)
        except Exception as e2:
            raise Exception(f"Even truncated JSON parse failed: {e2}. Raw[:500]: {raw[:500]}")
    return data.get('corrections', [])

def review_srt(srt_path, script_path):
    """
    主函数：校对 SRT
    返回: [(index, start, end, corrected_text), ...]
    """
    print(f"[subtitle_review] 开始校对 SRT: {srt_path}")
    print(f"[subtitle_review] 原始脚本: {script_path}")

    srt_entries = load_srt_entries(srt_path)
    script_text = load_script_text(script_path)

    print(f"[subtitle_review] SRT entries: {len(srt_entries)}")
    print(f"[subtitle_review] 脚本字数: {len(script_text)}")

    prompt = build_review_prompt(srt_entries, script_text)
    print("[subtitle_review] 调用 MiniMax M2.7 校对...")
    response = call_minimax(prompt)

    print(f"[subtitle_review] LLM 响应长度: {len(response)} chars")
    corrections = parse_corrections(response)
    print(f"[subtitle_review] 发现错误: {len(corrections)} 处")

    # 构建修正后的 entries
    idx_to_correction = {c['index']: c for c in corrections}

    reviewed_entries = []
    for idx, start, end, text in srt_entries:
        if idx in idx_to_correction:
            corrected_text = idx_to_correction[idx]['corrected']
            print(f"  [{idx}] '{text}' → '{corrected_text}'")
            reviewed_entries.append((idx, start, end, corrected_text))
        else:
            reviewed_entries.append((idx, start, end, text))

    return reviewed_entries

def write_reviewed_srt(entries, output_path):
    """将修正后的 entries 写回 SRT 文件"""
    def fmt_time_srt(t):
        # t 是 "HH:MM:SS,mmm" 格式，直接返回
        return t

    with open(output_path, 'w', encoding='utf-8') as f:
        for idx, start, end, text in entries:
            f.write(f"{idx}\n{start} --> {end}\n{text}\n\n")

    print(f"[subtitle_review] 已写入: {output_path}")

def fmt_time(t):
    """将秒数转为 SRT 时间格式"""
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    ms = int((t % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

if __name__ == "__main__":
    # 测试用
    import sys
    srt_path = sys.argv[1] if len(sys.argv) > 1 else "/tmp/test.srt"
    script_path = sys.argv[2] if len(sys.argv) > 2 else "/tmp/script.txt"
    output_path = sys.argv[3] if len(sys.argv) > 3 else srt_path

    entries = review_srt(srt_path, script_path)
    write_reviewed_srt(entries, output_path)