#!/usr/bin/env python3
"""
SRT 映射确认表生成器 - Stage 1 强制输出物

运行此脚本后，会生成一个映射表，必须确认后才能进入 SRT 生成。

用法:
    python3 build_srt_mapping.py /path/to/whisper_result.json /path/to/script.txt

输出:
    1. 逐片段列表（用于确认 Whisper 分组边界）
    2. 脚本行列表（用于确认合并规则）
    3. 预检结果（哪些 entry 超 45 字）
    4. 分组方案建议
"""
import json, sys
from pathlib import Path

def analyze_whisper(json_path):
    with open(json_path) as f:
        data = json.load(f)
    segments = data["segments"]
    total_dur = segments[-1]["end"]
    return segments, total_dur

def read_script_lines(txt_path):
    """读取脚本文件，每行一个完整句子（以句号/问号/感叹号结尾）"""
    with open(txt_path, encoding="utf-8") as f:
        content = f.read()
    # 按换行拆分（口播脚本格式）
    lines = [l.strip() for l in content.strip().split("\n") if l.strip()]
    return lines

def build_mapping_table(segments, script_lines):
    """生成映射表，但不执行合并"""
    n_segs = len(segments)
    n_lines = len(script_lines)
    ratio = n_segs / n_lines if n_lines > 0 else 0

    print(f"\n{'='*60}")
    print(f"Whisper 片段数: {n_segs}")
    print(f"脚本行数: {n_lines}")
    print(f"平均每行占片段数: {ratio:.2f}")
    print(f"{'='*60}")

    print("\n--- 片段详情 ---")
    for i, seg in enumerate(segments):
        dur = seg["end"] - seg["start"]
        print(f"  seg{i:02d}: {seg['start']:.2f}-{seg['end']:.2f} ({dur:.2f}s): {seg['text']}")

    print(f"\n--- 脚本行详情 ---")
    total_chars = 0
    for i, line in enumerate(script_lines):
        chars = len(line)
        total_chars += chars
        print(f"  行{i+1:02d}: {chars}字: {line[:40]}...")
    print(f"  总字数: {total_chars}")

    print(f"\n--- 字数预检（≤45字为合格）---")
    warnings = []
    for i, line in enumerate(script_lines, 1):
        chars = len(line)
        flag = "✅" if chars <= 45 else "❌超限"
        if chars > 45:
            warnings.append((i, chars, line))
        print(f"  行{i:02d}: {chars}字 {flag} | {line[:30]}...")
    if warnings:
        print(f"\n  ⚠️  {len(warnings)} 行超过45字，需要拆分:")
        for i, chars, line in warnings:
            print(f"    行{i}: {chars}字 → {line[:50]}...")
    else:
        print("  ✅ 全部 ≤45字")

    print(f"\n--- 分组方案建议 ---")
    print(f"  建议合并规则（仅供参考，需人工确认）:")
    print(f"  当 ratio ≈ 2-3 时：按片段数均分")
    print(f"  当 ratio >> n_lines 时：需要拆分（每行占多个片段）")
    print(f"  当 ratio << n_lines 时：需要合并（多行占同一片段组）")
    print(f"\n  ⚠️ 确认映射后，将结果填入 build_srt_from_mapping() 执行生成")

    return {
        "n_segs": n_segs,
        "n_lines": n_lines,
        "ratio": ratio,
        "warnings": warnings,
    }

def build_srt_from_mapping(segments, script_lines, groupings):
    """
    根据确认后的分组生成 SRT。

    groupings: [(seg_start, seg_end, text), ...]
    seg_start: 片段起始索引（含）
    seg_end: 片段结束索引（不含）
    text: 脚本原文（不是 Whisper 文本）
    """
    import re
    def fmt_time(s):
        h = int(s // 3600)
        m = int((s % 3600) // 60)
        sec = int(s % 60)
        ms = int((s % 1) * 1000)
        return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"

    entries = []
    for seg_start, seg_end, text in groupings:
        start = segments[seg_start]["start"]
        end = segments[seg_end - 1]["end"]
        chars = len(text)
        dur = end - start
        speed = chars / dur if dur > 0 else 0
        flag = "✅" if chars <= 45 else "❌超限"
        entries.append((start, end, text, chars, speed, flag))

    return entries

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法: python3 build_srt_mapping.py whisper_result.json script.txt")
        sys.exit(1)

    json_path = sys.argv[1]
    script_path = sys.argv[2]

    segments, total_dur = analyze_whisper(json_path)
    script_lines = read_script_lines(script_path)

    result = build_mapping_table(segments, script_lines)
    print(f"\n总音频时长: {total_dur:.2f}s")
