#!/usr/bin/env python3
"""
SRT → segments.json 转换器
将 SRT 文件转换为 burn_subtitles.py 所需的 JSON segments 格式。

Usage:
    python3 srt_to_segs.py <srt_path> [output_json_path]

Output:
    *.srt → *_segs.json（与 SRT 同目录）
"""

import sys, re, json

def parse_time(s):
    s = s.strip().replace(',', '.')
    h, m, rest = s.split(':')
    sec, ms = rest.split('.')
    return float(h)*3600 + float(m)*60 + float(sec) + float(ms)/1000

def srt_to_segs(srt_path, output_path=None):
    with open(srt_path, encoding='utf-8') as f:
        content = f.read()
    
    segs = []
    blocks = re.split(r'\n\n+', content.strip())
    for block in blocks:
        lines = block.split('\n')
        if len(lines) < 3:
            continue
        t = lines[1].split(' --> ')
        text = '\n'.join(lines[2:])
        segs.append([parse_time(t[0]), parse_time(t[1]), text])
    
    if output_path is None:
        output_path = srt_path.replace('.srt', '_segs.json')
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(segs, f, ensure_ascii=False)
    
    return len(segs), output_path

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: srt_to_segs.py <srt_path> [output_json_path]")
        sys.exit(1)
    
    srt_path = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else None
    
    count, out = srt_to_segs(srt_path, output_path)
    print(f"{count} segments → {out}")