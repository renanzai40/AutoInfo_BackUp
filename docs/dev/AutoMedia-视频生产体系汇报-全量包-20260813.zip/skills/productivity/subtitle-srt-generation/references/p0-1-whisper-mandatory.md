# P0-1 铁律：Whisper 是 SRT 验证的 MANDATORY 工具（不仅是质量检查）

### P0-1 铁律：Whisper 是 SRT 验证的 MANDATORY 工具（不仅是质量检查）

> **2026-06-05 session 113223 实测踩坑**：mp3 是旧版"GPT5 工具红利期"内容，SRT 是新版"Alphabet 800亿"内容——**两套完全不同的内容**。**Vision QA 抽 5 帧全在 S1 段，sync_check 抽 12 帧也无法发现文本不匹配**——只有 Whisper 转写 mp3 实际内容 + diff SRT 原文才能发现。**根治**：发飞书前必跑 Whisper。

**Whisper 三大用途**（2026-06-05 v10 实战确认）：

| 用途 | 时机 | 命令 |
|------|------|------|
| **内容验证**（防 mp3 ≠ SRT 错配） | 每次生成新 mp3 后 | `whisper <mp3> --language zh --model tiny --output_format srt` → diff SRT |
| **时间戳重切**（防 silencedetect 漏） | 每次 SRT 偏差 > 0.5s | `whisper <mp3> --word_timestamps True --output_format srt` → 合并到 SRT |
| **质量兜底**（防 TTS 用了错误脚本） | 每次 TTS 后 | Whisper 听到的内容与脚本相差甚远 = TTS 用了错误脚本 |
