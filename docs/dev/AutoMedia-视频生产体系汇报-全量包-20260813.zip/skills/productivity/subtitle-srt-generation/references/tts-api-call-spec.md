# TTS API 调用规范（2026-05-26 新增）

## TTS API 调用规范（2026-05-26 新增）

MiniMax speech-2.8-hd API 必须用整数：
```python
payload = {
    "voice_setting": {
        "voice_id": "Chinese (Mandarin)_Radio_Host",
        "speed": 1.0,   # 浮点 OK
        "vol": 10,        # int，非 1.0
        "pitch": 0,       # int，非 0.0
        "emotion": "calm"
    }
}
```
