# v11 终极修复案例（2026-06-05 Alphabet + OpenAI）

> **报告时间**：2026-06-05
> **范围**：AlphabetAnthropic + OpenAICodexTeam 两个视频 v3-v11 共 9 轮修复
> **核心结论**：**SRT 文本 + mp3 朗读 + 段边界 = 全部从 mp3 silencedetect 真实句尾算**——手写 SRT 估算偏差 1-2.6s，v11 用真实句尾后偏差 = 0.00s

## 一、v3-v10 失败的 6 个根因

| 版本 | 修复尝试 | 真实根因 | 引入的新问题 |
|------|---------|---------|------------|
| v3 | 手写 TransitionSeries | "已交付不改进"铁律误用 | 没用 NSegmentSkeleton 模板 |
| v4 | 用 NSegmentSkeleton + 12 通用组件 | 漏 N 段骨架 | vision QA 9.5/10 通过 |
| v5 | 字幕改回 SRT 原文 | 改短 SRT 文本 | 改后又擅自估 start |
| v6 | 段内 start/duration 修正 | 估算偏差 1-4s | multisession 抽帧污染 |
| v7 | silencedetect 重切 SRT | 漏短停顿 | 句尾错位 1-5s |
| **v8** | **edge-tts 重生成 mp3** | **擅自换声音** | Whisper 验证找到核心 root cause |
| v9 | m3 tts 重生成 + silencedetect | 漏短停顿 | 残余 1-2.9s 偏差 |
| **v10** | **Whisper word_timestamps 校准** | **删 E11 幽灵字幕** | E11 擅自加（"关注就行。"） |
| **v11** | **srtTimeToFrame + 真实句尾** | **彻底解决** | **0.00s 偏差（9/9 entries）** |

## 二、v11 5 步工作流（必走）

```bash
# Step 1: ffmpeg silencedetect 拿 mp3 真实静音点（**必跑**）
ffmpeg -i <mp3> -af "silencedetect=noise=-30dB:d=0.3" -f null - 2>&1 | \
  grep "silence_start" | awk '{print $NF}' > /tmp/silences.txt

# Step 2: 对照 SRT 文本（10/11 entries），按 silences 真实句尾重切
# 保持 SRT 文本 100% = TTS 朗读，但时间戳按 silences 真实句尾

# Step 3: SCENE_SUBTITLES 段内 start/duration 按 srtTimeToFrame() 算
# 段内 start = srtTimeToFrame("00:00:XX,XXX") - 段起点
# 段内 duration = entry.end - entry.start

# Step 4: 跑 render_with_qa.sh hook 6 步（linter + voice + scene-data count + render + sync + Whisper）
bash scripts/render_with_qa.sh <CompId> out/<file>.mp4 \
  public/audio/<topic>.mp3 public/subtitles/<topic>.srt

# Step 5: vision QA 抽 ≥10 帧验证字幕文本 100% = SRT
```

## 三、v11 实战数据

### Alphabet (37.69s, 9 entries)

| # | SRT end | TTS 静音 | 偏差 | 文本 |
|---|---------|---------|------|------|
| 1 | 3.65 | 3.65 | 0.00 | AI 行业八月的头条， |
| 2 | 6.82 | 6.82 | 0.00 | 全被一笔融资和一份招股书抢走了。 |
| 3 | 9.85 | 9.85 | 0.00 | Alphabet 拟融资 800 亿美元， |
| 4 | 18.02 | 18.02 | 0.00 | Anthropic 同步提交 IPO 申请——两笔交易合计规模超过千亿。 |
| 5 | 19.41 | 19.41 | 0.00 | Alphabet 现金储备超 950 亿， |
| 6 | 21.74 | 21.74 | 0.00 | Anthropic 估值半年翻 4 倍。 |
| 7 | 25.16 | 25.16 | 0.00 | 机构为什么突然重仓 AI？ |
| 8 | 32.79 | 32.79 | 0.00 | 因为算力即内容产能——AI 内容生产赛道进入军备竞赛阶段。 |
| 9 | 37.69 | 37.39 | +0.30 | 关注壹目贯维...生成多平台内容。（末段 0.3s WARN）|

**汇总**：PASS=8, WARN=1, BLOCK=0

### OpenAI (40.21s, 9 entries)

| # | SRT end | TTS 静音 | 偏差 | 文本 |
|---|---------|---------|------|------|
| 1 | 7.68 | 7.68 | 0.00 | OpenAI 又放大招——Codex 推出团队专属插件， |
| 2 | 9.91 | 9.91 | 0.00 | 编程场景的团队协作正式登陆。 |
| 3 | 12.57 | 12.57 | 0.00 | 以前 Codex 是单人工具， |
| 4 | 17.17 | 17.17 | 0.00 | 现在团队能用同一套配置：共享 prompt 库、统一代码规范、 |
| 5 | 19.15 | 19.15 | 0.00 | 协同调试、插件支持权限分级。 |
| 6 | 21.89 | 21.89 | 0.00 | 版本回滚、 |
| 7 | 27.57 | 27.57 | 0.00 | 代码 review 流——CI/CD 集成 + Slack 通知 + Jira 关联。 |
| 8 | 36.06 | 36.06 | 0.00 | AI 内容生产也是一样——团队插件思路：从单兵作战到流水线协作。 |
| 9 | 38.53 | 38.53 | 0.00 | 关注壹目贯维...从今天开始。（末段填到末静音点 38.53，不是 40.21）|

**汇总**：PASS=9, WARN=0, BLOCK=0

## 四、3 个反模式（v11 固化）

### 反模式 28：手写 SRT 估算 entry end

**症状**：SRT entry end 用"段落大致时间"手写（如 E4 end 15.36 估算 = 估算 +0.5-2s）
**后果**：偏差 1-2.6s（v3-v10 案例）
**正确做法**：必从 mp3 silencedetect 真实句尾算（`ffmpeg silencedetect=noise=-30dB:d=0.3`）

### 反模式 29：S5 末段 end 用 mp3 总时长

**症状**：S5 末段 end 用 mp3 实测总时长（如 40.21s），实际 mp3 末 1-2s 是静音尾巴
**后果**：末段偏差 1-2s（openai 案例，E9 偏差 1.68s）
**正确做法**：S5 末段 end 校准到 mp3 末**静音点**（openai 38.53s，不是 40.21s）—— Composition S5_TO 用 srtTimeToFrame("00:00:38,530") 而非 srtTimeToFrame("00:00:40,210")

### 反模式 30：E10 短 entry < 10 帧

**症状**：S5 末段拆 E9+E10 两个 entry，E10 duration < 10 帧（0.3s 静音尾巴）
**后果**：SubtitleCard `interpolate([10, 9])` panic（v11 渲染 1122 帧报错）
**正确做法**：E10 短 entry 文本**并入 E9**（S5 CTA 单 entry，9 entries 取代 10/11 entries）

## 五、v11 完整 timeline（6-05 一天）

| 时间 | 动作 | 状态 |
|------|------|------|
| 11:00 | session 113223 时代 mp3 ≠ SRT 错配 | 发现 |
| 12:00-17:00 | v3-v7 反复修复，10 轮全失败 | 失败 |
| 17:30 | v8 edge-tts 擅自换声音 | 严重错误 |
| 18:00 | v9 m3 tts 重生成 male-qn-qingse | 声音恢复 |
| 18:30 | v10 Whisper word_timestamps | 删 E11 幽灵字幕 |
| 19:00 | v10 残余 0.5-2.7s 偏差 | 部分修复 |
| 22:00 | **v11 silencedetect 真实句尾** | **0.00s 偏差** |
| 22:20 | 飞书报告 + 事故报告存档 | 收官 |

## 六、v11 沉淀的 4 个产物

1. **5+1 步工作流**（patch 进 `remotion-workflow` skill）
2. **6 步硬约束 hook**（`scripts/render_with_qa.sh`，V0-V5 + V6 hook pipeline）
3. **v11 2 视频**：`out/{alphabet-anthropic-v11.mp4, openai-codex-team-v11.mp4}`
4. **事故报告**：`~/.hermes/profiles/content/.audit/2026-06-05-chaos.md`

## 七、给未来 agent 的建议

**加载这个文件后必读**：
1. `remotion-workflow` 的 5+1 步工作流（必走）
2. `automedia-production-guard` 的 V0-V5 6 个 gate
3. `remotion-timecode-anti-pattern` 的反模式 A（硬编码时间戳）

**核心一句话**：
> **"手写 SRT 估算 = 偏差 1-2.6s；silencedetect 真实句尾 = 0.00s"** —— 必跑 `ffmpeg silencedetect` 拿真实静音点
