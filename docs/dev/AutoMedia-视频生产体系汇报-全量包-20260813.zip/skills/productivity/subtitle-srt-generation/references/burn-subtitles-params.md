# 官方 burn_subtitles.py 参数说明

### 官方 burn_subtitles.py 参数说明

| 参数 | 值 | 说明 |
|------|-----|------|
| `--segments` | JSON文件路径 | **不是** `--segs-json`（那是内联JSON字符串） |
| `--fps` | 2 | 提取帧率，41s=84帧，66s=133帧，足够质量 |
| `--font-size` | 55 | 字幕字号 |
| `--subtitle-margin-bottom` | 120 | 距底部像素 |
| `--margin-h` | 40 | 左右边距 |
| `--audio-file` | mp3路径 | 外部音频（不用视频内置音轨时） |
