# SRT 生成新路径（2026-05-24 验证通过）

## 核心结论

**Whisper 不参与 SRT 生成。** Whisper 只用于音频质量验证（SRT 生成前检查音频文件大小/时长是否正常；SRT 生成后抽帧送 Vision QA）。

```
脚本文案（精准） → 直接生成 SRT → TTS音频 → burn_subtitles.py 烧录
                                        ↓
                                   Whisper（仅验音频，不写 SRT）
```

## 旧流程（已废弃）

```
脚本文案 → TTS → Whisper ASR → SRT（丢失精度，引入误差）
                                ↓
                           PIL 逐帧烧录（25fps，超时风险）
```

## 新流程（2026-05-24 验证）

### Step 1：生成 SRT（不经 Whisper）

```python
import json, re

def build_srt_proportional(script_lines, audio_path, output_srt_path):
    """直接从脚本原文生成 SRT，按字符比例分配时间轴"""
    
    # 音频总时长 ffprobe 实测
    probe = subprocess.run(
        ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'json', audio_path],
        capture_output=True, text=True
    )
    audio_dur = float(json.loads(probe.stdout)['format']['duration'])
    
    # 每条 ≤45字 检查
    for line in script_lines:
        max_len = max(len(l) for l in line.split('\n'))
        if max_len > 45:
            raise ValueError(f"超限: {max_len}字 > 45字 | {line[:30]}")
    
    # 时间轴按字符比例分配
    total_chars = sum(len(s) for s in script_lines)
    entries = []
    t = 0.0
    for sent in script_lines:
        chars = len(sent)
        end_t = t + (chars / total_chars) * audio_dur
        entries.append([round(t, 2), round(end_t, 2), sent])
        t = end_t
    
    # 写入 SRT
    def fmt_time(s):
        h = int(s // 3600)
        m = int((s % 3600) // 60)
        sec = int(s % 60)
        ms = int((s - int(s)) * 1000)
        return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"
    
    with open(output_srt_path, 'w', encoding='utf-8') as f:
        for i, (start, end, text) in enumerate(entries, 1):
            f.write(f"{i}\n{fmt_time(start)} --> {fmt_time(end)}\n{text}\n\n")
    
    # 品牌名检查（正则扫描错误变形）
    with open(output_srt_path) as f:
        content = f.read()
    wrong = re.findall(r'一目贯维|一目惯为|义务官为|壹目惯为', content)
    if wrong:
        raise ValueError(f"品牌名错误变形: {wrong}")
    
    return entries
```

### Step 2：转 segments.json（给 burn_subtitles.py 用）

```python
import json, re

def srt_to_segs(srt_path):
    def parse_t(s):
        s = s.strip().replace(',', '.')
        h, m, rest = s.split(':')
        sec, ms = rest.split('.')
        return float(h)*3600 + float(m)*60 + float(sec) + float(ms)/1000
    
    with open(srt_path, encoding='utf-8') as f:
        content = f.read()
    
    segs = []
    for block in re.split(r'\n\n+', content.strip()):
        lines = block.split('\n')
        if len(lines) < 3:
            continue
        t = lines[1].split(' --> ')
        text = '\n'.join(lines[2:])
        segs.append([parse_t(t[0]), parse_time(t[1]), text])
    
    with open(srt_path.replace('.srt', '_segs.json'), 'w', encoding='utf-8') as f:
        json.dump(segs, f, ensure_ascii=False)
    
    return segs
```

### Step 3：烧录（用官方 burn_subtitles.py）

```bash
python3 /home/renanzai/.hermes/skills/productivity/automedia/scripts/burn_subtitles.py \
  video_nosub.mp4 \
  video_final.mp4 \
  --segments subtitle_new_segs.json \
  --fps 2 \
  --font-size 55 \
  --subtitle-margin-bottom 120 \
  --margin-h 40 \
  --audio-file audio_voiceover.mp3
```

## 性能对比

| 指标 | 旧流程（PIL 25fps） | 新流程（burn_subtitles.py fps=2） |
|------|-------------------|----------------------------------|
| 帧数（41s视频） | 1046帧 | **84帧**（1/12） |
| 帧数（66s视频） | 1659帧 | **133帧**（1/12） |
| 引流款烧录耗时 | ~500s（超时风险） | **~30s** |
| 业务款烧录耗时 | 超时（600s跑不完） | **~45s** |
| SRT文本精度 | Whisper ASR误差（近音字） | **100%脚本原文** |
| 时间轴精度 | Whisper边界（碎片化） | **按字符比例均匀分配** |

## 为什么会超时（旧流程根因）

PIL 逐帧烧录 720×1280 分辨率：
- 每帧背景：720 × 90px ≈ 64,800 像素写入
- 业务款：1,659帧 × 64,800像素 ≈ **1.07 亿次像素操作**
- 600s 超时限制下：1.4帧/秒，业务款只完成 855帧（51.5%）

官方 `burn_subtitles.py`：
- 帧提取：fps=2（不是25）→ 帧数降到 1/12
- PIL 烧录：4 个 worker 并行
- 结果：66s 业务款 **~45s 完成**

## 已知局限

- fps=2 输出视频也是 2fps（画面动作不连贯），适合图文类视频，不适合快节奏剪辑
- 时间轴按字符比例分配，对语速不均匀的脚本会有误差（但比 Whisper 碎片化好）
- 品牌名"壹目贯维"在 TTS 中可能被读成"義務官為"（粤语TTS音色问题），此时 Whisper 能发现，但新流程需要额外音频校验步

## 何时需要音频校验（Whisper 仍参与的唯一场景）

如果 TTS 音色对品牌名有特殊发音（如粤语/其他音色把"壹目贯维"读成明显不同的音），需要：
1. TTS 生成后，用 Whisper 听音频中是否有"壹目贯维"（不是"義務官為"）
2. 若 Whisper 听到的不是品牌名 → 换回中文标准音色重做 TTS
3. 然后走新流程生成 SRT（不依赖 Whisper 的文本输出）