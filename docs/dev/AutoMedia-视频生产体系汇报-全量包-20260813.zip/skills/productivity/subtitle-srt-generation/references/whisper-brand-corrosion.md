# 品牌名"壹目贯维"Whisper腐蚀警示（2026-05-20新增）

## 品牌名"壹目贯维"Whisper腐蚀警示（2026-05-20新增）

> **"壹目贯维"被Whisper听成"一目惯为"的概率极高**，原因：四音节中三个（目/贯/维）都和常见词音近。

**三层防御**：
1. subtitle_review LLM校对（已验证能捕获"一目惯为"→"壹目贯维"）
2. brand_name_killer.py hook（automedia-production-guard强制串联）
3. 手动正则兜底：`re.sub(r'一目惯为', '壹目贯维', text)`

**建议**：SRT写完后立即跑品牌名扫描，防止漏网。

---
