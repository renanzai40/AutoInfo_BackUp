# 比例分配时间轴 vs Whisper 识别（2026-05-20 实测结论）

## 核心决策树

TTS音频已生成 → 脚本文本是否正确（人工确认过）？
- YES → 用比例分配时间轴（不用Whisper）
- NO → 用Whisper检测边界，但文本必须用脚本原文

## 比例分配标准流程

```python
import subprocess, json
probe = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", audio_path], capture_output=True, text=True)
total_dur = float(json.loads(probe.stdout)["format"]["duration"])
sentences = ["第一句", "第二句", ...]
total_chars = sum(len(s) for s in sentences)
entries = []
t = 0.0
for sent in sentences:
    chars = len(sent)
    end_t = t + (chars / total_chars) * total_dur
    entries.append([round(t, 2), round(end_t, 2), sent])
    t = end_t
```

## 何时用比例分配

- TTS使用的是正确脚本，文本无需从音频识别
- 只需要知道每句话的时间边界

## 何时不用

- TTS生成的文本与预期不符（需Whisper验证）
- 音频里有非脚本内容（音乐/音效等）

## Whisper 的唯一不可替代价值

**语音边界检测**（这句话从哪里开始到哪里结束）。

Whisper 文本识别对中文TTS质量差：
- TTS音色导致近音字错误
- "壹目贯维" → "一目惯为" / "义务官为"
- "语音合成" → "语音和程"

## 品牌名近音字白名单（regex预处理）

```python
BRAND_VARIATIONS = ["壹目贯维", "一目惯为", "义务官为"]
def prefilter_brand(text):
    for var in BRAND_VARIATIONS[1:]:
        text = text.replace(var, BRAND_VARIATIONS[0])
    return text
```

## subtitle_review 超时降级路径（2026-05-20 新增）

LLM校对超时 → 直接走品牌名regex预处理 + 逐entry目检，不需要重试LLM。

## concat filter 时长偏差

图片序列视频concat后时长会系统性偏小，用setpts扩展：
```bash
RATIO=$(python3 -c "print($AUDIO_DUR / $CONCAT_DUR)")
ffmpeg -i video_only.mp4 -i audio.mp3 \
  -filter_complex "[0:v]setpts=${RATIO}*PTS[v]" \
  -map "[v]" -map "1:a" -shortest output.mp4
```

## 全流程正确顺序（2026-05-20 确认）

```
1. 写脚本（人工确认句子列表）
2. TTS生成音频 → 拿总时长
3. 比例分配时间轴 → SRT初版
4. 品牌名regex预处理
5. 目视检查全部entries
6. 写SRT终版
7. burn_subtitles.py 烧录
```

**不再有 Whisper 文本识别步骤。**
