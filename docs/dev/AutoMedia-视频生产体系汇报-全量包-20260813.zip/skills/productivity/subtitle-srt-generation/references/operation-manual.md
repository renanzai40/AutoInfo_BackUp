# 操作手册（必须按顺序执行）

### 操作手册（必须按顺序执行）

**Step 1**：从 approved 脚本提取正文行 → 检查每条 ≤45字 → 拆分超长 CTA

**Step 2**：生成 SRT
```python
# 音频总时长 ffprobe 实测
probe = subprocess.run(['ffprobe', '-v', 'error', '-show_entries',
    'format=duration', '-of', 'json', audio_path], capture_output=True)
total_dur = float(json.loads(probe.stdout)['format']['duration'])

# 按字符比例分配时间轴
total_chars = sum(len(s) for s in script_lines)
t = 0.0
for sent in script_lines:
    end_t = t + (len(sent) / total_chars) * total_dur
    entries.append([round(t,2), round(end_t,2), sent])
    t = end_t

# 写入 SRT
```

**Step 3**：SRT → segments.json（给官方烧录脚本用）
```python
# srt_to_segs.py 转换脚本（见 scripts/srt_to_segs.py）
# 用法：python3 <skill>/scripts/srt_to_segs.py
# 输出：subtitle_new_segs.json
```

**Step 4**：官方 burn_subtitles.py 烧录（fps=2）
```bash
python3 <skill>/../automedia/scripts/burn_subtitles.py \
  video_nosub.mp4 video_final.mp4 \
  --segments subtitle_new_segs.json \
  --fps 2 \
  --font-size 55 \
  --subtitle-margin-bottom 120 \
  --margin-h 40 \
  --audio-file audio_voiceover.mp3
```

> ⚠️ **禁止**：自行写 PIL 逐帧烧录逻辑、使用非官方脚本、从 Whisper 重建 SRT 文本。
