# SRT生成实操笔记 — 2026-05-21 实测

## 核心原则（铁律）

1. **文本=脚本原文**：Whisper ASR的文本是参考，唯一可信文本是MiniMax脚本原文
2. **时间轴=Whisper真实segment边界**：不得用字数÷语速估算
3. **每Entry≤45字**：超45字必须拆分

## 实战流程（本session实测）

### Step 1：Whisper转写 → 获取片段边界

```bash
WHISPER=/home/renanzai/mamba/envs/whisper/bin/python3
$WHISPER -c "
import whisper, json
model = whisper.load_model('base', device='cpu')
result = model.transcribe('audio.mp3', language='zh', task='transcribe')
with open('whisper_result.json', 'w') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
"
```

### Step 2：分析片段边界（关键！）

Whisper返回的片段数≠脚本行数。通常是2-3个片段压缩进1个脚本行。

**正确做法**：
1. 先读所有Whisper片段（共N个，索引0~N-1）
2. 按顺序把相邻片段分配给脚本行
3. 验证每个脚本行的字数（≤45字）
4. 超限→在该脚本行内部按语义再拆分（不是合并）

**典型错误**：假设"每3个片段=1个脚本行"然后硬套。本session教训：seg7-8应该是Entry 3的结尾，但硬套3片段/行规则导致Entry 3语速2.2字/秒（异常），Entry 4变成78字超限。

### Step 3：验证字符数

```python
for i, (start_idx, end_idx, text) in enumerate(entries):
    chars = len(text)
    dur = segments[end_idx]["end"] - segments[start_idx]["start"]
    speed = chars / dur if dur > 0 else 0
    print(f"E{i+1}: {chars}字({speed:.1f}字/秒) | {'OK' if chars <= 45 else '超限'}")
```

### Step 4：SRT格式

```python
def fmt_time(t):
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    ms = int((t % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

with open(output_path, "w", encoding="utf-8") as f:
    for entry_num, start_idx, end_idx, text in entries:
        start = segments[start_idx]["start"]
        end = segments[end_idx]["end"]
        f.write(f"{entry_num}\n{fmt_time(start)} --> {fmt_time(end)}\n{text}\n\n")
```

## 本session分组方案（AI内容生产工作流，47.95s音频，273字脚本）

共27个Whisper片段，分11个SRT entry：

| Entry | seg范围 | 字数 | 内容 |
|-------|---------|------|------|
| 1 | 0-1 | 18字 | 你知道吗？追热点这件事，本质上是个伪命题。 |
| 2 | 2-4 | 31字 | 热点来了，内容团队还在赶昨天的稿子。等稿子出来，热度已经过了。 |
| 3 | 5-6 | 16字 | 想追，追不上；不追，流量就丢了。 |
| 4 | 7-8 | 18字 | 我研究了很多内容团队，发现一个规律： |
| 5 | 9-11 | 35字 | 真正能持续追热点的团队，不是执行力更强，而是他们的工作流本身就不一样。 |
| 6 | 12-14 | 24字 | 热点来了，AI先跑框架，人工只做最后一步的判断。 |
| 7 | 15-17 | 21字 | 从发现热点到多平台发布，一套流程全部打通。 |
| 8 | 18-19 | 39字 | 所以问题的本质不是"怎么追热点"，而是"怎么让内容生产流程本身就能追上热点"。 |
| 9 | 20-21 | 11字 | 这是两件完全不同的事。 |
| 10 | 22-23 | 35字 | 壹目贯维做的事很简单：热点自动追踪，AI帮你生成文案，一键发到全平台。 |
| 11 | 24-26 | 21字 | 如果你也在为追热点头疼，关注我，了解更多。 |

## 常见错误

| 错误 | 后果 |
|------|------|
| 假设片段数/脚本行数=固定比例 | 分组错位，语速异常 |
| Entry超45字不拆分 | 字幕2-3行，违反UI规范 |
| 用比例分配时间轴 | 破坏句子边界，时间轴偏移 |
| 不验证seg索引范围 | AssertionError（end_idx超范围） |

## burn_subtitles.py 参数名（实测）

```
--font-size          # 不是 --subtitle-font-size
--subtitle-margin-bottom  # 正确
--big-title          # 大标题（全帧存在）
--title-font-size    # 大标题字号
--title-color        # 大标题颜色，格式R,G,B
--fps                # 帧率
--audio-file         # 外部音频文件
```
