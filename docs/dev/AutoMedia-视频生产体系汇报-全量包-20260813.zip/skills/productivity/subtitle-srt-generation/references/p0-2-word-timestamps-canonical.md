# P0-2 铁律：Whisper word_timestamps 是 SRT 重新对齐的 CANONICAL 方法

### P0-2 铁律：Whisper word_timestamps 是 SRT 重新对齐的 CANONICAL 方法

> **2026-06-05 v10 实测**：silencedetect d=0.3 漏了 TTS 连续朗读时的短停顿（E1+E2 一气呵成，silencedetect 报 11.21s 是合并末，不是 E1 末）——导致 SRT 切分偏差 1-2.5s。**Whisper word_timestamps 提供每个字的实际起止 = 真实朗读边界**——最准的 SRT 切分依据。

**Whisper word_timestamps 工作流**：

```bash
# 1. 转写 mp3 实际内容 + 词级时间戳
whisper <mp3_path> --language zh --model tiny \
    --word_timestamps True --output_format srt \
    --output_dir /tmp/whisper_word/

# 2. Whisper 输出按真实句尾切分（alphabet 14 entries / openai 18 entries 实测）
# 3. 合并 Whisper 切分到项目 SRT 文本（保证 100% 文本匹配 TTS 朗读）
# 4. SCENE_SUBTITLES 段内 start/duration 按 Whisper 校准的真实时间戳算
# 5. 重渲染 → vision QA ≥10 帧验证
```
