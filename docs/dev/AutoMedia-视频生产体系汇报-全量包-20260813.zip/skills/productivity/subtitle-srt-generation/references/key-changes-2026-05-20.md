# 关键变更（2026-05-20）

## 关键变更（2026-05-20）

> **TTS文本正确时用比例分配时间轴**，不需要Whisper识别文本。详见 `references/proportional-timing-2026-05-20.md`。
>
> **subtitle_review 超时降级路径**：LLM超时 → 直接走品牌名regex预处理 + 逐entry目检，不需要重试LLM。
>
> **SRT分组实战（2026-05-21）**：`references/srt-generation-pitfalls-2026-05-21.md` — Whisper片段数≠脚本行数，分组无固定比例，需逐片段分析边界并验证字数≤45。
