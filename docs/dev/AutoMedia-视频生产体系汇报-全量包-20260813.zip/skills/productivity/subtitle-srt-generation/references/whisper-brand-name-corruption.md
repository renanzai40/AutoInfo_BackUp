# Whisper ASR 品牌名"壹目贯维"腐蚀日志（2026-05-20 固化）

> "壹目贯维"因包含生僻字，在 Whisper ASR 中极易被误听为近音变形词。
> 这是可复现的系统性错误，不是个案。

## 腐蚀模式

| 正确词 | Whisper听到 | 音近字对应 |
|--------|------------|-----------|
| 壹目**贯维** | 一目**惯为** | 贯→惯 / 维→为 |
| 壹**目**贯维 | 壹**日**目惯为 | 目→日（少见，但可能） |

**规律**：Whisper对罕见专有名词（壹/贯/维都是低频字）倾向于替换为高频近音常用字。

## 实测案例

### 普京访华（2026-05-20）
- 原文：`壹目贯维是如何快速追踪`
- Whisper输出：`一目惯为是如何快速追踪`
- 修正：`一目惯为` → `壹目贯维`

### AI语音合成（2026-05-20）
- 原文：`壹目贯维AI语音合成`
- Whisper输出：`一目惯为AI语音合成`
- 修正：`一目惯为` → `壹目贯维`

## 防御方案

### 第一道：subtitle_review() LLM校对
```python
entries = review_srt(srt_path, script_path)
```
已验证能捕获"一目惯为"→"壹目贯维"。

### 第二道：brand_name_killer.py hook
automedia-production-guard 中强制串联，自动扫描 SRT/脚本/文章中的品牌名变形。

### 第三道：手动正则兜底
SRT写完后立即执行：
```python
import re
with open("subtitle.srt") as f:
    content = f.read()
fixed = re.sub(r"一目惯为", "壹目贯维", content)
with open("subtitle.srt", "w") as f:
    f.write(fixed)
```

## 关联文件
- `references/asr-error-log-2026-05-17.md` — 其他 Whisper 近音字错误模式
- `scripts/subtitle_review.py` — LLM 校对脚本
- `hooks/brand_name_killer.py` — 品牌名变形检测 hook
