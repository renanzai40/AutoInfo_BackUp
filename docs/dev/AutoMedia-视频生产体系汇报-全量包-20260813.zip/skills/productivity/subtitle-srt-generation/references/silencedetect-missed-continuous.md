# 边界 case：silencedetect 漏连续朗读（2026-06-05 v7 实测）

### 边界 case：silencedetect 漏连续朗读（2026-06-05 v7 实测）

> **6-05 alphabet 10 entries，silencedetect d=0.3 给 9 个真句尾 + 1 个 mp3 末**：
> - 期望 10 个句尾，实际 9 个
> - 缺失的句尾 = E1 与 E2 之间（被合并到 E3 句尾 12.30s）
> - **根因**：TTS 朗读 E1（2.91s）→ E2（4.54s）中间无停顿（标点"，"短停顿 < 0.3s 未被检测）→ silencedetect 报 12.30s = E1+E2+E3 合并末

**根治**：用 Whisper word_timestamps（每个字的起止都准），不靠 silencedetect。
