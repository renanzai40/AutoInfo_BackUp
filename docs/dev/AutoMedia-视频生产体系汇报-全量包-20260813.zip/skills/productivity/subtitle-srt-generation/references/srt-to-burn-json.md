# SRT → burn_subtitles.py JSON 格式转换

## burn_subtitles.py 接受格式

```python
[
    {"start": 0.0,   "end": 3.52,  "text": "2535亿美元签完了"},
    {"start": 3.839, "end": 5.919, "text": "但你知道这2535亿里"},
    ...
]
```

- `start/end`: **秒数浮点数字符串**，不是 SRT 的 `HH:MM:SS,mmm`
- `text`: 原始文本（含换行 `\n` 会被 PIL 正确处理）

## 转换函数

```python
import re

def srt_to_burn_json(srt_path):
    """
    SRT 文件 → burn_subtitles.py 用的 JSON segments 列表
    时间轴自动从 HH:MM:SS,mmm 转为秒数浮点
    """
    def parse_t(s):
        s = s.strip().replace(',', '.')
        h, m, rest = s.split(':')
        sec, ms = rest.split('.')
        return float(h)*3600 + float(m)*60 + float(sec) + float(ms)/1000

    with open(srt_path, encoding='utf-8') as f:
        blocks = re.split(r'\n\n+', f.read().strip())

    segs = []
    for block in blocks:
        lines = block.split('\n')
        if len(lines) < 3:
            continue
        t = lines[1].split(' --> ')
        segs.append({
            'start': parse_t(t[0]),
            'end':   parse_t(t[1]),
            'text':  '\n'.join(lines[2:])
        })
    return segs
```

## 完整烧录调用示例

```python
import subprocess, json, shutil

FFMPEG  = '/home/renanzai/mamba/envs/ffmpeg/bin/ffmpeg'
FFPROBE = '/home/renanzai/mamba/envs/ffmpeg/bin/ffprobe'
PYPIL   = '/home/renanzai/.hermes/hermes-agent/venv/bin/python3'
BURN    = '/home/renanzai/.hermes/skills/productivity/automedia/scripts/burn_subtitles.py'

def get_dur(path):
    return float(subprocess.run(
        [FFPROBE, '-v', 'quiet', '-show_entries', 'format=duration', '-of', 'csv=p=0', path],
        capture_output=True, text=True
    ).stdout.strip())

video_raw = '/path/to/video_raw.mp4'
audio     = '/path/to/audio.mp3'
srt       = '/path/to/subtitle.srt'
output    = '/path/to/video_final.mp4'
dur       = get_dur(audio)

segs = srt_to_burn_json(srt)

r = subprocess.run([
    PYPIL, BURN, video_raw, output,
    '--segs-json', json.dumps(segs),
    '--audio-file', audio,
    '--fps', '2'
], capture_output=True, text=True, timeout=300)

if r.returncode != 0:
    print('Burn failed:', r.stderr)
    raise SystemExit(1)

# 烧录后时长可能偏离音频，用 -shortest 截断
tmp = '/tmp/video_trimmed.mp4'
r2 = subprocess.run([
    FFMPEG, '-y', '-i', output,
    '-t', str(dur), '-c:v', 'copy', '-c:a', 'copy', tmp
], capture_output=True, text=True)
if r2.returncode == 0:
    shutil.move(tmp, output)

print(f'Final duration: {get_dur(output):.2f}s')
```

## 常见错误

| 错误 | 原因 | 正确 |
|------|------|------|
| `error: unrecognized arguments: --srt` | 用错了参数名 | 用 `--segs-json` |
| `error: unrecognized arguments: --audio_dur_override` | 参数不存在 | 烧录后手动截断 |
| 双行字幕 | entry 文本过长（>18字符/行） | 脚本设计时控制每 entry ≤45字 |