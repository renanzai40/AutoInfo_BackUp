# v11 反模式（永久禁止）

### v11 反模式（永久禁止）

| # | 反模式 | 后果 | 正确做法 |
|---|--------|------|---------|
| 28 | **手写 SRT 估算 entry end** | 偏差 1-2.6s（v3-v10 案例）| 必从 mp3 silencedetect 真实句尾算 |
| 29 | **S5 末段 end 用 mp3 总时长** | 末段偏差 1-2s（openai 案例）| S5 末段 end 校准到 mp3 末静音点（不是总时长）|
| 30 | **E10 短 entry < 10 帧** | SubtitleCard `interpolate([10, 9])` panic | E10 文本并入 E9（S5 CTA 单 entry）|
