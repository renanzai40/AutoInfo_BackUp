# 4 步捷径（不需要 Whisper 时）

### 4 步捷径（不需要 Whisper 时）

如果 mp3 是新生成且**确信 mp3 朗读 = SRT 文本**（如 m3 tts 用 SRT 文本作为输入生成），可走"沉默点 + 字符等分"混合法：

```bash
# Step 1: ffmpeg silencedetect 拿真实句尾
ffmpeg -i <mp3> -af "silencedetect=noise=-30dB:d=0.3" -f null - 2>&1 | grep "silence_end"

# Step 2: 对照 SRT 文本，按 silencedetect 句尾合并到 SRT entries
# ⚠️ silencedetect 漏连续朗读（E1+E2 一气呵成只给 1 个句尾）——

# Step 3: SCENE_SUBTITLES 段内 start/duration 按合并后 SRT 真实起止算

# Step 4: 重渲染 + vision QA
```
