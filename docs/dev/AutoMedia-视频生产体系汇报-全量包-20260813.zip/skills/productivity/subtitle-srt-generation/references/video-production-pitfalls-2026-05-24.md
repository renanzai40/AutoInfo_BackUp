# 视频生产效率对比（2026-05-24 实测）

## 问题：业务款视频生产超时

### 原因分析

| 方法 | 帧提取 fps | 41s视频帧数 | 66s视频帧数 | 烧录方式 | 耗时 |
|------|-----------|------------|------------|---------|------|
| **错误：自定义 PIL 25fps** | 25 | 1046帧 | 1659帧 | PIL 逐帧 + 单进程 | 超时（600s内未完成） |
| **正确：官方 burn_subtitles.py** | 2 | 84帧 | 133帧 | PIL 并行（4 workers） | ~45s |

**根本原因**：我绕过了官方 `burn_subtitles.py`，自己写了个低效的 v2 版本（全帧率提取 + 单进程 PIL）。

### 关键参数

官方 `burn_subtitles.py` 使用 `fps=2`：
- 2fps 已经足够字幕 QA 质量（每 Entry 有中点帧）
- 84帧（41s）用 4 个 worker 并行烧录，速度极快
- 133帧（66s）同样轻松在 45s 内完成

自定义 v2 用 `fps=25`：
- 25fps 对 9:16 竖屏视频没有额外质量收益
- PIL 逐帧 + 像素级 alpha 混合（`math.exp` 渐变）是 O(n×pixels) 的噩梦
- 1,659 帧 × 720×90 像素 = 1.07 亿次像素操作

### 教训

1. **必须使用官方 `burn_subtitles.py`**（`--fps 2`），禁止自行写 PIL 逐帧烧录
2. 官方脚本在 `frames_subtitled/` 目录并发处理，PIL ImageFont 和 ProcessPoolExecutor 并行
3. 如果官方脚本有 bug，修复它而不是绕过它

### 引流款 15s 人脸帧 QA 争议

原 QA 加入了"人脸/Logo"检查——这是我自己加的临时扩展，**不在 skill 标准 prompt 里**。

Skill 标准 prompt（`build_vision_prompt`）只有 4 项：底部位置 / 行数≤3 / 无乱码 / 品牌名正确。

人脸属于 MiniMax 图片生成阶段的内容过滤（`political-topic-image-safe-prompts.md`），不是视频 QA 环节的检查项。

### 已更新：Vision QA 精简版（2026-05-24）

更新后的 `auto_vision_qa.py` → 5 项检查：
1. 字幕在画面底部（下半部分）
2. 字幕行数 ≤ 3
3. 无乱码文字
4. 品牌名正确（不接受"一目惯为"等变形）
5. 无世界地图/政治地图 ✅ 新增（保留了地图检查，因为涉及政治边界风险）

去掉了"人脸"和"Logo"——壹目贯维的内容不需要这么严格。

备份：`auto_vision_qa.py.bak_20260524_1554`

---

## 新 SRT 流程（不经 Whisper，2026-05-24 验证通过）

```
脚本文案（已知精准）→ 按标点断句（每条≤45字）→ ffprobe音频时长 → 按字符比例分配时间轴 → SRT文件
                                                                              ↓
                                             srt_to_segs.py → segments.json
                                                                              ↓
                               burn_subtitles.py --fps 2 → 视频最终文件
```

Whisper 的角色降级为：**仅用于音频质量验证**（检查 Whisper 听到的内容是否与脚本基本一致），不参与 SRT 文本或时间轴生成。