# P0-3 铁律：SCENE_SUBTITLES 文本必须 100% = SRT 原文（= TTS 朗读文本）

### P0-3 铁律：SCENE_SUBTITLES 文本必须 100% = SRT 原文（= TTS 朗读文本）

> 见 `remotion-workflow` skill（已归档——HyperFrames 不依赖 Remotion 架构，此规则仅供参考）。
