# v11 实战数据

### v11 实战数据

| 视频 | E1-E9 entries 偏差 | E9 末段 | sync check |
|------|------------------|---------|-----------|
| Alphabet (37.69s, 9 entries) | E1-E8 = 0.00s | E9 = 0.30s WARN | 8/9 PASS, 1/9 WARN |
| OpenAI (40.21s, 9 entries) | E1-E8 = 0.00s | E9 = 0.00s | **9/9 PASS 全绿** |
