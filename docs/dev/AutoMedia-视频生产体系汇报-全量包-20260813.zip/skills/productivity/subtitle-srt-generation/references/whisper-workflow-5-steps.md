# 完整工作流（5 步）

### 完整工作流（5 步）

```bash
# Step 1: Whisper word_timestamps 转写 mp3 实际内容
whisper <mp3_path> --language zh --model tiny \
    --word_timestamps True --output_format srt \
    --output_dir /tmp/whisper_word/
# 输出：/tmp/whisper_word/<mp3_name>.srt
# 内容：每条 entry 包含真实句尾时间戳（不是字符比例估算）

# Step 2: 对照 SRT 文本，按 Whisper 真实句尾合并到 10/11 entries
# 规则：保持项目 SRT 文本 100% = TTS 朗读，但时间戳按 Whisper 真实句尾
# 例（alphabet 14 entries → 合并到 10 entries SRT）：
#   W1 0.000-2.280 + W2 2.280-5.480 → SRT E1+E2 (0.000-5.480)
#   W3 6.300-8.960 → SRT E3 (5.480-8.960)  # 跳过 0.82s 静默
#   W4 8.960-12.200 + W5 12.200-15.360 → SRT E4 (8.960-15.360)
#   W6 15.360-18.780 → SRT E5
#   W7 18.780-21.200 → SRT E6
#   W8 21.200-23.740 → SRT E7
#   W9+W10+W11 24.280-30.240 → SRT E8 (合并"因为算力即内容产能 AI 内容生产赛道 进入军备竞赛阶段")
#   W12+W13 30.240-36.000 → SRT E9
#   W14 36.000-37.480 → SRT E10

# Step 3: SCENE_SUBTITLES 段内 start/duration 按新 SRT 真实起止算
# 段内 start = SRT entry 绝对起 - 段 FROM
# 段内 duration = SRT entry 绝对末 - 绝对起
# 例：S2 段 (223..487) 内 E3 起 5.480-8.960 → 段内 start=0, duration=104

# Step 4: 改 scene-data.ts 段 boundaries（按新 SRT entry 切段）
# 段边界 = srtTimeToFrame("00:00:XX,XXX")（按 Whisper 校准的时间）

# Step 5: 重渲染 + vision QA ≥10 帧验证
bunx remotion render <CompId> out/<file>.mp4
# 抽 10 帧（每段 2 帧）vision QA 字幕文本 + 时序
```
