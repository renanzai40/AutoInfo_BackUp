# 完整 v11 工作流（5 步）

### 完整 v11 工作流（5 步）

```bash
# Step 1: ffmpeg silencedetect 拿 mp3 真实静音点（**必跑**）
ffmpeg -i <mp3> -af "silencedetect=noise=-30dB:d=0.3" -f null - 2>&1 | \
  grep "silence_start" | awk '{print $NF}' > /tmp/silences.txt

# Step 2: 对照 SRT 文本（10/11 entries），按 silences 真实句尾重切
# 规则：保持 SRT 文本 100% = TTS 朗读，但时间戳按 silences
# 例（alphabet 10 entries，silencedetect 22 个静默点）：

# Step 3: SCENE_SUBTITLES 段内 start/duration 按 srtTimeToFrame() 算
# 段内 start = srtTimeToFrame("00:00:XX,XXX") - 段起点
# 段内 duration = entry.end - entry.start

# Step 4: 跑 render_with_qa.sh hook 6 步（linter + voice + scene-data count + render + sync + Whisper）
# sync check 报 PASS（9/9 entries 偏差 < 0.3s）= 完成

# Step 5: vision QA 抽 ≥10 帧验证字幕文本 100% = SRT
```
