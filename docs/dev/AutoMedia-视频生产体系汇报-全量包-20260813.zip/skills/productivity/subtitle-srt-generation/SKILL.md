---
name: subtitle-srt-generation
description: SRT字幕生成标准工作流。每次生成视频字幕（SRT文件）前必须加载并执行。**Whisper 是 SRT 验证与重同步的核心工具**（不是可选）：(1) 验证 mp3 朗读内容 100% = SRT 原文（防 mp3 ≠ SRT 错配，如 session 113223 继承旧 mp3 + 新 SRT 案例）；(2) word_timestamps 重切 SRT 时间轴（防 silencedetect 漏连续朗读短停顿）；SRT 文本必须 = 脚本原文（字节级一致）。必须使用官方 burn_subtitles.py（fps=2）烧录，禁止自定义 PIL 逐帧逻辑。
version: 2.1
author: Hermes Agent for renan
license: MIT
tags: [subtitle, srt, whisper, automedia]
ffmpeg_ref: automedia/references/ffmpeg-subtitles-2026-05-19.md
---
## 🔥 P0 铁律（2026-06-05 v10 终极验证）

## 新路径（2026-05-24 验证通过）⭐

**核心变更**：Whisper 不再参与 SRT 生成（全量走脚本原文 + 比例时间轴）。

## Whisper word_timestamps 校准 SRT（2026-06-05 v10 终极验证 · CANONICAL 方法）

> **之前（旧路径）**：Whisper 仅在 segment 数与脚本句子数差异 ≤30% 时用于辅助分段。**之前（路径A vs 路径B）已弃用**。
> **现在（CANONICAL）**：Whisper word_timestamps 是 SRT 重新对齐的标准方法。**6-05 v10 实测**：Whisper 转写 14 entries（alphabet）/ 18 entries（openai），比 silencedetect 准 1-2s。

## 旧路径：Whisper 参与时（特殊场景保留）
1. 从 approved 脚本提取正文行 → 每条 ≤45字
2. `build_srt_proportional()` → 直接生成 SRT（ffprobe 音频时长 + 按字符比例分配时间轴）
3. `srt_to_segs()` → 转为 segments.json（给 burn_subtitles.py 用）
4. 官方 `burn_subtitles.py --fps 2` 烧录

**严禁**：自行写 PIL 逐帧烧录逻辑、使用非官方脚本、在 Whisper 上构建 SRT 文本。

---

## 🆕 v11 实战教训（2026-06-05 Alphabet/Codex · 6 步硬约束 + 真实句尾校准）

> **v10 之前所有版本 1-2.9s 偏差的根因 = "手写 SRT 估算"**——我按"段落大致时间"手写 SRT entry end，**没用 mp3 真实句尾**。v11 改用 ffmpeg silencedetect 拿 mp3 真实静音点后，**9/9 entries 偏差 = 0.00s**。
>
> **铁律（2026-06-05 v11）**：
> 1. **SRT entry.end 必从 mp3 silencedetect 真实句尾算**（不是字符比例、不是手写估算、不是 Whisper tiny 推断）
> 2. **S5 末段 end 校准到 mp3 末静音点**（不是 mp3 总时长）—— mp3 末 1-2s 通常是静音尾巴，**末段填到末静音点**而不是 mp3 末
> 3. **E10 短 entry 必须并入 E9**（防 SubtitleCard `interpolate([10, 9])` 反模式）

## 标准生产函数

以下情况仍可能需要 Whisper 参与时间轴，但不参与 SRT 文本：

### 何时 Whisper 参与时间轴（路径A）

当 Whisper segment 数与脚本句子数差异 ≤30% 时，可以用 Whisper 边界辅助分段。

### 铁律1：脚本 = 权威文本
**SRT 的文本来源永远是 MiniMax 脚本原文，不是 Whisper ASR 转写。**
TTS 生成的是固定内容，时长精确可测，脚本是已知正确文本，不需要"听写一遍"来获取它。Whisper 是音频分析工具，不是文本生成工具。

### 铁律2：时间轴分配有两条合法路径

**路径A（Whisper 边界 + 脚本文本）**：Whisper 获取 segment 边界，用脚本文本填入每个 entry。
适用：Whisper segment 数量 ≈ 脚本句子数量（误差 ±30%）。

**路径B（纯比例分配）**：当 Whisper 超时、或 Whisper segment 数与脚本句子数差异 >30% 时，用 ffprobe 测音频总时长，按 (句字数 / 总字数) × 音频总时长 分配时间轴。
适用：Whisper API 超时、Whisper 边界严重不准。

### 铁律3：烧录前必须执行品牌名检查
SRT 写入后，立即用正则扫描所有 entry 中的"壹目贯维"及其近音变形。如发现任何 entry 文本与脚本原文不符，立即重做该 entry，不继续烧录。

---

## 标准生产函数

```python
import json, re
from opencc import OpenCC

def build_srt_from_whisper_with_script(whisper_json_path, script_sentences, output_srt_path):
    """
    标准 SRT 生成流程（脚本=权威文本版）：
    1. 读取 Whisper JSON → 获取音频时长和 segment 边界（仅作参考）
    2. 音频总时长用 ffprobe 实测（不用 Whisper 报告的值）
    3. 文本：直接用 script_sentences（已确认为正确内容）
    4. 时间轴：按比例分配（音频总时长 × 句子字数占比）

    注意：Whisper 文本不写入 SRT。Whisper 只在 whisper_segment_count / script_sentence_count ≈ 1 时
    才参与 segment 边界辅助判断；差异大时完全用比例分配。
    """
    # 音频总时长
    import subprocess
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", audio_path],
        capture_output=True, text=True
    )
    total_dur = float(json.loads(probe.stdout)["format"]["duration"])

    total_chars = sum(len(s) for s in script_sentences)
    entries = []
    t = 0.0
    for sent in script_sentences:
        chars = len(sent)
        end_t = t + (chars / total_chars) * total_dur
        entries.append([round(t, 2), round(end_t, 2), sent])
        t = end_t

    # 写入 SRT
    def fmt_time(s):
        h = int(s // 3600)
        m = int((s % 3600) // 60)
        sec = int(s % 60)
        ms = int((s - int(s)) * 1000)
        return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"

    with open(output_srt_path, 'w', encoding='utf-8') as f:
        for i, (start, end, text) in enumerate(entries, 1):
            f.write(f"{i}\n{fmt_time(start)} --> {fmt_time(end)}\n{text}\n\n")

    return entries
```

**Whisper 什么时候不用**：Whisper 文本不作为 SRT entry 文本。Whisper 只用来比对 segment 数量是否与脚本句子数接近（差异 >30% 时走路径B）。

---

## 两阶段强制工序（2026-05-21 新增）

> ⚠️ **Stage 1 必须先完成并确认，才能进入 Stage 2。跳过 Stage 1 视为工艺失误。**

### Stage 1：映射确认表（强制输出物）

生成 SRT 之前，**必须先运行映射脚本**：

```bash
SKILL_SCRIPTS=/home/renanzai/.hermes/skills/productivity/subtitle-srt-generation/scripts
python3 $SKILL_SCRIPTS/build_srt_mapping.py \
    /path/to/whisper_result.json \
    /path/to/script_final.txt
```

**Stage 1 输出物**：
1. 逐片段列表（确认 Whisper 片段边界）
2. 脚本行字数预检（**超45字先行标记**）
3. 分组方案建议（按片段数/行数比率）

**Stage 1 确认条件**：
- 所有脚本行 ≤45字（或已拆分）
- 分组边界已人工确认（无歧义）

**Stage 1 通过后**：将分组方案填入 `build_srt_from_mapping(segments, script_lines, groupings)` 执行 Stage 2。

### Stage 2：SRT 生成

仅在 Stage 1 确认后执行。

---

## 调用时机与强制工序顺序

**automedia skill 强制触发点**：
- TTS音频生成后 → Whisper ASR → **立即调用 `build_srt_from_whisper()`**（仅满足三条铁律的初版SRT）
- → **立即调用 `subtitle_review()`（LLM校对步）** ← **强制，不可跳过**
- → 校对通过后才进烧录

**工序顺序（缺一不可）**：
```
TTS音频 → Whisper JSON → build_srt_from_whisper()  [Step A：初版SRT，三条铁律]
                         ↓
                       subtitle_review()            [Step B：LLM校对] ⚠️强制
                         ↓
                       烧录字幕
```

> ⚠️ **（2026-05-17 更新）**：Step B 强制化。Whisper ASR 存在大量近音字错误（热斗/战比/稳定气/满院父母等），opencc 和正则替换无法穷举，**必须用 LLM 一次性全局对照脚本校对**。正则替换只作为品牌名兜底，不替代 LLM 校对步。

> ⚠️ **（2026-05-20 更新）**："壹目贯维"被 Whisper 系统性腐蚀为"一目惯为"，subtitle_review LLM校对可捕获，但建议额外跑 brand_name_killer.py 二次确认。详见 `references/whisper-brand-name-corruption.md`。

**字幕校对脚本**：`scripts/subtitle_review.py`（在 skill 目录内，加载时用 `sys.path.insert` 指向 skill 的 scripts 目录）
```python
import sys
SKILL_SCRIPTS = '/home/renanzai/.hermes/skills/productivity/subtitle-srt-generation/scripts'
sys.path.insert(0, SKILL_SCRIPTS)
from subtitle_review import review_srt, write_reviewed_srt

reviewed = review_srt(srt_path="/path/to/subtitle.srt", script_path="/path/to/script.txt")
write_reviewed_srt(reviewed, "/path/to/subtitle.srt")  # 覆盖写入
```

**为什么不能用正则列表代替 LLM 校对**：
Whisper ASR 的近音字错误无法穷举。已验证的漏网案例：
- "热斗"（应为"热度"，正则列表无覆盖）
- "满院父母"（应为"埋怨父母"）
- "稳定气动作"（应为"稳定器动作"）
- "战比最高"（应为"占比最高"）
正则列表永远不完备，LLM 一次性对照脚本全文校对是唯一可靠方案。

## SRT 时间轴分配策略（2026-05-19 大幅修正）

### 标准规则

| 要素 | 来源 | 说明 |
|------|------|------|
| **时间轴** | Whisper JSON segment start/end | 唯一可信的时间基准 |
| **文本（标准）** | Whisper 文本（繁转简） | 当识别基本正确时 |
| **文本（替换）** | MiniMax 脚本原文 | 当 Whisper 识别大量错误时 |
| **断句** | 脚本标点拆分 + 比例分配时间轴 | 当需要重建 SRT 时 |

### 何时用「比例分配」而非「直接用 Whisper segment」

**判断标准**：Whisper ASR 全文与脚本全文对比
- 近音字错误 < 5% → 直接用 Whisper 文本 + Whisper 时间轴
- 近音字错误 > 5%，或出现语义完全不同的词 → **比例分配 + 脚本文本**

**典型触发场景**：
- TTS 生成了与脚本不符的音频（简体脚本 + 粤语发音 TTS）
- TTS 音色对特定词有特殊发音（壹目贯维 → 義務官為）
- 脚本在 TTS 生成后被修改

### 比例分配算法

```python
def build_srt_proportional(script_sentences, audio_duration):
    """按字符比例将音频时长分配给各句子"""
    total_chars = sum(len(s) for s in script_sentences)
    cumsum = []
    t = 0
    for s in script_sentences:
        t += len(s)
        cumsum.append(t)

    entries = []
    for i, sent in enumerate(script_sentences):
        end_pct = cumsum[i] / total_chars
        start_pct = (cumsum[i-1] / total_chars) if i > 0 else 0
        start_t = round(start_pct * audio_duration, 2)
        end_t = round(end_pct * audio_duration, 2)
        entries.append([start_t, end_t, sent])
    return entries
```

### 业务款 2026-05-19 完整案例

- 音频：63.56s / 317字
- Whisper：32 segments，文本大量错误（粤语发音干扰）
- 脚本：15个句子，317字
- 决策：Whisper 识别错误率 > 5%，启用比例分配
- 结果：15个 SRT entries，每条 ≤45字，全部合规

### 何时必须重建 TTS

当脚本与 TTS 音频内容完全不匹配时（如：用了错误的脚本版本生成了 TTS），**必须重新生成 TTS**，不得用「比例分配 SRT」修补。

判断：Whisper ASR 和脚本内容根本对不上 → 重新生成音频。

## SRT v2 修复算法（2026-06-05 Alphabet/Codex 实测 · 字符比例偏差 2-4s）

> **触发**：SRT 字符比例分配（路径B）实际偏差 0.9-4.3s（m3 案例 0.9-1.4s，Radio_Host 音色长 entry 末尾停顿 2-4s），sync check 报 BLOCK。
>
> **修复**：用 `ffmpeg silencedetect` 拿 TTS 静音点（17-19 silences），把 13 entry 边界严格对齐静音点 ±0.05s。

### 完整算法（v2 silencedetect 严格对齐）

```python
import subprocess, re

def get_silences(mp3):
    cmd = ["ffmpeg", "-i", mp3, "-af", "silencedetect=noise=-30dB:d=0.15", "-f", "null", "-"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return [float(line.split("silence_start: ")[1].strip())
            for line in result.stderr.split("\n") if "silence_start" in line]

def fix_srt_v2(entries, silences, audio_dur):
    """v2: 严格用静音点对齐 entry 边界"""
    fixed = []
    for i, e in enumerate(entries):
        new_start = silences[i] + 0.05
        new_end = silences[i+1] - 0.05 if i+1 < len(silences) else audio_dur - 0.05
        # 防御: 不能超过下一条 entry.start (字幕重叠)
        if i + 1 < len(entries):
            next_start = srt_to_sec(entries[i+1]["start"])
            new_end = min(new_end, next_start - 0.05)
        new_end = max(new_end, srt_to_sec(e["start"]) + 0.05)
        fixed.append({**e, "start": sec_to_srt(new_start), "end": sec_to_srt(new_end)})
    return fixed
```

**完整可复用脚本**：`scripts/fix_srt_silencedetect.py`（含 5 段切分 + SCENE_SUBTITLES frame 计算）

### 修复结果（2026-06-05 实测）

| 视频 | 字符比例偏差 | 修复后偏差 | sync check |
|------|-------------|-----------|-----------|
| Alphabet (56.95s) | E1=-2.14s, E7=-3.90s, E11=-3.27s | 26/26 ≤ 0.05s | ✅ PASS |
| Codex (51.66s) | E1=-4.30s, E8=-4.09s | 26/26 ≤ 0.05s | ✅ PASS |

**副作用**：SRT 末 ≠ TTS 末（视频末 10-11s 无字幕，因为 silences 中 4-6 个是视频末静音段）。**Composition 必须把 S5_TO 改到 TTS 末**（参见 `remotion-timecode-anti-pattern` 反模式 G）。

### 为什么不用 Whisper 路径 A

按本 skill 永久记录："**Whisper 路径 A 适用：Whisper segment 数量 ≈ 脚本句子数量（误差 ±30%）**"。Alphabet/Codex 实测 Whisper base 模型转写 = 32 segments vs 13 entry，**差异 2.46 倍远超 30% 阈值**——必须走路径 B（纯比例）或 v2 修复。

### 为什么 v1 修复算法（min(end+0.5, ...））失败

原 `min(srt.end+0.5, silence_start-0.05)` 是"避免推太多"逻辑，**只推 0.5s**。但 Radio_Host 音色长 entry 末尾停顿 2-4s（实测 E1=2.14s, E7=3.90s）——0.5s 推量远不够。**必须用绝对推法**（next_sil - 0.05）。

### Gotchas (含 v2 修复)

10. **silencedetect d=0.3 漏"连续朗读"短停顿**（2026-06-05 v7 案例固化）⚠️：

> **TTS 短 entry 间可能无停顿**（特别是连续的短 entry 如 "AI 行业八月的头条，" + "全被一笔融资和一份招股书抢走了。"）—— TTS 一气呵成读完，silencedetect 只给 1 个句尾静默点（= 2 个 entry 的合并末）。**silences count < entries count → v2 算法报错**。

**6-05 v7 实测数据**（alphabet 10 entries，silencedetect d=0.3）：

| 期望 silences | 实际 silences | 缺失的句尾 |
|--------------|--------------|----------|
| 10 | 9 | E2 末（被合并到 E3 句尾 12.30s） |

**根因**：E1 "AI 行业八月的头条，" (2.91s) → E2 "全被一笔融资和一份招股书抢走了。" (4.54s) → TTS 中间无停顿（标点"，" 短停顿 < 0.3s 未被 d=0.3 检测到）→ silencedetect 报 12.30s = E3 句尾 = E1+E2 合并末。

**修复算法 v3**（entries count > silences count 时）：

```python
def fix_srt_v3(srt_path, mp3_path):
    """v3: 处理 silences < entries 的连续朗读情况"""
    entries = parse_srt(srt_path)
    silences = get_silences(mp3_path)  # d=0.15 更细
    audio_dur = get_audio_dur(mp3_path)

    if len(silences) >= len(entries):
        # 走 v2 算法（正常情况）
        return fix_srt_v2(entries, silences, audio_dur)

    # 连续朗读：silences < entries，按字符等分分配未被静音点覆盖的 entry
    # 1. 先用 v2 把能对齐的 entry 对齐
    fixed = fix_srt_v2(entries, silences, audio_dur)
    # 2. 检查残余偏差：哪个 entry 偏差 > 0.5s
    # 3. 对这些 entry 用字符等分重切 (entry_chars / total_chars) * (next_silence - this_silence)
    #    例如 E1 在 silences[0]=2.91s 和 silences[1]=12.30s 之间，按字符等分：
    #    E1 (9字) = 9/(9+14) * (12.30-2.91) = 0.39 * 9.39 = 3.67s
    #    E1 末 = 2.91 + 3.67 = 6.58s
    ...
```

**临时规避**（如果 silences < entries）：
- **手工指定哪些 entry 是连续朗读的**（看 SRT 标点，"，" 或 "——" 连续出现的 entry）
- **对这些连续朗读的 entry 用字符等分切**（仅这些 entry 字符 / 全部 entry 字符 × (next_silence - this_silence)）
- **对其他 entry 仍用 v2 silencedetect 严格对齐**

**根治**（长期）：用 Whisper word-level timestamp（每个字的起止）—— 但当前 session 无 Whisper 工具。

**重要**：v3 修复后，**残余偏差**仍可能 1-5s（因为字符等分不是真实朗读时间）—— 真正的根治需要 m3 tts 重新生成 mp3 + 完整 Whisper 转写对齐。

11. **vision OCR 抽帧不是验证时序的工具**（2026-06-05 v6 案例）⚠️：
vision 抽帧只能验证"字幕文本是否等于 SRT 原文"，**不能验证"字幕出现时机是否对齐 TTS 朗读"**。
6-05 v6 案例：vision QA 5 帧显示"字幕文本 100% = SRT 原文"，但 sync_check 跑 S2-S5 段 entry 偏差表显示 1-4s 时序偏差——**字幕文本对但时机对不上**。
**时序验证必用 sync_check**（silencedetect + entry 偏差表），不能用 vision OCR。

1. **Whisper 文本不写入 SRT**：automedia 内容有已知正确的 MiniMax 脚本，SRT 文本来源永远是脚本。Whisper 只用于 timing（路径A）或完全不用（路径B）。把 Whisper 文本当 SRT 文本是今日（2026-05-20）整个返工的根本原因。
2. **opencc 繁转简仍需要**：Whisper 不写入 SRT 文本，但 Whisper 可用于检查 TTS 音频内容是否匹配脚本（如 Whisper 听到的内容与脚本相差甚远，说明 TTS 用了错误脚本）。繁转简仍用 opencc 在 Whisper 文本检查阶段。
3. **比例分配是合法路径B**：当 Whisper 超时、或 segment 数与句子数差异大时，比例分配是标准解法，不是"凑合"。关键参数：音频总时长 ffprobe 实测，总字数 = 脚本字数，时间轴 = 比例 × 总时长。
4. **烧录前必须品牌名检查**：无论用路径A还是路径B，SRT 写完后立即扫描"壹目贯维"近音变形（壹目贯维/一目贯维/义务官为/壹目惯为）。发现与脚本不符 → 立即修正该 entry，再烧录。
5. **brand_name_killer timeout 时降级**：若 auto_vision_qa hook 中 brand_name_killer 超时，降级为纯正则扫描（壹目贯维→一目惯为→义务官为），regex 覆盖已知变形即可，不需要 LLM。
7. **burn_subtitles.py SRT 末尾必须有空行**（2026-06-17 实测）：regex `(.+?)\n\n` 要求最后一条 entry 后有 `\n\n`。如果文件末尾无空行，最后一条 entry 不被匹配，静默丢失。**修复**：生成 SRT 后在末尾 append `\n\n`。

9. **drawtext 换行符陷阱**（2026-06-19 三修验收）：在 drawtext 的 text 参数中，不能用 `\n` 转义序列表示换行——ffmpeg filter 解析器不处理 `text='...'` 内的 `\n`，会原样传给 drawtext，显示为字母"n"。**正确做法**：直接传真实换行符（ASCII 10），filter 解析器保留单引号内的真实换行符，drawtext 正确渲染多行。`scripts/burn_subtitles.py` 已内置自动换行逻辑（35 字阈值，句号/问号提前拆行），且保留真实换行符不做转义。：ffmpeg drawtext 将 `%` 视为表达式扩展前缀。SRT 文本含 `%`（如"30-40%"）时报 `Stray % near`，字幕静默消失（exit code=0）。**转义链**：`\\\\%`（文件）→ `\\%`（字符串）→ `\%`（滤镜解析）→ `%`（输出）。`burn_subtitles.py` 已包含此修复。

6. **burn_subtitles.py NoneType Bug**：当帧时间无对应字幕时 `active_text=None`，`'\\n' in active_text` 会抛出 `TypeError`。必须在 `add_subtitle_to_frame()` 中用 `if not active_text: img.save(...); return True` 提前返回，不能省略。
6. **TTS API vol/pitch 必须是 int**（2026-05-26）：`vol` 传 `1.0`（浮点）报错 `"Mismatch type int64"`。正确：`vol: 10`（整数），`pitch: 0`（整数）。

12. **mp3 vs SRT 内容错配是 6-05 终极 root cause**（2026-06-05 v10 实测固化）⚠️⚠️⚠️：

> **session 113223 时代踩坑**：mp3 朗读内容 = "GPT5 工具红利期"（旧版 6-02/6-03 m3 tts 产物），SRT 文本 = "Alphabet 800亿"（session 113223 新写）——**两套完全不同的内容**。user 看到视频字幕显示"Alphabet 拟融资 800 亿美元"但音频在讲"GPT5 还没捂热"——必然"对不上"。

**根治**（Whisper pre-send 强制验证）：

```bash
# 1. mp3 生成后立即 Whisper 转写
whisper <mp3_path> --language zh --model tiny --output_format srt \
    --output_dir /tmp/whisper_verify/

# 2. 与项目 SRT 文本对比（不看时间戳，只看文本）
python3 -c "
srt = open('/path/to/subtitle.srt').read()
whisper = open('/tmp/whisper_verify/<mp3_name>.srt').read()

# 提取所有 SRT 文本（忽略时间戳）
import re
srt_texts = set(re.findall(r'[\u4e00-\u9fff]{2,}', srt))
whisper_texts = set(re.findall(r'[\u4e00-\u9fff]{2,}', whisper))

# 关键词覆盖率（Whisper 转写有 ASR 误识别，需容忍 ±20%）
common = srt_texts & whisper_texts
coverage = len(common) / len(srt_texts) * 100

if coverage < 80:
    missing = list(srt_texts - whisper_texts)[:5]
    raise Exception(
        f'❌ mp3 vs SRT 文本错配：覆盖率 {coverage:.1f}% < 80%\\n'
        f'   缺失关键词: {missing}\\n'
        f'   → mp3 朗读的不是 SRT 文本，必须重新生成 mp3'
    )
print(f'✅ 覆盖率 {coverage:.1f}% ≥ 80%')
"

# 3. 用 Whisper word_timestamps 重切 SRT（见上文"Whisper word_timestamps 校准"节）
```

**反模式**（永久禁止）：
- ❌ **只跑代码层 linter/sync_check 就报"音画同步通过"**——linter/sync_check 只校验时间戳偏差，**完全不查文本是否对得上**。
- ❌ **"我先 m3 tts 一下，文本应该差不多"**——TTS 引擎有随机性 + 旧 mp3 可能被复用，**mp3 ≠ 脚本**是 6-05 实测案例。
- ❌ **Whisper 转写后不 diff SRT 文本**——只跑 Whisper 不 diff = 没用，必须文本比对。

13. **MultiMax CN TTS 调通工作流**（2026-06-05 v10 实测，2026-06-05 之前用户没发现 MINIMAX_CN_API_KEY 可用）：

```python
import os
from dotenv import load_dotenv
load_dotenv('/home/renanzai/.hermes/profiles/content/.env')
# .env 中有 MINIMAX_CN_API_KEY（api.minimaxi.com/v1/t2a_v2 端点）
api_key = os.environ.get('MINIMAX_CN_API_KEY')

import requests
def m3_tts_cn(text, output_path, voice='male-qn-qingse'):
    url = 'https://api.minimaxi.com/v1/t2a_v2'  # CN 端点
    payload = {
        'model': 'speech-02-hd',  # 高清模型
        'text': text,
        'voice_setting': {
            'voice_id': voice,  # 中文男声 = male-qn-qingse
            'speed': 1.0, 'vol': 1.0, 'pitch': 0
        },
        'audio_setting': {
            'sample_rate': 32000, 'bitrate': 128000
        }
    }
    r = requests.post(url, json=payload,
                      headers={'Authorization': f'Bearer {api_key}',
                              'Content-Type': 'application/json'})
    data = r.json()
    # 关键：t2a_v2 返回 hex 编码 audio，需 bytes.fromhex 解码
    if 'data' in data and 'audio' in data['data']:
        audio_bytes = bytes.fromhex(data['data']['audio'])
        with open(output_path, 'wb') as f:
            f.write(audio_bytes)
        return f"OK {output_path} {len(audio_bytes)} bytes"
```

**关键差异 vs 之前的 m3 tts 用法**：
- t2a_v2 端点返回 **JSON 含 hex 编码 audio**（不是直接 mp3 二进制）
- 必须 `bytes.fromhex(data['data']['audio'])` 解码
- API key 名 = `MINIMAX_CN_API_KEY`（不是 `MINIMAX_API_KEY`，tts_tool.py 用 `MINIMAX_API_KEY` 但实际 .env 里只有 CN key）

**edge-tts 4x 语速警告**（再次提醒）：edge provider 比 m3 tts 快 4 倍（56.95s → 13.75s），**不要用 edge-tts 顶替 m3 tts**。

14. **vision QA 抽 5 帧的致命陷阱**（2026-06-05 v6 案例固化）⚠️：

> **5 帧容易全在 S1 段**（S1 段通常偏差小）→ 误判"修复成功"→ 漏检 S2-S5 段 1-4s 偏差。
> 必抽 **≥10 帧**（每段 ≥2 帧 + 视频首尾 5s），用 `audio_video_sync_check.py` 自动按 SRT entry 分布 12-13 帧。



8. **字符比例分配对短 entry 偏差 0.9-1.4s**（2026-06-02 m3 案例永久固化）⚠️：

> 字符比例分配算法假设**每个字等时长**，但 TTS 实际是"重音字 + 停顿字"不均匀的。每个 entry 末尾的"。"、"，"、"——"等标点让 TTS 多读 0.5-1.4s，这部分时间**没有分配给任何 entry**——导致 entry 提前结束。

**实测数据**（m3 视频 SRT #1-#14，对比 TTS 静音点 silence_start）：

| # | SRT end | 真实静音点 | 偏差 |
|---|---------|-----------|------|
| 5 | 23.75s | 25.17s | **-1.42s** |
| 7 | 34.79s | 35.69s | **-0.90s** |
| 10 | 53.54s | 54.97s | **-1.43s** |
| 12 | 62.29s | 63.70s | **-1.41s** |
| 13 | 65.62s | 66.62s | **-1.00s** |

**根因**：标点（特别是"。"和"——"）的 TTS 停顿时间不被字符计入。SRT entry.end 比真实 TTS 句尾早 0.9-1.4s。

**为什么以前没发现**：(a) 比例分配对长 entry（22-39 字）偏差被段内缓冲吸收；(b) 短 entry（12-16 字）的偏差更明显（4-8%），但视觉 QA 抽帧只看 25%/75% 关键帧，不验证时序。

**对 Remotion 的传导效应**（已归档——详见图文记录 `archived/remotion-workflow` 的 TTS 变更耦合规则修正）：如果 Composition 的 `SCENE_SUBTITLES` 数组用 `(chars_i / total_chars) * total_tts_seconds * fps` 重算 duration，会**叠加** SRT 本身的 0.9-1.4s 偏差，导致 4-5s 级别的音画错位。**新铁律（2026-06-02）**：Composition 的 start/end 必须从 SRT 真实时间戳读取（`entry.start * fps` / `entry.end * fps`），不能再次估算。

**根除方案**（长期——Remotion 已归档，此问题不适用于 HyperFrames。HyperFrames 的 SRT 按帧映射，无 Composition 重算偏差）：用 Whisper word-level timestamp 反推 entry 边界（每个 entry.end = 后面最近的 silence_start - 0.05s）。当前缺工具化，统一改 Whisper 路径排期在 B 方案（详见 `remotion-workflow` TTS 变更耦合规则修正节）。

**临时规避**（如果用 Whisper 路径 A 但 segment 数对不上）：在比例分配后，对每条 entry.end 做"向前推"修正——找到 TTS 静音段里该 entry 后面最近的 silence_start，取 `min(srt.end + 0.5s, silence_start - 0.05s)` 作为新 end。验证脚本：`ffmpeg -i tts.wav -af silencedetect=noise=-30dB:d=0.15 -f null -`。


---

## 章节导航（JiT Loading）

> 主文件保留核心流程。以下章节已移至 references/，按需加载：

| 章节 | Reference | 行数 |
|------|-----------|------|
| 操作手册（必须按顺序执行） | `references/operation-manual.md` | 43 |
| 完整工作流（5 步） | `references/whisper-workflow-5-steps.md` | 36 |
| 完整 v11 工作流（5 步） | `references/v11-workflow-5-steps.md` | 21 |
| P0-2 铁律：Whisper word_timestamps 是 SRT 重新对齐的 CANONICAL 方法 | `references/p0-2-word-timestamps-canonical.md` | 18 |
| 4 步捷径（不需要 Whisper 时） | `references/4-step-shortcut.md` | 16 |
| TTS API 调用规范（2026-05-26 新增） | `references/tts-api-call-spec.md` | 14 |
| 品牌名"壹目贯维"Whisper腐蚀警示（2026-05-20新增） | `references/whisper-brand-corrosion.md` | 13 |
| P0-1 铁律：Whisper 是 SRT 验证的 MANDATORY 工具（不仅是质量检查） | `references/p0-1-whisper-mandatory.md` | 12 |
| 普京访华（2026-05-20）- 9处修正 | `references/case-putin-visit-2026-05-20.md` | 12 |
| 官方 burn_subtitles.py 参数说明 | `references/burn-subtitles-params.md` | 11 |
| 效率数据（实测） | `references/efficiency-data.md` | 11 |
| 边界 case：silencedetect 漏连续朗读（2026-06-05 v7 实测） | `references/silencedetect-missed-continuous.md` | 9 |
| v11 反模式（永久禁止） | `references/v11-antipatterns.md` | 8 |
| 关键变更（2026-05-20） | `references/key-changes-2026-05-20.md` | 8 |
| v11 实战数据 | `references/v11-practical-data.md` | 7 |
| 完整 v11 案例参考 | `references/v11-case-reference.md` | 6 |
| P0-3 铁律：SCENE_SUBTITLES 文本必须 100% = SRT 原文（= TTS 朗读文本） | `references/p0-3-scene-subtitles-eq-srt.md` | 4 |
| AI语音合成（2026-05-20）- 15处修正 | `references/case-ai-voice-2026-05-20.md` | 4 |
