---
name: delivery-packaging
description: "AutoMedia 交付打包 — 项目文件夹进 zip，包含完整性强制检查。触发：打包发送给用户之前。 排除：不用于普通文件打包，仅 AutoMedia 项目交付打包时加载。"
category: productivity
version: 1.0.0
author: user
tags: [automedia, delivery, packaging, zip]
trigger: 发给用户之前必须调用此 skill
---

# delivery-packaging

## 执行原则

**只打包最终验收通过版本。过程版本（video_final_v2/v3/v8/v9、audio_v2/v3等）一律不打包。**

**打包前必须先通过三个强制检查。检查不通过不得打包，不发消息告知用户，直接在主 agent 补全缺失内容。**

禁止：
- ❌ 跳过检查直接打包
- ❌ 检查不通过后告知用户"缺了什么"
- ❌ 打包后发现内容不够再补

## 三个强制检查

### 检查A：文件存在性

项目目录必须包含以下文件：

| 文件 | 说明 |
|------|------|
| `03_video/video_final.mp4` | 最终视频（含字幕） |
| `03_video/audio_voiceover.mp3` | TTS 配音 |
| `03_video/subtitle.srt` | 字幕文件 |
| `01_content/script_final.txt` | 口播脚本 |
| `01_content/wechat_draft.html` | 公众号草稿 |
| `01_content/drafts/zhihu/zhihu_article.md` | 知乎文章 |
| `01_content/drafts/xiaohongshu/xiaohongshu_post.md` | 小红书笔记 |
| `01_content/drafts/wechat/images/*.png` | 公众号内文配图（HTML 引用必须全部有对应文件） |

**公众号内文配图强制检查（2026-06-01 新增，user 强制）**：

如果 `wechat_draft.html` 存在 `<img src="images/wechat_img_*.png">` 引用，则 `01_content/drafts/wechat/images/` 下每个引用文件都必须实际存在。

```python
# 自动化检查脚本（嵌入 package_project）
import re, os
wechat_html = f"{project_dir}/01_content/drafts/wechat/wechat_draft.html"
if os.path.exists(wechat_html):
    with open(wechat_html, encoding="utf-8") as f:
        html = f.read()
    img_refs = re.findall(r'<img[^>]*src="(images/[^"]+\.png)"', html)
    img_dir = f"{project_dir}/01_content/drafts/wechat/images"
    missing = [ref for ref in img_refs if not os.path.exists(f"{img_dir}/{os.path.basename(ref)}")]
    if missing:
        raise Exception(f"CHECK_A_FAILED: 公众号 HTML 引用了图片但 files 不存在: {missing}")
```

**禁止行为（2026-06-01 踩坑）**：
- ❌ 报告里写"⚠️ 本轮没做（图片）"然后交付 zip —— **user 当场质疑"图片生成了吗"**（`images/wechat_img_N.png` 是占位符，HTML 引用是 broken image）
- ❌ 跳过图片检查直接打包
- ✅ 图片必须先生成 → Vision QA 全 PASS → 落到 `images/` 目录 → 再打包
- ✅ 如果实在无法生成图片，**坦白告知"未完成"**而不是包装成"已完成 + ⚠️ 备注"

**视频文件路径解析规则**：
- 优先 `03_video/video_final.mp4`
- 如不存在，按以下顺序查找（取第一个存在的）：
  - `03_video/<topic_prefix>_video_final.mp4`（如 `renda_video_final.mp4`、`xiaomi_video_final.mp4`）
  - `03_video/*.mp4`（取最新修改时间）
- 找到后统一重命名为 `video_final.mp4` 写入 zip
- 严禁打包任何带 `_v2` / `_v3` / `_old` / `_bak` 后缀的过程版本视频

### 检查B：内容字数

| 平台 | 最低字数 |
|------|---------|
| 公众号 | 1500字 |
| 知乎 | 1500字 |
| 小红书 | 300字 |
| 口播脚本 | 100字 |

字数不足 → 立即补充，不告知用户。

### 检查C：平台完整性

5个平台：wechat / zhihu / xiaohongshu / tiktok / bilibili，全部必须有内容。

---

## 可执行打包函数

```python
import zipfile, os, shutil, glob, re

def package_project(project_dir, topic_slug, zip_path, video_src=None):
    """
    项目交付打包。三个检查不通过则抛异常，不返回。
    project_dir: 项目根目录（/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/YYYYMMDD_HHMMSS_name/）
    topic_slug: zip内部目录名，如 "china-us-summit"
    zip_path:  输出zip路径，如 "/tmp/china-us-summit.zip"
    video_src: 视频来源路径，默认从 project_dir/03_video/video_final.mp4
                如需指定其他路径（如/tmp/v4合格版），显式传入
    """

    # ── 视频源路径解析 ──────────────────────────────────────
    default_video = f"{project_dir}/03_video/video_final.mp4"
    video_file = video_src if video_src else default_video

    # ── 强制检查A：文件存在性 ────────────────────────────────
    required_files = {
        "video":        video_file,
        "audio":        f"{project_dir}/03_video/audio_voiceover.mp3",
        "subtitle":     f"{project_dir}/03_video/subtitle.srt",
        "script":       f"{project_dir}/01_content/script_final.txt",
        "wechat":       f"{project_dir}/01_content/wechat_draft.html",
        "zhihu":        f"{project_dir}/01_content/drafts/zhihu/zhihu_article.md",
        "xiaohongshu":  f"{project_dir}/01_content/drafts/xiaohongshu/xiaohongshu_post.md",
    }
    missing = []
    for name, path in required_files.items():
        if not os.path.exists(path):
            missing.append(name)

    if missing:
        raise Exception(f"CHECK_A_FAILED: missing files: {missing}")

    # ── 强制检查B：内容字数 ─────────────────────────────────
    zhihu_path = required_files["zhihu"]
    xhs_path   = required_files["xiaohongshu"]
    script_path = required_files["script"]

    def char_count(path):
        with open(path, encoding="utf-8") as f:
            text = f.read()
        # 纯中文字符数
        chars = len(re.findall(r'[\u4e00-\u9fff]', text))
        return chars

    issues_b = []
    if char_count(zhihu_path) < 1500:
        issues_b.append("zhihu")
    if char_count(xhs_path) < 300:
        issues_b.append("xiaohongshu")
    if char_count(script_path) < 100:
        issues_b.append("script")

    if issues_b:
        raise Exception(f"CHECK_B_FAILED: insufficient chars: {issues_b}")

    # ── 强制检查C：平台完整性 ───────────────────────────────
    # tiktok 和 bilibili 用口播脚本兼任（脚本是共用的）
    tiktok_script = f"{project_dir}/01_content/script_final.txt"
    bilibili_script = f"{project_dir}/01_content/script_final.txt"
    # 如果有独立脚本目录则优先检查
    for alt in [
        f"{project_dir}/01_content/drafts/tiktok/script.txt",
        f"{project_dir}/01_content/drafts/bilibili/script.txt",
    ]:
        if os.path.exists(alt):
            pass  # 存在即可

    # ── 构建临时目录结构 ────────────────────────────────────
    tmp_dir = f"/tmp/delivery_{topic_slug}"
    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir)
    os.makedirs(f"{tmp_dir}/{topic_slug}/03_video", exist_ok=True)
    os.makedirs(f"{tmp_dir}/{topic_slug}/01_content/drafts/zhihu", exist_ok=True)
    os.makedirs(f"{tmp_dir}/{topic_slug}/01_content/drafts/xiaohongshu", exist_ok=True)
    os.makedirs(f"{tmp_dir}/{topic_slug}/02_images", exist_ok=True)

    # 视频（必须是 QA 通过的合格版）
    shutil.copy2(video_file, f"{tmp_dir}/{topic_slug}/03_video/video_final.mp4")

    # 音频+字幕
    for f in ["audio_voiceover.mp3", "subtitle.srt"]:
        src = f"{project_dir}/03_video/{f}"
        if os.path.exists(src):
            shutil.copy2(src, f"{tmp_dir}/{topic_slug}/03_video/{f}")

    # 内容文件
    for fname, arcname in [
        ("script_final.txt",      f"{topic_slug}/01_content/script_final.txt"),
        ("wechat_draft.html",     f"{topic_slug}/01_content/wechat_draft.html"),
        ("zhihu_article.md",      f"{topic_slug}/01_content/drafts/zhihu/zhihu_article.md"),
        ("xiaohongshu_post.md",   f"{topic_slug}/01_content/drafts/xiaohongshu/xiaohongshu_post.md"),
    ]:
        # 向上回溯找正确的源文件
        src = None
        if fname == "zhihu_article.md":
            src = zhihu_path
        elif fname == "xiaohongshu_post.md":
            src = xhs_path
        else:
            # script_final.txt / wechat_draft.html 可能在根目录或 01_content/
            for candidate in [
                f"{project_dir}/{fname}",
                f"{project_dir}/01_content/{fname}",
            ]:
                if os.path.exists(candidate):
                    src = candidate
                    break
        if src:
            dest = f"{tmp_dir}/{arcname}"
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)

    # 封面图（递归扫描 02_images/）
    img_extensions = {".png", ".jpg", ".jpeg", ".webp"}
    for root, dirs, files in os.walk(f"{project_dir}/02_images"):
        for fn in files:
            if os.path.splitext(fn.lower())[1] in img_extensions:
                src = os.path.join(root, fn)
                shutil.copy2(src, f"{tmp_dir}/{topic_slug}/02_images/{fn}")

    # ── 打包（排除过程版本）────────────────────────────────
    def should_skip(fname):
        """排除过程版本文件，避免交付脏版本"""
        skip_patterns = [
            '_v2', '_v3', '_v4', '_v5', '_v6', '_v7', '_v8', '_v9',
            '_old', '_bak', '_tmp', '.tmp',
            '审核', 'review', 'log', 'wip',
            'video_clean',  # 中间处理文件
        ]
        return any(p in fname for p in skip_patterns)

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(f"{tmp_dir}/{topic_slug}"):
            # 跳过审核/发布目录本身（内容已在上面按需复制）
            dirs[:] = [d for d in dirs if d not in {'04_review', '05_publish', 'logs'}]
            for file in files:
                if should_skip(file):
                    continue
                full = os.path.join(root, file)
                arcname = os.path.relpath(full, f"{tmp_dir}/{topic_slug}")
                zf.write(full, arcname)

    shutil.rmtree(tmp_dir)

    # ── 验证zip内容 ────────────────────────────────────────
    with zipfile.ZipFile(zip_path, 'r') as z:
        names = sorted(z.namelist())
    print(f"[delivery-packaging] {zip_path}")
    print(f"  files: {len(names)}")
    for n in names:
        print(f"  {n}")

    return zip_path
```

## 调用方式

```python
from hermes_tools import write_file, execute_code

# 主 agent 调用
execute_code(code=f"""
import sys
sys.path.insert(0, '/home/renanzai/.hermes/skills/productivity/delivery-packaging')
from delivery_packaging import package_project

package_project(
    project_dir="/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/20260516_100010_china-us-summit",
    topic_slug="china-us-summit",
    zip_path="/tmp/china-us-summit.zip",
    video_src="/tmp/video1_final_v4.mp4"  # 显式传入QA合格版
)
""")
```

## 错误处理

### 检查D：视频时长质检（生产交付模式B）

视频时长必须在 **35–65 秒**范围内。低于 35 秒的视频直接判定为不合格，需要重新生成。

典型不合规时长：
- `< 30s`：音频被截断，或 concat 阶段 seek 过度
- 20260514_xiaomi-car 项目：25 秒，必须重做

**处理方式**：视频时长不合规 → 立即报告主 agent，主 agent 排查 SRT/音频时长问题，重新烧录。

**禁止行为**：看到异常后告知用户"请补充"。视频时长 < 35s → 主agent排查SRT/音频，重新烧录，不告知用户。

## 两种执行模式

### 模式A：历史归档打包
用户要求打包已完成的历史项目时触发。

**核心原则：历史项目也必须内容完整。** 如果项目缺少文案内容，必须立即生成，不告知用户。只有纯视频素材项目（如"引流款"类早期项目）无法补全内容时，才可以打包现有素材，同时向用户说明哪些内容缺失。

- 先检查项目结构，列出缺失内容
- 发现非标准结构（如子目录嵌套、旧格式）→ **立即整理**，不等待用户确认
- 打包时在 zip 内生成标准目录结构
- 内容缺失 → 立即生成（参考字幕文件/脚本/视频素材），不告知用户

### 模式B：生产交付打包
当前正在进行的项目交付时触发。
- 三个检查必须全部通过
- 缺失内容由 agent 自行补全，不告知用户

**判断依据**：用户说"打包发我"或"发给我看看" → 模式A或B。用户明确说"历史项目打包"或"归档" → 模式A。

---

## 使用场景

- 用户说"发给我看看" → 先调用 delivery-packaging → 模式A/B 由 agent 自行判断
- 用户明确说"历史项目打包"或"归档" → 模式A，先提问确认结构异常
- 用户说"打包" → 同上
- 任何交付动作之前必须先经过此 skill

## 双话题项目拆分规范

双话题项目（如 `20260514_1000_dual-topics`）必须拆分为独立项目，拆分时：

1. **识别**：视频文件夹内有多个前缀（`renda_*`、`xiaomi_*`）→ 双话题项目
2. **拆分前检查每个子话题的文案完整性**：
   - `01_content/drafts/wechat/`（公众号）
   - `01_content/drafts/zhihu/`（知乎）
   - `01_content/drafts/xiaohongshu/`（小红书）
   - `01_content/script_final.txt`（口播脚本）
3. **缺失则立即生成**：基于字幕/SRT/视频内容生成对应文案，不告知用户，不等待用户确认
4. **拆分后打包**：每个子话题独立项目、独立 zip

**典型错误（本次教训）**：只拆视频素材、不查文案 → 用户打开 zip 发现只有视频 → "必须都补上"

---

## 打包前结构审查清单（历史项目模式A）

收到历史项目打包请求时，依次检查：

```
1. 是否有 00_project_info/project_info.json
      └→ 无 → 记录为"结构不标准"，先提问

2. 是否为标准目录结构（00_project_info/01_content/02_images/03_video/04_review/05_publish）
      └→ 否（如 20260513 那种嵌套子目录）→ 记录异常，先提问

3. 是否有重复/废弃版本
      └→ 是（如 video_final_v8.mp4、img_1_old.png）→ 记录，由用户决定是否剔除

4. content 文件路径是否标准
      └→ 公众号草稿在 drafts/wechat/ vs 01_content/根目录 → 打包时自动归位

5. 是否为双话题项目
      └→ 是（视频文件夹内有多个前缀）→ 立即拆分 + 检查文案完整性 + 缺失则生成
```

**先提问的典型情况**（模式A）：
- 项目缺少 project_info.json（需要补充项目信息才能正确命名）
- 项目有多种相似内容不知选哪个（如 wechat.md 和 wechat_draft.html 并存）
- 用户提到"按规定格式"但项目结构与标准差异较大

**直接执行的**：
- 项目结构标准，只有封面图等零散文件需要归位（自动归位，不问）
- 视频文件有多个版本，自动选最新合格版本（video_final.mp4 或 vN 最高版）
- **双话题拆分 + 文案补全**（直接执行，不问）

