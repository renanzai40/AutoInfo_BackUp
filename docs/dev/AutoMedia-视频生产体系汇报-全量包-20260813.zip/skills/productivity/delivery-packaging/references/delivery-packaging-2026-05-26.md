# 项目归档标准流程（2026-05-26 固化）

> 每次内容生产完成（视频+文案+审查通过）后，必须执行本流程归档。
> 归档 = 将散落的中间文件整理为标准项目结构 + 打包交付。

---

## 归档触发时机

- 用户说"归档吧"时
- 视频 + 全平台文案全部完成审查后
- 交付 zip 打包前

---

## 标准项目结构（归档后必须存在）

```
YYYYMMDD_HHMMSS_topic-slug/
├── 00_project_info/project_info.json    ← 项目元数据
├── 01_content/
│   ├── drafts/                           ← 原始草稿（不删除）
│   └── approved/                         ← ★ 本次新建/更新
│       ├── tiktok/tiktok_script.md
│       ├── bilibili/bilibili_script.md
│       ├── wechat/wechat_article.html
│       ├── zhihu/zhihu_article.md
│       └── xiaohongshu/xiaohongshu_post.md
├── 02_images/cover/ + assets/
├── 03_video/                             ← video_final.mp4 + subtitle.srt + audio
├── 04_review/                            ← 全5平台 copy_review 文件
└── 05_publish/publish_log.json
```

---

## 六步归档流程

1. **建 approved/ 目录**：`mkdir -p 01_content/approved/{tiktok,bilibili,wechat,zhihu,xiaohongshu}`
2. **复制审核通过定稿**：抖音/B站=script_final.txt，公众号=wechat_draft_fixed.html（最新），知乎/小红书=对应md
3. **移动散落视频到 03_video/**：上级目录 *.mp4/*.md → 移入项目
4. **检查 04_review/ 五平台全覆盖**：任一缺失不得归档
5. **确认 05_publish/publish_log.json**：含微信草稿ID
6. **打包 zip**：用 zipfile.ZIP_DEFLATED

---

## 散落文件处理

| 散落位置 | 处理 |
|---------|------|
| `/projects/*.mp4`（上级目录） | 移动到 `03_video/` |
| `wechat_draft_fixed.html` | 复制到 `approved/wechat/wechat_article.html` |
| `_c.txt` / `_raw.mp4` / `_b.txt` | 疑似临时，保留不删 |

---

## 已归档项目（2026-05-26）

- wentech-ansys-litigation → `20260525_wentech-ansys-litigation.zip`（10.3 MB）
- 618-ai-tools-recommendation → `20260525_618-ai-tools-recommendation.zip`（8.5 MB）