"""
delivery-packaging - AutoMedia 交付打包模块
三个强制检查：文件存在 / 字数 / 平台完整
检查不通过则抛异常，不返回。
"""
import zipfile, os, shutil, glob, re

def package_project(project_dir, topic_slug, zip_path, video_src=None):
    default_video = f"{project_dir}/03_video/video_final.mp4"
    video_file = video_src if video_src else default_video

    # ── 检查A：文件存在性 ────────────────────────────────────────
    required_files = {
        "video":        video_file,
        "audio":        f"{project_dir}/03_video/audio_voiceover.mp3",
        "subtitle":     f"{project_dir}/03_video/subtitle.srt",
        "script":       _find_file(project_dir, "script_final.txt"),
        "wechat":       _find_file(project_dir, "wechat_draft.html"),
        "zhihu":        f"{project_dir}/01_content/drafts/zhihu/zhihu_article.md",
        "xiaohongshu":  f"{project_dir}/01_content/drafts/xiaohongshu/xiaohongshu_post.md",
    }
    missing = [name for name, path in required_files.items() if not os.path.exists(path)]
    if missing:
        raise Exception(f"CHECK_A_FAILED: {missing}")

    # ── 检查B：内容字数 ─────────────────────────────────────────
    def char_count(path):
        with open(path, encoding="utf-8") as f:
            text = f.read()
        return len(re.findall(r'[\u4e00-\u9fff]', text))

    issues_b = []
    zh = required_files["zhihu"]
    xs = required_files["xiaohongshu"]
    sc = required_files["script"]
    if char_count(zh) < 1500:  issues_b.append(f"zhihu({char_count(zh)}chars)")
    if char_count(xs) < 300:   issues_b.append(f"xiaohongshu({char_count(xs)}chars)")
    if char_count(sc) < 100:   issues_b.append(f"script({char_count(sc)}chars)")

    if issues_b:
        raise Exception(f"CHECK_B_FAILED: {issues_b}")

    # ── 构建临时目录 ─────────────────────────────────────────────
    tmp_dir = f"/tmp/delivery_{topic_slug}"
    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir)
    os.makedirs(f"{tmp_dir}/{topic_slug}/03_video", exist_ok=True)
    os.makedirs(f"{tmp_dir}/{topic_slug}/01_content/drafts/zhihu", exist_ok=True)
    os.makedirs(f"{tmp_dir}/{topic_slug}/01_content/drafts/xiaohongshu", exist_ok=True)
    os.makedirs(f"{tmp_dir}/{topic_slug}/02_images", exist_ok=True)

    # 视频
    shutil.copy2(video_file, f"{tmp_dir}/{topic_slug}/03_video/video_final.mp4")

    # 音频+字幕
    for f in ["audio_voiceover.mp3", "subtitle.srt"]:
        src = f"{project_dir}/03_video/{f}"
        if os.path.exists(src):
            shutil.copy2(src, f"{tmp_dir}/{topic_slug}/03_video/{f}")

    # 脚本
    shutil.copy2(sc, f"{tmp_dir}/{topic_slug}/01_content/script_final.txt")

    # 公众号
    wc = required_files["wechat"]
    shutil.copy2(wc, f"{tmp_dir}/{topic_slug}/01_content/wechat_draft.html")

    # 知乎
    shutil.copy2(zh, f"{tmp_dir}/{topic_slug}/01_content/drafts/zhihu/zhihu_article.md")

    # 小红书
    shutil.copy2(xs, f"{tmp_dir}/{topic_slug}/01_content/drafts/xiaohongshu/xiaohongshu_post.md")

    # 封面图
    img_exts = {".png", ".jpg", ".jpeg", ".webp"}
    img_src_dir = f"{project_dir}/02_images"
    if not os.path.isdir(img_src_dir):
        img_src_dir = f"{project_dir}/02_images/assets"
    for root, dirs, files in os.walk(img_src_dir):
        for fn in files:
            if os.path.splitext(fn.lower())[1] in img_exts:
                src = os.path.join(root, fn)
                shutil.copy2(src, f"{tmp_dir}/{topic_slug}/02_images/{fn}")

    # ── 打包 ────────────────────────────────────────────────────
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(f"{tmp_dir}/{topic_slug}"):
            for file in files:
                full = os.path.join(root, file)
                arcname = os.path.relpath(full, f"{tmp_dir}/{topic_slug}")
                zf.write(full, arcname)

    shutil.rmtree(tmp_dir)

    # ── 验证报告 ────────────────────────────────────────────────
    with zipfile.ZipFile(zip_path, 'r') as z:
        names = sorted(z.namelist())
    print(f"[delivery-packaging] {zip_path}")
    print(f"  CHECKS PASSED — {len(names)} files:")
    for n in names:
        print(f"  {n}")
    return zip_path


def _find_file(project_dir, filename):
    """从项目根目录向上查找文件，常见于根目录或 01_content/"""
    for cand in [
        f"{project_dir}/{filename}",
        f"{project_dir}/01_content/{filename}",
    ]:
        if os.path.exists(cand):
            return cand
    return f"{project_dir}/{filename}"
