---
name: automedia-research
description: "壹目贯维选题后-脚本前标准化调研环节。从 source_url 提取原文、结构化记录关键数据/引用/实体、建立可溯源 source 档案，确保脚本所有事实主张有据可查。 触发：选题确认后、写脚本前必加载；不用于不需要事实核查的纯观点内容。"
category: productivity
version: 1.0.0
author: Hermes Agent
trigger: Topic selected by user, before any script writing
---

# AutoMedia Research — 标准化调研工作流

## Trigger

**当用户选定 topic 后、开始写脚本之前**，必须执行本流程。禁止跳过调研直接写脚本。

## Purpose

从选题标题 → 找到原始出处 → 阅读原文 → 提取硬数据 → 留存 source 档案，使得后续脚本写作中每个事实主张都能溯源验证。

## 标准目录结构

在项目的根目录下创建 `00_research/` 目录，包含三个文件：

```
00_research/
├── source_article.md    # 原始文章全文（从 URL 提取）
├── research_notes.md    # 结构化调研笔记
└── sources.json         # 机器可读的源记录档案（用于事后核查）
```

---

## Step-by-Step Workflow

### Step 1: 获取 topic 的 source_url

从项目的 SQLite 数据库 `pool.db` 中查询选中 topic 的原始来源 URL：

```bash
# topic_id 由用户在选题阶段提供
sqlite3 pool.db "SELECT source_url FROM topics WHERE topic_id='$TOPIC_ID';"
```

- 如果 `source_url` 非空 → 进入 Step 2
- 如果 `source_url` 为空/NULL → 跳转到 Step 5a（无 URL 补救方案）

### Step 2: 提取原文内容

使用 `web_extract` 工具提取 URL 的正文内容：

```bash
# 使用 Hermes web_extract 工具（或等价方式）
web_extract "$SOURCE_URL" > 00_research/source_article.md
```

如果 `web_extract` 不可用，也可以用 `curl` + `pandoc` 或 `lynx -dump` 降级方案：

```bash
curl -sL "$SOURCE_URL" | lynx -stdin -dump -nolist > 00_research/source_article.md
```

### Step 3: 阅读原文 → 提取关键信息

逐段阅读 `source_article.md`，提取以下四类信息：

| 类别 | 提取内容 | 示例 |
|------|----------|------|
| **Key Numbers** | 百分比、金额、时间、规模等量化数据 | "87% 的任务时间缩短" |
| **Key Quotes** | 直接引语、专家观点、报告原文 | "某某教授指出…" |
| **Named Entities** | 公司名、产品名、人名、机构名、地名 | Perplexity, Harvard, AI Agent |
| **Dates/Statistics** | 发布日期、统计时间窗口、研究周期 | 2025年Q3调研 |

**禁止**：不得编造不存在的数据。如原文模糊（"很多人"、"大幅提升"），在 research_notes 中标注 `[原文表述模糊，未提供具体数字]`。

### Step 4: 补充搜索

针对 topic 核心概念，使用 `web_search`（或 Tavily）搜索 1-2 篇补充材料：

- **背景资料**：帮助理解 topic 上下文
- **相关数据**：验证或补充原文的数字
- **官方文档/白皮书**：增加权威引用

```bash
# 搜索补充材料
web_search "topic 关键词 数据 报告 2025"
web_search "topic 关键词 白皮书"
```

### Step 5a: 无 source_url 的补救方案

当 `source_url` 为空时：

1. **搜索 2-3 个权威来源**：
   ```bash
   web_search "$TOPIC_TITLE 报告 数据"
   web_search "$TOPIC_TITLE 官网 白皮书"
   web_search "$TOPIC_TITLE 行业分析 2025"
   ```

2. **阅读搜索结果**，选择最相关的 2-3 篇作为主要来源
3. **提取原文**（同 Step 2）写入 `source_article.md`
4. 将第一条来源标记为 `primary_source`，其余为 `supplementary`

### Step 5b: 写入 research_notes.md

```markdown
# Research Notes

## Topic

**选题标题**：{TOPIC_TITLE}
**原始出处**：{SOURCE_URL}
**调研日期**：{YYYY-MM-DD}

## Key Numbers

| Number | Context | Source |
|--------|---------|--------|
| 87% | Task time reduction with AI agent | Perplexity/Harvard study |
| 3.2x | Revenue lift for early adopters | McKinsey 2025 report |
| ... | ... | ... |

## Key Quotes

| Quote | Speaker/Context | Source |
|-------|----------------|--------|
| "AI agents will fundamentally reshape knowledge work" | Satya Nadella, Microsoft Build 2025 | primary |
| ... | ... | ... |

## Named Entities

- **Perplexity**: AI search engine, cited in the study
- **Harvard Business Review**: Published the original study
- **AI Agent**: Core technology under discussion
- ...

## Supplementary Materials

- [AI Agent Market Report 2025](https://example.com/report): Provides market size and growth projections
- [Official Documentation](https://example.com/docs): Technical specs for implementation details

## Key Dates

- **研究发布**：2025-04
- **数据采集周期**：2024 Q3 - 2025 Q1
- **调研日期**：{YYYY-MM-DD}
```

### Step 6: 写入 sources.json

```json
{
  "topic_id": "{TOPIC_ID}",
  "topic_title": "{TOPIC_TITLE}",
  "primary_source": {
    "url": "{SOURCE_URL}",
    "title": "{原文标题或搜索标题}",
    "accessed_at": "{YYYY-MM-DDTHH:MM:SS+08:00}",
    "domain": "{域名，如 perplexity.com}"
  },
  "supplementary": [
    {
      "url": "https://example.com/report",
      "title": "AI Agent Market Report 2025",
      "what_it_adds": "Provides market size ($X B) and CAGR projections"
    }
  ],
  "extracted_data": {
    "numbers": [
      {
        "value": "87%",
        "context": "Task time reduction with AI agent vs manual process",
        "source_ref": "primary"
      },
      {
        "value": "3.2x",
        "context": "Revenue lift for early adopters within 12 months",
        "source_ref": "primary"
      }
    ],
    "quotes": [
      {
        "text": "AI agents will fundamentally reshape knowledge work",
        "speaker": "Satya Nadella",
        "context": "Microsoft Build 2025 keynote",
        "source": "primary"
      }
    ],
    "entities": [
      {
        "name": "Perplexity",
        "type": "company",
        "context": "AI search engine cited in the study"
      },
      {
        "name": "Harvard Business Review",
        "type": "organization",
        "context": "Published the original study"
      },
      {
        "name": "AI Agent",
        "type": "technology",
        "context": "Core technology under discussion"
      }
    ],
    "dates": [
      {
        "date": "2025-04",
        "context": "Research publication date"
      }
    ]
  },
  "metadata": {
    "created_at": "{YYYY-MM-DDTHH:MM:SS+08:00}",
    "research_method": "url_extract + web_search",
    "fact_check_required": false
  }
}
```

*注：`fact_check_required` 在以下情况设为 `true`：原文来自非权威来源（自媒体/博客）、数据看起来异常或与其他来源矛盾、原文发布时间超过 2 年。*

---

## 集成：调研 → 脚本

调研完成后，脚本写作阶段必须遵守以下原则：

### 事实引用规则

1. **所有事实主张必须来自 `research_notes.md`** — 禁止凭空编造数据
2. **脚注/来源标注**：在脚本中每个数字/引用旁标注来源引用（使用 `{source: primary}` 或 `{source: supp-1}`）
3. **模糊处理原则**：如果原文数据缺失或模糊，在脚本中也要使用模糊表述（"据统计" → 改为 "据某机构调研"），并在 `sources.json` 的 `extracted_data` 中留空

### 验收 Gate

脚本写完后的 QA 检查：

- [ ] 脚本中每个数字都可以从 `research_notes.md` 中找到
- [ ] `research_notes.md` 中每个数字都可以从 `sources.json` 溯源
- [ ] `sources.json` 中每个 source 都是真实可访问的 URL
- [ ] 无数据编造：如发现任何无法溯源的数据，标记为 `fact_check_required: true`

---

## Pitfalls

| 问题 | 后果 | 预防 |
|------|------|------|
| 跳过调研直接写脚本 | 事实错误、数据编造 | 使用 Gate 强制检查 00_research/ 目录存在 |
| web_extract 提取失败（JS 渲染页面） | source_article.md 为空 | 用 `web_search` 找同一篇的纯文本版本 |
| 原文是付费墙内容 | 无法提取全文 | 搜索摘要/媒体报道作为替代来源 |
| source_url 是视频/PDF | 无法直接提取 | 视频用 transcript 替代，PDF 用 pdfplumber 提取 |
| 用户提供的 topic 太泛（如"AI 趋势"） | 无单一 source_url | 搜索 3+ 来源构建综合性 research_notes |
| 数据在原文中表述模糊 | 脚本中也必须模糊，不可编造 | 在 notes 中标注 `[原文模糊]` |
| 委托 subagent 输出含 research_notes 没有的数据 | 编造数据渗入最终内容，人眼难发现 | 每条数字必须跨平台核对 research_notes.md |

## Quick Reference (Shell)

```bash
# 完整执行流程
TOPIC_ID="t-001"
PROJ_DIR="./projects/$TOPIC_ID"
mkdir -p "$PROJ_DIR/00_research"

# Step 1: 获取 source_url
SOURCE_URL=$(sqlite3 pool.db "SELECT source_url FROM topics WHERE topic_id='$TOPIC_ID';")

if [ -n "$SOURCE_URL" ]; then
  # Step 2: 提取
  web_extract "$SOURCE_URL" > "$PROJ_DIR/00_research/source_article.md"
else
  # Step 5a: 搜索补救
  web_search "$TOPIC_TITLE 报告" > "$PROJ_DIR/00_research/search_results.md"
fi

# Step 3-6: 手动执行（LLM 驱动），写入 research_notes.md + sources.json
```

---

## 文件变更记录

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0.0 | 2026-06-15 | 初版创建 |
