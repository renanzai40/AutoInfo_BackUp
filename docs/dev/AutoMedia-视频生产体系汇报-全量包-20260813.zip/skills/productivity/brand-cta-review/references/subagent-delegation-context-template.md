# Subagent Delegation Context Template — 品牌约束上下文

> **用途**：通过 `delegate_task` 委托子 agent 写多平台文案时，在 `context` 字段中直接复制本模板。子 agent 没有品牌记忆，所有约束必须显式写出。

## 标准上下文块（复制到 delegate_task.context）

```
品牌身份：壹目贯维=AI内容生产公司（热点追踪、文案生成、多平台发布），不是投资/分析/咨询机构。
禁止写成：投资情报、金融研究、政策信号追踪、市场洞察、科技资本分析、产业前沿研究。

品牌名「壹目贯维」首次出现必须在正文50%-70%位置，全文≤3次。
前50%禁止出现品牌名，后30%也不推荐（可能超70%上限）。
建议在「数据解读→B2B映射」过渡段自然引出品牌。

禁止词（任何平台均不可出现）：扫码、扣1、私信领资料、免费、投资情报、金融研究、市场洞察(作为定位词)。
零承诺原则：禁止任何无法兑现的承诺，如「评论区扣1到时统一发」「前50名免费」「免费送资料」。

主题角度：{填入本次话题的核心角度}
```

## Detection（delegate_task 返回后立即执行）

```bash
# 1. 品牌位置检测（每平台）
python3 -c "
import os
for f in ['wechat_draft.html','zhihu_article.md','xiaohongshu_post.md','script.txt']:
    fp = f'01_content/drafts/{f}' if f not in {'wechat_draft.html'} else f'01_content/drafts/wechat/{f}'
    if not os.path.exists(fp): fp = f'01_content/drafts/tiktok/{f}'
    if not os.path.exists(fp): continue
    content = open(fp).read()
    idx = content.find('壹目贯维')
    if idx > 0:
        pct = round(idx / len(content) * 100, 1)
        ok = '✅' if 50 <= pct <= 70 else '⚠️'
        print(f'{f}: brand@{pct}% {ok}')
    elif idx == 0: print(f'⚠️ {f}: brand@0%')
    else: print(f'❌ {f}: NO BRAND')
"

# 2. 品牌名计数
grep -c '壹目贯维' 01_content/drafts/tiktok/script.txt 01_content/drafts/bilibili/script.txt 01_content/drafts/wechat/wechat_draft.html 01_content/drafts/zhihu/zhihu_article.md 01_content/drafts/xiaohongshu/xiaohongshu_post.md 2>/dev/null

# 3. 禁止词扫描
grep -rn '扫码\|扣1\|私信\|领资料\|免费\|投资情报\|金融研究\|市场洞察' 01_content/drafts/ 2>/dev/null || echo 'No banned words found'
```

## 品牌位置修复模式（brand@>70% 时）

如果检测发现品牌首次出现 >70%，用以下模式修复：

1. **Add earlier** — 在正文 50-60% 区间加一句品牌早期提及，如：
   > "壹目贯维在追踪{AI话题}时注意到..."
   > "这也是壹目贯维作为AI内容生产公司持续关注的方向"

2. **Remove from later** — 将原文末品牌出现改为"我们"或直接删去（保持总数 ≤3 次）

3. **Verify again** — 重新跑 Detection 脚本确认修复后 brand@50-70%

**不要**在正文前 50% 加品牌（违反前50%禁止规则）。
