# Layer 3 语义审核执行模式（2026-07-23 实测）

> 覆盖：LLM-driven cron 中 DB 操作的技术限制、mid-run 话题检测、内容验证流程。
> 与 `audit-08x05-late-collection-2026-07-16.md` 互补：后者是「采集跑晚→首次 pending=0」，本文是「采集正常完成→处理期间有新话题入库」。

## 1. `execute_code` 在 cron 模式下不可用

**背景**：LLM-driven cron job 的 agent 无法使用 `execute_code` 工具（cron 模式下被拦截）。此限制意味着你不能写 `execute_code(code=...)` 来执行 SQL/Python 操作。

**替代模式（本文档所示例）**：

```python
# ❌ 不可用（cron 模式拦截）
execute_code(code="import sqlite3; conn = sqlite3.connect(...)")

# ✅ 可用（两步走）
# Step 1: write_file 写脚本到 /tmp/
write_file(path='/tmp/xxx.py', content='...')
# Step 2: terminal 执行
terminal(command='python3 /tmp/xxx.py')
```

**注意事项**：
- 脚本路径用 `/tmp/`（cron agent 有写权限）
- 脚本内容里用绝对路径写 pool.db（`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db`）
- 跑完后用 `terminal(command='python3 -c "...")` 验证 DB 变更

## 2. Mid-run 话题检测

**背景**（2026-07-23 实测）：Layer 3 审核 Job 在 00:20 触发，初始 SQL 查到 2 条 pending 话题。处理完成后进行 verify 查询，发现 pending 数仍是 1 —— 第 3 条话题已被写入（created_at=08:18）。这说明采集脚本在 Layer 3 审核运行期间仍在向 pool 写入数据。

**模式**：

```
初始查询 (pending=2)
    ↓ 审核 + DB update (approved=1, rejected=1)
    ↓ verify 查询 (pending=1 ← 新增了！)
    ↓ 处理新 topic
    ↓ 最终 verify (pending=0)
```

**规则**：Layer 3 审核完成后必须重新 `SELECT COUNT(*) WHERE review_status='pending' AND status='pending'`。如果数 > 0，说明审核过程中有新话题写入，应继续处理。

**不是「晚采集」变体**：
- 晚采集：08:05 跑时采集还没完 → pending=0 → 等采集完再查 → 有数据
- Mid-run 写入：采集正常完，但后续批次的写入发生在审核期间 → 初始 pending>0 但处理过程中又增加了

## 3. DB 更新后的验证链

每次 `UPDATE topics` 后应立刻验证：

```sql
-- 验证 topic 状态已更新
SELECT topic_id, title, review_status FROM topics WHERE topic_id IN (?, ?);

-- 验证剩余 pending 数
SELECT COUNT(*) FROM topics WHERE review_status='pending' AND status='pending';

-- 验证 blocked_domains 新增
SELECT * FROM blocked_domains WHERE domain='xxx';
```

**2026-07-23 实测收益**：验证链在 rejected=1, approved=1 后发现 `pending=1` → 捕捉到第 3 条 mid-run 话题。

## 4. 内容质量验证流程

Layer 3 审核不能仅靠标题判断，必须验证来源内容：

| 步骤 | 工具 | 做什么 |
|------|------|--------|
| 1. `web_extract(url)` | web_extract | 获取文章正文（看是否是 content farm / SEO / 原创） |
| 2. `read_file`（如果 truncate） | read_file | 读取被 truncate 的正文后半段（看文章结构） |
| 3. `web_search(query)` | web_search | 验证事件时间线（旧闻检测） |
| 4. 查 `blocked_domains` | 直接 SQL | 看同域名是否有 blocked 历史 |

**审核检查清单**：
- [ ] 标题是否是 SEO 内容农场模式（"8大技巧"/"99%的人都不知道"/列表式标题）？
- [ ] 作者是否为自媒体聚合账号而非记者/编辑？
- [ ] 正文是否有独创观点/数据，还是纯粹的产品功能介绍/教程？
- [ ] 来源域名是否已被 blocked_domains 收录？
- [ ] 事件是否已过时（`event_date` >7天 or `COALESCE(event_date,created_at)` >7天）？
- [ ] 标题中的「将发布」「即将」与实际时间线是否一致？（可 `web_search` 验证）

## 5. 新垃圾域名的 blocking 决策

**判定标准**（2026-07-23 案例 `k.sina.com.cn`）：
- 新浪看点（k.sina.com.cn）是自媒体聚合平台，类似 `zhuanlan.zhihu.com` / `tech.ifeng.com` / `app.myzaker.com` 已被封禁
- 文章作者「每日热点速览」为聚合类自媒体账号，无记者署名
- 文章为列表式 SEO 内容（"8大妙用"），无新闻价值
- 域名级别 blocking，不针对单篇文章

**反向检查**：新域名的 content farm 判定是否与已有 blocked 域名模式一致？如果不一致，只 reject 单篇不封域名。
