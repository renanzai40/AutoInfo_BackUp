# 📋 陷阱 31（2026-06-30 新增）：`status='selected'` 不意味着「已选题未生产」——必交叉验证 PROJECT_REGISTRY

### 📋 陷阱 31（2026-06-30 新增）：`status='selected'` 不意味着「已选题未生产」——必交叉验证 PROJECT_REGISTRY

> **本陷阱的 victim：agent 自己**（2026-06-30 实测）。根因已在陷阱 25 记录，但 agent 行为端缺少约束。

**症状**：
- agent 查 pool.db 看到 `status='selected'`
- 直接默认解读为「已选题、未生产」
- 告诉用户「这个 topic 还没做」
- 用户反驳「昨天刚做完的」

**2026-06-30 真实案例**：
```
Topic: DeepSeek 开源 DSpark 投机解码框架，加速 DeepSeek-V4 生成速度 60-80%
pool.db status=selected
Agent 结论: "status=selected 表示已选题未生产"
实际: 昨天全链路走完（视频+5平台文案+审核+发布）
根因: 项目交付后 pool.db status 未同步（陷阱 25 经典模式）
```

**根因**：
- 陷阱 25 已记录「生产链路没有任何代码回写 pool.db 的 status」
- 但陷阱 25 是**系统设计层**的 bug（代码不写）
- 陷阱 31 是**agent 行为层**的 bug（不查）
- **两者叠加**：系统不写 + agent 不查 = 用户被错误告知「未生产」

**强制规则（查 pool.db 时执行）**：

```python
# ❌ 禁止：仅凭 status=selected 就默认「未生产」
status = cur.execute("SELECT status FROM topics WHERE topic_id=?", (tid,)).fetchone()
if status == 'selected':
    print("⚠️ status=selected 不意味着未生产！必交叉验证 PROJECT_REGISTRY")

# ✅ 正确：查 PROJECT_REGISTRY.json 的 active 项目
import json
reg = json.load(open('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/PROJECT_REGISTRY.json'))
for p in reg.get('active', []):
    info = p.get('info', {})
    if info.get('topic_id') == tid or info.get('topic', '') == pool_title:
        print(f"→ 项目已在 PROJECT_REGISTRY active 中: {p['id']}")
        print(f"→ status=selected 可能是已交付但未同步，不是未生产")
        # 进一步走 session_search 或 ls project directory 确认

# ✅ 正确：查项目目录是否有视频/发布日志
import os
proj_dir = f'/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects'
# 遍历找含该 topic_id 的 project_info.json
for d in os.listdir(proj_dir):
    pj = f'{proj_dir}/{d}/00_project_info/project_info.json'
    if os.path.exists(pj):
        with open(pj) as f:
            pj_data = json.load(f)
        if pj_data.get('topic_id') == tid or pj_data.get('topic', '') == pool_title:
            files = os.listdir(f'{proj_dir}/{d}/03_video/') if os.path.isdir(f'{proj_dir}/{d}/03_video/') else []
            video_done = any(f.endswith('.mp4') for f in files)
            print(f"→ 项目 {d}: video={'✅' if video_done else '❌'}")
```

**快速验证**（发现 status=selected 时立即执行）：

```bash
# 一行查出项目是否存在
grep -rl "topic_id_here\|话题标题" /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/*/00_project_info/project_info.json 2>/dev/null

# 或查 session 是否记录过
session_search(query="话题关键词", limit=1, sort=newest)
```

**预防（永久规则）**：
- ✅ 看到 `status=selected` 时，**禁止直接下结论**"已选题未生产"
- ✅ 先查 `PROJECT_REGISTRY.json` 的 active 列表（按 topic_id 或 title 匹配）
- ✅ 再查项目目录 `03_video/video_final.mp4` 或 `05_publish/publish_log.json` 是否存在
- ✅ 最后查 session 历史确认
- ❌ 永远不要仅凭 pool.db 单个字段判断项目是否完成

**关联陷阱**：
- 陷阱 25（无回写钩子）→ 系统不写 status = 本陷阱的触发前提
- 陷阱 18（脚本 exit code 信号解读）→ 同为「单个字段不可信」类问题
- 陷阱 17（cron 静默无操作）→ 同为「只看一个信号就下结论」类问题

> 这个陷阱曾在 2026-06-01 导致误杀话题「**大模型头部玩家吸干一级市场 - QQ.com**」

**错误推理链（禁止使用）：**
```
来自Tavily + 无source_url + 标题含站点名 → 聚合转载 → reject
```

这个推理链是错的。**"标题含站点名"≠"内容农场"**。Tavily收录时带站点名作为标题后缀，不等于内容本身是聚合转载。

**正确判断只基于「来源域名」本身：**

| 判断要素 | ✅ Content Farm（reject） | ✅ 正常话题（keep） |
|---------|--------------------------|-------------------|
| source_url的**域名** | diandian.com、leifeng.com、smzdm.com等已知农场 | 证券时报、36氪、澎湃、知乎、微博等正规媒体/平台 |
| 标题本身 | 含SEO特征词：工具推荐、教程、"技巧"、"如何..." | 有具体事件/数据/分析，无SEO词 |
| 无source_url | **只是一个信号**，交 Layer 3 细审，不直接 reject | 微博热搜天然无URL，但本身是新闻事件 |

**三个「不是reject条件」：**
1. ❌ **"无source_url"** — 不等于内容差，可能是Tavily收录时没带URL。处理方式：交Layer3细审。
2. ❌ **"标题含站点名"** — "新浪财经"、"QQ.com"出现在标题后缀里是Tavily的正常行为，不等于聚合转载。
3. ❌ **"来自Tavily"** — Tavily来源本身不是reject理由。

**"一否"：只看source_url的域名本身是否是content farm。**

**误判案例（2026-06-01 教训）：**
- 话题："大模型头部玩家吸干一级市场 - QQ.com"
- 错误判断逻辑：Tavily + 无URL + 标题含QQ.com → 聚合转载 → reject
- 问题：这条是正常科技报道，只是Tavily收录时没带URL，不能reject
- 正确做法：标记为"需要Layer3细审"而不是直接reject
- 结果：已误杀，已手动捞回

---
