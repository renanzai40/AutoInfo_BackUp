# event_date 新鲜度升级（2026-06-12 落地）

## 背景

DeepSeek V4 话题暴露的核心矛盾：`freshness_score` 衡量的是"这篇报道什么时候入库的"，不是"这个事件什么时候发生的"。

## 改动

### 1. 角度判定脚本加 `event_date` 输出

在 `judge_topics_angle.py` 的 PROMPT 中新增第 6 个输出字段 `event_date`，LLM 根据内部知识判断该事件发生的时间。

```
输出 schema 新增:
  "event_date": "<该事件发生的具体日期，格式 YYYY-MM-DD；无法判断给 null>"
```

LLM 判定规则：
- 已知大事件（DeepSeek V4 上线、融资、产品发布等）→ 输出真实发生日期
- 无法判断（节日、纯人名、模糊事件等）→ null
- 旧闻翻炒识别：如果标题说"将发布"但实际已上线多日，输出真实上线日期而非文章发布日期

### 2. freshness_maintenance.py 改用 COALESCE

```sql
-- 改前（基于入库时间）：
MAX(6.0, 10.0 - (today - created_at))

-- 改后（基于事件时间，无则回退入库时间）：
MAX(6.0, 10.0 - (today - COALESCE(event_date, created_at)))
```

### 3. pool.db 新增列

```sql
ALTER TABLE topics ADD COLUMN event_date DATE;
```

### 4. max_tokens 提升（副作用）

prompt 因新增 event_date 字段 + 规则说明 + 更新 few-shot 示例而变长（2200→2848 chars），输出需求增大。原 `max_tokens=1500` 不足（finish_reason=length 截断），提升至 `max_tokens=3000`。

## 效果验证

以 DeepSeek V4 财联社话题为例：
- 入库时间: 2026-06-10 → freshness=9.0（入库仅 2 天）
- 事件时间: 2026-06-01（V4 Flash 实际上线日期）→ freshness=6.0（保底）
- 综合分从 8.71 → 7.81，业务款 TOP2 → TOP4

## 局限

- **仅对新入库话题生效**：已有 angle_score 的历史话题不会被重新判定，event_date=null → 仍回退到 created_at
- **依赖模型知识**：对模型训练数据未覆盖的小众事件，LLM 可能无法判断日期 → event_date=null（正常 fallback）
- **Layer 3 旧闻拦截互补**：event_date 降低综合分（排序下沉），Layer 3 直接 rejected（不进角度判定），两者不重叠
