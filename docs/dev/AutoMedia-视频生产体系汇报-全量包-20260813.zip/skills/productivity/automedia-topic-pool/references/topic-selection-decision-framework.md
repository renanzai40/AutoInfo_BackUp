# 选题决策框架：业务款 vs 引流款（2026-06-06 固化）

> 本文件讲"业务款 / 引流款**怎么选**"——是 SKILL.md "评分公式" + "Layer 2.5 m3 角度判定" + 8:30 推送 SQL 三者之间的**选品决策层**。
>
> 触发：8:30 推送 SQL 编写 / 选题推荐给 user / 池薄时决定是否放宽阈值 / 8:30 推送误塞低分污染推送 / 业务款 vs 引流款优先级冲突。

---

## 核心原则（2026-06-06 user 拍板）

> **"业务款是产品，引流款是流量入口"** —— 两者**用不同维度评估**，**不能混着用同一 SQL 过滤**

| 维度 | 业务款（产品） | 引流款（流量入口）|
|------|---------------|-----------------|
| **目标** | 给 B2B AI 目标受众**直接提供价值** | 拉点击 + 制造情绪共鸣 |
| **m3 angle_score 阈值** | **≥7**（hard filter） | 4-6（mid 段可用）|
| **heat_score 阈值** | 中等（≥0.5 即可）| **≥0.7**（hard filter）|
| **source 优先** | Tavily/AIHOT（金矿）| 微博/知乎/抖音（真热点）|
| **三维度 c/b/t 要求** | 三维都 ≥6 | c 维度 ≥6 即可 |
| **风险** | 必 none | 必 none |
| **数量** | 1-2 条/天 | 1-2 条/天 |
| **桥接目标** | CTA 到"壹目贯维服务" | 引到同 session 业务款 |

---

## 为什么需要两套独立评估

### m3 评分对中文平台话题的判定特性（2026-06-06 实证）

m3 **不是中性**评分模型——它对 B2B AI 业务款的"内容可生产性"有偏好。

| source | 处理数 | 角分 avg | 高分(≥7) | mid(4-6) | low(<4) |
|---|---|---|---|---|---|
| 知乎 | 78 | **1.26** | **0** | 3 | 75 |
| 微博 | 41 | **1.49** | **0** | 4 | 37 |
| 抖音 | 40 | **1.30** | **0** | 2 | 38 |
| Tavily | 25 | 5.56 | 11 | 7 | 7 |
| AIHOT | 17 | 6.12 | 8 | 7 | 2 |

**关键事实**：
- 微博/知乎/抖音 159 条 → **0 条 ≥7 分**（avg 1.3-1.5）
- Tavily/AIHOT 42 条 → **19 条 ≥7 分**（avg 5.5-6.1）
- **如果用 m3 score ≥7 一个标准选业务款 + 引流款**：
  - 业务款池：19 条（Tavily/AIHOT 主导）
  - 引流款池：**0 条**（中文平台过不了 m3 ≥7 的门槛）
  - **但中文平台恰恰是引流款的真热点**——m3 1.3 的"曝红果短剧收益断崖式下跌"是 6.0 分微博话题，**热度和 CTR 极高**

**结论**：
- 业务款 = m3 主导（m3 score 是"内容可生产性"的直接测量）
- 引流款 = heat 主导（heat 是"平台热度"的直接测量，m3 score 只做"内容可生产"底线）
- **两者用不同主维度排序**——不能用同一 SQL 选

---

## 实操 SQL 模板（8:30 推送 prompt 用）

### 业务款候选

```sql
-- 业务款候选（m3 score 主导）
SELECT title, source, angle_score, heat_score, angle_reason
FROM topics
WHERE status = 'pending'
  AND review_status = 'approved'
  AND angle_score IS NOT NULL
  AND angle_score >= 7
  AND risk_flag NOT IN ('politics', 'disaster', 'privacy', 'sensitive')
ORDER BY angle_score DESC, heat_score DESC
LIMIT 5;
```

**关键点**：
- **hard filter**：`angle_score >= 7`（必带，否则 1.3 分微博会塞进来）
- **不**用 `heat_score` 做硬过滤（业务款允许 heat 0.2 的"5亿Tokens白送"——m3=8.0 业务款）
- **次序**：m3 score DESC > heat DESC（业务款先看内容可生产性，再看平台热度）

### 引流款候选

```sql
-- 引流款候选（heat 主导，m3 score 4-6 段可用）
SELECT title, source, angle_score, heat_score, angle_reason
FROM topics
WHERE status = 'pending'
  AND review_status = 'approved'
  AND angle_score IS NOT NULL
  AND angle_score >= 4 AND angle_score < 7
  AND heat_score >= 0.7
  AND risk_flag NOT IN ('politics', 'disaster', 'privacy', 'sensitive')
ORDER BY heat_score DESC, angle_score DESC
LIMIT 5;
```

**关键点**：
- **hard filter**：`heat_score >= 0.7`（必带，否则低热度话题塞进来）
- **m3 阈值 4-6**（不卡 ≥7——引流款允许 m3 中等分；卡 <4 是为了拦"内容完全不可生产"的话题）
- **次序**：heat DESC > m3 score DESC（引流款先看平台热度，再看内容底线）

### 池空时的处理

```sql
-- 业务款池空检查
SELECT COUNT(*) FROM topics
WHERE status = 'pending'
  AND review_status = 'approved'
  AND angle_score >= 7
  AND risk_flag NOT IN ('politics', 'disaster', 'privacy', 'sensitive');
-- = 0 → 8:30 推送显示"业务款池空，今日无可推荐业务款" + 提示"等明早 cron 跑新进库"
-- ❌ 不要放宽到 ≥6 凑数

-- 引流款池空检查
SELECT COUNT(*) FROM topics
WHERE status = 'pending'
  AND review_status = 'approved'
  AND angle_score >= 4 AND angle_score < 7
  AND heat_score >= 0.7
  AND risk_flag NOT IN ('politics', 'disaster', 'privacy', 'sensitive');
-- = 0 → 8:30 推送显示"引流款池空" + 提示"建议从 5+ 分话题里挑一条临时引流"
-- ⚠️ 引流款池空比业务款常见（中文平台入库数波动大），适当放宽到 m3 ≥3 是 OK 的
-- ❌ 不要放宽到 m3=0（2026-06-05 "天涯神帖" angle=3 污染推送的根源）
```

---

## 选题推荐 SOP（agent 给 user 推 2 选 1 时用）

### 第一步：跑两个 SQL 拿到候选

```python
import sqlite3
c = sqlite3.connect('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db')

# 业务款 TOP5
biz = c.execute("""
    SELECT title, source, angle_score, heat_score
    FROM topics
    WHERE status = 'pending'
      AND review_status = 'approved'
      AND angle_score IS NOT NULL
      AND angle_score >= 7
      AND risk_flag NOT IN ('politics', 'disaster', 'privacy', 'sensitive')
    ORDER BY angle_score DESC, heat_score DESC
    LIMIT 5
""").fetchall()

# 引流款 TOP5（mid 段）
growth = c.execute("""
    SELECT title, source, angle_score, heat_score
    FROM topics
    WHERE status = 'pending'
      AND review_status = 'approved'
      AND angle_score IS NOT NULL
      AND angle_score >= 4 AND angle_score < 7
      AND heat_score >= 0.7
      AND risk_flag NOT IN ('politics', 'disaster', 'privacy', 'sensitive')
    ORDER BY heat_score DESC, angle_score DESC
    LIMIT 5
""").fetchall()
```

### 第二步：4 维评估每个候选

| 维度 | 业务款评估 | 引流款评估 |
|------|----------|----------|
| **m3 score** | 三维度 c/b/t 都 ≥6 | c 维度 ≥6 即可 |
| **heat_score** | 0.5+ 都 OK（不是主维度）| **0.7+** 是底线 |
| **跨平台** | 出现多次 = 高价值信号 | 单源 = 真热点信号 |
| **新鲜度** | 入库时间 < 7 天优先 | 入库时间 < 14 天（可以稍旧）|
| **bridge 路径** | 桥接到"壹目贯维服务"具体路径 | 桥接到同 session 业务款 |

### 第三步：给 user 推 2 选 1 + 3 套备选

```
业务款 TOP3 候选：
1. [title] | m3=9.0 | heat=0.8 | source=AIHOT | 适配角度：...
2. ...
3. ...

引流款 TOP3 候选：
1. [title] | m3=6.0 | heat=0.9 | source=微博 | CTR 钩子：...
2. ...
3. ...

我的推荐：业务款 #1 + 引流款 #1（理由：...）
备选 1：业务款 #2 + 引流款 #1（理由：...）
备选 2：业务款 #1 + 引流款 #3（理由：...）
```

### 第四步：等 user 选 → 启动 5 平台文案 + Remotion 视频生产

**禁止 agent 主动选**——8:30 推送"等 user 选"是设计原则（推送 cron 不直接触发生产，避免半成品）

---

## 反模式（永久禁止）

### ❌ 反模式 1：8:30 推送一条 SQL 选两个 category
```sql
-- ❌ 错
SELECT * FROM topics
WHERE angle_score >= 7  -- 业务款标准
   OR (angle_score >= 4 AND heat_score >= 0.7)  -- 引流款标准
ORDER BY angle_score DESC
LIMIT 5;
```
**问题**：OR 逻辑下，m3=1.5 heat=0.9 的微博可能排前面，污染"业务款"推荐

### ❌ 反模式 2：业务款池空就放宽到 ≥6
```sql
-- ❌ 错：业务款池空放宽阈值凑数
SELECT * FROM topics WHERE angle_score >= 6 ORDER BY ...
```
**问题**：m3 6-7 分话题里很多是"勉强可做"，强行 1-2 条/天产能下不划算（2026-06-03 user 拍板 ≥7 阈值）

### ❌ 反模式 3：引流款池空就放宽到 m3=0
```sql
-- ❌ 错：引流款池空塞任何高分
SELECT * FROM topics WHERE angle_score >= 7 ORDER BY heat_score DESC
-- 这就回到业务款池了，没意义
```
**问题**：塞回业务款候选 = 同话题推两次，浪费 8:30 推送名额

### ❌ 反模式 4：用 heat_score 给业务款排序
```sql
-- ❌ 错：业务款按 heat 排
SELECT * FROM topics WHERE angle_score >= 7 ORDER BY heat_score DESC
```
**问题**：heat 0.2 的"5亿Tokens白送"（m3=8.0）会被埋没——heat 0.9 的"红果短剧"（m3=6.0）排前面，但这是引流款不是业务款

### ❌ 反模式 5：用 m3 score 给引流款排序
```sql
-- ❌ 错：引流款按 m3 score 排
SELECT * FROM topics WHERE heat_score >= 0.7 ORDER BY angle_score DESC
```
**问题**：m3 1.3 的微博热搜（CTR 极强）永远排后面，heat 0.9 m3 5.5 的小众话题（CTR 中等）排前面——违反引流款目标

---

## 真实案例（2026-06-06）

### 76 高分话题分布
- Tavily: 41 / AIHOT: 31 / 知乎: 2 / 微博: 1 / 项目文件: 1

### 业务款候选（m3 ≥7，22 条）—— 6 大类热门

| 话题 | m3 | heat | source | 推荐度 |
|---|---|---|---|---|
| Grok Imagine 1.5 预览版发布 | 9.0 | 0.8 | AIHOT | ⭐⭐⭐⭐⭐ TOP1 |
| AI生成视频技术进展：2026 商用水平 | 8.0 | 0.7 | Tavily | ⭐⭐⭐⭐ |
| 吉宏电商×火山引擎：Seedance 共建 AI 素材工厂 | 8.0 | 0.6 | Tavily | ⭐⭐⭐⭐ |
| 5亿 Tokens 白送！全球首个商用 AI 主机发布 | 8.0 | 0.2 | Tavily | ⭐⭐⭐ (heat 异常低) |
| 配音师困在 AI 里：声音被盗后火遍全网 | 8.0 | 0.7 | Tavily | ⭐⭐⭐⭐ 双修款 |
| Apollo 350 亿债务融资，为 Anthropic 采购 AI 芯片 | 7.0 | 0.6 | AIHOT | ⭐⭐⭐ |

### 引流款候选（mid 4-6 + heat ≥0.7，3 条）—— 微博 + 知乎

| 话题 | m3 | heat | source | CTR 钩子 |
|---|---|---|---|---|
| 曝红果短剧收益断崖式下跌 | 6.0 | 0.9 | 微博 | "断崖式下跌"4 字天然 CTR |
| 外国网红中国搭便车的视频火到国外 | 6.0 | 0.9 | 微博 | 文化反差 + 跨文化传播 |
| 配音师困在 AI 里（重新分类为引流款） | 8.0 | 0.7 | Tavily | 情绪共鸣 + AI 伦理 |

### 我的推荐（带理由）

**业务款 #1 = Grok Imagine 1.5**：
- m3 9.0（最高） + 三维 9/9/9（唯一三维全满） + AIHOT 一手信息 + 6/4 入库新
- bridge 路径：横评 → "我们提供 AI 内容生产工具链选型" CTA

**引流款 #1 = 红果短剧收益断崖式下跌**：
- heat 0.9（最高） + 微博源（真热点） + 短剧赛道流量天花板
- bridge：短剧下滑 → "AI 短剧是不是出路？" → 引到 A1 Grok Imagine 视频生成

---

## 8:30 推送 prompt 中如何表达这个框架

```markdown
# 8:30 推送 prompt 选品决策章节

## 业务款候选（必选 1 条）
- 跑 biz 那个 SQL 拿 TOP 5
- 如果 0 条 → 显示"业务款池空"+ 提示等 cron 跑新进库
- 如果 < 3 条 → **不要**放宽阈值，按现有条数推（哪怕只有 1 条）

## 引流款候选（必选 1 条）
- 跑 growth 那个 SQL 拿 TOP 5
- 如果 0 条 → 显示"引流款池空"+ 提示"建议从 5+ 分话题里挑一条临时引流"
- 如果 ≥ 3 条 → 按 heat 排序取 TOP 1

## 输出格式
- 业务款 TOP 1：{title} | m3={score} | heat={score} | source={src}
- 引流款 TOP 1：{title} | m3={score} | heat={score} | source={src}
- 桥接建议：引流款 → 业务款 的具体桥接路径
- 等待用户回复选择
```

---

## 触发本 reference 的所有场景

| 症状 | 跳到哪一节 |
|------|----------|
| 8:30 推送 prompt SQL 编写 | 实操 SQL 模板 |
| 给 user 推 2 选 1 | 选题推荐 SOP |
| 业务款池空不知道怎么显示 | 池空时的处理 |
| 推送误塞低分污染 | 反模式 1-5 |
| 业务款 vs 引流款优先级冲突 | 核心原则 + 4 维评估表 |
| m3 评分对中文平台偏低怀疑 m3 出 bug | m3 评分对中文平台话题的判定特性 |

---

## 相关 reference（不重复造轮子）

- `SKILL.md` 评分公式段（heat_score/correlation_score/freshness_score 加权公式）
- `SKILL.md` Layer 2.5 LLM 角度判定层（m3 score 4 维评分 + 阈值 ≥7 推荐）
- `SKILL.md` 陷阱 21（业务款 vs 引流款不能用同一维度硬过滤）
- `references/llm-angle-judgment.md` — m3 v1/v2 评分细节
- `references/llm-angle-judgment-cron-timing.md` — m3 任务 cron 时序
- `references/cron-0830-push-workflow.md` — 8:30 推送 7 步流程（含 SQL 模板）
