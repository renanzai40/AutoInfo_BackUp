# DeepSeek reasoning_content 吞噬 token 陷阱

> 采集脚本和角度判定脚本中，deepseek-v4-flash（通过 opencode API）返回的 `reasoning_content` 会占用 `max_tokens` 预算，导致 `content` 为空，JSON 解析失败。
>
> 触发：看到 cron output 中持续出现「LLM去重解析失败，保留全部…条」/「Layer2 解析失败，保留全部…条」。
>
> 关联：陷阱 28（角度判定 prompt 变长后 max_tokens 不够）。

## 现象

采集脚本 cron output 中以下 4 行**全部**出现（持续数周不断）：

```
LLM去重解析失败，保留全部44条
Layer2 解析失败，保留全部 44 条
LLM去重解析失败，保留全部111条
Layer2 解析失败，保留全部 111 条
```

之后所有 LLM 过滤层全部降级为「保留全部」，流 1/流 2 的 AI 质量筛选完全失效。

## 根因

通过直接 API 测试验证：

```
Content repr: ''
Has reasoning: True
Finish reason: length
Usage: {..., completion_tokens: 2000, reasoning_tokens: 2000}
```

- **`content` 为空字符串**——模型把所有 `max_tokens` 预算消耗在 `reasoning_content`（思考过程）上，没有剩余 token 产出实际回答
- `finish_reason: "length"`，不是 `"stop"`
- API 响应中的 `content` 字段为 `null`/`""`，脚本 `json.loads('')` 失败 → 正则 `\{.*\}` 在空字符串上匹配不到 → 打印「解析失败」→ 返回全部保留

这是 DeepSeek 模型通过 opencode API 调用的固有行为。模型会先输出思考过程，再用剩余 token 输出回答。当 batch 较大、prompt 较长或 `max_tokens` 不足时，思考过程就可能吃光所有预算。

### 与陷阱 28 的区别

| 维度 | 陷阱 28（已有） | 本陷阱 |
|------|----------------|--------|
| 触发脚本 | `judge_topics_angle.py`（单条调用） | `auto_media_hot_collection_v3_*.py`（批量 44-140 条） |
| 触发原因 | prompt 变长，`max_tokens=1500` 不够 | **批量太大**导致 reasoning 开销剧增 + `subprocess timeout=50` 过紧 |
| `max_tokens` 值 | 1500 → 3000 修好 | **2000 不够**，需 3000+ |
| `subprocess timeout` | 130s（够用） | **50s**（远小于 curl `--max-time=120`） |
| 重试逻辑 | 有（3 次重试） | 无（1 次失败直接降级） |

## 影响范围

**采集脚本 3 个 LLM 调用函数全部受影响：**

| 函数 | 位置 | max_tokens | subprocess timeout | curl --max-time | 状态 |
|------|------|-----------|-------------------|-----------------|------|
| `llm_dedup` | L549 | 2000 | 50 | 120 | **两个都不够** |
| `llm_layer2_gate` | L467 | 2000 | 50 | 120 | **同上** |
| `llm_seo_filter` | ~L380 | 2000 | 50 | 120 | **同上**（可能同样受影响） |

由于 LLM 过滤全部失效，流 1 和流 2 的内容全靠「信息密度过滤器」（关键词/正则/实体匹配）硬扛，AI 内容质量大幅下降。

## 修法（2026-06-20 采集脚本全面修复）

实际修法比预期复杂——**单纯增大参数不够**，需要 3 类改动配合。

### 第一类：参数对齐（3 处函数 × 3 参数 = 9 处改动）

| 参数 | 修前 | 修后 | 原因 |
|------|------|------|------|
| `max_tokens` | 2000 | **6000** | 3000 不够（见下文「第二类」原因）。单条调用用 3000，批量调用（40+条）必须 6000+ |
| `subprocess.run timeout` | 50 | **180** | 旧值 `50 < curl --max-time=120` 是致命 bug——curl 活到 120s，但 subprocess 50s 就杀进程 |
| `curl --max-time` | 120 | **150** | 配套增大，确保 subprocess timeout(180) > curl timeout(150)，留 30s 余量 |

**位置**：`llm_seo_filter`（L369-380）/ `llm_layer2_gate`（L467-478）/ `llm_dedup`（L549-561）。

### 第二类：Layer2 大 batch 拆分（核心修复）

原理：DeepSeek 模型的 reasoning tokens 消耗随**批量大小**而非线性——45 条 batch 需要 6000+ reasoning tokens，后续 content 永远 0。

**实测数据**（max_tokens=6000 时）：

| 任务 | 条数 | 内容长度 | 通过 |
|------|------|---------|------|
| 单条 JSON | 1 | `'{"test":"hello"}'` | ✅ |
| Dedup | 3 | `'{"groups":[["DeepSeek发布新模型","DeepSeek推出新一代AI模型"]]}'` | ✅ |
| Dedup | 45 | **空字符串** (6000 全 reasoning) | ❌ |
| Dedup | 83 | **空字符串** (6000 全 reasoning) | ❌ |
| Layer2 | 45 | 正常 JSON (`decisions` dict) | ✅ |
| Layer2 | 83 | **空字符串** | ❌ |

**拆分批处理**——在 `llm_layer2_gate` 函数入口加分割逻辑，每批 ≤40 条：

```python
BATCH_SIZE = 40
if len(items) > BATCH_SIZE:
    all_filtered = []
    for chunk_start in range(0, len(items), BATCH_SIZE):
        chunk = items[chunk_start:chunk_start + BATCH_SIZE]
        chunk_result = _layer2_process_batch(chunk, api_key)
        all_filtered.extend(chunk_result)
    return all_filtered
```

拆出 `_layer2_process_batch` 作为实际处理函数（原来 `llm_layer2_gate` 的主体代码移入此函数）。

### 第三类：Dedup 解析失败 → hash 兜底（而非保留全部）

Dedup 任务（判断 45+ 条哪些是同一事件）的推理复杂度 O(n²) 远超 Layer2（分类）。即使拆分为更小 batch（≤20），模型仍需大量 `reasoning_content`。

**不再尝试让 LLM 做批量 dedup**——解析失败时降级到 hash 去重（按 title 前 50 字符）： 

```python
# 原：print("LLM去重解析失败，保留全部")
#     return titles  ← 44-111 条全保留，信息密度扛不住

# 改为：
print("⚠️ LLM去重解析失败，本地 hash 兜底去重")
seen = set()
local_kept = []
for t in titles:
    key = t[:50].lower().strip()
    if key not in seen:
        seen.add(key)
        local_kept.append(t)
return local_kept
```

hash 去重对标题精确/近似重复已足够（同源热搜天然唯一居多），Layer2 和信息密度过滤会做后续质量兜底。

### 验证结果

修前（4 道 LLM 全挂）：
```
LLM去重解析失败，保留全部44条      ← 流1 dedup ❌
Layer2 解析失败，保留全部 44 条    ← 流1 Layer2 ❌
LLM去重解析失败，保留全部111条     ← 流2 dedup ❌
Layer2 解析失败，保留全部 111 条   ← 流2 Layer2 ❌
```

修后（全通）：
```
⚠️ LLM去重解析失败 (content空/无JSON)，本地 hash 兜底去重
本地去重: 45条 -> 45条 (排除0条)          ← 流1 dedup ✅ hash
Layer2 相关性过滤: 45条 -> 1条 (排除44条不相关)  ← 流1 Layer2 ✅ LLM

⚠️ LLM去重解析失败 (content空/无JSON)，本地 hash 兜底去重
本地去重: 151条 -> 151条 (排除0条)         ← 流2 dedup ✅ hash
⚠️ Layer2批处理: 151条拆为多批 (每批40条)
Layer2 相关性过滤: 40条 -> 35条 (排除5条不相关)  ← 流2 Layer2 批1 ✅
Layer2 相关性过滤: 40条 -> 32条 (排除8条不相关)  ← 流2 Layer2 批2 ✅
Layer2 相关性过滤: 40条 -> 33条 (排除7条不相关)  ← 流2 Layer2 批3 ✅
Layer2 相关性过滤: 31条 -> 19条 (排除12条不相关) ← 流2 Layer2 批4 ✅
```

**核心指标**：4 道 LLM 过滤全部工作，**没有任何降级保留全部的情况**。

## 2026-06-25 三重修复：双副本不同步 + llm_dedup batch splitting + hash 预去重层

### 发现 1：6-20 修复只同步了 cron 副本，DEV 副本未同步

md5sum（2026-06-25 修前）：
```
a3182507  ~/.hermes/profiles/content/scripts/...  (已修复)
5e4f4940  /mnt/d/Hermes-Workspace/...              (未修复)
```

DEV 副本 `max_tokens=2000` / `timeout=50` 撑了 5 天未被同步。用户手动跑时全部降级。

**教训**：修完脚本后立即 `cp` 到所有副本 + `md5sum` 校验。仅仅在 skill 文档里写"⚠️ 副本必同步"不够（已写但 5 天后发现 DEV 副本仍不同步）——必须作为**修复流程的强制出口步骤**，修完不 cp 就不算修完。

### 发现 2：`llm_dedup` 缺少 batch splitting

6-20 修复给 `llm_layer2_gate` 加了 `BATCH_SIZE=40` batch splitting，但 **`llm_dedup` 没加**。Tavily 16 query 一次产出 100+ 条全塞一个 LLM 调用。即使 `max_tokens=6000`，大 batch 下 reasoning_content 仍可能吃光预算。

### 三重修复内容

| 层 | 修复 | 解决什么 |
|----|------|---------|
| 1 | **hash 预去重层**（flow1 + flow2 的 `llm_dedup` 前） | 用 `t[:50].lower().strip()` 先消 obvious 重复，减少 LLM 输入量 + LLM 全挂时的兜底 |
| 2 | **`llm_dedup` batch splitting**（≤10 条/批 + 跨批 hash 去重） | 等价于 Layer2 的 batch splitting——拆小 batch 后 reasoning 开销可控。但 6-28 实测发现即使 20 条 batch，O(n²) 配对比较的 reasoning 也会吃光 6000 tok，需降到 ≤10 条。 |
| 3 | **双副本同步**（cp + md5sum） | DEV 副本拿到全部历史修复 + 新修复 |

**核心验收指标**：两副本 md5sum 一致。修复完成时必须验证，不允许单向修复。

#### 改动 1：hash 预去重层（flow1 + flow2）

在 `llm_dedup` 调用之前插入：

```python
flow1_titles = list({item['title']: item for item in flow1_raw}.keys())

# Layer 1.5: hash 近精确预去重
if flow1_titles:
    _seen = set()
    _hashed = []
    for _t in flow1_titles:
        _k = _t[:50].lower().strip()
        if _k not in _seen:
            _seen.add(_k)
            _hashed.append(_t)
    _dropped = len(flow1_titles) - len(_hashed)
    if _dropped > 0:
        print(f"  hash预去重: {len(flow1_titles)}条 -> {len(_hashed)}条 (排除{_dropped}条)")
    flow1_titles = _hashed

flow1_kept = llm_dedup(flow1_titles, LLM_API_KEY) if flow1_titles else []
```

同一模式也应用到 `flow2`。

#### 改动 2：`llm_dedup` batch splitting + 跨批去重

`llm_dedup` 顶部添加 batch splitting（≤10 条，2026-06-28 从 40 下调），超出时递归调用自身处理每批，最后对汇总结果做跨批 hash 去重：

```python
def llm_dedup(titles, api_key):
    if not titles:
        return []
    
    # 2026-06-28: BATCH_SIZE=10（DeepSeek-v4-flash 的 O(n²) 配对比较在 20 条时 already 吃光 max_tokens=6000）
    BATCH_SIZE = 10
    if len(titles) > BATCH_SIZE:
        batched = [titles[i:i+BATCH_SIZE] for i in range(0, len(titles), BATCH_SIZE)]
        print(f"  ⚠️ LLM去重批处理: {len(titles)}条拆为 {len(batched)} 批 (每批{BATCH_SIZE}条)")
        all_kept = []
        for chunk in batched:
            all_kept.extend(llm_dedup(chunk, api_key))
        # 跨批最终 hash 去重
        seen, deduped = set(), []
        for t in all_kept:
            k = t[:50].lower().strip()
            if k not in seen:
                seen.add(k)
                deduped.append(t)
        inter = len(all_kept) - len(deduped)
        if inter > 0:
            print(f"  LLM去重跨批去重: 消除{inter}条跨批重复")
        return deduped
    
    return _llm_dedup_batch(titles, api_key)
```

`_llm_dedup_batch` 是原 `llm_dedup` 的主体代码（0-40 条的单批处理逻辑）。

### 完整去重管线（修后）

```
flow2_titles（50~120 条）
  → L0 标题精确去重（set）→ 50~100 条
  → L1 hash 预去重（t[:50].lower().strip()）→ 30~70 条
  → L2 LLM 语义去重（≤10 条/批 + 跨批 hash）→ 5~15 条
  → Layer2 相关性过滤
```

每一层都带 hash 兜底，LLM 全挂时管线退化到 L1 hash 去重 + Layer2 信息密度过滤，功能不中断。

### 修改的文件和备份

- `auto_media_hot_collection_v3_20260525.py` — 两副本均修改，md5sum 一致验证
- 备份：`.bak.20260625_102231_triple-fix`（DEV 副本和 CRON 副本都有）

## 关键约束

- **`subprocess.run timeout` 必须 ≥ `curl --max-time`**，否则 subprocess 先杀进程，curl 的 `--max-time` 形同虚设
- 修前  `subprocess timeout=50 < curl --max-time=120` 是 bug
- 修后  `subprocess timeout=180 > curl --max-time=150` ✅
- **Layer2 Batch splitting ≤ 40**——Layer2 分类（O(n) 逐条判断）超过 40 条时 reasoning_content 大概率吃光预算。这是经验值，基于 45 条 Layer2 刚好可以通过 6000 max_tokens 的实测
- **Dedup Batch splitting ≤ 10**——Dedup 是 O(n²) 配对比较，即使 ≤40 条也会吃光预算。实测 20 条时 reasoning 已满 6000 tok，必须降到 ≤10

## 诊断方法

在脚本之外直接调 API，验证 reasoning_content 行为和 max_tokens 够不够：

```bash
source /home/renanzai/.hermes/profiles/content/.env && \
curl -s --max-time 45 -X POST 'https://opencode.ai/zen/go/v1/chat/completions' \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer $OPENCODE_GO_API_KEY" \
  -d '{"model": "deepseek-v4-flash", "messages": [{"role": "user", "content": "Say only: {\"test\": \"hello\"}"}], "temperature": 0.1, "max_tokens": 100}' \
  | python3 -c "
import sys, json
data = json.load(sys.stdin)
msg = data['choices'][0]['message']
print('Content repr:', repr(msg.get('content', '')))
print('Has reasoning:', 'reasoning_content' in msg)
print('Finish reason:', data['choices'][0].get('finish_reason'))
print('Usage:', data.get('usage'))
"

# 正常响应：Content repr: '{"test": "hello"}' 或类似
# 异常响应：Content repr: '' 且 Has reasoning=True → max_tokens 被 reasoning 吃掉
```

## 预防

- **任何新写/修改调用 deepseek-v4-flash（或任何通过 opencode 的思维链模型）的脚本时，先测 `max_tokens` 足够大。** 经验值：单条 prompt 1500-3000，批量 prompt（≤40 条）6000+
- **`subprocess.run timeout` 必须 ≥ `curl --max-time`**，这是一对不可分开的参数
- 设置 curl 的 `--max-time` 时，留 10-20% 余量给 subprocess 兜底（如 curl=150, subprocess=180）
- **Batch splitting 是必要手段**——单纯加大 `max_tokens` 不能解决大批量推理的 reasoning 开销。注意：Layer2 分类（O(n)）BATCH_SIZE=40 可以正常工作，但 dedup（O(n²) 配对比较）必须 ≤10
- 同一个脚本中多处调用同一模型，参数必须保持一致（采集脚本 3 个 LLM 函数参数散落分布，改时全量检查）
- **Dedup/semantic 类任务优先用 hash fallback + pre-layer**——LLM 的 pairwise 比较在 20+ 条时推理预算无法控制。dedup BATCH_SIZE 必须 ≤10（实测 20 条 reqsoning 已吃光 6000 tok），Layer2 分类（O(n)）可以 ≤40
- **修完脚本后立即 `cp` + `md5sum` 到所有副本**——这是强制出口步骤，不做到不算修完。仅靠文档里的 "⚠️ 副本必同步" 警告不够（有过 5 天不同步的实际案例）。

## 已发生两次的副本不同步案例

| 时间 | 漏洞 | 不同步持续 |
|------|------|-----------|
| 2026-06-09 → 06-12 | `judge_topics_angle.py` 模型迁移 DeepSeek，skill 包副本残留 MiniMax | 3 天 |
| 2026-06-20 → 06-25 | 采集脚本 6-20 修复（max_tokens/timeout/batch splitting）仅落 CRON 副本 | **5 天** |

两个案例都是同一个反模式：**只修了 CI/CD 部署路径上的副本，忘了同步 dev 区。** 下次任何脚本修改必须：
1. 备份所有副本
2. 修改一个副本（通常是 CRON 副本，生产直接跑的那个）
3. `cp` 到其他所有副本
4. `md5sum` 验证一致性
