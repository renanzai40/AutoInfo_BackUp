# MiniMax M3 API 实战陷阱（2026-06-03 实测）

> 2026-06-03 跑 278 条 LLM 角度判定时踩的坑。触发：调 m3 失败、JSON 解析为空、批量 m3 调用、prompt 设计。
>
> ⚠️ **模型迁移记录**：2026-06-08 壹目贯维已从 MiniMax 迁移到 DeepSeek-v4-flash。本文档记录的 MiniMax M3 特定陷阱（大小写、base_url、模型名规范）不再适用于当前运行时。文档保留为历史参考。

## 坑 1：`max_tokens=300` 截断 `` 思考标签

**症状**：
- LLM 输出 `<think>... 1000 字 ...</think> {"angle_score": 3, ...}`
- 但 `max_tokens=300` 只够 300 tokens（~450 字符）
- 截断后：API 返回 `<think>... 思考到一半就停 ...`（无 JSON）
- 日志记 `no_json:<think>The user wants me to evaluate...`

**根因**：m3 默认会输出 `` 思考过程（类似 o1 / DeepSeek-R1），`` 标签本身占满 token 预算。

**修法**：
```python
payload = json.dumps({
    "model": "MiniMax-M3",
    "messages": [...],
    "max_tokens": 1000,   # 关键：>= 1000，让 think + JSON 都有空间
}, ensure_ascii=False)
```

**额外加固**：在 prompt 里强提示
```
【必须直接输出 JSON，不要 <think> 思考标签】
只输出严格 JSON（不能有其他内容）
```

## 坑 2：API 偶发空响应（curl 静默失败）

**症状**：
- `r = subprocess.run(cmd, capture_output=True, text=True, timeout=130)`
- `r.stdout` 是空字符串
- 不是 timeout（30 秒内完成）
- 不是 JSON 错误（根本没有返回）

**根因**：MiniMax API 偶发返回空响应（可能是限流、可能是服务端问题）。curl 静默吞掉错误。

**修法**：retry 3 次 + 指数 backoff
```python
for attempt in range(max_retry):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=130)
        if not r.stdout:
            if attempt < max_retry - 1:
                time.sleep(5 * (attempt + 1))   # 5s, 10s, 15s
                continue
            return None, "empty_stdout"
        # ... 处理 r.stdout
    except subprocess.TimeoutExpired:
        if attempt < max_retry - 1:
            time.sleep(5)
            continue
        return None, "timeout"
```

## 坑 3：Python 字段名 KeyError

**症状**：
- 旧 log 字段是 `corr`（python 写入时简写）
- 新代码用 `r["correlation_score"]` → `KeyError`
- 跑批量脚本时**第一次循环就崩**

**根因**：字段名不统一，跨脚本/会话复用时易踩。

**修法**：用 `.get()` + 兜底默认值
```python
# ❌ 错误：硬编码字段名
corr = r["correlation_score"]

# ✅ 正确：容错读取
corr = r.get("corr") or r.get("correlation_score") or 5.0
```

**预防**：所有读取都走 `.get()`，写新代码时**先看实际 log 字段名再写代码**（用 `cat file.jsonl | head -1 | jq`）。

## 坑 4：patch 工具 whitespace 严格匹配（python indent=2 文件）

**症状**：
- jobs.json 是 `json.dump(..., indent=2)` 写入的
- patch 工具的 `old_string` 找不到匹配（因为空白不一致）
- 错误：`Could not find a match for old_string in the file`

**根因**：patch 工具的 fuzzy match 对 indent 不一致容忍度低。

**修法**：改用 Python str.replace + 备份 + 写回
```python
# ❌ 错误：用 patch 工具改 jobs.json
patch(mode="replace", path="jobs.json", old_string="...", new_string="...")

# ✅ 正确：Python str.replace
import json, shutil
JOBS = Path("jobs.json")
shutil.copy2(JOBS, "/tmp/jobs.bak.ts")  # 必做
content = JOBS.read_text()
content = content.replace(old_str, new_str)
JOBS.write_text(content)
```

**适用**：所有用 `json.dump(indent=2)` 写出的文件都走 Python 改。

## 坑 5：docstring 字面 `\u` 触发 SyntaxError

**症状**：
- 写中文 docstring 描述 bug：`"""本次 bug 是 \u escape 导致乱码"""`
- Python 解析报错：`SyntaxError: (unicode error) 'unicodeescape' codec can't decode bytes ... truncated \uXXXX escape`

**根因**：Python 把 `\u` 当 unicode escape 开始，期待后面 4 位 hex。如果不是 4 位 hex 就报错。

**修法**（3 选 1）：
```python
# 方案 1：raw string
r"""本次 bug 是 \u escape 导致乱码"""

# 方案 2：双反斜杠
"""本次 bug 是 \\u escape 导致乱码"""

# 方案 3：英文描述（最稳）
"""本次 bug 是 unicode-escape 导致乱码"""
```

**预防**：
- 写任何"修复 unicode 类 bug"的脚本时，**避免写 `\u` 字面量**
- 用 ASCII 描述（"unicode-escape bug" / "non-ASCII escape"）
- 写完用 `python3 -c "import ast; ast.parse(open('fix.py').read())"` 验证

## 坑 6：print 异常对象暴露 API key

**症状**：
- `print(f"  M3 调用失败: {e}")`
- `e.__str__()` 包含完整 curl cmd，包括 `Authorization: Bearer sk-cp-XXXX`
- 日志文件里泄露 API key

**根因**：`subprocess.TimeoutExpired` / `CalledProcessError` 异常的 `__str__()` **包含完整 cmd 列表**。

**修法**：
```python
# ❌ 错误：print 异常对象
print(f"  M3 去重失败: {e}，保留全部{len(titles)}条")

# ✅ 正确：只 print 异常类型名
print(f"  M3 去重失败 ({type(e).__name__})，保留全部{len(titles)}条")
```

## 坑 7：model name 大小写

**症状**：API 报 `model not found`

**正确名称**：`MiniMax-M3`（驼峰 + M3 大写）

**错误名称**：
- `M3` / `m3`（不识别）
- `minimax-m3`（全小写不识别）
- `MiniMax-M2.7`（不是 M3）

**预防**：复制粘贴时保留原始大小写。

## 坑 8：base_url 配置错误

**正确 base_url**：
- 国内：`https://api.minimaxi.com/v1`
- 国际：`https://api.minimax.io/v1`

**环境变量**：`MINIMAX_CN_BASE_URL`（**不是** `MINIMAX_BASE_URL` 也不是 `MINIMAX_URL`）

**验证**：
```bash
grep MINIMAX ~/.hermes/profiles/content/.env
```

## 坑 9：m3 输出含智能引号

**症状**：
- m3 返回：`{"reason": "AI\u4f01\u4e1a\u91cd\u7891\u4ea7\u54c1\u53d1\u5e03"}` 这是 Python repr 形式
- 实际 m3 返回可能：`{"reason": "AI企业重磅产品发布"}`（带智能引号）
- JSON 解析正常，但 reason 字符串含 `"` `'` 等智能引号

**修法**：prompt 强调"用普通 ASCII 引号"
```
reason: 一句话
避免用 "smart quotes" / 「」 等特殊符号
```

## 完整 m3 调用模板（推荐）

```python
import subprocess, json, re, time

API_KEY = os.environ.get("MINIMAX_CN_API_KEY")
BASE_URL = os.environ.get("MINIMAX_CN_BASE_URL", "https://api.minimaxi.com/v1")

def call_m3(prompt: str, max_retry: int = 3):
    """调 m3，重试 + JSON 容错"""
    payload = json.dumps({
        "model": "MiniMax-M3",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.1,
        "max_tokens": 1000,
    }, ensure_ascii=False)
    cmd = [
        "curl", "-s", "--max-time", "120",
        "-X", "POST",
        "-H", "Content-Type: application/json",
        "-H", f"Authorization: Bearer {API_KEY}",
        "-d", payload,
        f"{BASE_URL}/chat/completions",
    ]
    for attempt in range(max_retry):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=130)
            if not r.stdout:
                if attempt < max_retry - 1:
                    time.sleep(5 * (attempt + 1))
                    continue
                return None, "empty_stdout"
            try:
                data = json.loads(r.stdout)
            except json.JSONDecodeError:
                if attempt < max_retry - 1:
                    time.sleep(3)
                    continue
                return None, "json_parse_fail"
            if "error" in data:
                if attempt < max_retry - 1:
                    time.sleep(5)
                    continue
                return None, f"api_error:{data['error']}"
            content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
            m = re.search(r'\{[\s\S]*\}', content)
            if not m:
                if attempt < max_retry - 1:
                    time.sleep(3)
                    continue
                return None, "no_json"
            return json.loads(m.group()), None
        except subprocess.TimeoutExpired:
            if attempt < max_retry - 1:
                time.sleep(5)
                continue
            return None, "timeout"
        except Exception as e:
            return None, type(e).__name__  # 关键：不 print str(e) 暴露 key
    return None, "exhausted"
```

## 一句话总结

**调 m3 必设 `max_tokens=1000`，retry 3 次，print 异常用 type name 不用 str()**。
**写 unicode 修复类脚本时，docstring 避免 `\u` 字面量**。
