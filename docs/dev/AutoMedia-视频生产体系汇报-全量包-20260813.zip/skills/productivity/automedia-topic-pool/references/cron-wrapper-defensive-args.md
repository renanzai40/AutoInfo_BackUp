# Cron Wrapper 防御性参数显式传（2026-06-06 实测固化）

> 本文件讲"cron wrapper bash 脚本为什么必须显式传所有参数"——是 cron-deployment-pitfalls.md 11 个坑 + cron-silent-noop-patterns.md 4 大类的**横向补充**，专注"wrapper 设计"这一类问题。
>
> 触发：写新 cron 任务 / 改 judge_angles_cron.sh 这类 wrapper / 改 judge_topics_angle.py 默认值 / 怀疑"今天修的 bug 静默回归了"。

---

## 核心原则（一句话）

**Cron wrapper 是生产路径的胶水层。生产路径不能依赖被调脚本的默认值。**

---

## 为什么这个原则重要（2026-06-06 实测教训）

### 当天的 m3 静默坑时间线

1. 5/11 写 `judge_angles_cron.sh` 时只传 `--limit 200`，**不传** `--source`
2. 依赖 `judge_topics_angle.py` 默认 `--source="Tavily,AIHOT"`
3. 当时**Tavily/AIHOT 入库量大**（220 条）→ cron 正常处理 → 一切看起来 OK
4. 后来 Tavily/AIHOT 处理完了，**新进库全是中文平台**（微博/知乎/抖音）
5. cron 跑 → WHERE source IN 过滤 → 0 条 → "✅ 没有待判定的" → exit 0 → last_status=ok
6. **业务侧静默 0 进展**，但所有监控看 last_status 全 OK
7. 8:30 推送榜永远只有 Tavily/AIHOT 旧数据，**新进中文平台话题永远过不了 m3**

**修复**：
- 改 m3 脚本默认值 = `微博,知乎,抖音,Tavily,AIHOT`（5 个全开）✅
- **但**——如果未来 m3 脚本默认值又被改回 `Tavily,AIHOT`，**cron 静默回归** ❌

**真正的修法**：
- wrapper **显式传** `--source 微博,知乎,抖音,Tavily,AIHOT`
- 即使 m3 脚本默认值被改坏，cron 仍按 wrapper 指定的 source 跑
- wrapper 内 comment 写明"防御默认值被改坏"——未来维护者一眼能看出意图

---

## 完整 wrapper 模板（2026-06-06 已落地）

```bash
#!/bin/bash
# judge_angles_cron.sh — cron 调 m3 角度分判定的 wrapper
# 触发：judge_angles_08x10 / judge_angles_12x00 / judge_angles_16x00 3 个 cron job
# 原因：hermes cron scheduler 把 script 字段当纯路径，不支持命令行参数
#       所以包一层 bash 脚本，固定传 --limit 200
# 2026-06-06 增强：显式传 --source 全 5 个 source（防御 m3 脚本默认值被改坏导致
#                 cron 静默漏跑中文平台话题——8:30 推送会全靠旧数据）
set -e
exec /home/renanzai/.hermes/hermes-agent/venv/bin/python3 \
    /home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py \
    --limit 200 \
    --source 微博,知乎,抖音,Tavily,AIHOT
```

**关键 3 点**：
1. **所有会影响行为的参数都显式传**（`--limit` + `--source`）
2. **每个显式参数都带注释**说明"为什么这么传"
3. **结尾 comment 写明"防御 X 脚本默认值被改坏"**——给未来维护者的明确信号

---

## 哪些参数必须显式传（决策清单）

写 wrapper 时问自己：**"如果被调脚本默认值被改回坏值，cron 还会正常工作吗？"**

| 参数类型 | 显式传？ | 例子 |
|---|---|---|
| 影响**行为**的参数 | **必须**显式传 | `--source` / `--limit` / `--min-corr` / `--category` / `--threshold` |
| 影响**输入路径**的参数 | **必须**显式传 | `--config` / `--db-path` / `--input-dir` |
| 影响**输出位置**的参数 | **必须**显式传 | `--output` / `--log-file` / `--report-path` |
| 影响**模式**的参数 | **必须**显式传 | `--dry-run` / `--verbose` / `--force` / `--no-cache` |
| 仅影响**格式**的参数 | 可不传 | `--format json` / `--date-format` / `--locale` |
| 仅影响**help**的参数 | 可不传 | `--help` / `--version` |

**反例**（2026-06-06 修复前）：
```bash
# ❌ 错：依赖 m3 脚本默认值
exec python3 judge_topics_angle.py --limit 200
# m3 脚本默认 --source="Tavily,AIHOT" → 静默漏跑中文平台
```

```bash
# ✅ 对：显式传所有行为参数
exec python3 judge_topics_angle.py --limit 200 --source 微博,知乎,抖音,Tavily,AIHOT
# 即使 m3 默认值被改坏，cron 仍按 wrapper 指定的 5 source 跑
```

---

## 写新 wrapper 的 4 步检查清单

```bash
# 1. 看被调脚本的 default values
python3 judge_topics_angle.py --help
# 找出所有有 default 的参数

# 2. 评估每个 default 是不是 cron 想要的
# - 是 → 显式传（即使和 default 一样）+ 注释
# - 否 → 显式传 + 注释说明"为什么改这个值"

# 3. wrapper 内 comment 写明"防御默认值被改坏"

# 4. 写完跑 dry-run 验证
bash ~/.hermes/profiles/content/scripts/judge_angles_cron.sh --dry-run 2>&1 | head -10
# 看优先级 source 列表 / limit 等是不是和预期一致
```

---

## 反模式（永久禁止）

### ❌ 反模式 1：依赖默认值的 wrapper
```bash
exec python3 judge_xxx.py  # 完全依赖默认值
```
- 任何默认值改动都会静默影响 cron
- 没有防御性

### ❌ 反模式 2：透传 CLI 的 wrapper
```bash
exec python3 judge_xxx.py $@  # 透传 CLI
```
- cron scheduler 不支持传 CLI（陷阱 15），但**未来可能支持**
- wrapper 是生产路径，**不该有"灵活"借口**——"灵活"= 不可预测
- 万一未来传错参数（比如 `--dry-run`），cron 跑空跑 = 静默坑

### ❌ 反模式 3：wrapper 内调"动态探测"逻辑
```bash
SOURCE=$(python3 -c "print('微博,知乎,抖音,Tavily,AIHOT')")  # 动态拼 source
exec python3 judge_xxx.py --source "$SOURCE"
```
- 看起来"灵活"，实际把 cron 行为变成"动态"
- 动态 = 难调试 = 排查时多一个变量
- 静态写死 = 简单可读 = 排查快

### ❌ 反模式 4：wrapper 内做业务逻辑
```bash
# ❌ wrapper 内调 m3 API 算分
SCORE=$(curl -s ... | python3 -c "import json; print(json.load(sys.stdin)['score'])")
if [ "$SCORE" -gt 7 ]; then
    exec python3 judge_xxx.py --only-high-score
fi
```
- wrapper 只该做"参数固定 + exec"——业务逻辑放主脚本
- wrapper 调 m3 API 写业务逻辑 = 跨层关注 = 难维护
- **例外**：纯文件操作（如 lock 检查 / log 路径生成）

### ❌ 反模式 5：wrapper 不写注释
```bash
exec python3 judge_xxx.py --limit 200 --source 微博,知乎,抖音,Tavily,AIHOT
```
- 看起来"对"，但未来维护者不知道为什么是这个 source 列表
- 不知道"为什么"= 不知道能不能改 = 容易改坏

---

## 预防性设计：wrapper 配置 vs 业务脚本默认值

**两个层次**：
- **业务脚本默认值**：给"手动跑"用（开发者灵活性）
- **wrapper 参数**：给"cron 跑"用（生产路径确定性）

**两者解耦的好处**：
- 开发者手动跑：`python3 judge_xxx.py --limit 50 --source Tavily`（用 default 或灵活传）
- cron 跑：`bash judge_angles_cron.sh`（wrapper 固定 200 条 + 5 source）
- 改 default 不影响 cron（wrapper 显式传覆盖了）
- 改 wrapper 不影响手动跑（手动跑不走 wrapper）

**坏处（接受）**：
- wrapper 和脚本默认值**可能不一致**——定期对账是 OK 的
- 任何参数"加了" → 同步在 wrapper 显式传

---

## 实操：写新 wrapper 的完整流程

```bash
# 1. 备份（如有旧 wrapper）
cp ~/.hermes/profiles/content/scripts/judge_angles_cron.sh \
   ~/.hermenues/profiles/content/scripts/judge_angles_cron.sh.bak.$(date +%Y%m%d_%H%M%S)

# 2. 写新 wrapper（用模板）
cat > ~/.hermes/profiles/content/scripts/judge_angles_cron.sh << 'EOF'
#!/bin/bash
# <wrapper_name>.sh — <一句话说明>
# 触发：<cron job IDs>
# 原因：<为什么需要 wrapper>
# 2026-06-06 增强：显式传 <所有影响行为的参数>（防御 <被调脚本> 默认值被改坏导致 <静默后果>）
set -e
exec /home/renanzai/.hermes/hermes-agent/venv/bin/python3 \
    <被调脚本绝对路径> \
    --<参数1> <值1> \
    --<参数2> <值2> \
    --<参数3> <值3>
EOF

# 3. chmod +x
chmod +x ~/.hermenues/profiles/content/scripts/<wrapper_name>.sh

# 4. dry-run 验证
bash ~/.hermes/profiles/content/scripts/<wrapper_name>.sh --dry-run 2>&1 | head -10
# 看所有参数（priority source 列表 / limit 等）是不是和 wrapper 写的对得上

# 5. 改 jobs.json script 字段（如有改）
# 旧: "script": "<wrapper_name>.sh"
# 新: "script": "<wrapper_name>.sh"  # 通常不变

# 6. 触发一次 cron 验证
hermes cron run <job_id>
sleep 30
# 看 db delta / output 文件 / 4 步验证（cron-silent-noop-patterns.md Step 1-4）
```

---

## 触发本 reference 的所有场景

| 症状 | 跳到哪一节 |
|------|-----------|
| 想写新 cron 任务的 wrapper | 写新 wrapper 的完整流程 |
| 怀疑"今天修的 bug 静默回归了" | 哪些参数必须显式传（决策清单）+ 预防性设计 |
| 改 judge_topics_angle.py 默认值后想确认 cron 不受影响 | 反模式 1：依赖默认值的 wrapper |
| 同事改 wrapper 但不知道影响哪些 cron | 反模式 4：wrapper 内做业务逻辑 |
| cron 跑通但 pool.db 数据不对 | 反模式 2：透传 CLI 的 wrapper |

---

## 相关 reference（不重复造轮子）

- `references/cron-deployment-pitfalls.md` — 坑 1（路径）+ 坑 1.5（script 不支持参数） + 坑 5（last_status 假阳性）
- `references/cron-silent-noop-patterns.md` — 4 大类静默坑（wrapper 默认值算类别 A2 + 类别 B1）
- `references/cron-m3-script-hardening.md` — 解决 m3 脚本 commit / SIGTERM 问题
- `references/2026-06-06-m3-silent-failures-incident.md` — 当天 m3 静默坑完整时间线
- `references/manual-m3-run-workflow.md` — 手动跑 m3 任务的 6 步流程
