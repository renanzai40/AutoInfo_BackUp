# LLM 角度判定层 v2（2026-06-05 升级）

> 触发：调整 Layer 2.5 角度判定 prompt、设计 m3 评分维度、改 brand-cta-review 关联逻辑、debug 旅行/儿童节/矿难等争议话题。
>
> 上游文档：v1 设计见 `references/llm-angle-judgment.md`（5/5 样本 + 278 全量实证）

## 升级背景（user 反馈触发）

**2026-06-05 user 原话**：

> "之所以要做角度分是因为有些引流款实在是不好写 bridge 和 CTA"

**Agent 此前误读**：把 `angle_score` 理解成"话题和 AI 的字面相关度"（`correlation_score` 已经做这层了，重复）。

**正确理解**（从 `brand-cta-review` Section 0 Topic Selection Gate 反推）：

`angle_score` 的本质 = **bridge/CTA 可写性的预审**——
- 问 1：话题核心概念与"AI 内容生产"有没有天然连接？
- 问 2：桥的方向是否在"AI 内容生产"业务线上（不走偏成投资/数据/个人效率）？
- 问 3：硬桥是否比不桥更差？（灾难/政治/隐私等敏感话题一律不桥）

**v1 bug 实测**：旅行记忆 v1 判 3 分（"无 AI 关联"），其实有桥"旅行内容创作者在用 AI 工具做内容 → 壹目贯维"——v1 把 content 可生产性和 bridge 可写性混着评，bridge 维度被 content 拉低。

## v2 架构：4 维度独立打分

### 字段定义

```json
{
  "content_score": <0-10>,    // 内容可生产性：标题本身是否有事件/数据可展开
  "bridge_score": <0-10>,     // bridge 可写性：能否 3 句话内自然桥到"AI 内容生产"业务
  "cta_score": <0-10>,        // CTA 可写性：壹目贯维"AI 内容生产公司"身份能否自然承接
  "risk_flag": "none|disaster|politics|privacy|sensitive",  // 风险标记
  "suggested_bridge": "<一句话桥接方向；final<6 给 null>"
}
```

### 评分维度详解

**content_score**（内容可生产性）
- 0-3: 纯节日/纯人名/3字以下无数字
- 4-5: 有事件但信息模糊
- 6-7: 有清晰事件，5-15秒可讲
- 8-10: 完美（AI 行业新闻/产品发布/技术突破/具体数据）

**bridge_score**（核心新增维度，**按 brand-cta-review Topic Selection Gate 三问**）

```
问1：话题核心概念与"AI 内容生产"有没有天然连接？
  天然连接（bridge 6-10）：内容传播/假信息 / 内容生产工具/创作 / 热点追踪/信息获取 / AI 行业新闻
  无法桥（bridge 0-4）：纯娱乐/个人体验/情感 / 投资/金融/政策分析 / 纯社会事件

问2：桥的方向是否在"AI 内容生产"业务线（热点追踪/文案生成/多平台发布）？
  同向：bridge 不变
  走偏（投资情报/数据分析/个人效率工具）：bridge -2

问3：硬桥是否比不桥更差？
  强行桥 = 非 sequitur 感：bridge -3
  灾难/政治敏感（即使事件大也不桥）：bridge = 0-1
```

**cta_score**（CTA 可写性，参照 brand-cta-review Section 1.3 "过渡同向"）
- 0-3: CTA 硬塞会"非 sequitur"或违反"零承诺原则"
- 4-5: CTA 勉强能写但要绕弯
- 6-7: CTA 自然承接（"AI 追踪热点/AI 生成内容/AI 多平台发布"任一具体功能可挂）
- 8-10: CTA 完美承接（话题本身在 AI 内容生产业务生态里）

**risk_flag**（4 类风险，触发后 final 减分）
- `disaster`: 矿难/地震/空难/重大伤亡 → penalty -2
- `politics`: 政治敏感/政府官员/政策争议 → penalty -1
- `privacy`: 个人隐私/八卦/未公开信息 → penalty -1
- `sensitive`: 教育/民族/性别等争议话题 → penalty -1
- `none`: 无风险 → penalty 0

### final angle_score 公式

```python
base = min(content_score, bridge_score, cta_score)
penalty = {"disaster": 2, "politics": 1, "privacy": 1, "sensitive": 1, "none": 0}.get(risk_flag, 0)
final = max(0, round(base - penalty))
```

**关键设计**：取三维度的**最小值**（最严格），防止一维度高分带飞整话题。例：content=8（事件清晰）但 bridge=2（无桥），final=max(2, ...)=2，不会因为内容好就过。

### suggested_bridge 规则

- `final >= 6`：必给一句话桥接方向（例"旅行记忆 → 旅行内容创作者在用 AI 工具 → 壹目贯维"）
- `final < 6`：给 `null`（避免 m3 给低分话题也硬塞桥，污染选题）

## 5 样本 v2 验证（2026-06-05 实测，5/5 schema 正确）

| 样本 | v1 angle | v2 c/b/t/risk | v2 final | 评估 |
|------|---------|---------------|---------|------|
| M3 大模型发布 | 10 | 10/10/10/none | **10** | ✓ 保持满分 |
| 旅行买的是专属记忆 | 3 | 5/6/6/none | **5** | ⬆️ +2（bridge=6 显式识别） |
| 留神峪煤矿事故82人 | 1 | 8/0/0/disaster | **0** | ⬇️ 更准（disaster penalty -2） |
| CBA 季后赛 G1 | 3 | 7/2/2/none | **2** | ⬇️ -1（bridge=2 显式无桥） |
| Alphabet 800亿+Anthropic IPO | 9 | 8/8/7/none | **7** | ⬆️ 更精细（cta=7 区分度） |

**关键发现**：
1. **schema 5/5 正确**：所有字段名一致，类型正确
2. **bridge 维度独立可观察**：旅行从 3 → 5（bridge=6），CBA 从 3 → 2（bridge=2）
3. **risk flag 精确**：矿难 disaster 触发，final 直接降到 0
4. **副作用**：v2 比 v1 **分数普遍下降 1-2 分**——更精确但阈值可能需要重新校准

**bridge 建议文本质量**（m3 输出实测）：
- M3: "AI 模型新品发布，5秒讲完，天然业务款，壹目贯维基于同源能力做 AI 视频/配音/批量内容生产"
- 字母: "AI 行业资本动作频繁，可解读为 AI 内容生产赛道持续被看好，需求旺盛"

→ 可作为后续写脚本的桥接提示，**实测可用**。

## 实施步骤（v1 → v2 迁移）

### 1. ALTER TABLE topics 加 2 列

```sql
ALTER TABLE topics ADD COLUMN suggested_bridge TEXT;
ALTER TABLE topics ADD COLUMN risk_flag TEXT;
```

### 2. 改 `judge_topics_angle.py`（在 `~/.hermes/profiles/content/skills/productivity/automedia-topic-pool/scripts/`）

**PROMPT 整段替换**（v2 完整 prompt 见 SKILL.md 的 Layer 2.5 章节，或直接看脚本顶部常量）

**关键改动**：
- JSON schema 5 字段（content_score/bridge_score/cta_score/risk_flag/suggested_bridge）
- 占位符用 `$title`/`$source`/`$corr`（**用 string.Template，不用 .format()**）
- max_tokens 1000 → 1500（5 字段输出更长）

**`call_m3()` 改动**：
```python
from string import Template
prompt = Template(PROMPT).safe_substitute(title=title, source=source, corr=corr)
# max_tokens: 1500
```

**主循环解析逻辑改动**（写库）：
```python
content = parsed.get("content_score")
bridge = parsed.get("bridge_score")
cta = parsed.get("cta_score")
risk = parsed.get("risk_flag", "none")
bridge_text = parsed.get("suggested_bridge")
reason = (parsed.get("reason") or "")[:500]

if content is None and "angle_score" in parsed:
    # v1 容错：老 m3 偶发回 v1 schema，降级用
    score = parsed.get("angle_score")
    # 写老 3 列
elif content is not None and bridge is not None and cta is not None:
    # v2 正常路径
    base = min(content, bridge, cta)
    penalty = {"disaster": 2, "politics": 1, "privacy": 1, "sensitive": 1, "none": 0}.get(risk, 0)
    final = max(0, round(base - penalty))
    if final < 6:
        bridge_text = None  # 规则：final<6 不给 bridge 建议
    reason_full = f"[c={content},b={bridge},t={cta},risk={risk},final={final}] {reason}"
    if bridge_text:
        reason_full += f" | bridge: {bridge_text[:200]}"
    # 写 5 列：angle_score, angle_reason, angle_judged_at, suggested_bridge, risk_flag
else:
    # malformed_json 失败
```

### 3. dry-run 验证 + 小批量回灌

- `--limit 5 --dry-run` 看候选列表（不调 m3）
- 写独立 test 脚本（不要用 dry-run flag），单条调 m3 验证 schema
- 50 条样本验证 v2 vs v1 分布变化
- 全量回灌（清 angle_score 后重跑）**必须先和 user 确认**

## 已知坑

### string.Template vs .format()（2026-06-05 实测）

**坑**：PROMPT 里有 JSON 大量 `{}` 字符，`.format()` 会把 `{"content_score": ...}` 当占位符，KeyError。

**修法**：用 `string.Template` + `$varname` 占位符：
```python
from string import Template
prompt = Template(PROMPT).safe_substitute(title=title, source=source, corr=corr)
```

**为什么不用 f-string 转义 `{{...}}`**：v1 PROMPT 用 `{{"angle_score"...}}` 转义，但 v2 PROMPT 长 50+ 行 + JSON 多重嵌套，转义后几乎不可读。Template 干净。

### max_tokens 1500 不是 1000

**坑**：v1 max_tokens=1000 够（3 字段），v2 输出 5 字段更长，1000 会被 m3 默认 `<think>` 思考标签截断。

**修法**：v2 必须 `max_tokens=1500`，并 prompt 强提示"不要 `<think>` 思考标签"。

### v1 fallback 不能丢

**坑**：m3 偶发返回 v1 schema（只回 angle_score，没 3 维度），如果代码硬要求 3 维度都非空会统计成 malformed。

**修法**：保留 v1 容错路径——`content is None and "angle_score" in parsed` → 走老 3 列 UPDATE。

### risk_flag 不在枚举里时 default 0

m3 偶尔输出 `"risk_flag": ""` 或新枚举（如 `"controversial"`），不要 crash。

**修法**：`{"disaster": 2, "politics": 1, "privacy": 1, "sensitive": 1, "none": 0}.get(risk_flag, 0)` —— 未知值默认 0 penalty，log 出来人工看。

## 跨引用

- `brand-cta-review` Section 0 Topic Selection Gate — **bridge_score 维度的判定标准来源**
- `brand-cta-review` Section 1.3 过渡同向 — **cta_score 维度的判定标准来源**
- `brand-cta-review` Section 1.7 零承诺原则 — **risk_flag sensitive 类的来源**
- `references/llm-angle-judgment.md`（v1）— 5/5 样本 + 278 全量实证 + m3 API pattern

## 未来校准方向

v2 实测分数普遍下降 1-2 分（v1 的"内容可生产性强"在 v2 拆出后变成 content=8 但 bridge=2 拉低 final），**8:30 推送的 angle>=7 阈值可能需要重新校准**：

- 跑 50 条 v2 历史样本后，看 final>=7 / final>=6 / final>=5 三档的话题数
- 8:30 推送 SQL 硬过滤 `angle_score >= 7` 维持不变，但要在 cron prompt 注释"v2 阈值"出处
- 如果引流款 final>=7 仍只有 2 条/day，**这是诚实的答案**（不是 bug），触发空池提示即可

## 修改历史

- 2026-06-05: v2 升级（3 维度 + risk + bridge），5/5 样本验证通过
- 2026-06-03: v1 落地（Layer 2.5 + 5/5 样本 + 278 全量实证），见 `references/llm-angle-judgment.md`
