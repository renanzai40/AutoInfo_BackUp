# ⚠️ 致命陷阱：SQL 查询与脚本操作（2026-06-01 新增）

## ⚠️ 致命陷阱：SQL 查询与脚本操作（2026-06-01 新增）

### 陷阱 1：`pool.db` 的 `source` 字段是大写，不是小写

**坑过的真实案例（2026-06-01 B 跑验证）**：
- 准备删除 3 条 AIHOT 话题时，写 `WHERE source='aihot'` → 匹配 0 条 → 误以为没数据
- 实际：表里是 `AIHOT`、`Tavily`、`微博`、`知乎`、`抖音`、`项目文件`（**首字母大写或中文**）

**source 字段的 distinct 值（实测 2026-06-01）**：
```
AIHOT: 13
Tavily: 179
微博: 144
知乎: 132
抖音: 118
项目文件: 1
```

**所有 SQL 涉及 source 过滤时，必须用上表中的真实值，不能凭直觉写小写。**

### 陷阱 2：`auto_media_hot_collection_v3_*.py` 是「假 import、真执行」

> 🔴 **这是最高优先级的坑。任何对 v3 脚本做"import 验证"都会触发真实采集 + 写库。**

**坑过的真实案例（2026-06-01）**：
```python
# 以为只是验证脚本能加载
import importlib.util
spec = importlib.util.spec_from_file_location('m', '...v3_20260525.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)  # ← 实际上执行了完整采集！写了 3 条 AIHOT 话题！
```

**根因**：v3 脚本的模块顶层就有采集执行代码（`minimax_seo_filter`、`minimax_layer2_gate`、`minimax_dedup` 等函数调用 + 写库），不是封装在 `if __name__ == '__main__':` 里。

**正确做法**：
- ❌ **永远不要用 importlib 做 v3 脚本的"dry-run"**
- ✅ 如果想验证脚本能跑：`subprocess.run(['python3', script_path, '--help'])` 看是否有 dry-run 参数
- ✅ 临时验证：在子目录里复制 v3 脚本，**手动加 `if __name__ == '__main__':` 保护**后再 import
- ✅ 跑前必查：跑前先 `SELECT COUNT(*) FROM topics` 记数，跑完对比

### 陷阱 3：删除 topic 前必先 SELECT 打印 + JSON 备份

**流程**：
```python
# 1. SELECT 打印待删的（不直接 DELETE）
cur.execute("SELECT topic_id, title, source, created_at FROM topics WHERE ...")
to_delete = cur.fetchall()
for r in to_delete:
    print(r)  # 让人眼看一眼

# 2. 写 JSON 快照到 /tmp
import json, datetime
ts = datetime.now().strftime("%Y%m%d_%H%M%S")
log_path = f"/tmp/pool_delete_log_{ts}.json"
with open(log_path, 'w', encoding='utf-8') as f:
    json.dump([...], f, ensure_ascii=False, indent=2)

# 3. 再 DELETE
cur.executemany("DELETE FROM topics WHERE topic_id=?", [(r[0],) for r in to_delete])

# 4. 立即 SELECT COUNT(*) 验证

# 5. 用户决定不要了 → 用快照 JSON 重新 INSERT
```

**坑过的真实案例（2026-06-01）**：删了 3 条 AIHOT 话题（"误以为是噪音"），但用户**反而想保留**（M3 真实产品信息）→ 幸亏有 JSON 快照，3 条全部恢复。

---
