# 遗留 References 章节（陷阱 22/23 等）

## References

- 脚本备份：`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/auto_media_hot_collection_v3_20260525.py.bak.20260601`
- 知识库：`/mnt/d/Hermes-KnowledgeBase/`

### 陷阱 22：cron dashboard `last_run: error` 是**历史状态**而非"现在跑的状态"（2026-06-06 23:00 dashboard 实测，认知坑）

**症状**：
- 23:00 dashboard 跑完，报告里写"08:10 m3 ❌ error / last_run: 13h ago"
- 用户怀疑 23:00 dashboard 没刷新这个 job 的 last_run
- 实际 23:00 跑时**这个 job 不会重跑**（cron 调度按 schedule expr，不是 dashboard 触发）
- dashboard 只读 `jobs.json` 的 last_run_at + last_status 字段显示

**根因**：
- cron job 的 `last_run_at` 字段是**最近一次 cron 调度器实际跑该任务**的时间
- 8:10/12:00/16:00 这 3 个 job 的 next_run_at 是 06-07 8:10/12:00/16:00
- 23:00 dashboard 跑时，**这 3 个 job 不会重跑**（schedule 未到）
- jobs.json 显示的 `last_run: 13h ago` = 今天 8:10/12:00/16:00 那次跑的状态（**历史**）

**正确解读 dashboard 报告**：
- 23:00 dashboard 显示的 `last_run` = **该 job 最近一次被 cron 调度跑的时间**（不是 dashboard 触发的）
- 如果 last_run_at 跨过"job 应该跑的多个 schedule 周期"都没更新 → 任务真没跑（独立 bug）
- 如果 last_run_at 是上次的失败状态 + **下次 cron 应该跑的时间还没到** → 历史问题，下次成功跑会覆盖

**实测案例（2026-06-06 23:00 dashboard）**：
- 报告："08:10 m3 判定 ❌ error / last_run: 13h ago"
- 真因：今天 8:10 跑时 jobs.json 没 `script_timeout: 1800`（17:21 才加），300s default 杀进程
- **23:00 跑 dashboard 不会**改这个字段——要等 6-07 8:10 cron 触发
- 6-07 8:10 cron 跑（approved NULL ≈ 0）→ exit 0 → last_run 改为 `2026-06-07T08:10:xx` + status=ok
- 6-07 23:00 dashboard 报告 → 这 3 个 m3 job 应该是 ✅ ok / last_run: today

**预防 + 修复**：
- ✅ 看到 dashboard 报 "❌ error" 时，**先看 last_run 时间**——是历史就**等下次 cron 自然跑**
- ❌ **不要**手动跑 `hermes cron run <id>` 试图"清错误"——可能抢锁 / 副作用不可控
- ❌ **不要**改 jobs.json 字段（`last_run_at` / `last_status`）试图"标记 ok"——**不**修改 scheduler 内部状态
- ✅ 真正修复 = 修 trap 14/15/16/17 的根因，等下次 cron 自然覆盖

**关联反模式**：
- 看到 ❌ error 立刻 panic → 实际是历史
- 看到 8:10/12:00/16:00 全 error 就怀疑 "系统全挂了" → 实际只是这一天的历史，下个 schedule cycle 就好
- 把 dashboard 报告当"实时状态" → dashboard 是**调度器历史快照**，不是"现在跑的状态"

### 陷阱 23：手跑 m3 wrapper 0 秒 exit 0 = **approved NULL = 0 = 池子健康**（2026-06-06 23:21 实测，认知信号）

> 陷阱 22 是"error 是历史"，陷阱 23 是"0 秒退是健康"——两个都是 dashboard / 手跑**信号解读**问题。

**症状**：
- 手跑 `bash judge_angles_cron.sh` → 0 秒 exit 0
- 输出"待处理: 0 条 / 没有待判定的 approved 话题"
- 用户担心"是不是 wrapper 错了 / m3 脚本坏了"

**真因**（2026-06-06 23:21 手跑实测）：
- m3 脚本 SQL：`WHERE angle_score IS NULL AND review_status='approved'`
- 当时 approved NULL = 0（之前 hand-run 跑完了 200+ 条）
- wrapper 0 秒 SELECT → 0 结果 → exit 0（**正常**）
- **不是** wrapper 错 / m3 脚本坏

**正确解读**：
- ✅ 0 秒 exit 0 + "待处理 0 条" = 池子健康（approved 都被判过了）
- ✅ 用 `review_status='approved' AND angle_score IS NULL` 验证池子状态
- ❌ **不要**因为"0 秒太短"怀疑 wrapper 错
- ❌ **不要**改 m3 脚本 SQL 让它处理 rejected 话题（**设计正确，rejected 不该被 m3 判**）

**池子健康度 SQL 速查**：
```sql
SELECT
  COUNT(*) AS total,
  SUM(CASE WHEN review_status='approved' AND angle_score IS NULL THEN 1 ELSE 0 END) AS approved_unjudged,
  SUM(CASE WHEN review_status='rejected' AND angle_score IS NULL THEN 1 ELSE 0 END) AS rejected_unjudged,
  SUM(CASE WHEN review_status='pending' THEN 1 ELSE 0 END) AS pending_review
FROM topics;
-- 理想状态：approved_unjudged 接近 0（m3 跑完了）
-- 解读：rejected_unjudged 多 = Layer 3 审核严格（健康）/ 池子里有大量 rejected 不代表 bug
```

**关联**：与陷阱 22 配合——dashboard 报 ❌ + 手跑 0 秒 = 实际**健康**（历史 error 还没被下次 cron 覆盖 + 当前 approved NULL = 0）。

- **Cron 部署陷阱**（`references/cron-deployment-pitfalls.md`）— jobs.json 迁移、script 路径、deliver chat_id、last_status 假阳性等 5 个 2026-06-01 实测坑 + 修法。触发：手动测试 cron、迁移 jobs.json、添加新 no_agent=true 脚本类 job、新装 hermes profile。
- **LLM 角度判定层设计 + v2 升级**（`references/llm-angle-judgment.md`）— 2026-06-03 v1 + 2026-06-05 v2 合并版。Layer 2.5 prompt 模板、m3 API 调用 pattern、5/5 样本验证（v1+v2 各 5 条）、v1 278 全量实证、v2 50 样本翻盘率实证（**4.8%——prompt 优化有上限，扩池要靠扩源**）、集成架构、v1/v2 已知失败模式、**string.Template 避 `{}` 冲突**、**scripts 副本必同步**陷阱、改 v1→v2 PROMPT 步骤、回灌策略（不推荐全量）。触发：调整 Layer 2.5 prompt、设计 m3 评分维度、改 bridge/CTA 关联逻辑、跑回灌、debug 角度分不一致。
- **角度判定 cron 时序**（`references/llm-angle-judgment-cron-timing.md`）— 2026-06-03 新增。**关键**：cron 必须跑在 08:30 推送**之前**（user 纠正"09:30 太晚"），实测 4 cron 时序（07:30→08:00→08:05→08:10→08:30→09:30），jobs.json 字段模板，m3 提示词全文，selection bias 警告 + Tavily 内容农场过滤 + 阈值 ≥7 推荐 + 4 个已知失败模式。触发：设计/调整角度分 cron 任务、debug 08:30 推送看不到 angle_score、改 Layer 2.5 阈值或 prompt。
- **Cron 08:30 推送工作流**（`references/cron-0830-push-workflow.md`）— 2026-06-06 新增。**7 步推送流程 + session_lock 抢锁/释放 pattern**（含"脚本 time.sleep(60) 阻塞前台 60s"致命陷阱 + 后台启动 + 主 agent 并行干活正确模式）、pool.db SQL hard filter（status=pending + review_status=approved + angle_score IS NOT NULL AND angle_score >= 7）、growth/business 评分公式、推送文本契约（含 5 个最小必含元素）、**池薄(soft-empty)预期场景处理**（2026-06-06 实测引流款仅 1 个 angle≥7 候选）、Pre-production 二次抢锁必要性、推送反模式清单。触发：执行 cron 08:30 推送、debug session_lock 卡死、推送格式不一致、引流款池空了不知道怎么处理。
- **Cron final response 纪律**（`references/cron-final-response-discipline-2026-06-24.md`）— 2026-06-24 新增。LLM-driven cron job agent 输出收尾消息覆盖推送正文的事故复盘 + prompt 硬约束模板。触发：写新 LLM-driven cron job prompt、调试 08:30 推送发空内容。
- **LLM 批处理并行化模式**（`references/llm-batch-parallelization-2026-06-10.md`）— 2026-06-10 新增。**B（延长 timeout）+ C（ThreadPoolExecutor 并行）组合方案**：Phase 1 并行 API 调用 → Phase 2 单线程写库。当 cron 脚本顺序处理 N 条 LLM API 调用超时时使用。触发：judge_topics_angle.py 或其他 cron LLM 批处理脚本超时需要提速。
- **8:00 时区错乱事故复盘**（`references/cron-8am-timezone-bug.md`）— 2026-06-06 新增。
- **8:00 时区错乱事故复盘**（`references/cron-8am-timezone-bug.md`）— 2026-06-06 新增。**config.yaml `timezone: ''` → hermes-time fallback → croniter 解释成 UTC → next_run_at 错位**导致 8:00 任务实际跑在 CST 16:00。3 层根因（fallback 不稳 / advance_next_run 算错 / scheduler 触发时按错位时间）、为什么只有 8:00 任务错乱（其他任务正常）、短期 patch 修法 + 根本预防（强制 config.yaml 锁时区 + job 创建后必查 next_run_at + 跑 1 次验证）。触发：cron 任务实际跑时间 ≠ 预期、next_run_at 算错、jobs.json 时区显示异常。
- **手动跑 m3 任务标准流程**（`references/manual-m3-run-workflow.md`）— 2026-06-06 新增。**6 步完整流程**：查 cron job IDs → 查 baseline NULL 数 → background=true + notify_on_complete=true 启动 → **必 process(poll) 验证真启动**（exit_code: 0 是占位符）→ 等完成通知 → 验证 delta。包含 2 个新陷阱：(陷阱 17) `--limit N ≠ 处理 N 条` 实测 200 → 41 条；(陷阱 18) `terminal(background=true)` 立即返回的 `exit_code: 0` 是占位符而非真实状态。含完整验证脚本 `scripts/verify_m3_run.py` 代码。触发：用户说"手动跑 m3"/"清 NULL"/"补跑角度判定"、cron 任务失败需要补跑、debug 后台任务状态。
- **长跑 cron 脚本硬化**（`references/cron-m3-script-hardening.md`）— 2026-06-06 新增。**commit in loop + SIGTERM handler 2 件套代码 + 测试方法**。修 scheduler 300s timeout 杀进程时已处理结果不丢的核心方案。背景：m3 任务 1 条 API 30+ 秒，200 条要 8-15 分钟，scheduler 必杀。实测改完后 1 条 30 秒 + commit 持久化 OK。触发：改 judge_topics_angle.py / 设计新 no_agent=True 长跑任务 / 调外部 API ≥ 50 次。
- **Cron 任务"静默无操作"反模式**（`references/cron-silent-noop-patterns.md`）— 2026-06-06 新增（**最重要**）。**cron 是 3 段流水线（任务定义 → 脚本执行 → 数据副作用），last_status 只看段 2**。4 大类 9 个反模式：类别 A 任务定义错（`script=null` / `script=xxx.py --arg` / 路径不在 scripts/）、类别 B 脚本跑通但产出 0（**SQL `source IN` 过滤排除全部数据 = 静默坑典型**）、类别 C 业务侧副作用 0（commit 漏了 / 写错 db / 推送缓存）、类别 D 跨段（任务依赖链断 / gateway 旧版）。**4 步诊断手册**（任务定义 → 执行层 → 业务副作用 → 手动跑 db delta） + 2026-06-06 单日发现 5 个独立静默坑清单。**触发：手动跑 cron 处理 0 条 / 用户说"任务没看见触发" / 推送数据陈旧 / last_status 全 ok 但业务侧 0 进展**。
- **Cron wrapper 防御性参数**（`references/cron-wrapper-defensive-args.md`）— 2026-06-06 新增。**"Cron wrapper 是生产路径的胶水层——生产路径不能依赖被调脚本的默认值"**。完整 wrapper 模板（m3 wrapper 显式传 `--limit 200 --source 微博,知乎,抖音,Tavily,AIHOT`）、哪些参数必须显式传（决策清单：影响行为/输入路径/输出位置/模式 = 必传；影响格式/help = 可不传）、4 步写新 wrapper 检查清单、5 个反模式（依赖默认值/透传 CLI/动态探测/wrapper 内做业务逻辑/不写注释）。**触发：写新 cron 任务 wrapper / 改 judge_angles_cron.sh 这类 wrapper / 改 judge_topics_angle.py 默认值 / 怀疑"今天修的 bug 静默回归了"**。
- **选题决策框架：业务款 vs 引流款**（`references/topic-selection-decision-framework.md`）— 2026-06-06 新增。**业务款 = m3 score 主导（≥7 hard filter）+ heat 中等即可 + Tavily/AIHOT 优先**；**引流款 = heat 主导（≥0.7 hard filter）+ m3 4-6 段可用 + 微博/知乎/抖音 优先**。两个独立 SQL 模板 + 4 维评估表 + 选题推荐 SOP（agent 给 user 推 2 选 1）+ 5 个反模式（一条 SQL 选两 category / 业务款池空放宽到 ≥6 / 引流款池空放宽到 m3=0 / heat 排业务款 / m3 排引流款）+ 2026-06-06 真实案例 22 条候选。**触发：8:30 推送 SQL 编写 / 选题推荐给 user / 池薄时决定是否放宽阈值 / 8:30 推送误塞低分污染推送 / 业务款 vs 引流款优先级冲突**。
- **2026-06-06 m3 静默无操作事故复盘**（`references/2026-06-06-m3-silent-failures-incident.md`）— 2026-06-06 新增。**上午 5 个静默坑 + 下午 2 个自造坑**的完整时间线 + 修法 + 5 条关键教训。重点：脚本 `sys.exit(0 if stats["fail"] == 0 else 1)` 让 7/152 fail 看起来全失败、bash `output=$()` 静默截断 4-8 KB 上限、`status` vs `review_status` 两个 status 列、m3 评分对中文平台偏好（avg 1.3-1.5 vs Tavily 5.5-6.1）。触发：debug m3 任务"silent noop"、写 batch wrapper、对账 NULL 数、做 cron 任务 review。
- **池子完整性审计 + 3 个 2026-06-08 新增陷阱**（`references/topic-pool-integrity-audit-2026-06-08.md`）— 2026-06-08 新增。**"用户报告池子里又出现已制作完成的话题"的标准调查流程**：(1) 用 topic_id 交叉 PROJECT_REGISTRY.json vs pool.db 找"已交付但 status 漂移" (2) 用 title GROUP BY HAVING 找"跨 source 重复" (3) 用 status+review_status 双 GROUP BY 找"语义/生产两套状态机漂移"。**3 个新陷阱**：陷阱 24 采集脚本 topic_id 用 md5(title+source) 哈希 → INSERT OR IGNORE 失效 → 同 title 跨 source 产生 N 条；陷阱 25 任何项目交付完成时**没有任何代码回写 pool.db 的 status** → 已交付话题永远停在 selected/archived；陷阱 26 8:05 audit SQL 缺 `status='pending'` 过滤 → "已交付但 status=selected" 的话题被当成新话题重新审核。**完整 SQL 审计 5 步 recipe**（**Step 0 静默零入库 precheck** → topic_id 交叉验证 → 同 title 重复检测 → 两套 status 漂移 → 修复 + 一次性清理脚本模板）。**触发：用户报告"池子里又有老话题"、每月一次池子健康度巡检、改采集脚本的 topic_id 计算公式、改 regen_project_registry.py、改 audit_08x05 prompt SQL**。
- **静默零入库 pattern（2026-06-08 10:30 新增）**（`references/silent-zero-out-patterns-2026-06-08.md`）— 2026-06-08 10:30 新增。**P0 `in list_of_dict` 静默 bug**完整案例：item['title'] in flow1_related（list of dict）永远 False → flow1 入库永远 0 → 跑了 4+ 天没人发现。**4 个 type-mismatch 必死 pattern**（str in list_of_dict / str in list_of_list / str in dict / 集合类型错用）、**与陷阱 17（cron 静默无操作）的内外层关系**、**3 道硬保险**（type assert / counter sanity check / cron output db delta 验证）、**3 个误诊陷阱**（last_status=ok ≠ 业务健康 / "3 个流 0/1"模式被忽略 / 手动跑只看 exit code）。触发：采集脚本入库数 < 抓取期望、改完采集脚本 filter 逻辑后、debug 池子"突然没新内容"、调 m3 API 返回 list of dict 的处理。
- **角度判定脚本**（`scripts/judge_topics_angle.py`）— 2026-06-03 新增。可重跑脚本，--dry-run/--limit/--source/--min-corr 参数齐全，CLI 设计给 cron 调用。位置：`/home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py`
- **并行 LLM 批量处理：ThreadPoolExecutor 模式**（`references/parallel-llm-batch-processing.md`）— 2026-06-10 新增。**Phase 1 并行 API + Phase 2 串行写库**的二阶段模式。为什么选 5 个 worker、为什么二阶段不是边收边写、`future.result(timeout=130)` 必须 > curl --max-time、陷阱 5 条。触发：改 judge_topics_angle.py 主循环、设计新批量 LLM 调用脚本、遇到 39+ 条串行超时。
- **Freshness 硬过滤升级**（`references/freshness-hard-gate-2026-06-22.md`）— 2026-06-22 新增。4 层时效防线设计：推送 7天硬过滤/自动归档 >14天/Layer 3 旧闻增强。完整审计数据（804条话题分布、114条过期话题明细）。触发：用户报告过期新闻出现在推送、改推送 SQL 的 WHERE 过滤条件、调查 event_date 字段覆盖问题。

---


---
