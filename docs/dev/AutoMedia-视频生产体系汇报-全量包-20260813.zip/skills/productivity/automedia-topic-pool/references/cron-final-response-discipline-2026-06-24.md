## 陷阱 29：LLM-driven cron 的 final response 纪律（2026-06-24 实测）

**症状**：08:30 推送 cron job 跑完，agent 写了本地备份（summary 文件有完整 TOP3 数据），但 final response 输出的是「✅ 全流程完成。今日推送已就位」——没有推送正文。用户收到空内容。

**根因**：prompt 写的是「3.1 本地备份（先写，保底）」和「3.2 生成推送文本」，但 agent 写完 3.1 后把 3.2 理解为「把内容写进文件就够了」，final response 只输出了完成确认。hermes cron 投递的是 agent 的最后一条消息（无 tool_calls 的纯文本回复），之前的推送正文虽然存在但被最后一条收尾消息覆盖了。

**修法**（prompt 内新增约束）：
```markdown
**3.1 本地备份（先写，保底）**
...
- ⚠️ 关键纪律：写完备份文件后，你的 final response 必须直接输出推送正文（含 TOP3 完整数据+智能体推荐），不得再追加任何收尾消息（如「✅ 全流程完成」等）。推送正文即 final response。

## 重要规则
- ⚠️ 最终纪律：推送正文就是你的 final response。写完 3.1 备份后直接输出推送正文作为最终回复，不得追加任何收尾总结消息。
```

**预防**：写新 LLM-driven cron job prompt 时，必须在最后一步显式写死「你的 final response = X，不得追加任何收尾」。

**关联**：这是 LLM 的随机性（stochasticity）问题。同一天之前 3 次运行（6/21-6/23）都正常输出推送正文，只有今天 agent 多输出了一条收尾消息。硬约束比 agent 自觉更可靠。
