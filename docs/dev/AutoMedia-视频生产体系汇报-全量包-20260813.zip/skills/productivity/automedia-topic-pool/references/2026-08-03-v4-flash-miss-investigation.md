# 2026-08-03 DeepSeek-V4-Flash 正式版漏采根因调查

## 症状
用户问「最近有没有 DeepSeek-V4-Flash 正式版新闻」→ 查到 7-31 发布 → 查话题池 pool.db → **池子里没有这条**。用户追问「这么大的新闻为什么没捕捉到」。

## 结论
不是过滤逻辑误杀，是**采集管线在黄金窗口期整体失效**：
- 7-31(周五) 下午发布 → 8-1(周六) 早上是唯一能抓到热榜的窗口
- 8-1 采集 cron 零执行（调度器未运行）→ 8-2 11:33 补跑超时失败 → 8-3 恢复时三流全 miss

## 排查证据链（可复用）

### ① pool.db 每日入库量（先做这个，最便宜）
```sql
SELECT substr(created_at,1,10) d, COUNT(*), group_concat(source)
FROM topics WHERE created_at >= '2026-07-29' GROUP BY d ORDER BY d;
-- 结果：7-30:14条 | 7-31:15条 | 8-01:0条 | 8-02:0条 | 8-03:3条
-- 0 入库日 = 采集没跑（或全失败），是异常信号
```
再按天列出话题明细确认该事件确实不在：
```sql
SELECT title, source, heat_score, status FROM topics
WHERE substr(created_at,1,10)=? ORDER BY heat_score DESC;
```

### ② cron executions.db（判断「没跑」还是「跑了失败」）
```bash
python3 -c "import sqlite3,os; conn=sqlite3.connect(os.path.expanduser('~/.hermes/profiles/content/cron/executions.db')); print([r for r in conn.execute(\"SELECT job_id, started_at, status, substr(error,1,80) FROM executions WHERE started_at >= '2026-07-28' ORDER BY started_at\")])"
```
本次关键发现：
- 8-1：**全天无任何 job 记录**（调度器进程没存活）
- 8-2 11:33：所有 job 同时补跑（调度器重启特征）→ 采集 job `failed, Script timed out after 1800s`，无重试
- 8-3 08:00：正常 completed（但窗口已过）

### ③ cron/output/ 输出文件（肉眼最快）
```bash
ls -lat ~/.hermes/profiles/content/cron/output/ | grep 143d19e69a7c
# 7-30、7-31、8-03 有采集输出，8-01、8-02 没有 → 采集没产出
```

### ④ 采集日志流级分析（为什么恢复后还 miss）
读 `cron/output/143d19e69a7c_20260803_*.txt`：
- 流1 热榜：45 原始 → Layer2 4 条 → 信息密度 1 条（V4 Flash 已掉出 top15，剩「deepseek 定价回本」）
- 流2 Tavily：165 原始 → 信息密度**全灭 15 条**（返回全是内容农场/教程站；`--time-range day` 只搜 24h，8-2 的内容已过期）
- 流3 AIHOT：**API 只返回 2 条**（正常 30 条）——第三方精选源当天没收录 V4 Flash

## 根因（4 个系统漏洞）
1. **调度器无周末保障 + 无 catch-up 重试**：Hermes 进程周末未存活 → 8-1 完全漏采；8-2 补跑超时失败后没有重试，错过的采集不会自动补。
2. **watchdog 不检测 0 入库日**：09:30 健康检查在 8-1 也没跑；8-2 补跑时显示 completed，没有报警「8-1 采集缺失」。
3. **单窗口敏感设计**：Tavily `--time-range day` 错过一天=永久错过；热榜只取 top15（3 天后掉出）；AIHOT 过度依赖第三方精选。
4. **无重大事件跟进**：池子 7-19 有「V4 正式版即将发布」话题（archived），正式版发布后无机制验证预告话题后续/补采——「预告→发布」事件闭环是断的。

## 修复建议（2026-08-03 已实施：漏采补偿机制 v1）

**已实施：**
- **`catchup_collection.py`**（~/.hermes/profiles/content/scripts/ + AutoMedia/Scripts/ 双副本）：
  - ① 检测段：pool.db 近 7 天每日入库分布 → 0 入库日=漏采，<5 条=异常
  - ② 信号段 A：池子 archived「预告/即将发布」类话题 → 提取实体 → 定向搜 `<实体> 正式版 发布`（week-range）
  - ③ 信号段 B：通用实体表 × 动作词组合（截断 25 组）
  - ④ 候选报告：写 `cron/output/catchup_*.md`，不进池子自动流程
  - ⑤ `--apply N`：挑中候选写入池子正常 pending 流程（source='Tavily'，event_date 从正文提取）
  - **闭卷验证通过**：脚本无任何 V4 字样，通过「预告话题 DeepSeek V4 正式版即将发布 → 实体 DeepSeek → 定向搜索」自动挖出 6 条 V4 Flash 正式版报道并入库
- **`wdog_auto_retry.py` 增强**：detect_missing_days() 检测近 7 天 0 入库日/异常日 → 告警 + 提示补采命令

**设计要点（教训沉淀）：**
- 补偿**只追有信号的事件**（预告话题跟进 + 通用实体扫描），不做全量 7 天回扫（week-range 噪声大：内容农场/标签页/跨年旧闻会混入）
- 补偿话题**不进自动流程**（不判 angle、不进 8:30 推送），避免踩 judge_topics_angle source 白名单坑（B1），由人挑中后 --apply 转正
- 补偿时效现实化：耗时 30-60 分钟，赶不上当天 08:30 推送，价值是"不永久错过"而非"赶当日推送"
- 已知噪声：Tavily week 过滤不严格（可能返回 2025 年旧闻），同源多 URL 变体重复 → v2 需强化时间过滤 + 事件级去重

## 关键教训
- **0 入库日 = 采集没跑，不是过滤误杀**。大新闻漏采先查调度执行记录，再查过滤逻辑。
- 数据库里「有这个话题但 archived」≠「事件闭环完成」——「即将发布」类预告话题需要发布后的跟进机制。
- 采集管线对单次窗口（热榜 top15、Tavily 24h）高度敏感，重大事件（尤其下午发布）的黄金窗口是**下一个采集日早晨**。
