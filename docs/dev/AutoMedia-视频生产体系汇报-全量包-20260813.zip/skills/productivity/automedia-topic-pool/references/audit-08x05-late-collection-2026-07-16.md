# audit_08x05 晚采集边缘场景（2026-07-16 实测）

> 触发：08:00 热集脚本跑晚（实测 08:18 而非预期的 08:02），08:05 审核 job 在先采集合之前跑，首次查询 pending = 0 条。

## 现象

**2026-07-16 实操**：
- 本 job（audit_08x05）在 ~08:16 触发（调度 08:05，但有 `depends_on_grace_min=30`）
- 08:00 采集 job 同时在跑，~08:18 完成（`last_run_at: 2026-07-16T08:18:55`）
- 首次 DB 查询 `review_status='pending' AND status='pending'` → **0 条**
- 采集完成后重新查询 → **1 条 pending**
- 采集脚本跑了 ~18 分钟（非预期的 2-3 分钟），但仍在 30 分钟依赖宽限期内

## 正确应对步骤

当 `audit_08x05` 首次查询 pending 为 0 时：

1. **不要直接结束**。查采集 job 的完成时间：
   ```bash
   python3 -c "
   import json
   d = json.load(open('/home/renanzai/.hermes/profiles/content/cron/jobs.json'))
   for j in d.get('jobs', []):
       if '08:00' in j.get('name', '') or '143d19e69a7c' in j.get('id', ''):
           print(f'last_run_at: {j.get(\"last_run_at\")}')
           print(f'last_status: {j.get(\"last_status\")}')
   "
   ```

2. **如果采集刚完成**（last_run_at 距现在 < 5 分钟），重新查询 pool.db：
   ```sql
   SELECT COUNT(*) FROM topics 
   WHERE review_status = 'pending' AND status = 'pending'
   AND DATE(created_at) = DATE('now')
   ```

3. **如果再查仍有数据** → 正常执行 Layer 3 审核

4. **如果再查仍为 0** → 确认采集确实没产出（而不是时序错位），输出「今日无待审核话题」

## 标题 SEO 关键词伪影

**2026-07-16 实测**：163.com 文章在 pool.db 中的标题为：
```
Xmax AI 发布 X2.0，把视频变成可以「玩」的界面|xmax|命令提示符|手机_手机网易网
```
竖线分隔的内容来自 HTML `<title>` 标签中的 SEO 关键词堆砌，**不是文章实际标题**。

### Layer 3 审核规则（针对此模式）

| 信号 | 不是 reject 理由 | 是 reject 理由 |
|------|-----------------|---------------|
| 标题含 `\|关键词\|关键词\|` 竖线分隔 SEO 词 | ❌ 单一竖线模式 → HTML title 抓取伪影 | ✅ 全文为关键词堆砌、无实际内容 |
| source_url 来自正规媒体（163/36kr/jiemian 等） | 必须 web_extract 验证正文 | title 脏 ≠ 内容脏 |
| 标题长、含多个分隔符 | 先看正文再决定 | — |

**处理原则**：**以 source_url 的 web_extract 结果为准，不以 pool.db 中的 raw title 为唯一判断依据。**

## 近期采集耗时波动

| 日期 | 08:00 采集耗时 | 实际完成时间 |
|------|--------------|-------------|
| 历史基线 | 2-3 分钟 | 08:02-08:03 |
| 2026-07-15 | — | 08:13 (last_run_at) |
| 2026-07-16 | ~18 分钟 | 08:18 (last_run_at) |

采集耗时波动 >10 分钟时，08:05 audit 应预期可能找不到当天数据，需等待后重试。

## 相关 reference

- `cron-timing-design.md` — 基线耗时 / 依赖关系设计
- `cron-silent-noop-patterns.md` — 静默无操作 4 大类（类别 D1：任务依赖链断了）
- `topic-pool-audit-20260601.md` — content farm 判断逻辑 / 标题正则
