# 手动跑 m3 任务的标准流程（2026-06-06 落地）

> **触发条件**：用户说"手动跑 m3 任务"/"清一下 NULL"/"补跑角度判定"，或 cron 任务失败需要补跑。
> **核心目的**：在不破坏 cron 状态的情况下，**手动**触发 `judge_topics_angle.py` 并验证结果。
> **关键陷阱**：详见文末"陷阱 17（--limit 200 神话）"和"陷阱 18（background exit_code 占位符）"。

---

## 标准 6 步流程

### 1. 查 cron 任务 ID 和脚本路径

```bash
cat cron/jobs.json | python3 -c "
import json, sys
d = json.load(sys.stdin)
for j in d.get('jobs', []):
    if 'm3' in j.get('name','').lower() or 'angle' in j.get('name','').lower():
        print(j['id'], '|', j['name'], '|', j.get('script',''))
"
```

**输出示例**（2026-06-06 实测）：
```
judge_angles_08x10 | AutoMedia 08:10 m3 角度分判定（8:30 推送前） | judge_angles_cron.sh
judge_angles_12x00 | AutoMedia 12:00 m3 角度分判定（清历史 NULL + 兜底新进库） | judge_angles_cron.sh
judge_angles_16x00 | AutoMedia 16:00 m3 角度分判定（清历史 NULL + 兜底新进库） | judge_angles_cron.sh
```

### 2. 查当前 NULL 数（必查 baseline）

```bash
python3 -c "
import sqlite3
c = sqlite3.connect('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db')
n = c.execute('SELECT COUNT(*) FROM topics WHERE angle_score IS NULL').fetchone()[0]
total = c.execute('SELECT COUNT(*) FROM topics').fetchone()[0]
print(f'NULL: {n} / total: {total}')
"
```

**输出示例**（2026-06-06 实测）：
```
NULL: 316 / total: 615
```

### 3. 启动后台任务（设 30 分钟 timeout，tee 留 log）

```python
terminal(
    background=True,
    notify_on_complete=True,
    timeout=2000,  # 33 分钟
    command="""cd /home/renanzai/.hermes/profiles/content && \
        HERMES_CRON_SCRIPT_TIMEOUT=1800 \
        /home/renanzai/.hermes/hermes-agent/venv/bin/python \
        scripts/judge_topics_angle.py --limit 200 2>&1 | tee /tmp/m3_run.log""",
)
```

**返回**（陷阱 18 关键）：
```json
{
  "session_id": "proc_3696c0d45d8f",
  "pid": 546213,
  "exit_code": 0,    // ← 假的占位符！进程还在跑
  "status": "starting",
  "uptime_seconds": 0
}
```

### 4. 第一动作：验证真启动了（陷阱 18 必看）

```python
process(action='poll', session_id='proc_3696c0d45d8f', timeout=3)
```

**真实 status**：
```json
{
  "session_id": "proc_3696c0d45d8f",
  "command": "...",
  "status": "running",
  "pid": 546213,
  "uptime_seconds": 5,
  "output_preview": ""
}
```

**判断**：`status='running'` + `uptime_seconds > 0` = 进程真在跑。`exit_code: 0` 永远是占位符。

### 5. 等完成通知

**两种方式二选一**：

#### 方式 A：等系统通知（推荐）
- `notify_on_complete=true` 已设 → 完成后系统会自动通知（带 exit code + 完成时间）
- 你可以同时干别的活，不阻塞

#### 方式 B：主动 wait
```python
process(action='wait', session_id='proc_3696c0d45d8f', timeout=1800)
```

### 6. 验证实际处理（必查 delta，不看 --limit）

```python
python3 -c "
import sqlite3
c = sqlite3.connect('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db')
n = c.execute('SELECT COUNT(*) FROM topics WHERE angle_score IS NULL').fetchone()[0]
total = c.execute('SELECT COUNT(*) FROM topics').fetchone()[0]
new = c.execute(\"SELECT COUNT(*) FROM topics WHERE angle_score IS NOT NULL AND angle_judged_at >= '2026-06-06 13:00:00'\").fetchone()[0]
high = c.execute('SELECT COUNT(*) FROM topics WHERE angle_score >= 7').fetchone()[0]
print(f'NULL: {n} / total: {total} / new_judged: {new} / high(>=7): {high}')
"
```

**输出示例**（2026-06-06 实测）：
```
NULL: 276 / total: 615 / new_judged: 41 / high(>=7): 75
```

**delta 解读**：
- 316 → 276 = **40 条** + 1 fail（JSONDecode）= 41 processed
- **不是 `--limit 200` 字面意义的 200 条**（陷阱 17）
- 高分（≥7）从 57 → 75（+18 条新 7+ 分）

---

## 关键参数说明

| 参数 | 必填 | 值 | 说明 |
|------|------|-----|------|
| `HERMES_CRON_SCRIPT_TIMEOUT` | ✅ | `1800`（30 min）| 环境变量，m3 任务必设（默认 300s 不够）|
| `timeout` (terminal) | ✅ | `2000`（33 min）| background 模式下的最大允许运行时间 |
| `notify_on_complete` | ✅ | `true` | 完成后系统通知（不等也可知结果）|
| `--limit 200` | ⚠️ | 字面值 ≠ 实际处理 | 详见陷阱 17，**永远别用 --limit 判断耗时** |
| `tee /tmp/...log` | ✅ | 自定义 | 留 log 备查（`process(action='log')` 也可）|

---

## 反模式（禁止）

- ❌ **前台跑** `python3 judge_topics_angle.py` —— 30+ 分钟会撞 terminal timeout
- ❌ **不查 baseline** 就跑 —— 跑完不知道清了多少
- ❌ **不查 delta** 就报告"跑完了" —— 可能 exit 0 但实际没处理（陷阱 18）
- ❌ **不设 HERMES_CRON_SCRIPT_TIMEOUT** —— 进程会被 scheduler SIGTERM（即使是手动跑）
- ❌ **用 `--limit` 字面值预估耗时** —— 41 条 ≠ 200 条（陷阱 17）
- ❌ **看到 exit_code: 0 就报告完成** —— 必须 poll 拿真实 status

---

## 与 cron 自动跑的区别

| 维度 | cron 自动 | 手动补跑 |
|---|---|---|
| 触发 | jobs.json schedule | `terminal(background=true, ...)` |
| wrapper | `judge_angles_cron.sh`（去 --limit 参数）| 直接调 python 即可（不用 wrapper）|
| timeout 来源 | scheduler 读 `job.script_timeout` | 环境变量 `HERMES_CRON_SCRIPT_TIMEOUT` |
| 跑完状态 | jobs.json 标 `last_status=ok` + next_run_at 推进 | 不动 jobs.json，下次 cron 仍按 schedule 跑 |
| 失败重试 | scheduler 自动 + watchdog 兜底 | 手动重跑 |

**手动跑完不写 jobs.json**——下次 cron 自然跑就行。如果你想"本次手动跑后跳过下一次 cron"，需要 `cronjob action='update'` 临时改 next_run_at（本 skill 不展开）。

---

## 实测耗时基线（2026-06-06 多轮）

| 任务 | 实际处理 | 耗时 | 速度 |
|------|---------|------|------|
| `--limit 1` | 1 | 37.9s | 37.9 s/条 |
| `--limit 200`（实际 41）| 41 | 1273.2s ≈ 21 min | 31.0 s/条 |
| 推算 100 条 | 100 | ~50 min | - |
| 推算 200 条 | 200 | ~100 min | - |
| 推算 316 条（清空）| 316 | ~160 min ≈ 2.6 h | - |

**结论**：
- 清 316 条 NULL 需 **~2.6 小时/手动跑一次**
- 或等 3 个 m3 cron（8:10/12:00/16:00）每日累积 3×41=123 条跑 **3 天**
- 改 judge_topics_angle.py 内部 SQL `LIMIT 200 → LIMIT 1000`（先备份 + 验证）可一次清更多

---

## 陷阱 17：`--limit N` 不等于处理 N 条

**症状**：
- 跑 `python3 judge_topics_angle.py --limit 200` 期望清 200 条 NULL
- 实际只处理 **41 条**（log 显示 `[22/41]` 到 `[41/41]`，加 1-21 共 41）
- pool.db 角度分 NOT NULL 只 +40（不是 +200）
- 任务跑了 1273s ≈ 21 分钟就退出了

**根因**（实测 2026-06-06）：脚本的内部 SQL 限制（可能是 `LIMIT 200` 仅是"尝试取 200 条 NULL"，但实际 SELECT 受其他 WHERE 条件/子查询限制），**不是** argparse `--limit 200` 字面意义的"处理 200 条"。

**实测基线**：
| --limit | 实际处理 | 耗时 | pool.db NOT NULL 增量 |
|---|---|---|---|
| `--limit 1` | 1 | 37.9s | +1 |
| `--limit 200` | **41** | 1273.2s | +40（1 fail JSONDecode）|

**反推**：~31s/record（1273.2s ÷ 41 条）。**316 条 NULL 全清需要 316 × 31s ≈ 2.6 小时**。

**预防（永久规则）**：
- ❌ **不要相信 `--limit` 字面值**判断"会处理多少条"
- ✅ **必查 pool.db delta**（跑前查 `WHERE angle_score IS NULL` 跑完再查）
- ✅ **必查 log 最后一行**（`【完成】N ok / M fail`）确认实际处理数
- ✅ **预估耗时 = NULL 数 × 31s + 启动 30s**
- ✅ **200 条 `--limit` 实际处理 41 条**=**只能清 ~40 条**/次 → 3 个 m3 cron 一日 3 × 41 = 123 条 < 316 → 至少 3 天才能清空
- ✅ 想清更快：改 judge_topics_angle.py 内部 SQL `LIMIT`（先备份 + 验证）；或并行多 session 跑（注意 session_lock）

---

## 陷阱 18：`terminal(background=true)` 立即返回的 `exit_code: 0` 是占位符

**症状**：
```json
{
  "session_id": "proc_3696c0d45d8f",
  "pid": 546213,
  "exit_code": 0,           // ← 假的！进程还在跑
  "status": "running",       // ← 真的
  "uptime_seconds": 0
}
```

**根因**：Hermes `terminal(background=true)` 设计是"启动后台 + 立即返回 session_id"，返回 JSON 中的 `exit_code` 是 **placeholder 0**，不是真实状态。真实状态必须用 `process(action='poll')` 查。

**实测案例（2026-06-06 m3 跑）**：
- 启动：`background=true, notify_on_complete=true, timeout=2000`
- 立即看到：`exit_code: 0, status: "running", uptime_seconds: 0/5/...`
- 起初我以为进程"秒退成功"——差点误判
- 实际：进程还在跑，21 分钟后才真的 exit 0

**预防（永久规则）**：
- ✅ 启动后台任务后**第一动作**必 `process(action='poll', timeout=3)` 拿真实 status
- ✅ `uptime_seconds > 0` + `status='running'` = 进程真在跑
- ❌ 不要看 `exit_code: 0` 就以为"任务完了"——那是占位符
- ✅ 长跑任务必配 `notify_on_complete=true` —— 真的完成时会有一次通知
- ✅ 配 `timeout=N`（秒）—— background 模式下 timeout 是**最大允许运行时间**，超时后系统主动 SIGTERM（不是 exit_code=0 的占位符）

**完整工具行为**：
- `terminal(background=true, ...)`：启动 + 立即返回 + exit_code 占位
- `process(action='poll', ...)`：非阻塞查状态
- `process(action='wait', ...)`：阻塞等到完成或 timeout
- `process(action='log', ...)`：拿完整输出（可分页）
- `process(action='kill', ...)`：主动 SIGTERM

**为什么这个坑能烧人**：
- 用户问"任务跑了吗"——你看 exit_code=0 说"跑了"——实际没跑 → 用户收不到推送
- 修复方法：永远 `process(action='poll')` 一次拿真实 status 再报告

---

## 验证脚本（可直接复用）

`scripts/verify_m3_run.py`（建议新建）：

```python
#!/usr/bin/env python3
"""验证 m3 任务跑完后的 pool.db 状态。usage: python3 verify_m3_run.py [since_ts]"""
import sqlite3, sys
from datetime import datetime

DB = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db"
since = sys.argv[1] if len(sys.argv) > 1 else "2026-06-06 13:00:00"

c = sqlite3.connect(DB)
n_null = c.execute("SELECT COUNT(*) FROM topics WHERE angle_score IS NULL").fetchone()[0]
n_total = c.execute("SELECT COUNT(*) FROM topics").fetchone()[0]
n_new = c.execute(
    f"SELECT COUNT(*) FROM topics WHERE angle_score IS NOT NULL AND angle_judged_at >= ?",
    (since,)
).fetchone()[0]
n_high = c.execute("SELECT COUNT(*) FROM topics WHERE angle_score >= 7").fetchone()[0]

print(f"NULL: {n_null} / total: {n_total} / new(>=since): {n_new} / high(>=7): {n_high}")

# TOP 5
print("\n=== TOP5 by angle_score ===")
for row in c.execute(
    "SELECT title, angle_score FROM topics WHERE angle_score IS NOT NULL ORDER BY angle_score DESC LIMIT 5"
):
    print(f"  {row[1]:>4.1f} | {row[0][:60]}")
```

---

## 改动登记

- 2026-06-06 落地本文档（首次记录手动跑 m3 任务的标准流程）
- 备份：`/home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py.bak.20260606_103811`（commit in loop + SIGTERM handler 已在之前落地）
- 触发场景：今天 6-06 用户问"手动跑 m3 任务"——我先查 job IDs、查 baseline、设 timeout 1800、background + notify、tee log、poll 验证、查 delta 6 步走完，确认 41/200 处理 → 报告用户
- 修复后预期：任何"手动跑 m3 任务"请求都按这 6 步走，30 分钟内给准确报告
