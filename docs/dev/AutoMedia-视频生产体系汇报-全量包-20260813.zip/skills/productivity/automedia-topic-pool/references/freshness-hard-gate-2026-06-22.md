# Freshness 硬过滤升级（2026-06-22）

## 问题
`event_date` 字段在 `judge_topics_angle.py` 中正确输出，写入 pool.db，
但 **8:30 推送 SQL 的 WHERE 子句没有引用它**。导致事件已发生 21 天的
"DeepSeek将发布V4"（event_date=2026-06-01）仍出现在推送 TOP3 中。

## 修复（4 层时效防线）

| 层 | 机制 | 位置 |
|----|------|------|
| 1 | freshness_score 衰减（同前） | freshness_maintenance.py (07:30) |
| 2 | **推送层 7天硬过滤** — `COALESCE(event_date, created_at)` <= 7天 | 8:30 push SQL (`jobs.json` → `7671da210b69`) |
| 3 | **自动归档 >14天** — 事件超过14天自动 status→archived | freshness_maintenance.py (07:30) |
| 4 | **旧闻翻炒审核增强** — event_date 参考 | audit_08x05 prompt |

## 类级别教训：陷阱 29 — 字段存在 ≠ 下游 SQL 在用

新增任何字段后，必须 audit 所有读该表/该对象的 SQL 和代码路径：
```bash
grep -rn "SELECT.*FROM topics" \
  ~/.hermes/profiles/content/cron/jobs.json \
  ~/.hermes/profiles/content/skills/ --include="*.md"
```

## 审计数据

- 可推送话题（pending+approved+angle≥7）：144 条
- 其中事件超过 7 天（会被新过滤拦截）：117 条
- 超过 14 天（会被自动归档）：63 条
- event_date 填充率：5/804（0.6%）→ **已知缺口，待 backfill**

## 触发
- 用户报告过期新闻出现在推送
- 改推送 SQL 的 WHERE 过滤条件
- 调查 event_date 字段覆盖问题
