# 8:00 热点采集任务时区错乱事故（2026-06-06 实测）

> **触发场景**：cron 任务实际跑的时间 ≠ 预期时间（早 8 跑在下午 4 / 凌晨 0 / 其他时区）/ 下次运行时间算错。
> **症状**：用户问"8:05 后没看到任务触发"——实际 8:00 任务在 CST 16:00 跑了（用户早上根本看不到）/ 3 个 m3 任务 next_run_at 一直是 null。

---

## 事故经过

**2026-06-06 08:42** 用户报告："8:05 后的任务我都没看见触发"。

排查发现 4 个独立 bug 叠加：
1. **8:30 任务 prompt session_lock 参数错**（`--timeout 5`）→ argparse 报错 → 静默退出 [SILENT]（主因）
2. **3 个 m3 角度分判定任务从未排上**（next_run_at=null）→ log 显示反复"recovering cron run"
3. **3 个 m3 任务 script 字段带参数**（`judge_topics_angle.py --limit 200`）→ "Script not found"（独立子坑）
4. **8:00 热点采集任务时区错乱** → 跑在 CST 16:00 不是 8:00（本文件主题）

## 8:00 时区 bug 详解

### 症状
- 8:00 任务 `last_run_at: "2026-06-05T16:03:04+08:00"` = **CST 16:03**（昨天下午 4 点跑）
- 8:00 任务 `next_run_at: "2026-06-06T16:00:00+08:00"` = **CST 16:00**（今天下午 4 点）
- 8:00 任务的 output 目录 mtime = **Jun 5 16:03**（昨天 16 点跑过）
- 对比 8:05 任务 last_run_at = "2026-06-06T08:06:08"（今天 8:06 跑）→ **其他任务正常**

### 根因（3 层）

**第 1 层：hermes-time fallback 时区不稳定**
- `~/.hermes/profiles/content/config.yaml` 里 `timezone: ''`（空字符串）
- `hermes_time.get_timezone()` 返回 None → `now()` 走 `datetime.now().astimezone()` fallback
- 系统时区是 `Asia/Shanghai`（/etc/timezone 验证）→ 大多数时候返回 CST

**第 2层：8:00 任务上次 advance_next_run 时 hermes-time 返回了 UTC**
- `hermes-agent/cron/jobs.py:983 advance_next_run()`：
  ```python
  now = _hermes_now().isoformat()  # aware datetime 含 +08:00
  new_next = compute_next_run(job["schedule"], now)
  ```
- 当 hermes-time 返回 **UTC**（如 `2026-06-05T16:03:04+00:00`）时：
  - croniter 拿这个 aware UTC 16:03 当 base
  - 算 `"0 8 * * *"` 下一个 = UTC 8:00 → `2026-06-06T08:00:00+00:00`
  - 存到 jobs.json 时**保留 +00:00 tz 标记** = UTC 8:00
  - 但 jobs.json 实际显示 `2026-06-06T16:00:00+08:00`（+08:00 标记）→ 实际跑在 **CST 16:00**

**第 3 层：scheduler 调度时按 CST 8:00 触发不了**
- jobs.json 里的 next_run_at 是 UTC 8:00，scheduler 内部 `get_due_jobs()` 比较 aware datetimes
- 8:00 CST = 0:00 UTC → scheduler 看到 next = 16:00 CST = 8:00 UTC
- 当前时间 8:00 CST = 0:00 UTC → next 8:00 UTC > 当前 0:00 UTC → **不触发**
- 等到 16:00 CST = 8:00 UTC → next == 当前 → **触发**（但用户不知道）

**实测证据**：
```bash
# 模拟 hermes-time 当时返回 UTC
base = '2026-06-05T16:03:04.266968+00:00'
from croniter import croniter
nxt = croniter('0 8 * * *', datetime.fromisoformat(base)).get_next(datetime)
# → 2026-06-06 08:00:00+00:00 (UTC)
# 存进 jobs.json 标 +08:00 = 实际跑在 CST 16:00
```

**对比 croniter 跑 CST aware base**（正确路径）：
```bash
base = '2026-06-05T16:03:04.266968+08:00'  # CST
nxt = croniter('0 8 * * *', datetime.fromisoformat(base)).get_next(datetime)
# → 2026-06-06 08:00:00+08:00 (CST) ✅
```

### 为什么只有 8:00 任务错乱（其他任务正常）？

- 8:00 任务 `created_at: 2026-05-11T19:56:07+08:00`（5 月 11 日创建）→ 当时 hermes-time 可能不稳
- 其他任务（8:05 audit_08x05、8:30 推送、7:30 维护、9:30 watchdog）都是后来创建 → 当时 hermes-time 已稳
- **关键事实**：watchdog 9:30 任务的 last_run_at 是 "2026-06-05T09:32:04" = **CST 9:32**（对的）—— 说明**当前 hermes-time 已返回 CST**，不会再产生新错乱

## 修法

**短期修复（2026-06-06 已做）**：
```bash
# 直接 patch jobs.json 把 next_run_at 改成正确的 CST 时间
# 8:00: '2026-06-06T16:00:00+08:00' → '2026-06-07T08:00:00+08:00'
# 3 个 m3: None → 06-07 08:10/12:00/16:00
```

**根本预防**：
1. **config.yaml 强制锁时区**（`config.yaml` 是 protected file，需手动用 hermes config 命令改）：
   ```yaml
   timezone: 'Asia/Shanghai'  # 不写空，让 hermes-time 总返回 CST
   ```
2. **写新 cron job 必查 next_run_at**（首次创建后立刻看 1 次）：
   ```bash
   /home/renanzai/.hermes/hermes-agent/venv/bin/hermes cron list
   # 找新 job 的 next_run_at：应该是 CST 正确时间
   # 错位 = UTC 解释 → 立刻 patch
   ```
3. **job 创建后跑 1 次验证**（`hermes cron run <job_id>`）：
   - 跑完立刻 `list` 看 last_run_at 是不是预期时间
   - 不是预期时间 = 时区 bug，立刻排查
4. **升级 hermes-agent 必看 release notes**（fix timezone fallback 是高频 PR）

## 相关源码位置

- `hermes_time.py:78-89` get_timezone() — fallback 路径
- `hermes_time.py:91-102` now() — fallback 路径
- `cron/jobs.py:376-419` compute_next_run() — 接受 aware datetime 当 base
- `cron/jobs.py:983-1003` advance_next_run() — 调 compute_next_run(now)
- `cron/jobs.py:1011-1111` get_due_jobs() — 比较 next_run_at 与当前时间

## 完整内容索引

- SKILL.md 陷阱 13（session_lock `--wait-timeout` 写错）
- SKILL.md 陷阱 14（300s timeout 不够长）
- SKILL.md 陷阱 15（script 字段不接受参数）
- `references/cron-deployment-pitfalls.md` 坑 1.5（script 参数 + wrapper 修法）
- `references/cron-0830-push-workflow.md` 步骤 1（session_lock 正确用法）
