# Prompt 长度 → reasoning_content 耗尽 max_tokens 陷阱

## 症状

角度判定脚本（`judge_topics_angle.py`）执行时，LLM 返回 `finish_reason: length` 且 `content` 为空字符串。

```
finish_reason: length
content 长度: 0
原始返回: choices[0].message.content = ""
但 choices[0].message.reasoning_content 非空（被模型内部思考占用）
```

## 根因

该 LLM 提供方（opencode-go / DeepSeek-v4-flash）支持 `reasoning_content`（内部思考token）。
当 prompt 长度增加时，模型进行更多内部思考，消耗了 `max_tokens` 配额。

对于 judge_topics_angle.py 这类要求 JSON 结构化输出的 prompt：
- 模型需要先推理（消耗 reasoning_content tokens）
- 再生成 JSON（消耗 content tokens）
- 两者共享 `max_tokens` 预算
- 当 prompt 变长时，推理阶段消耗更多 tokens → content 阶段配额不足 → `finish_reason: length` + 空 content

## 首次发现：2026-06-12

在 Layer 2.5 angle 判定 prompt v2 → v3 升级时（新增 `event_date` 字段 + 说明 + 更新 few-shot 示例），
prompt 从约 2200 chars 增长到约 2850 chars（+600 chars）。

- `max_tokens=1500` 时：`finish_reason: length`，content 为空，11/13 条失败
- `max_tokens=3000` 时：`finish_reason: stop`，content 正常，10/10 条成功

## 修复

```python
# 在 judge_topics_angle.py 中：
"max_tokens": 1500   # ❌ 旧值 - prompt 较短时够用
"max_tokens": 3000   # ✅ 新值 - 给 reasoning_content 留出空间
```

## 预防（永久规则）

1. **任何 prompt 长度增加后，先单独测试 API 返回**（单个 title，看 `finish_reason`）
2. **max_tokens 设 3000 作为安全基线**（DeepSeek-v4-flash 下已验证）
3. **不要只依赖"大部分返回正常"来判定 max_tokens 够用**——reasing_content 消耗与 prompt 长度非线性相关
4. 如果未来 prompt 进一步增长（如加更多 few-shot），先做单条 API 测试确认 max_tokens 仍够

## 排查步骤

```bash
# 1. 单条测试
python3 -c "
import json, subprocess
payload = json.dumps({
    'model': 'deepseek-v4-flash',
    'messages': [{'role': 'user', 'content': prompt_filled}],
    'temperature': 0.1,
    'max_tokens': 1500,
})
cmd = ['curl', '-s', '--max-time', '120', '-X', 'POST',
       '-H', 'Content-Type: application/json',
       '-H', f'Authorization: Bearer {API_KEY}',
       '-d', payload,
       f'{BASE_URL}/chat/completions']
r = subprocess.run(cmd, capture_output=True, text=True, timeout=130)
data = json.loads(r.stdout)
print('finish_reason:', data['choices'][0].get('finish_reason'))
print('content length:', len(data['choices'][0]['message'].get('content', '')))
"

# 2. finish_reason='length' → 增加 max_tokens
# 3. content 不为空 → 解析 JSON 验证 event_date 等新字段
```

## 触发条件

- 改 judge_topics_angle.py 的 PROMPT 常量（加新字段、加 few-shot、加规则说明）
- 改任何类似 prompt（要求 JSON 结构化输出、模型支持 reasoning_content）
- 怀疑"为什么角度判定突然失败率高"
