# 长跑 Cron 脚本硬化：commit in loop + SIGTERM handler

> **触发条件**：设计/改 cron 脚本类（`no_agent=True`）任务，预期耗时 > 5 分钟，或调外部 API 次数 ≥ 50 次。
> **核心目的**：scheduler 默认 300s timeout 杀进程时**已处理结果不丢**。
> **落地时间**：2026-06-06（judge_topics_angle.py）

## 问题背景（2026-06-06 实测）

m3 角度判定（`judge_topics_angle.py --limit 200`）的实际耗时基线：

| 任务 | 实测耗时 | 300s 是否够 |
|------|---------|------------|
| `auto_media_hot_collection_v3` (08:00 采集) | 2-4 min | ✅ 够 |
| `judge_topics_angle.py --limit 200` | **8-15 min** | ❌ 严重不够 |
| `audit_08x05` (LLM agent) | 1-3 min | ✅ 够 |

**为什么这么慢**：
- 每次 m3 API 调用要 1-2 秒
- 200 条 × 1-2 秒 = 200-400 秒（3-7 分钟纯网络）
- 慢启动 + retry 3 次 + 慢启动 = 实际 **8-15 分钟**

**scheduler 行为**（实测 hermes-agent/cron/scheduler.py）：
- 300s 后 SIGTERM wrapper.sh
- wrapper 退出，但 **Python 子进程变孤儿**继续跑（exec 的 bash 已经把 PID 给 Python）
- output 写 `Script timed out after 300s: .../judge_angles_cron.sh`
- jobs.json 标 `last_status=error`，next_run_at 推到下个周期
- 孤儿 Python 进程继续跑但失去 cron 控制 → 下次 tick 看到还在跑就再触发 → **重复跑**

**严重后果**：
- 30 条已处理结果**全部丢失**（没 commit）
- 下次 cron 跑又从头开始，浪费 API 调用
- pool.db 出现"已处理但没 commit"的中间状态不可见

## 修复方案（2 件套，2026-06-06 落地）

### 改动 1：commit in loop（每 20 条 commit 一次）

**位置**：`judge_topics_angle.py` 进度 print 处（line 325-329 附近）

**diff**：
```python
# ❌ 原始：只在最后 commit
for i, r in enumerate(pending, 1):
    parsed, err = call_m3(...)
    # 写入当前条到 con
    if i % 20 == 0 or i == len(pending):
        elapsed = time.time() - start
        rate = i / elapsed
        eta = (len(pending) - i) / rate if rate > 0 else 0
        print(f"  [进度] {i}/{len(pending)} | ... | ETA {eta:.0f}s", flush=True)
# 最后才 con.commit()  ← 杀进程时这行到不了

# ✅ 修复：每 20 条 commit
for i, r in enumerate(pending, 1):
    parsed, err = call_m3(...)
    # 写入当前条到 con
    if i % 20 == 0 or i == len(pending):
        con.commit()  # 2026-06-06 P0：每 20 条 commit 一次，防止 SIGTERM/scheduler timeout 丢数据
        elapsed = time.time() - start
        ...
        print(f"  [进度] {i}/{len(pending)} | ... | committed", flush=True)
```

**为什么是 20 条**：
- 20 条 m3 API = 20-40 秒，远小于 300s
- commit 开销可忽略（sqlite 本地写）
- 折中：commit 太频繁（每 5 条）浪费 I/O；太少（每 50 条）单次 commit 量太大

### 改动 2：SIGTERM handler（杀进程时先 commit 再退出）

**位置**：`judge_topics_angle.py` `main()` 函数 `con = sqlite3.connect(DB)` 之后

**diff**：
```python
import signal  # 顶部 imports 加

# === SIGTERM handler: scheduler 超时杀进程时先 commit 再退出（2026-06-06 P0 防丢）===
# 不加这个，300s timeout 杀进程时循环里已处理的 N 条全丢
def _sigterm_handler(signum, frame):
    try:
        con.commit()
        print(f"\n[signal] SIGTERM received, committed before exit", file=sys.stderr, flush=True)
    except Exception as e:
        print(f"\n[signal] SIGTERM commit failed: {e}", file=sys.stderr, flush=True)
    sys.exit(0)
signal.signal(signal.SIGTERM, _sigterm_handler)
# SIGINT (Ctrl+C) 也走同一路径
signal.signal(signal.SIGINT, _sigterm_handler)
```

**关键设计点**：
- **closure 访问 con**：handler 是 nested function，能捕获外层的 con 局部变量
- **try/except 包 con.commit()**：DB 可能在 commit 时已被 close 或损坏，不抛异常给 scheduler
- **stderr 输出 + flush=True**：scheduler 日志能立即看到，避免 [SILENT] 假象
- **sys.exit(0) 而非 1**：干净退出，scheduler 标 exit 0 = 处理完成（虽然中途被打断）
- **同时处理 SIGINT**：Ctrl+C / SIGTERM 都走同一逻辑，调试方便

**为什么是 0 而非错误码**：
- 进程被打断是**外部原因**（scheduler timeout），不是脚本 bug
- exit 0 表示"已处理到我能处理的程度，剩余的我接受被放弃"
- exit 1 会触发 jobs.json 标 `last_status=error` + 用户收到告警，**误报**

## 测试方法（2026-06-06 实测，2 步验证）

### 测试 1：SIGTERM handler 触发

```bash
# 后台启动 1 条 m3 任务
python3 judge_topics_angle.py --limit 1 &
PID=$!

# 等 2 秒（m3 API 慢启动还没返回）
sleep 2

# 发 SIGTERM
kill -TERM $PID

# 等待进程退出
wait $PID
echo "exit code: $?"  # 应该是 0

# 看 stderr 输出
# 应该看到: [signal] SIGTERM received, committed before exit
```

**预期结果**：
- exit code = 0
- stderr 含 `[signal] SIGTERM received, committed before exit`
- jobs.json 不会被改动（这个测试不通过 cron）

### 测试 2：正常 commit 持久化

```bash
# 跑 1 条 m3 任务，不杀，让它跑完
python3 judge_topics_angle.py --limit 1
# 实际耗时 30-40 秒

# 看 pool.db 角度分是否增加
sqlite3 /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db \
  "SELECT COUNT(*) FROM topics WHERE angle_score IS NOT NULL"
# 应该比之前多 1
```

**预期结果**：
- exit code = 0
- 进度行含 `| committed` 标记
- 完成后行有 `【完成】1 ok / 0 fail`
- pool.db 角度分 NOT NULL 数量 +1

## 实施检查清单

新写 cron 脚本类（`no_agent=True`）任务时，**先**过这个清单：

- [ ] **预估耗时**：用 `--dry-run` 模式跑一遍测基线
- [ ] **> 300s 吗？**
  - 否：直接用 cron 默认 300s
  - 是：**必加** commit in loop + SIGTERM handler
- [ ] **commit 频率**：每 20 条（或按 `limit / 15` 算）
- [ ] **handler 覆盖**：SIGTERM + SIGINT（Ctrl+C）
- [ ] **con.commit() 包 try/except**：避免 DB 异常时再抛
- [ ] **stderr 标记**：`[signal] SIGTERM received, committed before exit`（带 flush=True）
- [ ] **exit 0** 而非 1（被打断是外部原因，不算脚本错）
- [ ] **测试 1 + 测试 2 都过**：SIGTERM 触发 + 正常 commit 持久化

## 相关陷阱

- **陷阱 14**（scheduler 300s timeout 杀进程）：本文件是这个陷阱的**代码级修法**
- **陷阱 15**（script 字段不支持参数）：commit in loop + SIGTERM handler 是 Python 代码**写在脚本里**，不通过 script 字段传参数
- **陷阱 9**（jobs sequential + at-most-once）：commit in loop + 孤儿进程问题结合，可能导致**重复跑**——改 m3 脚本后仍要监控孤儿进程

## 待改进（后续）

- [ ] **checkpoint 文件**：在 /tmp 写 `judge_topics_angle_<date>.checkpoint`，记录已处理 topic_id → 下次启动跳过。**目前不实现**（commit 已处理的在 DB 里，下次 SQL `WHERE angle_score IS NULL` 自然跳过）
- [ ] **scheduler 默认 timeout 改 1800s**（影响所有 profile，不推荐）
- [ ] **wrapper 脚本捕获 SIGTERM 并 kill Python 子进程**（目前 wrapper 用 `exec python`，wrapper 死了 Python 变孤儿——可以改 wrapper 显式 `kill -TERM $PYTHON_PID` 后 `wait`）

## 实际效果（2026-06-06 实测，多轮）

- 改前：m3 任务 8:10 跑 → 300s timeout 杀 → 30 条已处理全部丢失 → 9:00 用户仍问"为什么没触发"
- 改后：m3 任务 8:10 跑 → 300s timeout 杀 → handler commit 30 条 → 12:00 续跑剩余 → 16:00 再续 → 累积处理不丢
- 1 条 30 秒测：实测 37.9 秒 + commit 持久化 OK ✅
- 41 条批量测：实测 1273.2s ≈ 21 分钟 + 40/41 ok 1 fail（JSONDecode）✅
- **速度反推**：~31s/record。**316 条 NULL 全清需 316 × 31s ≈ 2.6 小时**
- 200 条 `--limit` 实际只处理 41 条（详见下方"⚠️ --limit 神话"）

### ⚠️ --limit 神话：2026-06-06 新发现

**陷阱 17（重要）**：`judge_topics_angle.py --limit N` **不等于处理 N 条**。实测：

| --limit | 实际处理 | 耗时 | NOT NULL 增量 |
|---|---|---|---|
| `--limit 1` | 1 | 37.9s | +1 |
| `--limit 200` | **41** | 1273.2s | +40（1 fail）|

**根因**（推测）：脚本内部 SQL 的 `LIMIT` 可能被其他 WHERE 条件/子查询实际截断，**不是** argparse `--limit` 字面值。

**预防**：
- ❌ **不要**用 `--limit` 字面值预估"会处理多少条"或"需要多久"
- ✅ **必查** pool.db `WHERE angle_score IS NULL` 的 delta（跑前 + 跑后）
- ✅ **必查** log 最后一行 `【完成】N ok / M fail` 确认实际数
- ✅ 预估耗时公式：**NULL 数 × 31s + 启动 30s**

**详细手动跑流程**（含 background exit_code 占位符陷阱）：见 `references/manual-m3-run-workflow.md`

---

## 手动跑 m3 任务的标准流程（2026-06-06 落地）

> **触发**：用户说"手动跑 m3 任务"/"清一下 NULL"/"补跑角度判定"。

**6 步流程**（详见 `references/manual-m3-run-workflow.md`）：

1. **查 cron 任务 ID**：从 `cron/jobs.json` 找 3 个 m3 任务的 id + script
2. **查 baseline**：`SELECT COUNT(*) FROM topics WHERE angle_score IS NULL`（必查！）
3. **后台启动**：`terminal(background=True, notify_on_complete=True, timeout=2000, command="...HERMES_CRON_SCRIPT_TIMEOUT=1800 ... judge_topics_angle.py --limit 200 2>&1 | tee /tmp/m3_run.log")`
4. **第一动作**：`process(action='poll', session_id=..., timeout=3)` 验证真启动了（**exit_code: 0 是占位符**）
5. **等完成**：靠 `notify_on_complete=true` 系统通知，或 `process(action='wait', ...)`
6. **验证 delta**：`SELECT COUNT(*) ... WHERE angle_score IS NULL` 跑完再查一次，对比 baseline

**关键参数**：
- `HERMES_CRON_SCRIPT_TIMEOUT=1800`（默认 300s 不够，必设）
- `timeout=2000`（background 模式最大允许运行时间）
- `notify_on_complete=true`（必开，21 分钟后才有通知）
- `--limit 200` ≠ 处理 200 条（陷阱 17）

**反模式**（永久禁止）：
- ❌ 前台跑（撞 terminal timeout）
- ❌ 不查 baseline（不知道清了多少）
- ❌ 看 `exit_code: 0` 就报告完成（陷阱 18——是占位符）
- ❌ 用 `--limit` 字面值预估耗时（陷阱 17）
- ❌ 不设 `HERMES_CRON_SCRIPT_TIMEOUT`（scheduler SIGTERM）

**为什么 6 步必走全**：少了任何一步，21 分钟后才能从 `last_status='error'` 倒推出问题，浪费时间。

## 改动登记

- 2026-06-06 落地：`judge_topics_angle.py` 加 commit in loop + SIGTERM/SIGINT handler
- 备份：`/home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py.bak.20260606_103811`
- 触发场景：今天 8:10/12:00/16:00 m3 任务被 300s timeout 杀，pool.db 角度分仍 298 NOT NULL / 317 NULL 累计（修复前）
- 修复后预期：3 次 m3 任务累积处理 30-90 条/天，不会丢
