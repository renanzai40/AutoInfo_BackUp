# LLM Batch 并行化模式（2026-06-10 落地）

## 问题

`judge_topics_angle.py` 顺序调用 LLM API（39 条 × ~45s = ~30 分钟），远超 cron 默认 300s 超时。

## 解法：B + C 组合

### B：延长超时窗口

```bash
# ~/.hermes/profiles/content/.env
HERMES_CRON_SCRIPT_TIMEOUT=900  # 15分钟，覆盖默认 300s
```

### C：ThreadPoolExecutor 并行化

将主循环拆为二阶段：

```
Phase 1: 并发 API 调用
  ThreadPoolExecutor(max_workers=5)
  → 同时发起 5 条 LLM 请求
  → as_completed 收集结果
  → 预估 39 条 ≈ 5-6 分钟 (vs 串行 30 分钟)

Phase 2: 单线程写库
  → 原有 v2 解析逻辑不变
  → commit_in_loop（每 20 条 commit）保持
```

## 改造要点

```python
from concurrent.futures import ThreadPoolExecutor, as_completed

# === Phase 1: 并行 API ===
api_results = []
with ThreadPoolExecutor(max_workers=5) as executor:
    future_to_topic = {
        executor.submit(call_llm, r["title"], r["source"], r["correlation_score"]): r
        for r in pending
    }
    for future in as_completed(future_to_topic):
        r = future_to_topic[future]
        try:
            parsed, err = future.result(timeout=130)
            api_results.append((r, parsed, err))
        except Exception as e:
            api_results.append((r, None, f"{type(e).__name__}"))

# === Phase 2: 单线程写库 ===
for i, (r, parsed, err) in enumerate(api_results, 1):
    # ... 原有 DB 写入逻辑不变 ...
    if i % 20 == 0:
        con.commit()
```

## 设计决策

| 决策 | 选择 | 理由 |
|------|------|------|
| 并发模型 | ThreadPoolExecutor | 最轻量，script 主体本来就是 Python 单线程；asyncio 要改整个 I/O 层 |
| max_workers | 5 | 保守起步，避免 API 限流；实测够用 |
| DB 写时机 | phase 2 集中写 | 避免 SQLite 写并发 |
| 限流策略 | 集群 max_workers 替代 time.sleep(1) | 串行 sleep 在并发模式下无意义 |
| 错误处理 | future.result(timeout=130) | 防单条卡死；已有 call_llm 内部 3 次重试兜底 |

## 适用条件

任何 cron 脚本满足以下条件时适合此模式：
- 批处理 N 条数据（N > 10）
- 每条调一次外部 API（LLM / 搜索 / 翻译等）
- 单条处理时间 10-60s
- API 无严格的全局速率限制（或有但 5 并发不触发）
- DB 写入可在单线程安全完成后执行

## 不适用信号

- API 有严格 QPS（1 req/s）——只能用串行
- DB 写入必须逐条检查、断点续传——保留 commit_in_loop 但无法并行
- 外部 API 成本高（按 token 计费）——并行不会省成本但可以更快失败
