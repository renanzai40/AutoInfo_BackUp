# 8:30 TOP3 推送实操笔记（2026-08-07 运行沉淀）

## 1. session_lock.py CLI 默认持锁 60s —— terminal 超时是预期行为，不是失败

`session_lock.py` CLI 模式逻辑：`hold_sec = max(60, args.hold)`，即不传 `--hold` 时
**抢到锁后 sleep 60s 才退出**。cron prompt 首步命令只传 `--wait-timeout 5`，所以：

- terminal() 调用默认 60s 超时 → 进程在 60s 处被 kill → 显示 `[Command timed out after 60s]`（exit 124）
- **这代表锁已抢到并持有了 60s**（若抢不到会在 ~5s 内打印"⚠️ 抢不到 lock"并退出，不会跑满 60s）
- kill 后 flock 自动释放，但 `/tmp/session_lock_<name>.lock` 空文件会残留 → 下次抢锁
  直接 flock 成功（文件存在无碍），无需清理

**验证方式**（超时后确认锁状态）：
```bash
ps aux | grep session_lock | grep -v grep   # 无输出 = 无持锁进程 = flock 空闲
ls -la /tmp/session_lock_auto_media_top3_push.lock  # mtime = 本次运行时间 = 本 session 创建
```
确认无其他持锁进程后即可继续执行，**不要因超时重跑抢锁**（重跑会再白等 60s）。

## 2. heat_score 量纲：README 写 0-100，实际存 0-1

- `Pool/README.md` 表格写 `heat_score | REAL | 热度评分 0-100` —— **已过时**
- 采集脚本 `auto_media_hot_collection_v3_20260525.py` 实际写入 `1.0 - i * step`（排名归一化，0-1 量纲）
- 评分公式 `(heat_score/10)*0.30`（growth）/ `(heat_score/10)*0.10`（business）是按 0-10 假设写的，
  用 0-1 数据算出来 heat 分量只有 0.03~0.09，**热度几乎不影响综合分**——这是现状，不是 bug

**规范**：评分一律以 `Pool/archive-20260803/compute_top5.py` 为唯一事实源，
直接照抄其公式，不要"修正"量纲。历年 summary 里的综合分与此公式算出的值可能有
小出入（数据被刷新过），以当天 pool.db 实时查询 + compute_top5.py 公式为准。

## 3. 业务款首选「双高规则」

business TOP1 推荐遵循：**综合分差距 < 0.5 时，优先 angle_score 更高者**。
2026-08-07 案例：TOP1「AI智能体尚无法开展开放式AI研究」9.00/angle=7，TOP3「Soup
v0.72.4 微调 8B」8.71/angle=9 → 差距 0.29 < 0.5 → 业务款首选推 angle=9 的 Soup，
即使它排 TOP3。理由：业务款要可生产性+关联度，角度分高 = 内容可生产性强。

## 4. pool.db 查询：sqlite3 CLI 在 WSL 不可用，用 python3 内建模块

```bash
sqlite3 pool.db "..."   # ❌ command not found
python3 -c "import sqlite3; ..."   # ✅ 标准做法（conn.row_factory = sqlite3.Row）
```
这是 pool 相关所有 SQL 的通用写法，别依赖 sqlite3 CLI。

## 5. 8:30 推送格式要点（对齐 cron prompt + 前日备份）

- 备份先写 `~/.hermes/profiles/content/cron/output/YYYY-MM-DD_0830_summary.md`，再输出 final response
- final response = 推送正文，不得追加"全流程完成"类收尾
- 数据来源行写当日符合条件总数（如 37 条：business 29 / growth 8）
- 智能体推荐：引流款 = growth TOP1；业务款 = 按双高规则选（可能不是 TOP1）
- 两类池都非空时无需第六步空池提示
