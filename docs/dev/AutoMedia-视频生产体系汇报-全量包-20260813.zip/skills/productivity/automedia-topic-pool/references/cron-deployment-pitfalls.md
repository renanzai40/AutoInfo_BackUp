# AutoMedia Cron Job 部署陷阱（2026-06-01 实测）

> 本文件记录从 jobs.json 写入到 cron 真正跑通全链路上踩过的 5 个坑。每个坑都附"症状 → 根因 → 修法 → 预防"四段式，便于以后快速对照。
>
> 触发场景：手动测试 cron、迁移 jobs.json、添加新 no_agent=true 脚本类 job、新装 hermes profile。

---

## 坑 1：script 字段路径只能"复制真文件到 scripts/"（最致命）

**症状**：
```
last_error: "Script not found: /home/renanzai/.hermes/profiles/content/scripts/auto_media_hot_collection_v3_20260525.py"
# 或者
last_error: "Blocked: script path resolves outside the scripts directory
            (/home/renanzai/.hermes/profiles/content/scripts): 'auto_media_hot_collection_v3_20260525.py'"
last_status: "error"（或误报 "ok" — 见坑 5）
```

**根因**：hermes `cronjob_tools._validate_cron_script_path` 用 `validate_within_dir(scripts_dir / raw, scripts_dir)` 验证路径安全。意味着：

| jobs.json 里 `script` 字段写法 | 结果 |
|-------------------------------|------|
| 相对文件名：`"auto_media_xxx.py"` | ✅ 唯一可行 — 必须存在于 `~/.hermes/profiles/<profile>/scripts/` |
| 绝对路径：`"/mnt/d/.../Scripts/auto_media_xxx.py"` | ❌ 被当作文件名拼到 `scripts_dir` 后变无效路径 |
| Symlink 到脚本目录外 | ❌ realpath 解析后跨目录被拦 |
| `../Scripts/auto_media_xxx.py"`（含 `..`） | ❌ 路径逃逸被拦 |

**修法**：
```bash
# 唯一可行方案：复制真文件
mkdir -p ~/.hermes/profiles/<profile>/scripts/
cp /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/auto_media_hot_collection_v3_20260525.py \
   ~/.hermes/profiles/<profile>/scripts/
```

**预防**：
- 创建 no_agent=true 脚本类 job 时，**直接复制脚本到 scripts/**——别试 symlink，别试绝对路径
- v3 脚本（37KB）只 import 标准库，不依赖其他 minimax_*.py，单独复制可用
- 维护成本：原脚本更新时记得同步复制版本

---

## 坑 2：`cronjob action='list'` 报 `'str' object has no attribute 'get'`

**症状**：
```python
cronjob(action='list')  # → {"error": "'str' object has no attribute 'get'", "success": false}
```

**根因**：hermes `cronjob_tools.py` 工具的 list 路径有 bug。**但 `cron.jobs.list_jobs()` 内部函数本身完全正常**——5 个 job 都能正确返回（验证过）。

**绕过方案**：用 `execute_code` 直接调内部函数：
```python
import sys, os
sys.path.insert(0, '/home/renanzai/.hermes/hermes-agent')
os.chdir('/home/renanzai/.hermes/hermes-agent')
from cron.jobs import list_jobs
for j in list_jobs(include_disabled=True):
    print(j['id'], j['name'], j.get('last_status'), j.get('last_run_at'))
```

**预防**：
- 调试 cron job 状态时，**首选 `execute_code + cron.jobs.list_jobs()`**，绕过工具 bug
- `cronjob action='run'` 不受影响，**可以正常使用**
- `cronjob action='get'`（按 job_id 查）也工作

---

## 坑 3：状态字段是**异步更新**的，run 后立刻查是旧值

**症状**：
```python
cronjob(action='run', job_id='xxx')  # 返回 last_run_at 还是几小时前的
# 等 5 秒再查
cronjob(action='run', job_id='xxx')  # 这次返回的还是旧的！
```

**根因**：hermes cron 调度器**异步**执行脚本，`run` 返回的是 jobs.json **当前已写回的状态**（还没写就是上次的）。脚本跑完 hermes 才更新 `last_run_at` / `last_status` / `last_error` / repeat 计数。

**正确验证流程**：
1. 触发 `run`
2. 等 5-10 秒（脚本类 job 通常 30-180s）
3. 用 `cron.jobs.list_jobs()` 查最新状态
4. **同时**用 `ps -ef | grep <script_name>` 看进程是否真在跑
5. 看 output 文件 `~/.hermes/profiles/<profile>/cron/output/<job_id>/<timestamp>.md`（最新时间戳）
6. 看 pool.db 写入数（基线 vs 跑后）

**预防**：
- 永远**别**用 `action='run'` 的返回 JSON 当"真跑了"的证据
- 真验证 = 进程 + output 文件 + 副作用（DB 写入数）+ status 字段，**4 个交叉验证**

---

## 坑 4：迁移 jobs.json 时，`deliver` 字段保留了**错的私聊 ID**

**症状**：
```json
"deliver": "origin,feishu:oc_fb8771a1fb9b0214b99d7c28c03dbe7f,feishu:oc_fbc1c0b8faf60cf622b75904fd1f75cd",
"last_delivery_error": "delivery error: Feishu send failed: [230002] Bot/User can NOT be out of the chat."
```

**根因**：从 default profile 迁移 AutoMedia cron job 到 content profile 时，`deliver` 字段**整段照抄**——但里面写的私聊 chat_id（`oc_fb8771a1...`）是**其他 bot / 旧 session** 的私聊，不是 content profile 的私聊。`last_delivery_error` 揭示 bot 不在那个 chat 里。

**修法**：
- content profile 的私聊 ID 必须在 `send_message action='list'` 的实时输出确认（**不信文档里写的 ID**）
- 已知 content profile 私聊：`oc_23809420584b118ca6df5c514067045b`（实测 2026-06-01）
- 群"贯维内容生产"：`oc_fbc1c0b8faf60cf622b75904fd1f75cd`
- no_agent=true 脚本类 job（07:30 维护、08:00 采集）→ 建议 `deliver: "local"`（脚本不推结果，hermes 别推"结果"消息）

**预防**：
- 迁移 cron job 到新 profile 时，**deliver 字段必须重写**，不能整段照抄
- `origin` 字段也是同理（origin.chat_id 是触发 bot 的私聊 ID，新 profile 会变）
- job 改完**先 dry-check**：用 `cron.jobs.get_job(job_id)` 看 `origin` 字段的 chat_id 对不对

---

## 坑 5：`last_status='ok'` 是**假阳性**——hermes 不严格查 exit code

**症状**：
```json
"last_run_at": "2026-06-01T08:01:03",
"last_status": "ok",
// 但 output 文件里写：
// "Status: script failed\n\nScript not found: ..."
```

**根因**：hermes cron 调度器对 `no_agent=true` 脚本类 job **不严格查 exit code**——如果 `script path validation` 失败但 hermes 内部标记了 ok，状态字段就是 ok。这是个 hermes 已知行为（不是 bug 是设计选择）。

**真实验证 status 唯一可靠方式**：
1. 读 `last_error` 字段（**有值就是失败**，None 才是真成功）
2. 看 output 文件（最后几行通常写 "Status: script failed" 或 "ok"）
3. 看副作用（pool.db 写入数、文件创建等）—— **没副作用 = 没真跑**
4. 跑前 `ps -ef` 记基线，跑后看 v3 进程是否真启动过（看 PID 时间戳）

**预防**：
- **永远别**只看 `last_status` 字段判断 cron 是否真成功
- 真成功 = `last_status=ok` + `last_error=None` + output 文件写"Status: ok" + 副作用齐全
- 用户问"cron 跑通了吗" → 答"status 字段是 ok，但 output 写 failed，last_error 有值，pool.db 没新增 — 实际是失败的假阳性"

---

## 坑 6：jobs.json 字段名 `job_id` vs `id` —— hermes 工具只认 `id`

**症状**：
```
cronjob action='list'  # → {"error": "'str' object has no attribute 'get'", "success": false}
```
- 但**单独调** `cron.jobs.list_jobs()` 完全成功（绕过工具 bug）
- jobs.json 是合法 JSON，顶层是 dict

**根因**：
- 部分手写 / 迁移的 jobs.json job 用了 `job_id` 字段名（**不是** `id`）
- hermes `cronjob_tools.py` L528 `_format_job` → `job.get(...)` 假设 `id` 字段
- 当 jobs.json 某 job 缺 `id` 字段时，list 工具内部某处把 job 字符串化处理 → 报 `'str' object has no attribute 'get'`
- **不**影响 `cron.jobs.list_jobs()` 内部函数（它直接读 JSON）

**实测案例（2026-06-01）**：
- Watchdog job 字段是 `{"job_id": "wdog_auto_media", "name": "...", ...}`（无 `id`）
- 其他 4 个 job 都有 `id` 字段
- 5 个 job 写在同一个 `jobs.json` → list 工具炸

**修法**：
```python
# 直接给那个 job 加 id 字段（保留 job_id 不删，向后兼容）
import json, shutil
from datetime import datetime

src = "~/.hermes/profiles/content/cron/jobs.json"
bak = f"{src}.bak.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
shutil.copy2(src, bak)

data = json.load(open(src))
for j in data['jobs']:
    if 'Watchdog' in j.get('name', ''):
        j['id'] = j.get('job_id', 'wdog_auto_media')
        break

with open(src, 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
```

**预防**：
- 创建/迁移 job 时，**只用 `id` 字段**——别用 `job_id` / `name` / `cron_id` / `task_id` 等变体
- 写完 jobs.json 跑一次 `execute_code` 验证：每个 job 都有 `id` 字段 + 是 string + 唯一

---

## 坑 7：v3 脚本 "返回空" 真因 = `curl -s --max-time 45` 静默超时（**不是** M3 API 失败）

**症状**：
```
Layer2 返回空，保留全部 50 条
MiniMax返回空，保留全部50条
```
- 但**单独 curl** 测同样的 payload → **完全工作**（14.8s, 2921 chars, finish_reason=stop）
- v3 脚本的 `if not raw: return items` 路径被反复触发

**根因**：
- v3 脚本 L540 / L457: `curl -s --max-time 45 ...`
- `-s` flag → curl 静默（**stderr 也吞**，exit code 不显示）
- `--max-time 45` → 超过 45 秒 curl exit 28 (`CURLE_OPERATION_TIMEDOUT`) + stdout 空
- v3 L467-469 `if not raw: print("Layer2 返回空")` → 软失败降级（保留全部）

**实测（2026-06-01）**：
- 50 条 Tavily dedup curl 跑 **47.6s** → 超过 45s → 静默失败
- 50 条带 URL layer 2 curl 跑 **14.8s** → 不超时 → 真工作
- **dedup 任务天然慢**（pairwise 去重要 LLM 全量配对）vs **layer 2 单判断**（一条一次决策）—— 复杂度差 ~3x

**M3 任务耗时基线（实测 2026-06-01）**：
| 任务类型 | 实测耗时 | 阈值 45s | 阈值 120s |
|---------|---------|---------|----------|
| Dedup（pairwise 去重）| 47.6s | ❌ 超时 | ✅ 够 |
| Layer 2（单条判断）| 14.8s | ✅ 够 | ✅ 够 |
| SEO 过滤（流 2）| 短 | ✅ 够 | ✅ 够 |

**修法**：
```python
# v3 脚本 L540 + L457: 改 --max-time 45 → --max-time 120
# 改前**备份**（v3 无 __main__ 保护，importlib = 真采集+写库）
```

**预防**：
- **永远别**信 v3 "返回空" = M3 API 失败——先单独 curl 验证（构造同样的 payload，curl 跑 30-60s）
- 调大 curl 超时：dedup 任务 50-90s，layer 2 任务 15s 是合理值
- v3 脚本改前必备份（37KB）；验证用 `subprocess.run(['python3', script, '--help'])` 而不是 importlib
- 看 v3 output 文件 + 副作用 + M3 端点直连，三者交叉验证

---

## 坑 8：hermes cron 调度器行为 —— profile jobs sequential + at-most-once

**根因**（实测 hermes 源码 2026-06-01）：

| 机制 | 代码位置 | 行为 |
|------|---------|------|
| **Profile jobs sequential** | `scheduler.py` L1985-1992 + L1997-1999 | 同一 tick 内，profile 字段非空的 job **顺序**跑（避免 env context 互相污染） |
| **at-most-once 语义** | `scheduler.py` L1902-1905 | tick 启动时**先** advance 所有 due job 的 next_run_at，再执行（防双触发）|
| **file lock 防止并发 tick** | `scheduler.py` L7-8 + `.tick.lock` | 一个 tick 阻塞时，下一个 tick 延后但**不丢** |
| **default max_workers=unbounded** | `scheduler.py` L1907-1932 | 并行跑多个 due job（但 profile 类顺序跑） |

**实际影响 — 修改 v3 超时后是否冲突后续 job**：

cron 时间表：
```
07:30 → 08:00 (5min) → 08:05 (5min) → 08:30 (25min) → 09:30
```

A 方案 v3 跑通耗时估算（`--max-time 45` → `--max-time 120`）：
- 流 1 dedup 30s + 流 2 dedup 60-90s + 流 1 layer 2 15s + 流 2 layer 2 60-90s + Tavily 60s + 写库 5s = **210-270s (3:30-4:30)**
- 当前实测 188s (3:08) → 增量 ~50s

**冲突评估**：
- 08:00 → 08:05 间隔 300s > A 方案跑通 270s → **不冲突**
- 08:30 间隔 1500s → 绝对安全
- 极端（4 个 M3 都 90s+ = 360s）→ file lock 让 08:05 tick 延后 3-5 分钟触发（**at-most-once 保证 08:05 仍会跑**）

**预防**：
- 修改 v3 脚本耗时**先评估**后续 job 间隔：
  - 单 v3 job ≤ 4 分钟：与下一 job 间隔 5 分钟**勉强**安全
  - 单 v3 job 4-8 分钟：可能延后下一 job 3-5 分钟
  - 单 v3 job > 8 分钟：需拆 job 或拉长间隔
- 4-6 个串行 M3 调用累积耗时是主要风险点
- v3 输出文件 `cron/output/<job_id>/<timestamp>.md` 跑完时间戳可作为真实耗时审计

---

## 坑 10：`repeat` 字段必须是 dict `{"times": N, "completed": M}`，不能是 string `"forever"`

**症状**：
```python
cronjob action='list'
# → {"error": "'str' object has no attribute 'get'", "success": false}

cronjob action='run', job_id='wdog_auto_media'
# → {"error": "'str' object has no attribute 'get'", "success": false}
```

和坑 6 同样的错误信息，但是**不同的根因**——坑 6 是 `id` 字段缺失，这次是 `repeat` 字段是 string。

**根因**：
- hermes 源码 `cronjob_tools._format_job` → `_repeat_display` 内：
  ```python
  repeat = job.get("repeat", {}) or {}
  times = repeat.get("times")  # ← repeat 是 string "forever" 时，这里炸
  ```
- `repeat = "forever"` → `"forever".get("times")` → `AttributeError`
- `repeat = {"times": null, "completed": 0}` → `repeat.get("times") = None` → 走 `if times is None: return "forever"` 路径（**显示结果完全一样**）

**实测案例（2026-06-01）**：
- Watchdog job 手工编辑时写 `repeat: "forever"`（人类可读形式）
- 其他 4 个 job `repeat` 字段是 dict（hermes 内部正常化后的格式）
- 5 个 job 写在同一个 jobs.json → list 工具只对 Watchdog 炸（其他 4 个没炸是因为 repeat 是 dict）

**修法**：

```python
# 把 string "forever" 改成标准 dict 格式
j["repeat"] = {"times": None, "completed": 0}  # None times = 永远重复
# 或
j["repeat"] = {"times": 0, "completed": 0}     # 0 times = 永远重复（部分 hermes 版本认这个）
# 或（如果 job 只跑 N 次）
j["repeat"] = {"times": N, "completed": 0}

# 验证 _format_job 不再炸
from cron.jobs import list_jobs
jobs = list_jobs(include_disabled=True)
for j in jobs:
    if j.get('id') == 'wdog_auto_media':
        from cron.tools.cronjob_tools import _format_job
        formatted = _format_job(j)
        assert 'forever' in formatted.get('repeat_display', '')  # 显示仍是 "forever"
        print("✅ fixed")
```

**预防（永久规则）**：
- **写 jobs.json 时 `repeat` 字段一律用 dict 格式**——别用 `"forever"` / `"never"` / `"daily"` 之类的字符串
- 标准值：
  - 永远重复：`{"times": null, "completed": 0}`（显示 "forever"）
  - 跑 N 次：`{"times": N, "completed": 0}`
  - 跑完 N 次后停：`{"times": N, "completed": N}`（hermes 自动停）
- debug 时看到 `'str' object has no attribute 'get'` → **先查 `id` 字段（坑 6），再查 `repeat` 字段（坑 10）**

---

## 坑 9：v3 脚本 `print(f"失败: {e}")` 把 API key 写到 output 文件

**症状**：
- cron 跑通但 output 文件（`~/.hermes/profiles/<profile>/cron/output/<job_id>/<timestamp>.md`）含完整 API key：
  ```
  'MimiMax去重失败: Command \'[\\'curl\\', \\'-s\\', \\'--max-time\\', \\'120\\', \\'-X\\', \\'POST\\',
  ..., \\'-H\\', \\'Authorization: Bearer sk-cp-CAPjdmw...Jrpbw\\', ...] returned non-zero exit status 28.'
  ```
- 文件里搜 `sk-[A-Za-z0-9_-]{50,}` 模式能命中完整 key

**根因**：
- Python `subprocess.run()` 抛的 `TimeoutExpired` / `CalledProcessError` 异常，其 `__str__()` 自动生成 cmd 完整列表
- v3 脚本三处异常处理（L395 / L505 / L580 附近）用 `print(f"  失败: {e}")` → `{e}` 含 cmd → 写到 output 文件
- cmd 列表里 `-H 'Authorization: Bearer sk-...'` 完整落地

**实测（2026-06-01）**：
- 17:31-41 output 文件（13KB）含 key（v3 重跑触发 `CalledProcessError` exit 28）
- 17:03-04 output 文件（5.5KB）**不含** key（该次跑是降级路径 "返回空" 不触发 `print(e)`）

**修法**：

1. **改 v3 脚本三处 print 模板**（永久修复）：
   ```python
   # ❌ 错误
   except Exception as e:
       print(f"  失败: {e}")

   # ✅ 正确：只 print 类型名 + 自定义原因，**不**碰 {e}
   except Exception as e:
       print(f"  失败 ({type(e).__name__})，保留全部 N 条")
   ```
   改前**必备份**（v3 假 import 真执行，importlib = 真采集+写库）

2. **已落地文件**（一次性）：
   - 找含 `sk-[A-Za-z0-9_-]{50,}` 模式的 .md 文件
   - `re.sub(r'sk-[A-Za-z0-9_-]{50,}', 'sk-***MASKED***', content)` 替换
   - **不删**文件（保留 v3 跑通记录作为证据），加 `.bak.<ts>_masked` 备份
   - output 文件 owner-only 权限暴露面有限

3. **是否 rotate key**（按用户风险偏好决定）：
   - key 在 `~/.hermes/.env`，cron agent 通过 `source ~/.hermes/.env` 加载
   - 若 output 文件曾被其他进程读 / 同步到云端 / 备份上传 → 需 rotate
   - 若严格 owner-only 权限 + 本地备份 → 可观察
   - **永久方案**还是改 print 模板（坑已修）

**预防（永久规则）**：
- v3 脚本 / 任何 Python subprocess 脚本写异常处理时，**禁止** `print(f"...{e}...")`
- 用 `type(e).__name__` 或显式列出期望字段
- 写 cron job prompt 时也避开"如失败 print 完整异常"这种描述
- 新写 subprocess 调用时，**首条**检查：cmd 列表里有没有 secret？异常里会不会被 str()？

---

## 综合 debug 流程（迁移 / 新装 cron job 后必跑）

```
1. 检查 jobs.json
   - 5 个 job 都有 `id` 字段（hermes 工具只认 `id`，不认 `job_id`）
   - script 字段是相对文件名
   - deliver / origin 字段的 chat_id 是当前 profile 的（用 send_message list 确认）
   - schedule 是 dict 格式（{kind, expr, display}），不是 str

2. 脚本类 job
   - 真文件必须在 ~/.hermes/profiles/<profile>/scripts/
   - 不能是 symlink、不能是绝对路径
   - 跑前 ps 看进程，验证 realpath 在 scripts/ 内

3. 触发 + 验证
   - cronjob action='run' 触发
   - 等 5-10s + ps 看进程
   - cron.jobs.list_jobs() 查 last_status / last_error
   - 读 output 文件
   - 检查副作用（DB、文件）

4. 失败排查
   - last_error 字段 → 找根因
   - 如果是脚本路径问题 → 复制到 scripts/（坑 1）
   - 如果是 "list" 工具 bug → 用 execute_code 绕过（坑 2）
   - 如果状态没更新 → 等 5-10s（坑 3）
   - 如果 delivery error → 检查 deliver 字段 chat_id（坑 4）
   - 如果 status 报 ok 但实际失败 → 看 last_error + output（坑 5）
```

---

## 坑 11：`jobs.json` 路径按 profile 分目录，看错文件就改错地方（2026-06-05 实测）

**症状**：
- 以为自己改了 content profile 的 jobs.json，**实际上只改了 default profile 的**
- 改完跑 `cronjob action='list'` 显示变了 → 以为生效
- **但实际 content profile 跑的 jobs 没动**（因为它读的是 profile-specific 副本）

**根因**（实测 2026-06-05）：
- `~/.hermes/cron/jobs.json` — **default profile** 用
- `~/.herenzai/.hermes/profiles/<profile>/cron/jobs.json` — **每个 profile 各自一份**
- `cronjob` 工具（list/update/run）**根据 active profile 自动路由**到 profile-specific 文件
- 但**手动读文件**时，**很可能**直接 `read_file ~/.hermes/cron/jobs.json`（错位）
- **更阴险**：两个 jobs.json 内容差异可能很大（default 只有 2 个 job，content 有 6-8 个 job）

**实测（2026-06-05）**：
- 直接读 `~/.hermes/cron/jobs.json` 看到只有 2 个 job（context-sync + self-packaging）
- 误以为 content profile 也只有这 2 个
- **漏看** content profile 的 `profiles/content/cron/jobs.json`（实际有 6 个 AutoMedia jobs）
- 等到用 `cronjob action='list'` 验证时才看到 6 个全在
- **浪费了一轮**没必要的"找 jobs.json 位置"操作

**修法**：
- **永远先确认 active profile 再操作 jobs.json**——**别**直接 `read_file` 顶层 `~/.hermes/cron/jobs.json`
- 改 jobs.json 前必做：

```python
# 1. 确认 active profile
import os
active_profile = os.environ.get('HERMES_PROFILE', 'default')
print(f"active profile = {active_profile}")

# 2. 找对应 jobs.json 路径
if active_profile == 'default':
    jobs_path = '/home/renanzai/.hermes/cron/jobs.json'
else:
    jobs_path = f'/home/renanzai/.hermes/profiles/{active_profile}/cron/jobs.json'
print(f"jobs.json 路径 = {jobs_path}")

# 3. 验证
import json
data = json.load(open(jobs_path))
print(f"jobs 数 = {len(data['jobs'])}")
for j in data['jobs']:
    print(f"  {j.get('id', '?')}")
```

- 用 `cronjob action='list'` 验证改动生效（**它走 profile 路由**，一定看对位置）

**预防**：
- 写新 skill / reference 时，提到"改 jobs.json"必须同时说"哪个 profile 的"
- 改 jobs.json **前**：
  1. 确认 active profile（`HERMES_PROFILE` env var 或看会话开头标识）
  2. 备份**对应 profile** 的 jobs.json
  3. 改完用 `cronjob action='list'` 验证（**别**用 `read_file`）
- **永远别**假设 `~/.hermes/cron/jobs.json` 就是 active profile 用的
- profile 切换：content / default / code 各自一份，**别**跨 profile 复用同一份 jobs.json

**相关路径速查**：
- default profile: `~/.hermes/cron/jobs.json`
- content profile: `~/.hermes/profiles/content/cron/jobs.json`
- code profile: `~/.hermes/profiles/code/cron/jobs.json`（如果存在）

---

## 相关文件 / 路径速查

- jobs.json（content profile）：`~/.hermes/profiles/content/cron/jobs.json`
- jobs.json（default profile）：`~/.hermes/cron/jobs.json`
- 归档备份：`~/.hermes/cron/.archive/jobs.json.AutoMedia-pre-migration.<日期>.bak`
- scripts 目录（content profile）：`~/.hermes/profiles/content/scripts/`
- cron output：`~/.herrencies/profiles/content/cron/output/<job_id>/<timestamp>.md`
- v3 脚本原版：`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/auto_media_hot_collection_v3_20260525.py`
- 飞书 chat_id 验证：`send_message action='list'`（必须每次重新跑，文档 ID 不可信）
