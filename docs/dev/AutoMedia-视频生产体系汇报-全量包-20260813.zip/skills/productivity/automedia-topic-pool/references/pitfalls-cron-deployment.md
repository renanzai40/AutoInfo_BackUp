# ⚠️ Cron 部署相关致命陷阱（2026-06-01 新增）

## ⚠️ Cron 部署相关致命陷阱（2026-06-01 新增）

> 完整内容见 `references/cron-deployment-pitfalls.md`。这里只列最高频踩坑点：

### 陷阱 4（路径陷阱，最致命）：`script` 字段只能写相对文件名，且真文件必须存在于 `scripts/`

**坑过的真实案例（2026-06-01）**：08:00 采集 job 写 `script: "auto_media_hot_collection_v3_20260525.py"`，hermes 找 `~/.hermes/profiles/content/scripts/auto_media_hot_collection_v3_20260525.py`——不存在。**symlink 也不行**（realpath 跨目录被拦），**绝对路径也不行**（hermes 当文件名拼到 scripts_dir 后）。唯一可行：复制真文件到 scripts/。

**正确做法**：
```bash
mkdir -p ~/.hermes/profiles/<profile>/scripts/
cp /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/auto_media_hot_collection_v3_20260525.py \
   ~/.hermes/profiles/<profile>/scripts/
```

### 陷阱 5：迁移 jobs.json 时 `deliver` 字段的 chat_id 是旧 profile 的

**坑过的真实案例（2026-06-01）**：从 default profile 迁 5 个 AutoMedia job 到 content profile 时，`deliver` 字段写了 `feishu:oc_fb8771a1fb9b0214b99d7c28c03dbe7f`（**错的私聊 ID**，是其他 bot 的私聊），跑时 `last_delivery_error: [230002] Bot/User can NOT be out of the chat`。

**正确做法**：迁移后**必须**用 `send_message action='list'` 拿当前 profile 的真实 chat_id 重写 `deliver` 和 `origin` 字段。文档里的 ID 不可信。

### 陷阱 6：`last_status='ok'` 是假阳性 — hermes 不严格查 exit code

**坑过的真实案例（2026-06-01）**：08:00 实际脚本路径找不到，**但 jobs.json 里 `last_status='ok'`**——因为 hermes 调度器对 `no_agent=true` job 不严格查 exit code。

**正确验证**：`last_status='ok'` + **`last_error=None`** + output 文件写 "Status: ok" + 副作用齐全（pool.db 写入 / 文件创建），4 个交叉验证才作数。**只看 status 字段永远不够**。

### 陷阱 7：jobs.json job 字段必须用 `id`，**不是** `job_id`（新增 2026-06-01）

**坑过的真实案例（2026-06-01）**：Watchdog job 字段名是 `job_id: "wdog_auto_media"`，其他 4 个 job 都是 `id`。`cronjob action='list'` 报 `'str' object has no attribute 'get'` —— 工具只认 `id` 字段。

**修法**：给那个 job 加 `id` 字段（保留 `job_id` 不删，向后兼容）。**预防**：写/迁移 job 时只用 `id` 字段，别用 `job_id` / `name` / `cron_id` / `task_id` 变体。

### 陷阱 8：v3 "返回空" 真因 = `curl -s --max-time 45` 静默超时（新增 2026-06-01）

**坑过的真实案例（2026-06-01）**：v3 跑通时打印 "Layer2 返回空，保留全部 50 条" —— 表面看是 M3 API 失败，**实际是 curl 静默超时**。实测同样的 payload 单独 curl 完全工作（14.8s, 2921 chars）。50 条 Tavily dedup 跑 47.6s > `--max-time 45` → curl exit 28 + 空 stdout。`-s` flag 让 stderr 也被吞，错误完全静默。

**修法**：v3 脚本 L540 + L457 改 `--max-time 45` → `--max-time 120`（改前必备份）。**预防**：永远先单独 curl 验证 "返回空" 是否真因。**M3 任务耗时基线**：dedup 47.6s / layer 2 14.8s / SEO 过滤短。

### 陷阱 9：hermes cron profile jobs sequential + at-most-once（新增 2026-06-01）

**实测 hermes 源码（2026-06-01）**：
- 同一 tick 内，profile 字段非空的 jobs **顺序**跑（避免 env context 互相污染）
- tick 启动**先** advance next_run_at 再执行（at-most-once 语义）
- file lock `~/.hermes/cron/.tick.lock` 防止并发 tick，阻塞延后但**不丢**

**改 v3 超时前必评估**：
- 单 v3 job ≤ 4 分钟：与下一 job 间隔 5 分钟勉强安全
- 单 v3 job 4-8 分钟：可能延后下一 job 3-5 分钟
- 单 v3 job > 8 分钟：需拆 job 或拉长间隔
- 4-6 个串行 M3 调用累积耗时是主要风险点

**完整内容见 `references/cron-deployment-pitfalls.md` 第 6/7/8 坑。**

### 陷阱 10：v3 脚本 `print(f"失败: {e}")` 暴露 API key（新增 2026-06-01，最新）

**症状**：cron output 文件 `~/.hermes/profiles/<profile>/cron/output/<job_id>/<timestamp>.md` 包含完整 `Authorization: Bearer sk-cp-...`：
```python
# 异常信息 print 出来：
'MimiMax去重失败: Command '['curl', '-s', '--max-time', '120', '-X', 'POST',
... '-H', 'Authorization: Bearer sk-cp-CAPjdmw...Jrpbw', ...]'
```

**根因**：`subprocess.run()` 抛的 `TimeoutExpired` / `CalledProcessError` 异常的 `__str__()` **包含完整 cmd 列表**——而 cmd 里包含 `Authorization: Bearer <API_KEY>`。v3 脚本 L395 / L505 / L580-582 三个异常处理都 `print(f"失败: {e}")` → 暴露 key。

**修法（永久）**：
```python
# ❌ 错误：print 异常对象本身
print(f"  MiniMax去重失败: {e}，保留全部{len(titles)}条")

# ✅ 正确：只 print 异常类型名（保留调试能力 + 不暴露 cmd）
print(f"  MiniMax去重失败 ({type(e).__name__})，保留全部{len(titles)}条")
```

**已有 output 文件处理（一次性）**：
- 找含 `sk-[A-Za-z0-9_-]{50,}` 模式的 .md 文件
- `re.sub(r'sk-[A-Za-z0-9_-]{50,}', 'sk-***MASKED***', content)` 替换
- **不删**文件（保留 v3 跑通记录作为证据）+ 加 `.bak.<ts>_masked` 备份

**预防**：
- v3 脚本（任何 Python subprocess 脚本）写异常处理时，**禁止** `print(f"...{e}...")`
- 用 `type(e).__name__` 或显式列出期望字段
- 写 cron job prompt 时也避开"如失败 print 完整异常"这种描述
- key 真正暴露面小（owner-only 文件权限），但**不该有**——**rotate key 是更稳的彻底方案**，按用户风险偏好决定

**完整内容见 `references/cron-deployment-pitfalls.md` 第 9 坑。**

### 陷阱 11：`repeat` 字段必须是 dict `{"times": N, "completed": M}`，不能是 string `"forever"`（新增 2026-06-01）

**症状**：`cronjob action='list'` 或 `action='run'` 报 `{"error": "'str' object has no attribute 'get'", "success": false}`。

**根因（实测 hermes 源码）**：`cronjob_tools._format_job` → `_repeat_display`：
```python
repeat = job.get("repeat", {}) or {}
times = repeat.get("times")  # ← repeat 是 string "forever" 时炸
```
- `repeat = "forever"` → `"forever".get("times")` → `AttributeError`
- `repeat = {"times": null, "completed": 0}` → `repeat.get("times") = None` → 走 `if times is None: return "forever"` 路径（**显示完全一样**）

**与陷阱 7（job_id vs id）区别**：错误信息相同（都是 `'str' object has no attribute 'get'`），但根因不同：
- 陷阱 7：job 缺 `id` 字段（list 工具需要 `id` 字段）
- 陷阱 11：job 有 `id` 字段，但 `repeat` 字段是 string

**实测案例（2026-06-01）**：
- Watchdog job 手工编辑时写 `repeat: "forever"`（人类可读形式）
- 其他 4 个 job `repeat` 字段是 dict（hermes 内部正常化后的格式）
- 5 个 job 写在同一个 jobs.json → list 工具只对 Watchdog 炸

**修法（永久规则）**：
```python
# ❌ 错误（人类可读，但 hermes 工具炸）
j["repeat"] = "forever"

# ✅ 正确（hermes 标准 dict 格式）
j["repeat"] = {"times": None, "completed": 0}    # 永远重复（显示 "forever"）
j["repeat"] = {"times": 0, "completed": 0}       # 0 times = 永远重复
j["repeat"] = {"times": N, "completed": 0}       # 跑 N 次
j["repeat"] = {"times": N, "completed": N}       # 跑完 N 次后停
```

**预防**：
- 写 jobs.json 时 `repeat` 字段**一律**用 dict，别用 string
- debug 看到 `'str' object has no attribute 'get'` → **先查 `id` 字段（陷阱 7），再查 `repeat` 字段（陷阱 11）**

**完整内容见 `references/cron-deployment-pitfalls.md` 第 10 坑。**

### 陷阱 12：session_lock.py 脚本默认 `--hold 0` 实际持锁 60s（新增 2026-06-06，**2026-06-13 更新：引入 --hold 1 前台可行模式**）

**症状**：cron 08:30 prompt 抢 session_lock 第一次调用 `terminal(foreground)` 直接 timeout 60s，terminal 自动 SIGTERM 杀掉 Python 进程。

**根因**（实测 session_lock.py 源码）：
```python
hold_sec = max(60, args.hold) if args.hold <= 0 else args.hold
# args.hold=0 → 0 <= 0 → hold_sec = max(60, 0) = 60  ← 60s
# 脚本流程：抢锁 → print "✅ 抢到 lock" → time.sleep(60) → 释放
# 前台调用被卡在 time.sleep(60)
```

**两种可行模式，按场景选择**：

**模式 A（推荐）：后台启动 + 前台干活** — 持锁 60s，安全窗口充裕
```python
# 1. 启动锁脚本（后台）
terminal(background=true, command="python3 ~/.hermes/profiles/content/scripts/session_lock.py --name auto_media_top3_push --wait-timeout 3")
# 2. 等 2-3s 看到 "✅ 抢到 lock" 输出
# 3. 立即在主 agent 干活（DB 查询 / 评分 / 写备份 / 推送）—— 60s 窗口内
# 4. 锁 60s 后自动 time.sleep 完成 + flock 释放
# 5. 不需要主动 kill 进程
```

**模式 B（可行替代）：前台 `--hold 1` + 验证即释放** — 锁只用作并发检测，不保护长作业
```bash
python3 ~/.hermes/profiles/content/scripts/session_lock.py \
    --name auto_media_top3_push --wait-timeout 5 --hold 1
# terminal(timeout=10) 足够（脚本约 1s 完成）
# stdout 含 "✅ 抢到 lock" → 继续执行（1s 后锁释放）
# stdout 含 "⚠️ 抢不到 lock" → 静默退出
```

**适用场景**：
- 模式 A：需要锁保护整个推送/生产流程不被并行中断（如长 DB 更新）
- 模式 B（已验证 2026-06-13 cron 可行）：**cron at-most-once 调度上下文**，锁仅作为**并发检测**而非作业保护。锁在 1s 释放后 cron 的 at-most-once 语义（陷阱 9）已确保无并行 session

**反模式（永久禁止）**：
- ❌ 前台 session_lock.py 不带 `--hold` → 默认 60s → terminal timeout 杀掉
- ❌ 跳过抢锁"因为之前没出错"——错，2026-06-05 当天 3 session 抢活

**完整内容见 `references/cron-0830-push-workflow.md` 的"步骤 1"和"步骤 7"**。

> ⚠️ **陷阱 30（2026-06-24）：cron LLM-driven job 的 final response = 投递内容，prompt 必须显式约束** — agent 容易在中间消息输出推送正文（带 tool_calls），然后输出纯文本收尾作为 final response（无 tool_calls），而 cron 只投递最后一条消息。症状：备份文件有数据，用户收到的是收尾模板。修复：在备份步骤后加关键纪律，禁止输出收尾消息。

### 陷阱 13：session_lock.py CLI 参数名是 `--wait-timeout` 不是 `--timeout`（新增 2026-06-06，最新）

### 陷阱 13：session_lock.py CLI 参数名是 `--wait-timeout` 不是 `--timeout`（新增 2026-06-06，最新）

**症状**：
```
WARNING [cron_7671da210b69_...] agent.tool_executor: Tool terminal returned error (2.72s):
{"output": "usage: session_lock.py [-h] [--name NAME] [--hold HOLD]
                               [--wait-timeout WAIT_TIMEOUT] [--check-only]
session_lock.py: error: unrecognized arguments: --timeout 5",
```

**根因**：session_lock.py argparse 实际接受 `--wait-timeout`（拼写完整），但**很多人习惯写 `--timeout`**（类似 curl/mysql 等工具的简写）。写 prompt 时手误 → 抢锁命令直接报错 → agent 跳到 [SILENT] 静默退出 → 用户没收到推送。

**实测案例（2026-06-06）**：
- 08:30 prompt 第一次抢锁：`--timeout 5` → argparse 报错 → exit code != 0
- agent 试 fallback：`session_lock.py --check-only` 查 lock 状态
- 看到"⚠️ 锁存在" → 误判抢不到锁 → 静默退出
- 实际上**第一次根本没抢到锁**（argparse 错误发生在 argparse 解析阶段），不是被其他 session 占着
- 8:05 后用户问"为什么没看到触发"——其实 8:30 **触发了**但**静默退出了**

**预防（永久规则）**：
- ✅ 写 cron 08:30 / Pre-production prompt 抢锁时**唯一正确**写法：`--wait-timeout N`
- ❌ **永远不写** `--timeout N`（argparse 报错）/`--wait N`（无此参数）/`-t N`（无短选项）
- 写完 prompt **必查** job 的 `last_delivery_error` 字段——空 = 真抢到锁成功；有值 = 命令报错
- 改 prompt 后第一次跑，看 `~/.hermes/profiles/<profile>/cron/output/<job_id>/` 最新的 .md 文件——**没有** "✅ 抢到 lock" 字样 = 抢锁命令失败

**完整 session_lock.py CLI 参数清单**（2026-06-06 实测）：
```
--name NAME         锁名（不同任务用不同名）必填
--hold HOLD         持锁时长（秒）。0=默认 60s。
--wait-timeout N    等待锁的最长时间（秒），抢不到锁时重试。默认 5s。
--check-only        只检查锁状态，不抢锁
```

**完整内容见 `references/cron-0830-push-workflow.md` 的"步骤 1"**（已固化 `--wait-timeout 5` 正确写法）。

### 陷阱 14：scheduler 脚本类 job 默认 timeout 300s（2026-06-06 实测，重大隐患）

**症状**：
- m3 角度判定（judge_topics_angle.py --limit 200）实际要 8-15 分钟
- 300s 后 scheduler 主动 SIGTERM wrapper.sh，**但 Python 子进程变孤儿**继续跑
- output 写 `Script timed out after 300s: .../judge_angles_cron.sh`
- jobs.json 标 `last_status=error`，next_run_at 推到下个周期
- **孤儿 Python 进程继续跑**但失去 cron 控制，下次 tick 看到还在跑就再触发 → 重复跑

**根因**（实测 hermes-agent/cron/scheduler.py 821-833 行）：
```python
def _get_script_timeout() -> int:
    env_value = os.getenv("HERMES_CRON_SCRIPT_TIMEOUT", """).strip()
    if env_value:
        try:
            return int(float(env_value))
        except ValueError:
            pass
    return _DEFAULT_SCRIPT_TIMEOUT  # 300s
```

`_DEFAULT_SCRIPT_TIMEOUT = 300` 写死，**5 分钟不够** m3 类任务。

**实测耗时基线（2026-06-06 多次实测）**：
| 任务 | 实测耗时 | 300s 是否够 |
|------|---------|------------|
| auto_media_hot_collection_v3（08:00 采集）| 2-4 min | ✅ 够 |
| judge_topics_angle.py --limit 200 | **8-15 min** | ❌ **严重不够** |
| audit_08x05（LLM agent 任务）| 1-3 min | ✅ 够 |
| maintenance_01 | < 30s | ✅ 够 |

**修法（3 选 1，2026-06-06 推荐 2）**：

1. **设置环境变量**（推荐）：
   ```bash
   # ~/.hermes/profiles/<profile>/.env 或 gateway 启动环境
   HERMES_CRON_SCRIPT_TIMEOUT=1800  # 30 分钟
   ```
   - 优点：不动 hermes-agent 代码
   - 缺点：要重启 gateway 生效

2. **改 m3 脚本支持增量 commit**（推荐长期方案，**2026-06-06 已落地**）：
   ```python
   # judge_topics_angle.py 每判 20 条就 commit 一次
   for i, r in enumerate(pending, 1):
       parsed, err = call_m3(...)
       # 写入当前条
       cur.execute("UPDATE topics SET angle_score=? WHERE topic_id=?", ...)
       if i % 20 == 0:
           con.commit()  # 中间状态保存
   ```
   - 优点：300s 杀进程时已 commit 部分结果不丢
   - 缺点：要改 judge_topics_angle.py 源码
   - **代码 + SIGTERM handler + 测试方法**详见 `references/cron-m3-script-hardening.md`（**已固化**）

3. **缩小 m3 任务 limit**（临时方案）：
   - `judge_topics_angle.py --limit 50`（5 分钟内能跑完）
   - 缺点：处理能力下降，3 个 cron (8:10/12:00/16:00) 一天共 150 条不够清 317 NULL

**预防**：
- 设计新 cron 脚本类 job 时，**先**评估实际耗时（用 `--dry-run` 模式跑一遍测基线）
- > 300s 的任务 → 必设 `HERMES_CRON_SCRIPT_TIMEOUT=1800`
- 改 hermes-agent 默认值是**最不推荐**——影响所有 profile

**完整内容见 `references/cron-deployment-pitfalls.md` 坑 8（v3 跑批耗时）** + `references/cron-8am-timezone-bug.md` 关联上下文。

### 陷阱 15：hermes cron `script` 字段**不接受**命令行参数（2026-06-06 实测，重大隐患）

**症状**：
```json
"script": "judge_topics_angle.py --limit 200"
```
→ scheduler 把整段当文件路径
→ `Script not found: /home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py --limit 200`
→ 包含空格的"文件名"找不到

**根因**（实测 hermes-agent/cron/scheduler.py 885-902 行）：
```python
raw = Path(script_path).expanduser()  # ← 把整段当路径
if raw.is_absolute():
    path = raw.resolve()
else:
    path = (scripts_dir / raw).resolve()
# ...
if not path.exists():
    return False, f"Script not found: {path}"
```

scheduler **完全不支持 script 字段带参数**——整段当文件路径处理。

**修法（wrapper 脚本）**：
```bash
# ~/.hermes/profiles/content/scripts/judge_angles_cron.sh
#!/bin/bash
set -e
exec /home/renanzai/.hermes/hermes-agent/venv/bin/python3 \
    /home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py \
    --limit 200
```
```bash
chmod +x ~/.hermes/profiles/content/scripts/judge_angles_cron.sh
```
```json
// jobs.json script 字段改成纯文件名
"script": "judge_angles_cron.sh"
```

**预防（永久规则）**：
- ❌ **永远不写** `script: "xxx.py --limit 200"` / `script: "xxx.py --dry-run"` / `script: "xxx.sh --verbose"`
- ✅ **永远只写** 纯文件名（含 .sh 也能跑——scheduler 看后缀自动选 bash 解释器）
- 需要带参数 → 写 wrapper 脚本（.sh 包一层 exec python）
- jobs.json 改完用 `cronjob action='list'` 验证 + `ps -ef | grep <script_name>` 看 scheduler 启动的进程命令行是否对

**完整内容见 `references/cron-deployment-pitfalls.md` 坑 1.5**（独立子坑，2026-06-06 实测）。

### 陷阱 16：jobs.json 8:00 任务 advance_next_run 时 hermes-time 返回了 UTC（新增 2026-06-06，最新）

**症状**：
- 8:00 任务 `last_run_at: "2026-06-05T16:03:04+08:00"` = **CST 16:03**（昨天下午 4 点）
- 8:00 任务 `next_run_at: "2026-06-06T16:00:00+08:00"` = **CST 16:00**（今天下午 4 点）
- 其他任务（8:05/8:30/7:30/9:30）**都正常**

**根因**（实测 2026-06-06 三层）：
1. `config.yaml` 里 `timezone: ''`（空字符串）→ hermes-time 走 fallback `datetime.now().astimezone()`
2. 8:00 任务上次 advance_next_run 时 hermes-time 返回了 **UTC**（不是 CST）
3. croniter 拿 UTC 16:03 当 base → 算 "0 8 * * *" 下一个 = UTC 8:00 → 存到 jobs.json 标 +08:00 → 实际跑在 CST 16:00

**为什么只有 8:00 任务错乱**：8:00 任务 `created_at: 2026-05-11` 较早，当时 hermes-time fallback 不稳；其他任务后来创建，hermes-time 已稳。

**当前状态（2026-06-06 实测修复）**：
- 8:00 任务 next_run_at 直接 patch 成 `2026-06-07T08:00:00+08:00`（CST 8:00）
- 3 个 m3 任务 next_run_at 同样 patch 成 06-07 CST 8:10/12:00/16:00
- 当前 hermes-time 已返回 CST（watchdog 9:30 任务 next=CST 9:30 是对的）→ 不会再产生新错乱

**根本预防**：
1. config.yaml 强制锁时区（写 `timezone: 'Asia/Shanghai'`——但 config.yaml 是 protected file，需用 `hermes config set` 命令改）
2. 写新 cron job 必查 `cronjob action='list'` 看 next_run_at——错位 = UTC 解释 → 立刻 patch
4. job 创建后跑 1 次验证：`hermes cron run <job_id>` → 看 last_run_at 是不是预期时间

**完整内容见 `references/cron-8am-timezone-bug.md`**（独立 reference，2026-06-06 新增）。

---

### 陷阱 17：cron 任务"静默无操作" — last_status=ok 但业务侧 0 变化（2026-06-06 实测，重大隐患）

> **本陷阱是 16 个旧陷阱的**上位类**——它们每一个都是"任务跑出 0 价值的某个子原因"**。本陷阱讲的是这一类问题的**共同诊断方法**。

**核心问题（3 段流水线模型）**：

```
[段 1: 任务定义]    [段 2: 脚本执行]    [段 3: 数据副作用]
jobs.json 字段      script 实际跑       pool.db / 文件系统真的变化吗
                ↓                ↓                    ↓
        last_status 取决于这里 = 段 2 是否报错
        ↑ 但段 1 错 / 段 3 错 = last_status 全 ok
```

**任何一段坏了，最后都标 `last_status=ok`，但实际业务侧完全没进展。**

**2026-06-06 单日实测发现 5 个独立静默坑**（**全部** `last_status=ok`）：

| 坑 | 类型 | 跑了多久 | 业务影响 |
|---|------|---------|---------|
| 8:30 prompt `--timeout 5` 错 | A2 任务定义 | 数天 | 推送静默退出 |
| 8:00 任务时区错乱（DST/UTC） | D1 跨段 | 数周 | 8:00 实际跑 16:00 |
| 3 个 m3 cron `script` 带 `--limit 200` | A2 任务定义 | 一直 | m3 cron 报错"找不到脚本" |
| `audit_08x05` script=None | A1 任务定义 | 26 天 | Layer 3 审核从未跑过 |
| m3 脚本 default `--source Tavily,AIHOT` | B1 SQL 过滤 | 一直 | 159 条中文平台话题永远 0 候选 |

**最阴险的案例（2026-06-06 B1 静默坑根因）**：

- `judge_topics_angle.py` 默认 `--source "Tavily,AIHOT"`
- WHERE 条件 `AND source IN ('Tavily', 'AIHOT')`
- 全部 159 条 approved+NULL 都是**微博/知乎/抖音**（Tavily/AIHOT 的 220 条已全部判完）
- 每次 cron 跑 → WHERE 过滤 → 0 条 → 输出 "✅ 没有待判定的" → exit 0 → last_status=ok
- **脚本"成功"跑了 N 周，0 业务价值**
- 8:30 推送 75 条高分全是 Tavily/AIHOT 旧数据，新进中文平台话题永远过不了 m3 那一关

**4 步诊断手册**（任何"任务跑了但没干活"时按顺序跑）：

```bash
# Step 1: 任务定义层（段 1）—— 查 jobs.json 字段
python3 -c "
import json
d = json.load(open('/home/renanzai/.hermes/profiles/content/cron/jobs.json'))
for j in d.get('jobs', []):
    print(f'{j[\"id\"]} | script={j.get(\"script\")} | schedule={j.get(\"schedule\",{}).get(\"expr\")}')
"

# Step 2: 任务执行层（段 2）—— last_status + 输出文件 mtime
hermes cron list
ls -la ~/.hermes/profiles/content/cron/output/<job_id>/

# Step 3: 业务副作用层（段 3，**关键！**）—— db delta
sqlite3 /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db \
  "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL"
# 数值应该随 cron 跑下降，**长期不变 = 静默坑**

# Step 4: 手动跑一次 + db delta
before=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL")
HERMES_CRON_SCRIPT_TIMEOUT=1800 python judge_topics_angle.py --limit 200
after=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL")
echo "delta: $((before-after))"  # 0 = 静默坑
```

**核心原则：3 段全部验证，单看 last_status=ok = 不够。**

**4 大类反模式**（详细见 `references/cron-silent-noop-patterns.md`）：
- **类别 A 段 1 任务定义错**：`script=null` / `script=xxx.py --arg` / 路径不在 scripts/
- **类别 B 段 2 脚本跑通但产出 0**：**SQL `source IN` 过滤排除全部数据 = 静默坑典型** / WHERE 条件有时间范围全部候选过期
- **类别 C 段 3 业务侧副作用 0**：commit 漏了 / 写错 db / 推送内容是缓存
- **类别 D 跨段组合**：任务依赖链断（8:00 错位 → 8:05 找不到数据）/ gateway 旧版未生效

**预防（最实用 3 招）**：

1. **必加守护脚本**：所有"如果有数据就处理，没有就退出"的脚本，加：
   ```python
   if not pending and total_null > 0:
       print(f"⚠️ WARNING: 有 {total_null} 条候选，但本轮过滤后 0 条", file=sys.stderr)
   ```

2. **任务定义改完必跑**：`hermes cron run <id>` → 看 db delta > 0 才算改对

3. **不要相信 last_status 单字段**：永远 4 个交叉验证（last_status=ok + last_error=None + last_delivery_error=None + 业务侧 db delta > 0）

**完整内容见 `references/cron-silent-noop-patterns.md`**（2026-06-06 新增，**4 大类 9 个反模式 + 4 步诊断手册 + 真实案例**）。

**本陷阱与现有 16 个陷阱的关系**：
- 陷阱 4-16 是"单点"问题（具体哪个字段 / 哪个 API 错）
- 陷阱 17 是"类"问题（**不管哪一段坏了，last_status 都报 ok**）——是上位类
- **排查任何 cron 异常时，先按陷阱 17 的 4 步手册定位"哪一段坏了"，再跳到对应单点陷阱看具体修法**

### 陷阱 20：cron wrapper 脚本**必须显式传所有参数**（2026-06-06 实测，新增高频坑）

> 这是 cron deployment 范畴的"防御性编程"原则。任何 wrapper bash 脚本（`judge_angles_cron.sh` 之类）**不能依赖被调脚本的默认值**。

**症状（2026-06-06 实测）**：
- `judge_angles_cron.sh` 只传 `--limit 200`，**不传** `--source` → 依赖 `judge_topics_angle.py` 默认值
- 脚本默认值 = `Tavily,AIHOT`（**这是已修复的旧默认值**）
- 如果未来有人/我手贱改回 `Tavily,AIHOT` 或其他值，cron 静默漏跑中文平台话题
- 8:30 推送又会变成"全靠旧数据"——**今天修的 bug 静默回归**

**根因**：
- wrapper 是 cron 任务和业务脚本的**胶水层**——它的责任不仅是"包 exec"，**更是"固定 cron 跑该跑的行为"**
- 业务脚本默认值是给"手动跑"用的（让人能 `--limit 50 --source 微博` 灵活调）
- cron 跑是**生产路径**——必须**完全确定**——不允许"默认值变了我跟着变"
- 现有 19 个陷阱**没有专门讲**这个 wrapper 防御性编程

**修法（永久规则）**：

```bash
#!/bin/bash
# ~/.hermes/profiles/content/scripts/judge_angles_cron.sh
# 2026-06-06 增强：显式传 --source 全 5 个 source（防御 m3 脚本默认值被改坏导致
#                 cron 静默漏跑中文平台话题——8:30 推送会全靠旧数据）
set -e
exec /home/renanzai/.hermes/hermes-agent/venv/bin/python3 \
    /home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py \
    --limit 200 \
    --source 微博,知乎,抖音,Tavily,AIHOT
```

**核心原则**：
- ✅ **wrapper 显式传**所有**会影响行为的参数**（`--source` / `--min-corr` / `--dry-run` 等）
- ✅ **wrapper 内 comment 写明**"防御 X 脚本默认值被改坏"
- ❌ **永远不要** `exec python judge_xxx.py` 不带任何参数（依赖默认值）
- ❌ **永远不要** `exec python judge_xxx.py $@` 透传 CLI（cron scheduler 不支持传 CLI——但万一未来支持，wrapper 不该有"灵活"借口）

**预防检查清单**：
- 写新 wrapper 时，过一遍："如果被调脚本默认值被改回坏值，cron 还会正常工作吗？"
- 不行 → 显式传参数 + 注释说明
- cron 跑前 `bash <wrapper.sh> --dry-run` 看优先级 source 列表是否对

**完整内容见 `references/cron-wrapper-defensive-args.md`**（2026-06-06 新增）。

### 陷阱 21：业务款 vs 引流款**不能用同一维度硬过滤**（2026-06-06 实测，新增方法论）

> 这是 Layer 2.5 + 8:30 推送**核心选品决策框架**的固化，**不是 bug**——是设计原则。

**核心问题**：
- 业务款（直接给 B2B AI 目标受众提供价值）和引流款（拉点击 + 制造情绪共鸣）的**评分模型不同**：
  - 业务款：m3 angle_score（内容可生产性）**主导**（≥7 是 hard filter）
  - 引流款：heat_score（平台热度）**主导**（m3 4-6 分即可，heat ≥0.7 是 hard filter）
- 但 m3 任务 cron 8:10/12:00/16:00 **统一**给所有 approved 话题打分（不分引流/业务）
- 8:30 推送 SQL 必须**分两套**过滤逻辑——不能一条 SQL 选两个 category

**2026-06-06 实测 76 高分话题分布**：
- Tavily/AIHOT 占 72/76 = **94.7%**（业务款金矿）
- 微博/知乎/抖音 4 条（引流款窄源）
- 19 条 ≥7 分业务款候选 + 3 条 mid 引流款候选 = 22 条选题空间

**决策框架（2026-06-06 固化）**：

| 维度 | 业务款 | 引流款 |
|---|---|---|
| m3 angle_score | ≥7（hard filter）| 4-6（mid 段可用）|
| heat_score | 中等即可（≥0.5）| **≥0.7**（hard filter）|
| source | Tavily/AIHOT 优先（金矿）| 微博/知乎/抖音 优先（真热点）|
| 三维度 c/b/t | 三维都 ≥6（可生产 + 可桥接 + 可 CTA）| c 维度 ≥6 即可（内容可生产）|
| risk_flag | 必 none（不能有 politics/disaster）| 必 none |
| 数量限制 | 1-2 条/天（产能天花板）| 1-2 条/天 |
| 桥接目标 | 引到"壹目贯维服务"CTA | 引到对应业务款（同一个 session）|

**反模式（禁止）**：
- ❌ **8:30 推送一条 SQL** 选两个 category → 池薄时容易凑数塞低分（2026-06-05 引流款被 angle=3 污染的根源）
- ❌ **用 heat_score 给业务款排序** → heat 0.2 的"5亿Tokens白送"（m3=8.0）会被埋没
- ❌ **用 m3 score 给引流款排序** → m3 1.3 的微博热搜永远出不了
- ❌ **业务款池空就放宽到 ≥6** → 1-2 条/天产能下不划算（阈值推荐 ≥7 已经在 2026-06-03 user 拍板）
- ❌ **引流款池空就放宽到 m3=0** → 凑数塞不可生产的（如 2026-06-05 的"天涯神帖" angle=3）

**实操 SQL 模板**（8:30 推送 prompt 用）：

```sql
-- 业务款候选
SELECT title, source, angle_score, heat_score, angle_reason
FROM topics
WHERE status = 'pending'
  AND review_status = 'approved'
  AND angle_score IS NOT NULL
  AND angle_score >= 7
  AND risk_flag NOT IN ('politics', 'disaster', 'privacy', 'sensitive')
ORDER BY angle_score DESC, heat_score DESC
LIMIT 5;

-- 引流款候选
SELECT title, source, angle_score, heat_score, angle_reason
FROM topics
WHERE status = 'pending'
  AND review_status = 'approved'
  AND angle_score IS NOT NULL
  AND angle_score >= 4 AND angle_score < 7
  AND heat_score >= 0.7
  AND risk_flag NOT IN ('politics', 'disaster', 'privacy', 'sensitive')
ORDER BY heat_score DESC, angle_score DESC
LIMIT 5;
```

**两个池子独立**——业务款池空时**只**显示业务款池空提示，**不**让引流款候选顶上去。

**完整内容见 `references/topic-selection-decision-framework.md`**（2026-06-06 新增）。

### 陷阱 18：脚本 `sys.exit(0 if stats["fail"] == 0 else 1)` 让"7/152 fail"看起来全失败（2026-06-06 实测，新增高频坑）

**症状**：
- `judge_topics_angle.py` L355 写的是 `sys.exit(0 if stats["fail"] == 0 else 1)`
- 实际跑 67 分钟，**145 ok / 7 fail**（commit_in_loop 期间 7 次 m3 API 偶发 JSON parse fail，正常失败率 ~5%）
- exit 1 → cron 标 `last_status=error` → **用户/agent 看到"m3 任务失败"**
- **但 pool.db 角度分 +145**（7 fail 的不写库，145 ok 的 commit 进去了）→ 实际业务成功
- 双重错误：cron 报失败 + 我的 bash wrapper 解析 `output=$()` grep 同样报"0 ok / 7 fail"

**根因**：
- 把 `fail > 0` 等同于"任务失败"是**不当的二元判断**——长跑 LLM 任务偶发 fail 是正常
- 真正的"任务失败"应该是 `ok == 0`（一个都没成功） 或 DB delta 持续 0（连续多日无进展）
- **反模式思维**：把"完美主义"（必须 100% 成功）应用到长跑批量任务上

**修法（永久规则）**：
```python
# ❌ 错：把 fail > 0 直接当失败
sys.exit(0 if stats["fail"] == 0 else 1)

# ✅ 正确：只要有成功就算任务成功
sys.exit(0 if stats["ok"] > 0 else 1)

# 或者更激进：永远 exit 0（详情在 stats 报告里）
sys.exit(0)
```

**预防性监控**：
- 任何"批量处理 + 允许部分失败"的任务，必加**业务侧 db delta 验证**（陷阱 17 段 3 验证）
- 不要只信 `exit_code` —— 7/152 fail 时 exit_code 不可信
- 写任务时区分 3 种状态：
  - **完全失败**（ok=0）：exit 非 0，让 cron 报
  - **部分成功**（ok>0 且 fail>0）：exit 0，详情在 stats/log
  - **完全成功**（fail=0）：exit 0

**实测案例（2026-06-06）**：
- m3 任务 `judge_topics_angle.py` 跑 159 条 → 145 ok + 7 fail（m3 API 偶发 JSON parse error）
- cron 报 exit 1 → 我**误判**"任务失败" + bash wrapper 又把 ok 解析成 0（陷阱 19）
- 真实结果：pool.db 角度分 0→145（任务实际成功）
- **用户被告知"0 ok"但实际 145 条已 commit** — 完全错误报告

### 陷阱 19：bash `output=$()` 捕获长跑脚本会**静默截断**大输出（2026-06-06 实测，新增高频坑）

**症状**：
- 我的 wrapper 脚本：`output=$($PY "$SCRIPT" 2>&1)` 然后 `echo "$output" | grep -oP ...`
- m3 任务跑 67 分钟，每条 1 行 print + 每 20 条 1 行进度 → 152 次输出 + 8 行进度
- bash 内部 buffer（实测约 4-8 KB）静默截断超长字符串 → `$output` 只有前部分
- `grep` 在截断后的变量上跑 → 漏掉末尾的 `【完成】145 ok / 7 fail`
- **结果**：wrapper 报"0 ok / 7 fail"（陷阱 18 双倍叠加）

**根因**：
- bash `$()` 命令替换的 stdout 捕获走 `popen` + 内部 buffer
- 跨平台 buffer 大小不一（实测 WSL/Linux bash ~8 KB 临界）
- 超过 buffer 的输出**直接被丢**（不是 SIGPIPE 错误）—— 完全静默
- 这是 bash 设计限制，不是 bug —— 文档少有人提

**修法（永久规则）**：
```bash
# ❌ 错：变量捕获大输出
output=$(long_running_script 2>&1)
echo "$output" | grep "completion"  # 截断风险

# ✅ 正确：tee 到文件 + grep 文件
long_running_script 2>&1 | tee /tmp/script.log
grep "completion" /tmp/script.log      # 永不截断

# ✅ 或者：直接 >> 追加到 log 文件
long_running_script >> /tmp/script.log 2>&1
grep "completion" /tmp/script.log
```

**预防**：
- 写任何会输出 ≥ 100 行的脚本 wrapper → 必用 `tee` 或 `>> file`
- **永远不要** 用 `$()` 捕获可能超 1 KB 的输出
- 长跑任务（> 5 分钟）必 `tee /tmp/<job>.log` 留 log
- `tee` + 后台进程用 `process(action='log', session_id=...)` 也能看完整输出

**实测案例（2026-06-06）**：
- 我的 `/tmp/m3_batches.sh` 跑 7 批 × 67 分钟 = ~7.5 小时
- 每批 152 次 print + 进度行 = 总输出可能 50+ KB
- `output=$($PY ...)` 捕获后 grep 不到末尾的 "【完成】" 行
- 报告给用户"0 ok / 7 fail"——实际是 145 ok / 7 fail
- 修法：改用 `tee /tmp/m3_batches.log` 写盘 + `grep /tmp/m3_batches.log`

### 📊 m3 评分对中文平台话题的判定特性（2026-06-06 实证，**接受为模型行为**）

> 这不是 bug，是 m3 评分模型的固有偏好。**写 Layer 2.5 时必须知道**，否则会被误导为"m3 出 bug 了"。

**2026-06-06 实测 159 条新判定话题的角分分布**：

| source | 处理数 | 角分 avg | 高分(≥7) | mid(4-6) | low(<4) |
|---|---|---|---|---|---|
| 知乎 | 78 | **1.26** | **0** | 3 | 75 |
| 微博 | 41 | **1.49** | **0** | 4 | 37 |
| 抖音 | 40 | **1.30** | **0** | 2 | 38 |
| Tavily | 25 | 5.56 | 11 | 7 | 7 |
| AIHOT | 17 | 6.12 | 8 | 7 | 2 |

**结论（接受为模型特性，不试图修复）**：
- **微博/知乎/抖音 159 条新判定 → 0 条高分**（avg 1.3-1.5）
- m3 觉得这些话题"内容可生产性差"——B2B AI 受众契合度低
- 知乎偏专业讨论（无内容角度）/ 微博娱乐热搜（CTR 强但 B2B 弱）/ 抖音视频（标题简略）
- **这不是 m3 出 bug**，是 m3 在 B2B AI 评估上的合理判断
- Tavily/AIHOT 是 AI 业务款核心金矿（avg 5.5-6.1，高分占比 32-47%）

**实战影响**：
- 8:30 推送**业务款 TOP 候选池**主要靠 Tavily/AIHOT 提供
- 中文平台话题**对业务款贡献为 0**，但**对引流款贡献显著**（4-6 分段有 9 条）
- m3 任务 cron 必须覆盖全 5 source（陷阱 17 B1 已修），但**心理预期**：每天 m3 处理 200+ 条，能出 ≥7 分的 90% 来自 Tavily/AIHOT
- 不要因为"中文平台过不了 m3 那关"就调整 m3 prompt 或阈值——**接受这个特性**

**维护规范**：
- 看到 m3 评分 "0 高分" 不代表 bug → **先看 source 分布**（中文平台本身就是低分）
- 调整 Layer 2.5 时**不动 m3 prompt 接受度**——它对"哪些话题是 B2B AI 业务款"的判断是对的
- 引流款池子单独看（mid 4-6 分的微博/知乎/抖音）—— 不需要 m3 ≥7 也能进引流款推送

### 📋 pool.db 两个 status 列的语义区别（2026-06-06 教训，避免下次查错）

**两个看起来都叫"status"的列，实际语义完全不同**：

| 列名 | 语义 | 取值 | 谁写 | 谁读 |
|---|---|---|---|---|
| `status` | **生产状态**（pipeline 流转）| `pending` / `selected` / `writing` / `archived` | 8:30 推送 + 人工选 + 生产链路 | dashboard / 生产链路 |
| `review_status` | **审核状态**（Layer 3 语义审核）| `pending` / `approved` / `rejected` / NULL（legacy）| audit_08x05 任务 | m3 任务 / 推送 |

**SQL 查询时必须区分**：
- m3 任务：`WHERE review_status = 'approved' AND angle_score IS NULL`
- 8:30 推送：`WHERE status = 'pending' AND review_status = 'approved' AND angle_score >= 7`
- dashboard："今日入库未处理" 看 `status='pending'`,"待 m3 判"看 `review_status='approved' AND angle_score IS NULL`

**反模式（禁止）**：
- ❌ `WHERE status = 'approved'` —— 这是错的语义，应该是 `review_status='approved'`
- ❌ 把两个字段混写为 `WHERE status IN ('approved', 'pending')` —— 跨语义过滤无意义
- ❌ 调试时只看 `status` 不看 `review_status` —— 容易误判"为什么 m3 找不到候选"

**症状**：
- 8:00 任务 `last_run_at: "2026-06-05T16:03:04+08:00"` = **CST 16:03**（昨天下午 4 点）
- 8:00 任务 `next_run_at: "2026-06-06T16:00:00+08:00"` = **CST 16:00**（今天下午 4 点）
- 8:00 任务 output 目录 mtime = **Jun 5 16:03**（昨天 16 点）
- 其他任务（8:05/8:30/7:30/9:30）**都正常**

**根因**（实测 2026-06-06 三层）：
1. `config.yaml` 里 `timezone: ''`（空字符串）→ hermes-time 走 fallback `datetime.now().astimezone()`
2. 8:00 任务上次 advance_next_run 时 hermes-time 返回了 **UTC**（不是 CST）
3. croniter 拿 UTC 16:03 当 base → 算 "0 8 * * *" 下一个 = UTC 8:00 → 存到 jobs.json 标 +08:00 → 实际跑在 CST 16:00

**为什么只有 8:00 任务错乱**：8:00 任务 `created_at: 2026-05-11` 较早，当时 hermes-time fallback 不稳；其他任务后来创建，hermes-time 已稳。

**当前状态（2026-06-06 实测修复）**：
- 8:00 任务 next_run_at 直接 patch 成 `2026-06-07T08:00:00+08:00`（CST 8:00）
- 3 个 m3 任务 next_run_at 同样 patch 成 06-07 CST 8:10/12:00/16:00
- 当前 hermes-time 已返回 CST（watchdog 9:30 任务 next=CST 9:30 是对的）→ 不会再产生新错乱

**根本预防**：
1. config.yaml 强制锁时区（写 `timezone: 'Asia/Shanghai'`——但 config.yaml 是 protected file，需用 `hermes config set` 命令改）
2. 写新 cron job 必查 `cronjob action='list'` 看 next_run_at——错位 = UTC 解释 → 立刻 patch
4. job 创建后跑 1 次验证：`hermes cron run <job_id>` → 看 last_run_at 是不是预期时间

**完整内容见 `references/cron-8am-timezone-bug.md`**（独立 reference，2026-06-06 新增）。

---

### 陷阱 17：cron 任务"静默无操作" — last_status=ok 但业务侧 0 变化（2026-06-06 实测，重大隐患）

> **本陷阱是 16 个旧陷阱的**上位类**——它们每一个都是"任务跑出 0 价值的某个子原因"**。本陷阱讲的是这一类问题的**共同诊断方法**。

**核心问题（3 段流水线模型）**：

```
[段 1: 任务定义]    [段 2: 脚本执行]    [段 3: 数据副作用]
jobs.json 字段      script 实际跑       pool.db / 文件系统真的变化吗
                ↓                ↓                    ↓
        last_status 取决于这里 = 段 2 是否报错
        ↑ 但段 1 错 / 段 3 错 = last_status 全 ok
```

**任何一段坏了，最后都标 `last_status=ok`，但实际业务侧完全没进展。**

**2026-06-06 单日实测发现 5 个独立静默坑**（**全部** `last_status=ok`）：

| 坑 | 类型 | 跑了多久 | 业务影响 |
|---|------|---------|---------|
| 8:30 prompt `--timeout 5` 错 | A2 任务定义 | 数天 | 推送静默退出 |
| 8:00 任务时区错乱（DST/UTC） | D1 跨段 | 数周 | 8:00 实际跑 16:00 |
| 3 个 m3 cron `script` 带 `--limit 200` | A2 任务定义 | 一直 | m3 cron 报错"找不到脚本" |
| `audit_08x05` script=None | A1 任务定义 | 26 天 | Layer 3 审核从未跑过 |
| m3 脚本 default `--source Tavily,AIHOT` | B1 SQL 过滤 | 一直 | 159 条中文平台话题永远 0 候选 |

**最阴险的案例（2026-06-06 B1 静默坑根因）**：

- `judge_topics_angle.py` 默认 `--source "Tavily,AIHOT"`
- WHERE 条件 `AND source IN ('Tavily', 'AIHOT')`
- 全部 159 条 approved+NULL 都是**微博/知乎/抖音**（Tavily/AIHOT 的 220 条已全部判完）
- 每次 cron 跑 → WHERE 过滤 → 0 条 → 输出 "✅ 没有待判定的" → exit 0 → last_status=ok
- **脚本"成功"跑了 N 周，0 业务价值**
- 8:30 推送 75 条高分全是 Tavily/AIHOT 旧数据，新进中文平台话题永远过不了 m3 那一关

**4 步诊断手册**（任何"任务跑了但没干活"时按顺序跑）：

```bash
# Step 1: 任务定义层（段 1）—— 查 jobs.json 字段
python3 -c "
import json
d = json.load(open('/home/renanzai/.hermes/profiles/content/cron/jobs.json'))
for j in d.get('jobs', []):
    print(f'{j[\"id\"]} | script={j.get(\"script\")} | schedule={j.get(\"schedule\",{}).get(\"expr\")}')
"

# Step 2: 任务执行层（段 2）—— last_status + 输出文件 mtime
hermes cron list
ls -la ~/.hermes/profiles/content/cron/output/<job_id>/

# Step 3: 业务副作用层（段 3，**关键！**）—— db delta
sqlite3 /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db \
  "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL"
# 数值应该随 cron 跑下降，**长期不变 = 静默坑**

# Step 4: 手动跑一次 + db delta
before=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL")
HERMES_CRON_SCRIPT_TIMEOUT=1800 python judge_topics_angle.py --limit 200
after=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL")
echo "delta: $((before-after))"  # 0 = 静默坑
```

**核心原则：3 段全部验证，单看 last_status=ok = 不够。**

**4 大类反模式**（详细见 `references/cron-silent-noop-patterns.md`）：
- **类别 A 段 1 任务定义错**：`script=null` / `script=xxx.py --arg` / 路径不在 scripts/
- **类别 B 段 2 脚本跑通但产出 0**：**SQL `source IN` 过滤排除全部数据 = 静默坑典型** / WHERE 条件有时间范围全部候选过期
- **类别 C 段 3 业务侧副作用 0**：commit 漏了 / 写错 db / 推送内容是缓存
- **类别 D 跨段组合**：任务依赖链断（8:00 错位 → 8:05 找不到数据）/ gateway 旧版未生效

**预防（最实用 3 招）**：

1. **必加守护脚本**：所有"如果有数据就处理，没有就退出"的脚本，加：
   ```python
   if not pending and total_null > 0:
       print(f"⚠️ WARNING: 有 {total_null} 条候选，但本轮过滤后 0 条", file=sys.stderr)
   ```

2. **任务定义改完必跑**：`hermes cron run <id>` → 看 db delta > 0 才算改对

3. **不要相信 last_status 单字段**：永远 4 个交叉验证（last_status=ok + last_error=None + last_delivery_error=None + 业务侧 db delta > 0）

**完整内容见 `references/cron-silent-noop-patterns.md`**（2026-06-06 新增，**4 大类 9 个反模式 + 4 步诊断手册 + 真实案例**）。

**本陷阱与现有 16 个陷阱的关系**：
- 陷阱 4-16 是"单点"问题（具体哪个字段 / 哪个 API 错）
- 陷阱 17 是"类"问题（**不管哪一段坏了，last_status 都报 ok**）——是上位类
- **排查任何 cron 异常时，先按陷阱 17 的 4 步手册定位"哪一段坏了"，再跳到对应单点陷阱看具体修法**

### 陷阱 20：cron wrapper 脚本**必须显式传所有参数**（2026-06-06 实测，新增高频坑）

> 这是 cron deployment 范畴的"防御性编程"原则。任何 wrapper bash 脚本（`judge_angles_cron.sh` 之类）**不能依赖被调脚本的默认值**。

**症状（2026-06-06 实测）**：
- `judge_angles_cron.sh` 只传 `--limit 200`，**不传** `--source` → 依赖 `judge_topics_angle.py` 默认值
- 脚本默认值 = `Tavily,AIHOT`（**这是已修复的旧默认值**）
- 如果未来有人/我手贱改回 `Tavily,AIHOT` 或其他值，cron 静默漏跑中文平台话题
- 8:30 推送又会变成"全靠旧数据"——**今天修的 bug 静默回归**

**根因**：
- wrapper 是 cron 任务和业务脚本的**胶水层**——它的责任不仅是"包 exec"，**更是"固定 cron 跑该跑的行为"**
- 业务脚本默认值是给"手动跑"用的（让人能 `--limit 50 --source 微博` 灵活调）
- cron 跑是**生产路径**——必须**完全确定**——不允许"默认值变了我跟着变"
- 现有 19 个陷阱**没有专门讲**这个 wrapper 防御性编程

**修法（永久规则）**：

```bash
#!/bin/bash
# ~/.hermes/profiles/content/scripts/judge_angles_cron.sh
# 2026-06-06 增强：显式传 --source 全 5 个 source（防御 m3 脚本默认值被改坏导致
#                 cron 静默漏跑中文平台话题——8:30 推送会全靠旧数据）
set -e
exec /home/renanzai/.hermes/hermes-agent/venv/bin/python3 \
    /home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py \
    --limit 200 \
    --source 微博,知乎,抖音,Tavily,AIHOT
```

**核心原则**：
- ✅ **wrapper 显式传**所有**会影响行为的参数**（`--source` / `--min-corr` / `--dry-run` 等）
- ✅ **wrapper 内 comment 写明**"防御 X 脚本默认值被改坏"
- ❌ **永远不要** `exec python judge_xxx.py` 不带任何参数（依赖默认值）
- ❌ **永远不要** `exec python judge_xxx.py $@` 透传 CLI（cron scheduler 不支持传 CLI——但万一未来支持，wrapper 不该有"灵活"借口）

**预防检查清单**：
- 写新 wrapper 时，过一遍："如果被调脚本默认值被改回坏值，cron 还会正常工作吗？"
- 不行 → 显式传参数 + 注释说明
- cron 跑前 `bash <wrapper.sh> --dry-run` 看优先级 source 列表是否对

**完整内容见 `references/cron-wrapper-defensive-args.md`**（2026-06-06 新增）。

### 陷阱 21：业务款 vs 引流款**不能用同一维度硬过滤**（2026-06-06 实测，新增方法论）

> 这是 Layer 2.5 + 8:30 推送**核心选品决策框架**的固化，**不是 bug**——是设计原则。

**核心问题**：
- 业务款（直接给 B2B AI 目标受众提供价值）和引流款（拉点击 + 制造情绪共鸣）的**评分模型不同**：
  - 业务款：m3 angle_score（内容可生产性）**主导**（≥7 是 hard filter）
  - 引流款：heat_score（平台热度）**主导**（m3 4-6 分即可，heat ≥0.7 是 hard filter）
- 但 m3 任务 cron 8:10/12:00/16:00 **统一**给所有 approved 话题打分（不分引流/业务）
- 8:30 推送 SQL 必须**分两套**过滤逻辑——不能一条 SQL 选两个 category

**2026-06-06 实测 76 高分话题分布**：
- Tavily/AIHOT 占 72/76 = **94.7%**（业务款金矿）
- 微博/知乎/抖音 4 条（引流款窄源）
- 19 条 ≥7 分业务款候选 + 3 条 mid 引流款候选 = 22 条选题空间

**决策框架（2026-06-06 固化）**：

| 维度 | 业务款 | 引流款 |
|---|---|---|
| m3 angle_score | ≥7（hard filter）| 4-6（mid 段可用）|
| heat_score | 中等即可（≥0.5）| **≥0.7**（hard filter）|
| source | Tavily/AIHOT 优先（金矿）| 微博/知乎/抖音 优先（真热点）|
| 三维度 c/b/t | 三维都 ≥6（可生产 + 可桥接 + 可 CTA）| c 维度 ≥6 即可（内容可生产）|
| risk_flag | 必 none（不能有 politics/disaster）| 必 none |
| 数量限制 | 1-2 条/天（产能天花板）| 1-2 条/天 |
| 桥接目标 | 引到"壹目贯维服务"CTA | 引到对应业务款（同一个 session）|

**反模式（禁止）**：
- ❌ **8:30 推送一条 SQL** 选两个 category → 池薄时容易凑数塞低分（2026-06-05 引流款被 angle=3 污染的根源）
- ❌ **用 heat_score 给业务款排序** → heat 0.2 的"5亿Tokens白送"（m3=8.0）会被埋没
- ❌ **用 m3 score 给引流款排序** → m3 1.3 的微博热搜永远出不了
- ❌ **业务款池空就放宽到 ≥6** → 1-2 条/天产能下不划算（阈值推荐 ≥7 已经在 2026-06-03 user 拍板）
- ❌ **引流款池空就放宽到 m3=0** → 凑数塞不可生产的（如 2026-06-05 的"天涯神帖" angle=3）

**实操 SQL 模板**（8:30 推送 prompt 用）：

```sql
-- 业务款候选
SELECT title, source, angle_score, heat_score, angle_reason
FROM topics
WHERE status = 'pending'
  AND review_status = 'approved'
  AND angle_score IS NOT NULL
  AND angle_score >= 7
  AND risk_flag NOT IN ('politics', 'disaster', 'privacy', 'sensitive')
ORDER BY angle_score DESC, heat_score DESC
LIMIT 5;

-- 引流款候选
SELECT title, source, angle_score, heat_score, angle_reason
FROM topics
WHERE status = 'pending'
  AND review_status = 'approved'
  AND angle_score IS NOT NULL
  AND angle_score >= 4 AND angle_score < 7
  AND heat_score >= 0.7
  AND risk_flag NOT IN ('politics', 'disaster', 'privacy', 'sensitive')
ORDER BY heat_score DESC, angle_score DESC
LIMIT 5;
```

**两个池子独立**——业务款池空时**只**显示业务款池空提示，**不**让引流款候选顶上去。

**完整内容见 `references/topic-selection-decision-framework.md`**（2026-06-06 新增）。
