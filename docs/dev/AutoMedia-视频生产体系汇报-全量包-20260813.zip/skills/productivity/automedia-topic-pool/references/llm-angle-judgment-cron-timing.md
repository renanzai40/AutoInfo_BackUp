# LLM 角度判定 cron 时序设计（2026-06-03 落地）

> ⚠️ **模型迁移记录**：本文件的 API 调用示例使用 `MiniMax-M3`。2026-06-08 壹目贯维已从 MiniMax 迁移到 DeepSeek-v4-flash。运行时实际调用的模型由 cron 脚本 `judge_topics_angle.py` 的 provider 配置决定。

## ⚠️ 关键教训：cron 必须在 08:30 推送**之前**跑完

**2026-06-03 user 纠正**：我最初设计 `judge_angles_09x30` 跑角度分，user 立刻说"角度分应该在 8:30 之前就打完吧，这样 8:30 的推送就可以把角度分考虑在内不是吗"。

**正解**：
- 08:30 推送 cron 是**硬 schedule**，角度分 cron 必须在它**之前**完成
- 不然推送时 angle_score 还没写进 pool.db，推送内容不会用上角度分
- 09:30 watchdog 也太晚（推送已发 1 小时）

## 实测时序（基于 6-02 实测数据）

| Cron | 实际跑多久（实测） | schedule | 用途 |
|---|---|---|---|
| 07:30 maintenance_01 | ~3 分钟 | `30 7 * * *` | freshness decay |
| 08:00 143d19e69a7c (采集) | **2-3 分钟** | `0 8 * * *` | 流1+流2+流3 采集 |
| 08:05 audit_08x05 | ~3-5 分钟 | `5 8 * * *` | Layer 3 语义审核 |
| **08:10 judge_angles_08x10 (新)** | **5-10 分钟** | `10 8 * * *` | **Layer 2.5 LLM 角度判定** |
| 08:30 7671da210b69 (推送) | ~3 分钟 | `30 8 * * *` | 推送 TOP5 给 user |
| 09:30 wdog_auto_media | 1 分钟 | `30 9 * * *` | Watchdog 健康检查 |

**时间窗口**：08:00 采集完成 (~08:02) → 08:05 audit 完成 (~08:07-10) → **08:10-08:25 角度分** → 08:30 推送

**角度分 cron 时长上限**：从 08:10 到 08:30 = **20 分钟 buffer**。实测 274.1s = 4.6 分钟，**富余 15 分钟**。

## jobs.json 实测字段（2026-06-03 落地）

```json
{
  "id": "judge_angles_08x10",
  "name": "AutoMedia 08:10 m3 角度分判定（8:30 推送前）",
  "schedule": {"kind": "cron", "expr": "10 8 * * *", "display": "10 8 * * *"},
  "script": "judge_topics_angle.py --limit 100",
  "no_agent": true,
  "deliver": "local",
  "notify_on_complete": true,
  "profile": "content"
}
```

**deliver=local**：失败才发飞书（不在日常推送里骚扰）
**no_agent=true**：不调 LLM agent，直接跑脚本
**notify_on_complete=true**：跑完通知我

## 角度分 cron 脚本（实测通过）

**位置**：`/home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py`

**参数**：
- `--limit N`（默认 100）：最多处理 N 条
- `--dry-run`：不写库，只 print 将要处理的
- `--source X,Y`：优先级 source 列表（默认 Tavily,AIHOT）
- `--min-corr N`：最低 corr 阈值（兜底过滤）

**调用 pattern**：
```bash
python3 judge_topics_angle.py --limit 100
```

**m3 API 调用 pattern**（脚本内部，已迁移到 DeepSeek-v4-flash）：
```python
payload = json.dumps({
    "model": "MiniMax-M3",
    "messages": [...],
    "temperature": 0.1,
    "max_tokens": 1000,   # 关键：必须 ≥1000，`` 思考占满截断
}, ensure_ascii=False)
cmd = ["curl", "-s", "--max-time", "120", "-X", "POST",
       "-H", "Content-Type: application/json",
       "-H", f"Authorization: Bearer {API_KEY}",
       "-d", payload, f"{BASE_URL}/chat/completions"]
# retry 3 次 + 1s sleep 防限流
```

## m3 提示词（5/5 验证）

```
你是「壹目贯维」内容总监助理。壹目贯维是 B2B AI 内容生产服务商。

判断下面这条话题标题，**能不能在 5-15 秒短视频里讲清楚、并和"AI 内容生产"业务自然搭上**。

【必须直接输出 JSON，不要 <think> 思考标签】
只输出严格 JSON：
{{"angle_score": <0-10>, "reason": "<一句话>", "suggested_angle": "<一句话或null>"}}

评分维度：
- 0-3: 标题无可展开事件（纯节日/纯人名/3字以下无数字）
- 4-5: 有事件但和 AI 业务零关联
- 6-7: 有清晰事件，可从某个角度切入 AI/内容生产
- 8-10: 完美业务款（AI 行业新闻/产品发布/技术突破）

正例：MiniMax M3 100万token=10 | DeepSeek 75%折扣=9 | 阿里十三薪=4
反例：天涯神帖=3 | 儿童节=1 | 姆巴佩=2
```

**关键设计**：
- "【必须直接输出 JSON，不要 <think> 思考标签】" — 防止 m3 思考占满
- Few-shot 正反例 6 条 — 让 m3 知道评分标准
- 评分维度说明 — 引导 m3 语义推理
- 业务上下文"壹目贯维是 B2B AI 内容生产服务商" — 让 m3 知道相关性判断标准

## ⚠️ Selection Bias 警告（2026-06-03 自审发现）

**278 条实证只覆盖了启发式判 B 档的话题，不是全量**：
- 我特意挑了启发式 B 档的 278 条喂给 m3
- 所以"启发式判 A 0 条 = 启发式 100% 漏判业务款"是**错读**
- **正确表述**："在 278 条启发式判 B 的样本里 m3 救回 38 条 (13.7%)"

**下次任何 m3 vs 启发式对比必须**：
1. 先声明**采样范围**（从哪个子集）
2. 不用"启发式 0% 命中" = "启发式漏判 100% 业务款"这种错读

## ⚠️ Tavily 内容农场污染（2026-06-03 自审发现）

**修正前**：Tavily 救回 25 条 m3≥6
**修正后**（去内容农场）：Tavily 真救回 **23 条** m3≥6（2 条农场嫌疑）

**内容农场识别信号**：
- 标题含 `\d+款AI` / `实战案例` / `建议收藏` / `横评` / `日报`
- 标题尾部带站点名（`10款AI视频生成工具，1天能快速生成100+条视频（建议收藏）`）

## 阈值推荐（修正后）

**推荐 ≥7**（不是 ≥6）：
- ≥6 含 5-6 分"勉强可做"9 条（m3 自己说"需要聚焦"），1-2 条/天产能下不划算
- ≥8 漏 3 条真新闻
- **≥7 留 29 条业务款核心**（修正后 26 条真业务款），数字契合 1-2 条/天产能

**6-7 分边界条** → 人工复核（m3 自己也不确定的那部分）

## 已知失败模式（踩过的坑，写给未来 session）

### 1. max_tokens 必须 ≥1000
**坑过**：原本 `max_tokens=300` 触发 m3 思考占满，截断 JSON → 解析失败。
**修法**：`max_tokens=1000`（实测 0 失败）。

### 2. retry 3 次 + 慢启动
**坑过**：42 条跑到 20 条时 API 返回空 stdout 崩了。
**修法**：
```python
for attempt in range(3):
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=130)
    if not r.stdout:
        time.sleep(5 * (attempt + 1))  # 5s, 10s, 15s
        continue
    # 解析 + 处理
```

### 3. 字段名一致性
**坑过**：旧 log 字段是 `corr`，rerun 脚本我写 `correlation_score` → KeyError 崩 3 次。
**修法**：所有引用用 `r.get("corr") or r.get("correlation_score") or 5.0`。

### 4. Python 字符串字面 `\u`
**坑过**：写"修复 \u escape bug"脚本时 docstring/字符串里写 `\u escape` → SyntaxError。
**修法**：用 raw string `r"..."` 或描述时用 "unicode escape" 英文。
