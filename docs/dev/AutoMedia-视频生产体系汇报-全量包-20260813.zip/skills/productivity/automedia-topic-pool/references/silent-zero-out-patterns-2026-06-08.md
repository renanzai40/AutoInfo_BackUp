# 静默零入库 Pattern · 2026-06-08 完整案例

> **核心问题**：采集脚本"跑通 + exit 0 + cron output 写'流 X: N 条'"，**但 N 是 0**——不报错、不告警、不被发现。**跑了 4+ 天**才被用户觉察（"今天 AIHOT 怎么只有 1 条"）。

## 一、事故时间线（2026-06-08 10:30）

| 时间 | 事件 |
|---|---|
| 6-04 早上 | v3 采集脚本 `in` bug 引入（修改 minimax_layer2_gate 调用方式） |
| 6-04 ~ 6-08 | 流1+流2 入库永远 0，但流3（AIHOT）偶尔入库 1-2 条，**业务上"看起来在工作"** |
| 6-04 ~ 6-08 | 8:30 推送用历史 465 条 angle≥7 库存撑场面，无人察觉"今天 0 新增" |
| 6-08 10:30 | user 报告 "今天 AIHOT 怎么只入库 1 条"——开始排查 |
| 6-08 10:50 | 定位 P0：`item['title'] in flow1_related` 永远 False（flow1_related 是 list of dict） |
| 6-08 11:00 | 修 hash 公式 + AIHOT 跳过信息密度 + minimax_dedup 本地 hash fallback + P0 `in` 修 |
| 6-08 11:30 | 补采跑完：14 条新入库（修前 1 → 修后 9 AIHOT + 5 Tavily）|

## 二、根因详解：P0 `in list_of_dict`

### 2.1 代码位置

`auto_media_hot_collection_v3_20260525.py` L602（修前）：
```python
flow1_related = minimax_layer2_gate(
    [{'title': t, 'source': ...} for t in flow1_kept],
    MINIMAX_KEY
)
# flow1_related 是 list of dict (item, 含 title + source)

flow1_for_db = [item for item in flow1_raw if item['title'] in flow1_related]
#                            ^^^^^^^^^^^^^^^^^^^ str in list_of_dict
# 永远 False（除非 dict 里有 __eq__ 被改写过）
# → flow1_for_db = []  →  流1 入库永远 0
```

L614 同样问题（流2）：
```python
flow2_top15 = [item for item in flow2_unique if item['title'] in flow2_related][:15]
# 同 flow1，永远 0
```

### 2.2 Python type-mismatch 必死的 4 个 pattern

| 错法 | 示例 | 结果 |
|---|---|---|
| **str in list_of_dict** | `'foo' in [{'title': 'foo'}]` | 永远 False（本次踩中） |
| **str in list_of_list** | `'foo' in [['foo'], ['bar']]` | 永远 False（除非 'foo' 整体是 list 的元素） |
| **str in dict** | `'foo' in {'foo': 1}` | True（'in' 检查 key 不是 value） |
| **dict in list_of_str** | `{'title': 'foo'} in ['foo', 'bar']` | 永远 False |

### 2.3 为什么 4+ 天没人发现

| 假象 | 真相 |
|---|---|
| `last_status=ok` | hermes cron 不严格查 exit code（陷阱 6）|
| 流3 偶尔 1-2 条入库 | 业务上"看起来在工作" |
| 8:30 推送正常 | 用历史 465 条 angle≥7 库存 |
| cron output "流1: 0 / 流2: 0 / 流3: 1" | 0 不引起警觉（历史上偶尔就有）|

**真正的报警信号被忽略**：
- **"3 个流全 0 / 1"组合** = 强 P0 静默信号
- **"今天 created_at 入库数 < 5"** = 同样信号
- 两个信号 6-04 ~ 6-08 每天都触发，但 8:00 cron output 没人交叉对比

## 三、诊断手册（任何"池子没新内容"时按此跑）

### Step 1：今/昨日入库数 vs 抓取期望

```sql
-- 今天入池数
SELECT source, COUNT(*) AS n
FROM topics
WHERE created_at >= 'TODAY'  -- e.g. '2026-06-08'
GROUP BY source;
-- 预期：每个 source > 0（除非源挂了）

-- 昨天入库数（对比基线）
SELECT source, COUNT(*) AS n
FROM topics
WHERE created_at >= date('now', '-1 day') AND created_at < 'TODAY'
GROUP BY source;
-- 正常基线：流1 5-15 / 流2 5-10 / 流3 5-15
```

### Step 2：cron output 写"流 X 入库 N 条" vs SQL 实际行数

```bash
# 8:00 cron output
cat ~/.hermes/profiles/content/cron/output/143d19e69a7c/2026-06-08_08-02-51.md
# 找 "=== 最终入库统计 ===" 段：
#   流1(热搜): 0条 | 流2(Tavily): 0条 | 流3(AIHOT): 1条
#   异常信号：流1+流2 同时 0

# 验证 SQL 实际入库
sqlite3 pool.db "SELECT source, COUNT(*) FROM topics WHERE created_at >= '2026-06-08 08:00:00' GROUP BY source"
# AIHOT    1
# → 流1+流2 应该非 0
```

### Step 3：找到具体行号

```bash
# 看 v3 脚本里 "in xxx_related" 的用法
grep -n "in flow1_related\|in flow2_related\|in flow3_related" auto_media_hot_collection_v3_20260525.py
# 修前 L602, L614

# 检查每个 in 操作的右侧 list 类型
python3 -c "
import auto_media_hot_collection_v3_20260525 as v3
# 注意：不能 importlib 跑（陷阱 2）— 这是 v3 假 import 真执行
# 正确做法：手动看 minimax_layer2_gate 函数返回值类型
"
# minimax_layer2_gate 在 L497-504 实现:
#   filtered.append(item)  ← 返回 list of dict
# 但调用方当 list of str 用 → type mismatch
```

### Step 4：修法 + 防回归

**修法 A（推荐，立即可用）**：
```python
flow1_related_titles = {r['title'] for r in flow1_related}
flow1_for_db = [item for item in flow1_raw if item['title'] in flow1_related_titles]
```

**修法 B（用 list of dict 直接过滤）**：
```python
flow1_for_db = [item for item in flow1_raw
                if any(item['title'] == r['title'] for r in flow1_related)]
```

**3 道硬保险（防回归）**：

1. **type assert（开发期）**：
```python
assert all(isinstance(r, dict) for r in flow1_related), \
    f"flow1_related expected list of dict, got {type(flow1_related[0])}"
```

2. **counter sanity check（运行时）**：
```python
# 采集脚本入口/出口
total_input = len(flow1_raw) + len(flow2_unique) + len(flow3_normalized)
total_inserted = len(flow1_for_db) + len(flow2_top15) + len(flow3_passed)
if total_input >= 50 and total_inserted == 0:
    print(f"⚠️ 抓 {total_input} 条但入库 0 条——P0 静默零入库 bug")
    sys.exit(2)  # 强制 cron 报 error
```

3. **cron output db delta 验证**：
```bash
# 8:00 cron 末尾加:
before=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE created_at >= date('now')")
# 跑采集脚本
after=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE created_at >= date('now')")
delta=$((after-before))
echo "今日入库 delta: $delta"
if [ $delta -lt 5 ] && [ $total_input -gt 50 ]; then
  echo "❌ 抓 N 条但入库 < 5——P0 静默 bug" >&2
  exit 2
fi
```

## 四、与陷阱 17（cron 静默无操作）的对比

| 维度 | 陷阱 17（外层）| 陷阱 27（内层，本案例）|
|---|---|---|
| 触发位置 | cron 任务定义/调度层 | 采集脚本内部某行代码 |
| 表现 | `last_status=ok` 但业务侧 0 进展 | `last_status=ok` + 脚本"成功跑" + 入口数据齐全 + 出口入库 0 |
| 诊断 | 看 jobs.json + last_status + db delta | 看 cron output "流 X: N 条" + SQL 验证 + 找 type-mismatch 行 |
| 修法 | 改 jobs.json / 改 script 路径 / 修 wrapper  | 改 `in` 用法 / 加 type assert / 加 sanity check |
| **共同防御** | **业务侧 db delta > 0 作为最终健康指标** | **业务侧 db delta > 0 作为最终健康指标** |

**两个陷阱都靠同一条原则**："流程健康"（exit code / last_status）≠ "业务健康"（db delta / 文件变化）。**永远交叉验证**。

## 五、误诊陷阱（避免下次重蹈覆辙）

1. **❌ "last_status=ok = 任务成功"** → 真实业务可能入库 0
2. **❌ "3 个流 0/1 模式 = 偶尔正常"** → 实测 4+ 天每天都是 0/1，从未正常过
3. **❌ "手动跑一遍 + exit 0 = 修好了"** → 没看 db delta 不算修好
4. **❌ "流3 入库了 1 条 = 系统在工作"** → 可能是兜底/运气，不证明主路径 OK
5. **❌ "m3 解析失败 2 次 = MiniMax API 挂了"** → 实际是修错了 type 解析（list of dict），与 m3 无关

## 六、相关陷阱索引

- **陷阱 6**：`last_status='ok'` 是假阳性 — hermes 不严格查 exit code
- **陷阱 17**：cron 任务"静默无操作" — last_status=ok 但业务侧 0 变化（外层版）
- **陷阱 27**：本案例 — 采集脚本内部 `in list_of_dict` 静默零入库（内层版）
- **`references/cron-silent-noop-patterns.md`**：陷阱 17 的完整 4 大类 9 反模式
- **`references/topic-pool-integrity-audit-2026-06-08.md`**：5 步审计 recipe（含本案例 Step 0）
