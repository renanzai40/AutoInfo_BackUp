# 并行 LLM 批量处理：ThreadPoolExecutor 模式

> **触发**：设计/改批量 LLM 调用脚本（如 `judge_topics_angle.py`），预期调用次数 ≥ 20。
> **核心模式**：Phase 1 并行 API 调用 + Phase 2 串行 DB 写库。
> **落地时间**：2026-06-10（`judge_topics_angle.py`）

## 问题背景

`judge_topics_angle.py` 原为串行 for 循环，每条话题依次调 DeepSeek-v4-flash API：
```
for each topic:
    call_llm()  # ~30-60s HTTP
    time.sleep(1)  # 限流
    write DB
```

**实测耗时**（39 条 pending 时）：
- 串行：39 × ~46s = **~30 分钟**
- cron 默认 timeout：**300s**
- 结果：永远超时，永远 0 条写入

## 解决方案：二阶段并行模式

```
Phase 1: ThreadPoolExecutor(max_workers=5)
  ┌─ worker 1 ─┐  ┌─ worker 2 ─┐  ┌─ worker 3 ─┐
  │ call_llm()  │  │ call_llm()  │  │ call_llm()  │  ...
  └─────────────┘  └─────────────┘  └─────────────┘
      as_completed → 收集 (r, parsed, err) 元组列表

Phase 2: 单线程 for 循环
  for (r, parsed, err) in api_results:
      parse → UPDATE topics → commit every 20
```

### 为什么是二阶段（不是边收边写）

| 方案 | 优点 | 缺点 |
|------|------|------|
| **边收边写**（as_completed 里直接 UPDATE） | 进度实时 | SQLite 写并发风险；SIGTERM 时写了一半处于不确定状态 |
| **二阶段✅**（收齐再写） | 写库无竞争；SIGTERM 只丢 Phase 2（快且可重做） | 写完前 DB 无变化（但 Phase 1 已跑完，重跑只需写库阶段） |

### 为什么 max_workers=5

| Workers | 预期 39 条耗时 | 风险 |
|---------|---------------|------|
| 1（串行） | ~30 min | 超时 |
| 5 | ~6 min | 低 — 5 个并发 curl，约 5 RPM |
| 7 | ~4-5 min | 中 — 可能触发 API 限流 |
| 10 | ~3-4 min | 高 — opencode-go 可能 429 |

**选择 5**：保守起步。5 并发 × 45s avg = 39/5 ≈ 8 轮 × 45s ≈ 6 分钟。加上 `HERMES_CRON_SCRIPT_TIMEOUT=900` 兜底，安全。

## 关键代码

```python
from concurrent.futures import ThreadPoolExecutor, as_completed

# Phase 1: 并行 API 调用
api_results = []
with ThreadPoolExecutor(max_workers=5) as executor:
    future_to_topic = {
        executor.submit(call_llm, r["title"], r["source"], r["correlation_score"]): r
        for r in pending
    }
    for future in as_completed(future_to_topic):
        r = future_to_topic[future]
        try:
            parsed, err = future.result(timeout=130)
            api_results.append((r, parsed, err))
        except Exception as e:
            api_results.append((r, None, f"{type(e).__name__}"))

# Phase 2: 单线程写库
for i, (r, parsed, err) in enumerate(api_results, 1):
    # ...parse + UPDATE topics...
    if i % 20 == 0:
        con.commit()
con.commit()
```

## 与原串行模式的差异

| 项目 | 原串行 | 新并行 |
|------|--------|--------|
| API 调用 | 1 个接 1 个 | 5 个并发 |
| `time.sleep(1)` | 有限流 | **移除**（max_workers=5 替代限流） |
| DB 写 | 每条 immediate | Phase 2 批量写 |
| 进度打印 | `[i/len]` 按顺序 | Phase 1: `API {done}/{total}`（无顺序）<br>Phase 2: `写库 {i}/{total}`（有顺序） |
| ETA 计算 | 线性 rate 推算 | Phase 2 只统计 elapsed，不做 ETA |
| SIGTERM 影响 | 丢当前已跑完的 N 条 | Phase 1 完成 → Phase 2 写一半时被杀，只丢已写的部分<br>Phase 1 未完成 → 当前已完成的已收集在 `api_results` 但没写 DB（重跑即可） |

## 陷阱

### 陷阱 1：`future.result(timeout=N)` 的 timeout 必须 ≥ API 最大超时

`call_llm()` 内部有 `curl --max-time 120`，所以 `future.result(timeout=130)` 必须 **> 120**，否则 worker 线程还在等 curl 响应就被 future.result 抛出 TimeoutError。

### 陷阱 2：`call_llm()` 的 retry 逻辑不受并行影响

`call_llm()` 内部有 3 次 retry（带 sleep）。在并行模式下，每个 worker 线程独立走 retry，互不阻塞。这是安全的——retry 是本地函数内 sleep，不是全局锁。

### 陷阱 3：异常处理必须盖 `Exception` 基类

```python
# 正确：捕获所有异常（包括 curl 超时、JSON 解析、断网等）
try:
    parsed, err = future.result(timeout=130)
except Exception as e:  # 不能只写 ValueError/TypeError
    api_results.append((r, None, f"{type(e).__name__}"))
```

`as_completed` 不吞异常，但 `future.result()` 会把子线程抛的异常传递到主线程。主线程必须 catch `Exception`（不是更窄的类型）才能保证健壮。

### 陷阱 4：`api_results` 的顺序是完成任务顺序，不是提交顺序

这意味着 Phase 2 的 `[i/len]` 计数器**不映射**原始 pending 列表的索引。这是设计正确的——并行任务没有自然顺序。不要试图按 `pending` 顺序重排 `api_results`（无意义，只会加开销）。

### 陷阱 5：并发数不能超过 API 提供商的 RPM/RTPM 限流

DeepSeek-v4-flash (via opencode-go) 没有公开限流文档。5 concurrent × ~2 RPM = ~10 RPM 是保守值。如果未来遇到 429 错误，三步应对：
1. 减少 `max_workers` 到 3
2. 在 `call_llm()` 的 retry 逻辑里加 429 特判（当前重试对 200/非 200 不区分）
3. 若持续 429，退回串行 + `--limit 20` + 900s timeout

## 配合措施

```bash
# 必须在 .env 设置（cron 启动时读取）
echo 'HERMES_CRON_SCRIPT_TIMEOUT=900' >> ~/.hermes/profiles/content/.env
```

单靠并行化不够——39 条 × 5 workers ≈ 6 分钟仍超过 300s。`HERMES_CRON_SCRIPT_TIMEOUT=900` 是并行化的前提条件（不是可选）。

## 与已有机制的关系

| 已有机制 | 与并行的关系 | 文件 |
|----------|-------------|------|
| commit_in_loop（每 20 条） | Phase 2 保留，每 20 条 commit | `cron-m3-script-hardening.md` |
| SIGTERM handler | Phase 2 被 SIGTERM 时 commit 已处理部分 | `cron-m3-script-hardening.md` |
| `--limit` 字面值 ≠ 实际处理数 | 并行化不改这个行为——仍是 SQL WHERE 条件和 unique 入参决定实际行数 | `manual-m3-run-workflow.md` |
