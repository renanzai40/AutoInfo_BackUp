# 🔒 池子完整性的 4 道防线设计（2026-06-08 固化）

## 🔒 池子完整性的 4 道防线设计（2026-06-08 固化）

> **核心问题**：陷阱 24/25/26 是"单点 bug"。**完整防御需要多层防线 + 误判分析**。本章节讲的是从"修 bug"升级到"防御体系"。

### 双 Source of Truth 的事实表

```
PROJECT_REGISTRY.json (active + archived)    =  事实表 (已交付清单)
                       ↕ 单向同步
Pool/pool.db (topics.status)                  =  待选池 (待生产/已选/已交付)
```

**关键设计原则**：**PROJECT_REGISTRY 是事实表，pool.db 是待选池**——两个不能双向同步，必须有**单向自动同步**：已交付 → pool.db archived。

### 4 道防线架构

```
                   4 平台/Tavily/AIHOT 原始流
                              ↓
   ┌─── 防线 1（采集源头去重）── 价值低, 易误判 ─────────┐
   │  8:00 脚本读 PROJECT_REGISTRY active titles          │
   │  INSERT 前过滤掉已交付的                              │
   │  ⚠️ 真实拦截率 ≈ 0 (8:00 是当日热搜, 99% 不重名)    │
   └───────────────────────────────────────────────────────┘
                              ↓  入库 pool.db
   ┌─── 防线 2（推送层硬过滤）── 已落地 ──────────────────┐
   │  8:30 SQL: WHERE status='pending' AND review_status='approved' │
   │            AND angle_score IS NOT NULL AND angle_score >= 7   │
   │            AND topic_id NOT IN (已交付 topic_id)              │
   └───────────────────────────────────────────────────────────────┘
                              ↓  用户选 → status='selected'
                         启动生产链路
                              ↓  upload_draft.py
   ┌─── 防线 3（交付自动归档）── 已落地 ──────────────────┐
   │  regen_project_registry.py 末段 + DB 回写            │
   │  触发: upload_draft.py 末尾 hook (待接) + 09:30 兜底 │
   └───────────────────────────────────────────────────────┘
                              ↓  pool.db status='archived'

   ┌─── 约束层（DB 物理约束）── 未落地 ─────────────────┐
   │  SQLite 部分唯一索引:                                │
   │  CREATE UNIQUE INDEX idx_active_title                │
   │    ON topics(title) WHERE status != 'archived'       │
   │  → "未归档的 title 物理唯一"                         │
   └────────────────────────────────────────────────────────┘
```

### 误判分析：5 种匹配方案对比

**核心 trade-off**：**过度拦截风险 vs 漏拦截风险**。壹目贯维用户的偏好是**过度拦截 > 漏拦截**——宁可漏拦也别误杀新热点。

| 方案 | 实现 | 过度拦截 | 漏拦截 | 推荐度 |
|---|---|---|---|---|
| A. `title == title` 严格相等 | 3 行 | 几乎 0 | 高 | ⭐⭐ |
| B. **normalize(去空格/标点/简繁) 后相等 + 30 天窗口** | 20 行 | 极低 | 中 | ⭐⭐⭐⭐ |
| C. 关键词组合（公司+动作）| 50 行 | **中** | 中 | ⭐⭐ |
| D. embedding 相似度 ≥ 0.92 | 200 行 + LLM | **高** | 极低 | ❌ |
| E. 三元组 NER（公司+产品+动作）| 500 行 + 模型 | 低 | 中 | ⭐⭐ |

### 误判案例（禁止使用 D 方案）

**反例 1（embedding 误判）**：
- 已交付：「OpenAI 春节红包活动」
- 新采集：「OpenAI 端午活动上线」
- embedding 相似度 ≈ 0.88 → **误判成同一事件被拦**
- 实际：2 个不同节日活动，应独立处理

**反例 2（关键词组合误判）**：
- 已交付：「DeepSeek 模型降价 75%」
- 新采集：「DeepSeek 模型降价 50%」（新数据, 但被关键词命中拦截）

### 推荐：方案 B（normalize 精匹配）+ 30 天时间窗口

```python
import re, json
from datetime import datetime, timedelta

_reg = json.load(open('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/PROJECT_REGISTRY.json'))
_WINDOW_DAYS = 30
_cutoff_iso = (datetime.now() - timedelta(days=_WINDOW_DAYS)).isoformat()

def _normalize(title: str) -> str:
    t = title.lower()
    t = re.sub(r'[\s\u3000\.,。、,;!?:：；！？「」『』【】《》"""''()()·…—\-]', '', t)
    return t

_delivered_set = set()
for p in _reg.get('active', []):
    info = p.get('info', {})
    if info.get('created_at', '9999') >= _cutoff_iso:
        t = info.get('topic', '')
        if t:
            _delivered_set.add(_normalize(t))

# INSERT 前 (3 道保险):
# if _normalize(item['title']) in _delivered_set: continue
# 保险 1: dry-run 模式可看拦截清单
# 保险 2: 拦截日志写 disk, 7 天可查
# 保险 3: 白名单覆盖, 紧急放行某 title
```

### 推荐方案的 4 个不误判防御点

1. **精匹配不是模糊匹配** — "OpenAI 春节" 和 "OpenAI 端午" normalize 后完全不同, 不拦
2. **30 天窗口** — 1 年前做过的 "巴西世界杯 26 人名单" 今天又上热搜, **不挡**
3. **normalize 防御"换空格漏匹配"** — "Hy-Memory" vs " Hy-Memory " 算同一个
4. **信息增量的转载不误拦** — "Runway Aleph 2.0 上线 30 秒视频编辑" vs 已交付的 "Runway API 推出 Aleph 2.0 视频编辑功能", normalize 后**不完全相等**, 不挡

### 工程判断：采集源头去重真实价值低

**8:00 采集的是当日实时热搜, 与 "几天前做的题" 几乎 99% 不重名**：
- 真重复来源是**同一天内同源重复**（已被 `INSERT OR IGNORE` 拦住）
- 跨天的"同题换角度"本来就是新话题（不该拦）

**所以防线 1 在生产环境的真实拦截率 ≈ 0** —— 更多是"心理安慰"。

**真正值钱的是防线 3（交付自动归档）** —— 这才是用户问的"以后不再出现"的关键:
- ✅ 已落地（regen_project_registry.py 末尾回写）
- 触发：upload_draft.py 末尾 hook（待接）+ 09:30 watchdog 兜底 cron（推荐）

### 推荐组合：3 道防线 + 1 个兜底

**实际推荐**（不落防线 1, 因为价值低 + 误判风险）：

| # | 防线 | 状态 | 价值 |
|---|---|---|---|
| 2 | 推送层 status 过滤 | ✅ 已落地 | 高（推到用户眼前） |
| 3 | 交付自动归档 | ✅ 已落地 | 高（所有非推送路径） |
| 兜底 | 09:30 watchdog 跑 regen | 待落 | **关键**（hook 漏触发也兜底）|
| 约束 | DB 部分唯一索引 | 待落 | 兜底兜底（DB 物理拦截） |

**反模式（永久禁止）**：
- ❌ 用 embedding 拦截 → 误判 "OpenAI 春节" 和 "OpenAI 端午" 为同一事件
- ❌ 用关键词组合拦截 → 漏 "DeepSeek 价格调整"（同事件但换词）
- ❌ 永久拦截（无时间窗口）→ 1 年后"巴西世界杯"又上热搜, 拦错
- ❌ 把防线 1 当主线 → 真实拦截率 ≈ 0, 还引入误判风险
- ❌ 不落 09:30 兜底 → hook 漏触发 = 沉默腐烂（用户报告后才修）

### 关联实战案例（2026-06-08）

执行步骤（实跑 5 步全过）：
1. 备份：`auto_media_hot_collection_v3_20260525.py.bak.<ts>_hash-fix` + `regen_project_registry.py.bak.<ts>_db-writeback`
2. patch 3 处 hash 公式（陷阱 24 修法）
3. SQL 改 5 条已交付为 archived（陷阱 25 一次性清理）
4. patch regen_project_registry.py 末段加 11 号段（陷阱 25 自动化修法）
5. patch jobs.json 改 audit_08x05 prompt SQL（陷阱 26 修法）

**验证**：
- regen 跑一次 → 自动找出 9 个已交付（agent 之前手动只找 5 个, regen 多找 4 个）→ 4 条 selected/writing 自动改 archived
- 新 hash 公式下, 4 个 source 跨平台同 title 唯一
- audit SQL 加 `AND status='pending'` 后, 历史漂移数据不再被审

**新发现**（修陷阱 25 时的副产物）：
- 29 个 active 项目里**只有 9 个有 topic_id 字段**（schema 不统一）
- regen_project_registry.py 从 projects/ 目录读 33 个 active（比 registry 多 4 个）
- 教训：不能只靠 agent 一时 SQL 查到的数 —— 需要"自动回写"机制保证事实表唯一来源

---
