# Cron 时序设计原则

> 2026-06-03 教训：角度分必须在 08:30 推送之前打完。触发：设计/调整 cron 时序、改 jobs.json、调试 cron 实际耗时。

## 核心原则：**依赖关系 = 时序约束**

每个 cron job 的设计必须考虑**下游消费者**什么时候需要它的数据。
如果 job A 的输出被 job B 消费，**A 必须在 B 之前跑完**。

### 错误示范（2026-06-03 我犯的错）
```
08:00 采集 → 08:05 audit
09:30 ★ judge_angles（角度分）     ← 错！晚于 08:30 推送 1 小时
08:30 推送（推送时看不到 angle_score）
```
**问题**：08:30 推送时 angle_score 全是 NULL（m3 还没跑），推送的"业务款 TOP3"用的是旧启发式评分，**13.7% 业务款核心被漏掉**。

### 正确时序（user 纠正后，2026-06-03 落地）
```
07:30 maintenance
08:00 采集 → 08:02 完成（实测 2-3 分钟）
08:05 audit → 08:07 完成（实测 2-3 分钟）
08:10 ★ judge_angles_08x10 → 08:15 完成（实测 4.6 分钟）
08:30 推送 ★ angle_score 已经是新的
09:30 watchdog
```

**窗口分析**（08:05 完成 ~ 08:30 开始 = 25 分钟可用）：
- 角度分 ~5-10 分钟（50-100 条 m3 调用 + retry + 慢启动）
- buffer 15-20 分钟（防 audit 跑超）
- 08:30 推送直接看 angle_score

## 实测耗时基线（2026-06-03）

| Job | 实际耗时 | 起止时间 |
|---|---|---|
| 08:00 采集 (v3) | 2-3 分钟 | 08:00:00 → 08:02:06 / 08:03:22 |
| 08:05 audit_08x05 | 2-3 分钟 | 08:05 → 08:07 |
| 08:10 judge_angles_08x10 | 4.6 分钟 | 08:10 → 08:15 (20 条) / 预计 5-10 分钟（50-100 条）|
| 08:30 推送 | 2.7 分钟 | 08:30 → 08:32:44 |
| 09:30 watchdog | 0-5 分钟 | 09:30 起 |

## 设计新 cron 的 3 步检查

1. **谁消费这个 job 的输出？** → 查下游 job 什么时候跑
2. **上游 job 实际跑多久？** → 看 `last_run_at` vs schedule 起点的差（不是估）
3. **窗口够不够？** → (下游起点 - 上游完成点) vs (job 实际耗时 + 30% buffer)

如果窗口 < 5 分钟：**不要加新 cron**，嵌入上游或合并。

## 错误 vs 正确决策

| 情况 | 错误决策 | 正确决策 |
|---|---|---|
| 角度分给 08:30 推送用 | 09:30 跑（晚 1 小时） | 08:10 跑（早 20 分钟） |
| cron 跑超 5 分钟 | 直接嵌入下游 | 拆 job 或扩 cron 间隔 |
| m3 API 限流 | 重试到死 | retry 3 次 + 1s sleep + 失败退出（下次补） |
| 时序冲突 | 改 cron schedule | 改 v3 脚本里的并行/串行 |

## 时序冲突的诊断

```bash
# 看每个 job 实际什么时候跑完
for j in $(jobs | jq -r '.jobs[].id'); do
  echo "=== $j ==="
  ls -la ~/.hermes/profiles/content/cron/output/$j/ | tail -3
done
```

**关注**：每个 job 的 `mtime` vs 它的 `schedule` 起点 = 实际耗时。

## 08:30 推送 prompt 的关键改动（必做）

角度分在 08:10 跑完 → 08:30 推送要**看 angle_score 字段**。当前 prompt 必须改：

```sql
-- 旧 (2026-06-03 之前)
SELECT topic_id, title, category, heat_score, correlation_score, freshness_score, source
FROM topics
WHERE status = 'pending' AND review_status = 'approved'
ORDER BY category, heat_score DESC

-- 新 (2026-06-03 user 确认)
SELECT topic_id, title, category, heat_score, correlation_score, freshness_score, source,
       angle_score, angle_reason                                -- 新加 2 列
FROM topics
WHERE status = 'pending' AND review_status = 'approved'
ORDER BY category, heat_score DESC
```

推送格式也要改（让用户看到 angle_score）：
```
引流款 TOP3（热度驱动，按综合评分排序）：
1. [话题名] 综合评分=XX | 角度分=XX | 来源：... | 分析：[...]

业务款 TOP3（关联驱动，**优先选 angle_score >= 7 的**）：
1. [话题名] 综合评分=XX | 角度分=XX | 角度：[m3 reason 简写] | 来源：... | 分析：[...]
```

智能体推荐也要优先 angle_score >= 7：
```
智能体推荐：
- 引流款首选：TOP1（理由）
- 业务款首选：**优先选 angle_score >= 7 的 TOP1**（m3 角度分理由：[m3 reason 简写]）
- 说明为什么这两条最适合今天生产
```

## 改 jobs.json 的实操（Python 而非 patch 工具）

按 memory 教训：patch 工具的 whitespace 严格匹配对 jobs.json 的 indent=2 写入常失败。**改 jobs.json 必用 Python str.replace**：

```python
import json, shutil
from datetime import datetime
from pathlib import Path

JOBS = Path("/home/renanzai/.hermes/profiles/content/cron/jobs.json")
TS = datetime.now().strftime("%Y%m%d_%H%M%S")
BAK = f"/tmp/jobs.json.bak.{TS}_add_judge_angles"
shutil.copy2(JOBS, BAK)  # 必做：备份

jobs_data = json.loads(JOBS.read_text())

# 构造新 job
new_job = {
    "id": "judge_angles_08x10",
    "name": "AutoMedia 08:10 m3 角度分判定（8:30 推送前）",
    "schedule": {"kind": "cron", "expr": "10 8 * * *", "display": "10 8 * * *"},
    "schedule_display": "10 8 * * *",
    "script": "judge_topics_angle.py --limit 100",  # 注意是相对文件名（陷阱 4）
    "no_agent": True,
    "deliver": "local",  # 失败才发飞书，不日常推送
    "enabled": True,
    "state": "scheduled",
    "repeat": {"times": None, "completed": 0},
    "created_at": datetime.now().isoformat(),
    "profile": "content",
}

# 插入到合适位置（在 08:00 采集之后，audit 之前）
jobs_data["jobs"].insert(1, new_job)  # index 1 = audit 之前
jobs_data["updated_at"] = datetime.now().isoformat()
JOBS.write_text(json.dumps(jobs_data, ensure_ascii=False, indent=2), encoding="utf-8")
```

**注意 script 字段是相对文件名**——必须复制真文件到 `~/.hermes/profiles/content/scripts/`（陷阱 4）：
```bash
cp /path/to/judge_topics_angle.py ~/.hermes/profiles/content/scripts/
```

## 一句话总结

**任何 cron 设计**：
1. **先查下游消费者什么时候需要**（不是上游什么时候方便）
2. **看实测耗时**（不是估的）
3. **窗口 < 5 分钟** → 不加新 cron，嵌入上游
4. **改 jobs.json 必用 Python**（patch 工具 whitespace 不匹配）
5. **改 08:30 推送**让它看新字段（不止加 cron）
