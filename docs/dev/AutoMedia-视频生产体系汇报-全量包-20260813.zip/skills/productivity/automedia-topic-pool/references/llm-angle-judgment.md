# LLM 角度判定层（Layer 2.5）完整方法论

> 2026-06-03 实测完整方法论。触发：设计/调整 Layer 2.5 LLM 角度判定、改 prompt、debug 实证结果。
>
> ⚠️ **模型迁移记录**：本文件示例用的 `MiniMax-M3` 是历史运行模型。2026-06-08 壹目贯维已从 MiniMax 迁移到 DeepSeek-v4-flash。文档中的评分示例（MiniMax M3 = 10 分等）保留为算法参考，运行时实际调用的模型由 cron 脚本 `judge_topics_angle.py` 的 provider 配置决定。确认当前运行时模型后再改 prompt。

## 一句话核心

**`correlation_score` 是"是不是 AI 行业话题"（关键词层面）**。
**`angle_score` 是"能不能拍成 AI 业务款视频"（内容可生产性）**。
两者互补，业务款核心优先用 `angle_score >= 7`。

## 算法（实测 prompt 设计）

**模型**：`DeepSeek-v4-flash`（max_tokens=1000，temperature=0.1）

**Few-shot 正例**（模型看的"什么是好"）：
- `MiniMax M3:100万token上下文与原生多模态` → **10 分**（AI 模型发布，业务款核心）
- `DeepSeek将对其旗舰AI模型实施永久性75%折扣` → **9 分**（AI 商业事件）
- `阿里十三薪将并入年终奖` → **4 分**（HR 事件，硬搭 AI 不自然）

**Few-shot 反例**（模型看的"什么是差"）：
- `天涯神帖` → **3 分**（纯标签，标题无事件）
- `儿童节` → **1 分**（节日，无内容角度）
- `姆巴佩` → **2 分**（纯人名无事件）

**评分维度**（模型实际推理的逻辑）：
```
0-3  → 标题无可展开事件/角度（纯节日/纯人名/3字以下无数字）
4-5  → 有事件但和 AI 业务零关联，强行做会走偏
6-7  → 有清晰事件，可从某个角度切入 AI/内容生产
8-10 → 完美业务款（AI 行业新闻/产品发布/技术突破）
```

**输入**：`title + source + correlation_score`（corr 给模型当辅助参考）
**输出**（严格 JSON，不能含其他内容，不能含 <think> 标签）：
```json
{
  "angle_score": 8,
  "reason": "一句话判断为什么这个分",
  "suggested_angle": "一句话建议切入角度（score≥6 时必给）"
}
```

## 完整 prompt 模板

```python
PROMPT = """你是「壹目贯维」内容总监助理。壹目贯维是 B2B AI 内容生产服务商，主营 AI 视频生成/AI 配音/AI 短视频批量生产。

判断下面这条话题标题，**能不能在 5-15 秒短视频里讲清楚、并和"AI 内容生产"业务自然搭上**。

【必须直接输出 JSON，不要 <think> 思考标签】
只输出严格 JSON（不能有其他内容）：
{{"angle_score": <0-10>, "reason": "<一句话>", "suggested_angle": "<一句话或null>"}}

评分维度：
- 0-3: 标题本身无可展开事件/角度（纯节日/纯人名/3字以下无数字）
- 4-5: 标题有事件但和 AI 业务零关联，强行做会走偏
- 6-7: 有清晰事件，可从某个角度切入 AI/内容生产
- 8-10: 完美业务款（AI 行业新闻/产品发布/技术突破）

正例：MiniMax M3 100万token=10 | DeepSeek 75%折扣=9 | 阿里十三薪=4
反例：天涯神帖=3 | 儿童节=1 | 姆巴佩=2

待判断话题：{title}
来源：{source} | correlation={corr}
"""
```

## DeepSeek-v4-flash API 调用 pattern（实测可用）

```python
import subprocess, json, time

def call_llm(title, source, corr, max_retry=3):
    payload = json.dumps({
        "model": "deepseek-v4-flash",
        "messages": [{"role": "user", "content": PROMPT.format(title=title, source=source, corr=corr)}],
        "temperature": 0.1,
        "max_tokens": 1000,   # 关键：不能是 300，会被 reasoning 截断
    }, ensure_ascii=False)
    cmd = [
        "curl", "-s", "--max-time", "120",
        "-X", "POST",
        "-H", "Content-Type: application/json",
        "-H", f"Authorization: Bearer {API_KEY}",
        "-d", payload,
        f"{BASE_URL}/chat/completions",
    ]
    for attempt in range(max_retry):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=130)
            if not r.stdout:
                if attempt < max_retry - 1:
                    time.sleep(5 * (attempt + 1))
                    continue
                return None, "empty_stdout"
            try:
                data = json.loads(r.stdout)
            except json.JSONDecodeError:
                if attempt < max_retry - 1:
                    time.sleep(3)
                    continue
                return None, "json_parse_fail"
            if "error" in data:
                if attempt < max_retry - 1:
                    time.sleep(5)
                    continue
                return None, f"api_error:{data['error']}"
            content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
            m = re.search(r'\{[\s\S]*\}', content)
            if not m:
                if attempt < max_retry - 1:
                    time.sleep(3)
                    continue
                return None, "no_json"
            return json.loads(m.group()), None
        except subprocess.TimeoutExpired:
            if attempt < max_retry - 1:
                time.sleep(5)
                continue
            return None, "timeout"
        except Exception as e:
            return None, type(e).__name__   # 关键：不 print str(e) 暴露 key
    return None, "exhausted"
```

## 5/5 样本验证（2026-06-03 5 条样本）

| 标题 | 启发式 | m3 实答 | 评估 |
|---|---|---|---|
| 天涯神帖 | 3 (字少启发式碰巧对) | 3 纯标签无事件 | ✓ |
| MiniMax M3 模型发布 | 3 (启发式错) | **10** 完美业务款 | ✓ m3 纠错 |
| BLG 2:1 IG | 3 (启发式错) | 3 电竞无AI关联 | ✓ |
| DeepSeek 75% 折扣 | 3 (启发式错) | **9** AI 商业事件 | ✓ m3 纠错 |
| 儿童节 | 1 (节日启发式对) | 1 节日 | ✓ |

## 278 全量实证（2026-06-03 跑完，73.6 分钟）

**最终统计**（修正 selection bias + 内容农场过滤后）：
- 启发式判 B 档 278 条 → m3 重新判定
- 启发式 + m3 双确认不可做（m3 < 6）：240 条（86.3%）
- 启发式误判 m3 救回（m3 >= 6）：**38 条 (13.7%)**
  - 业务款核心（m3 >= 8）：**29 条**（Tavily 21 + AIHOT 6 + 知乎 2 + 微博 0 + 抖音 0）
  - 可做（m3 6-7）：9 条
- 按 source m3 评分 ≥6 占比：
  - **Tavily: 69.4%（启发式全误判）**
  - **AIHOT: 100%（启发式全误判）**
  - 知乎: 3.8% / 微博: 1.0% / 抖音: 1.3%
- **结论**：m3 在 Tavily/AIHOT（AI 业务长尾新闻）上**比启发式强 50-100 倍**；在微博/抖音（娱乐/民生热搜）上和启发式判断一致

**AIHOT 8 条全救回**（用户最关心）：
- DeepSeek 75% 折扣 (corr=9, m3=9)
- MiniMax M3 模型发布 (corr=10, m3=10)
- TrapDoor 供应链攻击 (corr=9, m3=9)
- ChatGPT 长文编辑功能 (corr=8, m3=8)
- 格雷格·布罗克曼 OpenAI 72小时 (corr=8, m3=8)
- Anthropic 800亿融资 (corr=7, m3=7)
- Pixverse 角色设计工作流 (corr=5, m3=5)
- Codex 自我优化提示词框架 (corr=5, m3=5)
- **所有 8 条都是业务款核心素材，启发式判 B 档全误杀**

## 阈值定法

**推荐 ≥7**（修正后）：
- ≥6 救回 38 条，含 9 条 5-6 分"勉强可做"——产能 1-2 条/天 看不完
- ≥7 留 29 条业务款核心（修正后 26 条真业务款），数字契合 1-2 条/天产能
- ≥8 漏 3 条真新闻（如"AI 神话"模型被封印 = 9 分但偏窄）

**产能倒推**：
- 每天 50-100 条新 approved 话题 × 13.7% = 7-14 条 / 天
- 实际 1 个内容总监 1 天最多 1-2 个短视频脚本
- **7-14 条 vs 1-2 条产能 = 80% 救回会被浪费**
- **阈值应反过来看**——按产能倒推阈值

## 集成架构

**不动 v3 采集脚本**（按 cron-deployment-pitfalls.md，v3 改动风险大）：
- v3 已有 layer 1.5 正则 + layer 2 LLM 过滤 + layer 3 审核
- 角度分是**消费侧**的前置过滤，**不污染历史数据**

**生产链路时序（2026-06-03 user 确认）**：
```
07:30 maintenance (freshness decay)
08:00 采集 (实际 08:02 完成, 跑 2-3 分钟)
08:05 audit_08x05 语义审核 (跑 2-3 分钟)
08:10 ★ judge_angles_08x10 (新加 cron)
       ↓ ~5 分钟跑完（实测 4.6 分钟）
08:15-08:25 完成
08:30 推送 ★ 直接看 angle_score
09:30 watchdog
```

**关键**：角度分必须在 08:30 推送之前打完——推送文本里要显示 angle_score + 业务款优先 m3 ≥ 7。

**用户原话纠正**：
> "如果角度分的算法合理的话，应该纳入我们的正式工作流"——但**角度分应该在 8:30 推送之前就打完吧**。
> 我之前设计成 09:30 完全是错的（推送已经发出去了，角度分晚了）。

## 已知失败模式 + 修法

| 失败模式 | 原因 | 修法 |
|---|---|---|
| m3 返回 `no_json:<think>...` 截断 | m3 默认会 `` 思考 + max_tokens=300 不够 | max_tokens=1000 + prompt 强提示"不要 <think>" |
| API 偶发空响应 (curl 静默) | 网络/限流 | retry 3 次 + 指数 backoff (5s/10s/15s) |
| KeyError 'correlation_score' | 字段名是 `corr` 不是 `correlation_score` | 用 `r.get("corr") or r.get("correlation_score") or 5.0` |
| m3 输出含智能引号 `'/"/"/'` | 中文输出常见 | JSON 解析时 `re.sub` 智能引号 |

## 推荐用法（查询模板）

**业务款核心**（AI 内容生产可直接做）：
```sql
SELECT * FROM topics
WHERE angle_score >= 7
  AND review_status = 'approved'
  AND status != 'archived'
ORDER BY angle_score DESC, correlation_score DESC
LIMIT 10;
```

**真不可做**（双确认不要）：
```sql
SELECT * FROM topics
WHERE angle_score < 4
  AND correlation_score < 5
ORDER BY created_at DESC;
```

**人工复核候选**（corr 和 angle 矛盾）：
```sql
SELECT * FROM topics
WHERE (angle_score >= 7 AND correlation_score < 5)
   OR (correlation_score >= 8 AND angle_score < 4)
ORDER BY created_at DESC;
```

## 修正数据警示（selection bias）

⚠️ **必须声明**：本次 278 条实证**只对启发式判 B 档的话题跑 m3**。**不是全量对比**。
- 启发式判 A 档的话题**没测** m3 怎么判
- 不能推论"启发式 100% 漏判业务款"——只推论"启发式判 B 的话题中 13.7% 实际可做"

下次想测**全量对比**（A+B+unrated 全跑 m3），需要：
1. 重置全部 approved 话题的 angle_score 为 NULL
2. 跑一次完整 m3 角度判定
3. 按 m3 评分分布重新分析

## v2 升级（2026-06-05 落地）

> 触发：6-05 user 反馈"角度分卡的本质是 bridge/CTA 可写性，不只是 AI 角度"。基于 brand-cta-review Section 0 Topic Selection Gate 三问，把单维度 angle_score 拆成 3 维度独立评分 + 风险标记 + 桥接建议输出。

### 拆分逻辑

v1 单一 angle_score 把"内容可生产性 + bridge 可写性 + CTA 可写性"混评，**m3 在大众话题（旅行/儿童节/节日）上找桥视野不够**——"旅行买的是专属记忆"v1 判 3，但其实有桥"旅行内容创作者在用 AI 工具 → 壹目贯维"。

v2 拆 3 维度（按 Topic Selection Gate 三问）：

| 维度 | 衡量 | 评分依据 |
|------|------|---------|
| `content_score` | 标题本身是否有事件/数据可展开 | 0-3 纯节日/纯人名 → 8-10 AI 行业新闻 |
| `bridge_score` | 能否 3 句话内自然桥到"AI 内容生产" | 问1天然连接 + 问2同向 + 问3非 sequitur |
| `cta_score` | 壹目贯维"AI 内容生产公司"身份能否自然承接 | 0-3 非 sequitur → 8-10 完美业务款 |
| `risk_flag` | 灾难/政治/隐私/敏感 | disaster -2，politics/privacy/sensitive -1，none 0 |

**final angle_score = min(content, bridge, cta) - risk_penalty**

### v2 输出 schema

```json
{
  "content_score": 5,
  "bridge_score": 6,
  "cta_score": 6,
  "risk_flag": "none",
  "suggested_bridge": "旅行内容创作者在用 AI 工具 → 壹目贯维"
}
```

`risk_flag` 取值：`none` / `disaster` / `politics` / `privacy` / `sensitive`
`suggested_bridge`：final<6 时必给 null（规则强制）

### topics 表 schema 变更

```sql
ALTER TABLE topics ADD COLUMN suggested_bridge TEXT;
ALTER TABLE topics ADD COLUMN risk_flag TEXT;
```

### 50 样本 v1 vs v2 实证（2026-06-05 跑完）

**翻盘率（user 重点关注）**：

| v1 bucket | n | v2 翻盘到 ≥5 | v2 翻盘到 ≥7 | 维持 <5 |
|-----------|---|--------------|--------------|---------|
| 重点 3-5 | 21 | **1 (4.8%)** | **0 (0%)** | 20 (95.2%) |
| 中 5-7 | 10 | 6 (60%) | 2 (20%) | 4 (40%) |
| 高 8-10 | 4 | — | 4 (100% 保持) | 0 |
| 低 0-2 | 5 | 0 (0%) | 0 | 5 (100% 保持) |

**bridge 维度分流**：`bridge` 维度是 final 限制因素的占 **72.5%**（29/40）—— bridge 维度在真正发挥作用

**误杀/误救率**：
- 误杀（v1=8-10 → v2<7）：**0%**
- 误救（v1=0-2 → v2≥7）：**0%**
- 风险话题覆盖：disaster 2 / politics 7 / sensitive 2 / privacy 1 = 30% 新加防线

**关键结论（直接反 user 之前的预期）**：
- ❌ **翻盘率仅 4.8%——v2 不"扩引流池"**
- ✅ v2 真正价值：**精确区分"能桥/不能桥"**，不误杀老高分、不误救老低分
- 翻盘率低的根因：**池子里 v1=3-5 的话题本来就是没桥的**（微博/知乎/抖音的娱乐/民生/体育），prompt 调多细都不能"变出桥"
- **要扩引流池必须走"扩源"路线**（招 2：扩 AI 类一手新闻源；招 3：限热搜 source 对业务款；招 4：清 NULL）——源头产出"bridge 天然好写"的话题，不是 prompt 优化的领域

### 回灌建议（基于数据）

**不建议全量回灌**。理由：
1. 翻盘率 4.8%——回灌不"扩池"
2. v2 评分更严，**全量回灌会让现有 v1=7 的部分话题 v2 评到 4-5**（看 v1=7 bucket 10 条，v2 给 4-5-5-5-6-6-6-6-6-6 有 7 条掉到 4-5）
3. **会让 8:30 推送的"业务款"合格话题变少**

**推荐方案**（2026-06-05 user 拍板用）：
- **A. 不回灌**：cron 跑 v2 评新进库话题；v1 存量保留不重判
- 等 1-2 周 NULL 清完，所有新进库话题都是 v2 评分；老 v1 分数不会"消失"，但也不会"被 v2 替换"——只是被新 v2 分数盖过

### bridge 文本质量（实测可写脚本直接用）

v1=7 智博会"逛完2026智博会，我发现AI不讲'故事'了" v2=6 bridge:
> "AI 从讲概念到干实事，AI 内容生产正是最先落地的赛道之一 → 壹目贯维"

v1=8 DeepMind 开源科学智能体工具包 v2=7 bridge:
> "DeepMind 开源科学智能体是 AI 行业重大动态，可借势做 AI 工具趋势解读短视频 → 壹目贯维帮客户 5 分钟批量产出 AI 行业热点内容"

—— 桥接方向明确，**写脚本阶段直接拿 bridge 当过渡句底稿**。

## ⚠️ PROMPT 模板陷阱：JSON 内 `{}` vs `.format()` 冲突

v2 prompt 用了 JSON schema（5 字段），**直接用 `.format(title=, source=, corr=)` 全部撞 KeyError**——KeyError 提示指向 prompt 内部 JSON 的 `{` 字符。

**修法（已落地）**：用 `string.Template` 风格占位符（`$var`），调用时 `Template(PROMPT).safe_substitute(...)`，避开 `{}` 冲突。

```python
# ❌ 错（v1 风格，PROMPT 内有 {{...}} 转义）
PROMPT = """... {{\"content_score\": <0-10>}} ... 待判断：{title} """
prompt = PROMPT.format(title=title)  # 失败：format 把 {content_score 当占位符

# ✅ 对（v2 风格，PROMPT 用 $var 占位符）
PROMPT = """... "content_score": <0-10> ... 待判断：$title """
from string import Template
prompt = Template(PROMPT).safe_substitute(title=title)  # 成功
```

**经验规则**：
- PROMPT 含 JSON schema（多个 `{}`）→ **必须**用 `string.Template` + `$var` 占位符
- PROMPT 只有 1-2 个占位符且无 `{}` 字符 → `.format()` 可以
- **不要** f-string 风格 `{{...}}` 转义（v1 用过但容易看错，且调用 .format() 时多余转义）

## ⚠️ Cron 部署陷阱：scripts 副本必同步

**6-05 发现的坑**：cron 实际跑的脚本在 `~/.hermes/profiles/content/scripts/judge_topics_angle.py`，**不是** `~/.herzen/profile/content/skills/.../scripts/judge_topics_angle.py`。

按 `cron-deployment-pitfalls.md` 第 4 坑：`script` 字段只能写相对文件名，hermes 找 `scripts_dir` 下的副本。**改完 skill 目录的源脚本不会自动同步到 cron 跑的副本**。

**强制做法**：
1. 在 skill 目录的源脚本改完 + 测试 OK
2. 立即 `cp` 到 `~/.hermes/profiles/content/scripts/`：
   ```bash
   cp /home/renanzai/.hermes/profiles/content/skills/productivity/automedia-topic-pool/scripts/judge_topics_angle.py \
      /home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py
   ```
3. **验证副本与源 md5 一致**：`md5sum` 两个文件对比

**反例（6-05 险些踩）**：改完 skill 目录的 PROMPT 升级到 v2，**没复制**到 cron scripts 目录 → cron 第二天跑的还是 v1 → 角度分表现还是 v1 风格。**md5 校验会发现但很容易忘**。

## v2 已知失败模式 + 修法

| 失败模式 | 原因 | 修法 |
|---|---|---|
| m3 返回 `no_json:<think>...` 截断 | m3 默认会 `` 思考 + max_tokens=1000 不够（v2 输出更长） | **v2 max_tokens=1500** + prompt 强提示"不要 <think>" |
| PROMPT `.format()` KeyError | JSON 内 `{}` 字符与 .format() 占位符冲突 | **用 `string.Template` + `$var`** |
| Cron 跑老 v1 | skill 目录改了 v2，cron 副本未同步 | **改完必 cp 到 scripts 目录** + md5 校验 |
| 50 样本 empty_stdout 失败 8/48（16.7%） | m3 限流（v2 prompt 比 v1 长 50%） | retry 3 次 + 慢启动 1s/条；如果失败率 >20% 调回 1000 tokens |
| 翻盘率低 | v1=3-5 话题本来就无桥 | **别再寄望 prompt 优化扩池**——走"扩源"路线（招 2/3/4） |

## v2 评分阈值（待定，2026-06-05 暂无 30 天回灌数据）

**当前沿用 v1 阈值 angle_score >= 7**（hard filter）。v2 评分更精细，理论阈值可能调整：
- 维持 ≥7：稳，等回灌数据
- 降到 ≥6：可能让 v2 评 6 的"桥勉强能写"的话题入 top3——风险大，先不动
- 加 8:30 推送 cron 的 risk_flag 过滤：`AND (risk_flag IS NULL OR risk_flag='none')`——把 30% 风险话题主动剔除

**推荐**：v2 跑 1 周后看新进库数据，再决定阈值。

## 一句话总结

**`correlation_score` 看"是不是 AI 行业"**
**`angle_score` v2 = min(content, bridge, cta) - risk_penalty**
**`bridge` 维度按 brand-cta-review Topic Selection Gate 三问判断，是引流款/业务款都关键的限制维度**
**`suggested_bridge` 是写脚本直接可用的桥接方向**
**`risk_flag` 是新加的硬防线（disaster/politics/privacy/sensitive）**
**v2 不"扩引流池"——扩池要靠扩 AI 类源**（招 2/3/4）

---

## v2 升级记录（2026-06-05 user 拍板）

### 动机

- user 原话："之所以要做角度分是因为有些引流款实在是不好写 bridge 和 CTA"
- v1 设计：angle_score 单一分，m3 把"内容可生产性 + bridge 可写性"混着评
- 漏判案例：v1 评 angle=3 的"旅行买的是专属记忆"，其实有桥（"旅行内容创作者在用 AI 工具"），但 v1 笼统判低
- 反之 v1 评 9 的"Alphabet/Anthropic 资本动作"也不够精细——"完美业务款"和"业务款偏边缘"没区分

### v2 设计（基于 brand-cta-review Section 0 Topic Selection Gate 三问）

- 拆 3 个独立维度 + 1 个 risk flag：
  - **content_score**：标题是否有事件/数据可展开（0-10）
  - **bridge_score**：能否 3 句话内自然桥到"AI 内容生产"业务（0-10，**核心新增**）
  - **cta_score**：壹目贯维"AI 内容生产公司"身份能否自然承接（0-10）
  - **risk_flag**：none / disaster / politics / privacy / sensitive
- `final angle_score = round(min(content, bridge, cta)) - risk_penalty`
  - risk_flag=none：取三维度最小值
  - risk_flag=disaster：-2
  - risk_flag=politics/privacy/sensitive：-1
- 新字段 `suggested_bridge`（TEXT）：final>=6 时给一句话桥接方向，<6 给 null
- 新字段 `risk_flag`（TEXT）：风险标签
- PROMPT 改用 `string.Template` 避 JSON `{}` 冲突（`.format()` 会把所有 `{}` 当占位符）
- max_tokens：1000 → 1500（5 字段输出更长）

### 50 样本验证（2026-06-05 实测）

| 指标 | 实测 | 解读 |
|------|------|------|
| 成功率 | 40/48 (83.3%) | m3 限流（v1 也是 ~85%） |
| v1=8-10 误杀率（v2<7） | **0% (0/4)** | 老高分不误降 ✓ |
| v1=0-2 误救率（v2≥7） | **0% (0/5)** | 老低分不误拉 ✓ |
| **v1=3-5 翻盘率（v2≥5）** | **4.8% (1/21)** | **不"扩池"**——反预期结果 |
| bridge 维度限制 final 比例 | **72.5% (29/40)** | bridge 真正发挥分流作用 ✓ |
| risk_flag 触发比例 | 30% (12/40) | politics 7 + disaster 2 + sensitive 2 + privacy 1 |

### 关键结论（user 拍板依据）

- v2 prompt **设计正确**：不误杀 + 不误救 + bridge 维度 72.5% 分流 + risk_flag 30% 触发
- v2 **不"扩引流池"**——只是"更准"地判定"能不能桥"
- **真正扩池要靠招 2/3/4**（扩 AI 新闻源 + 限热搜源对业务款 + 清 NULL），让源头就产出"bridge 天然好写"的话题
- **回灌不建议**：翻盘率 4.8% 不抵回灌成本

### 部署方案（A 方案，user 拍板）

- **不回灌 v1 存量分数**
- cron `judge_angles_08x10` 跑 v2 评新进库 + NULL 话题
- 老 v1 分数保留（不会被 v2 主动覆盖）
- v1/v2 长期共存：v2 分数按 created_at DESC 优先（cron 先跑新的）
- 1-2 周后 NULL 清完，所有新话题都是 v2 评分；老 v1 分数仍可见但不会被覆盖

### 维护注意事项

- cron 实际跑的是 `~/.hermes/profiles/content/scripts/judge_topics_angle.py`（**不是** skill 目录那份）
- 改 v2 prompt 必须同时改两处 + md5 一致（cron 路径陷阱，详见 cron-deployment-pitfalls.md 陷阱 4）
- v2 max_tokens=1500（v1 是 1000，v2 输出更长）—— 失败率与 v1 相当
- 8:10 cron 失败率 ~16% 是 m3 限流，retry 3 次 + 慢启动 1s 够用，不要调高
- 部署命令：`cp skills/.../scripts/judge_topics_angle.py ~/.hermes/profiles/content/scripts/judge_topics_angle.py`

### 数据库变更

```sql
-- 2026-06-05 ALTER TABLE topics 加 2 列
ALTER TABLE topics ADD COLUMN suggested_bridge TEXT;
ALTER TABLE topics ADD COLUMN risk_flag TEXT;
```

### 反模式（2026-06-05 固化）

- ❌ **不要回灌 v1 存量话题**（翻盘率仅 4.8%，回灌不扩池）
- ❌ **不要静默清空 v1 角度分**让 cron 自然补（伪回灌）
- ❌ **不要因为 v2 失败率高就回滚 v1**（v2 设计正确，限流是 m3 自身问题）
- ❌ **不要在 cron 跑时手动跑批量补 v1 NULL**（让 cron 自然处理，1-2 周清完）

---

## ⚠️ v2 prompt 改前的必读 4 skill 清单（2026-06-05 user 揭穿）

**症状**（2026-06-05 实测反例）：
- agent 推 v2 prompt 改造时**只读** `automedia-topic-pool` + 本文件
- 错误结论："引流款不需要卡 angle，只卡 heat"（推 A 方案）
- user 揭穿："之所以要做角度分是因为有些引流款实在是不好写 bridge 和 CTA"
- 反预期：v2 prompt 实测翻盘率仅 4.8%，**真要扩池要靠扩源**（招 2/3/4）

**根因**：
- 没读 `brand-cta-review` —— v2 prompt 根本目标正是该 skill Section 0 Topic Selection Gate 三问
- 没读 `yimuguanwei-persona` —— "AI 内容生产"业务线具体定义
- "摸清 X 必全量" 原则（memory 第 14 行）没执行 —— 把 `automedia-topic-pool` 当唯一相关 skill

**v2 prompt 改前必读 4 skill 清单**（按加载顺序）：

| 顺序 | Skill | 必读章节 | 为什么必读 |
|------|-------|---------|-----------|
| 1 | `automedia-topic-pool` | SKILL.md + 本文件 v2 章节 | 现有 v1/v2 算法 + 评分公式 + 历史验证 |
| 2 | `brand-cta-review` | **Section 0 Topic Selection Gate**（**核心**）| bridge/CTA 可写性根本定义 |
| 3 | `yimuguanwei-persona` | 品牌身份 + 业务线定义 | "AI 内容生产"=热点追踪/文案生成/多平台发布 |
| 4 | `automedia-topic-pool` | `references/cron-deployment-pitfalls.md` | prompt 改后部署到 cron 的陷阱（含 profile jobs.json 路径坑） |

**改 v2 prompt 必做的 3 步**：
1. **加载 4 个 skill 全部阅读**（**不要**只看其中一个就下结论）
2. **跑 5 样本 dry-run** 验证新 prompt schema 正确（m3 输出字段对得上、JSON 不 KeyError）
3. **跑 30-50 样本历史数据**验证 v2 vs v1 评分分布（看翻盘率、误杀率、误救率、bridge 维度贡献）

**反例（2026-06-05 实测，禁止重犯）**：
- ❌ 只读 `automedia-topic-pool` 就推 v2 设计 → 漏 brand-cta-review 维度
- ❌ 跑 5 样本就宣布 v2 OK → 5 样本看不到分布
- ❌ 跳过历史数据回看 → 翻盘率 4.8%（扩池效果远低于预期）
- ❌ 看到 v2 "看起来更准"就推回灌 → 回灌会重置 v1 分数，必须用 50 样本数据拍板
- ❌ 改完 prompt 没 cp 到 `~/.hermes/profiles/content/scripts/` → cron 第二天仍跑老版

**预防**：
- 任何 v2/v3/v4 prompt 改造工作流前**先列 skill 加载清单**（4 个必读）+ **在 todo 工具里登记**
- 读完 4 个 skill 后**先写"v2 设计原则"小节**（20-30 行，含每个 skill 的核心引用），再写 PROMPT
- 跑批验证分两阶段：**5 样本（schema）→ 50 样本（分布）**
- **写完 v2 第一件事**：把 50 样本数据发给 user 拍板（不是"看起来对就上线"）

**实测教训**（2026-06-05 必看）：
- agent 推"招 1+5 v2 prompt 改造"前**没读** brand-cta-review → 推 A 方案"引流款不卡 angle"被 user 当场揭穿
- v2 prompt 改造后实测翻盘率 4.8%（v1=3-5 话题 v2 几乎不"翻盘"到 ≥7）——**v2 不扩池**
- 真正扩池靠扩 AI 类源（招 2：Tavily 8→16 组、招 3：限热搜 cat、招 4：清 NULL）
- 推 v2 设计前**必读** brand-cta-review Section 0 三问 + yimuguanwei-persona 业务线定义，否则会推出反预期结论
