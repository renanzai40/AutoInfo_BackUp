# ⚠️ 致命陷阱：池子完整性（2026-06-08 新增，3 个结构性 bug）

## ⚠️ 致命陷阱：池子完整性（2026-06-08 新增，3 个结构性 bug）

> **核心问题**：`pool.db` 是"待生产话题池"，`PROJECT_REGISTRY.json` 是"已交付项目清单"。**两个 source of truth 之间没有自动同步**——任何"用户报告池子里又出现已交付/已选过的老话题"的根因都在这里。

### 陷阱 24：采集脚本 `topic_id = md5(title + source)` 哈希 + `INSERT OR IGNORE` → 同 title 跨 source 产生 N 条

**症状**（2026-06-08 实测）：
```sql
-- 池里同 title 完全重复 2 条
SELECT t1.topic_id, t1.title, t1.source, t1.created_at,
       t2.topic_id, t2.source, t2.created_at
FROM topics t1
JOIN topics t2 ON t1.title=t2.title AND t1.topic_id < t2.topic_id;

-- 结果：
-- '巴西队世界杯26人名单'
--   6b0d124039... [抖音] 2026-05-19
--   877c78b372... [微博] 2026-05-19
-- '中国航天员第8次太空会师'
--   1ebb4caaac... [微博] 2026-05-25
--   de0ee672e7... [抖音] 2026-05-25
```

**根因**（`auto_media_hot_collection_v3_20260525.py` L891/L908/L918）：
```python
# 流1（热搜）
topic_id = hashlib.md5((item['title'] + item['source']).encode()).hexdigest()
# 流2（Tavily）
topic_id = hashlib.md5((item['title'] + 'Tavily').encode()).hexdigest()
# 流3（AIHOT）
topic_id = hashlib.md5((item['title'] + 'AIHOT').encode()).hexdigest()

# 全部走 INSERT OR IGNORE
cur.execute("""INSERT OR IGNORE INTO topics ...""", (topic_id, ...))
```

`INSERT OR IGNORE` 只对**主键冲突**生效。同 title 跨 source = 4 个不同 hash = 4 条入库。

**反模式（永久禁止）**：
- ❌ **`topic_id` 用 `(title, source)` 组合**——把"采集来源"作为唯一性的一部分，导致同事件跨源去重失效
- ❌ **依赖 `INSERT OR IGNORE` 兜底**——主键不对 = IGNORE 无效 = 永远会重复

**修法（永久规则）**：

```python
# ✅ 方案 A（推荐）：去 source，仅按 title 哈希
topic_id = hashlib.md5(item['title'].encode()).hexdigest()

# ✅ 方案 B（更安全）：用 title 做 UNIQUE INDEX
# pool.db schema 加：
# CREATE UNIQUE INDEX IF NOT EXISTS idx_topics_title ON topics(title);
# 然后 INSERT 不带 OR IGNORE（依赖 UNIQUE 抛 IntegrityError → 显式 try/except 跳过）
```

**预防**：
- 改采集脚本的 `topic_id` 计算公式时，**先**在数据库加 `UNIQUE INDEX` 兜底，**再**改 hash 公式
- 改完用 `SELECT title, COUNT(*) c FROM topics GROUP BY title HAVING c>1` 验证历史数据无重复
- 已有重复数据：可保留（不影响业务）或一次性清理（删除 `topic_id` 较小的那条 + JSON 备份）

### 陷阱 25：项目交付后**没有任何代码回写 pool.db 的 status**——已交付话题永远停在 `selected`/`archived`

> **2026-06-22 追加**：项目初始化也不写 → 双向缺口。已新增 `scripts/pool_sync.py` 在创建项目时立即标记 selected。详见该脚本的 docstring 和 `automedia-project-init` skill。

**症状**（2026-06-08 实测，29 个已交付项目 vs pool.db 状态）：

| topic_id | title | pool.db status | source | PROJECT_REGISTRY |
|---|---|---|---|---|
| `a18ac3e30f1c` | Runway API Aleph 2.0 | **selected** | AIHOT | active / draft_uploaded |
| `e6b645526ee7` | DeepSeek 75% 折扣 | **selected** | AIHOT | active / draft_uploaded |
| `81d19106f755` | Lorai 智能营销 | **selected** | Tavily | active / draft_uploaded |
| `ae520404506a` | MiniMax M3 即将发布 | **archived** | AIHOT | active / draft_uploaded |
| `e71d13a33728` | 腾讯混元 Hy-Memory | **archived** | AIHOT | active / draft_uploaded |

**根因**：
1. `projects/<id>/05_publish/publish_log.json` 写 `status: "draft_uploaded"`
2. `PROJECT_REGISTRY.json` 由 `regen_project_registry.py` 重新生成，标 active
3. **但没有任何脚本会去找这个 topic_id，把 pool.db 的 status 改掉**
4. 5 个已交付 topic 永远停在 `selected`/`archived`，且 3 个还在 `selected`（系统还以为"已选中未启动"）

**全代码库 0 行验证**：
```bash
# UPDATE topics 全文搜索（除 judge_topics_angle.py 改 angle_score 之外）
grep -rn "UPDATE topics" ~/.hermes/profiles/content/scripts/ /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/
# → 0 命中

# status='archived' 字符串全文搜索
grep -rn "status='archived'" ~/.hermes/profiles/content/scripts/ /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/
# → 0 命中
```

池里 2 条 `archived` 是历史**手动 SQL 改的**，**不是任何脚本写的**——自动化回写钩子根本不存在。

**反模式（永久禁止）**：
- ❌ **生产链路完成时**只更新 `publish_log.json` / `PROJECT_REGISTRY.json`，**忘了** `topics.status`——双 source of truth 漂移
- ❌ **依赖 8:30 推送的 `status='pending'` 过滤**兜底——只防"推到用户眼前"，**不防**"出现在 audit/采集/对账等所有非推送路径"
- ❌ **手工 SQL 改 status**——下次问题复发时找不到"是哪条规则改的"

**修法（永久规则）**：

**方案 1（推荐）：在 `regen_project_registry.py` 末段加回写**
```python
# regen_project_registry.py 末段（生成完 registry 后）
import sqlite3
conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()
archived_count = 0
for proj in projects_active:
    tid = proj["info"].get("topic_id")
    if not tid:
        continue
    cur.execute("""
        UPDATE topics
        SET status='archived', updated_at=CURRENT_TIMESTAMP
        WHERE topic_id=? AND status IN ('pending', 'selected', 'writing')
    """, (tid,))
    if cur.rowcount > 0:
        archived_count += 1
conn.commit()
print(f"✅ 已归档 {archived_count} 个已交付 topic（status: pending/selected/writing → archived）")
```

**方案 2：单独写一个 cron 任务 `archive_delivered_topics` 每天跑一次**
```python
# scripts/archive_delivered_topics.py
import json, sqlite3
DB = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db"
REG = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/PROJECT_REGISTRY.json"

with open(REG) as f:
    reg = json.load(f)
done_topic_ids = {p["info"]["topic_id"] for p in reg["active"]
                  if p.get("info",{}).get("topic_id")}

conn = sqlite3.connect(DB)
cur = conn.cursor()
placeholders = ",".join("?" * len(done_topic_ids))
cur.execute(f"""
    UPDATE topics
    SET status='archived', updated_at=CURRENT_TIMESTAMP
    WHERE topic_id IN ({placeholders})
      AND status NOT IN ('archived', 'published')
""", list(done_topic_ids))
print(f"已归档 {cur.rowcount} 个已交付 topic")
conn.commit()
```

**一次性清理（修复历史漂移数据）**：
```python
# 在 audit 之前先备份
import json, datetime
ts = datetime.now().strftime("%Y%m%d_%H%M%S")
with open(f"/tmp/pool_archive_2026-06-08_log.json") as f:
    affected = json.load(f)  # 先 SELECT 打印保留

# 再 UPDATE
import sqlite3
conn = sqlite3.connect(DB)
cur = conn.cursor()
cur.execute("""UPDATE topics SET status='archived' ... """)
conn.commit()
```

### 陷阱 25 子坑：manual 项目 topic_id 不匹配 → regen 回写钩子找不到记录（2026-06-11）

**上文的 regen 回写方案（方案 1）只解决了「标准路径」的问题。** manual 项目（`source: "manual"`）的 topic_id 是 agent 编造的 `manual_xxx` 格式，不在 pool.db 中 → `WHERE topic_id IN (placeholders)` 永远匹配 0 条 → 回写钩子失效。

**症状**：项目目录存在（内容已完成），但 pool.db 中该话题 `status='pending'`（从未被更新）。`regen_project_registry.py` 回写钩子跑完后 `affected=0`。话题在次日的推送/审核/角度判定中再次出现。

**根因**：regen 回写只按 `topic_id` 匹配。manual 项目的 `topic_id` 是编造的，pool.db 中该话题的 `topic_id` 是采集脚本生成的真实 hash。两套 ID 对不上。

**2026-06-11 实证**：2 个 manual 项目（英伟达斗山、DeepSeek V4 Flash）全部脱轨。

**修法（2026-06-11 落地）**：在 `regen_project_registry.py` 回写段加 **title fallback** — 对每个 topic_id 在 pool.db 中查不到的 active 项目，按 title 精确匹配 pool.db → 标 archived + 修复 project_info.json 的 topic_id。完整实现见 `regen_project_registry.py` L340-390。

**2026-06-15 升级**：title fallback 从 `WHERE title=?` 精确匹配改为**去空格归一化比较**。真实案例：pool.db 标题"豆包AI误导用户损失600元"（无空格），项目标题"豆包 AI 误导用户损失 600 元"（含空格）→ 精确匹配失败导致回写失效。修复后：先精确匹配（快速路径），失败则去全部空格后逐一比对。两条漂移 manual 项目（Perplexity哈佛、豆包AI误导）经修复后成功被 regen 识别并归档。

**验证方式**：跑一次 regen → 输出 `title fallback: N` 即为命中：
```
=== pool.db 回写 ===
  已交付 topic_id: 13 (含 1 条 title fallback)
  强制 archived: 3 条 (其中 title fallback: 1)
```

**预防**：① 源头 — manual 项目创建时反查 pool.db title → 用真实 topic_id（见 `automedia-project-init` 技能「手动项目 topic_id 反查规则」）② 兜底 — regen title fallback 自动化修复 ③ 禁止编造 `manual_xxx` 前缀的 topic_id

**预防（永久规则）**：
- **改 PROJECT_REGISTRY 任何回写逻辑时**：必查 `topics` 表是否需要同步
- **改 regen_project_registry.py 时**：必加 `topics` 回写
- **新写任何生产链路 hook**（如 `safe_upload_wechat.py` / `wechat_draft_uploaded`）时：**必带** `UPDATE topics SET status='archived' WHERE topic_id=?`
- 改 regen 回写逻辑时：**title fallback 不可丢**（manual 项目 topic_id 不匹配的兜底防线），如果未来重构 regen 回写段，必须保留 title fallback 段

### 陷阱 26：8:05 audit SQL 缺 `status='pending'` 过滤 → "已交付但 status=selected" 的话题被当成新话题重新审核

**症状**（2026-06-08 实测 audit_08x05 prompt）：
```sql
-- audit_08x05 第一步读待审核话题
SELECT topic_id, title, source_url, heat_score, source
FROM topics
WHERE review_status = 'pending'      -- ❌ 缺 AND status='pending'
ORDER BY heat_score DESC LIMIT 30;
```

对比其他 3 个 cron 的 SQL（都正确）：
- 8:10 m3: `WHERE status NOT IN ('selected','writing','archived','published') AND review_status='approved' AND angle_score IS NULL` ✅
- 8:30 推送: `WHERE status='pending' AND review_status='approved' AND angle_score >= 7` ✅
- 8:30 dashboard: `WHERE status='pending' AND review_status='approved'` ✅
- **8:05 audit 唯独漏了 `status='pending'`** ❌

**为什么是问题**：
- 如果 8:00 采集脚本**未来**因为 hash 公式改动 / schema 变更等场景**重新插入**了已交付的 topic（且 review_status='pending'），audit 8:05 会把它当新话题审
- 更隐蔽：8:00 采集 INSERT OR IGNORE 对已存在的 topic_id 不会重复插，**但**如果 hash 公式改了（陷阱 24 修复路径），已存在的"已交付" topic 因为 review_status 早已是 'approved'，**不会**被 audit 重新审——**这条路径暂时安全**
- **真正风险**：未来如果加新逻辑重置 review_status（例如全量重审 / 季度重审），audit 会一次性把"已交付但 selected"的话题重新跑语义审核

**修法**（audit_08x05 prompt SQL 改 1 行）：
```sql
SELECT topic_id, title, source_url, heat_score, source
FROM topics
WHERE review_status = 'pending'
  AND status = 'pending'             -- ✅ 加这一行
ORDER BY heat_score DESC LIMIT 30;
```

**预防（永久规则）**：
- 写/改**任何**读 `topics` 表的 SQL 时，**先**想清楚 3 个核心 WHERE 条件：
  - `status`（生产状态，区分待生产/已选/已交付）
  - `review_status`（审核状态，区分待审/已批/已拒）
  - `angle_score`（角度分，对 m3 任务相关）
- 3 个条件**按业务需求组合**，**不**是默认都加，**不**是默认都省
- SQL 写完用 `SELECT COUNT(*)` 验证命中数 vs 预期（例：8:05 audit 跑完应该看到 0-N 条新话题，**不应该**看到任何 selected/archived）

### 陷阱 28：DeepSeek reasoning_content 吞噬 max_tokens + 双副本不同步（2026-06-25 升级）

> 这是 **deepseek-v4-flash 通过 opencode API 的固有行为**，不是偶发故障。模型先输出 `reasoning_content`（思考过程），再输出 `content`（回答）。`max_tokens` 不够大时，思考过程吃光预算，content 空字符串返回。

**双重根因**：技术问题（reasoning_content） + 工程问题（三副本不同步）。

#### 根因 1：reasoning_content 吞噬 max_tokens（技术层）

**2026-06-20 修复（采集脚本）**——但修复仅同步到 cron 副本，DEV 副本未同步（见根因 2）：

| 修复类型 | 数量 | 具体改动 |
|---------|------|---------|
| 参数对齐 | 3 处 × 3 参数 | max_tokens=2000→**6000**, timeout=50→**180**, max-time=120→**150** |
| Layer2 batch 拆分 | 1 处新函数 | ≤40 条/批，拆出 `_layer2_process_batch` |
| Dedup parse 失败处理 | 1 处逻辑 | → hash 去重兜底（而非保留全部） |

**2026-06-25 补充修复（llm_dedup 延续）**：之前的修复只覆盖了 Layer2 和参数对齐，**漏了 `llm_dedup` 本身的 batch splitting**，且修复只落 CRON 副本未同步 DEV 副本。三重补齐：
- **Hash 预去重层**（flow1 + flow2 的 `llm_dedup` 前）：对所有标题做 `t[:50].lower().strip()` hash 去重，减少 LLM 输入量 + 兜底保障
- **llm_dedup batch splitting**：超过 **10 条**自动拆分（2026-06-28 从 40 下调，因 DeepSeek-v4-flash 的 O(n²) 配对比较推理在 20 条时已吃光 max_tokens=6000），递归调用自身处理每批，最后跨批 hash 去重消除批间重复
- **双副本同步**：`cp + md5sum` 确保 DEV 和 CRON 副本一致，禁止单向修复

**⚠️ 设计缺口：`llm_dedup` 未做 batch splitting**（2026-06-25 发现）：
- `llm_layer2_gate` 做了 batch splitting（`BATCH_SIZE=40`），但 `llm_dedup` **没做**
- Tavily 16 个 query 一次产出 100+ 条，全塞进一个 LLM 调用
- 即使 `max_tokens=6000`，大 batch 下 reasoning_content 仍可能吃光预算
- Dedup 的语义相似度判断（O(n²) 复杂度）比 Layer2 的分类（O(n)）更耗 reasoning
- **修复建议**：给 `llm_dedup` 加同样的 batch splitting（≤10 条/批）或直接限制传入条数

#### 根因 2：三副本不同步（工程层，2026-06-25 实测）

| 副本 | 路径 | max_tokens | timeout | md5sum |
|------|------|-----------|---------|--------|
| CRON | `~/.hermes/profiles/content/scripts/` | **6000** ✅ | **180** ✅ | a3182507 |
| DEV | `/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/` | **2000** ❌ | **50** ❌ | 5e4f4940 |
| SKILL | `skills/.../automedia-topic-pool/scripts/` | **2000** ❌ | **50** ❌ | （同 DEV 未同步） |

6-20 修复只改了 CRON 副本，DEV 副本和老版 CRON 副本无差异。用户手动跑脚本时（agent 默认从 DEV 读）→ 所有 LLM 调用全部降级。详见上文「三副本必同步」规则。

**症状**：
- **角度判定脚本**（2026-06-12）：11/13 调用返回 `empty_content`
- **采集脚本**（2026-06-20 发现，**已持续数周**）：4 个 LLM 调用全部「解析失败」
  ```
  LLM去重解析失败，保留全部44条
  Layer2 解析失败，保留全部 44 条
  LLM去重解析失败，保留全部111条
  Layer2 解析失败，保留全部 111 条
  ```
- API 直接测试确认：`content: ''`, `Has reasoning: True`, `Finish reason: length`, `reasoning_tokens = completion_tokens`

**根因**（两层问题叠加 + 架构缺失）：

| 层 | 问题 | 角度判定脚本 | 采集脚本 6-20 修复后 |
|----|------|-------------|---------------------|
| `max_tokens` | 被 reasoning 吃光 | 1500→3000 ✅ | **cron 副本 6000 ✅, DEV 副本 2000 ❌** |
| `subprocess timeout` | < curl max-time | 130s ≥ 120s ✅ | **cron 副本 180 ✅, DEV 副本 50 ❌** |
| 批大小 | batch splitting | 单条 ✅ | **Layer2 ✅, Dedup ❌（设计缺口）** |
| parse 失败行为 | hash 兜底 | retry ✅ | **cron 副本 ✅, DEV 副本（保留全部）❌** |

**修法**和**核心教训**详见 `references/deepseek-reasoning-content-pitfall.md` 2026-06-20 全面修复章节。

### 陷阱 27：采集脚本内部 `item['title'] in list_of_dict` 永远 False → 静默 0 入库（P0，2026-06-08 实测）

> **这是与陷阱 24/25/26 完全不同类别的 bug**——不是 state-machine 同步问题，**是采集脚本内部 API 输出类型被错用**。更阴险：**永不报错**，`last_status=ok`，但实际入库 0 条。

**症状**（2026-06-08 10:30 实测，跑了 4+ 天没人发现）：
```python
# auto_media_hot_collection_v3_20260525.py 修前:
flow1_related = minimax_layer2_gate([{'title': t, 'source': ...} for t in flow1_kept], MINIMAX_KEY)
# minimax_layer2_gate 返回 list of dict (item), 不是 list of str

flow1_for_db = [item for item in flow1_raw if item['title'] in flow1_related]
#                           ^^^^^^^^^^^^^^^^^^^ str in list_of_dict = 永远 False
# → flow1_for_db = []  →  流1 入库永远 0 条
```

**根因**（Python 类型 mismatch 必死的 3 个 pattern）：
```python
# ❌ 错 1：str in list_of_dict（本次踩中）
[item for item in raw if item['title'] in layer2_output]  # layer2_output 是 list of dict

# ❌ 错 2：str in list_of_list（也踩过类似）
[hit for hit in hits if hit == [[1,2], [3,4]]]  # 永远 False（除非 hit 真是 list of list 整型）

# ❌ 错 3：str in dict（最容易写错）
[hit for hit in hits if hit in {'a': 1, 'b': 2}]  # 'in' 检查 key, 不是 value
```

**为什么 4+ 天没人发现**：
- `last_status=ok`（hermes cron 不严格查 exit code——陷阱 6 已记录）
- 流2 兜底成 0 时还有流3（AIHOT 1 条）入库 → 业务上"看起来在工作"
- 8:30 推送用历史 angle≥7 库存（465 条）撑场面 → 没人注意到"今天 0 新增"
- 8:30 cron output 写着"流1: 0 / 流2: 0 / 流3: 1"——**但 0 不引起警觉**（历史上偶尔就有 0）
- **真正的报警信号**："3 个流全 0 / 1"组合 → 没人交叉对比

**修法（永久规则）**：
```python
# ✅ 方案 A（推荐）：从 list of dict 提取 str 集合
flow1_related_titles = {r['title'] for r in flow1_related}
flow1_for_db = [item for item in flow1_raw if item['title'] in flow1_related_titles]

# ✅ 方案 B：直接用 list of dict 过滤
flow1_for_db = [item for item in flow1_raw
                if any(item['title'] == r['title'] for r in flow1_related)]
```

**预防（3 道硬保险）**：

1. **采集脚本每个 list filter 都 type-check**（开发期）
   ```python
   assert all(isinstance(r, dict) for r in flow1_related), \
       f"flow1_expected dict, got {type(flow1_related[0])}"
   flow1_related_titles = {r['title'] for r in flow1_related}
   ```

2. **采集脚本入口/出口加 counter sanity check**（运行时）
   ```python
   # 入库后:
   if total_input >= 50 and total_inserted == 0:
       print(f"⚠️ 抓 {total_input} 条但入库 0 条——可能 P0 静默零入库 bug")
       sys.exit(2)  # 强制 cron 报 error
   ```

3. **cron output 写"delta 验证"**（详见下"Step 0" 审计 precheck）
   ```bash
   # 8:00 cron 末尾:
   before=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE created_at >= 'TODAY'")
   after=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE created_at >= 'TODAY'")
   echo "今日入库 delta: $((after-before))"
   if [ $((after-before)) -eq 0 ] && [ $total_input -gt 0 ]; then
     echo "❌ 抓 N 条但 0 入库——P0 静默 bug" >&2
     exit 2
   fi
   ```

**反模式（永久禁止）**：
- ❌ **`x in some_list`** where `x` 是基础类型、`some_list` 是 list of object —— 必败但不报错
- ❌ **依赖"看 cron output 数字"诊断**——3 个流全 0/1 的模式被习惯性忽略
- ❌ **不在采集脚本加 db delta 报警**——silent zero-out 跑 4 天才发现
- ❌ **手动跑一遍只看 exit code**——exit 0 不代表有效入库

**与陷阱 17（cron 静默无操作）的关系**：
- 陷阱 17 是**外层**：cron 任务定义/调度层面 last_status=ok 但业务侧 0
- 陷阱 27 是**内层**：cron 任务"成功跑"，但脚本内部某行代码让入库数归 0
- **两者都靠"业务侧 db delta > 0"作为最终健康指标**——必须都验证

**完整案例**（`references/silent-zero-out-patterns-2026-06-08.md`）：
- 完整 SQL 验证步骤 + 4 步诊断法
- 3 个 type-mismatch 经典 pattern + 单元测试代码
- 跨类对比：陷阱 17 vs 陷阱 27 的诊断区别

### 🔍 池子完整性审计 5 步 Recipe（2026-06-08 10:30 升级，含静默零入库 precheck）

> **触发**：用户报告"池子里又有已交付/已选过的老话题"，**或**每月 1 次池子健康度巡检，**或**改完采集脚本后立即跑。

**Step 0（新增 2026-06-08 10:30，** P0 静默零入库 precheck**）：
```sql
-- 今日入库数 vs 抓取期望
SELECT source, COUNT(*) AS inserted
FROM topics
WHERE created_at >= 'TODAY'  -- e.g. '2026-06-08'
GROUP BY source;
-- 预期：每个 source 都 > 0（除非源本身挂了）
-- 异常信号：所有 source 合计 < 5 条 + 跑通 exit 0 = P0 静默零入库陷阱 27

-- 反向：抓取日志中"流 X 入库 N 条"  vs SQL 实际行数
-- 流1 打印 "流1(热搜): N 条" → SQL 查 source='微博/知乎/抖音' 行数 = N
-- 差 > 0 = 静默丢数据
```

**Step 1：topic_id 交叉验证 — 已交付但 pool.db 状态漂移**
```sql
-- 读 PROJECT_REGISTRY 拿已交付 topic_ids
-- 读 pool.db 查这些 topic 的当前 status
SELECT t.topic_id, t.title, t.status, t.source, t.updated_at
FROM topics t
WHERE t.topic_id IN (
    -- 这里填 PROJECT_REGISTRY 里的所有 active topic_id
    'a18ac3e30f1c', 'e6b645526ee7', '81d19106f755',
    'ae520404506a', 'e71d13a33728'
)
  AND t.status NOT IN ('archived', 'published');

-- 命中 > 0 = 状态漂移
```

**Step 2：同 title 跨 source 重复 — 采集脚本去重失效**
```sql
SELECT t1.title, t1.topic_id, t1.source, t1.created_at,
       t2.topic_id, t2.source, t2.created_at
FROM topics t1
JOIN topics t2 ON t1.title=t2.title AND t1.topic_id < t2.topic_id
ORDER BY t1.title, t1.created_at;

-- 命中 > 0 = 采集脚本 hash 公式错
```

**Step 3：两套 status 字段的语义漂移 — 状态机不一致**
```sql
-- status 分布
SELECT status, COUNT(*) FROM topics GROUP BY status;
-- 预期：pending 为主，selected/writing 少（用户已选未启动），archived 较少（已交付），published 极少或 0

-- review_status 分布
SELECT review_status, COUNT(*) FROM topics GROUP BY review_status;
-- 预期：approved 为主，pending/rejected 较少

-- 异常信号：status='selected' 但 review_status='pending'（被审核但被选了——时序错乱）
-- 异常信号：status='archived' 但 review_status='rejected'（被拒但已交付——不可能）
SELECT status, review_status, COUNT(*)
FROM topics GROUP BY status, review_status ORDER BY 1,2;
```

**Step 4：一次性清理 + 自动化回写（陷阱 25 修法）**
- 备份到 `/tmp/pool_archive_<date>_log.json`（先 SELECT 打印保留所有 affected）
- UPDATE 漂移数据（status NOT IN archived → archived）
- 改 `regen_project_registry.py` 加回写钩子
- 跑 1 次 `regen_project_registry.py` 验证新钩子工作

**3 个新陷阱的关系**：
- 陷阱 24（采集 hash 错）→ 同 title 跨 source 重复 → Step 2 检出
- 陷阱 25（无回写钩子）→ 已交付状态漂移 → Step 1 检出
- 陷阱 26（8:05 audit 缺过滤）→ 审核层兜不住前两个 bug 的副作用 → Step 3 检出"语义/生产两套状态机漂移"

**3 个 bug 是独立路径，修复必须全部覆盖**：
- 只修 24（采集）→ 历史已漂移数据不会被回写（陷阱 25 还在）
- 只修 25（回写）→ 新采集的重复数据继续污染（陷阱 24 还在）
- 只修 26（audit 过滤）→ 只是把审核层兜底，前两个 root cause 还在污染 pool.db

**审计触发节奏**：
- 用户主动报告"池子又有 X" → 立即跑 4 步
- 每月 1 号 09:30 watchdog 后加一步池子健康度报告（**待办**——可加到 automedia-cron-watchdog）
- 改采集脚本 / 改 regen_project_registry.py / 改 audit_08x05 prompt / 改 status 字段语义 → 必跑 4 步

---
