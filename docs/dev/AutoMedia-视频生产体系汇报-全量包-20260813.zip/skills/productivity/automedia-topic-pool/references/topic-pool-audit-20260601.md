# Topic Pool Audit · 2026-06-01

## 事件背景

用户反馈 Business TOP20 中出现「AI视频生成|点点资讯」「我的第一支AIGC短片」等明显不是新闻的话题，要求调研这些话题是如何进池的。

## 调查结论

### 根因：三层漏斗均有漏洞

1. **Layer 1（Domain黑名单）漏过**：`diandian.com`（点点资讯）、`leifeng.com`（雷锋网）不在黑名单
2. **Layer 1.5（标题正则）漏过**：缺少 `r'点点资讯'`、`r'雷峰网'`、`r'^我的.*AIGC'` 等规则
3. **Layer 3（语义审核）漏过**：历史异常话题已approved，未被Layer3清理
4. **流3（AIHOT）零过滤**：AIHOT条目直接入库，不经过Layer 1/1.5

### 修复操作

#### DB层
- 新增blocked_domains：`diandian.com`、`leifeng.com`、`instagram.com`
- 历史异常话题（4条）重置为`pending`
- 手动reject 18条content farm话题
- 二次额外reject 6条（鹤写AI、万维易源、AtomGit等工具站）

#### 脚本层（auto_media_hot_collection_v3_20260525.py）
- `TITLE_BLOCK_PATTERNS` 追加4条：点点资讯、雷峰网、`^我的.*AIGC`、`^#\w+\s`
- 流3接入Layer1.5过滤（新增逻辑）
- 脚本备份：`auto_media_hot_collection_v3_20260525.py.bak.20260601`

## 核心教训：Content Farm 判断逻辑

### 错误逻辑（误杀教训）
```
来自Tavily + 无source_url + 标题含站点名 → 聚合转载 → reject
```
错误原因：Tavily收录时带站点名是正常行为，不等于内容农场。

### 正确逻辑
**只以source_url的域名为reject依据**，不看"无URL"或"标题含站点名"。

| 信号 | 含义 | 处理 |
|------|------|------|
| source_url的域名是已知农场 | reject | 直接reject |
| 无source_url | 不可追溯 | 交Layer3细审，不直接reject |
| 标题含站点名 | Tavily正常行为 | 不作为判断依据 |

### 误判案例
- 话题："大模型头部玩家吸干一级市场 - QQ.com"（误判后已捞回）
- 错误原因：Tavily + 无URL + 标题含QQ.com → 错误判定为聚合转载
- 正确做法：保留，交Layer3细审

## 清理后池子状态

| 类别 | 数量 |
|------|------|
| Business approved | 108条 |
| Business rejected | 86条 |
| Growth approved | 358条 |

## Business TOP20（清理后）

| # | 标题 | 来源 |
|---|------|------|
| 1 | 字节豆包登顶视觉榜、Qwen代码反超闭源 | Tavily |
| 2 | 自家AI太强人类会危险：Mythos大模型封印 | Tavily |
| 3 | 晚上AI大模型传出利好，宁王要投DeepSeek | Tavily |
| 4 | DeepSeek官宣永久降价！700亿融资 | Tavily |
| 5 | 价格屠夫DeepSeek再度出手 | Tavily |
| 6 | 俄银行采购中国芯片为大模型提供算力 | 知乎 |
| 7 | 牛津/微软等9机构音视频智能综述 | Tavily |
| 8 | 完善大模型评测体系提升中国话语权 | Tavily |
| 9 | 美国AI大模型周调用量3.76万亿Token | Tavily |
| 10 | 格雷格·布罗克曼：差点让OpenAI覆灭的72小时 | AIHOT |

## 待优化项

- [ ] 重复话题去重（#2/#3重复、NUS/牛津重复）
- [ ] 无URL话题占比仍高（TOP20中约60%无URL），Layer3需加强验证
- [ ] AtomGit、鹤写AI、万维易源等工具站应考虑加入domain黑名单
