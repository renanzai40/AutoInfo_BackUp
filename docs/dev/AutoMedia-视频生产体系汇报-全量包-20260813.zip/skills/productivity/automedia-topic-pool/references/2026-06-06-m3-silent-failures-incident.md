# 2026-06-06 m3 静默无操作事故复盘（5 + 2 独立坑 + sys.exit + bash 截断）

> **本 reference 是 cron-silent-noop-patterns.md 的姊妹篇，专注 2026-06-06 单日一次性发现 5 个别人代码静默坑 + 2 个自己代码自造坑的全过程**。触发：debug "m3 任务跑了但 pool.db 没动"、调查 cron 任务"silent noop"、批量跑 m3 后做对账、写新 wrapper/batch 脚本。

## 事故概要

**2026-06-06 上午**，用户问"8:05 后的任务我都没看见触发"。我调查后**单日发现 5 个独立静默坑**（详见 `references/cron-silent-noop-patterns.md`）。下午用户要求"手动跑 m3 任务"清空 316 条 NULL，结果**又一次发现 2 个新坑**（sys.exit fail-handling + bash `$()` 截断）—— **直接导致我向用户报告"0 ok"但实际 145 ok**。

**这是本事故的核心教训**：5 个静默坑修完后，**我自己的 wrapper 脚本又制造了 2 个新坑**。修别人代码时，自己代码也得审。

---

## 完整时间线（含真实数字）

### 上午：5 个静默坑（修别人代码）

| 时间 | 事件 | 数据点 |
|---|---|---|
| 10:01 | 8:30 推送**实际成功**发飞书 | 10:01:38 推送完成 |
| 11:50 | 用户问"8:05 后的任务我都没看见触发" | 触发调查 |
| 11:55 | 修 8:30 prompt `--timeout 5` → `--wait-timeout 5` | 1 行 patch |
| 12:00 | 修 3 个 m3 cron 任务的 `script` 字段（去掉 --limit 参数） | 写 wrapper `judge_angles_cron.sh` |
| 12:05 | 修 8:00 任务 `next_run_at` 时区错乱（UTC → CST 8:00）| jobs.json 1 行 patch |
| 12:10 | 修 3 个 m3 任务 `next_run_at` 直接写 CST 8:10/12:00/16:00 | jobs.json 3 行 patch |
| 12:15 | 8:00 任务手动补跑 09:18:26 入库 5 条 AIHOT + Tavily | pool.db +5 |
| 12:30 | 4 改进完成（依赖图 + per-job timeout + session_lock max_age + dashboard）| 387 cron tests pass |

### 下午：2 个新坑（修自己代码）

| 时间 | 事件 | 数据点 |
|---|---|---|
| 14:30 | 用户要求"手动跑 m3 任务"清空 316 条 NULL | 触发新坑 |
| 14:32 | 我写 `/tmp/m3_batches.sh` wrapper，7 批串行跑 | bash 循环 + `$PY $SCRIPT --limit 200` |
| 14:32 | 启动 batch 1，预期 159 条/批 | 实际后述 |
| 16:32 | batch 1 完成 (67 分钟)，wrapper 报"exit=1 ok=0 fail=7 NULL=123" | **🚨 双坑首次暴露** |
| 16:35 | 我立即重写 wrapper 启动 batch 2-8 | 重蹈覆辙 |
| 16:50 | batch 2-8 全部 0-1s 退出，"NULL=116" | **8 批 0 进展** |
| 17:00 | 我调查发现 batch 1 实际跑了 67 分钟，但 `$()` 截断 | 找到 陷阱 19 |
| 17:05 | 查 pool.db 实际：判了 159 条，145 ok + 7 fail | 找到 陷阱 18 |
| 17:10 | 115 → 116 NULL 是 rejected 状态（不归 m3 管）| 找到 audit_08x05 26 天 noop |
| 17:15 | 修 m3 脚本默认 `--source` 覆盖全 5 source | 1 行 patch |
| 17:30 | 重跑 m3 任务，159 条全部判完，cron 跑出 7/159 fail | exit 1（但实际 145 成功）|
| 17:45 | 给用户报告：19 条业务款 + 3 条引流款候选 | **修正错误报告** |

---

## 5 + 2 个静默坑完整清单

### 上午：别人代码的 5 个静默坑（已修）

| # | 类型 | 坑 | 跑了多久 | last_status | 实际业务影响 |
|---|---|---|---|---|---|
| 1 | A2 任务定义 | 8:30 prompt `--timeout 5` 错 | 数天 | ok | 推送静默退出 |
| 2 | D1 跨段 | 8:00 任务时区错乱（UTC）| 数周 | ok | 8:00 实际跑 16:00 |
| 3 | A2 任务定义 | 3 个 m3 cron `script` 带 `--limit 200` | 一直 | error | m3 cron 找不到脚本 |
| 4 | A1 任务定义 | `audit_08x05` script=None | **26 天** | ok | Layer 3 审核从未跑 |
| 5 | B1 SQL 过滤 | m3 脚本 default `--source Tavily,AIHOT` | 一直 | ok | 159 条中文平台 0 候选 |

### 下午：我自己代码的 2 个新坑（已修）

| # | 类型 | 坑 | 跑了多久 | 误报数据 | 真实数据 |
|---|---|---|---|---|---|
| 6 | C2 脚本 exit code | `judge_topics_angle.py` L355 `sys.exit(0 if stats["fail"] == 0 else 1)` | 1 个 67 分钟批次 | cron 报 exit 1 | 145 ok + 7 fail（任务实际成功）|
| 7 | C3 wrapper 解析 | `/tmp/m3_batches.sh` 用 `output=$()` 捕获 67 分钟输出 | 1 批 | wrapper 报 "0 ok / 7 fail" | 145 ok + 7 fail（解析不到末尾 "【完成】" 行）|

---

## 真实数据流（**完整对账**）

| 时点 | pool.db NULL | 备注 |
|---|---|---|
| 11:50 | 316 | 用户问"8:05 后没看到" |
| 12:30 | 316 | 上午修复后 NULL 数没动（m3 没真跑）|
| 14:30 | 316 | 下午用户要求手动跑 |
| 14:32 | 316 | 启动 batch 1（67 分钟）|
| 16:32 | 123 | batch 1 完，commit_in_loop 期间 commit 了 **152 条**（含 7 fail 但 7 fail 不写库，所以是 145 commit + 7 没 commit）|
| 16:50 | 116 | batch 2-8 都 0s 退出，NULL 数不变 |
| 17:10 | 116 | 116 = 113 Tavily + 1 知乎 + 1 微博 + 1 AIHOT **全 rejected** |
| 17:15 | 116 | 修 m3 `--source` 默认值（不影响 NULL）|
| 17:30 | 116 | 重跑 m3 159 条后 NULL 仍 116（rejected 不被 m3 处理）|
| 17:45 | 116 | 终态。**116 是 rejected 池子，本来就不该过 m3** |

**注意**：116 NULL 没清空是**预期行为**（rejected），不是 bug。**159 approved+NULL 全部判完是 17:15 之后**。

---

## 修法（按坑号倒序）

### 修 7：bash wrapper 用 `tee` + grep log 文件

**新 wrapper 模板**：
```bash
# ❌ 旧：$() 变量捕获大输出（截断风险）
output=$($PY $SCRIPT 2>&1)
echo "$output" | grep "完成"

# ✅ 新 1：tee 到文件 + grep log 文件
$PY $SCRIPT 2>&1 | tee /tmp/m3_run.log
grep "完成" /tmp/m3_run.log  # 永不截断

# ✅ 新 2：>> 追加到 log 文件
$PY $SCRIPT >> /tmp/m3_run.log 2>&1
grep "完成" /tmp/m3_run.log
```

### 修 6：m3 脚本 exit code 改用 `ok > 0` 判定

**新 `judge_topics_angle.py` L355**：
```python
# ❌ 旧：fail > 0 → exit 1
sys.exit(0 if stats["fail"] == 0 else 1)

# ✅ 新 1：ok > 0 → exit 0（部分成功也算成功）
sys.exit(0 if stats["ok"] > 0 else 1)

# ✅ 新 2（推荐永久方案）：永远 exit 0，靠 stats + log 报告 + db delta 验证
sys.exit(0)
```

### 修 5：m3 脚本默认 `--source` 改全 5 source

**`judge_topics_angle.py` L205**：
```python
# ❌ 旧：只 Tavily/AIHOT（中文平台被过滤）
parser.add_argument("--source", default="Tavily,AIHOT", ...)

# ✅ 新：全 5 source（覆盖所有平台）
parser.add_argument("--source", default="微博,知乎,抖音,Tavily,AIHOT", ...)
```

**附加守护**（推荐永久方案）：
```python
# 启动时检查 "有 NULL 但过滤后 0" → WARNING
if not pending and total_null > 0:
    print(f"⚠️ WARNING: 有 {total_null} 条 approved+NULL，本轮 --source 过滤后 0 条", file=sys.stderr)
    print(f"⚠️ 考虑调整 --source 包含更多数据源", file=sys.stderr)
```

### 修 4：audit_08x05 任务补 script 字段

**`jobs.json` audit_08x05 任务**：
```json
{
  "id": "audit_08x05",
  "schedule": {"expr": "5 8 * * *"},
  "script": "audit_topics_v3.py",  // ← 之前是 null
  "no_agent": true
}
```

### 修 3：3 个 m3 cron `script` 字段去参数 + wrapper

**wrapper `judge_angles_cron.sh`**：
```bash
#!/bin/bash
set -e
exec /home/renanzai/.hermes/hermes-agent/venv/bin/python3 \
    /home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py \
    --limit 200
```

**`jobs.json` 3 个 m3 任务**：
```json
{"id": "judge_angles_08x10", "script": "judge_angles_cron.sh", ...}
{"id": "judge_angles_12x00", "script": "judge_angles_cron.sh", ...}
{"id": "judge_angles_16x00", "script": "judge_angles_cron.sh", ...}
```

### 修 2：8:00 任务 next_run_at patch（jobs.json 1 行）

```json
{
  "id": "auto_media_8am_collect",  // 或类似 ID
  "next_run_at": "2026-06-07T08:00:00+08:00"  // ← patch 掉原来的 UTC 16:00
}
```

### 修 1：8:30 prompt `--timeout` → `--wait-timeout`

**8:30 推送 prompt 第 1 步**：
```bash
# ❌ 旧
python3 session_lock.py --name auto_media_top3_push --timeout 5

# ✅ 新
python3 session_lock.py --name auto_media_top3_push --wait-timeout 5
```

---

## 关键教训（写给未来的我）

### 教训 1：修别人代码时，自己代码也得审

5 个静默坑修完后，**我自己写的 wrapper 又制造了 2 个新坑**：
- 坑 6：直接拷贝了 m3 脚本的 `sys.exit(0 if stats["fail"] == 0 else 1)` 不质疑
- 坑 7：直接用 `output=$()` 捕获不质疑

**反模式**：
- ❌ 修问题时快速写新代码，不审自己的旧假设
- ❌ 把"已知工作"的代码模式直接照搬

**正确做法**：
- ✅ 修任何代码前，**先** grep 自己即将用的 pattern
- ✅ 写新 wrapper 时**先**问"有没有同样问题"
- ✅ 任何 `sys.exit(N)` 在批量任务里都要"为什么是 1 而不是 0"

### 教训 2：don't trust single signal

**5 + 2 个静默坑的共同模式**：
- `last_status=ok` 不可信
- `exit_code=0` 不可信
- `output=...` 变量不可信
- 单看 1 个字段永远不够

**正确做法**：
- ✅ 4 个交叉验证（last_status + last_error + last_delivery_error + 业务侧 db delta）
- ✅ batch 跑完必 `tail -50 /tmp/*.log` 看完整 log
- ✅ 报数字给用户前必 `SELECT COUNT(*)` 对账

### 教训 3：bash `$()` 是隐藏陷阱

`$()` 捕获**有上限**（实测 4-8 KB），超长输出**静默截断**。文档少提，但**实测如此**。

**永久规则**：
- ✅ 长跑任务（> 5 分钟）必 `tee /tmp/<job>.log` 留 log
- ✅ 永远 grep log 文件，不 grep `$output` 变量
- ✅ 任何 `output=$(long_running_command)` 都是反模式

### 教训 4：m3 评分模型有偏好（接受为特性）

**2026-06-06 实证**：159 条中文平台话题 → 0 条 ≥7 分。Tavily/AIHOT 平均 5.5-6.1，**显著高于**中文平台 1.3-1.5。

**不是 bug**，是 m3 在 B2B AI 评估上的合理判断：
- 知乎偏专业讨论（无内容角度）
- 微博娱乐热搜（CTR 强但 B2B 弱）
- 抖音视频（标题简略）

**接受 + 不试图修复**：
- 8:30 推送业务款 TOP 主要靠 Tavily/AIHOT
- 中文平台话题对引流款贡献显著（mid 4-6 分段）
- 不要因为"中文过不了 m3"就调 prompt 或阈值

### 教训 5：pool.db 两个 `status` 列不一样

`status` = 生产状态（pending/selected/writing/archived）
`review_status` = 审核状态（pending/approved/rejected/NULL）

**写 SQL 前必想清楚**：
- m3 看 `review_status='approved'`
- 8:30 推送看 `status='pending' AND review_status='approved'`
- dashboard 看两者组合

**反模式**：
- ❌ `WHERE status='approved'` —— 错列名
- ❌ `WHERE status IN ('approved', 'pending')` —— 跨语义过滤

---

## 改动登记

- 2026-06-06 落地本事故复盘文档
- 备份：
  - `judge_topics_angle.py.bak.20260606_143215`（修 sys.exit 之前）
  - `judge_topics_angle.py.bak.20260606_103811`（之前加 commit in loop + SIGTERM handler）
  - `scheduler.py.bak.20260606_125535`（修 per-job timeout）
  - `jobs.py.bak.20260606_125535`（加 dependency check）
  - `session_lock.py.bak.20260606_125535`（加 max_age）
  - `jobs.json.bak.20260606_125535`（加 depends_on + script_timeout + dashboard）
- 修复后：159 approved+NULL 全部判完（145 ok + 7 fail 写入 DB + 7 fail 重试可补救），116 NULL 是 rejected 不归 m3
- 8:30 推送业务款候选 19 条 + 引流款候选 3 条（中文平台 mid 4-6 段）

## 引用

- `references/cron-silent-noop-patterns.md` — 5 个静默坑 B1/A1/A2/D1/A2 详解 + 4 大类反模式
- `references/manual-m3-run-workflow.md` — 6 步手动跑 m3 任务 + 陷阱 17/18
- `references/cron-m3-script-hardening.md` — commit in loop + SIGTERM handler
- `references/cron-deployment-pitfalls.md` — 16 个 cron 部署坑
- `references/cron-8am-timezone-bug.md` — 8:00 时区错乱详解
- `references/cron-0830-push-workflow.md` — 8:30 推送的 session_lock pattern
