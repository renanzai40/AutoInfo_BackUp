# ⚠️ 陷阱 29：字段存在但下游 SQL 没引用它（2026-06-22 发现，类级别反模式）

### ⚠️ 陷阱 29：字段存在但下游 SQL 没引用它（2026-06-22 发现，类级别反模式）

**症状**：
- `event_date` 字段在 `judge_topics_angle.py` prompt 中正确输出（LLM 判定了事件发生时间）
- `event_date` 写入了 pool.db（5/804 条有值）
- **但 8:30 推送 SQL 的 WHERE 子句根本没看这个字段** → 过期话题堂而皇之出现在 TOP3 推送中

**根因**：
- 2026-06-12 加 `event_date` 字段时，只改了 `judge_topics_angle.py`（生产端）和 `freshness_maintenance.py`（衰减端）
- **忘了改 8:30 推送 prompt SQL**（消费端）——读路径没更新
- 这是类级别问题：任何新增字段，**必须 audit 所有读该表/该对象的 SQL 和代码路径**

**预防（永久规则）**：
- ✅ 新增任何字段后，立即 grep 所有读该表的查询和代码路径：
  ```bash
  grep -rn "SELECT.*FROM topics" ~/.hermes/profiles/content/cron/jobs.json \
    ~/.hermes/profiles/content/skills/ --include="*.md" --include="*.py" --include="*.json"
  ```
- ✅ 每个读路径逐一确认：新字段是仅用于 display，还是应该用于 WHERE/ORDER BY
- ✅ 写 SQL 时确认：这个 WHERE 子句真的过滤了我想要的所有维度吗？
- ❌ **不要在 SQL 里写 `SELECT *`** 然后认为"读到了这个字段"——读到不等于用了
- ❌ **不要假设** "这个字段会在推送 prompt 里被 agent 注意到"——agent 优先用 SQL 结果集排序，不会去扫描表 schema 找漏掉的字段

**关联**：陷阱 26（8:05 audit 缺 status 过滤）同属"SQL WHERE 子句不全"类问题。

**每天 07:30 衰减 SQL**（`freshness_maintenance.py`）：
```sql
UPDATE topics
SET freshness_score = MAX(6.0, 10.0 - CAST(julianday('now') - julianday(COALESCE(event_date, created_at)) AS INTEGER))
WHERE status = 'pending' AND freshness_score > 6.0
```

- **有 `event_date`**（LLM 推定的事件发生时间）→ 基于事件日期衰减
- **没有 `event_date`**（无明确时间线的旧话题）→ fallback 到 `created_at`
- 最低保底 6.0

**`event_date` 来源**：`judge_topics_angle.py` prompt 输出字段，LLM 根据标题和自身知识判断事件发生日期。零额外 API 成本（与 angle 判定共用同一次 LLM 调用）。
