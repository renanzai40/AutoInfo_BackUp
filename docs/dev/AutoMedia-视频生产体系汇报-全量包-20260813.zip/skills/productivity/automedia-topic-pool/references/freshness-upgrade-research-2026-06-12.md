# Freshness 升级调研 + event_date 实施记录（2026-06-12）

## 背景

用户发现话题池中一条「DeepSeek将发布其最新大模型V4」（score=8.71）是旧闻翻炒——V4 已上线多日。调研 freshness_score 是否能从"入库新鲜度"升级为"新闻新鲜度"。

## 各数据源发布时间元数据

### Tavily

| 模式 | 是否有 published_date | 实测验证 |
|------|---------------------|---------|
| `--topic general`（当前采集脚本在用） | ❌ 无 | 返回结构无此字段 |
| `--topic news` | ✅ 有，GMT格式 `Thu, 11 Jun 2026 12:10:35 GMT` | 实测每个 result 都带 |

`--time-range day` 与 `--topic` 是独立参数。前者只过滤搜索结果范围，不影响返回字段结构。`published_date` 只由 `--topic news` 决定。

### AIHOT

- **已有** `publishedAt` 字段（ISO 8601 UTC：`2026-06-11T08:00:00.000Z`）
- 当前只用于排序（最新排最前），**未用于计算 freshness_score**
- 可无缝集成

### 热搜（uapis.cn：微博/知乎/抖音）

- 无发布时间字段（热搜天然是今日事件）
- 可视为今日事件，freshness=10

## 实测数据：如果改 published_date 会怎样

| 来源 | 当前初始freshness | 改后 | 差异 |
|------|-----------------|------|------|
| 热搜 | 8.0 | 10.0 | 多2分，持续6天 |
| Tavily（`--topic news`） | 8.0 | 基于published_date | 多数情况+1（`--time-range day`已限制24h内） |
| AIHOT | 8.0 | 基于publishedAt | 多数情况0-1分差异（since=yesterday限制） |

## 关键发现：published_date 不能解决旧闻翻炒

freshness_score 无论基于 published_date 还是 created_at，衡量的都是**「这篇文章什么时候发的」**，而不是**「这个事件什么时候发生的」**。

像财联社那篇 DeepSeek V4 文章：文章本身是 6月10日新发的（freshness=9），但内容在炒 6月1日就发生的 V4 上线事件。**文章是新鲜的，事件是陈旧的。纯时间维度的 freshness 再升级也解决不了这个矛盾。**

## 最终实施：event_date 方案（2026-06-12 user 拍板）

不做 published_date 升级。改为两层共同治理时效性：

### 层 1：Layer 3（audit_08x05）旧闻识别
Prompt 新增"旧闻翻炒"剔除标准 + 重要规则，LLM 直接在审核层拦截旧闻。

### 层 2：event_date freshness 升级
在 `judge_topics_angle.py` 的 angle 判定 prompt 中新增 `event_date` 输出字段，让 LLM 根据标题和自身知识判断事件实际发生时间（以 YYYY-MM-DD 格式输出）。然后在 `freshness_maintenance.py` 中用 `COALESCE(event_date, created_at)` 替代 `created_at` 做衰减基数。

**为什么能治旧闻翻炒**：LLM 看到标题"将发布其最新大模型V4"，结合内部知识（V4 已是当前版本、已上线多日），输出 event_date="2026-06-01"（事件实际发生时间），freshness 从 9.0 降至保底 6.0，综合分从 8.71 降至 ~7.9，退出业务款 TOP10。

**不改采集脚本**，不改 Tavily `--topic` 参数，不依赖各数据源的发布时间元数据。全部靠 LLM 在已有角度判定调用中顺带输出 event_date，零额外 API 成本。

### 改动清单

| 文件 | 改动 |
|------|------|
| `pool.db` | `ALTER TABLE topics ADD COLUMN event_date DATE` |
| `judge_topics_angle.py` | PROMPT 新增 `event_date` JSON 字段 + 判定规则 + few-shot 示例升级 |
| `freshness_maintenance.py` | SQL: `julianday(created_at)` → `julianday(COALESCE(event_date, created_at))` |

### 设计原则：angle 和 freshness 各管各的

- angle_score：衡量"内容可生产性"，**不加 timeliness 维度**（user 明确否决不往 prompt 里塞旧闻判断）
- freshness_score：衡量"新闻新鲜度"，通过 event_date 让 LLM 间接提供事件时间线信息
- Layer 3：审核层直接拦截旧闻
- 三条线不重叠，各管各的事
