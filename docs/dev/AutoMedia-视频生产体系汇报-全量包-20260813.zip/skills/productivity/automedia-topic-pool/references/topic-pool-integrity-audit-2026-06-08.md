# Topic Pool 完整性审计 · 2026-06-08 实操复盘

> **触发场景**：用户报告"你的池子里又出现了已经选定并制作完成的话题"。
> **根因**：`pool.db`（待生产池）和 `PROJECT_REGISTRY.json`（已交付清单）**没有自动同步**——3 个独立 bug 叠加导致"已交付话题长期污染生产池"。

## 一、用户反馈与初始假设

**用户原话**（2026-06-08 早上）："你的池子里又出现了已经选定并制作完成的话题"

**agent 初始假设**（错了 2 次）：
- 假设 A：`status='pending'` 过滤应该挡住了 → 但 5 个已交付话题里 3 个还是 `selected`、2 个是 `archived`，**理论上不该在推送里出现**——但用户还是看到了
- 假设 B：可能是 8:30 推送 SQL 漏过滤 → 实际 8:30 推送**有** `status='pending'` 过滤，**不是** 8:30 推送的 bug

**真因**：3 个独立 bug 叠加（详见下文）。

## 二、4 步审计实操 transcript

### Step 1：先看 pool.db 当前状态

```python
import sqlite3
conn = sqlite3.connect("/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db")
cur = conn.cursor()
cur.execute("SELECT status, COUNT(*) FROM topics GROUP BY status")
# 结果：
# ('archived', 2)
# ('pending', 582)
# ('selected', 32)
# ('writing', 2)
# (status='published' = 0)
```

**第一个异常信号**：`status='published'` 永远 0 条——状态机的"已发布"节点**从来没人走到**。

### Step 2：同 title 跨 source 重复检测

```sql
SELECT t1.title, t1.topic_id, t1.source, t1.created_at,
       t2.topic_id, t2.source, t2.created_at
FROM topics t1
JOIN topics t2 ON t1.title=t2.title AND t1.topic_id < t2.topic_id
ORDER BY t1.title, t1.created_at;
```

**结果**：
```
'巴西队世界杯26人名单'
  6b0d124039... [抖音] 2026-05-19 08:00:35.711556
  877c78b372... [微博] 2026-05-19 08:00:35.711556

'中国航天员第8次太空会师'
  1ebb4caaac... [微博] 2026-05-25 08:00:49.105792
  de0ee672e7... [抖音] 2026-05-25 11:22:10.134409
```

**根因**：`auto_media_hot_collection_v3_20260525.py` 3 个流都 `md5(title + source)`：
- L891: `hashlib.md5((item['title'] + item['source']).encode()).hexdigest()` (流1 热搜)
- L908: `hashlib.md5((item['title'] + 'Tavily').encode()).hexdigest()` (流2)
- L918: `hashlib.md5((item['title'] + 'AIHOT').encode()).hexdigest()` (流3)

`INSERT OR IGNORE` 只对主键生效 → 同 title 跨 source 4 个不同 hash = 4 条入库。

### Step 3：topic_id 交叉 PROJECT_REGISTRY.json 找"已交付但漂移"

```python
import json
with open("/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/PROJECT_REGISTRY.json") as f:
    reg = json.load(f)
done_tids = {p["info"]["topic_id"] for p in reg["active"]
             if p.get("info",{}).get("topic_id")}
# 29 个 active 项目里 5 个有 topic_id
```

```sql
SELECT t.topic_id, t.title, t.status, t.source, t.updated_at
FROM topics t
WHERE t.topic_id IN ('a18ac3e30f1c', 'e6b645526ee7', '81d19106f755',
                     'ae520404506a', 'e71d13a33728');

-- 结果：
-- selected  a18ac3e30f1c 'Runway API 推出 Aleph 2.0 视频编辑功能'           AIHOT  2026-06-03
-- selected  e6b645526ee7 'DeepSeek将对其旗舰AI模型实施永久性75%折扣'      AIHOT  2026-06-02
-- selected  81d19106f755 'Lorai - AI驱动的智能营销内容生成工具'           Tavily  2026-06-02
-- archived  ae520404506a 'MiniMax M3即将发布，可免费试用'                 AIHOT  2026-06-02
-- archived  e71d13a33728 '腾讯混元发布智能体长期记忆插件Hy-Memory'        AIHOT  2026-06-02
```

**3 个还在 `selected`，2 个在 `archived`**——5 个都已交付（PROJECT_REGISTRY active），但 pool.db 完全不知道。

### Step 4：全代码库搜 status 回写钩子

```bash
# 任何脚本 UPDATE topics 改 status
grep -rn "UPDATE topics" ~/.hermes/profiles/content/scripts/ \
                          /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/
# → 0 命中（除 judge_topics_angle.py 改 angle_score 之外）

# status='archived' 字符串
grep -rn "status='archived'" ~/.hermes/profiles/content/scripts/ \
                              /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/
# → 0 命中
```

**根因**：池里 2 条 archived 是**历史手工 SQL 改的**，**不是任何脚本写的**——自动化回写钩子根本不存在。

### Step 5：检查 8:05 audit 过滤逻辑

```bash
# audit_08x05 prompt 第一步 SQL
grep "FROM topics" ~/.hermes/profiles/content/cron/output/audit_08x05/2026-06-08_08-06-39.md
# → "FROM topics WHERE review_status = 'pending'"
# ❌ 缺 AND status='pending'
```

对比 8:10 m3 / 8:30 推送 / 8:30 dashboard——**8:05 audit 唯独漏 `status='pending'`**。

## 三、3 个独立 bug 总结

| Bug | 位置 | 影响 | 修复方案 |
|---|---|---|---|
| **Bug A (陷阱 24)** | `auto_media_hot_collection_v3_20260525.py` L891/908/918 | 同 title 跨 source 产生 N 条 | 改 hash 公式 `md5(title)` + 加 `UNIQUE INDEX(title)` 兜底 |
| **Bug B (陷阱 25)** | 任何"项目交付完成"脚本（`regen_project_registry.py` / `safe_upload_wechat.py` 等） | 已交付话题永远停在 selected/archived | 在 `regen_project_registry.py` 末段加 `UPDATE topics SET status='archived' WHERE topic_id IN (...)` |
| **Bug C (陷阱 26)** | `audit_08x05` cron job prompt SQL | "已交付但 selected" 的话题被当新话题重新审 | SQL 加 `AND status='pending'` |

**3 个 bug 是独立路径**：
- 只修 A → 历史已漂移数据不会被回写（B 还在）
- 只修 B → 新采集的重复数据继续污染（A 还在）
- 只修 C → 只是把审核层兜底，前两个 root cause 还在污染 pool.db

## 四、用户当前的实际体验（已交付话题"再次出现"的路径）

虽然 8:30 推送被 `status='pending'` 过滤挡住（这 5 个都不是 pending），但用户还是看到了——可能路径：

1. **8:00 采集当天又重新插入同 hash（理论不会发生，OR IGNORE 跳过）**
2. **8:05 audit 把 selected 状态的话题错认为新待审**（Bug C 路径）→ 重新跑语义审核 → 重新打 angle_score → 8:30 推送看到的是**打过分的旧数据**而不是"又出现"
3. **用户主动查 pool.db**（dashboard / mcp 查询）→ 直接看到 selected/archived 的话题

**最可能是路径 2**：audit 8:05 跑完，那些 selected 状态的话题被重新审核 + 重新打分（如果 review_status 因为某种原因被重置成 pending），8:10 m3 给打分，8:30 推送看到了。

但目前 5 个话题的 review_status 都是 'approved'，8:05 audit 实际**不会**重审（因为只看 `review_status='pending'`），所以严格来说**8:30 推送没看到**——用户可能是**自己查 pool.db** 看到的。

## 五、用户拍板决策点

agent 给 user 列了 2 个待决策点：

1. **Bug A 改 hash 公式 → 会让历史重复数据留着但不再产生新重复，OK 还是清空重灌？**
2. **Bug B 给 5 个"已交付但还在池里"的话题：直接全部改 archived（保守，8:30 看不到），还是改 published（语义更准但用了 unused 状态）？**

**user 拍板**（user 实际回复前，需要先问）：见 conversation。

## 六、修复方案完整代码（user 拍板后可直接执行）

### 修复 1：采集脚本 hash 公式 + UNIQUE INDEX

**前置**：先在 pool.db 加 UNIQUE INDEX（修历史数据时方便定位）

```python
import sqlite3
conn = sqlite3.connect("/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db")
cur = conn.cursor()

# 加 UNIQUE INDEX（注意：如果有历史重复数据会报错，需要先清理）
try:
    cur.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_topics_title ON topics(title)")
    conn.commit()
    print("✅ UNIQUE INDEX 创建成功")
except sqlite3.IntegrityError as e:
    print(f"❌ 历史有重复数据，先清理: {e}")
    # 清理策略：保留 updated_at 最新那条
    cur.execute("""
        DELETE FROM topics WHERE topic_id NOT IN (
            SELECT topic_id FROM (
                SELECT topic_id, title, ROW_NUMBER()
                    OVER (PARTITION BY title ORDER BY updated_at DESC) AS rn
                FROM topics
            ) WHERE rn = 1
        )
    """)
    conn.commit()
    print(f"已删除 {cur.rowcount} 条历史重复")
    cur.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_topics_title ON topics(title)")
    conn.commit()
```

**改采集脚本**：把 3 行的 `md5(title + source)` 改成 `md5(title)`

```python
# auto_media_hot_collection_v3_20260525.py L891
topic_id = hashlib.md5(item['title'].encode()).hexdigest()  # 去掉 + item['source']
# L908
topic_id = hashlib.md5(item['title'].encode()).hexdigest()  # 去掉 + 'Tavily'
# L918
topic_id = hashlib.md5(item['title'].encode()).hexdigest()  # 去掉 + 'AIHOT'
```

**反向修改 INSERT**：去掉 `OR IGNORE`（依赖 UNIQUE 抛 IntegrityError → 显式 try/except）

```python
try:
    cur.execute("""INSERT INTO topics ...""", (topic_id, ...))
except sqlite3.IntegrityError:
    pass  # 同 title 已存在，跳过
```

### 修复 2：regen_project_registry.py 末段加回写

```python
# 找到 regen_project_registry.py 写完 PROJECT_REGISTRY.json 之后的位置，添加：
import sqlite3
DB_PATH = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db"

conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()
archived_count = 0
for proj in projects_active:  # 或 reg["active"]，看具体代码
    tid = proj["info"].get("topic_id")
    if not tid:
        continue
    cur.execute("""
        UPDATE topics
        SET status='archived', updated_at=CURRENT_TIMESTAMP
        WHERE topic_id=? AND status IN ('pending', 'selected', 'writing')
    """, (tid,))
    if cur.rowcount > 0:
        archived_count += 1
conn.commit()
conn.close()
print(f"✅ 已归档 {archived_count} 个已交付 topic（status → archived）")
```

### 修复 3：一次性清理 5 个漂移数据

```python
import sqlite3, json, datetime
DB = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db"
ts = datetime.now().strftime("%Y%m%d_%H%M%S")
LOG = f"/tmp/pool_archive_2026-06-08_log_{ts}.json"

# Step 1：SELECT 打印 + 备份
conn = sqlite3.connect(DB)
cur = conn.cursor()
cur.execute("""
    SELECT topic_id, title, status, source, updated_at
    FROM topics
    WHERE topic_id IN ('a18ac3e30f1c', 'e6b645526ee7', '81d19106f755',
                       'ae520404506a', 'e71d13a33728')
      AND status NOT IN ('archived', 'published')
""")
to_archive = cur.fetchall()
print(f"将归档 {len(to_archive)} 条：")
for r in to_archive:
    print(f"  {r}")
with open(LOG, 'w') as f:
    json.dump([{
        'topic_id': r[0], 'title': r[1], 'status': r[2],
        'source': r[3], 'updated_at': r[4]
    } for r in to_archive], f, ensure_ascii=False, indent=2)
print(f"备份到 {LOG}")

# Step 2：等 user 拍板后才执行 UPDATE
# cur.execute("""UPDATE topics SET status='archived', updated_at=CURRENT_TIMESTAMP
#                WHERE topic_id IN ('a18ac3e30f1c', 'e6b645526ee7', '81d19106f755',
#                                   'ae520404506a', 'e71d13a33728')
#                  AND status NOT IN ('archived', 'published')""")
# conn.commit()
```

### 修复 4：audit_08x05 prompt SQL 补过滤

找到 `audit_08x05` cron job 的 prompt（`~/.hermes/profiles/content/cron/jobs.json` 或 prompt 模板）：

```sql
-- 改前
SELECT topic_id, title, source_url, heat_score, source
FROM topics
WHERE review_status = 'pending'
ORDER BY heat_score DESC LIMIT 30;

-- 改后
SELECT topic_id, title, source_url, heat_score, source
FROM topics
WHERE review_status = 'pending'
  AND status = 'pending'              -- ✅ 加这一行
ORDER BY heat_score DESC LIMIT 30;
```

## 七、预防清单（永久规则）

- 改采集脚本的 `topic_id` 计算公式 → 必加 `UNIQUE INDEX(title)` 兜底
- 改 `regen_project_registry.py` → 必带 `UPDATE topics SET status='archived'`
- 改 `audit_08x05` / `8:30 推送` / 任何读 `topics` 的 SQL → 必想清楚 3 个 status 字段（`status` / `review_status` / `angle_score`）的组合
- 每月 1 号 watchdog 后加一步池子健康度报告（**待办**——可加到 automedia-cron-watchdog）
- 任何"项目交付完成"的 hook 脚本（`safe_upload_wechat.py` 等）→ 必带 topics 回写

## 八、相关陷阱对照

- **陷阱 1 (source 字段大小写)** —— SQL 字段大小写坑，2026-06-01
- **陷阱 17 (cron 静默无操作)** —— last_status=ok 但业务侧 0 变化，2026-06-06
- **陷阱 22 (dashboard last_run 是历史)** —— dashboard 信号解读，2026-06-06
- **陷阱 23 (手跑 m3 0 秒退出 = 健康)** —— 池子健康度信号，2026-06-06
- **陷阱 24 (采集 hash 错)** —— 本次新发现，2026-06-08
- **陷阱 25 (无回写钩子)** —— 本次新发现，2026-06-08
- **陷阱 26 (8:05 audit 缺过滤)** —— 本次新发现，2026-06-08

3 个新陷阱是"`pool.db` 与 `PROJECT_REGISTRY.json` 双 source of truth 漂移"的 3 个独立路径——共同构成"池子完整性"这一类问题。
