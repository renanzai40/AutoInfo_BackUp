# Cron 任务"静默无操作"反模式（2026-06-06 实测重大发现）

> **本 reference 是 cron-deployment-pitfalls.md 的姊妹篇，专注"任务跑了但没干活"这一类最难发现的失败。**
> 触发：手动跑 cron 任务处理 0 条 / 用户说"8:05 后任务没看见触发" / 推送数据陈旧 / cron 跑了 N 天但 pool.db 某字段没动 / last_status 全 ok 但业务侧 0 进展。

---

## 核心问题：cron 是 3 段流水线，last_status 只看段 2

```
[段 1: 任务定义]    [段 2: 脚本执行]    [段 3: 数据副作用]
jobs.json 字段      script 实际跑       pool.db / 文件系统真的变化吗
                ↓                ↓                    ↓
        last_status 取决于这里 = 段 2 是否报错
        ↑ 但段 1 错 / 段 3 错 = last_status 全 ok
```

**任何一段坏了，最后都标 `last_status=ok`，但实际业务侧完全没进展。**

---

## 静默无操作 4 大类（2026-06-06 实测 + 历史案例汇总）

### 类别 A：段 1 任务定义错（jobs.json 字段）

#### A1. `script` 字段为 null（最严重，长期隐藏）

**症状**：
- jobs.json 里 `"script": null`（不是字符串）
- hermes 跑 job 时跳过执行（取决于实现），`last_status` 保持 `ok` 或 `never_ran`
- **不会有任何错误日志**——脚本路径空 = 无事可做 = 静默
- 历史可能"上次改过"但忘了补 script

**2026-06-06 实测**：
- `audit_08x05` 任务（08:05 语义审核）`script: None`
- 任务从 5/11 创建至今**一直 no-op**（~ 26 天）
- Layer 3 审核从未实际跑过 → 159 条微博/知乎/抖音 pending 永远不 approve
- m3 任务 (`review_status='approved'` 过滤) 永远没数据可处理
- **用户从 8:30 推送看到的 75 条高分全是 Tavily/AIHOT 旧数据**，新进中文平台话题永远过不了 m3 那一关

**检测方法**（4 步）：
```bash
# 1. 直接 grep jobs.json
python3 -c "
import json
d = json.load(open('/home/renanzai/.hermes/profiles/content/cron/jobs.json'))
for j in d.get('jobs', []):
    if not j.get('script'):
        print(f'❌ {j[\"id\"]} | script is None/empty')
"

# 2. 跑 cron job 看输出文件 mtime
ls -la ~/.hermes/profiles/content/cron/output/<job_id>/

# 3. 看 pool.db / 业务侧是否有副作用
sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE ..."

# 4. last_status 仍 ok ≠ 健康（这是 A1 的关键反模式）
```

**修法**：
1. 补 script 字段（指向真实脚本）
2. 手动跑一次验证：`hermes cron run <job_id>`
3. **看 pool.db 真的有数据变化**（段 3 验证）
4. 不依赖 last_status

---

#### A2. `script` 字段带 CLI 参数（hermes 不支持）

**症状**：
```json
"script": "judge_topics_angle.py --limit 200"
```
- hermes 把整段当文件路径
- 报错：`Script not found: ...judge_topics_angle.py --limit 200`
- 任务标 `error`，**但** cron delivery 还是把这错误推给用户（如果设置了 deliver）

**修法**（已固化在 cron-deployment-pitfalls 坑 1.5）：
- 写 wrapper bash 脚本（`judge_angles_cron.sh` 包一层 exec python）
- jobs.json script 字段只写 `judge_angles_cron.sh`

---

#### A3. `script` 字段路径不在 `scripts/` 目录

**症状**：
- 真实脚本在 `/mnt/d/Hermes-Workspace/.../Scripts/`，但 jobs.json 写完整路径
- hermes `_validate_cron_script_path` 拦下，**symlink 也不行**（realpath 跨目录被拦）
- 任务标 `error`，`last_error` 含 `Script not found`

**修法**：把脚本 cp 到 `~/.hermes/profiles/<profile>/scripts/` 下。

---

### 类别 B：段 2 脚本执行"成功"但产出 0

#### B1. SQL 过滤排除所有候选数据（本次发现的最大坑）

**症状**：
- 脚本跑通，exit 0，输出 "✅ 没有待判定的 approved 话题"
- last_status=ok
- **但** pool.db 角度分 NULL 数 1 条都没减少
- 跑了 N 天，0 业务价值

**2026-06-06 实测**：
- `judge_topics_angle.py` 默认 `--source "Tavily,AIHOT"`
- WHERE 条件 `AND source IN ('Tavily', 'AIHOT')`
- 全部 159 条 approved+NULL 都是**微博/知乎/抖音**（Tavily/AIHOT 的 220 条已全部判完）
- 每次 cron 跑 41 条候选 → WHERE 过滤 → 0 条 → 输出 "✅ 没有待判定的"
- 静默跑了 N 周

**检测方法**（3 步）：
```bash
# 1. 跑 --dry-run 看候选数
python3 judge_topics_angle.py --dry-run --limit 200
# 期望输出：
#   待处理: 41 条  ← 应该有数字
# 实际错误：
#   待处理: 0 条
#   ✅ 没有待判定的 approved 话题  ← 静默 0 输出

# 2. 验证 SQL 过滤条件 vs 实际数据
python3 -c "
import sqlite3
c = sqlite3.connect('/path/pool.db')
n_total = c.execute('SELECT COUNT(*) FROM topics WHERE angle_score IS NULL AND review_status=\"approved\"').fetchone()[0]
n_after_filter = c.execute('SELECT COUNT(*) FROM topics WHERE angle_score IS NULL AND review_status=\"approved\" AND source IN (\"Tavily\",\"AIHOT\")').fetchone()[0]
print(f'approved+NULL: {n_total} | 过滤后: {n_after_filter}')
# 大量数据被过滤 = 坑
"

# 3. 跑 N 次看 db delta 是不是 0
before=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE angle_score IS NOT NULL")
sleep 60
after=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE angle_score IS NOT NULL")
echo "delta: $((after-before))"  # 0 = 静默坑
```

**修法**：
1. 改 default `--source` 为"全 5 个 source"（`微博,知乎,抖音,Tavily,AIHOT`）
2. 或者**动态探测** source 白名单：SQL `SELECT DISTINCT source FROM topics WHERE ...`
3. **加守护**：脚本启动时检查"无候选" + 实际有 NULL 数据 → 打印 WARNING 提示 source 过滤过严

**预防性修法**（推荐）：
```python
# judge_topics_angle.py 启动时加这行
import sys
total_null = con.execute("SELECT COUNT(*) FROM topics WHERE angle_score IS NULL AND review_status='approved'").fetchone()[0]
if not pending and total_null > 0:
    print(f"⚠️ WARNING: 有 {total_null} 条 approved+NULL 候选，但本轮 --source 过滤后 0 条", file=sys.stderr)
    print(f"⚠️ 考虑调整 --source 包含更多数据源", file=sys.stderr)
```

---

#### B2. WHERE 条件有时间范围/状态过滤，全部候选都过期

**症状**：
- 脚本 `WHERE created_at > datetime('now', '-7 days')`
- 实际数据全在 30 天前 → 0 候选
- 跑 1 次 0 条 + "✅ 没有待处理的"

**检测**：
```sql
-- 看 NULL 数据的 created_at 分布
SELECT 
  CASE 
    WHEN created_at > datetime('now', '-7 days') THEN '< 7 days'
    WHEN created_at > datetime('now', '-30 days') THEN '7-30 days'
    ELSE '> 30 days'
  END as bucket,
  COUNT(*)
FROM topics WHERE angle_score IS NULL
GROUP BY bucket
```

---

#### B3. `last_status=ok` 假阳性（已知但易忘）

**症状**：
- `no_agent=true` job 跑通但脚本路径找不到 → hermes 仍标 `last_status=ok`
- 输出文件存在但内容是空
- "Script not found" 类错误被 swallowed

**检测**：永远用 4 个交叉验证
- ✅ `last_status=ok`
- ✅ `last_error=None`
- ✅ `last_delivery_error=None`
- ✅ **业务侧有数据变化**（db delta > 0 / 文件 mtime 新 / 推送含新内容）

**只看 status 字段永远不够**。

---

### 类别 C：段 3 业务侧副作用全 0

#### C1. 脚本写了 db 但 commit 漏了

**症状**：
- 脚本 `cur.execute("UPDATE ...")` 跑了
- 但 `con.commit()` 在异常路径/末尾失败时漏掉
- cron exit 0，但 db 0 变化
- 下次 cron 跑同一批数据 = 重复工作

**修法**：commit in loop（每 N 条 commit 一次）
```python
# judge_topics_angle.py 已用此模式
for i, r in enumerate(pending, 1):
    cur.execute("UPDATE ...", ...)
    if i % 20 == 0:
        con.commit()  # 中间状态保存
con.commit()  # 末尾再 commit
```

完整模式见 `references/cron-m3-script-hardening.md`。

---

#### C2. 写到了错误 db / 错误路径

**症状**：
- 脚本里有 `DB = "/path/pool.db"`，但实际写到 `/tmp/test.db`（环境变量覆盖了）
- 业务侧 db 0 变化
- 找了一圈发现 db 在 `/tmp` 而不是 `/mnt/d/...`

**检测**：
```bash
# 看 db 文件 mtime
ls -la /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db /tmp/pool.db 2>/dev/null
# 两个 mtime 哪个新 = 哪个被写了
```

---

#### C3. 推送内容是缓存/旧数据

**症状**：
- 推送 cron 跑通，`last_status=ok`，飞书收到
- 但内容是 3 天前缓存的（SQL 没限定时间窗口）
- 8:30 推送永远推同一批高分话题

**修法**：SQL 必须含 `AND created_at >= ...` 或类似的"今日/本周"硬过滤。

---

### 类别 D：跨段组合（最阴险）

#### D1. 任务依赖链断了

**症状**：
- 8:00 采集 实际跑在 CST 16:00（时区错位）
- 8:05 审核 / 8:10 m3 正常 8:05/8:10 跑 → 找不到 8:00 跑的数据 → 0 候选 → 0 业务
- 看 8:05/8:10 last_status 全 ok，但实际啥都没干

**修法**：见 `references/cron-8am-timezone-bug.md` + 任务依赖图（jobs.json `depends_on` 字段）。

---

#### D2. 任务定义改对了，但 cron scheduler 还在跑旧版

**症状**：
- 改了 jobs.json + 重启 gateway
- 新字段（如 depends_on / script_timeout）**没生效**
- 旧版 job 仍按原 schedule 跑

**检测**：
```bash
ps -ef | grep hermes-cron  # 看进程启动时间
hermes cron list            # 看 next_run_at 是不是新版
```

---

## 检测手册：cron 任务"静默无操作"4 步诊断

任何怀疑"任务跑了但没干活"时，**按顺序跑这 4 步**：

```bash
# Step 1: 任务定义层（段 1）
python3 -c "
import json
d = json.load(open('/home/renanzai/.hermes/profiles/content/cron/jobs.json'))
for j in d.get('jobs', []):
    print(f'{j[\"id\"]} | script={j.get(\"script\")} | schedule={j.get(\"schedule\",{}).get(\"expr\")}')"

# Step 2: 任务执行层（段 2）
hermes cron list  # 看 last_status + last_error + last_delivery_error + 输出文件 mtime
ls -la ~/.hermes/profiles/content/cron/output/<job_id>/  # 输出文件 mtime

# Step 3: 业务副作用层（段 3，关键！）
# 验证 pool.db / 推送内容 / 文件系统真的有变化
sqlite3 /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db \
  "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL"
# 数值应该随 cron 跑下降，**长期不变 = 静默坑**

# Step 4: 手动跑一次 + 看 db delta
before=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL")
HERMES_CRON_SCRIPT_TIMEOUT=1800 python judge_topics_angle.py --limit 200
after=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL")
echo "delta: $((before-after))"
# delta=0 持续多日 = 静默坑
```

**核心原则：3 段全部验证，单看 last_status=ok = 不够。**

---

## 预防：把"段 3 副作用检查"加进 watchdog

**当前 watchdog（automedia-production-guard 段）**只检查 `last_status + last_error + 输出文件存在性`——**没检查业务侧 db delta**。

**建议强化**（P1 改进，可选实施）：

```python
# watchdog 跑时，加段 3 检查
def check_business_side_effect(j):
    """对每个 cron job，跑前后查 pool.db 业务字段 delta"""
    if 'judge_angles' in j['id']:
        before = sqlite_count('topics', 'angle_score IS NULL')
        # 触发 cron
        hermes_cron_run(j['id'])
        time.sleep(60)
        after = sqlite_count('topics', 'angle_score IS NULL')
        if after == before and j['last_status'] == 'ok':
            return f"⚠️ 段 3 副作用为 0（{before} → {after}）— 怀疑静默无操作"
    return "✅ 段 3 副作用正常"
```

这个强化**可加可不加**——但加完后 watchdog 能自动发现 A1/A2/B1 等静默坑。

---

## 真实案例：2026-06-06 单日发现 4 个独立静默坑

| 坑 | 类型 | 跑了多久 | 业务影响 |
|---|------|---------|---------|
| 8:30 prompt `--timeout 5` 错 | A2 | 数天 | 推送静默退出 |
| 8:00 任务时区错乱（DST/UTC） | D1 | 数周 | 8:00 实际跑 16:00 |
| 3 个 m3 cron `script` 带 `--limit 200` | A2 | 一直 | m3 cron 报错"找不到脚本" |
| `audit_08x05` script=None | A1 | 26 天 | Layer 3 审核从未跑过 |
| m3 脚本 default `--source Tavily,AIHOT` | B1 | 一直 | 159 条中文平台话题永远 0 候选 |

**5 个独立坑，全是 last_status=ok，但业务侧严重不健康。**

---

## 触发本 reference 的所有场景（不冗余）

| 症状 | 跳到哪一节 |
|------|----------|
| 任务 last_status=ok 但业务侧 0 变化 | Step 1-4 全跑 |
| jobs.json `script=null` 或 `script=...py --arg` | 类别 A |
| 脚本输出 "✅ 没有待处理的" 但 db 实际有数据 | 类别 B1（SQL 过滤排除）|
| db 文件 mtime 没动 / mtime 在 `/tmp` 而不在 `/mnt/d/...` | 类别 C2 |
| 8:00 / 8:10 等任务实际跑时间 ≠ 预期 | 类别 D1（时区/依赖）|
| 推送内容是几天前的同一批话题 | 类别 C3（推送没时间过滤）|
| cron gateway 重启后旧版还在跑 | 类别 D2 |

---

## 相关 reference（不重复造轮子）

- `references/cron-deployment-pitfalls.md` — 任务定义层（A 类）大部分已覆盖；本文件补充静默场景
- `references/cron-m3-script-hardening.md` — C1 commit in loop 模式
- `references/cron-8am-timezone-bug.md` — D1 时区坑详解
- `references/cron-0830-push-workflow.md` — 8:30 推送的 session_lock + Pre-production 抢锁
- `automedia-production-guard` SKILL.md "Cron 健康检查 Watchdog" 段 — 段 2 层监控
- `references/cron-watchdog-pattern-2026-06-04.md` — watchdog 4 步执行 + 9 pitfalls
