---
name: automedia-topic-pool
description: '壹目贯维热点话题采集与评分系统（Topic Pool）。覆盖：采集脚本架构、三层过滤漏斗、评分公式、Domain/标题正则维护规范、**池子完整性审计（重复检测 + 交付回写 + 8:05 audit 过滤）**、**漏采补偿机制（catchup_collection.py：0 入库日检测 + 预告话题跟进 + --apply 转正）**。触发：话题池异常调查、**用户报告大新闻漏采/0 入库日/要求补采**、评分逻辑修改、采集脚本修改、Layer3审核规则更新、**用户报告"池子里有已交付/已选过的老话题"**。 排除：不用于内容生产本身（归 automedia）；仅话题池运维时加载。'
version: 1.8.0
author: Hermes Agent for renan
license: MIT
tags: [automedia, topic-pool, hot-collection, content-strategy, integrity-audit, freshness]
---
## 系统定位

Topic Pool 是壹目贯维内容生产的「题材水源」。所有引流款/业务款内容均从池中选取。池子质量直接决定内容质量。

## 根本设计原则（2026-06-03 user 确认）

> **"话题池一定是为内容生产服务的。" —— user 2026-06-03**

池子不是为"看起来热闹"服务，不是为"流量指标好看"服务。**任何会让"无法写脚本的话题"进入池子、污染选题环节的设计都是 bug。** 这一原则在评估新功能、改公式、动 status 字段时优先级最高。

具体推论：
- 4.73 这种分衡量的是"流量潜力"，**不衡量"内容可生产性"** —— 这正是 2026-06-03 暴露的盲区
- Layer 3 审核通过 ≠ 一定能写脚本（"天涯神帖" approved 但无内容角度）
- "approved 但内容空"的话题是**结构性脏数据**，必须在前置过滤拦住

**核心文件**：
- 采集脚本：`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/auto_media_hot_collection_v3_20260525.py`
- 数据库：`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db`
- 域名黑名单：`pool.db → blocked_domains 表`
- 备份：`auto_media_hot_collection_v3_20260525.py.bak.20260601`
- 角度判定脚本：`scripts/judge_topics_angle.py`（详见 Layer 2.5）

---

## 采集管道架构（Three-Layer Funnel）

```
流1: 微博/知乎/抖音/B站热搜 API
  ↓ rank归一化
  ↓ Layer2 LLM相关性过滤
  → 写入 pool.db (review_status='pending')

流2: Tavily AI搜索（8个Query）
  ↓ 去重
  ↓ Layer1 Domain黑名单过滤
  ↓ Layer1.5 标题正则过滤  ←── TITLE_BLOCK_PATTERNS
  ↓ Layer2 LLM相关性过滤
  → 写入 pool.db (review_status='pending')

流3: AIHOT API精选
  ↓ 去重
  ↓ Layer1.5 标题正则过滤  ←── ⚠️ 2026-06-01之前流3绕过此层！
  → 写入 pool.db (review_status=NULL)  ← ⚠️ 之前不带此字段！
```

**Layer 2（LLM相关性预审）**：将话题分为 related/unrelated/uncertain，只有 related 和 uncertain 入库等待 Layer3 细审。

**Layer 3（语义Cron审核）**：`audit_08x05` cron job 每小时运行，读取 `review_status='pending'` 的话题，逐条判断是否为好新闻，通过则改 `approved`，不通过则 `rejected`。详见 `references/layer3-semantic-review-execution-patterns.md`（LLM-driven cron 的 DB 操作模式、mid-run 话题检测、内容验证流程）。⚠️ **首次查询 pending=0 时先查采集进程**：`ps aux | grep auto_media_hot_collection` + executions.db status —— 采集完成时间已从 08:05 拖到 08:27（08-10 实测 27.5 分钟），pending=0 大概率是「晚采集」而非「今日无话题」，轮询等采集完再审核（见 `references/audit-08x05-collection-health-triage-2026-08-03.md`）。⚠️ **入库数 ≠ pending 数**：AIHOT 流入库即 `review_status='approved'`（精选免审），只有流1/流2 话题进 pending —— 08-10 入库 5 条但 pending 仅 1 条是正常现象，不是漏审。

**Layer 3 审核维度（最新）**：
1. **内容质量**：是否记者/编辑原创 vs SEO内容农场/广告软文/聚合转载/工具导航
2. **信源质量**：知名媒体保留，新垃圾域名写黑名单
3. **旧闻翻炒（2026-06-12 新增）**：标题看似新闻，但事件已发生多日/产品已上线/事件已结束。例：标题说「将发布」但该产品已上线多日 → rejected。不确定时可 web_search 验证事件时间线。

---

## 评分公式

### 引流款（growth）
```
score = (heat_score/10) * 0.30 + correlation_score * 0.40 + freshness_score * 0.30
```

### 业务款（business）
```
score = (heat_score/10) * 0.10 + correlation_score * 0.60 + freshness_score * 0.30
```

### freshness_score + 7天推送硬过滤（2026-06-22 升级）

**2026-06-22 新增（三层机制）**：

| 层 | 机制 | 位置 | 效果 |
|----|------|------|------|
| 1 | **freshness_score 衰减** | `freshness_maintenance.py` (07:30 cron) | 每天衰减，最低保底 6.0 |
| 2 | **推送层 7天硬过滤** | 8:30 push prompt SQL | `COALESCE(event_date, created_at)` >7天的话题不出现在推送中 |
| 3 | **自动归档 >14天** | `freshness_maintenance.py` (07:30 cron) | 事件超过14天的话题自动 status→archived |
| 4 | **旧闻翻炒审核** | audit_08x05 prompt | Layer 3 审核时参考 event_date 判断话题是否过时 |

**重要**：event_date 是 LLM 角度判定时推定的事件发生时间，无 event_date 的话题用 created_at（入库时间）兜底。

### ⚠️ 已经两次单向修复导致副本不同步（2026-06-25 硬化）

**这是最高优先级的操作规则，不是建议。**

| 时间 | 漏洞 | 不同步持续 |
|------|------|-----------|
| 2026-06-09 → 06-12 | `judge_topics_angle.py` 模型迁移 DeepSeek，skill 包副本残留 MiniMax | **3 天** |
| 2026-06-20 → 06-25 | 采集脚本 6-20 修复（max_tokens/timeout/batch splitting）仅落 CRON 副本，DEV 副本未收到 | **5 天** |

两次都是同一个反模式：**只修了 cron 路径上的副本，忘了同步 dev 目录下的副本。**

**强制规则**（任何修改采集脚本/角度判定脚本后，最后一步必须是这个）：

```
# 1. 备份所有副本
cp /path/to/script.py /path/to/script.py.bak.$(date +%Y%m%d_%H%M%S)_tag

# 2. 修改一个副本（通常是 CRON 副本，生产直接跑的那个）

# 3. cp 到其他所有副本 + md5sum 验证
cp ~/.hermes/profiles/content/scripts/auto_media_hot_collection_v3_20260525.py \
   /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/auto_media_hot_collection_v3_20260525.py
md5sum ~/.hermes/profiles/content/scripts/auto_media_hot_collection_v3_20260525.py \
   /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/auto_media_hot_collection_v3_20260525.py
# 两个 md5sum 必须完全一致
```

**不 cp 就不算修完。** 文档里的"⚠️ 副本必同步"警告已被证明不够（写了仍发生 5 天不同步）。

### correlation_score 关键词分级

### correlation_score 关键词分级

| 分级 | 分值 | 关键词示例 |
|------|------|-----------|
| Tier1 直接AI创作核心 | business=10, growth=9 | aigc, ai内容, ai生成, ai视频, ai配音, 内容生产, 自媒体工具, deepseek, kimi, sora, 可灵... |
| Tier2 AI/模型相关 | business=8, growth=7 | 人工智能, ai模型, ai工具, ai行业, 视频生成, 文生视频, 配音, 语音合成, 大模型, gpt, openai... |
| Tier3 泛科技/商业 | business=6, growth=5 | 科技, 互联网, 芯片, 新能源, 出海, 数字化, 抖音, 腾讯, 阿里, 字节... |
| Tier4 大众话题 | business=3, growth=2 | 体育, 足球, 电影, 游戏, 天气, 社会, 娱乐... |
| Default | business=5, growth=4 | 其他 |

### ⚠️ 评分公式的盲区（2026-06-03 暴露）

**问题**：当前公式只衡量"流量潜力"和"业务相关度"，**完全缺一个维度：「角度可生产性 (angle_score)」**。

推论：
- "天涯神帖" corr=5.0（Default 档）+ heat=1.0 + fresh=9.0 = 4.73 看似高分，但**没有任何内容角度**可展开
- "MiniMax M3 模型发布" corr=10 + heat=1.0 + fresh=9.0 = 6.71 高分且**完美业务款**——但 4.73 这类话题会污染选题

**修正方案**：见下文 **Layer 2.5: LLM 角度判定**。原则是**不动公式权重**（公式衡量流量/相关度是设计合理的），**补一个独立维度**。

---

## Layer 2.5: LLM 角度判定层（前置过滤，A方案，2026-06-03 新增，**2026-06-05 升级 v2**，**2026-06-12 升级 v3 加 event_date**）

> 这是消费侧的**前置过滤**，**不进 v3 采集脚本**。v3 改动风险大（model name 散落 3 处、cron 600s 不够），消费侧加层是安全做法。

**v1 → v2 升级（2026-06-05）**：
- v1: 单一 `angle_score` 0-10，m3 把"内容可生产性 + bridge/CTA 可写性"混着评 → 漏判（旅行记忆 v1 判 3，bridge 实际可写）
- v2: 拆 3 维度 + risk_flag + suggested_bridge

**v2 → v3 升级（2026-06-12）**：
- 新增 `event_date` 输出字段：LLM 根据标题和自身知识判断事件实际发生时间（YYYY-MM-DD，无法判断给 null）
- 不增加 LLM 调用次数（与角度判定共用同一次调用）
- event_date 不进 angle_score 计算（不污染"内容可生产性"维度）
- event_date 写回 pool.db 后，freshness_maintenance.py 用 COALESCE(event_date, created_at) 做衰减
- 5/5 样本验证 schema 正确（详见 `references/llm-angle-judgment-v2.md` 5 样本表）
- **副作用**：v2 比 v1 分数普遍下降 1-2 分（更精确但阈值可能需要校准）

**触发时机**：approved 话题进入"选题→写脚本"流水线之前。

**机制**（5 字段 JSON 输出）：

```json
{
  "angle_score": 7,            // 0-10，>=6 放行
  "reason": "可从XX角度切入AI内容生产",
  "suggested_angle": "用15秒拆解..."
}
```

**两个调用方式**：

| 方式 | schedule | 优点 | 缺点 | 状态 |
|---|---|---|---|---|
| 批量 cron `judge_angles_08x10` | 08:10 对 approved 但未打分的话题批量判 | 消费时 0 延迟 | 每天 50-100 次 LLM 调用 | ✅ **2026-06-03 落地** |
| 实时懒加载 | 写脚本时按需调 | 只对实际用的 topic 调 | 每次写脚本多 5-15s 延迟 | 暂未用 |

**⚠️ 关键时序（2026-06-03 user 纠正）**：cron 必须跑在 08:30 推送**之前**，否则推送看不到 angle_score。**禁止把角度分 cron 排到 09:30**——那时推送已经发出去了。

实测时序：
```
07:30 maintenance (freshness decay)
08:00 采集 (实测 08:02 完成, 跑 2 分钟)
08:05 audit_08x05 语义审核
08:10 ★ judge_angles_08x10 (新 cron, 5-10 分钟跑完)
08:25 完成
08:30 推送 ★ 直接看 angle_score（融入推送文本）
09:30 watchdog
```

**jobs.json 字段**（实测 schema 2026-06-03，后经 wrapper 封装简化）：
```json
{
  "id": "judge_angles_08x10",
  "schedule": {"expr": "10 8 * * *"},
  "script": "judge_angles_cron.sh",
  "no_agent": true,
  "deliver": "local"
}
```
⚠️ cron scheduler 不接受 `script` 字段带参数，通过 `judge_angles_cron.sh` wrapper 固定传递 `--limit 200 --source 微博,知乎,抖音,Tavily,AIHOT`。

**推荐批量 cron**——LLM 调用成本几乎可忽略（每天 50-100 次 × ¥0.001 ≈ ¥0.05-0.1/天），但消费侧零延迟。

**实现细节**：
- 完整 prompt 模板 + 5-sample 验证结果 + API 调用 pattern + 失败模式：`references/llm-angle-judgment.md`
- 可重跑脚本：`scripts/judge_topics_angle.py`（独立文件，可直接 cron 调）
- ⚠️ **三副本必同步（2026-06-25 升级：双副本→三副本 + md5sum 强制校验）**：AutoMedia 采集脚本以**三个副本**存在，**任一都可能成为"先进版"**：

  | # | 位置 | 谁来用 | 风险 |
  |---|------|--------|------|
  | 1 | `~/.hermes/profiles/content/scripts/` | **cron 调度器**每天执行 | 修了但 dev 没同步 → 手动跑的是旧版 |
  | 2 | `/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/` | **手动开发/调试**，agent 默认从这读 | 修了但 cron 没同步 → cron 跑的是旧版 |
  | 3 | `skills/productivity/automedia-topic-pool/scripts/` | **skill 包副本**，通过 skill_view 部署 | 偶尔滞后，三副本中最不常用的 |

  **2026-06-25 真实事故**：6-20 修复（max_tokens=2000→6000, timeout=50→180）只同步到 cron 副本（#1），DEV 副本（#2）未同步 → DEV 副本 max_tokens=2000/timeout=50 撑了 5 天 → 用户手动跑时 LLM 去重全部降级为 hash 兜底。两副本 md5sum 不同（5e4f4940 vs a3182507）。

  **2026-06-09 事故（同模式）**：judge_topics_angle.py 的 cron 副本（#1）已迁移 DeepSeek-v4-flash，但 skill 包副本（#3）仍残留 MiniMax-M3 凭据。见上文 2026-06-12 条目。

  **强制规则**：
  1. ✅ **每次修改任何一个副本后**，立即 `cp` 到另外两个 + `md5sum` 校验
  2. ✅ `md5sum` 输出不一致 = 修改丢失，必须立即补齐
  3. ✅ 修完后在对话末尾跑一次三路 md5sum 作为验收（见下方 Recipe）
  4. ❌ 永远不要只修一个副本就以为"改好了"——cron 跑的副本 ≠ 你手动的副本
  5. ❌ 永远不要假设"这次改的只是小参数，不需要同步"——6-20 的 max_tokens=2000→6000 改的就是参数

  **三路 md5sum Recipe（每次改完必跑）**：
  ```bash
  md5sum \
    /home/renanzai/.hermes/profiles/content/scripts/auto_media_hot_collection_v3_20260525.py \
    /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/auto_media_hot_collection_v3_20260525.py \
    /home/renanzai/.hermes/profiles/content/skills/productivity/automedia-topic-pool/scripts/auto_media_hot_collection_v3_20260525.py
  ```
  输出应完全一致。不一致 = P0 bug，立即同步。

  涵盖脚本：`auto_media_hot_collection_v3_*.py`、`judge_topics_angle.py`、`auto_media_dashboard.py`。

**5/5 样本验证（2026-06-03 实测）**：

| 标题 | 启发式 | m3 实答 | 评估 |
|---|---|---|---|
| 天涯神帖 | 3 (字少启发式碰巧对) | 3 纯标签无事件 | ✓ |
| MiniMax M3 模型发布 | 3 (启发式错) | **10** 完美业务款 | ✓ m3 纠错 |
| BLG 2:1 IG | 3 (启发式错) | 3 电竞无AI关联 | ✓ |
| DeepSeek 75% 折扣 | 3 (启发式错) | **9** AI 商业事件 | ✓ m3 纠错 |
| 儿童节 | 1 (节日启发式对) | 1 节日 | ✓ |

**278 条全量实证（2026-06-03 跑完，73.6 分钟）**：
- 原始 278 跑：236 通过 / 42 失败（15.1% 失败率）
- 42 失败根因：m3 默认 `` 思考 + max_tokens=300 截断 JSON
- 修后重跑：max_tokens=1000 + prompt 强提示"不要 think"，预期 0% 失败
- 合并 236+42 = 278 全量最终结果在 `/tmp/llm_judge_278_merged_<ts>.jsonl`

**278 实证最终统计（2026-06-03 修正版）**：
- 启发式判 B 档的 278 条 → m3 重新判定后：
  - 救回业务款核心（m3 ≥8）：**29 条**（Tavily 21 + AIHOT 6 + 知乎 2）
  - 可做（m3 6-7）：**9 条**（m3 6: 1 / m3 7: 8）
  - 启发式+m3 双确认不可做（m3 <6）：**240 条**（m3 4-5: 78 / m3 2-3: 145 / m3 0-1: 17）
- 按 source m3 评分 ≥6 占比：
  - **Tavily: 69.4%（启发式全误判 25/36）**
  - **AIHOT: 100%（启发式全误判 8/8，业务款核心）**
  - 知乎: 3.8% / 微博: 1.0% / 抖音: 1.3%
- **结论**：m3 在 Tavily/AIHOT（AI 业务相关长尾）上**比启发式强 50-100 倍**；在微博/知乎/抖音（娱乐/民生）上和启发式判断一致

### ⚠️ Selection Bias 警告（2026-06-03 自审发现，必须重申）

**278 条实证只覆盖了启发式判 B 档的话题，不是全量**：
- 我特意挑了启发式 B 档的 278 条喂给 m3
- 所以"启发式判 A 0 条 = 启发式 100% 漏判业务款"是**错读**
- **正确表述**："**在 278 条启发式判 B 的样本里** m3 救回 38 条 (13.7%)"
- **没测过**启发式判 A 的那 100+ 条 m3 怎么评——可能 m3 也会救回更多

**下次任何 m3 vs 启发式对比必须**：
1. 先声明**采样范围**（从哪个子集）
2. 不用"启发式 0% 命中" = "启发式漏判 100% 业务款"这种错读

### ⚠️ Tavily 内容农场污染（2026-06-03 自审发现）

**修正前**：Tavily 救回 25 条 m3≥6
**修正后**（去内容农场）：Tavily 真救回 **23 条** m3≥6（2 条农场嫌疑）

**内容农场识别信号**（写新过滤层时用）：
- 标题含 `\d+款AI` / `实战案例` / `建议收藏` / `横评` / `日报` / `\d+月\d+日`
- 标题尾部带站点名（`10款AI视频生成工具，1天能快速生成100+条视频（建议收藏）` / `RunwayAi视频生成工具实战案例分享`）

**修正后业务款核心**：m3≥8 真救回 **26 条**（Tavily 真救回 18 + AIHOT 6 + 知乎 2）

### 阈值推荐（修正后，2026-06-03 user 拍板）

**推荐阈值 ≥7**（不是 ≥6）：
- ≥6 含 5-6 分"勉强可做"9 条（m3 自己说"需要聚焦"），1-2 条/天产能下不划算
- ≥8 漏 3 条真新闻（如 "Mythos 封印" = 9 分是新闻但偏窄）
- **≥7 留 29 条业务款核心**（修正后 26 条真业务款），数字契合 1-2 条/天产能
- 6-7 分边界条**人工复核**——m3 自己也不确定的那部分

**反例：1 步贯维选 029-06-03**：
- TOP 1：Runway API 推出 Aleph 2.0（m3=9, corr=10, growth=6.42）双满分级
- TOP 2：微软 MAI-Thinking-1（m3=9, corr=8, growth=5.62）
- TOP 3：Alphabet 800亿融资 + Anthropic IPO（m3=9, corr=7, growth=5.22）

**AIHOT 8 条实测救回（用户最关心）**：

**AIHOT 8 条实测救回（用户最关心）**：
- DeepSeek 75% 折扣 (corr=9, m3=9)
- MiniMax M3 模型发布 (corr=10, m3=10)
- TrapDoor 供应链攻击 (corr=9, m3=9)
- ChatGPT 长文编辑功能 (corr=8, m3=8)
- 格雷格·布罗克曼 OpenAI 72小时 (corr=8, m3=8)
- Anthropic 800亿融资 (corr=7, m3=7)
- Pixverse 角色设计工作流 (corr=5, m3=5)
- Codex 自我优化提示词框架 (corr=5, m3=5)
- **所有 8 条都是业务款核心素材，启发式判 B 档全误杀**

**关键设计原则**：
- LLM 只补"内容可生产性"维度，**不替 Layer 3 审核**（那个是"是否是好新闻"），**也不替 correlation 关键词**（那个是"和 AI 业务的相关度"）
- 误判代价 = 浪费一次写脚本尝试，**不污染数据库**（对比 D 方案批量归档 = 直接改 status，风险高）
- threshold（6 分）首次可猜，跑 1-2 周后看实际拦截效果再调
- **2026-06-12 user 确认：不要往 angle prompt 里塞 timeliness/旧闻判断维度。** freshness 的职责（新闻时间线）和 angle 的职责（内容可生产性）应该分开治理。"旧闻翻炒"交给 Layer 3 处理（审核层），不扩散到角度判定层。

### ⚠️ 硬过滤不只是排序优先级，是 prompt 入口条件（2026-06-05 user 反馈）

**原则**：在 08:30 推送 prompt 的 SQL 里，`angle_score >= 7` 必须是 `WHERE` 子句的**入口条件**（hard filter），不能只是 Python 排序后的 secondary filter。

**6-05 bug 复盘**（引流款被 angle=3 话题污染）：
- 原 prompt 业务款有 `angle_score >= 7` 过滤，引流款漏了 → 6-05 推送引流款 TOP3 出现"天涯神帖"(angle=3) + "华为徐直军"(angle=3)
- 修复后 SQL 加 `AND angle_score IS NOT NULL AND angle_score >= 7` → 修复后引流款只剩 2 条 angle>=7，触发空池提示（合理副作用）

**维护规范**：
- ❌ **禁止**在 prompt 里写"按综合评分排序，angle_score >= 7 的优先"——这是软约束，agent 排序时只把 angle>=7 提到前面，但 top3 凑不够数时仍会把低 angle 塞进来
- ✅ **必须**在 SQL `WHERE` 子句里加 `AND angle_score IS NOT NULL AND angle_score >= 7`——硬过滤，连查询结果集都进不去，更不会进 top3
- ✅ 空池时（hard filter 后某 category 0 条）必须触发"池空提示"，**不能**为了凑数放宽阈值

**改动登记**（避免下次又改回软约束）：
- 08:30 cron job (`7671da210b69`) prompt 2026-06-05 已修
- 修复后引流款只剩 2 条 angle>=7 → 明早 8:30 推送会附带"今日引流款池空"提示
- **任何后续调整 08:30 推送 prompt 的人**：先看本警示框，不要把 hard filter 改回软约束

**6-06 实测确认软空场景（expected）**：引流款 388 总话题中仅 1 个 angle>=7（"抖音禁止录播伪装为直播"，angle=7.0）。业务款 44 个 angle>=7，弹药充足。**这是 hard filter 修复后的合理预期**，处理方式见 `references/cron-0830-push-workflow.md` 的"池薄(soft-empty)预期场景"章节。

---

## 扩源 + 限热搜 + 清 NULL 招法（2026-06-05 user 拍板）

### 招 2：Tavily 关键词 8 → 16 组

**动机**：招 1+5 验证 v2 prompt 翻盘率仅 4.8%（v1=3-5 的话题 v2 几乎不"翻盘"到 ≥7）→ 真正扩池要靠**扩源**而不是改 prompt。

**v3 改动**（`auto_media_hot_collection_v3_20260525.py` line 130-152）：
- 原 8 组关键词 → **16 组**（8 旧 + 8 新）
- 新增 8 组覆盖 AI 业务款核心赛道：AI Agent / AI 数字人 / AI 配音工具 / AI 短视频 / Sora/可灵/即梦对比 / 国内大模型商业化 / AI 内容生产 ROI / AI 多模态
- `max_workers` 8 → 12（避免 16 并发触发 Tavily 限流）

**预期收益**：
- Tavily 命中率 48.4%（v1 实证），是 AI 业务款金矿
- 16 组 × 10-15 结果/组 = 160-240 候选/天
- Layer 1.5 + Layer 2 + 信息密度 + 去重 5 重过滤后入库 ~30-50 条
- m3 angle 判定 50%+ 通过 ≥7 → **每天 +15-25 条 angle>=7 业务款**

**风险**：
- v3 跑批时间从 ~3 分钟延长到 ~5-7 分钟
- audit_08x05 (08:05) 仍能正常看到 8:00 采集结果（v3 在 8:00 开始，5-7 分钟内完成）
- max_workers=12 避免 Tavily 限流

### 招 4：8:10 cron 能力扩展

**动机**：v1 角度判定 cron --limit 100/天，能力不够清 177 条历史 NULL + 每天 ~50-100 条新进库。

**改动**（`/home/renanzai/.hermes/profiles/content/cron/jobs.json`）：
- `judge_angles_08x10` script: `--limit 100` → **`--limit 200`**
- 新增 `judge_angles_12x00` cron (0 12 * * *) — 清历史 NULL 兜底
- **⚠️ 重要：2026-06-06 实测发现 `--limit 200` 实际只处理 ~41 条**（不是 200）。详见 `references/manual-m3-run-workflow.md` 的"陷阱 17"。手动跑 m3 任务的完整 6 步流程（含 background exit_code 占位符陷阱）也在该 reference。
- 新增 `judge_angles_16x00` cron (0 16 * * *) — 清历史 NULL 兜底
- 三轮共 600 条/天角度判定能力

**预期**：
- 3-5 天清完 177 条历史 NULL
- 之后 3 个 cron 持续清新进库 + 兜底
- 不会撞车（hermes cron profile sequential + at-most-once，按 trap 9）

### 招 3：限热搜源对业务款贡献（**user 拍板 实施**）

**决策**：**实施**（user 6-05 决定做，agent 揭穿收益小后仍坚持）

**改动**（`auto_media_hot_collection_v3_20260525.py`）：
- **line 890**：`cat = 'business' if any(kw.lower() in item['title'].lower() for kw in BIZ_KW) else 'growth'` → `cat = 'growth'`
- **line 810-812**：BIZ_KW 定义保留但**标 deprecated**（避免破坏其他可能引用的代码，**不删除**）

**实际影响**：
- 12 条"热搜伪 business"（微博 2 + 知乎 8 + 抖音 2）从 business 改 growth
- 8:30 推送 SQL `WHERE angle_score >= 7` **不分 category**，2 条知乎 m3 判≥7 的改 cat 仍入选
- pool.db `category` 字段语义更准（热搜源话题不再误分类为 business）
- m3 调用**没省**（cron 角度判定不分类别）

**真实收益**：**接近 0**（agent 揭穿过，user 仍坚持——尊重决策）
- 数据卫生价值：pool.db 字段更准，未来分析 cat 分布时不被热搜伪 business 误导
- 心理价值：消除"12 条伪 business 一直占着业务款池"的不爽感

**反模式**：
- ❌ **不要**因为这次改完没明显效果就觉得"招 3 没意义"——这是 user 拍板的决策，价值是数据卫生 + 心理清爽
- ❌ **不要**恢复 BIZ_KW 判定（user 明确说改了）

### 数据库变更

```sql
-- 2026-06-05 ALTER TABLE topics 加 2 列（招 1+5 v2 升级）
ALTER TABLE topics ADD COLUMN suggested_bridge TEXT;
ALTER TABLE topics ADD COLUMN risk_flag TEXT;
```

### 反模式（2026-06-05 固化）

- ❌ **不要回灌 v1 存量话题**（翻盘率仅 4.8%，回灌不扩池）
- ❌ **不要静默清空 v1 角度分**让 cron 自然补（伪回灌）
- ❌ **不要因为 v2 失败率高就回滚 v1**（v2 设计正确，限流是 m3 自身问题）
- ❌ **不要在 cron 跑时手动跑批量补 v1 NULL**（让 cron 自然处理，1-2 周清完）
- ❌ **不要改 v3 line 879 不和 user 沟通**（招 3 收益小，agent 已揭穿，等拍板）
- ❌ **不要让 v3 跑批时 importlib dry-run**（v3 假 import 真执行，陷阱 2）
- ❌ **不要加热搜源 API**（头条/百度/快手等 99% 命中失败，浪费 m3）
- ❌ **不要降 angle 阈值到 5/6**（bridge 不好的灰色话题污染）

---

## Layer 1.5 标题正则黑名单（TITLE_BLOCK_PATTERNS）

> ⚠️ **维护规范**：新增垃圾源后必须追加到正则列表+域名黑名单，两道一起加。单独加一道不够。

```python
TITLE_BLOCK_PATTERNS = [
    r'AI快讯网',           # 聚合内容农场
    r'AI工具网',           # 工具导航聚合
    r'AI工具导航',         # 工具导航聚合
    r'什么值得买',         # SEO内容农场
    r'\(2026年最新\)',    # SEO标题特征
    r'，\w+技巧$',         # 教程类标题
    r'^如何\w+',           # 教程类标题
    r'^AIGC?\w*[资工具导]', # AIGC工具导航类
    r'\| ?AI工具导航',      # 站点导航类标题
    # 2026-06-01 精准堵漏
    r'点点资讯',           # 聚合内容农场
    r'雷峰网',             # 聚合内容农场
    r'^我的.*AIGC',        # UGC标记类（如"我的第一支AIGC短片"）
    r'^#\w+\s',            # 纯hashtag开头（如"#ai #aiart"）
    # 2026-06-01 二次堵漏（工具站误判教训）
    r'鹤写AI',             # AI工具官网（非新闻源）
    r'万维易源',           # AI工具聚合站
    r'AtomGit',            # 代码托管转载，非新闻
    r'Brain ?Pod',         # AI工具站
]
```

## Domain 黑名单维护规范

### 写入时机
- 发现新垃圾域名的内容进入池子时
- Layer 3 审核发现某域名下话题连续为垃圾时

### 推荐理由写法
```sql
INSERT OR IGNORE INTO blocked_domains (domain, reason, blocked_by) VALUES ('domain.com', '一句话原因', 'agent')
```

### 已block域名（部分）
| 域名 | 原因 | 添加时间 |
|------|------|---------|
| diandian.com | 点点资讯聚合内容农场，无原创记者，SEO标题党 | 2026-06-01 |
| leifeng.com | 雷锋网聚合内容农场，转载为主无原创报道 | 2026-06-01 |
| instagram.com | Instagram UGC内容聚合，非新闻源 | 2026-06-01 |
| aig123.com | AI工具导航聚合页，无原创内容 | 历史 |
| www.53ai.com | AI工具导航聚合页，无原创内容 | 历史 |
| ... | ... | ... |

---

## 关键设计原则（2026-06-01 确认）

### ✅ 正确的评估逻辑
- **微博热搜话题天然无source_url** —— 它们本身就是新闻事件，不需要二次来源
- Layer 3（语义Cron）是"好新闻"的最终判断层，应该加强它，而不是在评分层做预判
- `source_url`为NULL的话题**不应在评分时降权**

### ❌ 错误的设计（禁止使用）
- **方案B误区**：将「信息可追溯性」（source_url是否有值）等同于「新闻质量」，对无URL话题全局降权
- 后果：微博热搜（无URL但本身即新闻）会被误杀，与「追求好新闻」的底层逻辑相悖

### ✅ 正确的修复路径
当池子出现异常话题（聚合内容农场、UGC标记类）时：
1. **优先堵入口**：在 TITLE_BLOCK_PATTERNS 追加正则 + 在 blocked_domains 加域名
2. **同时清存量**：将历史异常话题重置为 `review_status='pending'`，让 Layer 3 重新审核
3. **不改变评分公式**：评分公式负责衡量「与业务的相关程度」，不是「信息可信度」

### ✅ 数据卫生（2026-06-03 二次教训：禁止批量归档）

> 🔴 **user 6-02 + 6-03 两次揭穿"批量归档"是擅自行动**。规则固化：

**绝对禁止**（不经验证 + 不经用户同意）：
- ❌ 批量 `UPDATE topics SET status='archived' WHERE ...`（**未 SELECT 打印 + 未 JSON 备份 + 未用户确认**）
- ❌ 启发式正则跑出 N 条就默认是垃圾，准备批量删/归档
- ❌ "看着像 B 档所以是 B 档"的直觉判断

**必须做**（任何批量操作前）：
1. **先验证**——启发式判定要跑反证，看 92% 假阳性那种坑（见下文 PITFALL）
2. **先 SELECT 打印**——让人眼确认范围
3. **先 JSON 备份**到 `/tmp/pool_<action>_backup_<ts>.json`
4. **先问用户**——clarify 列出方案，让用户选
5. **等用户确认**——才执行 UPDATE/DELETE

**反例**（2026-06-03 user 揭穿）：
- agent 跑启发式判 278 条 = B 档，准备 `status='archived'` 批量归档
- user 质疑："这 278 条是不合规的条目不是所有条目对吧"
- 跑反证：**假阳性 92%**（256/278 误判），8 条 AIHOT 业务款核心全部中招
- 教训：**启发式判出来的 B 档不是真 B 档**，必须验证

**最稳的修法**（也是 2026-06-03 后选定的）：
- **不动 status 字段**（不批量归档）
- **加 Layer 2.5 消费侧前置过滤**（不污染历史数据）
- 误判代价 = 浪费一次写脚本尝试，可重试

---

## 常见异常话题类型及处理

| 类型 | 示例 | 处理方式 |
|------|------|---------|
| 聚合内容农场 | "视频生成- AI快讯网" | Layer1.5正则 + Domain黑名单 |
| 点点资讯 | "AI视频生成\|点点资讯" | Domain黑名单（diandian.com） |
| 雷锋网 | "视频生成_雷峰网" | Domain黑名单（leifeng.com） |
| UGC/个人分享 | "我的第一支AIGC短片" | Layer1.5正则 `r'^我的.*AIGC'` |
| 纯Hashtag标题 | "#ai #aiart #aigc" | Layer1.5正则 `r'^#\w+\s'` |
| AIHOT绕过过滤 | 流3无Layer1.5 | 修改采集脚本流3过滤逻辑 |
| **内容不可生产（vague title）** | "天涯神帖"、"姆巴佩"、"儿童节" | **Layer 2.5 LLM 角度判定前置过滤**（不动 status） |

### 触发条件

**必须加载本 skill 的场景**：
- **用户报告池子里话题过期（"这不是新闻"）**（→ 加载本 skill + `references/freshness-hard-gate-2026-06-22.md`，检查 event_date/created_at 分布和推送 SQL 的 WHERE 条件）
- **改推送 SQL 的任何过滤条件**（→ 确认 3 个硬过滤维度全在：status + angle_score + event_date）
**触发条件**：
- **用户报告池子里话题过期（"这不是新闻"/"这话题没法做"）**（→ 加载本 skill + `references/freshness-hard-gate-2026-06-22.md`，检查 event_date/created_at 分布和推送 SQL 的 WHERE 条件）
- **用户报告"池子里又出现已选定/已制作完成的话题"**（→ **优先排查机制而非手动归档**：检查 `pool_sync.py` 是否在项目初始化时调用了，再跑 5 步完整性审计。参考 `references/topic-pool-integrity-audit-2026-06-08.md`）
- 需要修改评分公式或关键词分级
- 需要修改采集脚本（任何filter层）
- 需要更新Domain黑名单
- 调查 Layer3 审核结果
- 任何涉及 `topics` 表的批量操作（SELECT/UPDATE/DELETE）
- **新功能：设计/调整 Layer 2.5 LLM 角度判定层**（prompt、阈值、cron 时机）
- **执行 cron 08:30 推送**（看 `references/cron-0830-push-workflow.md` 7步流程 + session_lock pattern）
- **写新 cron 任务 wrapper**（看 `references/cron-wrapper-defensive-args.md` 防御性参数模板）
- **给 user 推 2 选 1 选题**（看 `references/topic-selection-decision-framework.md` 业务款 vs 引流款框架）| - **debug 业务款/引流款池空 / 阈值冲突**（看 `references/topic-selection-decision-framework.md` 反模式章节）\n- **推送中涉及已弃用技术栈话题**（看 `references/cron-0830-push-workflow.md` 陷阱 28）

**相关 cron job**：
- `audit_08x05`（08:05执行）：Layer 3 语义审核
- `采集脚本`（每日08:00执行）：流1+流2+流3 采集写入
- `judge_angles_08x10`（08:10执行，**已落地 2026-06-03**）：Layer 2.5 LLM 角度判定（**必须在 08:30 推送前打完**）
- `auto_media_top3_push`（08:30执行，**已固化 2026-06-06**）：推送 TOP3 等待用户选择，详见 `references/cron-0830-push-workflow.md`

---

## 章节导航（JiT Loading）

> 主文件保留核心流程。以下章节已移至 references/，按需加载：

| 章节 | Reference | 行数 |
|------|-----------|------|
| ⚠️ Cron 部署相关致命陷阱（2026-06-01 新增） | `references/pitfalls-cron-deployment.md` | 908 |
| ⚠️ 致命陷阱：池子完整性（2026-06-08 新增，3 个结构性 bug） | `references/pitfalls-pool-integrity.md` | 465 |
| 🔒 池子完整性的 4 道防线设计（2026-06-08 固化） | `references/pool-integrity-four-defenses.md` | 159 |
| 📋 陷阱 31（2026-06-30 新增）：`status='selected'` 不意味着「已选题未生产」——必交叉验证 PROJECT_REGISTRY | `references/pitfall-31-selected-vs-registry.md` | 113 |
| ⚠️ 致命陷阱：SQL 查询与脚本操作（2026-06-01 新增） | `references/pitfalls-sql-and-scripting.md` | 70 |
| ⚠️ 陷阱 29：字段存在但下游 SQL 没引用它（2026-06-22 发现，类级别反模式） | `references/pitfall-29-field-not-referenced.md` | 38 |
| ⚠️ 致命 PITFALL（2026-06-03）：启发式判定不可靠，92% 假阳性 | `references/pitfall-heuristic-92pct-false-positive.md` | 20 |

