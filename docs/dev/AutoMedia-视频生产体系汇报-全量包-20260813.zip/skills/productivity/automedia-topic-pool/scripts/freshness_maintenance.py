#!/usr/bin/env python3
"""AutoMedia 新鲜度衰减维护 — no_agent 脚本模式。

纯 SQL 操作，零 LLM 依赖，<5s 完成。
每天 07:30 由 cron scheduler 执行。

Changes:
- 所有 status='pending' 的 topics 按事件时间(event_date)衰减 freshness_score
- 公式: MAX(6.0, 10.0 - (julianday('now') - julianday(COALESCE(event_date, created_at))))
- 有 event_date 时按事件时间衰减，没有则回退到入库时间
- 最低保底 6.0

2026-06-12 新增: COALESCE(event_date, created_at) — 让 freshness 反映新闻事件时间而非入库时间
"""

import sqlite3
import sys
from datetime import datetime
from pathlib import Path

DB_PATH = Path("/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db")

def main():
    if not DB_PATH.exists():
        print(f"[FATAL] DB not found: {DB_PATH}", file=sys.stderr)
        return 1

    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    # 1. 执行衰减
    cur.execute("""
        UPDATE topics
        SET freshness_score = MAX(6.0, 10.0 - (CAST(julianday('now') - julianday(COALESCE(event_date, created_at)) AS INTEGER))),
            updated_at = datetime('now')
        WHERE status = 'pending' AND freshness_score > 6.0
    """)
    updated = cur.rowcount
    conn.commit()

    # 2. 获取分布
    cur.execute("""
        SELECT freshness_score, COUNT(*) as cnt
        FROM topics
        WHERE status = 'pending'
        GROUP BY freshness_score
        ORDER BY freshness_score DESC
    """)
    dist = {row["freshness_score"]: row["cnt"] for row in cur.fetchall()}

    # 3. 总计数
    cur.execute("SELECT status, COUNT(*) as cnt FROM topics GROUP BY status")
    summary = {row["status"]: row["cnt"] for row in cur.fetchall()}

    conn.close()

    # 输出报告
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"# 新鲜度维护完成 — {now}")
    print()
    print(f"**更新话题数：{updated} 条**")
    print()
    print("当前 freshness_score 分布：")
    for score in (10, 9, 8, 7, 6):
        count = dist.get(score, 0)
        print(f"- {score} 分：{count} 条")
    print()
    status_str = " / ".join(f"{k}={v}" for k, v in sorted(summary.items()))
    print(f"**数据库状态快照**：{status_str}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
