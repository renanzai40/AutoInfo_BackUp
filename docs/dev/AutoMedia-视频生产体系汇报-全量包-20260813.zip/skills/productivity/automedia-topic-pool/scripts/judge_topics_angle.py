#!/usr/bin/env python3
"""
judge_topics_angle.py — 角度分判定独立脚本（2026-06-08 切换到 DeepSeek-v4-flash）

设计目标：
  - 独立可运行（不被 v3 采集脚本耦合）
  - 可手动跑：python3 judge_topics_angle.py [--limit N] [--dry-run]
  - 可被 cron 调：judge_angles_08x10
  - 输出：写回 pool.db 的 angle_score / angle_reason / angle_judged_at

时序：
  08:00 采集完成 (~08:02)
  08:05 audit_08x05 完成 (~08:07)
  08:10 本脚本启动 (judge_angles_08x10)
       ↓ ~5-10 分钟跑完
  08:25 完成
  08:30 推送 cron 看到 angle_score 字段，融入推送文本

前置条件：
  - pool.db topics 表有 angle_score/angle_reason/angle_judged_at 三列（已 ALTER）
  - .env 有 OPENCODE_GO_API_KEY（内容 profile 已配置）

参数：
  --limit N       最多处理 N 条（默认 100）
  --dry-run       不写库，只 print 将要处理的
  --source X      只处理指定 source（默认 Tavily,AIHOT 优先）
  --min-corr N    只处理 correlation_score >= N 的（默认 0，兜底过滤）

返回：
  退出码 0 = 全部成功
  退出码 1 = 部分失败（>= 1 条 LLM 错误）
  退出码 2 = 致命错误（如 DB 连接失败）
"""
import json, os, re, sys, time, argparse, sqlite3, subprocess, signal
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from string import Template

# === 加载 env ===
env_path = Path("/home/renanzai/.hermes/profiles/content/.env")
env_vars = {}
if env_path.exists():
    for line in env_path.read_text().splitlines():
        if "=" in line and not line.strip().startswith("#"):
            k, v = line.split("=", 1)
            env_vars[k.strip()] = v.strip()
# 2026-06-08: 从 MiniMax-M3 切换到 DeepSeek-v4-flash (opencode-go)
API_KEY = env_vars.get("OPENCODE_GO_API_KEY")
BASE_URL = env_vars.get("OPENCODE_GO_BASE_URL", "https://opencode.ai/zen/go/v1")
MODEL = "deepseek-v4-flash"
if not API_KEY:
    print("FATAL: OPENCODE_GO_API_KEY not set in .env", file=sys.stderr)
    sys.exit(2)

DB = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db"

# === Prompt v2 (2026-06-05 升级: 拆 3 维度 + risk_flag + suggested_bridge) ===
# 改动（基于 brand-cta-review Section 0 Topic Selection Gate 三问）：
#   v1: angle_score 单一分（混淆内容可生产性 + bridge 可写性）
#   v2: 拆 3 维度（content_score/bridge_score/cta_score）+ risk_flag + suggested_bridge
#       final angle_score = min(content, bridge, cta) - risk_penalty
# 目的：让 LLM 在 bridge 维度上做"是否能 3 句话内自然桥到 AI 内容生产"显式判断
#       防止 v1 那种"旅行记忆 angle=3 但其实有桥"的漏判
# 注意：JSON 内的 {} 和 .format() 冲突 → 用 string.Template ($var) 避开
PROMPT = """你是「壹目贯维」内容总监助理。壹目贯维是 B2B AI 内容生产服务商，主营 AI 视频生成/AI 配音/AI 短视频批量生产。

判断下面这条话题标题，**能不能在 5-15 秒短视频里讲清楚、并自然桥到"AI 内容生产"业务**。

【必须直接输出 JSON，不要 <think> 思考标签】
只输出严格 JSON：
{
  "content_score": <0-10>,
  "bridge_score": <0-10>,
  "cta_score": <0-10>,
  "risk_flag": "none|disaster|politics|privacy|sensitive",
  "suggested_bridge": "<一句话桥接方向；final<6 给 null>",
  "event_date": "<该事件发生的具体日期，格式 YYYY-MM-DD；无法判断给 null>"
}

【content_score】标题本身是否有事件/数据可展开
- 0-3: 纯节日/纯人名/3字以下无数字
- 4-5: 有事件但信息模糊
- 6-7: 有清晰事件，5-15秒可讲
- 8-10: 完美（AI 行业新闻/产品发布/技术突破/具体数据）

【bridge_score】（核心新增维度）按 brand-cta-review Topic Selection Gate 三问判断

问1：话题核心概念与"AI 内容生产"有没有天然连接？
- 天然连接类型（bridge 高分）：内容传播/假信息 / 内容生产工具/创作 / 热点追踪/信息获取 / AI 行业新闻 → bridge 6-10
- 无法桥类型（bridge 低分）：纯娱乐/个人体验/情感 / 投资/金融/政策分析 / 纯社会事件 → bridge 0-4

问2：桥的方向是否在"AI 内容生产"业务线上（热点追踪/文案生成/多平台发布）？
- 同向：bridge 不变
- 走偏（投资情报/数据分析/个人效率工具）：bridge -2

问3：硬桥是否比不桥更差？
- 强行桥 = 非 sequitur 感：bridge -3
- 灾难/政治敏感（即使事件大也不桥）：bridge = 0-1

bridge 总分 = 问1结果 + 问2/问3调整，范围 0-10

【cta_score】壹目贯维"AI 内容生产公司"身份能否自然承接
- 0-3: CTA 硬塞会"非 sequitur"或违反"零承诺原则"
- 4-5: CTA 勉强能写但要绕弯
- 6-7: CTA 自然承接（"AI 追踪热点/AI 生成内容/AI 多平台发布"任一具体功能可挂）
- 8-10: CTA 完美承接（话题本身在 AI 内容生产业务生态里）

【risk_flag】
- "disaster": 矿难/地震/空难/重大伤亡
- "politics": 政治敏感/政府官员/政策争议
- "privacy": 个人隐私/八卦/未公开信息
- "sensitive": 教育/民族/性别等争议话题
- "none": 无风险

【final angle_score = round(min(content_score, bridge_score, cta_score)) - risk_penalty】
- risk_flag=none: 取三维度最小值
- risk_flag=disaster: -2
- risk_flag=politics/privacy/sensitive: -1
最终范围 0-10

【suggested_bridge 规则】
- final angle_score >= 6：必给一句话桥接方向（例"旅行记忆 → 旅行内容创作者在用 AI 工具 → 壹目贯维"）
- final angle_score < 6：给 null

【event_date 规则】
- 根据你的知识和常识，判断标题中事件实际发生的时间，输出具体日期 YYYY-MM-DD
- 如果事件正在发生或即将发生：输出当天日期
- 如果事件已发生多日（如产品已上线、融资已完成）：输出过去日期
- 如果标题是旧闻翻炒（例如某产品已上线多日还在说"将发布"）：输出该事件真实发生时间，而非文章发布时间
- 完全无法判断时给 null（如节日、纯人名、天气等无明确时间线的事件）

【few-shot 正例】
- "MiniMax M3 100万token上下文与原生多模态" → content=10, bridge=10, cta=10, risk=none, final=10, bridge="AI 模型新品发布，5秒讲完，天然业务款", event_date="2026-05-22"
- "DeepSeek 75%折扣 + 700亿融资" → content=10, bridge=9, cta=9, final=9, bridge="DeepSeek 降价直接利好 AI 内容生产成本 → 壹目贯维", event_date="2026-05-23"
- "Alphabet 800亿融资 + Anthropic IPO" → content=10, bridge=8, cta=7, final=7, bridge="AI 行业资本动作，可解读为 AI 内容生产赛道持续热门", event_date="2026-06-05"
- "旅行买的是专属记忆" → content=5, bridge=6, cta=6, final=5, bridge=null, event_date=null

【few-shot 反例】
- "天涯神帖" → content=3, bridge=2, cta=2, final=2, bridge=null, event_date=null
- "儿童节" → content=1, bridge=4, cta=4, final=1, bridge=null, event_date=null
- "留神峪煤矿事故82人遇难" → content=8, bridge=0, cta=0, risk=disaster, final=0, bridge=null, event_date=null
- "CBA 季后赛 G1 上海胜北京" → content=7, bridge=2, cta=2, final=2, bridge=null, event_date=null
- "如何评价复旦教授沈奕斐硬刚小学生家长" → content=8, bridge=2, cta=2, risk=sensitive, final=1, bridge=null, event_date=null

待判断话题：$title
来源：$source | correlation=$corr
"""


def call_llm(title, source, corr, max_retry=3):
    """调 DeepSeek-v4-flash 角度判定。重试 3 次，慢启动防限流。"""
    # 用 string.Template 避免 JSON 内的 {} 与 .format() 冲突
    prompt = Template(PROMPT).safe_substitute(title=title, source=source, corr=corr)
    payload = json.dumps({
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.1,
        "max_tokens": 1500,
    }, ensure_ascii=False)
    cmd = [
        "curl", "-s", "--max-time", "120",
        "-X", "POST",
        "-H", "Content-Type: application/json",
        "-H", f"Authorization: Bearer {API_KEY}",
        "-d", payload,
        f"{BASE_URL}/chat/completions",
    ]
    for attempt in range(max_retry):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=130)
            if not r.stdout:
                if attempt < max_retry - 1:
                    time.sleep(5 * (attempt + 1))
                    continue
                return None, f"empty_stdout_after_{max_retry}_retries"
            try:
                data = json.loads(r.stdout)
            except json.JSONDecodeError:
                if attempt < max_retry - 1:
                    time.sleep(3)
                    continue
                return None, f"json_parse_fail:{r.stdout[:80]}"
            if "error" in data:
                if attempt < max_retry - 1:
                    time.sleep(5)
                    continue
                return None, f"api_error:{data['error']}"
            content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
            if not content:
                if attempt < max_retry - 1:
                    time.sleep(3)
                    continue
                return None, "empty_content"
            m = re.search(r'\{[\s\S]*\}', content)
            if not m:
                if attempt < max_retry - 1:
                    time.sleep(3)
                    continue
                return None, f"no_json:{content[:80]}"
            return json.loads(m.group()), None
        except subprocess.TimeoutExpired:
            if attempt < max_retry - 1:
                time.sleep(5)
                continue
            return None, "timeout"
        except Exception as e:
            return None, f"{type(e).__name__}"  # 关键：不 print str(e) 暴露 key
    return None, "exhausted"


def main():
    parser = argparse.ArgumentParser(description="judge_topics_angle.py — 角度分判定")
    parser.add_argument("--limit", type=int, default=100, help="最多处理 N 条")
    parser.add_argument("--dry-run", action="store_true", help="不写库，只 print")
    parser.add_argument("--source", default="微博,知乎,抖音,Tavily,AIHOT", help="优先级 source 列表（逗号分隔）")
    parser.add_argument("--min-corr", type=float, default=0, help="最低 corr 阈值")
    args = parser.parse_args()

    sources = [s.strip() for s in args.source.split(",")]

    if not Path(DB).exists():
        print(f"FATAL: {DB} not found", file=sys.stderr)
        sys.exit(2)

    con = sqlite3.connect(DB)

    # === SIGTERM handler: scheduler 超时杀进程时先 commit 再退出（2026-06-06 P0 防丢）===
    # 不加这个，300s timeout 杀进程时循环里已处理的 N 条全丢
    def _sigterm_handler(signum, frame):
        try:
            con.commit()
            print(f"\n[signal] SIGTERM received, committed before exit", file=sys.stderr, flush=True)
        except Exception as e:
            print(f"\n[signal] SIGTERM commit failed: {e}", file=sys.stderr, flush=True)
        sys.exit(0)
    signal.signal(signal.SIGTERM, _sigterm_handler)
    # SIGINT (Ctrl+C) 也走同一路径
    signal.signal(signal.SIGINT, _sigterm_handler)
    con.row_factory = sqlite3.Row
    cur = con.cursor()

    # 查 schema 是否有 3 列
    cur.execute("PRAGMA table_info(topics)")
    cols = {r[1] for r in cur.fetchall()}
    if not {"angle_score", "angle_reason", "angle_judged_at"}.issubset(cols):
        print("FATAL: pool.db 缺 angle_score/angle_reason/angle_judged_at 列（先跑 ALTER TABLE）", file=sys.stderr)
        sys.exit(2)

    # 取未判过 + approved + 高价值 source
    placeholders = ",".join("?" for _ in sources)
    cur.execute(f"""
        SELECT topic_id, title, source, correlation_score
        FROM topics
        WHERE angle_score IS NULL
          AND review_status = 'approved'
          AND source IN ({placeholders})
          AND correlation_score >= ?
        ORDER BY
          CASE source WHEN 'AIHOT' THEN 1 WHEN 'Tavily' THEN 2 ELSE 3 END,
          correlation_score DESC,
          created_at DESC
        LIMIT ?
    """, (*sources, args.min_corr, args.limit))
    pending = [dict(r) for r in cur.fetchall()]

    print("=" * 70)
    print(f"【judge_topics_angle.py】")
    print(f"  待处理: {len(pending)} 条")
    print(f"  优先级 source: {sources}")
    print(f"  min_corr: {args.min_corr}")
    print(f"  dry-run: {args.dry_run}")
    print("=" * 70)

    if not pending:
        print("✅ 没有待判定的 approved 话题")
        con.close()
        return

    if args.dry_run:
        for r in pending[:20]:
            print(f"  [DRY] [{r['source']:6s}] corr={r['correlation_score']:>4.1f} | {r['title'][:55]}")
        if len(pending) > 20:
            print(f"  ... 还有 {len(pending)-20} 条")
        con.close()
        return

    # 写回
    now_iso = datetime.now().isoformat(timespec="seconds")
    stats = {"ok": 0, "fail": 0, "fail_types": {}}
    start = time.time()

    # === Phase 1: 并行 API 调用（2026-06-10 新增，ThreadPoolExecutor 加速） ===
    api_results = []
    print(f"  [并行] 提交 {len(pending)} 条给 ThreadPoolExecutor(max_workers=5)...", flush=True)
    with ThreadPoolExecutor(max_workers=5) as executor:
        future_to_topic = {
            executor.submit(call_llm, r["title"], r["source"], r["correlation_score"]): r
            for r in pending
        }
        done_count = 0
        for future in as_completed(future_to_topic):
            r = future_to_topic[future]
            done_count += 1
            try:
                parsed, err = future.result(timeout=130)
                api_results.append((r, parsed, err))
            except Exception as e:
                api_results.append((r, None, f"{type(e).__name__}"))
            if done_count % 10 == 0 or done_count == len(pending):
                print(f"  [进度] API {done_count}/{len(pending)} 完成", flush=True)

    # === Phase 2: 单线程写库 ===
    print(f"  [写库] {len(api_results)} 条结果，开始写入 DB...", flush=True)
    for i, (r, parsed, err) in enumerate(api_results, 1):
        if parsed is None:
            stats["fail"] += 1
            stats["fail_types"][err] = stats["fail_types"].get(err, 0) + 1
            print(f"  [{i}/{len(pending)}] FAIL: {r['title'][:40]} | {err}")
        else:
            # === v2 解析：拆 3 维度 + risk_flag + suggested_bridge + event_date ===
            content = parsed.get("content_score")
            bridge = parsed.get("bridge_score")
            cta = parsed.get("cta_score")
            risk = parsed.get("risk_flag", "none")
            bridge_text = parsed.get("suggested_bridge")
            event_date = parsed.get("event_date")  # str or None
            reason = (parsed.get("reason") or "")[:500]

            # 容错：老 v1 格式（只回 angle_score）—— 降级用
            if content is None and "angle_score" in parsed:
                score = parsed.get("angle_score")
                cur.execute("""
                    UPDATE topics SET
                        angle_score = ?,
                        angle_reason = ?,
                        angle_judged_at = ?
                    WHERE topic_id = ?
                """, (score, reason, now_iso, r["topic_id"]))
                stats["ok"] += 1
                print(f"  [{i}/{len(pending)}] OK(v1-fallback) llm={score} | {r['title'][:50]}")
            elif content is not None and bridge is not None and cta is not None:
                # v2 格式：算 final = min(content, bridge, cta) - risk_penalty
                base = min(content, bridge, cta)
                penalty = {"disaster": 2, "politics": 1, "privacy": 1, "sensitive": 1, "none": 0}.get(risk, 0)
                final = max(0, round(base - penalty))
                # suggested_bridge 规则：final<6 给 null
                if final < 6:
                    bridge_text = None
                # 拼 reason：3 维度 + risk + bridge 方向 + event_date
                reason_full = f"[c={content},b={bridge},t={cta},risk={risk},final={final}] {reason}"
                if bridge_text:
                    reason_full += f" | bridge: {bridge_text[:200]}"
                if event_date:
                    reason_full += f" | event_date: {event_date}"
                cur.execute("""
                    UPDATE topics SET
                        angle_score = ?,
                        angle_reason = ?,
                        angle_judged_at = ?,
                        suggested_bridge = ?,
                        risk_flag = ?,
                        event_date = ?
                    WHERE topic_id = ?
                """, (final, reason_full, now_iso, bridge_text, risk, event_date, r["topic_id"]))
                stats["ok"] += 1
                event_date_str = f" ed={event_date}" if event_date else ""
                print(f"  [{i}/{len(pending)}] OK  c={content} b={bridge} t={cta} risk={risk} final={final}{event_date_str} | {r['title'][:40]}")
            else:
                stats["fail"] += 1
                stats["fail_types"]["malformed_json"] = stats["fail_types"].get("malformed_json", 0) + 1
                print(f"  [{i}/{len(pending)}] FAIL(malformed): {r['title'][:40]} | parsed keys: {list(parsed.keys())}")
        if i % 20 == 0 or i == len(api_results):
            con.commit()
            elapsed = time.time() - start
            print(f"  [进度] 写库 {i}/{len(api_results)} | {stats['ok']}ok/{stats['fail']}fail | {elapsed:.0f}s elapsed", flush=True)

    con.commit()
    con.close()

    elapsed = time.time() - start
    print()
    print("=" * 70)
    print(f"【完成】{stats['ok']} ok / {stats['fail']} fail | 耗时 {elapsed:.1f}s")
    if stats["fail_types"]:
        print(f"  失败类型: {stats['fail_types']}")
    print("=" * 70)
    # 2026-06-06 P0：cron 视角下，只要处理到数据就算成功。LLM 偶发 API fail 不应让
    # 8:30 推送 skip（depends_on 链会把 exit 1 当成 last_status != ok）
    # 数据落库靠 commit_in_loop（每 20 条 commit + SIGTERM handler）
    sys.exit(0 if stats["ok"] > 0 else 1)


if __name__ == "__main__":
    main()
