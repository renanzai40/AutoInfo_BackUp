#!/usr/bin/env python3
"""AutoMedia 项目初始化 — pool.db 同步脚本。

在项目创建时调用，将选中话题的 pool.db status 从 pending 改为 selected，
并把真实的 topic_id 写回 project_info.json。

从而从源头杜绝「已选的话题仍在池子里重新出现」。

用法:
  python3 pool_sync.py --project-dir /path/to/project --topic-title "话题标题"

匹配策略（优先级递减）:
  1. 标题去空格归一化精确匹配
  2. 标题子串匹配（池中标题包含项目标题关键词或反之）
  3. 关键词交集匹配（提取数字+中文词+英文词+中文2-gram，>=3字符关键词交集 >= 2）
  4. 找不到则跳过（manual 话题不在池中，属于正常情况）

类级别陷阱（2026-06-22 总结）：
  - 字段存在 ≠ SQL 在用（event_date 修过但 push SQL 没引用）
  - project 创建了 ≠ pool.db 标记了 selected（pool_sync.py 解决）
  - 一个标题入库了 ≠ 搜索能匹配到（3 级匹配策略兜底）
"""

import argparse
import json
import re
import sqlite3
import sys
from pathlib import Path

DB_PATH = Path("/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db")


def normalize(s: str) -> str:
    s = s.lower()
    s = re.sub(r'[\s\u3000\u2000-\u200f\u3000\u3001-\u303f\uff00-\uffef'
               r'.,。、，、;:!?！？()（）「」『』【】《》""""''·…—\-]', '', s)
    return s


def extract_kws(s: str) -> set:
    """提取关键词：数字-量词 + 中文词(>=2字) + 英文词(>=3字符) + 中文2-gram"""
    s = s.lower()
    kws = set()
    nums = re.findall(r'\d+[\u4e00-\u9fff]*|[\u4e00-\u9fff]*\d+', s)
    kws.update(nums)
    cjk = re.findall(r'[\u4e00-\u9fff]{2,}', s)
    stopwords = {'一个', '可以', '这个', '那个', '什么', '怎么', '如何',
                 '我们', '他们', '你们', '没有', '不是', '就是', '但是',
                 '还是', '因为', '所以', '如果', '虽然', '已经', '通过',
                 '进行', '以及', '之后', '之前', '其中', '由于', '为了',
                 '发布', '推出', '上线', '新增', '宣布', '推出', '最新',
                 '首次', '正式', '全面', '开始', '实现', '打造'}
    kws.update(t for t in cjk if t not in stopwords)
    all_cjk = ''.join(re.findall(r'[\u4e00-\u9fff]+', s))
    for i in range(len(all_cjk) - 1):
        kws.add(all_cjk[i:i+2])
    eng = re.findall(r'[a-zA-Z]{3,}', s)
    kws.update(eng)
    return kws


def match_in_pool(title: str) -> dict | None:
    if not DB_PATH.exists():
        print(f"[WARN] pool.db not found: {DB_PATH}", file=sys.stderr)
        return None
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    norm_title = normalize(title)
    kw_title = extract_kws(title)
    cur.execute("SELECT topic_id, title, status, review_status, angle_score "
                "FROM topics WHERE status = 'pending' ORDER BY created_at DESC")
    all_pending = cur.fetchall()
    conn.close()
    candidates = []
    for row in all_pending:
        db_norm = normalize(row["title"])
        # P1: 归一化精确匹配
        if db_norm == norm_title:
            candidates.append((1, row))
            continue
        # P2: 子串匹配
        if norm_title in db_norm or db_norm in norm_title:
            if min(len(norm_title), len(db_norm)) / max(len(norm_title), len(db_norm)) > 0.3:
                candidates.append((2, row))
                continue
        # P3: 关键词交集（排除2-gram）
        db_kw = extract_kws(row["title"])
        overlap = kw_title & db_kw
        meaningful = {w for w in overlap if len(w) >= 3}
        if len(meaningful) >= 2:
            candidates.append((3, row, overlap))
    if not candidates:
        return None
    def sort_key(item):
        return (item[0], -(item[1]["angle_score"] or 0))
    candidates.sort(key=sort_key)
    priority, best = candidates[0][0], candidates[0][1]
    return {"topic_id": best["topic_id"], "title": best["title"],
            "match_priority": priority, "angle_score": best["angle_score"],
            "review_status": best["review_status"]}


def update_pool_db(topic_id: str) -> bool:
    conn = sqlite3.connect(str(DB_PATH))
    cur = conn.cursor()
    cur.execute("UPDATE topics SET status='selected', updated_at=CURRENT_TIMESTAMP "
                "WHERE topic_id=? AND status='pending'", (topic_id,))
    affected = cur.rowcount
    conn.commit()
    conn.close()
    return affected > 0


def update_project_info(project_dir: Path, topic_id: str):
    for info_candidate in [
        project_dir / "00_project_info" / "project_info.json",
        project_dir / "00_project_info.json",
    ]:
        if info_candidate.exists() and info_candidate.stat().st_size > 2:
            try:
                info = json.loads(info_candidate.read_text(encoding="utf-8"))
                changed = False
                if info.get("topic_id") != topic_id:
                    info["topic_id"] = topic_id; changed = True
                if info.get("source") != "pool":
                    info["source"] = "pool"; changed = True
                if changed:
                    info_candidate.write_text(json.dumps(info, indent=2, ensure_ascii=False), encoding="utf-8")
                print(f"  ✅ project_info.json updated: topic_id={topic_id[:16]}... source=pool")
                return True
            except Exception as e:
                print(f"  ❌ update project_info.json failed: {e}", file=sys.stderr)
    return False


def main():
    parser = argparse.ArgumentParser(description="Sync pool.db on project init")
    parser.add_argument("--project-dir", required=True, help="Project root directory")
    parser.add_argument("--topic-title", required=True, help="Topic title")
    parser.add_argument("--dry-run", action="store_true", help="Check only, no writes")
    args = parser.parse_args()
    project_dir = Path(args.project_dir)
    title = args.topic_title
    if not project_dir.exists():
        print(f"[ERROR] Project dir not found: {project_dir}", file=sys.stderr)
        return 1
    print(f"🔍 pool_sync: searching for「{title[:60]}」")
    match = match_in_pool(title)
    if match:
        print(f"  ✅ Matched (P{match['match_priority']}): {match['title'][:60]}")
        print(f"     topic_id={match['topic_id']} angle={match['angle_score']} review={match['review_status']}")
        if not args.dry_run:
            if update_pool_db(match["topic_id"]):
                print(f"  ✅ pool.db: pending → selected")
            else:
                print(f"  ⚠️ pool.db unchanged (possibly already selected/archived)")
            update_project_info(project_dir, match["topic_id"])
        else:
            print(f"  🔸 Dry-run, no writes")
        return 0
    else:
        print(f"  ⚠️ No match in pool.db (manual topic, skipping)")
        if not args.dry_run:
            for info_candidate in [
                project_dir / "00_project_info" / "project_info.json",
                project_dir / "00_project_info.json",
            ]:
                if info_candidate.exists():
                    try:
                        info = json.loads(info_candidate.read_text(encoding="utf-8"))
                        if info.get("source") != "manual":
                            info["source"] = "manual"
                            info_candidate.write_text(json.dumps(info, indent=2, ensure_ascii=False), encoding="utf-8")
                            print(f"  ✅ source=manual annotated")
                    except Exception:
                        pass
                    break
        return 0


if __name__ == "__main__":
    sys.exit(main())
