#!/usr/bin/env python3
"""AutoMedia 项目初始化 — pool.db 同步脚本（skill 同步副本）。

在项目创建时调用，将选中话题的 pool.db status 从 pending 改为 selected，
并把真实的 topic_id 写回 project_info.json。

从而从源头杜绝「已选的话题仍在池子里重新出现」。

主副本：~/.hermes/profiles/content/scripts/pool_sync.py（2026-06-26 更新：--project-dir 可选）

用法:
  # 只更新 pool.db（不需要 project-dir）
  python3 pool_sync.py --topic-title "话题标题"

  # 完整模式（更新 pool.db + 写 project_info.json）
  python3 pool_sync.py --project-dir /path/to/project --topic-title "话题标题"
"""
import sys
sys.path.insert(0, "/home/renanzai/.hermes/profiles/content/scripts")
from pool_sync import main
sys.exit(main())
