#!/usr/bin/env python3
"""
AutoMedia 项目初始化 — 新建项目的唯一标准入口。

每次开始一个新话题生产时，必须通过此脚本初始化项目目录。
禁止手动 mkdir + 直接 R0 跳过此步骤。

用法:
  python3 init_project.py --topic-title "xxx" --topic-slug "xxx" --category "引流款"

详见 ~/.hermes/profiles/content/scripts/init_project.py（主副本，本文件为同步副本）
"""
import sys
sys.path.insert(0, "/home/renanzai/.hermes/profiles/content/scripts")
from init_project import main
sys.exit(main())
