#!/usr/bin/env python3
"""
G0.5 Production Init Check — 生产前初始化预检 + 自动修复。
同步副本，主副本在 ~/.hermes/profiles/content/scripts/check_production_init.py
"""
import sys
sys.path.insert(0, "/home/renanzai/.hermes/profiles/content/scripts")
from check_production_init import main
sys.exit(main())
