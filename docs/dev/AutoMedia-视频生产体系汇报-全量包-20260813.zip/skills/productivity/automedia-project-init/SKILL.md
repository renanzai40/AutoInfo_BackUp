---
name: automedia-project-init
description: "AutoMedia 项目初始化——新建项目的唯一标准入口。先运行此 skill 或直接调用 init_project.py。**V1.1(2026-06-26)**：新增 init_project.py（统一入口）+ check_production_init.py（G0.5 预检+自动修复）。新增踩坑：跳过 init 直接 R0 导致 pool.db 未同步、话题重复推送。#content 触发：新建项目/选题确认后必加载；不用于已初始化项目的日常编辑。"
version: 1.1
author: Hermes Agent for renan
license: MIT
tags: [automedia, project-structure, folder-template, init]
---
## 什么时候用

> **强制触发：每次创建新的内容生产项目，或接手历史项目继续工作时。**
> 不论话题大小、不论是引流款还是业务款，只要涉及内容生产，就必须先运行此 hook。

## 🆕 Audit-First 方法论（2026-06-06 固化）

> **触发场景**：任何时候 user 问"X 时间点/位置/格式..."（workflow clarification）时。
>
> **user 原话 2026-06-06**：
> "确保你的提案符合现有的工作流并对现有工作流不合理的地方
> （专指文件夹结构和过程/结果文件的存放位置等）给出了合理的改进措施"
>
> **强制执行 5 步**：
> 1. **Audit 现有规范** — `skill_view` 相关 skill（automedia-project-init / video-production/hyperframes-workflow /
>    publish-log-schema / video-production/hyperframes-workflow / delivery-packaging / automedia-production-guard）+
>    `search_files` 关键词
> 2. **Audit 实际项目** — `ls` 最近项目目录 + 对比文档 vs 实际文件落点
> 3. **列出现有规则 + 实际工作流 + 矛盾点** — 证据化（贴文件名 + 行号）
> 4. **基于真实证据给方案** — 提案只针对"现有规则不合理"或"实际工作流未明文"
> 5. **明确推荐** — 不列 A/B/C 让选，除非不可逆
>
> **反面教材**（本 skill 之前的事故）：
> 第一轮我凭印象给 3 条建议（"3 硬门控"/"音频 pre-render 即落"/"Composition.tsx 项目目录备份"），
> user 要求 "review" 后自审发现 1 条过度工程 + 1 条冗余 + 1 条事实错误。详细 6 处真实不一致 +
> 修复 ROI 排序见 `references/known-inconsistencies-2026-06-06.md`。
>
> **不擅自动现有标准**——6 处修复待 user 拍板，本文件只记录证据。

## ⛔ 5 平台硬标准（不变量，2026-06-01 用户重申）

**每个 topic 必须做满 5 个平台：抖音 + B站（共用 1 个视频）+ 微信公众号 + 知乎 + 小红书。**

| 平台 | 字数 | 文件路径 |
|------|------|---------|
| 抖音 | 40s 视频脚本（~150-200 字口播，13 Entry）| `01_content/drafts/tiktok/script.txt` |
| B站 | 同上（与抖音共用 1 个视频，文件副本）| `01_content/drafts/bilibili/script.txt` |
| 微信公众号 | ~2000 字 | `01_content/drafts/wechat/wechat_draft.html` |
| 知乎 | ~2000 字 | `01_content/drafts/zhihu/zhihu_article.md` |
| 小红书 | ~500 字 | `01_content/drafts/xiaohongshu/xiaohongshu_post.md` |

**绝对标准 = 5 平台全部要做。** 不存在"业务款 = 4 平台"的特例。

**抖音 + B站共用 1 个视频**：写 1 份视频脚本，写到 `tiktok/script.txt`，**复制副本到 `bilibili/script.txt`**（同一内容、2 个文件）。不是 2 个独立视频。

## ⚠️ 6-05 chaos 教训固化（5 平台 + 视频必并行）

> **触发场景**：新建 AutoMedia 项目时（无论引流款/业务款）。
> **核心铁律**（2026-06-05 user 拍板）：**视频生产与 5 平台文案必并行启动，禁止"先修完视频再做文案"**。

## 标准项目目录结构

```
YYYYMMDD_HHMMSS_topic-slug/        ← 项目根目录（以当前时间戳命名）
├── 00_research/
│   └── research_notes.md           ← 调研笔记、数据来源、引用链接
├── 00_project_info/
│   └── project_info.json           ← 项目元数据（必须）
├── 01_content/
│   └── drafts/                     ← 各平台草稿文案
│       ├── wechat/
│       │   └── wechat_draft.html  ← 微信公众号 HTML
│       ├── zhihu/
│       ├── xiaohongshu/
│       ├── tiktok/
│       └── bilibili/
├── 02_images/
│   ├── assets/                    ← 视频帧图（Fallback 序列）、内文配图、中间素材图
│   └── cover/
│       ├── cover_16x9.png         ← 知乎/B站
│       ├── cover_3x4.png          ← 小红书竖版
│       ├── cover_1x1.png          ← 小红书正方
│       └── cover_9x16.png         ← 抖音
├── 03_subtitle/                    ← SRT 字幕（automedia 产出，6-05 模式固化）
│   └── subtitle.srt
├── 03_video/
│   ├── script_final.txt            ← 最终确认口播脚本
│   ├── video_final.mp4            ← 含字幕最终版视频（1080×1920）
│   └── audio_voiceover.mp3        ← TTS 配音音频（Whisper 读 + 打包用）
├── 04_review/
│   └── review_log.json            ← 审核记录
└── 05_publish/
    └── publish_log.json           ← 发布日志（每次发布后更新）
```

## 内文配图规范

> **`02_images/assets/` 用于存放：视频帧图（Fallback 序列）+ 内文配图 + 中间素材图。**
> 内文配图是各平台文章正文中使用的插图，与视频帧图不同，需按平台最低要求配图。

**推荐生成方式**：`python3 scripts/gen_inline_images.py <project_dir>`（来自 `automedia-production-guard` skill）— 自动从 research_notes 提取关键数据，按 4 种模板生成品牌统一配图。

| 平台 | 最低配图数 | 说明 |
|------|-----------|------|
| 微信公众号 | ≥3 | 正文中均匀分布，增强可读性 |
| 知乎 | ≥2 | 文章配图，辅助说明关键论点 |
| 小红书 | ≥1 | 封面图已单独在 `02_images/cover/`，此处指正文配图 |
| 抖音/B站 | 0 | 视频内容无需正文配图 |

**图片命名规范**：`<platform>_<序号>_<描述>.png`，如 `wechat_01_流程图.png`。

> ⚠️ **内文配图生成时机**：各平台文案定稿后、发布前，通过 Gate II 检查前生成。内容与对应段落相关，避免通用素材图。

## 项目命名规范

- 格式：`YYYYMMDD_HHMMSS_<话题核心词>-<topic-slug>`
- 示例：`20260515_ai_industry_daily`、`20260515_baidu_yijing`
- **强制：一个项目只对应一个话题。禁止在一个项目文件夹内存放多个独立话题的子目录。** 多话题内容必须拆分成独立项目。

## 项目去重检查（强制 Step 0，每次必须执行）

> **触发：创建新项目之前，必须先检查 `projects/` 下最近3天内是否有重复话题。**

**操作步骤：**
1. `ls -lt /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/ | head -20` 列出最近项目
2. 读取最近项目的 `00_project_info/project_info.json`，对比话题关键词
3. 判断是否重复：
   - **同一事件/话题**（如两个"普京访华"）→ 取消新项目，复用已有项目
   - **同类话题不同角度**（如"AI模型使用" vs "AI语音合成"）→ 保留新项目，查重角度差异
4. 重复时：将新项目目录重命名为 `_CANCELLED_` 后缀，不删除（保留记录）

**典型案例（2026-05-21 实录）：**
- 新项目 `20260521_1430_puyin-beijing`（普京专机落地北京，美西方集体沉默）
- 已有项目 `20260520_133057_putin-visit-china`（普京来中国了，第25次）
- 结论：同一事件，角度略有差异但不足以单独成篇 → 取消新项目

**Gotcha：** 不跳步。去重检查是 Hard Gate，未完成不得进入 Step 1 创建项目目录。

---

## Hook 工作流

## pool.db status CHECK 约束（必须遵守）

`topics.status` 字段有 DB 层 CHECK 约束，只接受以下值：

```
pending | selected | writing | published | archived
```

**`'producing'` 不是合法值。** 尝试写入会 `CHECK constraint failed` 且静默失败（Python 不抛异常，SQLite 返回 exit_code 0 但数据未改）。

正确映射：
| 项目阶段 | 写入 status |
|---------|------------|
| 刚建立项目 | `selected` |
| 开始写内容 | `writing` |
| 所有平台发布完成 | `published` |
| 归档完成 | `archived` |

## 项目状态检查（强制，每次接手或汇报前执行）

> **触发：用户问"XX项目状态如何"/"昨天启动的项目"时，或接手历史项目时。**

**标准检查流程（不得跳过）：**

1. **扫描 `projects/` 目录**，用 `ls -lt` 按时间排序，找最近项目
2. **识别 typo-variant 同名目录**：如果项目名包含常见拼写错误模式（如 `-litiation` vs `-litigation`、`wentech` vs `wentech`），必须同时检查所有变体
   - 典型模式：一个目录内容完整（correct），另一个是空壳或部分内容
   - 处理：**废弃拼写错误的目录，将内容合并到正确目录**
3. **读取每个活跃项目的 `00_project_info/project_info.json`**，确认：`status` / `topic_id` / `source`
4. **判断真实状态**：项目可能在 `project_info.json` 里显示 `initialized`，但实际已通过全部审核——判断方法：检查 `04_review/` 下是否有各平台的 `copy_review_*.md`
   - 有全部5个平台审核文件 → 内容生产完成，差发布
   - 只有1-2个 → 部分完成，需要继续
   - 一个都没有 → 项目确实未启动

**检查清单（每项目逐项）：**
| 检查项 | 路径 | 缺失时 |
|--------|------|--------|
| 小红书文案 | 01_content/drafts/xiaohongshu/xiaohongshu_post.md | ⚠️ 部分缺失 |
| 知乎文案 | 01_content/drafts/zhihu/zhihu_article.md | ⚠️ 部分缺失 |
| 微信公众号 | 01_content/drafts/wechat/wechat_draft.html | ⚠️ 部分缺失 |
| 抖音/B站脚本 | 01_content/drafts/tiktok/script.txt, bilibili/script.txt | ⚠️ 部分缺失 |
| 视频文件 | 03_video/video_final.mp4 | ⚠️ 未生成 |
| 审核记录 | 04_review/copy_review_*.md（5个平台） | ⚠️ 未走审核 |
| 发布日志 | 05_publish/publish_log.json | ❌ 未发布 |

**典型停滞模式（2026-05-26 实录）：**
- `618-ai-tools-recommendation`：5平台文案✅ + 视频✅ + 审核✅，但 `05_publish/` 为空
  → 内容完成，未执行发布 → 需要补充发布
- `wentech-ansys-litiation` vs `wentech-ansys-litigation`：
  litiation = 空壳（只有小红书1条）；**litigation = 完整**（5平台+视频+审核）
  → 处理：废弃 litiation，将 litigation 目录作为正式项目继续

**典型停滞模式（2026-05-26 实录）：**
- `618-ai-tools-recommendation`：5平台文案✅ + 视频✅ + 审核✅，但 `05_publish/` 为空
  → 内容完成，未执行发布 → 需要补充发布步骤
- `wentech-ansys-litiation` vs `wentech-ansys-litigation`：
  litiation = 空壳（只有小红书1条）；**litigation = 完整**（5平台+视频+审核）
  → 处理：废弃 litiation，将 litigation 目录作为正式项目继续

**发现 typo-variant 目录时（立即执行，不询问）：**
```bash
# 判断哪个目录内容完整，哪个是空壳
# 保留内容完整的正确拼写版本，将错误拼写版本标记为 _TYPO废弃_
mv .../20260525_085515_wentech-ansys-litiation \
   7. **项目时间戳用当前时间**：不是话题发生时间，是"建立项目"的时间
- `references/brand-cta-compliance-checklist.md` — 品牌CTA合规审查清单（5平台逐项+典型失败案例）
- `references/historical-project-patterns.md` — 历史项目非标准结构识别与修复模式
- `references/subagent-file-naming-20260517.md` — subagent 文件命名 bug
- `references/ffmpeg-subtitles-2026-05-19.md` — 字幕烧录：ASS格式/burn_subtitles.py陷阱/FFmpeg ASS正确流程
- `references/dedup-check-20260521.md` — 项目去重检查：普京访华重复项目取消实录
- `references/topic-dedup-cluster-20260522.md` — 话题池预防性去重：9大cluster硬编码规则 + cron集成
- `references/master-file-pattern-20260522.md` — Master-file bundling 模式：多平台内容混存在单个 `_content.md` 的识别与审查方法
- `references/project-discovery-20260522.md` — 项目定位模式：dual-topics 子目录查找、draft 文件命名规律、inline 多阶段审稿记录识别
- `references/project-status-vs-reality-2026-05-26.md` — status 字段不等于真实进度；wentech/litigation typo-variant 实录；DeepSeek/Lorai 视频找不到项目文件夹根因
- `references/project-status-5states-2026-06-02.md` — **（2026-06-02 新增）** 完整 5 状态 + 9 INV 设计 + WeChat 3 重触发器 + archive 双触发器规则
- `references/known-inconsistencies-2026-06-06.md` — **🆕（2026-06-06 新增）** 6 处真实不一致审计（`03_subtitle` 路径 / `video_raw.mp4` / Remotion 仓库结构 / 音频双份 / cp 时机 / out 清理）+ 修复 ROI 排序 + Audit-First 方法论 5 步

## Gotchas

1. **不要在 `/tmp/` 存项目文件**：`/tmp/` 会随 session 清理，所有产出必须放在 `projects/` 下
2. **每次内容产出后立即归档**：视频、文案、封面图生成后，立即复制到对应项目目录，不要留在 `/tmp/`
3. **视频帧图（Fallback 序列）**：生成后立即复制到 `02_images/assets/`，这是视频的原材料，必须留存。**内文配图**也存放于此目录，按平台分类命名，详见「内文配图规范」。
4. **图片生成建议在项目目录内执行**：先生成到 `/tmp/` 验证通过后，立刻复制到项目的 `02_images/assets/` 或 `02_images/cover/`，不要在 `/tmp/` 留存
5. **视频文件命名**：`video_final.mp4` = 含字幕最终版（无 `video_raw.mp4` —— Remotion 6-06 起内嵌字幕，不需要 raw 版）
6. **HyperFrames 路径也必须走此 Hook**：即使话题被确认后直接走 HyperFrames 视频生产，也必须先运行项目初始化（init_project.py），否则话题不会从推送池中剔除。
7. **项目时间戳用当前时间**：不是话题发生时间，是"建立项目"的时间
8. **project_info.json 中文引号 JSON 逃逸陷阱**（2026-06-13 新增）：当用 write_file 直接写 project_info.json 时，如果 topic/angle/bridge 等字段包含未转义的双引号 "（如中文引号习惯），JSON 解析器会提前终止字符串。症状：lint 报 "Expecting ',' delimiter"。
   ❌ 错误：`"angle": "豆包一句"放心退"让用户..."`（未转义双引号被当作 JSON 字符串结束）
   ✅ 正确：`"angle": "豆包一句「放心退」让用户..."`（中文书名号替代）
   ✅ 或：`"angle": "豆包一句\"放心退\"让用户..."`（标准 JSON 转义）
   ✅ Python json.dump() 自动处理转义，本陷阱仅发生在手写 JSON 内容时。
   > **注意**：init_project.py 使用 json.dump() 写入，不会触发此陷阱。
9. **TTS 音频双副本规则**（6-06 实战固化）...
10. **2026-06-26 事故：跳过初始化 = 话题重复推送** —— 关键踩坑：选题后直接 `mkdir` 建目录 + 开始 R0 调研，跳过了 `automedia-project-init` 和 `pool_sync.py`。后果：pool.db 中的 topic 始终 `status='pending'`，次日 08:30 推送再次命中。这是**第三次**发生同类事故（2026-05-27、2026-06-15 有过类似 root cause）。G0.5 的检查 B + `check_production_init.py` 已加入自动修复，但根治方法是所有新项目走 `init_project.py` 入门。
   TTS API 调完 → 立即 cp 到 **2 个位置**：
   1. `/home/renanzai/Remotion-Test/public/audio/<topic>.mp3`
      （Remotion 渲染时 NSegmentSkeleton L169 内部 `staticFile(audioSrc)` 读这个）
   2. `{project_dir}/03_video/audio_voiceover.mp3`
      （Whisper 转写读 + delivery-packaging 打包用）

   Composition.tsx audioSrc 字段 = 字符串字面量 `"audio/<topic>.mp3"`
   （不调 staticFile——HyperFrames 无需此设置，详见视频生产：`skill_view video-production/hyperframes-workflow` 的素材组织部分）

   漏 cp 任一份 = 渲染失败（找不到音频）或 Whisper 验证失败
9. **cp 时机分级表**（6-06 实战固化）：

   | 素材 | 时机 | 落点 |
   |---|---|---|
   | TTS mp3 | pre-render（TTS API 调完）| Remotion 仓库 `public/audio/` + 项目目录 `03_video/audio_voiceover.mp3` |
   | Whisper SRT | pre-render（Whisper 转写完）| `03_subtitle/subtitle.srt` + `whisper_result.json` |
   | LLM 校正 SRT | pre-render（LLM 校正完）| `03_subtitle/subtitle_corrected.srt` |
   | Composition.tsx | 写完立即 | Remotion 仓库 `src/<Topic>Composition.tsx`（git 控，**不在项目目录备份**）|
   | Remotion 渲染 mp4 | 渲染成功 | Remotion 仓库 `out/<topic>.mp4`（Remotion 默认）|
   | **最终视频 cp** | **post-render 3 门控全过** | `03_video/video_final.mp4` |

   **3 门控**（必须全过才 cp `03_video/video_final.mp4`）：
   1. Remotion 渲染 exit 0
   2. 帧图 Vision QA 全 PASS（V8：cover + 段间字幕实际渲染）
   3. Whisper 验证 mp3 朗读 = SRT 文本（V5：防 session 113223 错配）

## 项目状态注册表（PROJECT_REGISTRY.md，自动生成）

> **触发**：项目数量超过 20 个后，手动 `ls projects/` + 抽查 publish_log.json 已不可持续。
> 解决方案：自动生成的 `PROJECT_REGISTRY.md` 给人读，配套 `PROJECT_REGISTRY.json` 给机器读。
> 2026-06-02 用户提议"维护一个列表来记录各个 automedia子项目的状态" → 本节落地。

**生成器**：`Scripts/regen_project_registry.py`（~250 行 Python，2026-06-02 创建）

**位置**：
- **读**：`<root>/PROJECT_REGISTRY.md`（人读）
- **读**：`<root>/PROJECT_REGISTRY.json`（机器读）
- **生成**：`<root>/Scripts/regen_project_registry.py`

**双数据源**（自动读 + 容错）：
1. `projects/<id>/00_project_info.json`（单文件，24 个 active 用）
2. `projects/<id>/00_project_info/project_info.json`（目录+文件，m3/hy 用）
3. `projects/<id>/05_publish/publish_log.json`（schema v2，jsonschema 可验证）

**字段名兼容**：
- `type` 字段（active 用）+ `category` 字段（m3/hy 用）→ 模板里 `type_cell()` 自动 fallback
- `00_project_info.json` + `00_project_info/project_info.json` 两种目录结构都支持

**输出表格列**：

| ID | Topic | Type | Status | Current | Updated | Known Issues |
|---|---|---|---|---|---|---|
| 项目目录 | topic 前 40 字 | 引流款/业务款 | 📝/✅/🗂 emoji | content_id 或 03_video/ | 日期 | ⚠️/✅ issues |

**三段视图**：
1. **Active Projects**（`projects/` 顶层，24 个）
2. **Archived Projects**（`projects/archive/`，4 个）
3. **Orphaned Media**（`projects/archive/_orphans/`，6 mp4）

**触发方式**（3 选 1）：
- **手动**：`python3 Scripts/regen_project_registry.py`（最简）
- **hook**：upload_draft.py 写完 publish_log 后自动调
- **cron**：每日 08:00 兜底

**典型用法**：

```bash
# 1. 启动新会话时一眼看所有项目状态
cat PROJECT_REGISTRY.md

# 2. 找有 known_issues 的项目
jq '.active + .archived | map(select(.publish_log.known_issues | length > 0))' PROJECT_REGISTRY.json

# 3. 找所有 draft_uploaded 状态但未推进的（待发布的僵尸项目）
jq '.active | map(select(.publish_log.status == "draft_uploaded"))' PROJECT_REGISTRY.json
```

**设计要点**：

- **绝不手维护**——手维护 = 第三个 source of truth，与 00_project_info.json + publish_log.json 漂移
- **schema v2 优先**（D 任务固化）—— publish_log 字段稳定后，registry 解析零成本
- **空文件跳过**（m3 早期空 00_project_info.json 不报错）
- **行级 mtime 不追踪**——只追踪"数据源 JSON 的 updated_at 字段"

**踩坑教训**（2026-06-02 创建时发现）：

| 坑 | 修复 |
|---|---|
| m3/hy 用 `00_project_info/project_info.json` 目录，active 用 `00_project_info.json` 文件 | 脚本支持两种结构 |
| m3/hy 用 `category` 字段，active 用 `type` 字段 | `type_cell()` fallback |
| m3 早期 `00_project_info.json` 是 0 字节空文件 | `info_file.stat().st_size > 2` 跳过 |
| 早期项目没 `publish_log.json` | status 列自动显示 "🗂 delivered (no log)" |

**反模式**（避免）：

- ❌ 把 registry 当 source of truth 写数据 → 数据还是回写 00_project_info.json + publish_log.json
- ❌ 每天 cron 跑但不用其结果 → 浪费计算，建议只在生命周期节点跑
- ❌ 表格列继续加（如加"负责人/截止日期"）→ 字段膨胀，找支持类数据用单独文件

**与 INDEX.md 的分工**：

| 文档 | 角色 | 谁维护 |
|------|------|-------|
| `INDEX.md` | 这是什么项目 / 怎么跑（SOP/规范/架构） | 人维护，2026-05-11 v1.0 |
| `PROJECT_REGISTRY.md` | 现在项目状态如何（动态注册表） | 自动生成，2026-06-02 起 |


---

## 章节导航（JiT Loading）

> 主文件保留核心流程。以下章节已移至 references/，按需加载：

| 章节 | Reference | 行数 |
|------|-----------|------|
| 项目归档流程（2026-06-02 用户纠错后固化，INV-8/9） | `references/project-archive-flow.md` | 176 |
| 相关参考 | `references/related-references.md` | 92 |
| 第五步（历史文档，备用）：确认 pool.db 同步更新 | `references/hook-step5-pool-sync.md` | 35 |
| 第一步：检查或创建项目根目录（2026-06-26 更新） | `references/hook-step1-check-root.md` | 32 |
| 🔑 手动项目 topic_id 反查规则（2026-06-11 新增） | `references/manual-topic-id-reverse-lookup.md` | 32 |
| 正确 5+1 步工作流（项目启动 Step 0-1） | `references/workflow-5-plus-1-steps.md` | 31 |
| 双话题项目（dual-topics）结构（2026-06-01 固化） | `references/dual-topics-structure.md` | 30 |
| ⚡ 标准化操作：创建项目后即调用 init_project.py（2026-06-26 更新） | `references/hook-step-standard-init.md` | 25 |
| 验证（5 平台未就绪禁止发飞书） | `references/verify-5platform-ready.md` | 19 |
| ⚠️ 踩坑教训（2026-06-01 实录） | `references/pitfall-5platform-2026-06-01.md` | 16 |
| 第二步：写入项目信息 + 关联 topic_id | `references/hook-step2-project-info.md` | 11 |
| 错误反模式（2026-06-05 真实事故） | `references/antipattern-6-05-chaos.md` | 9 |
| 相关参考 | `references/related-references-2.md` | 1 |
