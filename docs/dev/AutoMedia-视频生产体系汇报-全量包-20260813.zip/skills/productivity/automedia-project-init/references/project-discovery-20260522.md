# 项目定位与文件发现模式（2026-05-22 实录）

> 接手历史项目时，如何快速找到文案文件。记录本次发现的非标准路径模式。

---

## 典型发现路径

### 1. 标准项目（独立目录）

独立项目直接在 `projects/` 下：

```
projects/
└── 20260520_133057_ai-voice-synthesis/   ← 直接可找
    └── 01_content/drafts/
        ├── wechat/wechat_draft.html
        ├── zhihu/zhihu_article.md
        └── xiaohongshu/xiaohongshu_post.md
```

**快速定位命令**：
```bash
ls -lt /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/ | head -20
```

---

### 2. 双话题项目的子目录（需额外搜索）

部分项目是"双话题合并"结构，子话题放在父目录名下：

```
projects/
└── 20260519_092124_dual-topics/           ← 父目录（双话题）
    ├── doubao-yuyue-canlou/               ← 子话题A
    │   └── 01_content/drafts/
    │       ├── wechat/wechat_draft.html
    │       ├── zhihu/zhihu_article.md
    │       └── xiaohongshu/xiaohongshu_post.md
    └── doubao-shoufei-llm/                ← 子话题B（同一父目录）
```

**搜索子目录**：
```bash
# 找所有子话题目录（不限层级）
find /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects -maxdepth 3 -type d -name "*doubao*" -o -type d -name "*ai-voice*"
```

**经验**：双话题父目录名称含 `dual-topics`，子目录才是实际项目单位。review 时按子目录找内容。

---

### 3. Draft 文件常见命名

| 平台 | 典型文件名 |
|------|-----------|
| 公众号 | `wechat_draft.html`（HTML格式）或 `wechat.md` |
| 知乎 | `zhihu_article.md` 或 `zhihu.md` |
| 小红书 | `xiaohongshu_post.md` 或 `xiaohongshu.md` |
| 抖音 | `tiktok_script_final.md` / `tiktok_script_raw.md` |

**搜索命令**：
```bash
find /path/to/project -name "wechat*" -o -name "zhihu*" -o -name "xiaohongshu*" -o -name "tiktok*"
```

---

### 4. 多阶段审稿记录（Inline Multi-Stage Pattern）

**症状**：小红书文案文件中包含多个阶段版本，混在同一文件里：

```
【Stage 1 - Humanizer Pass】
[初稿...]

---

【Stage 2 - Copy Review Pass】
[审稿后版本...]

---

【Stage 3 - Brand CTA Review Pass - FINAL】
[最终版...]
```

**处理原则**：
- **只 review 最终版（Stage 3 / FINAL）**，之前的版本是中间过程
- Stage 2/3 常含 `Copy Review 修改点` / `Brand-CTA Review 修改点` 备注，这些是**元数据**，不进入发布内容
- 最终版前面的版本行可能含草稿批注（如 `[ ]` checkbox），忽略即可

**典型文件**：`xiaohongshu_post.md` 经常含此模式；`wechat_draft.html` 通常只有一版。

---

## 快速定位工作流（接手项目时执行）

```bash
# Step 1：列出 projects/ 下所有项目
ls -lt /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/ | head -30

# Step 2：搜索关键字（怕项目藏在 dual-topics 子目录里时用）
find /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects -maxdepth 3 -type d -name "*关键词*"

# Step 3：进入项目后，找到所有平台文案
find /path/to/project/01_content -type f \( -name "*.md" -o -name "*.html" \) | sort

# Step 4：确认是否有 inline 多阶段版本（找 Stage/阶段关键字）
grep -l "Stage\|FINAL\|Humanizer\|Copy Review" /path/to/project/01_content/drafts/**/*.md 2>/dev/null
```

---

## 经验总结

| 问题 | 解决方案 |
|------|---------|
| 项目藏在 dual-topics 子目录里 | 用 `find -name "*关键词*"` + 确认父目录含 `dual-topics` |
| Draft 文件在子目录但名字不熟悉 | Step 3 命令一次性列出所有文案文件 |
| 小红书文件含多个版本不知道看哪个 | 只读 FINAL / Stage 3 版本，其余是中间稿 |
| 多平台内容混在一个 `_content.md` 里 | 参考 `master-file-pattern.md` 的识别方法 |
