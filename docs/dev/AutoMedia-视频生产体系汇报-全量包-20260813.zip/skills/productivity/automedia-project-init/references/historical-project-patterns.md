# 历史项目结构识别与修复模式（2026-05-18 实录）

> 本次 session 从用户 zip 包解压出 5 个历史项目（20260508 + topic001/002/003），发现典型结构问题和修复方法。

## 典型结构问题

### 1. 文件名编码损坏（GBK→CP437）

**症状**：解压后目录名含乱码字符，如 `╣·▓·AI╨┬═╗╞╞`、`╓¬║⌡`、`╢╢╥⌠`

**根因**：Windows 压缩包内文件名为 GBK 编码，WSL 解压时用 CP437 解释

**解码方法**：
```python
def decode_name(name):
    return name.encode('cp437').decode('gbk')
# 例：'╣·▓·AI╨┬═╗╞╞' → '国产AI新突破'
```

**快速诊断**：
```bash
ls /path/to/extracted/ | python3 -c "
import sys
for line in sys.stdin:
    name = line.rstrip('\n')
    try:
        decoded = name.encode('cp437').decode('gbk')
        print(f'{decoded} <- {name}')
    except:
        print(f'? <- {name}')
"
```

### 2. 嵌套 zip 包（双重压缩）

**症状**：顶层目录里还有 `.zip` 文件，如 `20260508/20260508_1755_家居AI助手.zip`

**处理**：必须递归解压每一层，才能访问完整内容

### 3. 脚本命名不一致

**历史项目典型命名**：
- `script.txt`（topic001/002/003）
- `口播文案.txt`（topic001/002）
- `20260508_1755_╣·▓·AI╨┬═╗╞╞_╜┼▒╛.md`（P1/P2）
- `script_raw.md`（subagent 输出）

**修复**：统一为 `03_video/script_final.txt`（主 agent 手动提取口播行）

### 4. 口播行提取逻辑

```python
def extract_spoken_text(md_path):
    """从脚本文件提取口播文本（纯对话行）"""
    content = open(md_path, encoding='utf-8').read()
    lines = content.split('\n')
    spoken = []
    for line in lines:
        stripped = line.strip()
        # 匹配引号包裹的对话行
        if stripped.startswith('"') and stripped.endswith('"'):
            spoken.append(stripped[1:-1])
        elif stripped.startswith('「') and stripped.endswith('」'):
            spoken.append(stripped[1:-1])
    return '\n'.join(spoken)
```

### 5. 内容审查清单（历史项目重做标准）

| 项目 | 问题 | 修复方式 |
|------|------|---------|
| 知乎 | 原文字数不足 ~2000 | MiniMax 扩展 |
| 公众号 | 原文字数不足 ~2000 | MiniMax 扩展 |
| 小红书 | ✅ 基本达标（>500字） | 保留 |
| 抖音脚本 | ❌ 尺寸/时长不合规或完全缺失 | 全新制作 |
| 视频 | ❌ 尺寸错误（768x1024）或超长（108s） | 路径B重建 |

### 6. 视频重建参数（路径B Fallback）

**历史项目常见问题**：
- 尺寸：768x1024（错误）→ 需 1080x1920
- 时长：5.9s/29.9s/108s（不合规）→ 需 35-65s
- 无视频：完全缺失

**标准参数**：
- TTS：speech-2.8-hd，Chinese (Mandarin)_Radio_Host，speed=1.0
- 帧数：5帧（均分音频时长）
- 烧录：FontSize=55，MarginV=120，Fontname=WenQuanYi Zen Hei

### 7. subagent 超时后的验证流程

当 subagent 超时（600s）时，可能只完成了部分任务：

**必须检查**：
1. `03_video/` 有 `.mp4` 文件吗？无则视频未开始
2. `script_final.txt` 存在吗？无则只有 `script_raw.md`
3. 文章文件字节数是否达标？

**原则**：视频生产不得进 subagent（超时高风险），全部在主 agent 执行

## 快速检查命令

```bash
# 检查项目完整性
for dir in /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/*/; do
    name=$(basename "$dir")
    has_video=$(find "$dir/03_video" -name "*.mp4" 2>/dev/null | wc -l)
    has_script=$(find "$dir/03_video" -name "script_final.txt" 2>/dev/null | wc -l)
    echo "$name: video=$has_video script=$has_script"
done

# 统计各平台文案字符数
for f in /path/to/project/01_content/drafts/**/*.md; do
    name=$(basename "$f")
    chars=$(python3 -c "import re; t=open('$f').read(); print(len(re.findall(r'[\u4e00-\u9fff]', t))+len(re.findall(r'[a-zA-Z]+', t)))")
    echo "$name: $chars chars"
done
```