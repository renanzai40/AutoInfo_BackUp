# Subagent 文件命名 bug — 2026-05-17 复盘

## 问题现象

subagent 完成文案扩展任务后，口播脚本写到 `script_raw.md`（输入文件）而非 `script_final.txt`（输出文件）。

## 根因分析

subagent prompt 里没有明确指定输出文件名，只说了"写口播脚本"，没有说"写到哪个文件"。

subagent 根据任务描述自行决定文件名，写到了输入文件（同目录下的 `script_raw.md`），覆盖了原始内容。

主 agent 在验收时发现只有 `script_raw.md`，没有 `script_final.txt`。

## 发生场景

文案扩展任务（口播脚本 + 知乎/公众号文案），由 subagent 并行执行时最容易出现。

原因：主 agent 将多个文件写入任务扔给 subagent，subagent 按自己的理解命名，容易写到中间文件而非最终文件。

## 修复方案

### 方案1：在 subagent prompt 里明确指定输出文件名（主 agent 责任）

主 agent 调度 subagent 时，在 goal 描述里明确：

```
输出文件（必须写到这里，不许写其他路径）：
- 知乎文案 → 01_content/drafts/zhihu/zhihu_final.md
- 公众号文案 → 01_content/drafts/wechat/wechat_final.html  
- 小红书文案 → 01_content/drafts/xiaohongshu/xiaohongshu_final.md
- 口播脚本 → 03_video/script_final.txt（不是 script_raw.md）
```

每个路径精确到文件名，不给 subagent 自由命名空间。

### 方案2：主 agent 验收时检查（automedia-project-init Step 5 已实装）

```python
# Step 5: Subagent 完成质量验证
def verify_subagent_output(project_root):
    required = {
        "03_video/script_final.txt": "口播脚本",
        "01_content/drafts/zhihu/zhihu_final.md": "知乎文案",
        "01_content/drafts/wechat/wechat_final.html": "公众号文案",
    }
    for rel_path, label in required.items():
        full_path = os.path.join(project_root, rel_path)
        if not os.path.exists(full_path):
            # 查中间文件是否有内容
            alt = os.path.join(project_root, rel_path.replace("_final", "_raw"))
            if os.path.exists(alt) and os.path.getsize(alt) > 100:
                # 有内容，手动创建 final
                shutil.copy(alt, full_path)
                print(f"⚠️ {label}: 修复命名 {alt} → {full_path}")
```

### 方案3：subagent prompt 禁止写入中间文件

```
约束：输出文件必须是 final 版本（_final.md / _final.txt / _final.html）。
禁止向 _raw.md / _draft.md 写入最终内容。
```

---

## 经验教训

1. **主 agent 必须明确指定输出文件名**，不能留给 subagent 自由判断
2. **中间文件（_raw/_draft）不能作为最终交付**，验收时必须检查最终文件（_final）
3. **subagent 超时问题**：视频生产链路太长（5步），subagent 跑不完；视频生产链路不应该进 subagent

---

## 相关修复

- `automedia-project-init` SKILL.md Step 5 已加入 Subagent 完成质量验证
- 主 agent 视频生产链路已调整为全在主 agent 执行，不进 subagent