# Master-File Bundling Pattern

> **记录时间**：2026-05-22  
> **来源**：20260515_ai_industry_daily、20260515_baidu-yijing 项目结构分析

## 模式描述

部分项目（尤其是 2026-05-15 前后的批次）采用了 **master-file bundling** 而非 per-platform 分离存储：

```
01_content/drafts/
├── <topic>_content.md      ← Master file：包含 V1.0 zhihu、V1.0 xiaohongshu、[审稿记录]、[V2.0 四平台]
├── wechat/
│   └── wechat_draft.html   ← Wechat 单独存放（HTML 格式，V2.0 终稿）
└── zhihu/                  ← 空目录，zhihu 内容在 master file 里
└── xiaohongshu/           ← 空目录，xiaohongshu 内容在 master file 里
```

`project_info.json` 的 `articles` 字段映射：

```json
{
  "wechat":   "01_content/drafts/wechat/wechat_draft.html",
  "zhihu":   "01_content/drafts/<topic>_content.md",
  "xiaohongshu": "01_content/drafts/<topic>_content.md"
}
```

## Master File 内部结构

典型的 master file 包含以下 sections（用 `---` 分隔）：

```
## 二、微信公众号文章（~2000字）   ← V1.0 wechat
...
---
## 三、知乎文章（~2000字）         ← V1.0 zhihu
...
---
## 四、小红书内容（~500字）        ← V1.0 xiaohongshu
...
---
# 【审稿记录】                    ← Humanizer/Copy-Review/CTA notes
...
---
# 【最终定稿 V2.0】               ← V2.0（所有平台汇总，但 wechat 已在 HTML 中）
```

## 识别方法

1. 读取 `project_info.json` 的 `articles` 字段
2. 如果 zhihu/xiaohongshu 指向 `_content.md` 而非 `zhihu/zhihu_article.md` → 是 master-file 模式
3. `ls 01_content/drafts/zhihu/` 若为空 → 内容在 master file 里

## 审查时的处理方式

**不需要重组文件**，直接按需提取：

1. 找到目标平台的 section header（`## 三、知乎文章`）
2. 找到下一个 `---` 或下一个 section header之间的内容
3. 按 `copy-review` skill 输出报告到 `04_review/copy_review_<platform>.md`
4. Wechat 内容在 `wechat_draft.html` 中独立审查（已是 V2.0 终稿）

## 注意事项

- Wechat 的 V2.0 终稿在 `wechat_draft.html`，不等于 master file 里的 wechat V1.0
- Master file 里的"【最终定稿 V2.0】"是整合文本，wechat 部分以 HTML 为准
- 项目时间戳：`20260515_ai_industry_daily`、`20260515_baidu-yijing` 都是此模式
