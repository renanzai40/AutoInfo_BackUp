# 2026-06-26 初始化跳过事故复盘

## 事故

OpenAI IPO 招揽双雄话题 6/25 已生产交付，6/26 早 08:30 推送再次出现。

## 根因

```
用户选题
    ↓
agent: 直接 mkdir 建项目目录（无 00_project_info/）
    ↓
agent: 直接开始 R0 调研
    ↓
...全链路生产完成...
    ↓
交付
    ↓
❌ pool.db 中 topic 仍是 status='pending'
    ↓
次日 08:30 推送读取 status='pending' → 再次推送
```

跳过步骤：
1. `automedia-project-init` 未加载 → 无 `00_project_info/project_info.json`
2. `pool_sync.py` 未调用 → pool.db 话题未标记为 `selected`

## 修复

### 短期（立即）
- pool.db 手动更新 status → selected ✅
- 补建 `00_project_info/project_info.json` ✅

### 长期（方案 C）
- **A**: `pool_sync.py` 改造 — `--project-dir` 改为可选，不提供目录时只更新 pool.db，不依赖 project_info.json
- **B**: `init_project.py` 创建 — 新建项目的唯一标准入口。自动做三件事：
  1. 建标准目录（含 00_project_info/）
  2. 写 `project_info.json`
  3. 调 `pool_sync.py` 同步池状态
- **G0.5**: `check_production_init.py` 创建 — R0 前预检，检测 `00_project_info/` + pool.db 状态，自动修复

## 文件

```
~/.hermes/profiles/content/scripts/
├── pool_sync.py                # A: --project-dir 可选
├── init_project.py             # B: 新建项目唯一入口
└── check_production_init.py    # G0.5: 预检 + 自动修复
```
