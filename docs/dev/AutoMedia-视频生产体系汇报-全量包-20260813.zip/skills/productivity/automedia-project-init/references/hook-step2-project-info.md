# 第二步：写入项目信息 + 关联 topic_id

### 第二步：写入项目信息 + 关联 topic_id

初始化后，立即更新 `project_info.json`：
- `topic`：话题名称
- `category`：引流款 / 业务款
- `status`：initialized → 生产中 → 待发布 → 已发布
- **`topic_id`**：关联到 pool.db 的 topic_id（★ 必须，没有则不得进入生产链路）
- **`source`**：`pool`（来自话题池）/ `manual`（旁路手动指定）

> ⚠️ **Hard Gate**：没有 `topic_id` 的项目不得进入生产链路。
