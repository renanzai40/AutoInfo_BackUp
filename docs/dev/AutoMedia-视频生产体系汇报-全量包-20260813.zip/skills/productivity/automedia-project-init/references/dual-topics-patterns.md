# Dual-Topics 双话题项目结构 3 种历史模式（2026-06-01 固化）

> **触发**：用户每天选 2 个话题（1 引流款 + 1 业务款）一起做 → 项目结构用 `dual-topics`。
> **何时读本文**：准备建新 dual-topics 项目 / 接手历史 dual-topics 项目 / 用户问"为什么 5/19 和 5/28 目录结构不一样"。

## 1. 三种历史模式对比表

| 时间 | 项目样例 | slug 父目录 | slug 内文件 | `00_project_info.json` 格式 | 字段命名 |
|------|---------|------------|-----------|--------------------------|---------|
| **5/19** | `20260519_092124_dual-topics` | `00_project_info.json` | `doubao-yuyue-canlou/00_project_info.json` | `topics[]` 数组（slug+topic+category+topic_id） | `category: growth/business`（英文） |
| **5/24** | `20260524_122819_dual-topics` | `00_project_info.json` | `ai-video-tools/00_topic_info.json` | `topics[]` 数组 | `type: 引流款/业务款`（中文） |
| **5/28** | `20260528_104457_dual-topics` | `00_project_info.json` | `trapdoor/00_topic_info.json` | `topics[]` 数组 | `type: 引流款/业务款`（中文） |

## 2. 当前推荐模式（5/28，最新）

```
20260601_HHMMSS_dual-topics/                ← 项目根（时间戳 + _dual-topics 后缀）
├── 00_project_info.json                    ← 根级：topics[] 数组，每元素含 type/topic_id
├── {引流款-slug}/                          ← 第一个话题子目录
│   ├── 00_topic_info.json                  ← 话题元数据（与父级 topics 元素对应）
│   ├── 01_content/drafts/{5平台}/          ← 5 平台草稿
│   ├── 02_images/{cover,assets}/
│   ├── 03_video/                           ← 视频产物（TTS 音频 + SRT）
│   ├── 04_review/                          ← 审核报告
│   └── 05_publish/                         ← 发布日志
└── {业务款-slug}/                          ← 第二个话题子目录
    └── ...（同上）
```

### 命名规范
- 父目录：`YYYYMMDD_HHMMSS_dual-topics`（不带 slug——slug 在子目录里）
- slug 目录：`<引流款核心词>-<topic-slug>` 或 `<业务款核心词>-<topic-slug>`（不含日期，日期已在父目录里）
- 示例：`minimax-m3-launch`（引流款）+ `tencent-hy-memory`（业务款）

## 3. 为什么用 5/28 模式（不推荐 5/19）

| 维度 | 5/19 模式 | 5/28 模式（推荐） |
|------|----------|-----------------|
| slug 内元数据文件 | `00_project_info.json` | `00_topic_info.json` |
| 命名清晰度 | ⚠️ 与父目录同名，混淆"父级 project vs slug topic" | ✅ 明确区分 |
| 字段命名 | `category: business/growth`（英文） | `type: 引流款/业务款`（中文） |
| 与品牌 persona 一致性 | ⚠️ pool.db 用英文，project 文件用中文更可读 | ✅ 中文+项目文件可读性更高 |

**关键决策点**：
- **`pool.db` 永远用英文**（`category='business'` 或 `'growth'`）—— schema 层 CHECK 约束
- **`00_project_info.json` 用中文**（`type: 引流款` 或 `业务款`）—— 与 yimuguanwei-persona 一致
- **不要混用** —— 写项目文件时不要写 `category: growth`（那是 pool.db 的命名）

## 4. 5 平台标准（不变量）

无论 dual-topics 还是单话题，每个 topic 必须做 **5 个平台**：

| 平台 | 字数 | 文件路径（在 slug 目录下）|
|------|------|----------------------|
| 微信公众号 | ~2000 字 | `01_content/drafts/wechat/wechat_draft.html` |
| 知乎 | ~2000 字 | `01_content/drafts/zhihu/zhihu_article.md` |
| 小红书 | ~500 字 | `01_content/drafts/xiaohongshu/xiaohongshu_post.md` |
| 抖音 | 40s 视频脚本（~150-200 字口播）| `01_content/drafts/tiktok/script.txt` |
| B站 | 40s 视频脚本（~150-200 字口播）| `01_content/drafts/bilibili/script.txt` |

**绝对标准 = 5 平台全部要做**。**4 平台是历史早期版本**（2026-05-19 之前 wechat 还是独立的 md/html，5/24 之后才统一 5 平台）。看到任何 4 平台文档/项目 = 旧版，按 5 平台补齐。

**字数是"软"标准**（±20% 内正常）：
- 2000 字文章实际 1600-2200 都可以
- 500 字小红书实际 400-700 都可以
- 150-200 字口播 = 40s 视频，±10s 可以

## 5. 历史项目识别速查

接手 dual-topics 项目时，先 `cat 00_project_info.json` 看 `topics[]` 数组结构：
- `category: growth/business`（英文）→ 5/19 旧模式
- `type: 引流款/业务款`（中文）→ 5/24+/5/28 新模式

**两种模式都能跑**，但新建项目必须用新模式（5/28）。

## 6. 跨会话踩坑记录

| 踩坑日期 | 现象 | 根因 | 修法 |
|---------|------|------|------|
| 2026-06-01 | 助手问"category 字段填什么" | 不确定 pool.db（英文）和 project 文件（中文）命名差异 | 见本文 §3 |
| 2026-06-01 | 助手问"5 平台还是 4 平台" | 看到 4 平台旧文档，不敢确认 | 见本文 §4，5 平台是硬标准 |
| 2026-06-01 | 助手对比 5/19 vs 5/24 vs 5/28 三个 dual-topics 项目 | 不知道用哪个版本 | 见本文 §2，用 5/28 |

## Gotchas

1. **不要新建单话题项目放 dual-topics 文件夹**：一个项目只对应一个话题，dual-topics 父目录是特殊情况（一天 2 话题的快捷结构）
2. **slug 目录里不要再嵌日期**：日期已经在父目录里了，slug 重复日期 = 冗余
3. **`topics[].type` 和 `pool.db.category` 是两套命名**：不要在 project 文件写 `category: business`（那是 pool.db 的）
4. **5 平台 = 1 项目**：不要把 4 平台做完就发，必须补齐到 5 平台
5. **00_project_info.json 必须在父目录根**，不要藏在 `00_project_info/` 子目录里（5/19 之前在子目录，5/19+ 改到根）
