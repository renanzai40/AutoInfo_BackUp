# 🔑 手动项目 topic_id 反查规则（2026-06-11 新增）

### 🔑 手动项目 topic_id 反查规则（2026-06-11 新增）

**触发**：`source: "manual"` 的项目（用户直接指定话题，非池子选题）。

**执行步骤（创建 project_info.json 前必须执行）：**

```
1. 取话题标题 title
2. 查 pool.db：SELECT topic_id FROM topics WHERE title = ?
3. 有结果 → 用 pool.db 的真实 topic_id（禁止编造 manual_xxx）
4. 无结果 → 去空格后重试（池中标题可能无空格，项目标题有空格），
   INSERT 一条到 topics 表，用返回的 hash 作为 topic_id
```

> ⚠️ **2026-06-15 实测陷阱**：步骤 2 的 `WHERE title=?` 精确匹配会因**空格差异**静默失效。
> 池中标题常不带空格（"豆包AI误导用户损失600元"），而项目标题带空格（"豆包 AI 误导用户损失 600 元"）。
> 结果：agent 以为池中没有这条记录 → 编造 `manual_xxx` → 漂移。
> **应对**：精确匹配 0 结果后，必做去空格归一化后再次查询。

**为什么必须遵守**：
- 不遵守 → pool.db 中原始记录 status 永远停在 'pending'
- 不遵守 → regen 回写钩子（按 topic_id 匹配）找不到对应记录
- 不遵守 → 话题永远留在池子里，不断被推送

**兜底机制**：`regen_project_registry.py` 有 title fallback 回写（2026-06-11 新增），
会在 regen 跑时按 title 匹配后自动修复。但这是兜底不是依赖——源头堵漏 0 滞后。

**反模式（禁止）**：
- ❌ 编造 `manual_20260610_xxx` 这样的 topic_id
- ❌ topic_id 留空或填任意字符串
- ❌ 依赖 regen 兜底修复（窗口期 0-24h 内话题仍在池子里）
