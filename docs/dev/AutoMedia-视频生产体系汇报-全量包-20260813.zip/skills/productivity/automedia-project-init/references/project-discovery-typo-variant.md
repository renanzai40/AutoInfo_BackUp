# 项目发现模式：typo-variant 同名目录（2026-05-26）

## 问题现象

用户问"昨天启动的两个项目状态如何"，我先扫描了 `projects/` 目录，找到了：
- `20260525_085515_wentech-ansys-litiation/` — 只有1个小红书文件，空壳
- `20260525_085515_wentech-ansys-litigation/` — 5平台文案+视频+审核，完整

两个目录只差一个字母：`litiation`（错误）vs `litigation`（正确）。

同时 projects/ 根目录有 `wentech_remotion_v1.mp4` + `wentech_script.md`（说明视频和脚本已生成，但散落在项目目录外）。

## 根因

2026-05-25 创建项目时输错了拼写（litiation → litigation），之后又重新建了正确拼写的目录。
结果：内容分散在两个目录，需要手工合并。

## 识别方法

1. `find /path -type d -name "*litiation*"` 可以快速找到 typo-variant
2. 扫描 projects/ 时，相同时间戳+相似名称的多个目录是强力信号
3. 判断哪个目录"更完整"：看文件数量和子目录层级

## 正确处理流程

```
1. ls projects/20260525_085515_wentech-ansys-litiation/ → 空壳，跳过
2. ls projects/20260525_085515_wentech-litigation/ → 完整，作为正式项目
3. mv litiation litiation_TYPO废弃_  → 保留记录，不删除
4. 检查 litigation/05_publish/ 是否为空 → 内容完成但未发布，需要补发布步骤
```

## 关联教训

- **项目目录名拼写错误**：应在建立项目时就用 automedia-project-init 的标准命名规范
- **视频/脚本散落在项目外**：根目录的 `wentech_remotion_v1.mp4` 说明视频生成时没有在项目目录内操作
  - 正确做法：生成视频后立即复制到 `03_video/video_final.mp4`，不要留在项目根目录
- **status 字段不等于真实进度**：`initialized` 可能意味着"建了目录就没动过"，也可能意味着"内容全做完了但没更新 status"

### B站脚本常放在 tiktok/ 子目录
审核时：同时检查 `drafts/tiktok/`（含 bilibili_script.txt）和 `drafts/bilibili/` 两个路径。


```bash
# 找 projects/ 下所有包含 "litia" 的目录（能覆盖 litiation/litigation 两种拼写）
find /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/ -maxdepth 1 -type d -name "*litia*" | sort

# 统计每个目录的文件数，判断哪个是空壳
for d in /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/*litia*; do
  count=$(find "$d" -type f | wc -l)
  echo "$count $d"
done | sort -rn
```