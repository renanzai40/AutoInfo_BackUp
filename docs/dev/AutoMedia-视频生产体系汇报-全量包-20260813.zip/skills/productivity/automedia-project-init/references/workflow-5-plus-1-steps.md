# 正确 5+1 步工作流（项目启动 Step 0-1）

### 正确 5+1 步工作流（项目启动 Step 0-1）

```
0. 选题确认（user 拍板）
    ↓
1. 初始化项目 ← 唯一入口：init_project.py（替代手动 mkdir）
   → 自动建目录 + 写 project_info.json + 同步 pool.db
    ↓
2. 加载 automedia-research → Gate R0（读 source_url → 产出 00_research/）
    ↓
3. 判定话题类型（业务款/引流款/热点/争议）
   → 加载 content-prompt-templates 执行 Gate PT（选差异化结构）
    ↓
4. 启动 2 条并行链路：
   ├─ 链路 A: 视频生产（HyperFrames + 5 步工作流）
   └─ 链路 B: 5 平台文案（公众号/知乎/小红书/抖音/B站 + 4 审核）
   ↑↑↑ 两条链路同时启动，禁止先 A 后 B
    ↓
5. 写 5 平台草稿前 → 加载 platform-differentiation 执行 Gate PD（平台差异化）
    ↓
6. 4 审核并行跑（humanizer / copy-review / brand-cta / wechat-upload-checklist）
    ↓
7. 文案锁定前 → Gate II（内文配图完整性检查）
    ↓
8. verify_5platform_ready.sh 必跑（见 automedia-production-guard V7）
    ↓
9. 发布 + publish_log.json v2.1 更新
```

**2026-06-26 重要修正**：步骤 1 和步骤 2（原为「写 00_project_info.json + topic_id 同步」）已合并进 init_project.py。不再需要手动写 project_info.json 或手动调 pool_sync.py。
