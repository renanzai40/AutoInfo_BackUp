# 验证（5 平台未就绪禁止发飞书）

### 验证（5 平台未就绪禁止发飞书）

```bash
# 渲染前/发飞书前必跑
bash /home/renanzai/Remotion-Test/scripts/verify_5platform_ready.sh \
  /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/<project_id>

# 退出码：
# 0 = ALL PASS（5 平台全就绪，可发飞书）
# 1 = FAIL（缺关键资产，禁止发飞书）
# 2 = WARN（缺 WARN 项，可发飞书但需 user 知道）
```

**禁止**：
- ❌ "视频先做，文案稍后补" → 2026-06-05 已固化为反模式
- ❌ "5 平台只做 3 个" → automedia-project-init skill 5 平台硬标准
- ❌ "用 v1 video 顶一下" → P0-8 声音品牌资产铁律 + V5 mp3 vs SRT 核验
- ❌ "不发视频只发文字" → P-C 反模式（漏发视频 6-05 真实事故）
