# Topic Pool Dedup — Cluster Rules (2026-05-22)

## 背景

2026-05-22 发现：话题池（`pool.db`）的 `status` 字段从未被正确更新，导致同一话题在 cron 08:30推送 时重复出现。根因是 3 个断点：

1. **cron job 选完话题后没有更新 `pool.db status='selected'`**
2. **旁路选定的话题从未进入 `pool.db`**
3. **项目文件夹没有存储 `topic_id`**

本次只解决**预防性扫描**（cron 触发时）。真正的修复需要 cron job 里加 `UPDATE pool.db SET status='selected'`。

## 硬编码 Cluster 规则

`hooks/topic_deduplication.py` 中的 `mark_cluster_duplicates_from_pool()` 函数。9 个 cluster：

| Cluster | 关键词 | 覆盖话题示例 |
|---------|--------|-------------|
| 普京簇 | putin, 普京, 俄罗斯, 俄语 | 普京访华/普京就职/中俄 |
| 特朗普簇 | trump, 特朗普, 美国大选 | 特朗普关税/特朗普就职 |
| 豆包语音簇 | 豆包, doubao, 语音 | 豆包语音合成 |
| TTS簇 | tts, 语音合成, text-to-speech | CosyVoice2/Speechify |
| 腾讯混元簇 | 腾讯, 混元, tencent | 腾讯混元大模型 |
| 小米簇 | 小米, xiaomi, su7 | 小米汽车/小米手机 |
| AI内容簇 | ai内容, ai写作, aigc | AI内容生产工作流 |
| AI工作流簇 | ai工作流, claude code, cursor | Cursor/Claude Code自动化 |
| AI视频竞赛簇 | AI视频, 竞争, sora, 可灵 | Sora vs可灵/AI视频生成竞赛 |

每个 cluster 的 `selected` 话题会保留，**同 cluster 内的其他 `pending` 话题全部标记为 `archived`**。

## 使用方式

```python
from hooks.topic_deduplication import mark_cluster_duplicates_from_pool

mark_cluster_duplicates_from_pool(pool_db_path="pool.db", dry_run=False)
```

- `dry_run=True`：只打印不写入
- `dry_run=False`（默认）：实际更新 `pool.db`

## cron 集成（未完成）

目前 `mark_cluster_duplicates_from_pool()` 需要被 cron job 调用。建议在 `automedia` skill 的 cron hook 部分添加：

```
08:30  cron job:
  1. 采集新话题 → 插入 pool.db
  2. mark_cluster_duplicates_from_pool()  # 预防性去重
  3. 评分排序 → 推送
```

## 根因修复（待做）

最终修复是让 cron job 在"选定话题"时同步更新 pool.db：

```python
# 在 cron job 选定话题后执行
import sqlite3
conn = sqlite3.connect("pool.db")
conn.execute("UPDATE topics SET status='selected' WHERE id=?", (topic_id,))
conn.commit()
conn.close()
```

这样就不需要预防性 cluster 扫描了。
