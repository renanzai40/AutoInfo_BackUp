# 第一步：检查或创建项目根目录（2026-06-26 更新）

### 第一步：检查或创建项目根目录（2026-06-26 更新）

> **2026-06-26 起，新建项目不再手动 `mkdir` 或运行下方 Python 代码。改用 `init_project.py` 作为唯一标准入口。**

**标准操作：**

```bash
python3 ~/.hermes/profiles/content/scripts/init_project.py \\
  --topic-title "话题标题" \\
  --topic-slug "topic-slug" \\
  --category "引流款"
# 自动完成：建目录 → 写 project_info.json → 同步 pool.db
```

**init_project.py 完成的三件事：**
1. 建标准项目目录结构（含 `00_project_info/` 等 10+ 子目录）
2. 写 `00_project_info/project_info.json`（含 topic_id/topic/source/category）
3. 调 `pool_sync.py` 将 pool.db 中话题 status → `selected`

**如果项目目录已存在**（补初始化场景），`init_project.py` 会补建缺失子目录 + 补写 project_info.json，不会覆盖已有内容。

**特殊情况：只有目录、没有 00_project_info/** → 直接跑 init_project.py，它会补建缺失子目录。

**反模式（永久禁止）**：
- ❌ 手动 `mkdir` 建项目目录绕过 init_project.py
- ❌ 选题确认后直接 R0 调研，跳过初始化步骤
- ❌ project_info.json 的 topic_id 留空或编造 `manual_xxx`

**特别提醒**：G0.5 脚本 `check_production_init.py` 会在 R0 前自动检测初始化完整性。如果未通过，会尝试自动修复。详见 `automedia-production-guard` skill 的 Gate G0.5。

> ⚠️ **2026-06-26 真实事故**：跳过初始化 → pool.db 未同步(topic 仍 pending) → 次日 08:30 推送再次命中已交付话题。详见 G0.5 的检查 B。
