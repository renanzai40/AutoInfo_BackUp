# 品牌 CTA 合规审查清单（每平台逐项）

> **触发**：项目内容审核、发布前检查、接手历史项目时
> 本清单是 `brand-cta-review` skill 在项目审核场景的具体落地

## 5平台文案品牌合规检查

所有5个平台的文案都必须通过以下零容忍项检查：

| # | 检查项 | 方法 |
|---|--------|------|
| 1 | 品牌名"壹目贯维"出现在文中 | `grep "壹目贯维" wechat_draft.html zhihu_article.md xiaohongshu_post.md script.txt bilibili_script.txt` |
| 2 | 全文无禁止词（投资机构/金融研究/投资情报/政策信号/投资决策） | `grep -E "投资机构\|金融研究\|投资情报\|政策信号\|投资决策"` |
| 3 | 小红书正文末尾有 `#壹目贯维` 品牌话题标签 | `grep "#壹目贯维" xiaohongshu_post.md` |
| 4 | 小红书无诱导话术（"评论区扣1"/"私信领资料"/"点赞过100"） | `grep -E "评论区扣\|私信领\|点赞过\|关注后私信" xiaohongshu_post.md` |
| 5 | 视频脚本 + 文章 CTA 同步（品牌描述一致） | 手动对照 tiktok/script.txt 和各平台文案中的品牌描述段落 |

## 各平台品牌CTA要求

| 平台 | CTA 形式 | 示例 |
|------|---------|------|
| 微信公众号 | 品牌描述段落 | "壹目贯维——全球AI内容生产公司，专注于热点追踪、文案生成与多平台发布" |
| 知乎文章 | 品牌描述段落 + 互动引导 | "如果你关心...欢迎关注壹目贯维..." |
| 小红书 | 品牌话题标签 `#壹目贯维` + 互动引导 | "关注壹目贯维，了解更多..." |
| 抖音 | 品牌口播（5秒内出现） | "我是壹目贯维，专注热点追踪..." |
| B站 | 品牌口播（同抖音，但B站用户期待更深度内容） | 同抖音，适当增加分析感 |

## 典型失败案例

### 知乎文章缺品牌CTA（2026-05-26 实录）

- **问题**：文章正文内容完整，但末尾无品牌CTA段落，读者读完不知道文章谁写的
- **修复**：在正文末尾追加"作者说"段落，包含：
  - 品牌身份：壹目贯维=AI内容生产公司
  - 具体功能：热点追踪、文案生成、多平台发布
  - 互动引导："欢迎关注壹目贯维"
- **验证**：全文 `grep "壹目贯维"` 返回 >0 条

### B站 copy-review 缺失（2026-05-26 实录）

- **问题**：项目审核记录只有 tiktok/wechat/xiaohongshu/zhihu，缺 bilibili 的 copy-review 报告
- **原因**：bilibili 脚本和 tiktok 脚本存在同一目录（tiktok/）下，审核时只做了 tiktok 忽略了 bilibili
- **修复**：补充 bilibili copy-review 报告，内容与 tiktok 版本对照检查
- **预防**：审核时明确要求5个平台的报告都存在

## 图片素材完整性检查

| 类型 | 路径 | 检查方法 |
|------|------|---------|
| 帧图（视频素材） | 02_images/assets/ | `ls frame_*.jpg | wc -l`，常见9帧（001-009） |
| 封面图 | 02_images/cover/ | 必须有 cover_16x9.png + cover_9x16.png |
| 视频 | 03_video/ | video_final.mp4 存在且尺寸正常 |
| 音频 | 03_video/ | audio_voiceover.mp3 存在 |
| 字幕 | 03_video/ | subtitle.srt 存在 |

## 发布日志完整性

每个项目必须有 `05_publish/publish_log.json`，内容：
```json
{
  "content_id": "微信草稿content_id",
  "thumb_media_id": "封面图media_id",
  "title": "文章标题",
  "topic": "原始话题",
  "uploaded_at": "ISO时间",
  "status": "draft_uploaded",
  "platform": "wechat"
}
```
