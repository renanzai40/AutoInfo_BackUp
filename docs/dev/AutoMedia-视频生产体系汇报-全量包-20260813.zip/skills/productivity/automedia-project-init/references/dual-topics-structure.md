# 双话题项目（dual-topics）结构（2026-06-01 固化）

### 双话题项目（dual-topics）结构（2026-06-01 固化）

> **触发**：用户每天选 2 个话题（1 引流款 + 1 业务款）一起做 → 用 `dual-topics` 后缀。
> **历史有 3 种目录结构**（5/19 / 5/24 / 5/28 / 6-05），三种都能跑但**新建项目必须用 5/28 / 6-05 模式**。
> **详细对比 + 模板 + 字段命名规范**：见 `references/dual-topics-patterns.md`

**速记要点**（完整版见 reference）：

**A. 5/28 模式（父目录 + 子目录结构）**：
- 父目录：`YYYYMMDD_HHMMSS_dual-topics/`（不带 slug，slug 在子目录）
- slug 内用 `00_topic_info.json`（**不要**用 `00_project_info.json` —— 与父目录重名）
- 父目录根放 `00_project_info.json`（**不要**藏在 `00_project_info/` 子目录里）
- 字段命名：`topics[].type: 引流款/业务款`（中文）—— pool.db 用 `category='growth'/'business'`（英文），**两套不要混**
- 5 平台标准：抖音 / B站 / 微信公众号 / 知乎 / 小红书（每个 topic 都做 5 个，不存在"4 平台版本"）

**B. 6-05 模式（**2 个独立项目目录**——2026-06-05 实测固化）**：
- **不建父目录**——2 个独立项目目录平铺在 `projects/` 顶层
- 父目录结构在实战中导致子目录内 `00_project_info.json` 字段命名混乱（`type` vs `category` 漂移）
- 推荐用于：双话题项目（引流 + 业务）一次性产出，按 `YYYYMMDD_HHMMSS_<引流款-slug>` 和 `YYYYMMDD_HHMMSS_<业务款-slug>` 创建
- 实例（2026-06-05）：
  ```
  projects/
  ├── 20260605_114900_openai-codex-team/    # 业务款
  └── 20260605_114900_alphabet-anthropic/   # 引流款
  ```
- 每个项目结构齐全：`00_project_info/project_info.json` + `01_content/drafts/{wechat,zhihu,xiaohongshu,tiktok,bilibili}/` + `02_images/{assets,cover}/` + `03_video/` + `03_subtitle/` + `04_review/` + `05_publish/`
- 优点：每个项目独立 status / publish_log / 4 阶 review_log，互不干扰

**修法决策**：**新建项目用 B（6-05 模式）**——A 模式保留为历史 5/19/5/24/5/28 项目的归档形式，不再用于新项目。
