# 项目归档流程（2026-06-02 用户纠错后固化，INV-8/9）

## 项目归档流程（2026-06-02 用户纠错后固化，INV-8/9）

> ⚠️ **重要修正（2026-06-02 教训）**：本节**重写**了之前的"项目完成发布 + 用户验收通过即可归档"模糊规则。
> 旧规则的 bug：让"放在 archive/ 目录" = "已归档"，agent 看到项目有 video_final.mp4 + publish_log 就会**擅自归档**——这是错的。
> 2026-06-02 4 个项目（m3/hy/deepseek-75/lorai-marketing）被前 session 错误归档，全部回滚到 active。

**核心铁律（用户原话 2026-06-02）**：

> "当一个项目没有做到全平台都发布完成之前，不得擅自归档，也不能把项目的已发布平台的素材，比如微信公众号素材，单独归档。"

**触发时机（双触发器，缺一不可）**：

| 触发器 | 含义 | 谁执行 |
|---|---|---|
| A. project.status = `published` | 全平台 published (业务款 5 平台,引流款 1 平台) | 派生（`compute_status()` 计算） |
| B. 用户显式告知 agent 归档 | 用户跑 `archive_project.py <project_id>` 或 `archive_project.py --force ...` | **用户**（**不是** agent） |

**两条铁律**：

```
INV-8: agent 不得把项目移到 archive/，除非 (compute_status() == "published") OR (user 显式 --force)
       实现: 任何 mv 项目到 archive/ 的脚本必须先验证 compute_status()
       例外: user 显式 run "archive_project.py --force <id> --reason '...'" 可绕过（带 reason 记录）

INV-9: 任何 platform 的素材（02_images/03_video/05_publish/等）不得单独移到 archive/
       即: 即使 wechat 已 published，wechat 素材仍留在原项目目录
       只有项目整体 archive 时，所有素材一起搬
```

**正确的归档命令**（**user-driven**）：

```bash
# 正常路径(必须先 published,user-driven)
python3 /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/archive_project.py <project_id>
# 内部:
#   1. compute_status(platforms, project_type, project_dir) == "published"?
#      YES → mv projects/<id> → projects/archive/<id>
#      NO → 拒绝,提示"先 published 再归档"
#   2. 同步 pool.db: topic.status = "archived"
#   3. 写 publish_log.notes = "archived at <date>"

# 强制路径(项目失败/永久放弃,带 reason 记录)
python3 archive_project.py --force <project_id> --reason "项目失败/永久放弃, ... "
# 内部: 不验证 published,但写 reason 到 publish_log.notes + pool.db 同步
```

**反模式（永久禁止）**：

| ❌ 错误做法 | ✅ 正确做法 |
|---|---|
| agent 看到有 video_final.mp4 + publish_log 写完 → 主动 mv 到 archive/ | 严格等 `compute_status() == "published"` 或 user 显式 --force |
| wechat 已 published → 把 wechat 素材（02_images/03_video 等）单独移到 archive/ | 全部素材**整体**保留在原项目目录,只等全平台 done 才整体 archive |
| agent 在 publish_log 写"status: archived" 但项目还在 active/ | 不写 status 字段,archive 是**目录位置**的语义,不是字段 |
| 用户没说归档,agent 看到"完事了"自作主张归档 | 永远等 user 显式跑命令,agent 永远不主动 mv |

**Step 1: 移动项目目录到 archive/**（user-driven,不是 agent）

```python
import shutil, os
import sys
sys.path.insert(0, '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts')
from compute_project_status import compute_status  # 单一 source of truth

PROJECTS = '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects'
ARCHIVE = f'{PROJECTS}/archive'
os.makedirs(ARCHIVE, exist_ok=True)

src = f'{PROJECTS}/{project_id}'
dst = f'{ARCHIVE}/{project_id}'

# ⚠️ INV-8 强制校验
force = args.get('force', False)
reason = args.get('reason', '')

if not force:
    status = compute_status(src)  # 派生状态
    if status != 'published':
        raise Exception(
            f"❌ INV-8 违反: project.status={status}, 拒绝归档。\n"
            f"  需要先全平台 published (业务款 5 平台,引流款 1 平台)。\n"
            f"  或用 --force 显式绕过 (带 reason 记录)。"
        )

# 移动
if not os.path.exists(dst):
    shutil.move(src, dst)
    print(f"✅ 归档: {src} → {dst}")
else:
    print(f"⚠️ {dst} 已存在,跳过")
```

**Step 2: 更新 pool.db status=archived**（topic 联动, INV-3）

```python
import sqlite3
db = '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db'
conn = sqlite3.connect(db)
cur = conn.cursor()

# 查 topic_id
import json
with open(f'{dst}/00_project_info/project_info.json') as f:
    info = json.load(f)
topic_id = info.get('topic_id')

if topic_id:
    cur.execute(
        "UPDATE topics SET status='archived', updated_at=datetime('now') "
        "WHERE topic_id=? AND status IN ('selected', 'published', 'writing')",
        (topic_id,)
    )
    conn.commit()
    print(f"✅ pool.db 同步: topic_id={topic_id[:8]}... → archived")
conn.close()
```

**Step 3: 记录 archive 元信息到 publish_log.json**

```python
import json
log_path = f'{dst}/05_publish/publish_log.json'
with open(log_path) as f:
    log = json.load(f)

log['archived_at'] = datetime.now().isoformat()
log['archive_reason'] = reason if force else 'all_platforms_published'
log['archive_method'] = 'user_command'  # 永远是 user 触发,不是 agent

with open(log_path, 'w') as f:
    json.dump(log, f, ensure_ascii=False, indent=2)
```

**4 个 INV 联动修正（2026-06-02 修正版）**：

| INV | 修正内容 |
|---|---|
| **INV-3** | `project.status ∈ {cancelled, published}` OR 项目目录在 archive/ ⇒ `topic.status = archived` |
| **INV-8 (新)** | agent 不得 mv 项目到 archive/ 除非 `compute_status() == "published"` OR `user --force` |
| **INV-9 (新)** | 任何 platform 素材不得单独归档（项目整体绑定）|
| **archive 触发** | 双触发：(A) published 自动派生 + (B) user 显式命令,两者等价 |

**为什么 archive 触发是双触发**：

- **自动派生（A）**：`compute_status() == "published"` 是**事实**（全平台 done）—— 但派生结果**不触发** mv,仅作"可以归档"信号
- **user 命令（B）**：user 显式 `archive_project.py <id>` 才是**行动触发**——即使 computed_status=published,user 也可以**不归档**(等几个月再归档)
- **never agent**：agent 永远不主动 mv,这是用户拥有的"项目生命周期收尾权"

**典型误用**（2026-06-02 实际发生）：

| 项目 | 实际状态 | 当时 archive 决定 | 错误 |
|---|---|---|---|
| m3 | awaiting_publish（公众号草稿未点发布）| 移到 archive/ | ❌ INV-8 违反 |
| hy | awaiting_publish（v1 已知缺陷未发布）| 移到 archive/ | ❌ INV-8 违反 |
| deepseek-75-discount | 无 publish_log,5/26 旧项目 | 移到 archive/ | ❌ INV-8 违反 |
| lorai-marketing | 无 publish_log,5/26 旧项目 | 移到 archive/ | ❌ INV-8 违反 |

**4 个全部回滚**到 `projects/` 顶层。**2026-06-02 E 任务发现此问题后立刻回滚**。

**关键 takeaway**：

- archive 不是"项目 done"的事实标记,archive 是**用户对项目收尾的决定**
- 用户可能"等几个月再归档"——这是合理的
- "全平台 published"是"可以归档"的必要条件,但**不是**充分条件
- agent 永远不擅自归档,这是 INV-8 的核心

**归档常见误区（2026-06-02 修正版）**：

| 误区 | 后果 | 正确做法 |
|---|---|---|
| ❌ agent 看到 "项目完事" 主动 mv | INV-8 违反, 4 个项目被错误归档 | ✅ 等 user 跑 `archive_project.py <id>` |
| ❌ wechat published 后单独把 wechat 素材移走 | INV-9 违反, 整体性破坏 | ✅ 整体项目保留, 全部素材一起搬 |
| ❌ 项目还没全平台 done 就归档 | "项目已归档"误导 future session | ✅ user 用 `--force --reason` 显式声明放弃 |
| ❌ archive 触发后删 03_video/ 视频 | 失去交付物 | ✅ archive 整体 mv, 视频跟着走 |

---
