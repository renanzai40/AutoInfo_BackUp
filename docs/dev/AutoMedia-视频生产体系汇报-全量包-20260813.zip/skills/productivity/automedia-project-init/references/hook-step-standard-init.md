# ⚡ 标准化操作：创建项目后即调用 init_project.py（2026-06-26 更新）

### ⚡ 标准化操作：创建项目后即调用 init_project.py（2026-06-26 更新）

```bash
# 新建项目的唯一入口——替代之前的 pool_sync.py 手动调用
python3 ~/.hermes/profiles/content/scripts/init_project.py \
  --project-dir <project_name> \
  --topic-title "<话题标题>" \
  --topic-slug "<topic-slug>" \
  --category "引流款|业务款"
```

init_project.py 内部自动完成：
1. 建标准项目目录（若目录已存在则补建缺失子目录）
2. 写 `00_project_info/project_info.json`
3. 调 `pool_sync.py` 将池中话题 status → `selected`（同时将真实 topic_id 写回 project_info.json）

**效果**：
- 有匹配话题 → `status` 改 `selected`，`project_info.json` 写入真实 `topic_id`
- 无匹配（manual 话题）→ 标注 `source=manual`，不污染数据
- 使用 `pool_sync.py` 的 3 级匹配策略（归一化精确 → 子串 → 关键词），覆盖标题不同措辞同一事件的情况

**G0.5 Gate 检查**：每次 R0 前，`check_production_init.py` 会自动验证初始化完整性。详见 `automedia-production-guard` skill 的 Gate G0.5 检查 B。

**不再需要以下手动步骤。** 保留下方第三备用，但新建项目时只用上面的脚本行。
