# 项目发现模式：status 字段不等于真实进度（2026-05-26）

## 问题现象

用户问"昨天启动的两个 automedia 项目状态如何"。

我先查了 `projects/` 目录，找到了：
- `20260525_085515_wentech-ansys-litiation/`（typo拼写错误）→ 空壳
- `20260525_085515_wentech-ansys-litigation/`（正确拼写）→ 完整
- `20260525_085515_618-ai-tools-recommendation/` → 状态显示 `initialized`

但扫描 session 历史发现：
- DeepSeek v7（8.7MB）和 Lorai v7（9.7MB）视频**已发送给用户**（消息 ID 33850/33851）
- 但在 `projects/` 和 `Production/` 目录里都找不到对应的项目文件夹
- `wentech-ansys-litigation/00_project_info/project_info.json` 的 `status: "initialized"`

**结论**：
1. `status` 字段值不反映真实进度——`initialized` 可能意味着"刚建目录没动过"，也可能意味着"内容全做完了但 status 没更新"
2. DeepSeek/Lorai 视频已发但项目文件夹下落不明

## 项目真实状态判断标准

检查 project_info.json 的 status 字段时，同时检查：

```bash
# 扫描每个项目的审核记录数量
for dir in /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/202605*/; do
  echo "=== $(basename $dir) ==="
  cat "$dir/00_project_info/project_info.json" | python3 -c "import sys,json; d=json.load(sys.stdin); print('status:', d.get('status'), '| topic:', d.get('topic','')[:40])"
  review_count=$(find "$dir/04_review" -name "copy_review_*.md" 2>/dev/null | wc -l)
  video_count=$(find "$dir/03_video" -name "*.mp4" 2>/dev/null | wc -l)
  echo "  copy_review files: $review_count | video files: $video_count"
done
```

**判断逻辑**：

| status 字段 | copy_review 数 | 视频文件 | 真实状态 |
|------------|---------------|---------|---------|
| `initialized` | 0 | 0 | ✅ 项目确实未启动 |
| `initialized` | 5 | 1 | ⚠️ **内容全做完了，status 没更新** |
| `writing` | <5 | 1 | ⚠️ 部分完成，需要继续 |
| `published` | 5 | 1 | ✅ 完成 |

**Gate E（项目完整性检查）应该在 status=initialized 时仍然执行**，因为 initialized 不等于"内容为空"。

## 已发现 typo-variant 目录清单（2026-05-26）

| 错误拼写 | 正确拼写 | 处理 |
|---------|---------|------|
| `litiation` | `litigation` | 废弃 litiation，保留 litigation |

## 教训

1. **status 字段永远不能直接相信**——必须结合文件系统实际内容判断
2. **初始化项目必须立即更新 status**——`initialized` 只在刚建目录时有效，内容做完立即改为 `writing` → `published`
3. **视频发送用户前必须确认已存项目目录**——DeepSeek/Lorai 视频从 `/tmp` 发出后没有复制到项目 `03_video/`，导致"发了视频但找不到项目"