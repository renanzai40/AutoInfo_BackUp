# known-inconsistencies-2026-06-06.md

> **状态：审计完成，修复待 user 拍板**。本文件不擅自动现有规范——只记录证据 + 建议。
> 创建于 2026-06-06 dual-topics（配音师+红果短剧）交付后的 workflow clarification 审计。

## 🆕 Audit-First 方法论（user 原话 2026-06-06）

> "确保你的提案符合现有的工作流并对现有工作流不合理的地方
> （专指文件夹结构和过程/结果文件的存放位置等）给出了合理的改进措施"

**强制执行步骤**（任何 workflow clarification 请求时）：

1. **Audit 现有规范** — `skill_view` 相关 skill（automedia-project-init /
   remotion-project-init / publish-log-schema / remotion-workflow / delivery-packaging /
   automedia-production-guard）+ `search_files` 关键词
2. **Audit 实际项目** — `ls` 最近项目目录 + 对比文档 vs 实际文件落点
3. **列出现有规则 + 实际工作流 + 矛盾点** — 证据化（贴文件名 + 行号）
4. **基于真实证据给方案** — 提案只针对"现有规则不合理"或"实际工作流未明文"
5. **明确推荐** — 不列 A/B/C 让选，除非不可逆

**反面教材**（本会话教训）：

第一轮我凭印象给 3 条建议（"3 硬门控"/"音频 pre-render 即落"/"Composition.tsx 项目目录备份"），
user 要求 "review" 后自审发现：
- **过度工程**（建议 3）：项目目录再存 .tsx 备份，Remotion 仓库 git 控版本就够了
- **冗余**（建议 1）：3 硬门控已在 `remotion-workflow` 5 Gate 链 + `remotion-delivery-gate` 写明
- **事实错误**（建议 2）：漏了 Remotion 仓库 `public/audio/` 副本，音频实际是**双份**

第二轮才做了 system audit 找到下面 6 处真实不一致。

---

## 6 处真实不一致（待修复）

### 🥇 1. `03_subtitle/` vs `03_video/subtitle.srt` 路径 5 处不统一

| 位置 | 写的路径 |
|---|---|
| `automedia-project-init` L107-131 **标准段** | `03_video/subtitle.srt` ⚠️ |
| `automedia-project-init` L165（6-05 模式段） | `03_subtitle/` ✅ |
| `automedia` skill L448 | `03_subtitle/subtitle.srt` ✅ |
| `remotion-timecode-anti-pattern` L632 | `03_subtitle/subtitle.srt` ✅ |
| `remotion-pre-render-gate` L77 | **两个都接受**（容忍歧义）|
| `automedia-production-guard` L1342 | **两个都查**（容忍歧义）|
| `delivery-packaging` L34 | `03_video/subtitle.srt` ⚠️ |
| 实际项目（6-06 配音师+红果短剧） | `03_subtitle/subtitle.srt` ✅ |

**风险**：新会话按最显眼的标准段（L107-131）写到 `03_video/`，delivery-packaging 找不到。

**建议修复**：把 L107-131 标准段改为 `03_subtitle/subtitle.srt`，对齐 L165 + 实际工作流。
或保留两套写明"6-05 模式用 `03_subtitle/`，delivery-packaging 两边都查"。

**改动量**：1 段（5 行），风险低。

### 2. `video_raw.mp4` 列在标准但实际从未产出

- L148-153 文件命名段列 `video_raw.mp4` = "无字幕原始版（Fallback 方案用）"
- 6 个项目实际**都没有** `video_raw.mp4` —— Remotion 6-06 实战是**内嵌字幕**，
  根本不需要 raw 版
- **误导**：agent 以为必须生成 2 个 mp4（实际只需 1 个）

**建议修复**：删 `video_raw.mp4` 一行，或加备注 "Remotion 内嵌字幕时不需要"。

**改动量**：1 行，风险低。

### 🥉 3. Remotion 仓库结构自相矛盾

- `remotion-project-init` L13-23 **标准说**："**每个话题独立** `{topic}/remotion/`"
  ```bash
  mkdir -p {topic}/remotion/src/scenes
  mkdir -p {topic}/remotion/public/audio
  ...
  ```
- L65-75 **解法说**："所有 Composition 合并到 `/home/renanzai/Remotion-Test/`
  根项目统一管理，各话题写到 `Remotion-Test/src/` 下"
- **实际**：`ls /home/renanzai/Remotion-Test/src/` 有 19 个 Composition.tsx
  （AlphabetAnthropic / DeepSeek / Hongguo / HyMemory / Lorai / M3 / OpenAICodexTeam /
   RunwayAi / RunwayAleph2 / SixOneEight / VoiceActor ...）

**风险**：新会话按 L13-23 标准建 `{topic}/remotion/`，做出来跑不通（Remotion 是单根项目）。

**建议修复**：删/重写 L13-23 标准段，明确"统一在 `/home/renanzai/Remotion-Test/` 根项目，
Composition.tsx 写到 `src/` 顶层，根 `public/audio/` 共享 TTS 音频"。

**改动量**：删 11 行 + 加 1 段 5 行，风险中（动核心标准段）。

### 🥈 4. 音频双份机制完全没明文

| 位置 | 实际工作流 |
|---|---|
| `Remotion-Test/public/audio/voice-actor-ai-crisis.mp3` | Remotion 渲染时 NSegmentSkeleton L169 `staticFile(audioSrc)` 读这个（30 个 mp3）|
| `03_video/audio_voiceover.mp3`（= Whisper 读 + delivery-packaging 打包用）| Whisper 转写 mp3 → 写 SRT；delivery-packaging 打包 |

**Composition.tsx 怎么引用**：
- `audioSrc="audio/voice-actor-ai-crisis.mp3"`（字符串字面量）
- NSegmentSkeleton 内部 L169 `staticFile(audioSrc)` → 找 `Remotion-Test/public/audio/voice-actor-ai-crisis.mp3`

**实际工作流已隐式在双份**，但**没有任何 skill 写这条规则**。

**风险**：新会话只 cp 到 `03_video/`，渲染时 `staticFile()` 找不到音频（双前缀或 missing file），
 走 session 113223 时代 mp3 ≠ SRT 错配的老路。

**建议修复**：在 Gotchas 段补 1 段 "TTS 音频双副本规则"：
> TTS API 调完 → 立即 cp 到 **2 个位置**：
> 1. `Remotion-Test/public/audio/<topic>.mp3`（Remotion 渲染时 staticFile 读）
> 2. `{project_dir}/03_video/audio_voiceover.mp3`（Whisper 读 + 打包用）
>
> Composition.tsx audioSrc 字段 = 字符串字面量 `"audio/<topic>.mp3"`（不调 staticFile，
> NSegmentSkeleton 内部 L169 已调，详见 P0-15）

**改动量**：加 1 段 5 行，风险低。

### 5. cp 时机没明文

Gotcha L2 说 "每次内容产出后立即归档" —— **没说"哪个生成"算归档时机**。
- TTS 调完算生成？
- Whisper 转写完算？
- 渲染完算？
- QA pass 算？

**实际工作流**（已观察 6-06 配音师+红果短剧）：

| 素材 | 时机 | 落点 |
|---|---|---|
| TTS mp3 | **pre-render**（TTS API 调完）| Remotion 仓库 `public/audio/` + 项目目录 `03_video/audio_voiceover.mp3` |
| Whisper SRT | **pre-render**（Whisper 转写完）| 项目目录 `03_subtitle/subtitle.srt` + `whisper_result.json` |
| LLM 校正 SRT | **pre-render**（LLM 校正完）| 项目目录 `03_subtitle/subtitle_corrected.srt` |
| Composition.tsx | 写完立即 | Remotion 仓库 `src/<Topic>Composition.tsx`（git 控，**不在项目目录备份**）|
| Remotion 渲染 mp4 | 渲染成功 | Remotion 仓库 `out/<topic>.mp4`（Remotion 默认）|
| **最终视频 cp** | **post-render 3 门控全过** | 项目目录 `03_video/video_final.mp4` |

**3 门控**（必须全过才 cp `03_video/video_final.mp4`）：
1. Remotion 渲染 exit 0
2. 帧图 Vision QA 全 PASS（V8：cover + 段间字幕实际渲染）
3. Whisper 验证 mp3 朗读 = SRT 文本（V5：防 session 113223 错配）

**建议修复**：在 Gotchas 段补 1 段 "cp 时机分级表"（pre-render 即落 vs post-render 门控）。

**改动量**：加 1 段 6 行，风险低。

### 6. Remotion-Test/out/ 累积脏文件，无清理机制

- 实际 `ls /home/renanzai/Remotion-Test/out/*.mp4` 有 **40+ 个**：
  ```
  alphabet-anthropic-v3-backup.mp4 (6.7MB)
  alphabet-anthropic-v4.mp4 (7.7MB)
  alphabet-anthropic-v6/v7/v8/v9/v10/v11.mp4
  alphabet-anthropic.mp4
  ... openai-codex-team 系列 10 个
  ... runway-aleph-2 系列 13 个
  voice-actor-ai-crisis.mp4 (9.4MB) ← 当前最终版
  hongguo-short-drama-cliff.mp4 (9.4MB) ← 当前最终版
  ```
- Gotcha L2 "生成后立即归档" **没说要清 Remotion 仓库 out/**
- delivery-packaging L15 "只打包最终验收通过版本" **没说清 out/**

**风险**：仓库膨胀，几个月后上百个废文件，**`ls` 找当前最新版要 scroll 很久**。

**建议修复**（独立任务，不在本 skill 范围）：
- 在 `remotion-post-render-qa` 加 cleanup hook：
  - 渲染成功后 `mv out/<topic>_v*.mp4 out/archive/<YYYY-MM>/`
  - 保留 `out/<topic>.mp4`（无版本后缀的 = 当前最终版）
- 或新 cron 任务：每月 1 号 03:00 把 30 天前的 `out/*-v*.mp4` 移到 `out/archive/`

**改动量**：1 个 cleanup 脚本 + 1 段规则说明，风险中（动 out/ 是破坏性）。

---

## 修复优先级（按 ROI 排序）

| ROI | 问题 | 改动量 | 收益 | 风险 |
|---|---|---|---|---|
| 🥇 #1 | `03_subtitle/` 路径不统一 | 1 段（5 行）| 极高（消除 onboarding 必踩坑）| 低 |
| 🥈 #4 | 音频双份机制没明文 | 加 1 段 5 行 | 高（避免漏 cp 渲染失败）| 低 |
| 🥉 #3 | Remotion 仓库结构自相矛盾 | 删 11 行 + 加 1 段 5 行 | 高（消除认知冲突）| 中 |
| #2 | `video_raw.mp4` 列了但不用 | 删 1 行 / 加备注 | 低（消除误导）| 低 |
| #5 | cp 时机分级表 | 加 1 段 6 行 | 中（稳定化 cp 行为）| 低 |
| #6 | out/ 清理机制 | 新 cron 任务 | 低（仓库卫生）| 中 |

## 待 user 拍板的 5 处 patch

```diff
A. automedia-project-init L107-131 标准段（最显眼位置）
   改：03_video/subtitle.srt → 03_subtitle/subtitle.srt
   或保留两套写明："03_video/ 和 03_subtitle/ 两个都接受，6-05 模式用 03_subtitle/"

B. automedia-project-init L148-153 文件命名
   删：video_raw.mp4 一行（实际不用）
   或加备注："Remotion 内嵌字幕时不需要 video_raw.mp4"

C. remotion-project-init L13-23
   删 / 重写：明确"所有话题统一在 /home/renanzai/Remotion-Test/ 根项目，
   Composition.tsx 写在 src/ 顶层"

D. automedia-project-init Gotchas L573-580 补 1 段
   "TTS 音频双副本规则"：渲染时 Remotion 仓库 public/audio/ +
   Whisper 读 03_video/audio_voiceover.mp3

E. automedia-project-init Gotchas L573-580 补 1 段
   "cp 时机分级表"：pre-render（TTS/SRT 完立即 cp）/
   post-render（QA 3 门控全过才 cp video_final.mp4）

F. （可选，独立任务）remotion-post-render-qa 或新 cleanup 任务
   Remotion-Test/out/ 定期归档到 out/archive/（按月）
```

**反模式自查**（避免 patch 时再栽）：

1. **没推翻任何现有规则**——5 处都是"现有规则内部矛盾/未明文"的修正
2. **没增加新概念**——只澄清"音频双份"和"cp 时机分级"两个**已存在但未明文**的实践
3. **没扩大 scope**——不碰 Remotion 仓库 git 化、6-05 dual-topics 模式、archive 流程

---

## 证据来源（审计素材）

| 来源 | 用途 |
|---|---|
| `20260606_183030_voice-actor-ai-crisis/` | 配音师项目（业务款）|
| `20260606_183030_hongguo-short-drama-cliff/` | 红果短剧项目（引流款）|
| `Remotion-Test/public/audio/*.mp3`（30 个）| 音频双份的实证 |
| `Remotion-Test/src/*.tsx`（19 个 Composition）| 仓库统一根项目的实证 |
| `Remotion-Test/out/*.mp4`（40+ 个）| out/ 脏文件累积的实证 |
| `automedia-project-init` L107-156 + L573-580 | 标准段 + Gotchas |
| `remotion-project-init` L13-23 + L65-75 | 标准 vs 解法矛盾 |
| `remotion-timecode-anti-pattern` L632 | `03_subtitle/` 路径 |
| `remotion-pre-render-gate` L77 | 路径容忍歧义 |
| `automedia-production-guard` L1342 | 路径容忍歧义 |
| `delivery-packaging` L34 | 路径标准（与实际脱节）|
| `remotion-workflow` L49-74 | 5 Gate 链 + 6+1 步 |
| `remotion-delivery-gate`（4 gates）| 交付前门控 |
| `publish-log-schema` v2.1 | publish_log schema |
