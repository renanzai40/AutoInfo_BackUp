# 第五步（历史文档，备用）：确认 pool.db 同步更新

### 第五步（历史文档，备用）：确认 pool.db 同步更新

> **触发：创建新项目目录后，立即检查 pool.db 中对应话题的 status 是否为 `selected`。**
> **根因（2026-05-27 教训）**：Remotion 路径直接启动生产，跳过了 `mark_topic_selected()`，导致 pool.db 中话题仍为 `pending`，后续推送再次出现。

```python
import sqlite3
db = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db"
conn = sqlite3.connect(db)
cur = conn.cursor()

# 读取 project_info.json 中的 topic_id
import json
with open(f"{project_root}/00_project_info/project_info.json") as f:
    info = json.load(f)

topic_id = info.get("topic_id", "")
if topic_id:
    cur.execute("SELECT status FROM topics WHERE topic_id = ?", (topic_id,))
    row = cur.fetchone()
    if row and row[0] != "selected":
        print(f"[⚠️ TOPIC GATE FAIL] {info['topic'][:40]} status={row[0]}, expected='selected'")
        print("立即调用 mark_topic_selected() 修复...")
        cur.execute("UPDATE topics SET status='selected' WHERE topic_id=?", (topic_id,))
        conn.commit()
    else:
        print(f"[OK] topic status={row[0] if row else 'NOT_FOUND'}")
else:
    print("[⚠️] topic_id 为空，旁路话题需先调用 ensure_topic_in_pool()")

conn.close()
```

**孤立项目检查**：`check_orphan_selected_projects()` 函数可扫描所有项目目录，发现"项目已存在但 pool.db 未标记"的情况并告警。
