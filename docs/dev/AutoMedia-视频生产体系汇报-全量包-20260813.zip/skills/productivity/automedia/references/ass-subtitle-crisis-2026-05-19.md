# ASS 字幕危机实录（2026-05-19）

## 项目：豆包预约餐厅（引流款）+ 豆包收费（业务款）

---

## 危机根源：FontSize=55 在 1080×1920 竖屏上失效

| FontSize | 单行最大安全字数 | 最宽 entry 实测 | 结论 |
|---------|--------------|--------------|------|
| 55pt | ≤14字（55×14=770px） | 22字=1375px | ❌ 裁断 |
| 40pt | ≤16字（40×16=640px） | 22字=980px | ❌ 仍有风险 |
| **28pt** | **≤22字（28×22=616px）** | **22字=784px < 920px** | ✅ 通过 |

**920px 安全线 = 1080px - 80px×2（左右边距）**

**根因**：Skill 说"单行≤18字符，55pt下=990px"，但忽略了 WenQuanYi Zen Hei 是等宽字体，实测宽度远超 FontSize×字符数的估算值。55pt 是给 1920×1080 横屏设计的，竖屏必须降 FontSize。

---

## 7轮失败排查过程

### 第1轮：ASS 时间戳格式错误
- **错误**：`H:MM:SS:CC`（冒号分隔）
- **现象**：字幕随机出现，Vision QA 返回 `结果——还真成了！` 等带 `,0,0,,` 残渣
- **根因**：FFmpeg ASS 解析器不认识 `:` 分隔符
- **修复**：改为 `H:MM:SS.CC`（秒.点厘秒）

### 第2轮：`\N` 换行符导致字段边界错乱
- **错误**：用 `\N` 做多行换行
- **现象**：Vision QA 返回 `,0,0,,` 等 ASS Dialogue 字段残渣
- **根因**：FFmpeg ASS 滤镜把 Effect/Text 字段边界搞混
- **修复**：单行不换行，降 FontSize 保证单行全宽可见

### 第3轮：MarginV=0 导致字幕贴底边
- **错误**：MarginV 写在 Dialogue 行 override（无效）
- **现象**：字幕紧贴画面底部，部分文字被裁出画面
- **根因**：MarginV 必须写在 Style 行，Dialogue 行 override 无效
- **修复**：Style 行写 `MarginV=120`

### 第4轮：55pt 超宽裁断
- **错误**：FontSize=55，单行 22 字 entry=1375px
- **现象**：后半段 entries 1/4/5/6 完全消失（被裁到画面外）
- **根因**：FFmpeg ASS 对超宽字幕行直接裁断不显示
- **修复**：降 FontSize 到 28pt

### 第5轮：burn_subtitles.py fps 硬编码
- **错误**：传 `--fps 30`，但脚本第 83 行 `fps=2.0` 硬编码
- **现象**：字幕时间轴提前数秒
- **根因**：脚本内部 fps 不跟随命令行参数
- **修复**：第 83 行改为 `fps = float(args.fps)`，task tuple 第 6 项加 `fps` 字段

### 第6轮：re-encode 回 30fps 导致时间基准变化
- **错误**：burn_subtitles.py 内部 re-encode 回 30fps，时间戳基准变化
- **现象**：字幕与音频时间轴错位
- **修复**：放弃 burn_subtitles.py，改用 FFmpeg 原生 ASS 滤镜（不需要 re-encode）

### 第7轮：像素亮度 QA vs Vision QA
- **错误**：主要依赖 Vision QA
- **现象**：同一帧多次询问返回不同答案，对 ASS 字段残渣敏感，误报率高
- **修复**：像素亮度扫描（底部 200px 高亮像素 > 100 = 有字幕）是更可靠的客观判断

---

## 最终验证方案

### ASS 文件格式（Python 直接拼接）
```python
def build_ass(srt_entries, output_path):
    ass_lines = [
        "[Script Info]",
        "PlayResX: 1080",
        "PlayResY: 1920",
        "ScaledBorderAndShadow: yes",
        "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, Shadow, MarginL, MarginR, MarginV, Alignment",
        "Style: Default,WenQuanYi Zen Hei,28,&H00FFFFFF,&H00000000,2,80,80,120,2",
        "",
        "[Events]",
        "Format: Layer, Start, End, Style, MarginL, MarginR, MarginV, Effect, Text",
    ]
    for entry in srt_entries:
        start = entry["start"]  # float 秒
        end = entry["end"]      # float 秒
        text = entry["text"].replace("\n", " ").replace("\r", "")
        def ts(s):
            h = int(s // 3600)
            m = int((s % 3600) // 60)
            sec = int(s % 60)
            cs = int((s % 1) * 100)
            return f"{h}:{m:02d}:{sec:02d}.{cs:02d}"
        ass_lines.append(f"Dialogue: 0,{ts(start)},{ts(end)},Default,80,80,120,,{text}")
    
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(ass_lines))
```

### FFmpeg 烧录命令
```bash
ffmpeg -y \
  -i video_without_audio.mp4 \
  -i audio.wav \
  -vf "ass=subtitle.ass" \
  -map 0:v:0 -map 1:a:0 \
  -c:v libx264 -preset fast -crf 18 \
  -c:a aac -b:a 192k -shortest \
  video_final.mp4
```

### 像素亮度 QA（推荐）
```python
import subprocess, numpy as np
from PIL import Image

def pixel_brightness_qa(video_path, check_times):
    for t in check_times:
        frame_path = f"/tmp/qa_t{t}.png"
        subprocess.run([
            "ffmpeg", "-y", "-ss", str(t), "-i", video_path,
            "-vframes", "1", "-q:v", "2", frame_path
        ], capture_output=True)
        img = Image.open(frame_path).convert("L")
        arr = np.array(img)
        bottom = arr[int(len(arr)*0.895):, :]  # 底部 ~200px
        bright = np.sum(bottom > 100)
        has_sub = bright > 100
        print(f"t={t}s: {bright} bright px {'✓' if has_sub else '✗'}")
        assert has_sub, f"No subtitle at t={t}s"

pixel_brightness_qa("video_final.mp4", [1.0, 4.0, 7.0, 10.0, 14.0, 18.0, 22.0])
```

---

## burn_subtitles.py 源码修复

**文件**：`/home/renanzai/.hermes/skills/productivity/automedia/scripts/burn_subtitles.py`

**第 83 行修改**：
```python
# 错误（硬编码）：
fps = 2.0

# 正确（动态传入）：
fps = float(args.fps)
```

**task tuple 第 6 项**（在 main() 调用处）加 `fps` 字段：
```python
# 错误：
task = (frame_path, start, end, text, font_size)

# 正确：
task = (frame_path, start, end, text, font_size, fps)
```

---

## 教训总结

1. **FontSize 不是"推荐值"而是"硬约束"**：竖屏 1080×1920 限制了单行最大像素数，超出即裁断，不报错。必须先用 FontSize 计算最大安全字数。
2. **FFmpeg ASS 滤镜有多个未文档化的 bug**：时间戳格式必须用 `.` 不是 `:`；`\N` 换行符有字段边界问题；Layer 多行堆叠有 seek 精度问题。
3. **MarginV/Shadow 必须写在 Style 行**：Dialogue 行 override 这两个字段无效。
4. **像素亮度 QA > Vision QA**：对于"字幕是否存在"这个二分问题，亮度扫描是客观的，不依赖 LLM 判断。
5. **burn_subtitles.py 的 re-encode 路径有架构问题**：re-encode 回 30fps 会改变时间基准，导致字幕时间轴错位。推荐使用 FFmpeg 原生 ASS 滤镜（不需要 re-encode）。
