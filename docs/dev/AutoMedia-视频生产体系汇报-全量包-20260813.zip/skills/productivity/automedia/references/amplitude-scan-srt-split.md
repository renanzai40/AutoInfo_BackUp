# Amplitude Scan for SRT Entry Splitting

## Purpose
Find natural silence breakpoints in TTS audio for splitting long SRT entries (>10s).

## When to Use
- Entry 8/9/10 exceeds 10 seconds
- CTA paragraph has multiple sentences TTS reads as one continuous speech
- Manual estimation of sentence boundaries produces wrong timestamps

## Method

### Step 1: Extract relevant audio section
```bash
export PATH=/home/renanzai/mamba/envs/ffmpeg/bin:$PATH
ffmpeg -y -ss T_START -t T_DUR -i AUDIO.wav \
    -vn -ac 1 -ar 16000 /tmp/section.wav
```

### Step 2: Amplitude scan
```python
import struct, math

with open('/tmp/section.wav', 'rb') as f:
    f.read(44)  # skip WAV header
    data = f.read()

samples = struct.unpack(f'<{len(data)//2}h', data)
window = 1600  # 16kHz × 0.1s = 1600 samples per 0.1s window
THRESHOLD = 200  # RMS below 200 = silence

for i in range(0, len(samples) - window, window):
    window_samples = samples[i:i+window]
    rms = math.sqrt(sum(x*x for x in window_samples) / len(window_samples))
    t = i / window * 0.1
    print(f"t={t:.1f}s (abs={T_START+t:.1f}s): {rms:6.0f} {'←SILENCE' if rms < THRESHOLD else ''}")
```

### Step 3: Identify breakpoints
- Silence gap: 3+ consecutive windows with RMS < 200 (~0.3s+ of silence)
- Breakpoint: gap end time = next entry start time

### Step 4: Adjust SRT timestamps
- Previous entry end = gap start time
- Next entry start = gap end time
- Key rule: end of entry N must exactly equal start of entry N+1

## Trump CTA Case (41-60s, v11)
| Entry | Start | End | Duration | Reason |
|-------|-------|-----|----------|--------|
| 8a | 41.44 | 44.60 | 3.16s | Brand intro (ends at silence) |
| 8b | 45.20 | 54.40 | 9.20s | Brand value (ends at silence) |
| 8c | 54.40 | 59.68 | 5.28s | CTA close |

Gap at 44.6-45.2s (0.6s silence) → 8a→8b split.
Gap at 54.4-55.9s (1.5s silence) → 8b→8c split.

## Notes
- RMS threshold 200: background noise ~40-60 RMS, 200 gives clean separation
- Window 0.1s: balances precision and noise immunity
- Only split on genuine silence gaps (0.3s+), not speed variation within a sentence
