# 强制门控 Pipeline Gotchas（2026-05-19 实测）

## 今日教训（按严重程度）

### P0：Pipeline STOP 级（Gate 失败 = 视频报废）

| 问题 | 根因 | 解法 |
|------|------|------|
| 业务款脚本方向走偏（"AI涨价潮"→投资分析） | brand-cta-review Gate 3 被跳过 | Gate3 未通过前禁止调用 TTS |
| 引流款 65s 视频白做（图片是 16:9 横屏） | 生成图片时未检查 aspect_ratio=9:16 | 图片生成前检查 prompt 必须含 aspect_ratio="9:16" |
| 引流款视频末尾 20s 无音频（65s 视频音频只有 45s） | concat demuxer 输出时长 > 音频时长，-shortest 失效 | 强制 trim 到音频精确时长（不用 -shortest） |
| 业务款 65s 视频末尾 20s 无字幕（字幕 entry 超宽被裁出画面） | 55pt CJK 下 18 字 = 990px > 1080px 安全值 | 降 FontSize 到 28pt，实测最宽 784px |
| 业务款 65s 视频 CTA 方向与品牌不符（无品牌身份/功能描述） | brand-cta-review 未审核脚本 | Gate3 Brand CTA 强制审查 5 平台 CTA |
| QA 文件 A，发送文件 B（用户看到的就是有问题的版本） | 无 MD5 追踪机制 | pipeline_md5.json 全程记录，Gate5 验证 MD5 一致 |

### P1：需立即修复（不报废但影响质量）

| 问题 | 根因 | 解法 |
|------|------|------|
| ASS 字幕格式字段泄露（`,0,0,0,` 成为可见文字） | FFmpeg ASS 滤镜对 concat 图片序列视频有叠加 bug | PIL 逐帧烧录，不用 FFmpeg ASS 滤镜 |
| burn_subtitles.py 输出 52-53s（音频只有 30s） | h264 编码器默认 25fps，60 帧被拉长到 52s | patch：re-encode 加 `-r fps -frames:v N` |
| 多行 Layer 叠加方案（Alignment=5）FFmpeg 不支持 | FFmpeg ASS 滤镜对同时间戳多 Dialogue 不支持 | 改为单行字幕 |
| Whisper 对中文品牌名"壹目贯维"识别误差（"一目惯为"） | 音色识别近音字误差，非音频问题 | 音频本身正确，用 MiniMax 脚本原文作 SRT 文本 |

---

## MD5 追踪机制（Gate5 Pre-send 核心）

**问题**：Vision QA 检查了文件 A，但发送了文件 B，用户看到的就是有问题的版本。

**解法**：每个 Gate 完成后记录产物 MD5 到 `{project_dir}/pipeline_md5.json`。

```python
import json, hashlib, os
MD5_LOG = "pipeline_md5.json"

def record_md5(project_dir, file_path, label):
    md5 = hashlib.md5(open(file_path,"rb").read()).hexdigest()
    path = os.path.join(project_dir, MD5_LOG)
    log = json.load(open(path)) if os.path.exists(path) else {}
    log[file_path] = {"md5": md5, "label": label}
    json.dump(log, open(path,"w"), ensure_ascii=False)

def verify_md5(project_dir, file_path):
    log = json.load(open(os.path.join(project_dir, MD5_LOG)))
    expected = log[file_path]["md5"]
    actual = hashlib.md5(open(file_path,"rb").read()).hexdigest()
    if actual != expected:
        raise Exception(f"MD5 MISMATCH: 文件在 QA 后被替换！不得发送。")
```

---

## Vision QA Gate 完整流程

```
burn_subtitles.py 完成
    ↓
batch_vision_qa(video_path, audio_dur)
  → extract_frame() × 3（t=1s / 中段 / 末尾前5s）
  → 写 /tmp/vqa_frames.json（帧路径+质检prompt）
    ↓
主agent 读取 /tmp/vqa_frames.json
  → mcp_minimax_understand_image 逐帧判断
  → write_vision_results([{"t": 1.0, "pass": True/False, "reason": "..."}, ...])
    ↓
wait_for_vision_results(timeout=300)
  → 读 /tmp/vqa_results.json
  → 全部 PASS → Gate4 通过
  → 任意 FAIL → Pipeline STOP
```

**三帧不够**：65s 视频前 45s 正常，末尾 20s 才断尾，但三帧（1s/中段/末尾前5s）全部 PASS。**Gate4 Vision QA 应改为逐 entry 验证时长覆盖**。

---

## 字幕参数与 9:16 CJK 渲染对照表

| FontSize | 每行安全字数（实测） | 18字像素宽 | 是否安全 |
|---------|---------------------|-----------|---------|
| 72pt | ≤12 字 | ~1188px | ❌ 超 1080px |
| 55pt | ≤16 字 | ~990px | ❌ 超 920px 留边 |
| 40pt | ≤20 字 | ~720px | ✅ 安全 |
| 28pt | ≤26 字 | ~784px | ✅ 安全 |

**Skill 标准 55pt 在 9:16 竖屏场景下不可达**。建议降至 32-40pt。

---

## burn_subtitles.py 已知坑（永久）

| 坑 | 根因 | 修复 |
|----|------|------|
| re-encode 输出 52-53s（音频 30s） | h264 编码器默认 25fps，-shortest 失效 | 加 `-r fps -frames:v N` |
| extract_frame 边界失败（视频末尾附近 seek 返回空帧） | safe_upper 超出实际时长 | 加 safe_seek_ts() 边界检查 |
| get_dur() 用 FFMPEG 变量指向 ffprobe | 返回 None | 显式调用 ffprobe |
| textbbox 陷阱（y1=baseline+descent 不是高度） | PIL textbbox 文档误导 | 高度 = y1 - y0 |

---

## FFmpeg concat demuxer Gotcha（2026-05-19 实测）

**症状**：concat demuxer + `duration` directives 生成 32s 视频，但音频只有 29.86s。用 `-shortest` 合并后输出 30.08s，多了 0.22s 画面（残余业务内容）。

**解法**：TS 分段法：
```bash
for i in $(seq 1 9); do
  ffmpeg -y -loop 1 -i "img_${i}.jpg" -t ${seg_dur} \
    -vf "scale=1080:1920" -r 2 -c:v libx264 -preset fast -pix_fmt yuv420p "seg_${i}.ts"
done
cat seg_*.ts > /tmp/all.ts
ffmpeg -y -i /tmp/all.ts -c copy video_raw.mp4
ffmpeg -y -i video_raw.mp4 -i audio.wav \
  -map 0:v -map 1:a -t 29.86 -c:v copy -c:a copy video_trimmed.mp4
```

---

## brand-cta-review Gate 零容忍项

**触发**：CTA 写作完成后、TTS 前。任一存在 = Pipeline STOP。

1. 品牌身份未锚定（末段无"壹目贯维，AI内容生产公司"）
2. 功能描述缺失（未说清热点追踪/文案生成/多平台发布）
3. 过渡不同向（如"AI涨价潮"→投资分析，不是内容生产）
4. 禁止词出现（"专注AI赋能"/"投资情报"/"金融分析"）
5. 品牌名近音字错误（"壹目惯为"/"一目贯为"等 Whisper 误判）
6. 视频+文章 CTA 方向不同步
