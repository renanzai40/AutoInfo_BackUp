# Hook 集成规范（2026-05-16）

## 场景
Skill A 的某个触发节点需要强制调用 Skill B 的检查逻辑，不能靠"建议"或"记得加载"，必须有代码级 enforcement。

## 两种集成模式

### 模式1：Skills 依赖表（知识层强制）

在 Skill A 的 SKILL.md 的 `## Skills依赖` 表格里，把 Skill B 列为强制，并标注 **Hard Gate**：

```markdown
| `wechat-upload-checklist` | **微信公众号上传安全检查（Hard Gate）** | 上传草稿前 |
```

**效果**：agent 每次走到这个节点，瞄一眼表格就知道必须加载 B。

**适用**：Skill B 是独立的检查清单（不返回数据给 A），只要"加载并执行"即可。

### 模式2：Hook 代码块（执行层强制）

在 Skill A 的触发节点下面，直接写 Python 代码调用 Skill B 的函数：

```python
# Step X — 某操作前
import sys
sys.path.insert(0, '/path/to/skill-b')
from skill_b import mandatory_check_function

mandatory_check_function(arg1, arg2)  # 失败抛 Exception
```

**效果**：跳过 Skill B = 代码报错，不是"忘了加载"。

**适用**：Skill B 有可调用的 Python 函数，调用结果可以决定是否继续。

## 今日案例：wechat-publisher

**问题**：微信公众号上传必须调用 `wechat-upload-checklist`，但 agent 经常跳步直接写内联 requests。

**解法**：在 `wechat-publisher` SKILL.md 里加 Hook 代码块：

```markdown
### ⚠️ 微信公众号上传强制检查

**触发条件**：任何涉及微信公众号的操作（保存 wechat.md、生成 wechat.html、上传草稿、发布）**之前**，必须加载 `wechat-upload-checklist` 并完成 7 步检查清单。

> ⚠️ 微信公众号 API 非幂等，脏内容上传 = 制造垃圾草稿，无法撤销。每次上传都是一次不可逆操作，必须预检通过才能执行。
```

同时在 `automedia` SKILL.md 的 Skills 依赖表里加一行：

```markdown
| `wechat-upload-checklist` | **微信公众号上传安全检查（Hard Gate）** | 上传草稿前 |
```

## Hook 函数设计原则

Hook 函数必须满足：

1. **抛出异常，不返回 False**：检测失败时 `raise Exception("CHECK FAILED: ...")`，不是 `return False`
2. **有明确成功路径**：成功后不写日志，直接继续
3. **错误信息包含具体缺失项**：不是"检查失败"，而是"缺失文件：01_content/drafts/wechat/wechat_draft.html"
4. **不接受"跳过"参数**：Hook 是 Hard Gate，不能被绕过

## 已有 Hook 库

| Hook 文件 | 触发时机 | 验证内容 |
|---------|---------|---------|
| `hooks/pre_send_whisper_check.py` | 打包发送前 | 视频内容含项目关键词 + MD5 追踪 |
| `hooks/auto_vision_qa.py` | 字幕烧录后 | 三帧检查：字幕位置/行数/内容 |
| `hooks/brand_name_killer.py` | CTA 写作后/TTS 前 | 品牌名正确/无变形/无禁止词/视频+文章同步 |
| `delivery-packaging/package_project` | 打包发送前 | 文件存在性/内容字数/平台完整性 |

所有 Hook 在 `productivity/automedia/hooks/` 目录下。调用方式：

```python
import sys
sys.path.insert(0, '/home/renanzai/.hermes/skills/productivity/automedia/hooks')
from auto_vision_qa import batch_vision_qa

batch_vision_qa(video_path="/tmp/video_final.mp4", audio_duration=54.86)
```