# Pool.db Topic Source-of-Truth 工作流

**触发场景**：agent 收到业务款/引流款话题，准备启动 AutoMedia 生产线之前。

## 核心铁律

> **pool.db 的 `source_url` 字段是话题的 source-of-truth**。**web_extract(source_url) 验证后**才能判定话题"真假"。

## 完整流程

### Step 1：查 pool.db

```python
import sqlite3
db = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db"
conn = sqlite3.connect(db)
cur = conn.cursor()

# topic_id 实际是 32 字符 hex 字符串，不是 12 字符 prefix
cur.execute("SELECT topic_id, title, source_url, source, review_status FROM topics WHERE topic_id=?", (topic_id,))
row = cur.fetchone()
# 注意：WHERE topic_id=? 用 12 字符 prefix 截断会 silent fail（0 rows）
```

### Step 2：用 source_url 验证（不搜中文网页）

```python
from web_extract import web_extract
content = web_extract([source_url])  # 提取 source_url 内容
# 验证话题标题里的事实点是否能在 content 里找到
```

### Step 3：判定真假

| 情况 | 动作 |
|------|------|
| source_url 内容支持话题 | ✅ 话题真实，启动生产 |
| source_url 内容与话题矛盾 | ❌ 标 topic_factually_wrong，告知用户 + 建议换话题 |
| source_url 内容不充分 | ⚠️ 标 topic_needs_more_verification，找更多源 |
| 搜不到中文 ≠ 假 | 继续推进（X/英文/海外源中文搜不到）|

## 2026-06-03 事故复盘（Runway Aleph 2.0）

| 步骤 | 行为 | 结果 |
|------|------|------|
| 1 | 收到话题 "Runway API 推出 Aleph 2.0 视频编辑功能" | - |
| 2 | 搜中文 web（CSDN/腾讯云/QQ News）| 搜到 Aleph v1，**没搜到 2.0** |
| 3 | **错误判断**："Aleph 2.0 不存在" | ❌ |
| 4 | 用户提示"这条话题是话题池中来的" | 转向查 pool.db |
| 5 | pool.db 查到 `source_url: https://x.com/runwayml/status/2061895998545244342` | - |
| 6 | web_extract 该 X 推文 | **@runwayml 2026-06-02 19:41 GMT 真发了** |
| 7 | 修正判断，启动生产 | ✅ |

## 错过的"自检机会"

我应该做的 Step 0：
- 任何话题进入生产前，先 SELECT pool.db 拿 source_url
- web_extract 验证 source_url
- 这两个步骤加起来 ~10s，但能避免 30 min 的误判来回

## topic_id 字段大小写 + 长度陷阱

- `topic_id` 是 **32 字符 hex**（不是 12 字符 prefix）
- 12 字符 prefix 截断查询会 **silent fail（0 rows）**，不报错
- WHERE 条件必须用完整 32 字符

```python
# ❌ 错
cur.execute("SELECT ... WHERE topic_id=?", ("a18ac3e30f1c",))  # silent fail

# ✅ 对
cur.execute("SELECT ... WHERE topic_id=?", ("a18ac3e30f1cf22e85181ab6b835c53d",))  # match
```

## 关联 skills

- `automedia` 主 skill（业务款/引流款 production workflow 入口）
- `tavily-business-topics`（pool 采集来源）
- `automedia-topic-pool`（pool.db schema 详解）
