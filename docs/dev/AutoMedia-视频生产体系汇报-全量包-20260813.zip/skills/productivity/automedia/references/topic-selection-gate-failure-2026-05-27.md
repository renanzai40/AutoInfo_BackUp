# Topic Selection Gate 失效分析（2026-05-27）

## 事件

2026-05-26 用户选中两个话题：
- DeepSeek将对其旗舰AI模型实施永久性75%折扣
- Lorai - AI驱动的智能营销内容生成工具

启动生产后，两个话题在 pool.db 中仍保持 `status='pending'`，未被标记为 `selected`。
次日（05-27）话题池再次推送时，两个话题仍然出现。

## 根因

话题通过 Remotion 项目直接启动，跳过了 AutoMedia 标准链路。

**AutoMedia 标准链路**（话题确认后的第一步）：
```
用户确认话题
    ↓
mark_topic_selected()   ← pool.db status: pending → selected
    ↓
ensure_topic_in_pool()（旁路话题用）
    ↓
元数据展开
```

**实际路径**（Remotion 直接启动）：
```
用户确认话题 → Remotion 项目启动 → 生产
    ↓
mark_topic_selected() 从未被调用
```

## 教训

1. **任何非标准链路启动生产时，必须先调用 `mark_topic_selected()` 更新 pool.db**
2. **旁路话题（不在 pool 里）：必须先 `ensure_topic_in_pool()` 入库再标记 selected**
3. **生产完成后：同步归档 pool.db（selected → archived）**

## 修复操作（已完成）

```python
# 归档两个话题
UPDATE topics SET status='archived'
WHERE topic_id IN (
    'e6b645526ee751228528679af85b00de',  # DeepSeek
    '81d19106f7557ce6ea068068d6583bd0'   # Lorai
);
```

## 预防机制

在 `topic_deduplication.py` 中新增 `check_orphan_selected_projects()` 函数，
定期扫描 projects 目录，对比 `00_project_info.json` 中的 topic_id 与 pool.db 状态，
发现"项目已存在但 pool.db 未标记"时主动告警。

## 相关函数

| 函数 | 作用 |
|------|------|
| `mark_topic_selected()` | 将 topic 标记为 selected |
| `ensure_topic_in_pool()` | 旁路话题入库并标记 selected |
| `mark_cluster_duplicates_from_pool()` | Pool 级聚类去重扫描 |
| `check_orphan_selected_projects()` | 新增：扫描孤立已选项目 |
