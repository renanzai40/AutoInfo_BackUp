# TTS 音频幅度分析 — 字幕时间戳验证（2026-05-13）

## 问题

SRT 时间戳来自 MiniMax post-processed 文本分配，与 TTS 音频实际朗读节奏不符。

**典型症状**：
- Entry 文本包含两句话"TEXT1 TEXT2"，但 TTS 朗读时中间有 0.5-1.0s 停顿
- 字幕显示"TEXT1 TEXT2"的时间段里，音频只读了 TEXT1
- 下一句话开始时字幕切早了/晚了

**实测案例（harness TTS）**：
```
TTS 0.25-2.35s: SPEECH — "你知道AI最大的问题是什么吗？"
TTS 2.35-3.20s: SILENCE — gap ~0.85s
TTS 3.20s+: SPEECH — "不是能力不够，是不听话。"
```
但 SRT Entry 1 把两句话合并成 0.00-2.52s，Entry 2 从 2.92s 开始。

---

## 验证脚本

```python
#!/usr/bin/env python3
"""tts_audio_probe.py — 验证 SRT 时间戳与 TTS 音频实际节奏是否匹配"""
import subprocess, numpy as np, sys, re

def parse_srt_timestamps(path):
    with open(path) as f:
        blocks = f.read().strip().split('\n\n')
    entries = []
    for block in blocks:
        lines = block.strip().split('\n')
        if len(lines) >= 3:
            m = re.match(r'(\d{2}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2}),(\d{3})', lines[1])
            if m:
                s = int(m.group(1))*3600 + int(m.group(2))*60 + int(m.group(3)) + int(m.group(4))/1000
                e = int(m.group(5))*3600 + int(m.group(6))*60 + int(m.group(7)) + int(m.group(8))/1000
                entries.append({'start': s, 'end': e, 'text': '\n'.join(lines[2:])})
    return entries

def analyze_audio(audio_path, threshold=250):
    """每 50ms 扫描，返回 SPEECH/SILENCE 转换点"""
    result = subprocess.run([
        'ffmpeg', '-y', '-i', audio_path,
        '-ac', '1', '-ar', '16000', '-f', 's16le', '-'
    ], capture_output=True)
    samples = np.frombuffer(result.stdout, dtype=np.int16)
    transitions = []
    prev = False
    for i in range(0, len(samples), 800):
        t = i / 16000
        seg = samples[i:i+800]
        rms = np.sqrt(np.mean(seg.astype(float)**2))
        is_active = rms > threshold
        if is_active != prev:
            transitions.append((round(t, 2), 'SPEECH' if is_active else 'SILENCE'))
            prev = is_active
    return transitions

def validate_srt_vs_audio(srt_path, audio_path):
    entries = parse_srt_timestamps(srt_path)
    trans = analyze_audio(audio_path)
    
    # 合并相邻同类型段
    speech_segs = []
    i = 0
    while i < len(trans):
        t, state = trans[i]
        if i + 1 < len(trans) and trans[i+1][1] == state:
            i += 1
            continue
        # 找结束
        for j in range(i, len(trans)):
            if j == len(trans)-1 or trans[j+1][1] != state:
                end_t = trans[j][0]
                if state == 'SPEECH':
                    speech_segs.append((t, end_t))
                i = j + 1
                break
    
    print(f"SRT entries: {len(entries)}")
    print(f"Actual SPEECH segments: {len(speech_segs)}")
    print()
    print("Entry | SRT Range | Speech-in-Entry | Status | Text")
    for i, e in enumerate(entries):
        in_speech = sum(max(0, min(e['end'], se[1]) - max(e['start'], se[0])) 
                        for se in speech_segs)
        entry_dur = e['end'] - e['start']
        ratio = in_speech / entry_dur if entry_dur > 0 else 0
        status = "OK" if ratio > 0.85 else ("GAP" if ratio < 0.5 else "WARN")
        print(f"[{i+1:02d}] {e['start']:.2f}-{e['end']:.2f} | speech={in_speech:.2f}s/{entry_dur:.2f}s | {status} | {e['text'][:40]}")

if __name__ == '__main__':
    srt_path = sys.argv[1]  # e.g. /tmp/harness_subtitle.srt
    audio_path = sys.argv[2]  # e.g. /tmp/harness_voiceover.mp3
    validate_srt_vs_audio(srt_path, audio_path)
```

**用法**：
```bash
python3 tts_audio_probe.py /tmp/harness_subtitle.srt /tmp/harness_voiceover.mp3
```

---

## 修复策略

### 当 SRT Entry 跨越静音 gap

```
原 SRT Entry:  0.00-2.52s | "你知道AI最大的问题是什么吗？不是能力不够——是不听话。"
     实际语音: [0.25-2.35 SPEECH] [2.35-3.20 SILENCE] [3.20+ SPEECH]
                          ^ gap 0.85s
修正后:
  Entry 1: 0.00-2.68s | "你知道AI最大的问题是什么吗？"  ← 只含第一句
  Gap:    2.68-3.00s | (无字幕)
  Entry 2: 3.00-5.68s | "不是能力不够，是不听话。"      ← 第二句独立
```

### concat 时长计算

```python
TTS_END = 52.668  # ffprobe -show_entries format=duration
for i, entry in enumerate(entries):
    if i < len(entries) - 1:
        dur = entries[i+1]['start'] - entry['start']  # start-to-next-start（正确）
    else:
        dur = TTS_END - entry['start']
    # 注意：不要用 entry['end'] - entry['start'] + gap
    # gap 已经在 next_start - this_start 中自然包含
    # 帧提取时间 = entry['start']
    # 帧烧录文本 = entry['text']
```

**⚠️ 常见错误**（rebuild_deepseek2.py 犯过）：
```python
# 错误：gap = entries[i+1]['start'] - entries[i]['end']
# 错误：dur = entry['dur'] + gap   ← 重复计算了 entry 时长
# 正确：
dur = entries[i+1]['start'] - entries[i]['start']   # = entry['dur'] + gap
```

### 关键检查点

每个 SRT Entry 都要验证：
1. Entry 的 `text` 对应音频在 `[start, end]` 区间内是否有多个 SPEECH 段？
2. 如果有内部 gap（>0.3s 静音），必须插入空白 Entry 分割
3. 合并后 concat 段总时长 = TTS_END（52.668s）

---

## 完整修正案例：harness SRT（v8 定稿）

**错误根源**：TTS SRT Entry 以逗号结尾 = 未完成的分句，不代表音频读完了。

**v8 之前所有版本（v4-v7）犯的同一个错**：Entry 7 "比如，你让它写文案，不是随便写，" 以逗号结尾，但整个 Entry 跨越 3 个独立语音段 [18.9→19.4] [19.6→20.5] [20.9→21.7]。所有版本都把它当成一个条目处理，导致字幕在 3 个不同时刻显示相同文本。

### 核心原则：以逗号/顿号分句，按 Whisper 时间戳分配

```
TTS SRT 文本: "比如，你让它写文案，不是随便写，"
               ↑分句1         ↑分句2         ↑未完成

Whisper 语音段: [18.9→19.4] [19.6→20.5] [20.9→21.7]
                 ↓分句1       ↓分句2       ↓分句3（这里才是"不是随便写"读完）

结果（v8）：
  Entry 8:  [18.9→19.4]  "比如，你让它写文案，不是随便写，"
  Entry 9:  [19.4→19.6]  （静音间隙，无字幕）
  Entry 10: [19.6→20.5]  "你让它写文案，"
  Entry 11: [20.5→20.9]  （静音间隙，无字幕）
  Entry 12: [20.9→22.0]  "不是随便写，"
```

### 最终正确的 harness_subtitle_v8.srt（17 条 + 静音间隙条目）

```srt
1  00:00:00.000 → 00:00:02.800 | 你知道AI最大的问题是什么吗？
2  00:00:02.800 → 00:00:05.600 | 不是能力不够，是不听话。
3  00:00:05.600 → 00:00:09.000 | 我是壹目贯维，今天聊一个新概念。
4  00:00:09.500 → 00:00:10.600 | Harness Engineering 翻译过来叫
5  00:00:10.600 → 00:00:11.200 | （静音间隙，无字幕）
6  00:00:11.200 → 00:00:13.600 | 驾驭工程。
7  00:00:13.600 → 00:00:18.400 | 说白了，就是给AI套上缰绳，让它按你的方向跑。
8  00:00:18.900 → 00:00:19.400 | 比如，你让它写文案，不是随便写，
9  00:00:19.400 → 00:00:19.600 | （静音间隙）
10 00:00:19.600 → 00:00:20.500 | 你让它写文案，
11 00:00:20.500 → 00:00:20.900 | （静音间隙）
12 00:00:20.900 → 00:00:22.000 | 不是随便写，
13 00:00:22.000 → 00:00:25.800 | 而是严格按照你的品牌调性，用户画像来产出。
14 00:00:26.300 → 00:00:28.200 | 我们壹目贯维在做的一件事，
15 00:00:28.200 → 00:00:28.600 | （静音间隙）
16 00:00:28.600 → 00:00:32.800 | 就是让AI在你掌控下高效产出。
17 00:00:32.800 → 00:00:38.200 | 热点自动追踪，文案一键生成，多平台智能发布。
18 00:00:38.200 → 00:00:41.800 | 不是替代你，是让你真正掌控AI。
19 00:00:41.800 → 00:00:47.400 | 如果你也在用AI做内容，遇到跑偏问题，评论区说说经历。
20 00:00:47.400 → 00:00:52.600 | 我是壹目贯维，关注我，一起探索AI内容生产的正确姿势。
```

**v6 错误版本特征**（不要重蹈）：
- Entry 6/7 文本完全相同（" Harness Engineering翻译过来叫驾驭工程"）
- Entry 7 跨 [13.6→18.4] 共 4.8s 但文本只在开头读完
- Entry 8/9/10 文本重复（"比如，你让它..."），没有静音间隙条目

**v8 正确原则**：
1. TTS SRT 以 `，`、`、`—` 结尾的 Entry = **未完成分句**，必须按标点拆分
2. Whisper on TTS 音频时间戳是**唯一权威**
3. 静音间隙（>0.3s）→ 插入空文本条目，concat 时长保留间隙
4. 每条字幕的 concat 时长 = `next_entry.start - this_entry.start`

---

## 完整修正案例：DeepSeek（50.4s）

**问题类型**：Entry 1 文本跨 3 句话，amplitude scan 找不到 <0.1s 的静音（micro-pause）。

**症状**：Entry 1 文本 = "DeepSeek融资450亿美元，很多人只看到数字——但这跟你有什么关系？"，TTS 实际在读三句话（Entry 1/2/3 对应三句）。amplitude scan 只找到 3 个独立语音段但无法判断边界。

**关键洞察**：SRT Entry 边界 = TTS **生成单元**的边界，不等于 acoustic silence 边界。

TTS 相邻句之间即使没有可闻停顿（<0.1s），TTS 也会把它们当作独立 Generation Entry 处理。这是 TTS 的内部机制，amplitude scan 看不见，但 SRT Entry 边界真实记录了这个边界。

**验证方法**：找到已被用户确认过的那个 Entry，用它的内容反推前一个 Entry 应该只含什么。

```
Entry 2 = "很多人只看到数字。"（用户确认 = TTS 在读第二句）
→ Entry 1 文本 = "DeepSeek融资450亿美元，很多人只看到数字——但这跟你有什么关系？"
→ Entry 1 应该 = "DeepSeek融资450亿美元。"（只含第一句）
```

**修正方案 A（v5b）**：按幅度拆成 3 个独立 Entry。时间轴 = [0→0.7] [0.7→2.8] [2.8→5.0]。结果：整体同步性变差。

**修正方案 B（v5c）**：只改 Entry 1 的**文本**，时间轴和 concat 框架完全不动。时间轴 = [0→2.8]（Entry 1）[2.8→4.8]（Entry 2）[4.8→6.8]（Entry 3）。结果：整体同步性保持，Entry 1 文本正确。

**结论**：
- **保持已有的 concat 框架稳定**：不要为了"更精确"而增加 Entry 数量。20 个稳定 concat 的 Entry 远好于 22 个新增切点的 Entry。
- **只改文本，时间轴不动**：对于文本跨多句的 Entry，直接缩短文本即可，不需要拆分时间轴。
- **TTS 生成单元的边界在 SRT 里，不需要 amplitude scan 来找**。

---

**⚠️ 今日教训（2026-05-13）**

1. **SRT Entry 边界 = TTS 生成顺序，不等于 acoustic silence 边界**
   - amplitude scan 找的是 >0.3s 的显著静音，<0.1s 的 micro-pause 完全检测不到
   - 但 micro-pause 依然让 TTS 把相邻句当作独立 Generation Entry 处理
   - 验证：找用户确认过的 Entry → 反推前一个 Entry 的正确文本

2. **修正多句 Entry 时，优先"只改文本"而非"拆分时间轴"**
   - harness 问题：Entry 跨多个语音段 + 静音间隙 → 必须拆分时间轴 + 插入静音条目
   - DeepSeek 问题：Entry 跨多句话但无显著静音 → 只改文本内容，时间轴不动
   - 原因：拆分 = 新增 concat 切点 = 新增 timing 漂移风险

3. **最小改动原则的真正含义**
   - 不是"只改那一条的文本"——而是"只改那一条的文本，时间轴和 concat 框架完全不动"
   - v5c = 只改 Entry 1 文本（其他 19 条原样）→ 同步性保持
   - v5b = 改 Entry 1 文本 + 拆出 2 个新 Entry + 重新分配所有后续时间轴 → 整体变差

4. **烧录必须用原始无字幕视频**
   - deepseek_video_final.mp4（无字幕）→ 可以叠加新字幕
   - deepseek_final_v4.mp4（已有字幕）→ 叠加后产生双重字幕，无法消除

5. **FFmpeg concat demuxer 对 JPG + duration 不稳定**
   - 用 concat filter：`[0:v][1:v]...[N:v]concat=n=N+1:v=1:a=0[outv]`
   - concat filter 输出视频时长准确（50.4s），demuxer 输出被截断到 35s

---

详见：`references/deepseek-subtitle-correction.md`（如有）
