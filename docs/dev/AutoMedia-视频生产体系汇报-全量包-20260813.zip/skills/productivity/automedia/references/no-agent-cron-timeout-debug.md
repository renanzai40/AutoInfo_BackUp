# no_agent Cron 超时排查指南

## 现象

收到 `⚠️ Cron 'AutoMedia 08:00 热点采集' failed: provider timeout. Fallback chain was exhausted` 报错，但实际脚本成功完成（`last_status=ok`，output 有 `✅ 采集入库完成`）。

## 根因：错误分类误导

`cron/scheduler.py` 中的 `_summarize_cron_failure_for_delivery()` 函数对所有含 `"timeout"` 关键字的 error 字符串统一归为 "provider timeout"：

```python
if "readtimeout" in lower or "timed out" in lower or "timeout" in lower:
    return f"⚠️ Cron '{job_name}' failed: provider timeout. ..."
```

**但 no_agent 脚本类 job 不走 LLM provider**。这里的 "provider timeout" 实际上是：

- **`subprocess.TimeoutExpired`** — 脚本整体被 cron scheduler 的 `subprocess.run(timeout=N)` kill
- **或脚本内部某 API 调用超时**（catch 到 `Exception` 后 continue，但总时间超了脚本级超时）

## 超时链（三层）

| 层级 | 超时值 | 机制 | 触发条件 |
|------|--------|------|---------|
| 脚本外部（cron level） | **900s** (`HERMES_CRON_SCRIPT_TIMEOUT`) | `subprocess.run(timeout=900)` | 脚本整体执行超过 15 分钟 |
| LLM API 调用（per call） | **180s** | `subprocess.run(timeout=180)` | DeepSeek-v4-flash 响应慢 / 排队 |
| curl （per request） | **150s** | `curl --max-time 150` | opencode-go API 无响应 |

当数据量大时（流 2 Tavily 结果 100+ 条），LLM 调用拆成多批（每批 10 条），180s × N 批的总和可能超过 900s 脚本级超时。

## 诊断步骤

### 1. 确认脚本是否真的超时了

查 cron output 目录：

```bash
ls -la ~/.hermes/profiles/content/cron/output/143d19e69a7c/
```

- 当日 output **有 status line** `**Status:** script failed` → 脚本被 cron kill
- 当日 output **无 status line** + `✅ 采集入库完成` → 脚本成功完成，报错可能来自：
  - 延迟的 Feishu 通知（前次失败被 retry 恢复后的遗留投递）
  - LLM-driven 的下游 job（08:05/08:10/08:30）的失败

### 2. 区分「真是 provider 挂了」vs 「脚本跑太慢」

```bash
# 查 provider 是否在线
curl -s -o /dev/null -w "%{http_code} %{time_total}s" https://opencode.ai/zen/go/v1/models

# 查近期 provider 延迟（看 script output 中 LLM 调用的「完成/失败」比例）
grep -E "LLM去重|Layer2" ~/.hermes/profiles/content/cron/output/143d19e69a7c/$(date +%Y-%m-%d)*.md
```

如果 provider 返回正常（200 + <2s），但 output 中大量 `⚠️ LLM去重解析失败 (content空/无JSON)` → 说明 opencode-go API 返回空响应（partial 超时），不是完全不可用。

### 3. 检查脚本内部异常

output 中搜索：

| 信号 | 含义 |
|------|------|
| `⚠️ LLM去重解析失败` | DeepSeek-v4-flash 返回空 content（可能是推理超时 180s） |
| `Layer2 解析失败，保留全部` | 同，API 返回非标准响应 |
| `curl失败: Expecting value` | opencode-go / uapis.cn 返回非 JSON（503 / 网关超时） |
| `LLM SEO过滤异常` | subprocess 超时或 curl 被 kill |

### 4. 关注 data volume 与超时的关联

```bash
for f in ~/.hermes/profiles/content/cron/output/143d19e69a7c/*.md; do
  total=$(grep -oP '总话题: \K\d+' "$f" 2>/dev/null)
  biz=$(grep -oP 'business:\K\d+' "$f" 2>/dev/null)
  t=$(stat -c '%y' "$f" | cut -d. -f1)
  [ -n "$total" ] && echo "$t total=$total biz=$biz"
done
```

横向对比：同是成功跑完的日子，total 越高说明数据量越大，LLM 调用批数越多。如果超时日子 total > 1000（或流 2 去重前 > 100），就是数据量超了脚本的承受能力。

## 修复手段

### 短期：加超时窗口

```bash
# .env 中加大
HERMES_CRON_SCRIPT_TIMEOUT=1800  # 30 分钟
```

### 中期：降低数据量

- 减少 Tavily 搜索关键词（当前 16 组，实测可以砍到 12-14）
- 降低流 1 热搜每条源的取顶数（当前每源 15 条 → 10 条）
- LLM dedup 的 batch 已减到 10，不动

### 长期：降脚本内部 LLM 调用延迟

- 考虑把 LLM 调用的 subprocess timeout 从 180s 降到 120s（180s × 10 批 = 30 分钟，已经超了 15 分钟窗口）
- 或增加一层「累计时间预算」检查：如果已跑 > 800s，跳过剩余 LLM 步骤改用 hash-only 去重

## 2026-07-03/04 案例

**07-03**: 首跑超时 900s，output 显示 `⚠️ LLM去重批处理: 118条拆为 12 批` + 多次 `LLM去重解析失败`。Watchdog 09:36 检测到失败后 auto-retry（PID 329469），重跑成功（10:04 完成）。job status 从 error → ok。

**07-04**: 脚本 10 分钟完成（流 2 仅 59 条拆 6 批），output 正常。但用户仍收到 "provider timeout" 报错——可能为前次（07-03 首跑）的延迟投递或 cron 系统级误报。

## 关联文件

- `cron/scheduler.py` — `_summarize_cron_failure_for_delivery()` 第 49-78 行，error 分类逻辑
- `cron/scheduler.py` — `_run_job_script()` 第 960-1079 行，脚本执行+超时机制
- `scripts/auto_media_hot_collection_v3_20260525.py` — 脚本本身的 LLM 调用超时（第 372-380 行）
- `.env` — `HERMES_CRON_SCRIPT_TIMEOUT=900` 配置
