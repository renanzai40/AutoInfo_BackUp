# AIHOT REST API — 接入 AutoMedia 话题池（2026-05-25）

## API 基本信息

| 属性 | 值 |
|------|------|
| 认证 | 无需 token，匿名免费 |
| Base URL | `https://aihot.virxact.com` |
| 必需 Header | `User-Agent`（默认 curl UA 会 403） |
| 速率限制 | 600 次/分钟/IP |
| 回溯上限 | 7 天 |
| OpenAPI | `https://aihot.virxact.com/openapi.yaml` |

## 端点

### `GET /api/public/items` — 主要接口

参数：

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `mode` | `"selected"` \| `"all"` | `"selected"` | selected=精选，all=全部 |
| `category` | 枚举 | 无 | `ai-models` / `ai-products` / `industry` / `paper` / `tip` |
| `since` | ISO datetime | now-7d | 早于7天自动截断 |
| `take` | integer 1-100 | 50 | 每页条数 |
| `cursor` | opaque string | 无 | 分页 token |
| `q` | string | 无 | 关键词搜索（2-200 chars） |

返回字段：`id / title / title_en / url / source / publishedAt / summary / category`

### 其他端点

- `GET /api/public/daily` — 最新日报
- `GET /api/public/daily/{YYYY-MM-DD}` — 指定日期日报
- `GET /api/public/dailies?take=N` — 日报归档列表

## User-Agent 注入（必须）

```python
ua = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
```

## category → 话题分类映射

| AIHOT category | 建议映射 | 说明 |
|---|---|---|
| `ai-models` | business | 模型发布 = AI 内容生产工具进化 |
| `ai-products` | business | 产品发布 = 工具选型参考 |
| `industry` | growth | 行业动态，可桥回到内容生产管理 |
| `paper` | growth | 论文研究，科普/教程方向 |
| `tip` | business | 技巧 = AI 内容创作实操教学 |

## 接入方案

在 `scripts/auto_media_hot_collection.py` 里新增流3（AIHOT API），插入在流1（热搜）和流2（Tavily）之后：

```python
def aihot_fetch(since_iso: str, take: int = 20):
    ua = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    url = "https://aihot.virxact.com/api/public/items"
    params = {"mode": "selected", "since": since_iso, "take": take}
    cmd = ['curl', '-s', '--max-time', '15',
           '-H', f'User-Agent: {ua}',
           url + '?' + urlencode(params)]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    data = json.loads(result.stdout)
    return data.get('items', [])
```

写入 pool.db 时按 category 映射 business/growth。

## 相对于 Tavily 流的优势

- 零成本（不需要 Tavily API key）
- 内容已经过人工精编筛选，质量高于一般搜索结果
- 来源是 Twitter/HN 技术社区，与 AI 内容生产受众高度重合
- 无需 SEO 过滤（精选内容本身已过滤内容农场）

## 待确认问题

1. **轮询频率**：并入现有 08:00 cron 还是单独 cron？
2. **跨信源去重**：同一事件可能同时出现在微博热搜和 AIHOT，需要基于 title 相似度去重
3. **流2（Tavily）是否保留**：两者覆盖有重叠，是区分优先级还是合并？
