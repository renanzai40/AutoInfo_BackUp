# MiniMax API 调试记录（会话积累）

> 记录非显而易见的 API 调用陷阱，按时间倒序。

---

## 2026-05-12 本次会话

### Chat API 模型名大小写敏感
- **错误**: `"model": "m2.7"` → `invalid params, unknown model 'm2.7' (2013)`
- **正确**: `"model": "MiniMax-M2.7"`（区分大小写，必须全大写）
- **诊断方法**: 调用 `/v1/models` 端点查看可用模型列表

### TTS `emotion` 字段导致 2013 错误
- **错误 payload**:
  ```python
  "voice_setting": {
      "voice_id": "male-qn-qingse",
      "speed": 1.0,
      "emotion": "happy"   # ← 禁止，会炸
  }
  ```
- **正确**: `voice_setting` 只含 `voice_id`, `speed`, `vol`, `pitch`，不含 `emotion`
- **错误信息**: `invalid params: voice_setting emotion`

### 图片生成返回字段是复数数组
- **错误**: `data["data"]["image_url"]` → `KeyError: 'image_url'`
- **正确**: `data["data"]["image_urls"][0]`（复数，取第一个元素）

### Whisper ASR 品牌名必死检测
- `壹目贯维` 被 Whisper 听成：`一目贯为` / `壹目贯为` / `一目惯为` 等近音字
- MiniMax review 也会漏检，必须**逐字对照原始脚本**核对
- 这不是随机错误，每次必定触发，是 Whisper 对未覆盖词汇的系统性问题

### MiniMax 视频生成 `video-01` 模型不支持
- **错误**: `"model": "video-01"` → status 2061 `your current token plan not support model, video-01`
- **解法**: 走 Fallback 路径 B（图片序列），不得阻塞生产
- **判断**: 收到 2061 立即切换，不重试

### 飞书 send_message target 格式
- `send_message(target="origin")` → `Unknown platform: origin`
- `send_message(target="feishu")` → `[230001] invalid receive_id`
- **正确**: `send_message(target="feishu:ou_{user_id}")`，user_id 从用户 profile 获取
- 私聊和群聊都遵循此格式

### 飞书 DM vs Group ID 区分（2026-05-12）
- `oc_fb` 开头 = 私聊DM，**不是**群的特征
- 系统 `send_message(action='list')` 显示的标注可能与实际相反（显示 dm 的实际是群，显示 group 的实际是私聊）
- **每次发送前必须用 `action='list'` 列出现有 target 并确认**，不要凭上次记忆
- 已确认ID：
  - renan 私聊DM: `oc_fb8771a1fb9b0214b99d7c28c03dbe7f`
  - 贯维内容生产群: `oc_fbc1c0b8faf60cf622b75904fd1f75cd`

---

## 历史记录

见 `references/tts-calibration.md`（TTS速度/HIS工作流）和 `references/projects-audit.md`（历史项目问题）。
