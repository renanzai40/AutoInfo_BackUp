# MiniMax API 模型发现记录（2026-05-22）

## 背景

需要用 LLM 做话题相似度筛选，尝试调用 MiniMax 文本模型。

## 测试过的模型名称（全部失败）

| 模型名称 | 错误代码 | 错误信息 |
|----------|---------|---------|
| `MiniMax-Text-01` | 2061 | your current token plan not support model |
| `abab6.5s-chat` | 2061 | your current token plan not support model |
| `abab6-chat` | 2061 | your current token plan not support model |
| `minimax-text` | 2013 | invalid params, unknown model |
| `MiniMax-Text` | 2013 | invalid params, unknown model |
| `gpt-3.5-turbo` | 2013 | invalid params, unknown model |
| `GLM-4` | 2013 | invalid params, unknown model |
| `minimax-chat` | 2013 | invalid params, unknown model |

## 可用端点

- **API Key**：`sk-cp-CAPjdmwYi7mVzEjlbnCpHfGAi2h07_EUM3vb7mPj84WqG5urhqFzPfbMBbY5T5eQGn7JDU5ThPr7wzc799yN3TsIkF2l0vN-STeXi0YDxrH8mMnvu-Jrpbw`
- **API Host**：`https://api.minimaxi.com`
- **Group ID**：`2031939467861824282`

## 可用模型（已验证）

| 模型 | 类型 | 用途 |
|------|------|------|
| `speech-2.8-hd` | TTS | 语音合成（默认音色：`Chinese (Mandarin)_Radio_Host`）|
| `image-01` | 图片生成 | 竖屏封面图生成 |
| `video-01` | 视频生成 | ⚠️ token plan 可能不支持（status 2061） |
| `Hailuo-2.3` | 视频生成 | ⚠️ 不支持 Text-to-Video（status 2013） |
| `MiniMax-M2.7` | 对话（当前 session 模型） | 会话/文本生成（已集成在 Hermes Agent）|

## 教训

1. **不要花时间探测 MiniMax 模型名**：当前 token plan 只支持已知专用模型（语音/图片/视频），文本生成通过 Hermes Agent 的会话层已内置 MiniMax-M2.7，不需要手动调用 API
2. **Pool 级去重用规则匹配**：本次改用关键词聚类规则（8个簇）实现，不依赖 LLM 调用
3. **如果确实需要 LLM 做语义匹配**：用 `mcp_minimax_*` 工具（MCP 协议）已集成在 Hermes，不走 raw API
