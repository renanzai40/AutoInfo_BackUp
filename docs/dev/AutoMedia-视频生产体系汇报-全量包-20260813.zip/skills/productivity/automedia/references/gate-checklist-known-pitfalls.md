# Gate 脚本已知 Pitfalls（2026-06-01 实测沉淀）

本文件汇总 AutoMedia 4 Gate（C1 Humanizer / C2 Copy-review / C3 Brand CTA / C4 Wechat-checklist）扫描脚本在中文场景下的 8 个真实踩坑 + 修复方案。**未来跑 Gate 必须先用本文档作为 checklist**，避免重复踩。

---

## 1. C1 Humanizer 误判：em-dash "——"

**症状**：第一次扫描报 m3_wechat 43 处 em-dash，触发"em-dash 过度使用"红线。

**根因**：Humanizer SKILL 里的"em-dash 滥用"特征是**英文 AI 写作**特征。中文破折号 "——" 是**正常中文标点**，使用比例 0.8-1.2% 在中文写作里完全合规。

**修复方案**：
- 不要用正则 `[—-]{1,}.*?[—-]{1,}` 扫中文，会匹配到所有 dash
- 改为精确数 `content.count("——")` 然后按比例判定（中文正常 0.8-1.2%）
- 阈值建议：>2% 才标"过度使用"

**适用范围**：C1 Gate 全部中文内容。

---

## 2. C1 Humanizer 误判："不是...而是"

**症状**：m3_wechat 报 1 处"不是 X 而是 Y" 触发"刻意对比转折"红线。

**根因**：Humanizer 把"不是 X 而是 Y" 当成 AI 套话，但实际可能是**真实观点对比**（如"不是挑工具，而是搭流程"）。

**修复方案**：
- 匹配后必须人工 review 上下文
- 判定标准：是有"明确观点/对比对象"（OK），还是"空洞对比"（不 OK）
- 不直接通过 regex 标黄，需人确认

---

## 3. C2 Copy-review 误判：HTML 头部干扰"首段钩子"检查

**症状**：m3_wechat 第一次扫描报"首段无钩子/痛点"未通过。

**根因**：脚本用 `content[:300]` 拿前 300 字符，但 HTML 文件前 300 字符是 `<!DOCTYPE html>...<style>...`，**不是真正的正文首段**。

**修复方案**：
```python
from html.parser import HTMLParser
class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.skip = False
    def handle_starttag(self, tag, attrs):
        if tag in ["script", "style"]:
            self.skip = True
    def handle_endtag(self, tag):
        if tag in ["script", "style"]:
            self.skip = False
    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)
    def get_text(self):
        return " ".join(self.parts)
```

- HTML 文件先 `TextExtractor().feed(content).get_text()` 转文本再检查
- 传 `text` 而非 `content` 给 check 函数

---

## 4. C2 Copy-review 误判：段落超长按 \n\n 切

**症状**：m3_wechat 报 1 个 4240 字超长段落。

**根因**：HTML 转文本后，整个文章用空格 join 成一段（中间是空格不是 \n\n），按 \n\n 切只切出 1 段。

**修复方案**：
- HTML 文件按 `<p[^>]*>([^<]+)</p>` 切段，不是按 \n\n
- Markdown 文件按 \n\n 切

---

## 5. C2 Copy-review 误判：引号内反例触发"无空话"

**症状**：hy_zhihu 报"赋能"、"数字化转型"触发"无空话"红线。

**根因**：原文是把这些词放在引号内作为"反例"（"避免用'赋能'、'数字化转型'这种空话"），但扫描器没区分。

**修复方案**：
```python
cleaned = re.sub(r'["「][^"」]*["」]', '', text)  # 去引号内文本
empty_words = ["赋能", "数字化转型", "抓手", ...]
# 然后再在 cleaned 上检查
```

---

## 6. C2 Copy-review 误判：数字+空格不匹配

**症状**：m3_xhs/hy_xhs 报"无具体数据"，实际有"4 小时"、"15 分钟"、"7.5 倍"。

**根因**：原始正则 `r'\d+(?:\.\d+)?(?:%|倍|万|千|小时|分钟|字)'` 不支持数字+空格的格式。

**修复方案**：
```python
num_matches = re.findall(r'\d+(?:\.\d+)?(?:\s*[%倍万千]|\s*(?:小时|分钟|秒|天|周|月|年|字|个|款|次|人|元|块|%|条|篇|成|分))', text)
```

- 数字后允许有空格
- 涵盖常用单位：小时/分钟/秒/天/周/月/年/字/个/款/次/人/元/块/%/条/篇/成/分

---

## 7. C2 Copy-review 误判：平台差异 CTA

**症状**：m3_xhs 报"无 CTA"，实际末尾有"💬 你们团队用 AI 写内容最头疼的是哪一步？评论区聊聊"。

**根因**：CTA 关键词用了"关注/私信/查看/试试"等，但小红书平台 CTA 主要是"评论互动"而非"关注公众号"。

**修复方案**：CTA 关键词按平台差异化：
```python
cta_kws = {
    "video": ["关注", "实测", "下期"],
    "xhs": ["关注", "评论", "聊聊", "扣", "看看", "更多", "下期", "你们"],
    "wechat": ["关注", "下期", "查看", "我们", "联系"],
    "zhihu": ["关注", "下期", "讨论", "查看", "知乎"],
}
```

---

## 8. C2 Copy-review 误判：可操作建议缺"怎么 X"通配

**症状**：m3_xhs 报"无可操作建议"，实际有"怎么喂它资料"、"怎么审它"、"怎么发出去"。

**根因**：关键词列表用了"怎么做"，但 xhs 里用的是"怎么喂/审/发"。

**修复方案**：
```python
c5b = bool(
    re.search(r'怎么[一-龥]', text)  # "怎么" 后接任意汉字
    or any(kw in text for kw in ["怎么做", "用 M3", "第一步", ...])
)
```

---

## 9. C3 Brand CTA 误判："第一" 序数用法

**症状**：hy_wechat 报 5 处"第一"触发"夸张形容词"红线。

**根因**：所有"第一"都是**序数/固定短语**（"第一天"、"第一层"、"第一次"、"第一时间"），不是品牌绝对化宣传。

**修复方案**：正则必须排除序数/固定短语用法：
```python
# 排除: 第一天/第一层/第一次/第一时间/第一件/第一反应/第一稿/第一个/第一批
# 只匹配品牌/产品宣传语境: "(壹目贯维|我们)...(最强|最大|第一|唯一|顶级)"
r"((?:壹目贯维|我们)[^，。\n]{0,15}?(?:最强|最大|第一|唯一|顶级))"
```

**适用 brand-cta-review 7_夸张形容词 项。**

---

## 10. C3 Brand CTA 误判：视频脚本"扫码"在注释里

**症状**：m3_tiktok 报 2 处"扫码"触发"扫码不一致"红线。

**根因**：视频脚本顶部有"CTA：关注（视频无二维码，强制不用'扫码'）"的注释 + 工序记录里有"扫码"红线说明。**这些是规则说明，不是口播内容**。

**修复方案**：
```python
if platform == "video" or path.endswith(".txt"):
    body = re.split(r'## 【工序记录】', content)[0]  # 去工序记录
    body = re.sub(r'^#.*$', '', body, flags=re.MULTILINE)  # 去顶部注释
else:
    body = content
# 然后在 body 上扫描
```

---

## 11. C4 Wechat-checklist 误判："万字" 技术描述

**症状**：m3_wechat 报"标题有营销夸张词"。

**根因**：规则有"万字"关键词，但文章里"100 万字上下文"是**技术描述**（大模型 token 数量），不是营销词"万字长文"。

**修复方案**：
- 排除"100 万字"、"百万字"、"1 万字"等技术用法
- 用 `(?<![百万])` 限定前面不能是"百"或"万"
- 只匹配"万字长文"、"万字深度"等营销用法

---

## 12. 视频脚本 Entry ≤45 字红线（必须拆分）

**症状**：m3_tiktok 第一次版本单 Entry 130 字（整段干货），触发 SRT 字幕红线。

**根因**：脚本里一个引号包了整段 130 字，但 TTS SRT 每 Entry 是 1 句，**单句 >45 字会超出字幕显示框**。

**修复方案**：
- 视频脚本口播必须按"短句"拆 Entry，每 Entry ≤45 字（**SRT 硬约束**）
- 130 字段落拆为 4-5 个 Entry（每 Entry 20-30 字）
- 修复后 m3_tiktok 13 Entry，最大 27 字，全部合规

**这是 short-video-script skill 5 段式里的核心规则，必须严守。**

---

## 13. 通用建议：所有 Gate 扫描做完后必须人工 review 触发项

**教训**：本 session 4 个 Gate 共触发 ~30 个"疑似违规"，但其中 90%+ 是 false positive（中文 vs 英文 AI 模式差异 + 平台差异 + 注释干扰）。

**正确流程**：
1. 脚本自动扫描 + 标黄
2. **人工逐条 review 标黄项的上下文**
3. 区分"真实违规" vs "false positive"
4. 真实违规 → 修；false positive → 文档化原因（写进本文件）

**禁止**只看脚本报"未通过"就盲改——会破坏内容真实性。

---

## 维护规则

- 每次 Gate 扫描踩到新坑，**立即**追加到本文件
- 修复方案带可执行代码（未来可以直接抄）
- Pitfall 描述要带"症状 → 根因 → 修复方案"3 段

**最后更新**：2026-06-01（automedia Step 0-5 实测沉淀）
