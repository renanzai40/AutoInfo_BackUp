# FFmpeg ASS 字幕烧录正确流程（2026-05-13 更新）

## 两种烧录方案

### 方案A：burn_subtitles.py（推荐，已验证 `--audio-file` 参数）

**使用场景**：Fallback 路径B（图片序列 → 视频）

**核心问题**：旧版 `burn_subtitles.py` 的 Step 3 用 `video_path`（无音轨图视频）作为音频源，导致 `-shortest` 以错误时长截断视频。

**修复**：v9 版本已添加 `--audio-file` 参数，显式传入 MP3 音频文件，绕过此问题。

```bash
# 构建图片视频（时长 = 音频时长）
# concat demuxer + -t 截断到精确音频时长
$FFMPEG -y -f concat -safe 0 -i concat.txt \
    -vf "scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2,setsar=1" \
    -r 2 -t 59.69 \
    -c:v libx264 -preset fast -crf 23 -pix_fmt yuv420p \
    img_video.mp4

# 烧录（传外部音频文件，--audio-file 绕过视频音轨问题）
$PYTHON $BURNPY img_video.mp4 subtitled.mp4 \
    --segments segs.json \
    --font-size 55 --margin-v 120 --margin-h 80 --fps 2 \
    --audio-file audio.mp3

# 最终合并（video 定义时长，audio 填满）
$FFMPEG -y -i subtitled.mp4 -i audio.mp3 \
    -c:v copy -c:a aac -b:a 128k -shortest \
    video_final.mp4
```

---

### 方案B：FFmpeg ASS 滤镜直烧

**问题**：FFmpeg 内置 `ffmpeg -i subtitle.srt ass_output.ass` 生成 PlayRes=384×288（错误），导致字幕在竖屏 720×1280 上字号被放大 5 倍并截断。

**正确做法**：Python 生成正确 PlayRes 的 ASS 文件。

```python
"""生成正确 PlayRes 的 ASS 字幕文件"""
import re

def ms_to_ass(ms):
    h = int(ms // 3600000)
    m = int((ms % 3600000) // 60000)
    s = int((ms % 60000) // 1000)
    cs = int(ms % 1000)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"

with open(srt_path) as f:
    content = f.read()

blocks = re.split(r'\n\n+', content.strip())
dialogues = []
for block in blocks:
    lines = block.strip().split('\n')
    if len(lines) >= 3:
        m = re.match(r'(\d{2}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2}),(\d{3})', lines[1])
        if m:
            start = int(m[1])*3600000 + int(m[2])*60000 + int(m[3])*1000 + int(m[4])
            end = int(m[5])*3600000 + int(m[6])*60000 + int(m[7])*1000 + int(m[8])
            text = '\n'.join(lines[2:]).replace('\\', '\\\\').replace('{', '\\{').replace('}', '\\}')
            dialogues.append((start, end, text))

ass = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,WenQuanYi Zen Hei,{font_size},&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,0,2,60,60,100,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
for start, end, text in dialogues:
    ass += f"Dialogue: 0,{ms_to_ass(start)},{ms_to_ass(end)},Default,,0,0,0,,{text}\n"
```

```bash
# 单次 FFmpeg 调用：ASS 烧录 + 音频合并
$FFMPEG -y \
    -i video_with_video_track.mp4 \
    -i audio.mp3 \
    -filter_complex "[0:v]ass='subtitle.ass'[v]" \
    -map "[v]" -map "1:a" \
    -c:v libx264 -preset fast -crf 23 -pix_fmt yuv420p \
    -c:a aac -b:a 128k \
    video_final.mp4
```

---

## 关键坑（永久记录）

| 坑 | 根因 | 解法 |
|----|------|------|
| burn_subtitles.py 视频比音频短 | Step 3 用 video_path（无音轨）作 `-shortest` 源 | 用 `--audio-file` 传外部 MP3 |
| FFmpeg SRT→ASS 生成 PlayRes=384×288 | ffmpeg 默认值硬编码 | Python 生成正确 PlayRes 的 ASS |
| concat demuxer 输出的视频时长不准确 | duration directive 支持不稳定 | 用 `-t` 参数在后续编码步显式截断 |
| 所有字幕时间轴必须与音频绑定 | 视频时长由音频决定 | 先锁定音频，再生成视频 |

## burn_subtitles.py --audio-file 参数（2026-05-13 新增）

```python
# process_video() 新增参数
def process_video(video_path, output_video, segments,
                  font_size=55, margin_v=120, margin_h=80, fps=2,
                  audio_file=None):   # ← 新增

    audio_src = audio_file if audio_file else video_path
    cmd = [
        ...,
        "-i", audio_src,         # 替换原来的 video_path
        "-map", "0:v", "-map", "1:a",
        "-c:a", "aac", "-b:a", "128k",  # 不再用 copy
    ]
```

```bash
# CLI 新增参数
parser.add_argument("--audio-file", default=None,
                    help="External audio file (overrides video's embedded audio)")
```
