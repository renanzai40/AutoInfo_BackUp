# pool.db 话题池去重与 status 管理（2026-05-22）

## 问题现象

已选话题在后续 cron 推送中重复出现。

**根因**：用户选定话题 → 启动生产链路，但 pool.db 的 `status` 从未被更新为 `'selected'`。

## 状态字段语义

| status | 含义 |
|--------|------|
| `pending` | 未被选中，可出现在推送候选中 |
| `selected` | 已被用户选中并启动生产，不再出现在推送候选中 |

## 快速查询

```python
import sqlite3
conn = sqlite3.connect('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db')
conn.row_factory = sqlite3.Row
cur = conn.cursor()

# 当前各状态数量
cur.execute("SELECT status, COUNT(*) as cnt FROM topics GROUP BY status")
for r in cur.fetchall():
    print(f"  {r[0]}: {r[1]} 条")

# pending 话题里有没有实际上已选过的？
cur.execute("""
    SELECT topic_id, title, created_at FROM topics
    WHERE status = 'pending'
    AND (title LIKE '%普京%' OR title LIKE '%特朗普%' OR title LIKE '%AI语音%')
    ORDER BY created_at DESC
""")
for r in cur.fetchall():
    print(f"  {r[2][:10]} | {r[1][:50]}")
```

## 完整去重修复流程

### 步骤 1：从项目文件夹收集 topic_id

```python
import os, json

projects_dir = '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects'
all_topic_ids = set()

skip_dirs = {'delivery'}  # 跳过非生产目录

for entry in os.scandir(projects_dir):
    if not entry.is_dir() or entry.name in skip_dirs or entry.name.startswith('_'):
        continue
    info_path = os.path.join(entry.path, '00_project_info.json')
    if os.path.exists(info_path):
        with open(info_path) as f:
            info = json.load(f)
        # 单 topic_id
        if info.get('topic_id'):
            all_topic_ids.add(info['topic_id'])
        # multi topics (dual-topics)
        for t in info.get('topics', []):
            if t.get('topic_id'):
                all_topic_ids.add(t['topic_id'])

print(f"收集到 {len(all_topic_ids)} 个 topic_id")
```

### 步骤 2：更新 pool.db

```python
import sqlite3
from datetime import datetime

conn = sqlite3.connect('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db')
cur = conn.cursor()
now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

for tid in all_topic_ids:
    cur.execute("""
        UPDATE topics
        SET status = 'selected', updated_at = ?
        WHERE topic_id = ? AND status = 'pending'
    """, (now, tid))

conn.commit()

# 验证结果
cur.execute("SELECT status, COUNT(*) as cnt FROM topics GROUP BY status")
for r in cur.fetchall():
    print(f"  {r[0]}: {r[1]} 条")
conn.close()
```

## 关键教训

1. **cron job 没有自动更新 status**：即使 cron 在推送中附带了"第六步"说明，执行时仍然跳过了这一步
2. **项目文件夹普遍缺少 topic_id**：2026年4月24日至5月19日的项目大多没有 `00_project_info.json`，无法追溯
3. **pool.db 只存 cron 采集的话题**：手动旁路创建的项目话题从未入库，导致这些话题在池中不存在
4. **双重追踪系统隔离**：`pool.db`（话题队列）和 `projects/`（内容生产）是两个独立系统，靠 `topic_id` 关联

## 预防措施

每次用户选择话题后，立即执行（不可跳过的两个动作）：
1. 更新 pool.db：`UPDATE topics SET status='selected' WHERE topic_id=?`
2. 创建/更新 `00_project_info.json`：写入 `topic_id` 字段

这两个动作必须在启动生产链路之前完成，不是在生产完成之后补。
