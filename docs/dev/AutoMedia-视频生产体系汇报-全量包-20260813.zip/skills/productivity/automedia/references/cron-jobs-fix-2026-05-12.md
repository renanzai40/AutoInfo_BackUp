# Cron Jobs 修复记录 (2026-05-12, v2 双流架构)

## 问题发现

08:00 和 08:30 两个定时任务配置错误：

- **08:00 任务**：只采集数据并展示 TOP20，**没有写入 pool.db**（数据丢失）
- **08:30 任务**：按单一 `heat_score` 排序，没有区分 growth/business 类别

导致 08:30 每次读到的 pool.db 都是空的。

## 修复内容

### pool.db schema

- `topics` 表缺少 `freshness_score` 字段 → 已添加
- `ALTER TABLE topics ADD COLUMN freshness_score REAL`

### 08:00 prompt（任务 ID: 143d19e69a7c）

> ⚠️ **（2026-05-13 已废弃 prompt 模式）**：cron agent 的 prompt 只能描述算法，不能执行 Python 数学运算。rank 归一化在 prompt 里写了但从未执行。
>
> **新方案**：迁移到 `no_agent=True` 脚本模式 → `scripts/auto_media_hot_collection.py`
> 脚本直接执行：curl HTTP → rank 归一化 → MiniMax 去重 → sqlite3 写入
> 详见：`scripts/auto_media_hot_collection.py`

~~**08:00 prompt**：~~

**2026-05-12 修复**：去重改用 MiniMax 语义判断，不自己算字符集合。

**2026-05-13 v2 修复：双流并行 + rank归一化**

入库逻辑升级为两路并行：

**流1（热搜流）**：
- 4平台各 TOP15 → 最多60条原始数据
- 各平台内按热度 rank 归一化：`heat_score = 1.0 - (rank-1) × 0.067`（rank1=1.0, rank15=0.06）
- MiniMax 语义去重（同一事件只保留热度最高的一条）
- 按归一化热度排序，取 TOP20
- MiniMax 话题分类（growth / business）→ 分别写入 pool.db

**流2（AI网搜流）**：
- 3组 Tavily AI 关键词并行搜索（`--time-range day`，确保时效性），每组取 TOP15
- 合并最多60条原始数据
- 按 Tavily score 排序做 rank 归一化：`score_norm = 1.0 - (rank-1) × 0.067`
- MiniMax 语义去重（同一事件只保留热度最高的一条）
- 取 TOP15
- **直接标 `category='business'`**，不经过 MiniMax 分类

**rank归一化目的**：各平台/来源热度量级不同（知乎几百万 vs Tavily 0.9），入库前全部归一化到 1.0~0.06，保证08:30评分时各来源话题公平竞争。

**时效性**：Tavily 用 `--time-range day` 过滤近24小时内的 AI 新闻。

**AI 关键词（8组，均为AI内容生产行业相关）**：
`AI视频生成`、`AI配音`、`AIGC创作平台`、`AI营销内容`、`AI研究突破`、`AI大模型行业动态`、`中国AI大模型周调用量`

**合流去重**：
- 流1 TOP20 + 流2 TOP15 合并
- 如果同一话题同时出现在两流（MiniMax 判断为同事件），只保留一条，优先保留流1的分类结果
- 最终入库最多35条

详见：`references/hot-collection-4platform-2026-05-12.md`

### 08:30 prompt（任务 ID: 7671da210b69）

修复后：
- 评分公式：growth 款用 `heat×0.55+rel×0.25+fresh×0.20`，business 款用 `heat×0.25+rel×0.55+fresh×0.20`
- 输出：智能体推荐结论 + 排序列表

**v2 说明**：08:30 prompt 不需要改动，rank归一化后各来源热度在同一量级，评分自动生效。

## 验证命令

```python
import sqlite3
conn = sqlite3.connect('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db')
cursor = conn.cursor()
cursor.execute('PRAGMA table_info(topics)')
cols = [c[1] for c in cursor.fetchall()]
print('freshness_score in schema:', 'freshness_score' in cols)
cursor.execute('SELECT COUNT(*) FROM topics')
print('topics count:', cursor.fetchone()[0])
cursor.execute('SELECT COUNT(*) FROM topics WHERE category="business"')
print('business count:', cursor.fetchone()[0])
cursor.execute('SELECT COUNT(*) FROM topics WHERE source="Tavily"')
print('Tavily count:', cursor.fetchone()[0])
```

## ⚠️ 已知：cron 延迟导致"幽灵空池"（2026-05-13 新增）

**症状**：pool.db 文件存在且大小正常（77KB），表结构正常，但 `SELECT COUNT(*) FROM topics` 返回 0。

**根因**：cron 调度器延迟时，两个任务执行顺序变为 08:30推送 → 08:00采集，导致推送任务读到空池。**不是数据库损坏。**

**判断方法**：对比 jobs.json 中两个任务的 `last_run_at`：
- 08:00采集(last_run_at) > 08:30推送(last_run_at) → 采集入库在推送之后 → 正常现象，明天自动恢复
- 推送 last_run_at 早于采集但池也为空 → 采集入库可能失败，需查采集任务日志

**诊断 Python**：
```python
import sqlite3
conn = sqlite3.connect('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db')
cursor = conn.cursor()
cursor.execute('SELECT COUNT(*) FROM topics')
count = cursor.fetchone()[0]
print(f'topics count: {count}')
# count=0 + cron延迟 → [SILENT] 即可，不要重建数据库或查schema
```

**不要做的浪费**：检查 schema、VACUUM、重建数据库——文件存在且 >10KB 说明数据库完好，浪费时间在这些步骤上只会拖延诊断。

**相关任务 ID**：
- 08:00 采集：`143d19e69a7c`
- 08:30 推送：`7671da210b69`
- 07:30 新鲜度维护：`maintenance_01`

## 相关文件

- `/home/renanzai/.hermes/cron/jobs.json` — cron 任务配置
- `/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db`
- `/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/README.md`
