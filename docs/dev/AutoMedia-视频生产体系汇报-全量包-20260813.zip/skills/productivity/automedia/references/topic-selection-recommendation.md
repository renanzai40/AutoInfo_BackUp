# 话题推荐生成规范（2026-05-24 新增）

## 背景

2026-05-24 发现：生成话题推荐列表时，查询未加 `status='pending'` 过滤，导致推荐给用户的话题可能已经是已选中状态（status='selected'），用户选完后才发现无法标记。

根因：推荐脚本从"全量 pending pool" 生成 TOP N，但 SQL 查询漏掉了 `status='pending'` 过滤条件。

## 正确的推荐查询

生成用户推荐列表时，**必须同时过滤** `status` 和 `review_status`：

```sql
SELECT topic_id, title, category, source,
       heat_score, correlation_score, freshness_score
FROM topics
WHERE status = 'pending'
  AND review_status = 'approved'
  AND category = 'growth'   -- 或 'business'
ORDER BY heat_score DESC
LIMIT 20
```

### 常见遗漏点

| 错误写法 | 正确写法 |
|---------|---------|
| `WHERE category='business'` | `WHERE status='pending' AND category='business'` |
| 忘了 `review_status='approved'` | 必须加，否则 pending review 的话题会混入 |
| 查完全表再在 Python 里过滤 | SQL 层就过滤，Python 只做排序展示 |

## 综合分计算公式（v3，2026-05-24）

```python
def score_g(heat, corr, fresh):
    """growth 引流款：热度30% + 相关性40% + 新鲜度30%"""
    return heat * 0.30 + corr * 0.40 + fresh * 0.30

def score_b(heat, corr, fresh):
    """business 业务款：热度10% + 相关性60% + 新鲜度30%"""
    return heat * 0.10 + corr * 0.60 + fresh * 0.30
```

## 批量重算 correlation_score

```python
import sqlite3, sys
sys.path.insert(0, '/home/renanzai/.hermes/skills/productivity/automedia/scripts')
from auto_media_hot_collection import score_correlation

DB = '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db'
conn = sqlite3.connect(DB)
conn.row_factory = sqlite3.Row
cur = conn.cursor()
cur.execute("SELECT topic_id, title, category FROM topics WHERE status='pending'")
for row in cur.fetchall():
    new_corr = score_correlation(row['title'], row['category'])
    cur.execute("UPDATE topics SET correlation_score=? WHERE topic_id=?",
                (new_corr, row['topic_id']))
conn.commit()
conn.close()
```

## 推荐列表生成检查清单

- [ ] SQL 查询包含 `WHERE status='pending' AND review_status='approved'`
- [ ] 生成后验证 TOP N 里没有 status='selected' 的话题
- [ ] 用户选择后、标记 selected 前，再次确认该 topic_id 状态是 pending
- [ ] 用户说"选N"时，先确认 N 是推荐列表的序号，而不是已选话题的序号
