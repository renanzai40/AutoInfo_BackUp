# Subagent CTA 后处理规范（2026-05-28）

## 问题现象

subagent 独立生成 5 平台文案时，CTA 段落产生变体：

| 平台 | 变体 CTA | 用户确认标准 CTA |
|------|---------|----------------|
| TikTok | 想know哪里有**真正**安全的...？关注壹目贯维，带你看清这门生意。 | 想know哪里有安全的...？关注壹目贯维 |
| Bilibili | 想know哪里有靠谱的...？关注壹目贯维，下期告诉你答案。 | 同上 |
| Zhihu | 想know哪里有安全的...？关注壹目贯维，**一起探索更安全的内容生产之道** | 同上 |
| WeChat | 想know哪里有安全的...？关注壹目贯维，让我们帮你守住这条线。 | 同上 |
| Xiaohongshu | 想know哪里有**真正**安全的...？关注壹目贯维，帮你守住这条线。 | 同上 |

根因：subagent context 中虽然写了"CTA话术必须一致"，但 subagent 的 MiniMax 生成不受硬约束，产生了语义相似但文字不同的变体。

## 强制步骤

subagent 返回后，**立即**执行：

1. 读取 5 个平台草稿
2. 全局搜索"壹目贯维"，定位每处 CTA 段落
3. 替换为用户确认的标准 CTA（精确匹配，不做语义等效判断）
4. 写回文件
5. 验证 5 个平台全部一致

```python
CONFIRMED_CTA = "想know哪里有安全的AI内容生产解决方案？关注壹目贯维"
for platform, filename in [('tiktok','script.txt'), ('bilibili','script.txt'),
                           ('wechat','wechat_draft.html'), ('zhihu','zhihu_article.md'),
                           ('xiaohongshu','xiaohongshu_post.md')]:
    path = os.path.join(project_dir, platform, filename)
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
    if '壹目贯维' not in content:
        continue
    lines = content.split('\n')
    changed = False
    for i, line in enumerate(lines):
        if '壹目贯维' in line and CONFIRMED_CTA not in line:
            lines[i] = CONFIRMED_CTA
            changed = True
    if changed:
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))
        print(f"Fixed CTA in {platform}/{filename}")
```

## 预防：confirmed CTA 必须写入 subagent context

在 delegate_task 的 context 参数中，CTA 应该写为：

```
CTA话术（用户已确认，不得修改）：想know哪里有安全的AI内容生产解决方案？关注壹目贯维
```

而不是"CTA话术必须一致"——后者给了 MiniMax 变体空间。

## 关联教训

- subagent 文件名不服从规范：subagent 生成了 `draft_tiktok.md`，skill 期望 `tiktok/script.txt`。subagent 返回后需要额外做文件归置步骤。
- 这两个问题都是"subagent 返回后立即执行"就能发现的，根源是主 agent 在 delegate_task 后没有强制验证。
