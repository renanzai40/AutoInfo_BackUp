# Runway Aleph 2.0 业务款案例复盘（2026-06-03）

**项目目录**：`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/20260603_164957_runway-aleph-2-api/`

**项目目录结构**：

```
20260603_164957_runway-aleph-2-api/
├── 00_project_info/project_info.json
├── 01_content/drafts/
│   ├── wechat/wechat_draft.html (8.7KB, 1887 中文字)
│   ├── zhihu/zhihu_article.md (8.1KB, 1881 中文字)
│   ├── xiaohongshu/xiaohongshu_post.md (1.6KB, 363 字 + 6 标签)
│   ├── tiktok/script.txt (0.9KB, 158 汉字 + DATA 100%)
│   └── bilibili/script.txt (0.9KB, 同 tiktok)
├── 02_images/assets/
│   ├── frame_001.jpg (161.9KB)  # 钩子段
│   ├── frame_002.jpg (333.8KB)  # 痛点段
│   ├── frame_003.jpg (156.5KB)  # 干货段
│   ├── frame_004.jpg (200.6KB)  # 高潮段
│   └── frame_005.jpg (120.7KB)  # CTA 段
├── 03_video/
│   ├── audio_voiceover.mp3 (1208.8KB, 77.26s, male-qn-qingse)
│   ├── subtitle.srt (1.3KB, 15 段, 品牌名校对后)
│   └── video_final.mp4 (6.80MB, 75.7s, MD5 1e73625be1b649b869cbecf32a02ff38)
├── 04_review/
│   ├── copy_review_wechat.md
│   ├── copy_review_zhihu.md (v2 修复后)
│   ├── copy_review_xiaohongshu.md (v3 修复后)
│   ├── copy_review_video.md (v2 修复后)
│   ├── zhihu_repair_log.md
│   ├── video_repair_log.md
│   ├── xhs_repair_log.md
│   └── post_render_qa_report.md
└── 05_publish/
    └── manifest.json
```

## 完整 18 步执行链 + 时间

| # | 步骤 | 工具/技能 | 时间 | 状态 |
|---|------|-----------|------|------|
| 1 | 事实查证 + Step 0 项目去重 + Topic Gate | pool.db SELECT + web_extract | ~3 min | ✅ |
| 2 | 创建项目目录 + 写 project_info + 改 pool status | execute_code | < 1 min | ✅ |
| 3 | 文案批 1：wechat + zhihu + xiaohongshu | 3 subagent 并发 | ~3 min | ✅ |
| 4 | 文案批 2：tiktok + bilibili | 1 subagent (双文件) | ~3 min | ✅ |
| 5 | 验证 5 平台文件 + 品牌名 + DATA 密度 | execute_code | < 1 min | ✅ |
| 6 | Gate 批 1 + 修复 zhihu 3 P1 | 3 subagent + 3 subagent 修复 | ~8 min | ✅ |
| 7 | Gate 复审 + 修 xhs 跨平台功能 | 3 subagent + inline patch | ~5 min | ✅ |
| 8 | 加载 6 个 remotion sub-skill + image-prompt + wechat-upload | skill_view | < 1 min | ✅ |
| 9 | TTS 生成 (5 段拼接 = 409 字) | MiniMax TTS API | < 1 min | ✅ |
| 10 | Whisper ASR + 手工拼装 SRT 15 段 | Whisper CLI + write_file | ~1 min | ✅ |
| 11 | MiniMax 5 帧生图 + Vision QA | 5 并发 + 5 vision_analyze | < 1 min | ✅ |
| 12 | Backup + 复制素材到 Remotion-Test | cp + shutil | < 1 min | ✅ |
| 13 | 写 Composition + Root.tsx + linter | write_file + patch + linter | < 1 min | ✅ |
| 14 | v1 渲染 + 像素验证 | npx remotion render + PIL | ~5 min | ⚠️ 8/10 字幕错位 |
| 15 | v2 修复 SCENE_SUBTITLES + 重渲染 | patch + npx render | ~5 min | ✅ 11/11 PASS |
| 16 | Post-render QA（Whisper pre-send）| whisper venv | ~30s | ⚠️ 关键词 fail (Whisper 限制) |
| 17 | manifest + post_render_qa_report | write_file | < 1 min | ✅ |
| 18 | 交付用户 | send_message | < 1 min | ✅ |

**总耗时：~2.5h**（其中 ~10 min 是 v1 渲染失败 → v2 修复的二次成本）

## 关键技术决策

1. **Whisper ASR → 手工拼装 SRT**（不直接用 Whisper 输出的繁体 + 错品牌名）
   - Whisper 第一次输出：Alif/Yimugwai/LF/視頻/Plug & Play → 全部错
   - 用 LLM 校对 Result 行（拿到 Result 文本）+ Whisper 时间戳 + 手工拼装 SRT
   - 比直接 LLM 输出 SRT 更稳（LLM 输出格式不可控）

2. **5 段式 + 段内相对 frame**（m3 v2 做法）
   - m3 案例 source-of-truth：SCENE_SUBTITLES 用段内 frame (start: 0, duration: 200)
   - v1 误用全局 frame → 8/10 帧字幕错位
   - v2 改用段内 frame → 11/11 帧字幕全过

3. **绕过 linter wrapper**（已交付老 Composition 不改）
   - `render_with_qa.sh` 扫整个 src/ 失败
   - 单文件 linter PASS + 直接 npx render
   - 按"已交付不改进"铁律不修老 Composition

4. **MiniMax API 凭证实际位置**：`~/.hermes/config.yaml` 的 `mcp_servers.minimax.env.MINIMAX_API_KEY`（不是 `providers.minimax.env`）；`MINIMAX_GROUP_ID` 在 `handoff/env_pack/.env`

5. **TTS 拼接方法**：5 段口播用"。"连接（不是"\n"），保证 TTS 音频是连续流

## 踩坑实录

### 踩坑 1：误判 "Aleph 2.0 不存在"

- **症状**：搜中文搜不到 → 报告"事实错误"
- **根因**：未查 pool.db.source_url
- **修复**：用户提示后查 source_url，验证 @runwayml 真的发了

### 踩坑 2：TTS 提取 bug

- **症状**：第一版用 `if not s.strip().startswith("【"): skip` 过滤 → 全部 5 段被过滤 → tts_text = "。" (1 字符)
- **根因**：每段都以【xxx】开头，过滤条件把每段都过滤了
- **修复**：用 `chunk.split("\n", 1)` 拆段头/正文

### 踩坑 3：SCENE_SUBTITLES 全局 frame 触发反模式 D

- **症状**：8/10 帧字幕错位
- **根因**：`TransitionSeries.Sequence` 内 `useCurrentFrame()` 返回**段内相对 frame**，不是全局 frame
- **修复**：SCENE_SUBTITLES entry 改用段内相对 frame（m3 v2 source-of-truth 做法）

### 踩坑 4：patch tool old_string 抄错字

- **症状**：patch xhs 失败 "Could not find a match"
- **根因**：old_string 抄成 "才能被调度"（实际是"真正被调度"）
- **修复**：read_file 拿到原文 + 精准匹配

## 关键产出物

### 视频 v2 final

- 文件：`03_video/video_final.mp4`
- 大小：6.80MB（< 30MB 飞书限制）
- 时长：75.7s（TTS 77.26s 差 1.55s 段间静音）
- 1080×1920 9:16 竖屏
- 11/11 帧像素验证 PASS
- 5 段式（钩子/痛点/干货/高潮/CTA）
- 5 帧 MiniMax 生图（无乱码/地图/Logo/肖像）
- 顶部主标题 "Runway Aleph 2.0" 黄色

### 5 平台文案

| 平台 | 字数 | 品牌名 | DATA 密度 | Gate |
|------|------|--------|----------|------|
| 公众号 | 1887 字 | ✅ 2 次 | - | ✅ PASS |
| 知乎 | 1881 字 | ✅ 1 次 | - | ✅ PASS (v2 修复) |
| 小红书 | 363 字 | ✅ 1 次 + 标签 | - | ✅ PASS (v3 修复) |
| 抖音/B站 | 158 汉字 | ✅ 2 次 | 100% | ✅ PASS (v2 修复) |

### 视频 Composition 关键参数

```typescript
// 5 段边界（全部用 srtTimeToFrame）
const S1_FROM = srtTimeToFrame("00:00:00,000");
const S1_TO = srtTimeToFrame("00:00:10,240");
const S2_FROM = srtTimeToFrame("00:00:10,980");
const S2_TO = srtTimeToFrame("00:00:26,359");
const S3_FROM = srtTimeToFrame("00:00:26,359");
const S3_TO = srtTimeToFrame("00:00:48,240");
const S4_FROM = srtTimeToFrame("00:00:48,780");
const S4_TO = srtTimeToFrame("00:01:00,640");
const S5_FROM = srtTimeToFrame("00:01:01,000");
const S5_TO = srtTimeToFrame("00:01:17,260");  // 估算 0.34s 静音末点

// SCENE_SUBTITLES 用**段内相对 frame**（m3 v2 做法）
// 段1 Sequence durationInFrames=322
[
  { text: "E1 字幕", start: 0, duration: 151 },
  { text: "E2 字幕", start: 171, duration: 136 },
],
// 段2 477
[
  { text: "E3 字幕", start: 0, duration: 96 },
  { text: "E4 字幕", start: 113, duration: 176 },
  { text: "E5 字幕", start: 313, duration: 149 },
],
// ...
```

## 关联 skills

- `automedia` — 入口
- `automedia-production-guard` — Gate 链
- `automedia-project-init` — 项目初始化
- `brand-cta-review` — 品牌 CTA
- `humanizer` / `copy-review` — 文案 3 阶 Gate
- `yimuguanwei-persona` — 品牌人设
- `image-prompt` — AI 生图规范
- `remotion-workflow` — 视频生产总览
- `remotion-timecode-anti-pattern` — 时间戳反模式
- `remotion-visual-plan` — Composition 设计
- `remotion-pre-render-gate` / `remotion-post-render-qa` / `remotion-delivery-gate`
- `whisper-postprocess` — Whisper 后处理
- `wechat-upload-checklist` — 公众号上传
- `automedia-content-repair` — 老草稿 brand-cta 修复
