# SRT字幕制作铁律（2026-05-17 固化）

## 核心原则

**音频是唯一真相，SRT是音频的倒影。Whisper JSON = 时间轴，建筑材料 = MiniMax脚本原文。**

三个强制规则：

1. **文本 = MiniMax脚本原文**：Whisper ASR 只提供 `start/end` 时间戳，文本必须用 MiniMax脚本。Whisper会把"壹目贯维"听成"壹目惯为"/"一目冠为"，必须逐字对照脚本核对并修正。
2. **时间轴 = Whisper JSON真实segment边界**：每个SRT entry的 `start/end` 必须精确等于 Whisper JSON 里对应 segment 的 `start/end` 值。
3. **每entry = 一个完整语音段**：两个segment之间有静音间隙时自然断开，不要合并。

---

## 错误模式（已造成音画不同步，2026-05-17 实测）

### ❌ 错误1：字数估算时长
用"脚本字数 ÷ 预估语速"计算每句时长，完全绕开Whisper时间轴。

**实测后果**：用户明确反馈"音画不同步"。

```python
# 错误代码
chars = len(sentence)
estimated_duration = chars / 5.0  # 假设5字/秒
start_time = i * estimated_duration
```

### ❌ 错误2：平均分段映射
把N个Whisper segments均分给M个脚本句子，每个字幕的时间轴仍是估算的。

```python
# 错误代码
segs_per_sent = n_whisper / n_sent  # e.g. 42/10 = 4.2
start_idx = int(i * segs_per_sent)
# 时间轴仍然来自估算，不是真实语音边界
```

---

## 正确工作流

```
TTS音频生成
    ↓
Whisper ASR（真实时间轴） → whisper_result.json
    ↓
读取脚本原文 → 逐句与Whisper segments对应
    ↓
SRT生成：每个Whisper segment = 一个SRT entry
         时间轴 = Whisper segment[start/end]
         文本 = MiniMax脚本原文（修正近音字后）
    ↓
逐entry检查：字数 ≤ 45字（超则按标点拆分，不跨语音段）
    ↓
品牌名"壹目贯维"必死检测：Whisper会听成近音字，修正后写入SRT
```

---

## 近音字修正清单（品牌名+高频错误）

```
壹目贯维  ←  壹目惯为/一目惯为/壹目貫为/一目冠为/壹目慣为/壹目惯为/一目惯为
赶稿      ←  感搞
热度      ←  熱鬥/熱斗
稿子      ←  搞子
热度已过  ←  熱鬥已經過了
占比      ←  戰比
蜜月期    ←  秘樂期
稳定器    ←  穩定氣
外交辞令  ←  外交磁力
内容团队  ←  內容團隊
备战状态  ←  備戰狀態
资料      ←  資料
埋怨父母  ←  满院父母/满园父母
淘宝兴起  ←  淘宝星期
实际贵    ←  实险贵
拍大腿    ←  排大腿
视而不见  ←  是而不见
牛市      ←  牛是
盯热点    ←  丁热点
生成      ←  深沉
```

---

## SRT时间轴精确对齐验证

生成SRT后必须验证：
1. Whisper末segment end ≈ 音频总时长（误差 < 1s）
2. 品牌名所在entry的时间轴与音频中实际念出该词的时间点匹配

```bash
ffprobe -v error -show_entries format=duration -of csv=p=0 audio.wav
# 对比 whisper_result.json 中最后一个 segment 的 end 值
```

---

## 关联文档

- `references/subtitle-srt-generation-2026-05-13.md` — 早期字幕修正案例
- `references/ffmpeg-subtitles.md` — PIL烧录 + FFmpeg ASS注意事项