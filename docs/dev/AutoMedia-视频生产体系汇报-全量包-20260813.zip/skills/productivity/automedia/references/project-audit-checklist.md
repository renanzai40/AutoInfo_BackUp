# 项目审计清单 — 接手已有项目时执行

> **何时用**：用户问"XX项目状态如何"/"继续做XX项目"时，必须先完整审计再继续。
> **不要**：不要假设目录存在=内容完整，不要只看文件名就判断"都有了"。

---

## 第一步：列目录树（完整枚举）

```bash
find /path/to/project/ -type f | sort
```

---

## 第二步：数内容

### 文案平台（5个）
| 平台 | 目录/文件 | 品牌CTA检查 |
|------|-----------|------------|
| 微信公众号 | `01_content/drafts/wechat/wechat_draft.html` | 必须有"壹目贯维"和"AI内容生产公司" |
| 知乎 | `01_content/drafts/zhihu/zhihu_article.md` | 必须有"壹目贯维"（知乎文章是品牌合规重灾区，容易末尾忘记加CTA） |
| 小红书 | `01_content/drafts/xiaohongshu/xiaohongshu_post.md` | 必须有#壹目贯维标签 |
| 抖音 | `01_content/drafts/tiktok/script.txt` | 必须有品牌CTA |
| B站 | `01_content/drafts/tiktok/bilibili_script.txt` 或 `bilibili/script.txt` | 必须有品牌CTA |

### copy-review 审核报告（5个）
`04_review/` 下必须有：copy_review_wechat.md / copy_review_zhihu.md / copy_review_xiaohongshu.md / copy_review_tiktok.md / copy_review_bilibili.md

### 帧图
`02_images/assets/` 下的 frame 图片。Fallback 视频方案通常需要 5-9 帧。

### 封面图
`02_images/cover/` 目录：cover_16x9.png（知乎/B站）/ cover_3x4.png（小红书竖）/ cover_1x1.png（小红书正方）/ cover_9x16.png（抖音）

### 视频素材
`03_video/`：video_final.mp4 + audio_voiceover.mp3 + subtitle.srt + script_final.txt

### 发布记录
`05_publish/publish_log.json` — 记录微信公众号草稿上传状态

---

## 第三步：品牌合规快速grep

```bash
# 1. 所有平台必须出现"壹目贯维"
grep -rl "壹目贯维" 01_content/drafts/*/

# 2. 禁止词（任一出现=不合格）
grep -rE "投资机构|金融研究|投资情报|政策信号|投资决策" 01_content/drafts/*/

# 3. 小红书必须有品牌话题标签
grep "#壹目贯维" 01_content/drafts/xiaohongshu/xiaohongshu_post.md
```

---

## 第四步：问题严重程度

| 严重程度 | 含义 | 示例 |
|---------|------|------|
| 🔴 硬性缺失 | 流程未走完，不能发布 | 无品牌CTA、无copy-review报告 |
| 🟡 内容缺失 | 素材不完整，可补齐 | 缺1帧图片、缺封面图 |
| 🟢 可选优化 | 有内容但质量可提升 | 文案可更自然 |

---

## 常见坑

### 坑1：目录拼写错误（litiation vs litigation）
- 同时存在两个拼写的目录时，内容在正确拼写的那个里
- 审计时同时检查两个拼写

### 坑2：B站脚本和抖音脚本混在同一目录
- `tiktok/script.txt` = 抖音
- `tiktok/bilibili_script.txt` = B站
- copy_review_tiktok.md 只审了抖音，B站无单独审核

### 坑3：assets（帧图）和 cover（封面图）是两个目录
- 分别检查，不能只查 assets/

### 坑4：品牌合规 — 知乎文章是重灾区
- 知乎文章正文是深度分析，容易在结尾忘记加品牌CTA
- brand-cta-review 零容忍项：全文必须搜得到"壹目贯维"
- 其他平台（微信公众号/小红书/抖音/B站）相对不容易漏
