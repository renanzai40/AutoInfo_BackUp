# 黑名单分层审计 — 自审发现（2026-05-29）

> 关联：`Pool/blacklist_refactor_SQL.sql`（待执行）/ `Pool/blacklist_refactor_SELF_REVIEW.md`（完整报告）
> 触发：每次执行话题池采集/审核相关操作前必读

---

## 核心发现：4个严重架构问题

### 问题A：流1（微博/知乎/抖音）完全没有质量审核

**现象**：近7天微博76条/知乎64条/抖音55条，**全部 review_status='approved'**，无任何审核。

**根因**：采集脚本INSERT语句没有`review_status`字段，用DB default `'approved'`直接进池。

**后果**：世界杯CBA/地震/娱乐八卦直接污染话题池，可被选为视频素材。

**正确做法**：流1入库时 `review_status='pending'`，让 audit job 统一走 Layer 2 + Layer 3。

**临时缓解**：在话题评分阶段，correlation_score 驱动 business 池，引流款由 growth 池产出——但 gaming/体育话题仍然是"真实 approved"，可被选为生产话题。

---

### 问题B：AIHOT 完全绕过 Layer 1

**现象**：采集脚本流3（AIHOT）没有经过 Domain 黑名单过滤，信任 AIHOT 精选但 source_url 可能含垃圾信源。

**后果**：如果 AIHOT 返回 `news.pchome.com.tw` 或 `instagram.com` 内容，不会被 Layer 1 拦住。

**正确做法**：AIHOT 也应该过 Layer 1 Domain 黑名单过滤（因为它有 source_url）。

---

### 问题C：audit job 只审核 Tavily

**现象**：`WHERE review_status = 'pending' AND source = 'Tavily'` — 流1 和 AIHOT 完全不进入审核流程。

**正确做法**：audit job 应该覆盖所有 `review_status='pending'` 的话题，不限定 source。

---

### 问题D：Layer 2（LLM 相关性 Gate）缺失

**现象**：`score_correlation()` 是关键词匹配，含"AI"的游戏话题被判定为 tier2 相关（8分），但本质与 AI 内容生产无关。

**典型案例**：《世界滅亡共有幻想MAMIYA》被判为 AI 相关（tier2），但本质是游戏发布新闻。

**正确做法**：新增 LLM Gate 做语义相关性判断，不依赖关键词匹配。

---

## 修正后的黑名单 REMOVE/KEEP 列表

### 应移除（已自审确认）

| Domain | 移除原因 |
|--------|----------|
| `www.163.com` | 网易科技频道有正规AI报道，通过率50% |
| `www.iyiou.com` | 亿欧主站有记者署名AI报道，通过率50% |
| `x.com` | X(Twitter)是AI开发者动态正规渠道，有approved记录 |

### 应改为子站隔离（已自审确认）

| Domain | 变更 | 原因 |
|--------|------|------|
| `apple.com` | → `podcasts.apple.com` | Apple官方有AI新闻稿，主域不应整域拉黑；Podcast索引页是内容聚合无新闻价值 |

### 暂不移除，需观察

| Domain | 原因 |
|--------|------|
| `cnblogs.com` | 通过率0%但博客园确实有技术好文，样本不足 |
| `segmentfault.com` | 1篇软文样本不足，需更多数据 |
| `www.aastocks.com` | 保留黑名单，股票资讯站非AI新闻源定位清晰 |
| `www.china-aii.com` | 有1条approved，需更多样本 |

---

## SQL 执行前检查清单

执行 `Pool/blacklist_refactor_SQL.sql` 前确认：

- [ ] 备份文件存在：`Pool/blocked_domains_BACKUP_20260529_101038.json`
- [ ] 脚本已读取并理解（先插后删顺序）
- [ ] 目标环境是生产 pool.db，不是测试库

---

## 架构改进优先级

| 优先级 | 改进项 | 影响 |
|--------|--------|------|
| **高** | 流1入库前加 Layer 2 LLM Gate | 阻止 gaming/娱乐话题污染池子 |
| **高** | 流1入库时 review_status='pending' | 让 audit job 统一审核流1 |
| **高** | audit job 去掉 source='Tavily' 限制 | 覆盖所有 pending 话题 |
| **中** | AIHOT 加 Layer 1 Domain 黑名单过滤 | 阻止垃圾信源进入 |
| **低** | 新增 section 字段支持子站隔离 | 精准黑名单管理 |