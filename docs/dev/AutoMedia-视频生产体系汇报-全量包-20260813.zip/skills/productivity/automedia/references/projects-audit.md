# AutoMedia 项目审计记录

> 更新：2026-05-12

---

## 项目当前状态（2026-05-12）

| 项目 ID | 类型 | 文案 | 封面 | 视频(含音轨+字幕) | 发布状态 |
|---------|------|------|------|------------------|---------|
| `20260510_deepseek-financing` | 引流款 | ✅ | ✅ | ✅ v11: 47.2s（视频=音频），品牌名✓，字幕22段硬烧。问题：raw视频内容为正方形(1:1)放入9:16容器，prompt需修正 | 待审核 |
| `20260510_harness-engineering` | 种草款 | ✅ | ✅ | ✅ v11: 45.6s（视频=音频），品牌名✓，字幕20段。问题同上：raw视频内容为正方形放入竖屏容器 | 待审核 |

> ⚠️ 两个项目的 raw 视频内容均为正方形构图放入 9:16 容器，导致视频上下有黑边。这是 MiniMax 视频生成 prompt 问题，下次生成时 prompt 必须明确写"9:16竖屏、占满画面、禁止正方形构图"。

---

## 字幕问题记录（2026-05-12 更新）

### 问题汇总
| # | 问题 | 根因 | 解法 |
|---|------|------|------|
| 1 | FFmpeg drawtext/ASS 中文乱码 | libass 对 CJK 字符有解析 bug | ✅ FFmpeg subtitles 滤镜 + WenQuanYi 字体（直接读 SRT，不转 ASS） |
| 2 | 字幕字号48px太大遮挡画面 | 48px/32px都不对，FFmpeg subtitles滤镜FontSize相对于PlayRes=384放大5x | ✅ 竖屏字幕：FontSize=20px + PlayRes=1920×1080，Alignment=2（底部居中），MarginV=40 |
| 3 | 视频上下有黑边（正方形内容放入竖屏容器） | MiniMax 视频生成 prompt 未明确指定竖屏构图 | ✅ prompt 必须写"9:16 竖屏、占满画面、禁止正方形构图" |
| 4 | video_final.mp4 含旧字幕 | 之前的错误烧录叠加在帧里 | 用 video_raw.mp4 重新开始 |
| 5 | 字幕内容与音频不匹配 | Whisper ASR 结果未 MiniMax review | MiniMax M2.7 review ASR 输出 |
| 6 | SRT 时间格式错误 | 用句点而非逗号 | SRT 标准：逗号毫秒 |
| 7 | 字幕时间轴不准 | 按脚本估算，非真实时间轴 | Whisper ASR 提取真实时间轴 |
| 8 | 音频45s vs 视频30s 不匹配 | 旧脚本与新视频时长不同 | 扩展视频到45s（setpts=RATIO*PTS） |
| 9 | Whisper 把"壹目贯维"听成"壹目贯为" | 同音字错误，MiniMax review 也会漏检 | 对照原始脚本逐字核对品牌名 |

### 字幕硬烧录方案（2026-05-12 更新）
1. `video_raw.mp4`（干净无字幕） + 完整 `audio_voiceover.wav` → 扩展到音频时长 → `video_extended.mp4`
2. Whisper ASR 提取真实时间轴（CPU 模式，--device cpu）
3. MiniMax M2.7 review 修正文字（繁→简，品牌名逐字核对）
4. **SRT手动控制换行**：每行≤20字符，前半句末尾断句
5. **FFmpeg subtitles 滤镜**烧录（WenQuanYi 字体，FontSize=20px + PlayRes=1920×1080）
6. vision 逐帧验证（t=1s / 中部 / 末尾 三帧必查）

### Scripts/
| 脚本 | 状态 |
|------|------|
| `minimax_image.py` | ✅ 正常 |
| `minimax_tts.py` | ✅ 正常 |
| `minimax_video.py` | ✅ 正常 |
| `wechat_publisher.py` | ✅ 正常 |
| `burn_subtitles.py` | ⚠️ 备用；FontSize=24 已修正（旧版 48px 太大） |

---

## 旧版问题汇总（来源：OpenClaw handoff）

| # | 问题 | 状态 |
|---|------|------|
| 1 | Windows zip → 文件名含字面 `\\\\`，目录结构丢失 | ✅ 已修复 |
| 2 | `generate_*.py` 散落项目根目录 | ✅ 已清理 |
| 3 | `video_no_voice.mp4` 规格错误（1364×768） | ⚠️ 待用户决定 |
| 4 | v1/v2/v3 版本命名 | ✅ 已整合进 Production/ |
| 5 | `04_review/review_log.json` 缺失 | ✅ 已创建 |
| 6 | TTS 与视频时长不匹配 | ✅ 已解决（音轨重建） |
| 7 | 字幕与音频不同步 | ✅ 已解决（ASR时间轴+字幕重烧） |
