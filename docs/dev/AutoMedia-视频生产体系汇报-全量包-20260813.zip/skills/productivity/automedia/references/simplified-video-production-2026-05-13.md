# 简化视频生产路径 — 5段封面图均分法（2026-05-13验证）

## 背景

本次双话题生产（特朗普访华74秒 / 模型用量39秒）验证了简化路径B的可行性：

- 话题1（311字口播）：5段覆盖，Whisper 32 segments均分，每段约14.9秒
- 话题2（179字口播）：5段覆盖，Whisper 19 segments均分，每段约7.9秒

Vision Review结论：质量优秀/合格，可上线。

## 完整流程

```
① TTS 生成音频 → 锁定时长
② Whisper ASR → 获取 segments（仅用于分段，不依赖精确时间轴）
③ 把音频按时间均分 N 段（如5段）
④ 每段：
   - 取一张封面图（PIL 加载，resize到1080×1920）
   - 聚合该段所有 Whisper segments 的 text
   - PIL 在封面图底部烧录字幕（55pt/WenQuanYi/黑边白字）
   - FFmpeg 图片→视频片段（时长=段时长）
⑤ concat filter 合并所有片段
⑥ 合并音频 → video_final
```

## 品牌名必死检测

Whisper ASR 对「壹目贯维」的误识别模式：
- `一目惯为` / `壹目惯为` / `壹目关维` / `一木贯维` / `一目关为`

每次 Whisper 识别后必须检测：
```python
brand_aliases = ["壹目贯维", "一目惯为", "壹目惯为", "壹目关维", "一木贯维", "一目关为"]
for seg in whisper_result["segments"]:
    for alias in brand_aliases:
        if alias in seg["text"]:
            print(f"⚠️ 疑似品牌名误识别: '{alias}' → 应为 '壹目贯维'")
```

## 核心参数

| 参数 | 值 |
|------|-----|
| 分段数 | 5 |
| 封面图比例 | 9:16（1080×1920） |
| 字幕字号 | 55pt |
| 字体 | /usr/share/fonts/truetype/wqy/wqy-zenhei.ttc |
| 字幕颜色 | 白色字+黑色描边 |
| MarginL | 80px |
| MarginV | 120px |
| 每行字符数 | ≤18 |
| concat方式 | concat filter（不能用demuxer） |

## 本次生产数据

| 话题 | 音频时长 | 每段时长 | 视频大小 |
|------|---------|---------|---------|
| 特朗普访华 | 74.66s | ~14.9s/段 | 3651KB |
| 模型用量 | 39.71s | ~7.9s/段 | 1591KB |