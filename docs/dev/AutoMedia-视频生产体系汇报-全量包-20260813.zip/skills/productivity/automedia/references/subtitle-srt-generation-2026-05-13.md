# 字幕同步标准 vs SRT生成教训 (2026-05-13)

## 用户确认的标准参考视频

**Harness v7f** (`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Production/20260510_harness-engineering/03_video/video_final_v7f.mp4`)
- 用户在 05-12 晚验收通过
- SRT: `/tmp/harness_subtitle_v7f.srt`
- 特征：一行一句字幕，语音和字幕完全同步，无堆叠

**对比**: Harness v14 和 DeepSeek v14 是同一天的重建版本，但 v7f 才是用户最终确认的标准

---

## 核心规则：一行一句

> **字幕同步铁律（用户表述）**：一段语音播放的时间内，屏幕上有且只有这段语音对应的文字。不多，不少，不重叠。

**正确效果** (v7f 标准):
```
1
00:00:00,000 --> 00:00:02,800
你知道AI最大的问题是什么吗？

2
00:00:02,800 --> 00:00:05,600
不是能力不够，是不听话。
```

**错误效果** (05-13 特朗普/模型用量视频):
```
1
00:00:00,000 --> 00:00:01,640
特朗普回来了，

2
00:00:01,800 --> 00:00:04,000
这次不是总统身份，

3
00:00:04,120 --> 00:00:06,000
是带着一帮商人来的。

4
00:00:06,280 --> 00:00:07,560
上次他访华

5
00:00:07,560 --> 00:00:10,440
签了2535亿美元大单，
```
→ PIL烧录时4-6个碎片entry同时出现，画面底部堆了4行字幕，乱糟糟

---

## 错误根因

SRT生成直接用了Whisper原始segments作为entry，把一句话的语音片段切成了3-4个碎片entry。

**正确做法**：每个SRT entry必须是**一句完整的话**，而不是Whisper的语音切分边界。

Whisper segments只是时间参考，文本必须按**标点符号+语义完整性**重新组织成完整句子。

---

## SRT生成强制流程

1. **对照原始口播脚本** — 确认每句话是否完整
2. **不以Whisper切分为准** — Whisper只提供时间轴，文本按完整句子组织
3. **完整句子 = 一个SRT entry** — 句号/问号/感叹号结尾才算完整
4. **未完整句子（逗号/顿号结尾）** — 要么并入前一个entry，要么并入下一个entry，不能独立存在
5. **PIL逐Entry烧录** — 每个entry烧一帧，entry时长=下一个entry开始时间-当前entry开始时间

---

## 验证方法

视频生成后，用vision review查3帧：
- t=1s附近：检查字幕是否只显示一句
- t=中部：检查字幕是否与语音同步（不多不少）
- t=末尾：检查字幕是否完整收尾

如果看到多行字幕堆叠 → SRT生成违反了"一句一字"规则，需要重建。

---

## v10 教训：音频版本混乱导致完全不同步（2026-05-13）

**Trump案例**：
- Whisper在 `/tmp/trump_radio_host.mp3`（新TTS，59.7s）上跑
- 视频烧录用的是项目目录里的旧音频（74.5s）
- 字幕时间轴（0-59s）和视频音频（0-74s）完全不匹配

**Model案例**：同款问题

**铁律**：TTS生成后，立即将新音频复制到项目文件夹替换旧文件。Whisper和视频烧录必须用同一个文件。不得在`/tmp`和项目文件夹各留一份。

## v10 教训：SRT文本必须用MiniMax脚本，不得直接用Whisper ASR

**Trump案例**：Entry 8 显示"多平台只能发布"，脚本原文是"多平台智能发布"。Whisper把"智能"听成"只能"，SRT直接用了Whisper文本。

**必错关键词检测**：
- 壹目贯维 → Whisper听成 → 壹目惯为 / 一目冠为 / 一目贯为
- 智能发布 → 只能发布
- 蹭热点 → 刺热点 / 蹭RE点

**铁律**：SRT文本以MiniMax脚本为准，Whisper只提供时间戳。生成后烧录前，逐字核对品牌名和关键词。

## v10 教训：SRT时间戳必须等于Whisper JSON真实segment边界

**Model案例**：Entry 3 时间戳写`8.20-13.00`秒，但Whisper JSON里对应segment实际从`10.80s`开始（差2.6s）。

**根因**：用「字数÷预计语速」估算时间戳，而不是用Whisper JSON的实际`start/end`值。

**正确做法**：
```python
# 从Whisper JSON读真实segment边界
with open('whisper_result.json') as f:
    d = json.load(f)
entry_start = d['segments'][n]['start']   # 精确值
entry_end   = d['segments'][n]['end']     # 精确值
```

## v10 教训：burn_subtitles.py烧录后视频时长会偏离

**实测**：音频59.7s → 烧录后64.5s（多4.8s）；音频45.9s → 烧录后64.5s（多19s）。

**铁律**：每轮烧录后必须执行精确截断：
```bash
ffmpeg -i burned.mp4 -t AUDIO_DURATION -c:v copy -c:a copy output.mp4
```

## 完整SRT重建流程（v10确认版）

```
1. TTS生成 → 立即复制到项目文件夹替换旧文件
2. Whisper ASR（在新音频上）→ whisper_result.json（含真实start/end）
3. 构造SRT：
   for each 完整句子 in MiniMax脚本:
       find 对应Whisper segment（从头到尾顺序扫描）
       start = segment['start']      # 用真实值
       end   = segment['end']        # 用真实值
       text  = MiniMax脚本原文       # 不用Whisper ASR文本
4. 核对"壹目贯维"+"智能/只能"等关键词
5. burn_subtitles.py 烧录
6. ffmpeg -t AUDIO_DURATION 截断
```

---

**amplitude scan方法**：见 `references/amplitude-scan-srt-split.md`。

**Trump v11 实测**：Entry 8 原长18秒（98字符），amplitude scan在41-60s音频段找到两个静音间隙：
- 44.6-45.2s（0.6s沉默）→断点1
- 54.4-55.9s（1.5s沉默）→断点2
- 8a结束时TTS语速23.7c/s偏快（3.16s读完75字符），但TTS就是这样，不接受也得接受



- **SRT时间格式**：逗号毫秒 `00:00:00,000`
**Whisper设备**：`/home/renanzai/mamba/envs/whisper/bin/python3`（hermes venv torch不完整）
**PIL烧录**：路径B Fallback必须用PIL，FFmpeg ASS有concat视频seek bug
**品牌名检测**："壹目贯维" Whisper必听成近音字，必须逐字对照脚本核对

---

## Per-Entry TTS 技法（2026-05-14 新增）

### 问题

所有 entry 合并为一段 TTS → Whisper 输出 15-29 个碎片 segments（按逗号/停顿切分）→ 映射到 6-10 个 script entry 的算法复杂且不稳定（贪婪匹配会产生重复分配、跳号）。

实测案例（2026-05-14）：
- Xiaomi 6 entry → 单次 TTS 后 Whisper 产出 22 segments
- Renda 10 entry → 单次 TTS 后 Whisper 产出 29 segments
- 贪婪映射算法：entry1 被重复分配 7 次，entry3 跳号到 entry8

### 解法：Per-Entry TTS + Concat + Whisper

```
每个 entry 独立 TTS（单独 MP3）
    ↓
所有 MP3 concat（ffmpeg concat demuxer）
    ↓
在拼接音频上跑 Whisper → 得到干净的 per-entry 时间轴
    ↓
按 whisper segment 边界划分 entry（逐 entry 对应一段连续 whisper segment）
    ↓
文本用 MiniMax 脚本原文（逐字核对品牌名）
```

**优点**：
- Whisper segments 和 script entries 一一对应，无需映射算法
- 每个 entry 的时间轴精确且可独立验证
- 碎片问题彻底消除

**操作步骤**：

```bash
# 1. 生成每个 entry 的 MP3
# （记录文件名和 entry 顺序的对应关系）

# 2. 拼接 MP3
ffmpeg -y -f concat -safe 0 -i concat_list.txt \
  -acodec libmp3lame -b:a 128k concatenated_audio.mp3

# 3. Whisper on 拼接音频
WHISPER_PY=/home/renanzai/mamba/envs/whisper/bin/python3
$WHISPER_PY -c "
import whisper, json
model = whisper.load_model('base', device='cpu')
result = model.transcribe('concatenated_audio.wav', language='zh', task='transcribe')
with open('whisper_result.json', 'w') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(f'Segments: {len(result[\"segments\"])}')
for i, s in enumerate(result['segments']):
    print(f'  [{i}] {s[\"start\"]:.2f}-{s[\"end\"]:.2f}s: {s[\"text\"].strip()[:40]}')
"

# 4. 人工审查 whisper segments 与 entries 的对应关系
#    打印所有 segments，手动确定每个 entry 的 start/end

# 5. 构建 SRT（文本用 MiniMax 脚本原文）
```

**关键点**：
- 拼接后的 Whisper segments 数量 ≈ entries 数量（而非 3-5 倍）
- 文件名→entry 顺序映射：用 TTS 返回的文件大小或 mtime 区分同名文件
- Entry 边界由相邻 whisper segment 之间的断点决定（不是算法推断）

### Entry 长度设计（字幕行数上限）

> 用户确认标准（2026-05-14）：任何时刻字幕不超过 3 行；设计目标 2 行（约 45 字）。

**脚本设计阶段**：每个 entry 不超过约 45 字（约 2 行 / 55pt 字体），为 3 行上限留 buffer。超过 45 字的 entry 在 TTS 前拆分。

**不合格案例**（2026-05-14 Xiaomi 原版 Entry 5）：
> "接下来就是'用得爽'的问题了——壹目贯维，帮你把AI做成内容。一键发到全网。想试试？扫码就行。"（~56 字，3-4 行 ⚠️）

**合格版本**（拆分后）：
> Entry 5a："接下来就是'用得爽'的问题了——壹目贯维，帮你把AI做成内容。"（~32 字，2 行 ✅）
> Entry 5b："一键发到全网。想试试？扫码就行。"（~22 字，1-2 行 ✅）

### Vision QA 流程

> 用户确认标准（2026-05-14）：任何时刻字幕不超过 3 行；长句允许但上限 3 行。

**三帧检查**（烧录完成后执行）：
```
t = 1s
t = 音频总时长 × 0.5（中段）
t = 音频总时长 - 5s（末尾前 5s）
```

**检查维度**：
1. 该帧字幕行数（≤ 3 行 ✅，> 3 行 ❌）
2. 字幕内容与脚本一致性
3. 品牌名"壹目贯维"正确出现（无近音字错误）

**通过条件**：三帧全部 ≤ 3 行。

**PIL 解释器**（烧录必须用）：
```
/home/renanzai/.hermes/hermes-agent/venv/bin/python3
```
不能用 mamba ffmpeg env 的 Python（3.14，无 PIL）。
