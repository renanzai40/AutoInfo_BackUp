# Business Topic Sourcing: Tavily Strategy v3 (2026-05-23)

## Problem (v2 Limitations)

v2 双流架构成功解决了"business 池为空"的问题，但 Tavily 返回的聚合站/SEO内容农场直接入库：

**2026-05-23 实测入库的垃圾信源：**
| Domain | 类型 | 质量 |
|--------|------|------|
| aiku.js (AI快讯网) | AI聚合站 | ❌ 内容质量差，TOP1 |
| didigallery.com (点点资讯) | 内容聚合 | ❌ 3条同日入库 |
| he-xie.com (鹤写AI) | 工具站+排行榜 | ❌ 工具站非新闻源 |
| aitools-list.com | 聚合站 | ❌ 无原创内容 |
| smzdm.com (什么值得买) | 消费导购站 | ❌ 商业导购非行业媒体 |
| csdn.net | SEO博客 | ❌ 内容农场，2026-05-13 TOP2 |

**根因**：`tavily_search` 函数只捕获 `title` + `score`，没有捕获 `url`，导致入库前无法按 domain 过滤。

---

## v3 三层架构

```
Tavily 原始结果
    ↓
Layer 1: 脚本 domain 黑名单过滤（已知垃圾信源秒级排除）
    ↓ 通过的写入 topics 表
Layer 2: 08:05 Agent 语义审核（Agent in the Loop）
    ↓ 审核通过 → 入 business 池
    ↓ 发现新垃圾信源 → domain 加入 blocked_domains（下次采集自动生效）
    ↓
08:30 推送：干净的 business 池
```

**时间线：**
- 08:00 脚本：~1.5 分钟（实际 08:00:58→08:02:24）
- 08:05 Agent 审核：~5-10 分钟（LLM 语义判断，25 分钟窗口）
- 08:30 推送：干净数据已就位

---

## Layer 1: Domain 黑名单（脚本级，硬编码）

**当前已知垃圾信源：**
```
csdn.net, blog.csdn.net           # CSDN 博客，SEO 内容农场
aiku.js                           # AI快讯网，AI 聚合站
didigallery.com, didi1.com        # 点点资讯，内容聚合
he-xie.com, hexieai.com          # 鹤写AI官网，工具站+排行榜
aitools-list.com                  # AI工具集，聚合站
smzdm.com                         # 什么值得买，消费导购站
aine ws.com, alinews.ai          # AI NEWS，英文聚合站
```

**关键修复：`tavily_search` 必须捕获 url**
```python
# 错误（当前）：
return [{'title': item['title'], 'score': item['score']}
        for item in data.get('results', [])]

# 正确（需要修复）：
return [{'title': item['title'], 'score': item['score'], 'url': item['url']}
        for item in data.get('results', [])]
```

---

## Layer 2: Agent 语义审核（Agent in the Loop）

**触发时间**：08:05（cron job）
**输入**：review_status='pending' AND source='Tavily' 的今日话题
**输出**：
- 干净话题 → review_status='approved'
- 语义垃圾 → review_status='rejected'
- 新发现垃圾信源 → 写入 blocked_domains 表

### Agent 审核 Prompt 逻辑

```
## 第一步：读取待审核话题
SELECT title, source_url, heat_score
FROM topics
WHERE review_status='pending' AND source='Tavily'
ORDER BY heat_score DESC

## 第二步：按 domain 分组呈现
按 domain 分组，列出每个 domain 的：
- 话题数量
- 代表标题（最多3条）
- Agent 判断：是否允许进入池子

## 第三步：逐 domain 判断
对于每个 domain，Agent 输出：
{
  "domain": "xxx.com",
  "action": "BLOCK|KEEP",
  "reason": "判断理由（BLOCK时必填）",
  "if_block": "该domain下所有话题都BLOCK"
}

## 第四步：执行 DB 操作
- BLOCK domain → 写入 blocked_domains 表
- 该domain下所有话题 → review_status='rejected'
- KEEP → review_status='approved'
- 删除 rejected 条目

## 第五步：输出报告
- 本次新增 blocked_domains
- 审核通过话题数
- 审核拒绝话题数
```

---

## DB Schema

### topics 表新增列
```sql
ALTER TABLE topics ADD COLUMN review_status TEXT DEFAULT 'approved';
ALTER TABLE topics ADD COLUMN source_url TEXT;
```

- 流1（平台热搜）：`review_status='approved'`，`source_url=NULL`
- 流2（Tavily）：`review_status='pending'`，`source_url='https://...'`

### blocked_domains 表
```sql
CREATE TABLE blocked_domains (
  domain TEXT PRIMARY KEY,
  blocked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  reason TEXT,
  blocked_by TEXT DEFAULT 'agent'
);
```

---

## 08:30 推送 Job SQL 改动

**当前（需改动）：**
```sql
WHERE status = 'pending'
```

**改动后：**
```sql
WHERE status = 'pending' AND review_status = 'approved'
```

---

## 黑名单自适应机制

```
每天采集 → Agent 审核 → 发现新垃圾信源
                                 ↓
                      写入 blocked_domains 表
                                 ↓
                    下次 Layer 1 自动生效
```

**效果**：黑名单随着使用不断丰富，新垃圾信源最多只进池子一次。

---

## Known Issues

- `--topic news` 参数有 bug，不要用，只用 `--time-range day`
- Tavily API 返回的 `url` 字段必须捕获，否则 Layer 1 无法工作
- B站 API 在 WSL 环境返回 -352，无法使用
