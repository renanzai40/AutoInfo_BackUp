# Tavily 自适应 Domain 黑名单系统（2026-05-23）

## 架构

```
Tavily 原始结果
    ↓ Layer 1: 脚本黑名单过滤（已知垃圾信源，秒级）
    ↓ Layer 2: Agent 语义审核（新垃圾发现，黑名单自动扩充）
    ↓ 干净数据进 topics 表
    ↓ 08:30 推送
```

## Layer 1: 脚本黑名单过滤

**执行时机**: tavily_search 结果去重**之前**，先过滤黑名单

```python
BLOCKED_DOMAINS = {
    'csdn.net', 'blog.csdn.net',
    'aiku.js', 'aiku.cn', 'aiku.com',
    'didigallery.com', 'he-xie.com',
    'aitools-list.com', 'smzdm.com',
    'leiphone.com', 'jiqizhixin.com',
    'ithome.com', 'freebuf.com',
    # 2026-05-23 Layer2 新增
    'my.hiredly.com', 'www.golftime.cn',
    'ahrefs.com', 'cn.indeed.com',
    'www.aitntnews.com', 'news.softunis.com',
    'www.pkuef.org', 'tchina.kyodonews.net',
    'pollo.ai', 'x.com',
}
```

## Layer 2: Agent 语义审核（08:05 cron job）

**Job ID**: `audit_08x05` | **调度**: `5 8 * * *`

1. 读取 `review_status='pending'` 的 Tavily 条目（带 source_url）
2. 按 domain 分组呈现 TOP N
3. 语义判断 → `review_status='approved'/'rejected'`
4. 新垃圾 domain → `blocked_domains` 表（`blocked_by='agent'`）

## DB Schema

```sql
ALTER TABLE topics ADD COLUMN review_status TEXT DEFAULT 'approved';
ALTER TABLE topics ADD COLUMN source_url TEXT;

CREATE TABLE blocked_domains (
    domain       TEXT PRIMARY KEY,
    blocked_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    reason       TEXT,
    blocked_by   TEXT DEFAULT 'agent',
    review_count INTEGER DEFAULT 0
);
```

## 08:30 SQL

```sql
WHERE status = 'pending' AND review_status = 'approved'
```

## 设计原则

- **无兜底 watchdog**: 08:05 失败 → 08:30 告警，不静默放行
- **黑名单先于去重**: 防止脏标题通过重名绕过 blocklist
- **失败可见**: 系统出问题应显示失败，不假装一切正常
