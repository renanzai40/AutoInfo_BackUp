# OPP/OL v0.2.0 更新记录（2026-05-22）

## OPP v0.2.0 新功能

- **`{文件名}_manifest.json`** — 每次 OPP 处理自动生成，包含：文件哈希(MD5)、工具版本、段落数/表格数/图片数、骨架信息（DOCX/PPTX）
- **`{文件名}.skeleton.zip`** — DOCX/PPTX 原始 ZIP 骨架，保存用于格式重建回滚
- **CLI**：`opp file.docx --target-format md` 自动生成 manifest + skeleton

## OL v0.2.0 新功能

- **YAML frontmatter 元数据头** — 翻译后的 `.md` 文件自动追加 YAML frontmatter（语言对/源文件名/版本/生成时间）
- **`--frontmatter` 开关** — 控制是否输出 frontmatter
- **XLIFF `<note from="OL">`** — 导出 XLIFF 时新增头部注释，兼容 Trados/MemoQ 等 CAT 工具

## book-localization 项目更新（2026-05-22）

项目路径：`/mnt/d/Hermes-Workspace/01-Projects/book-localization/`

### 本地仓库同步教训

**OMNI_Localizer 本地落后 11 commits，pull 时本地修改冲突**：

```bash
# 错误：git stash 会失败
git stash && git pull --ff-only  # → "local changes overwritten by merge"

# 正确：丢弃本地修改
git reset --hard HEAD && git clean -fd && git pull --ff-only
```

**根因**：本地 `.sisyphus/` 开发笔记与 origin/main 的正式 v0.2.0 内容冲突。

## 知识库 README 更新（2026-05-22）

- 新增「书籍文档本地化」段落（pipeline 图示）
- 添加 OPP/OL v0.2.0 release 链接
- commit hash: `63cc5a6`

## 仓库

- OPP: `1StepMore/Omni_Pre_Processor` — v0.2.0
- OL: `1StepMore/Omni_Localizer` — v0.2.0
