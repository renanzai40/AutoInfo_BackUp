# Cron Job 静默跳过根因分析 — 2026-05-17 复盘

## 事件概述

用户报告"今天的定时任务没有启动"。

实际调查结果：08:00 任务被静默跳过，08:30/07:30 在 08:57 手动触发（非定时），09:30 Watchdog 从未运行。

---

## 根因：事件循环静默跳过

### 触发链条

```
你从 07:45 开始交互 session
  → session 持续至 09:05（响应延迟 19 分钟）
Gateway 事件循环被 interactive session 占用
  → 08:00 tick 触发（每 60s 正常运行）
  → get_due_jobs() 检测到事件循环忙
  → 返回空列表（跳过执行，无错误日志）
  → jobs.json last_run_at 停在昨天（未更新）
  → 你未收到飞书消息
  → 无任何告警（静默跳过）
```

### 关键证据

```
agent.log（2026-05-17 08:00-08:59）：
- 每分钟都有 "context-sync 01:00 missed its scheduled time, fast-forwarding" 日志
- 这证明 cron ticker 每 60s 在正常触发
- 但没有任何 "Job '143d19e69a7c' running" 或类似记录
- 说明 tick() 跑起来了，但 get_due_jobs() 返回了空

errors.log（2026-05-17）：
- 有 Feishu send failed（delivery 问题），但那是 08:57 之后
- 没有 KeyError（排除之前的错误归因）
```

---

## 与 KeyError 的区别

| 特征 | KeyError（旧） | 事件循环静默跳过（本次） |
|---|---|---|
| 错误日志 | 有 AttributeError | 无 |
| jobs.json 更新 | 未更新 | 未更新 |
| 飞书消息 | 无 | 无 |
| 诊断方法 | `python3 -c "from cron.jobs import ..."` 查 schedule 类型 | 查 agent.log 有无 cron 执行记录 |
| 根因 | jobs.json 字段名不一致 | 事件循环被占用 |

---

## Watchdog 静默跳过的风险

Watchdog 是检查其他 job 状态的，但它本身也是一个 cron job，触发也依赖 tick()。

如果 Watchdog 被静默跳过，系统失去了自我诊断能力——用户不知道其他 job 也在被跳过。

### 解法：Watchdog 改为 no_agent 模式

Watchdog 不应依赖事件循环。改为 `no_agent=True`（纯脚本，独立 subprocess 运行）：

```bash
# jobs.json 中 watchdog 配置改为：
{
  "job_id": "wdog_auto_media",
  "name": "AutoMedia Watchdog 09:30 健康检查",
  "no_agent": true,
  "script": "python3 ~/.hermes/scripts/wdog_auto_media_check.py",
  "schedule": {"kind": "cron", "expr": "30 9 * * *", "display": "30 9 * * *"}
}
```

这样 watchdog 在独立 subprocess 运行，无论事件循环是否空闲都能触发。

---

## 诊断流程（下次快速定位）

```
第一步：查 jobs.json last_run_at
  → 停在昨天 → 可能是跳过， goto 第二步
  → 昨天之前 → 可能是 KeyError

第二步：查 agent.log 有无 "Job '143d19e69a7c' running"
  → 有执行记录 → 任务跑了，查 delivery 失败
  → 无执行记录 → 可能是事件循环占用 or KeyError

第三步：直接跑 get_due_jobs() 诊断
  cd ~/.hermes/hermes-agent && python3 -c "
  import sys; sys.path.insert(0, '.')
  from cron.jobs import load_jobs, get_due_jobs
  jobs = load_jobs()
  due = get_due_jobs(jobs)
  for j in due:
    print(f'DUE: {j[\"name\"]} next={j.get(\"next_run_at\")}')
  "
```

---

## 预防措施

### 措施1：Cron job 跳过时的明确日志

在 `get_due_jobs()` 或 `tick()` 里，当 job 因事件循环占用被跳过时，写入明确日志：

```
2026-05-17 08:00:00,123 WARNING cron.scheduler: Job '143d19e69a7c' SKIPPED - event loop busy (session 20260517_074552 running)
```

这样下次可以直接从日志判断根因，不需要读 agent.log 逐条排查。

### 措施2：定时任务执行状态卡

在 08:00/08:30/09:30 三个时间点，cron job 执行后推送状态卡到飞书：

```
⏰ AutoMedia 定时任务状态
08:00 热点采集：✅ 已执行（08:02）
08:30 话题池推送：✅ 已执行（08:30）
09:30 Watchdog：✅ 已执行（09:30）
```

如 job 被跳过，状态卡也应明确标注：
```
08:00 热点采集：⚠️ 跳过（事件循环忙，等待下次触发）
```

### 措施3：Watchdog no_agent=True

见上方"解法"部分。

---

## 教训（永久记录）

1. **"任务没启动"不等于"真的没运行"**：可能是延迟触发、可能是静默跳过、可能是 delivery 失败
2. **诊断顺序**：先查 jobs.json last_run_at → 再查 agent.log 执行记录 → 再查 errors.log → 最后判断根因
3. **cron job 依赖事件循环 = 有被 interactive session 阻塞的风险**，watchdog 必须独立
4. **静默跳过是最危险的风险**：没有日志，没有告警，用户以为没跑但实际上 tick 在跑只是跳过了
5. **cron job 跳过和 cron job 执行后 delivery 失败是两个不同问题**：前者 last_run_at 不更新，后者 last_run_at 更新但飞书没收到消息