# FFmpeg 字幕烧录核心坑（2026-05-19）

## ⚠️ ASS 时间戳格式：必须用小数点

**ASS格式：`H:MM:SS.CC`（秒.厘秒），不是 `H:MM:SS:CC`！**

```
正确：0:00:02.72
错误：0:00:02:72  ← FFmpeg静默失败
```

## burn_subtitles.py 的架构陷阱

第83行：`t = (frame_num - 1) / 2.0` — 硬编码，与 --fps 参数无关。

| 调用 | 效果 |
|------|------|
| `--fps 30` | 时间戳全部错位（快30倍） |
| `--fps 2` | 时间戳正确，但 re-encode 有时长漂移 |

**推荐：直接用 FFmpeg ASS 滤镜烧录。**

## 正确 ASS 生成 + FFmpeg 烧录

```python
def fmt_time_ass(t):
    h = int(t // 3600); m = int((t % 3600) // 60)
    s = int(t % 60); cs = int((t - int(t)) * 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"  # 小数点

FONT_SIZE = 55; PLAYRES = (1080, 1920); MARGIN_V = 120

ass = "[Script Info]\nScriptType: v4.00+\n"
ass += f"PlayResX: {PLAYRES[0]}\nPlayResY: {PLAYRES[1]}\n\n"
ass += "[V4+ Styles]\n"
ass += "Format: Name,Fontname,Fontsize,PrimaryColour,OutlineColour,Shadow,Bold,Alignment,MarginL,MarginR,MarginV\n"
ass += f"Style: Default,WenQuanYi Zen Hei,{FONT_SIZE},&H00FFFFFF,&H00000000,2,0,2,80,80,{MARGIN_V}\n\n"
ass += "[Events]\nFormat: Layer,Start,End,Style,Text\n"
for start, end, text in entries:
    text_esc = text.replace('\\', '\\\\').replace('\n', '\\N')
    ass += f"Dialogue: 0,{fmt_time_ass(start)},{fmt_time_ass(end)},Default,,0,0,0,,{text_esc}\n"

with open("subtitle.ass", "w", encoding="utf-8") as f:
    f.write(ass)
```

```bash
ffmpeg -y -i video_with_audio.mp4 -vf "ass=subtitle.ass" \
  -map 0:v:0 -map 0:a:0 -c:v libx264 -preset fast -crf 18 \
  -c:a aac -b:a 192k -shortest video_final.mp4
```

## Vision QA 的局限性

Vision 模型对同一帧的答案有随机性。**正确验证方式**：
1. 对每个 SRT entry，在其中间时间点 seek 提取帧验证
2. 检查 entry 边界时间点
3. 验证最后一个 entry 在视频末尾附近
4. 音频时长 ≈ 视频时长（差值 < 1s）是硬性门控

## 竖屏标准（1080×1920）

| 参数 | 值 |
|------|-----|
| FontSize | 55 |
| PlayResX/Y | 1080×1920 |
| MarginV | 120px |
| Alignment | 2（底部居中） |
| 单行安全字数 | ≤18字符 |
