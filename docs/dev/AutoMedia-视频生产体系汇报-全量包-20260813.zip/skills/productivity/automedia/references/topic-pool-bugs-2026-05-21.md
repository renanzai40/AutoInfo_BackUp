# 话题池 Bug 修复记录（2026-05-21）

> 记录今日（2026-05-21）发现的两个话题池 bug 及修复方案。

---

## Bug 1：`status='selected'` 话题未从池中剔除

**症状**：数据库有 6 条 `status='selected'` 的话题仍出现在 08:30 推送里。

**根因**：
- `auto_media_hot_collection.py` 的统计查询和 TOP5 打印均未加 `WHERE status != 'selected'`
- 08:30 cron job prompt 里虽有 `status = 'pending'` 但没有强调"selected 必须排除"

**修复（已执行）**：
- `auto_media_hot_collection.py` 第 452-464 行：所有 SQL 查询加 `AND status != 'selected'`
- cron job `7671da210b69` prompt：显式 SQL `WHERE status = 'pending'`，prompt 末尾加强调规则

**验证**：
```python
import sqlite3
conn = sqlite3.connect('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db')
cur = conn.cursor()
cur.execute("SELECT COUNT(*) FROM topics WHERE status='selected'")
print("selected话题:", cur.fetchone()[0])  # 应为 0
conn.close()
```

---

## Bug 2：Tavily 流混入 SEO/广告内容

**症状**：business 池 TOP5 出现"什么值得买"affiliate 文、"CSDN博客"SEO 教程、"立即体验xxx"广告文案。

**根因**：流2（Tavily）归一化后直接入库，没有 LLM 判断环节。

**修复（已执行）**：
- `auto_media_hot_collection.py` 新增第 4 步 `minimax_seo_filter()`
- Tavily 归一化后、入库前，调用 LLM 过滤以下类型：
  - SEO 内容农场：CSDN、什么值得买(zdm/smzdm)、IT之家、4399 等平台教程/导航/排行榜
  - 广告软文："立即体验"、"点击查看"、"限时"、"免费领取"、"扫码"等营销话术
  - SEO 标题特征："（2026年最新）"、"xxx技巧"、"如何xxx"等教程类
  - 无原创观点的转载/摘录

**清理已有脏数据（一次性）**：
```sql
DELETE FROM topics WHERE
    title LIKE '%什么值得买%'
    OR title LIKE '%CSDN%'
    OR title LIKE '%立即体验%'
    OR title LIKE '%(2026年最新)%'
    OR title LIKE '%限时%'
    OR title LIKE '%扫码%'
```

---

## 架构变更（v2 → v2.1）

```
流2（Tavily，v2）：归一化 → 直接入库
流2（Tavily，v2.1）：归一化 → LLM SEO过滤 → 入库
```

变更文件：
- `scripts/auto_media_hot_collection.py`：新增 `minimax_seo_filter()` 函数，修改入库逻辑
- `cron/jobs.json`（job ID `7671da210b69`）：prompt 更新
