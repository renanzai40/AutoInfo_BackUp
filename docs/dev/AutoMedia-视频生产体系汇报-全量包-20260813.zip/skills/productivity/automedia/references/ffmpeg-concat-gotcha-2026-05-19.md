# FFmpeg concat demuxer vs concat filter (2026-05-19)

## The Problem

FFmpeg's **concat demuxer** (`-f concat -safe 0 -i list.txt`) with `duration` directives is **unreliable** for image sequences. Declares `4.5` but actual output is `4.0` or `2.0`. This causes video duration ≠ audio duration, breaking subtitle burn-in.

## Why TS Segmentation Works

TS (MPEG-2 Transport Stream) files are self-contained. Concatenating pre-encoded TS files with the concat **filter** always produces the correct sum.

## Verified Pipeline

Each image → TS at exact duration → concat filter → exact total duration.

```python
import subprocess

SEG_DIR, OUTPUT, SEG_COUNT, FPS = "/tmp/segments", "/path/to/output.mp4", 8, 30

for i in range(SEG_COUNT):
    subprocess.run([
        "ffmpeg", "-y", "-loop", "1", "-i", f"{SEG_DIR}/img_{i}.png", "-t", "4.5",
        "-vf", "scale=1080:1920:force_original_aspect_ratio=increase",
        "-pix_fmt", "yuv420p", "-c:v", "libx264", "-preset", "fast", "-r", str(FPS),
        f"{SEG_DIR}/seg_{i:02d}.ts"
    ], check=True)

inputs = []
for i in range(SEG_COUNT):
    inputs.extend(["-i", f"{SEG_DIR}/seg_{i:02d}.ts"])

filter_str = "".join([f"[{i}:v]" for i in range(SEG_COUNT)]) + f"concat=n={SEG_COUNT}:v=1:a=0[outv]"
subprocess.run(["ffmpeg", "-y"] + inputs + [
    "-filter_complex", filter_str, "-map", "[outv]",
    "-c:v", "libx264", "-preset", "fast", "-crf", "18", "-pix_fmt", "yuv420p", OUTPUT
], check=True)

dur = subprocess.run(
    ["ffprobe", "-v", "quiet", "-show_entries", "format=duration", "-of", "csv=p=0", OUTPUT],
    capture_output=True, text=True).stdout.strip()
assert abs(float(dur) - SEG_COUNT * 4.5) < 0.2

subprocess.run([
    "ffmpeg", "-y", "-i", OUTPUT, "-i", "/path/to/audio.wav",
    "-c:v", "copy", "-c:a", "aac", "-shortest",
    OUTPUT.replace(".mp4", "_with_audio.mp4")
], check=True)
```

## burn_subtitles.py re-encode: exact frame count

h264 encoder defaults to 25fps. 72 frames at 2fps → 52-59s instead of 36s.

Fix: use `-frames:v N` and remove `-shortest`:

```python
cmd = [
    FFMPEG, "-y",
    "-framerate", str(fps), "-i", pattern,
    "-i", audio_src,
    "-map", "0:v", "-map", "1:a",
    "-c:v", "libx264", "-preset", "fast", "-crf", "23",
    "-pix_fmt", "yuv420p",
    "-r", str(fps),
    "-frames:v", str(len(frames)),
    "-c:a", "aac", "-b:a", "128k",
    output
]
```

## Image cleanliness check (MANDATORY before video construction)

`c_*.png` files in `03_video/` are often already burned with old subtitle text (bottom ~15% of frame). Always verify images from `02_images/` directory with Vision QA before building video. Do not assume images are clean.

## Duration verification checklist

After concat: actual duration must match expected (error < 0.1s). If mismatch → do not proceed.

After audio merge with `-shortest`: video ≈ audio (error < 0.5s). If video > audio + 1s → `-shortest` failed, use exact frame count instead.
