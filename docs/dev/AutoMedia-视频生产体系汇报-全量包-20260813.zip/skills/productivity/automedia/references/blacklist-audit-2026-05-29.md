# 黑名单审计记录（2026-05-29）

## 审计背景

AutoMedia Layer 2 审核 Job（audit_08x05）报告发现：
1. 同一游戏话题（MAMIYA）被 PChome 和 GNN 两个信源同时采集，分别被剔除和通过
2. `www.163.com` 被整域拉黑，但网易科技频道有大量正规 AI 报道
3. `x.com` 被标记为 spam，但 X 是 AI 开发者发布动态的正规渠道

**核心问题**：黑名单粒度太粗，把"某主流媒体的一篇差文章"当成"整个域名都该拉黑"。

## 审计方法

每次修改黑名单前，必须先查近7天实际采集记录，再做判断：

```python
cur.execute("""
    SELECT title, source_url, review_status
    FROM topics
    WHERE source_url LIKE '%' || ? || '%'
    AND created_at >= datetime('now', '-7 days')
    ORDER BY created_at DESC
""", (domain,))
```

## 2026-05-29 审计结论

### REMOVE（已从黑名单移除）

| Domain | 原因 | 审计数据 |
|---|---|---|
| `www.163.com` | 网易科技有正规AI报道 | 近7天4条，✅2/❌2，通过率50% |
| `www.iyiou.com` | 亿欧主站有记者署名AI报道 | 近7天2条，✅1/❌1，通过率50% |
| `x.com` | X是AI开发者动态正规渠道 | 近7天3条 approved（Luma/PixVerse/Claude） |

### UPDATE（已改为子站隔离）

| Domain | 变更 | 原因 |
|---|---|---|
| `apple.com` → `podcasts.apple.com` | 主域移除，子站隔离 | Apple主域有AI新闻稿/开发者公告，Podcast索引页是内容聚合无新闻价值 |

### KEEP（spam类，已验证无approved）

| Domain | 原因 |
|---|---|
| `seogkd.com` | 内容聚合站，无原创 |
| `www.aiyjs.com` | AI研究所tag聚合 |
| `www.aihub.cn` | AIHub tag聚合 |
| `medisan.sld.cu` | 可疑URL含异常参数 |
| `caifuhao.eastmoney.com` | 财富号自媒体标题党（子站隔离） |
| `news.pchome.com.tw` | 游戏新闻聚合无原创（子站隔离） |

### 暂不移除，继续观察

| Domain | 原因 | 审计数据 |
|---|---|---|
| `cnblogs.com` | 需要更多样本判断 | 近7天2条，✅0/❌2，样本不足但博客园有技术好文 |
| `segmentfault.com` | 需要更多样本判断 | 近7天1条，✅0/❌1，一篇软文不代表整域 |
| `www.aastocks.com` | 股票资讯站非AI新闻源定位清晰，但偶有AI金融报道 | 近7天2条，✅1/❌1 |

### 待定（近30天无采集记录）

- `www.aitntnews.com`、`news.softunis.com`、`www.pkuef.org`

## 新分层架构

```
Layer 1（硬过滤）：只杀明确spam，不杀主流媒体主域
    ↓
Layer 2（LLM Gate，新增）：判断内容是否与AI相关
    ↓
Layer 3（语义审核）：质量判断 + 黑名单精准更新（基于子站/频道）
```

详见：`automedia` skill → 分层过滤架构（Layer 1 / 2 / 3 + 黑名单精细化）

## 备份文件

- `Pool/blocked_domains_BACKUP_20260529_101038.json` — 44条完整备份
- `Pool/blacklist_refactor_SQL.sql` — 待执行的修正版SQL脚本
- `Pool/blacklist_refactor_PLAN.md` — 完整改革方案文档