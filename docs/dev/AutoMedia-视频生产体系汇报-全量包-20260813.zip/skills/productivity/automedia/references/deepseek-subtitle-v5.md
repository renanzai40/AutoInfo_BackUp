# DeepSeek v5 字幕修复实录（2026-05-12）

## 问题描述

deepseek_final_v4 存在字幕重叠问题：用户反馈"字幕重叠"。

**根因**：`rebuild_deepseek2.py` 的 concat 时长计算错误：
```python
# 错误写法（相邻 entry 重叠）
gap = srt[i+1]['start'] - srt[i]['end']
seg_dur = entry['dur'] + gap   # ← 这会让 seg 延伸到下一个 entry 的时间段
```

## 正确做法

**concat 时长公式**：
```python
for i, (s, e, text) in enumerate(SRT_ENTRIES):
    nxt = SRT_ENTRIES[i+1][0] if i+1 < len(SRT_ENTRIES) else s + (e - s)
    dur = nxt - s   # ← start-to-next-start，不叠加
```

## FFmpeg concat：对 JPG 序列用 filter，不用 demuxer

concat demuxer（`file 'xxx.jpg'\nduration X\n`）对 JPG + duration directives 支持不稳定，输出视频经常被截断。

**正确方法：用 concat filter**：
```bash
# 构建输入参数
INPUTS=""
for i in $(seq -w 0 19); do INPUTS="$INPUTS -i /tmp/ds/seg_${i}.mp4"; done

# 用 filter_complex concat
ffmpeg -y $INPUTS \
  -filter_complex "[0:v][1:v][2:v]...concat=n=20:v=1:a=0[outv]" \
  -map "[outv]" -c:v libx264 -preset fast -crf 23 \
  /tmp/ds/video_only.mp4

# 再合并音频
ffmpeg -y -i /tmp/ds/video_only.mp4 -i /tmp/voiceover.mp3 \
  -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest \
  /tmp/ds/final.mp4
```

## 完整工作流

```python
# rebuild_deepseek_v5.py（经验证可用）
from PIL import Image, ImageDraw, ImageFont
import subprocess, os

FONT = '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc'
FONT_SIZE = 50; IMG_W, IMG_H = 1080, 1920
MARGIN_H = 130; LINE_SPACING = 8

VIDEO_SRC = '/tmp/deepseek_video_final.mp4'  # 原始无字幕视频
AUDIO = '/tmp/deepseek_voiceover.mp3'
OUT = '/tmp/deepseek_final_v5.mp4'

SRT_ENTRIES = [
    (0.0,   2.8,  'DeepSeek融资450亿美元，很多人只看到数字——但这跟你有什么关系？'),
    (2.8,   4.8,  '很多人只看到数字。'),
    # ... 共20条
]

os.makedirs('/tmp/ds_v5', exist_ok=True)

# Step 1: 提取帧 + 烧录字幕
for i, (s, e, text) in enumerate(SRT_ENTRIES):
    frame_file = f'/tmp/ds_v5/frame_{i:02d}.jpg'
    burned_file = f'/tmp/ds_v5/burned_{i:02d}.jpg'
    subprocess.run(['ffmpeg','-y','-ss',str(s),'-i',VIDEO_SRC,
                    '-frames:v','1','-q:v','3',frame_file], capture_output=True)
    burn_subtitle(frame_file, text, burned_file)

# Step 2: concat 时长 = start-to-next-start
concat_items = []
for i, (s, e, text) in enumerate(SRT_ENTRIES):
    nxt = SRT_ENTRIES[i+1][0] if i+1 < len(SRT_ENTRIES) else s + (e - s)
    dur = nxt - s
    concat_items.append((f'/tmp/ds_v5/burned_{i:02d}.jpg', max(0.001, dur)))

# Step 3: 生成每段视频（-loop 1 + -t duration）
for frame, dur in concat_items:
    seg_file = f'/tmp/ds_v5/seg_{i:02d}.mp4'
    subprocess.run([
        'ffmpeg', '-y', '-loop', '1', '-i', frame, '-t', str(dur),
        '-vf', 'fps=25', '-c:v', 'libx264', '-preset', 'fast', '-crf', '18',
        '-pix_fmt', 'yuv420p', '-r', '25', seg_file
    ], capture_output=True)

# Step 4: concat filter（不用 demuxer）
# 拼接所有 -i 参数用 filter_complex concat=n=20:v=1:a=0

# Step 5: 合并音频
subprocess.run([
    'ffmpeg', '-y', '-i', video_only, '-i', AUDIO,
    '-map', '0:v', '-map', '1:a', '-c:v', 'copy', '-c:a', 'aac',
    '-b:a', '192k', '-shortest', OUT
], capture_output=True)
```

## 幅度扫描结果（20条 Entry）

| Entry | 时间 | gap比例 | 状态 |
|-------|------|---------|------|
| 1 | 0.0-2.8 | 29% | OK |
| 2 | 2.8-4.8 | 20% | OK |
| 3 | 4.8-6.8 | 30% | OK |
| 4 | 6.8-8.6 | 39% | ⚠️ 静默0.7s |
| 5 | 8.6-10.0 | 36% | ⚠️ 静默0.5s |
| 6 | 10.0-13.0 | 20% | OK |
| 7 | 13.0-15.6 | 31% | ⚠️ |
| 8 | 15.6-19.6 | 45% | ⚠️ 跨3段 |
| 9 | 20.6-23.4 | 32% | ⚠️ |
| 10 | 23.4-26.6 | 34% | ⚠️ |
| 11 | 26.6-29.6 | 30% | OK |
| 12-16 | 30.2-40.8 | <25% | OK |
| 17 | 40.8-42.8 | 55% | ⚠️ 静默1.1s |
| 18 | 42.8-44.8 | 30% | ⚠️ |
| 19 | 44.8-46.6 | 50% | ⚠️ 静默0.9s |
| 20 | 46.6-50.4 | 32% | ⚠️ |

**v5 状态**：重叠问题已解决（concat 时长修正）。13个 Entry 静音间隙问题未处理（用户未要求）。

## 水印说明

deepseek_video_final.mp4 底部有细小水印文字（"茂之灵会"等），这是原视频自带的水印，不是字幕叠加。Reburning 时水印会保留在画面中，属于原视频自带内容，不需要消除。
