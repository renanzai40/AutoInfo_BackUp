#!/usr/bin/env python3
"""
amplitude_scan.py — 音频幅度扫描，返回静音/语音段边界
用于验证 TTS SRT 时间戳是否与实际音频节奏匹配。

用法:
    python3 amplitude_scan.py <audio.mp3> [threshold]
    python3 amplitude_scan.py harness_voiceover.mp3 0.1

输出: 每行一个时间点 + 幅度值 + SILENCE/SPEECH 状态
用于快速定位: 哪个 SRT Entry 区间内有多个语音段（需要拆分）
"""
import subprocess, sys, math, array, wave, re

def scan(audio_path, threshold_pct=0.1):
    """返回 [(t, rms, is_speech), ...]"""
    # Convert to wav if needed
    wav_path = audio_path
    if not audio_path.endswith('.wav'):
        wav_path = '/tmp/scan_tmp.wav'
        r = subprocess.run(['ffmpeg', '-y', '-i', audio_path,
                            '-ar', '8000', '-ac', '1', wav_path],
                           capture_output=True)
        if r.returncode != 0:
            print(f"FFmpeg error: {r.stderr[-200:]}", file=sys.stderr)
            sys.exit(1)

    with wave.open(wav_path, 'rb') as w:
        n_frames = w.getnframes()
        rate = w.getframerate()
        frames = w.readframes(n_frames)
        audio = array.array('h', frames)

    rms_list = []
    step = rate // 10  # 100ms windows
    for i in range(0, len(audio) - step, step):
        chunk = audio[i:i+step]
        rms = math.sqrt(sum(x*x for x in chunk) / len(chunk))
        rms_list.append((i / rate, rms))

    max_rms = max(r for _, r in rms_list)
    thr = max_rms * threshold_pct

    print(f"# {audio_path} | threshold={thr:.0f} (peak={max_rms:.0f}, {threshold_pct*100:.0f}%)")
    print("time,rms,state")
    for t, r in rms_list:
        state = "SPEECH" if r > thr else "SILENCE"
        print(f"{t:.2f},{r:.0f},{state}")

    if wav_path != audio_path:
        import os
        os.unlink(wav_path)

def find_speech_segments(audio_path, srt_path=None, threshold_pct=0.1):
    """
    找音频中的语音段，并可选地与 SRT Entry 对比。

    Args:
        audio_path: TTS 音频文件
        srt_path: TTS SRT 文件（可选）
        threshold_pct: RMS 阈值百分比
    """
    wav_path = '/tmp/scan_tmp.wav'
    subprocess.run(['ffmpeg', '-y', '-i', audio_path,
                    '-ar', '8000', '-ac', '1', wav_path],
                   capture_output=True)

    with wave.open(wav_path, 'rb') as w:
        frames = w.readframes(w.getnframes())
        rate = w.getframerate()
        audio = array.array('h', frames)

    rms_list = []
    step = rate // 10
    for i in range(0, len(audio) - step, step):
        chunk = audio[i:i+step]
        rms = math.sqrt(sum(x*x for x in chunk) / len(chunk))
        rms_list.append((i/rate, rms))

    max_rms = max(r for _, r in rms_list)
    thr = max_rms * threshold_pct

    # Find speech segments
    segments = []
    in_speech = False
    seg_start = 0
    for t, r in rms_list:
        if r > thr and not in_speech:
            seg_start = t
            in_speech = True
        elif r <= thr and in_speech:
            segments.append((seg_start, t))
            in_speech = False
    if in_speech:
        segments.append((seg_start, len(audio)/rate))

    print(f"\n=== SPEECH SEGMENTS ({len(segments)} found) ===")
    for i, (s, e) in enumerate(segments):
        print(f"  [{s:.2f}→{e:.2f}] dur={e-s:.2f}s")

    # If SRT provided, check each entry
    if srt_path:
        with open(srt_path) as f:
            blocks = f.read().strip().split('\n\n')
        entries = []
        for block in blocks:
            lines = block.strip().split('\n')
            if len(lines) >= 3:
                m = re.match(r'(\d{2}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2}),(\d{3})', lines[1])
                if m:
                    s = int(m.group(1))*3600 + int(m.group(2))*60 + int(m.group(3)) + int(m.group(4))/1000
                    e = int(m.group(5))*3600 + int(m.group(6))*60 + int(m.group(7)) + int(m.group(8))/1000
                    entries.append((s, e, '\n'.join(lines[2:])))

        print(f"\n=== SRT ENTRY vs SPEECH MATCHING ({len(entries)} entries) ===")
        for i, (es, ee, text) in enumerate(entries):
            # Count speech segments inside this entry
            inside = [(s2, e2) for s2, e2 in segments
                      if max(es, s2) < min(ee, e2)]
            entry_dur = ee - es
            if len(inside) > 1:
                print(f"  ⚠️  [{i+1:02d}] {es:.2f}→{ee:.2f} | {len(inside)} SPEECH segs | '{text[:30]}'")
                for s2, e2 in inside:
                    print(f"       speech: [{s2:.2f}→{e2:.2f}]")
            elif len(inside) == 0:
                print(f"  🔇 [{i+1:02d}] {es:.2f}→{ee:.2f} | NO SPEECH | '{text[:30]}'")
            else:
                pct = (inside[0][1]-inside[0][0]) / entry_dur * 100 if entry_dur > 0 else 0
                flag = " ⚠️ GAP" if pct < 70 else ""
                print(f"  OK  [{i+1:02d}] {es:.2f}→{ee:.2f} | {pct:.0f}% speech{flag} | '{text[:30]}'")

    import os
    os.unlink(wav_path)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)

    audio = sys.argv[1]
    thr = float(sys.argv[2]) if len(sys.argv) > 2 else 0.1
    srt = sys.argv[3] if len(sys.argv) > 3 else None

    find_speech_segments(audio, srt, threshold_pct=thr)
