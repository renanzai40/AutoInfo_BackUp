# FFmpeg 图片序列已知 Bug（2026-05-19 汇总）

## concat filter 对图片序列产出错误时长（2026-05-19）

**症状**：concat filter 处理多张图片，每张声明 4.5s，8 张预期 36s，实际产出 4.5s

**根因**：concat filter 在处理纯图片输入时，对输入流的帧率/时长解析有边界 bug。FFmpeg concat 滤波器设计预期输入是连续视频流，不是离散图片帧。

**已验证可靠的解法：TS 分段法**

```bash
# Step 1: 每张图片独立编码为 MPEG-TS（精确时长）
for i in 1 2 3 4 5 6 7 8; do
  ffmpeg -y -loop 1 -i "img_${i}.png" -t 4.5 \
    -vf "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2" \
    -pix_fmt yuv420p -c:v libx264 -preset fast -r 30 \
    "/tmp/seg_$(printf '%02d' $((i-1))).ts"
done

# Step 2: concat filter 合并 TS 文件
ffmpeg -y \
  -i /tmp/seg_00.ts -i /tmp/seg_01.ts -i /tmp/seg_02.ts -i /tmp/seg_03.ts \
  -i /tmp/seg_04.ts -i /tmp/seg_05.ts -i /tmp/seg_06.ts -i /tmp/seg_07.ts \
  -filter_complex "[0:v][1:v][2:v][3:v][4:v][5:v][6:v][7:v]concat=n=8:v=1:a=0[outv]" \
  -map "[outv]" -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p \
  "output.mp4"
```

验证：`ffprobe -v quiet -show_entries format=duration -of csv=p=0 output.mp4` → 应为 36.000s

---

## concat demuxer 对图片序列声明时长不精确

**症状**：concat demuxer 的 `duration` directives 声明 2.07s，实际产出 4s

**根因**：FFmpeg concat demuxer 对 `duration` directive 解析精度有限，特别是声明时长与实际帧率不匹配时

**禁用**：不要用 concat demuxer 处理图片序列。只用 TS 分段法。

---

## h264 re-encode 时忽略 -r 参数导致时长错误

**症状**：输入是 72 帧 2fps 图像序列，re-encode 后视频变成 52.5s（72×25/2）

**根因**：h264 编码器默认输出 25fps，`-r` 参数在 re-encode 时只影响输入帧率

**解法**：加 `-frames:v N` 强制精确帧数
```bash
ffmpeg -y -framerate 2 -i "frame_%06d.jpg" \
  -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p \
  -r 2 -frames:v 72 \   # 强制输出帧率和精确帧数
  output.mp4
```

---

## 图片序列输出视频的 ffprobe 时长可能四舍五入

**症状**：`ffprobe` 报告 30.000000s，实际是 30.08s

**解法**：以帧数/fps 计算预期时长：`python3 -c "print(72 / 2.0")` → 36.0s
