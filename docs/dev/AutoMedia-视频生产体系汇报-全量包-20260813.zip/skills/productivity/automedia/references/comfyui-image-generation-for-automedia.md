# AutoMedia 内文配图 + 封面生成 — ComfyUI

> **2026-06-25 用户纠错固化**：内文配图使用 ComfyUI（SD 1.5），**不再使用 MiniMax 生成图片**。MiniMax 仅用于音乐/视频生成。

## 使用方式

**脚本**: `~/.hermes/profiles/content/scripts/gen_ui_images.py`

```bash
python3 scripts/gen_ui_images.py /path/to/project
```

自动生成：
- `01_content/drafts/wechat/images/wechat_img_{1,2,3}.png`（内文配图，512×512）
- `02_images/cover/cover_16x9.png`（640×360）
- `02_images/cover/cover_9x16.png`（360×640）
- `02_images/cover/cover_3x4.png`（512×512）

## ComfyUI 状态

| 项目 | 值 |
|------|-----|
| 地址 | `http://127.0.0.1:8188` |
| Checkpoint | `v1-5-pruned-emaonly.safetensors`（SD 1.5） |
| GPU | NVIDIA GTX 1660 Ti 6GB |
| 工作流 | `sd15_txt2img.json`（标准 txt2img） |
| 启动 | `comfy launch --background` |

## 调用方式

直接通过 REST API 提交 prompt，不依赖 `run_workflow.py` 脚本（该脚本有序列化兼容问题）。

关键参数：
- steps=20, cfg=7, sampler=euler, scheduler=normal
- 负面 prompt: `blurry, low quality, distorted, watermark, text, signature`

## 参考

- `creative/comfyui` skill — 完整 ComfyUI 文档和工作流
- `productivity/automedia-production-guard` skill — Gate II（内文配图）要求
