# 热点采集四平台方案 (2026-05-12, v2 双流架构)

## 平台决策

**定时采集：4平台**
- 微博 / 知乎 / B站 / 抖音
- 微信公众号、小红书：暂不纳入（无稳定免费API）

**内容发布：5平台**
- 微信公众号 + 知乎 + 小红书 + 抖音 + B站

---

## 数据源：双流并行

### 流1：热搜流（保障泛热度话题）

| 平台 | API | type参数 | 热度字段 |
|------|-----|---------|---------|
| 微博 | `https://uapis.cn/api/v1/misc/hotboard` | `type=weibo` | hot_value（实数） |
| 知乎 | `https://uapis.cn/api/v1/misc/hotboard` | `type=zhihu` | hot_value=**0**（无效） |
| B站 | `https://api.bilibili.com/x/web-interface/ranking/v2?rid=0&day=3` | —（直连API） | 有真实播放量 |
| 抖音 | `https://uapis.cn/api/v1/misc/hotboard` | `type=douyin` | hot_value（实数） |

4平台 × TOP15 = 最多60条原始数据。

**知乎/B站热度为0的 workaround**：用排名位置做 proxy 热度（rank1=15分, rank2=14分... rank15=1分）。

### 流2：AI新闻搜索（专门补 business 池）

**数据源**：Tavily 网络实时搜索（支持按时间范围过滤，确保时效性）

**时效性要求**：`--time-range day`（只保留最近24小时内的 AI 新闻）。

**搜索关键词（8组并行，均为AI内容生产行业相关）**：
- `AI 大模型 最新进展 新闻`
- `AI视频生成 行业资讯`
- `AI配音 语音合成 新闻`
- `AIGC 创作平台 新闻`
- `AI营销内容 工具动态`
- `AI 研究突破 最新资讯`
- `AI 大模型 行业动态 最新`
- `中国AI大模型 周调用量最新`

每组取 TOP15，合并后最多120条原始数据，去重后取 TOP15。

**Tavily 命令格式**：
```bash
tvly search "AI视频生成 行业资讯" --time-range day --max-results 15 --json
```

**注意**：`--topic news` 参数当前版本有 bug，去掉不用，只用 `--time-range day` 过滤即可。

**注意**：流2的目的不是覆盖所有AI话题，而是保证 business 池始终有时效性强的 AI 相关话题可选。

---

## 入库工作流（三层，v2 双流架构）

```
流1：4平台热搜 TOP15 × 4 = 60条
     ↓
第一层：MiniMax 语义去重（同一事件只保留热度最高的一条）
     ↓
第二层：按热度排序，取 TOP20
     ↓
第三层：MiniMax 话题分类（growth / business）→ 写入 pool.db

- 流2：Tavily AI网搜（8组关键词×15条），合并后最多120条
     ↓
第一层：MiniMax 语义去重（同一事件只保留热度最高的一条）
     ↓
第二层：按 score 排序，取 TOP15
     ↓
第三层：直接标 category='business' → rank归一化写入 pool.db

合流去重：如果同一话题同时出现在流1和流2（MiniMax 判断为同事件），只保留一条，优先保留流1的分类结果
     ↓
最终入库：最多35条（流1 TOP20 + 流2 TOP15 合并后）
```

---

## 两流分类规则

### 流1 分类标准（MiniMax 判断）

- `growth`（引流款）：大众流量型，有传播潜力，面向泛受众（娱乐、社会热点、生活方式）
- `business`（业务款）：商业/专业型，有业务价值，面向特定行业人群（营销方法论、行业洞察、工具测评、商业趋势）

### 流2 分类标准

直接标 `category='business'`，不经过 MiniMax 分类判断。

---

## 去重方案

### 结论：不能用字符集合算法

```python
def title_similar(a, b):
    chinese_a = set(c for c in a if '\u4e00' <= c <= '\u9fff')
    chinese_b = set(c for c in b if '\u4e00' <= c <= '\u9fff')
    return len(chinese_a & chinese_b) > 5  # ← 阈值太低，误判严重
```

**问题**：常见中文字（如"中国""回应""问题"）重叠即触发，60条去重后变成全是抖音。

### 正确方案：MiniMax 语义去重

**只用来判断"是否同一事件"**，不负责排序。排序按热度数值来。

**注意**：MiniMax 有安全过滤，以下话题可能触发拒绝：
- 地缘政治（台湾/特朗普/世卫等）→ 被过滤
- 解决方案：去掉敏感话题再发，或接受部分话题无法去重

---

## uapis.cn 可用性验证（2026-05-12）

| 平台 | 状态 | 备注 |
|------|------|------|
| 微博 | ✅ | 50条，热度实数 |
| 知乎 | ✅ | 30条，热度=0 |
| B站 | ✅ | 100条，热度=0 |
| 抖音 | ✅ | 50条，热度实数 |
| B站直连API | ❌ | 返回-352（频率限制），不稳定 |

**B站直连API备用方案**（不稳定，仅备用）：
```
GET https://api.bilibili.com/x/web-interface/ranking/v2?rid=0&day=3
Headers: Referer=https://www.bilibili.com/
```

---

## MiniMax API 测试结果

| 测试内容 | 结果 |
|---------|------|
| 简单对话 | ✅ |
| 按热度凭空排序 | ❌ 拒绝（"不具备实时热度数据"） |
| 地缘政治话题 | ❌ 安全过滤 |
| 纯娱乐/科技话题去重 | ✅ 可用 |
| 话题分类（growth/business） | ✅ 可用 |

---

## 08:30 空池通知机制（2026-05-12 新增）

如果 08:30 执行时查询 pool.db 发现 `category='business'` 的话题数量为 0：

1. 在推送消息末尾添加空池提示
2. 群里消息用飞书 `@所有人` mention 语法
3. 提示用户手动建议一个业务话题方向

**飞书 @所有人 语法**：在文本中加入 `@所有人`，飞书可解析。

---

## v2 变更记录（2026-05-13）

- 新增流2：**Tavily 网络搜索 AI 新闻**（替代平台关键词过滤）
- 流2 直接标 business，不走 MiniMax 分类
- **时效性要求**：`--time-range day`，确保近24小时新报道
- 流2 改为每组 TOP15（合并后最多120条，取TOP15入库）
- 流2 关键词升级为AI内容生产行业关键词（AI视频生成/AI配音/AIGC创作平台/AI营销内容等8组）
- **热度归一化**：入库前按来源内排名归一化，流1各平台按rank 1.0→0.07，流2按score rank归一化，保证跨来源排序公平
- 两流独立去重，合并时做跨流去重
- 入库上限调整为最多35条（TOP20+TOP15）

---

## ⚠️ 已知问题：Prompt模式不执行算法（2026-05-13 新增）

**症状**：cron job prompt 里写了 rank 归一化公式，但入库数据仍是原始热度值。

**根因**：cron agent 的 prompt 描述了"1.0-(rank-1)×0.067"算法，但 agent 只能调用工具（terminal/execute_code），**不会执行 Python 数学运算**。prompt 里的公式描述永远不会被真正执行。

**已验证**：Python requests 在 WSL 环境 HTTPS 握手慢，MiniMax API 超时；subprocess curl 稳定可用。

**解法**：迁移到 `no_agent=True` 脚本模式 `scripts/auto_media_hot_collection.py`，所有算法直接在 Python 里执行。

**相关文件**：
- 脚本：`scripts/auto_media_hot_collection.py`
- uapis.cn JSON 结构：`{"list":[...]}` 在根级，不是 `{"data":{"list":[...]}}`
- 知乎热度值：`'2636 万热度'` 格式，需 `re.search(r'[\d.]+', s)` 提取数字
- B站 API：WSL 环境返回 -352 错误，已禁用
