# Remotion 评估报告（2026-05-25）

> **结论**：Remotion bundler 在 WSL 环境下存在内部 bug，暂不可用。
> 视频生产继续使用现有 FFmpeg + PIL 工作流。

## 环境确认 ✅

| 组件 | 状态 | 路径/版本 |
|------|------|--------|
| Chrome headless | ✅ 可用 | `/home/renanzai/.cache/ms-playwright/chromium-1217/chrome-linux64/chrome` v147 |
| Node.js | ✅ v22.22.2 | npm 10.9.7 |
| FFmpeg | ✅ v8.1.1（libass enabled） | `/home/renanzai/mamba/envs/ffmpeg/bin` |

## 症状

```
Error: Module not found: Can't resolve 'path' in '/home/renanzai/Remotion-Test/node_modules/@remotion/bundler/css-loader'
    ╭─[11:13]
  9 │
 10 │ const {fileURLToPath} = require("url");
 11 │ const path = require("path");
    ·              ───────────────
```

## 根因

`@remotion/bundler/css-loader/utils.js`（bundler 内部 fork 的 css-loader v5.2.7）在 bundler 的 **build 时** 调用 `require("path")`。

Bundler 使用 Webpack 5（通过 rspack）来 bundler 自己的代码。在 build 阶段，bundler 的 Webpack 配置设置了 `resolve.fallback` 将 `path` 等 Node.js 内置模块 fallback 到 `false`，导致 `require("path")` 失败。

这个 bug 发生在 bundler 的内部构建进程中，不是用户代码问题，无法从外部配置覆盖。

## 尝试过的解法（全部失败）

| 方法 | 结果 | 原因 |
|------|------|------|
| `webpackConfig` 中 `resolve.fallback.path = false` | ❌ 失败 | bundler 在我们之前应用配置，我们的被覆盖 |
| `webpackConfig` 中 `alias: { path: require.resolve("path") }` | ❌ 失败 | 同上 |
| `rspack: true` 切换到 rspack | ❌ 失败 | 同样的 resolve 问题 |
| `Module._resolveFilename` monkey-patch | ❌ 失败 | bundler/rspack 不走 Node.js Module API |
| 降级到 v3.3.103 | ❌ 失败 | 同样的问题（fs → path） |
| 安装 `path-browserify` 并 alias | ❌ 失败 | bundler 在我们之前应用配置 |
| 手动 patch `css-loader/utils.js` 的 `require("path")` → `require("node:path")` | ❌ 失败 | bundler 在我们之前修改了文件 |

## 技术细节

- **报错文件**：`node_modules/@remotion/bundler/css-loader/utils.js` 第 11 行
- **Bundler 内部**：`@remotion/bundler` 使用 rspack 1.7.6 做 bundler 自身的构建
- **Webpack 配置**：`shared-bundler-config.js` 的 `getResolveConfig()` 没有配置 `path` fallback，但 bundler 应用配置时自动设置了
- **问题触发点**：bundler build 开始时，rspack 需要解析 css-loader，而 css-loader 的 utils.js 依赖 `path`

## 许可证确认 ✅

用户确认：**一人公司，免费版（≤3人）可用**，无需购买 Company License。

## 下一步

1. 视频生产继续使用现有工作流：`FFmpeg + PIL burn_subtitles.py`
2. 如需继续 Remotion 调研，建议：
   - 在非 WSL 环境（原生 Linux/macOS/Windows）测试 Remotion
   - 向 Remotion 官方报告此 bundler bug
   - 或者等待 Remotion 修复此问题

## 相关文件

- 测试项目：`/home/renanzai/Remotion-Test/`
- Bundler 源码：`node_modules/@remotion/bundler/dist/bundle.js`
- css-loader：`node_modules/@remotion/bundler/css-loader/utils.js`（第 11 行 `require("path")`）