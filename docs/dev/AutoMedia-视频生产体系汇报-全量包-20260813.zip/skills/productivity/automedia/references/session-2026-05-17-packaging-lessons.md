# 2026-05-17 打包与字幕教训

## 双话题项目拆分教训（永久规则）

**事故**：0514双子项目 `20260514_1000_dual-topics` 只拆了视频帧图，没有拆文案内容。用户打开zip后发现只有视频没有文案，说"必须都补上"。

**根因**：拆分时只看了视频文件（`renda_img_*`、`xiaomi_img_*`），没检查文案（wechat/zhihu/xiaohongshu 全部为空目录）。

**正确流程**：
1. 识别双话题项目（视频文件夹内有多个不同前缀）
2. **先检查每个子话题的文案完整性**：
   - `01_content/drafts/wechat/`（公众号）
   - `01_content/drafts/zhihu/`（知乎）
   - `01_content/drafts/xiaohongshu/`（小红书）
   - `01_content/script_final.txt`（口播脚本）
3. 缺失则立即基于字幕/SRT/视频内容生成，不告知用户
4. **文案补全后再打包**，不能只打包视频

---

## 打包前完整性检查（永久规则）

**检查清单（打包前必查）**：
```
项目目录存在？
  → 检查 01_content/drafts/wechat/、zhihu/、xiaohongshu/ 是否都有文件
  → 检查 01_content/script_final.txt 是否存在
  → 检查是否视频帧图-only（无文案）→ 告知用户，询问是否仍要打包
  → 有文案则检查字数是否达标（公众号≥1500、知乎≥1500、小红书≥300）
```

---

## burn_subtitles.py 更新（2026-05-17）

**新增功能**：
- `--title "大标题文本"`：视频大标题，黄色黑边（#FFD700），置画面上1/3处，全片持续显示
- 口播字幕MarginV从120→320（底部偏上离底1/6 @ 1080×1920）

**参数对照**：
| 类型 | FontSize | MarginV | 颜色 | 位置 |
|------|---------|---------|------|------|
| 视频大标题 | 72pt | 640（上1/3） | 黄#FFD700+黑描边 | 全片 |
| 口播字幕 | 55pt | 320（底部1/6） | 白+黑描边 | 每帧变化 |

**调用示例**：
```bash
# 无大标题
python3 burn_subtitles.py video.mp4 audio.wav subtitle.srt output.mp4 53.9

# 有大标题
python3 burn_subtitles.py video.mp4 audio.wav subtitle.srt output.mp4 62.7 --title "为什么你总错过AI红利"
```

---

## 品牌内容文件（用户发的）

用户说"发给我看看 brand 内容"时，先搜 session 记录确认具体指哪个：
- `brand-cta-review` skill（CTA审核Hard Gate规范）
- `brand-profile.md`（壹目贯维品牌轮廓，品牌身份/产品价值/CTA原则）

路径：`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/skills_backup_20260517_010000/automedia/references/brand-profile.md`