# FFmpeg Subtitles 字幕渲染坑（2026-05-19 重大更新）

## ⚠️ ASS 时间戳格式：必须用小数点（2026-05-19 新增）

**ASS 格式用 `H:MM:SS.CC`（秒.厘秒），不是 `H:MM:SS:CC`！**

```
正确：0:00:02.72
错误：0:00:02:72  ← FFmpeg 静默失败，字幕不渲染
```

**症状**：字幕烧录后，视频前半段乱跳、后半段消失。FFmpeg 不报错——它只是静默忽略。

```python
def fmt_time_ass(t):
    """ASS时间格式 H:MM:SS.CC（小数点）"""
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    cs = int((t - int(t)) * 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"  # ← . 不是 :
```

## burn_subtitles.py 的架构陷阱（2026-05-19 新增）

`scripts/burn_subtitles.py` 第83行：
```python
t = (frame_num - 1) / 2.0   # 硬编码！与 --fps 参数无关！
```

| 调用 | 提取帧 | 时间戳 | 结果 |
|------|--------|--------|------|
| `--fps 30` | 695帧 | `(n-1)/2` 错位30倍 | ❌ 完全错误 |
| `--fps 2` | 46帧 | `(n-1)/2` 正确 | ⚠️ 可用但有 re-encode 漂移 |

**推荐：直接用 FFmpeg 原生 `ass` 滤镜烧录，绕过此陷阱。**

## 正确 ASS 生成 + FFmpeg 烧录流程（2026-05-19）

```python
def fmt_time_ass(t):
    h = int(t // 3600); m = int((t % 3600) // 60)
    s = int(t % 60); cs = int((t - int(t)) * 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"

FONT_SIZE = 55; PLAYRES_X, PLAYRES_Y = 1080, 1920; MARGIN_V = 120

ass_lines = [
    "[Script Info]", "ScriptType: v4.00+",
    f"PlayResX: {PLAYRES_X}", f"PlayResY: {PLAYRES_Y}", "",
    "[V4+ Styles]",
    "Format: Name,Fontname,Fontsize,PrimaryColour,OutlineColour,Shadow,Bold,Alignment,MarginL,MarginR,MarginV",
    f"Style: Default,WenQuanYi Zen Hei,{FONT_SIZE},&H00FFFFFF,&H00000000,2,0,2,80,80,{MARGIN_V}",
    "", "[Events]", "Format: Layer,Start,End,Style,Text",
]
for start, end, text in entries:
    text_escaped = text.replace('\\', '\\\\').replace('\n', '\\N')
    ass_lines.append(f"Dialogue: 0,{fmt_time_ass(start)},{fmt_time_ass(end)},Default,,0,0,0,,{text_escaped}")

with open("subtitle.ass", "w", encoding="utf-8") as f:
    f.write('\n'.join(ass_lines))
```

```bash
# FFmpeg ASS 滤镜烧录（正确 PlayRes 已写入 ASS 文件）
ffmpeg -y -i video_with_audio.mp4 \
  -vf "ass=subtitle.ass" \
  -map 0:v:0 -map 0:a:0 \
  -c:v libx264 -preset fast -crf 18 \
  -c:a aac -b:a 192k -shortest \
  video_final.mp4
```

## Vision QA 的局限性（2026-05-19 新增）

**Vision 模型对同一帧图片的答案有随机性**，同一截图多次询问会得到不同回答。

**正确做法**：不依赖 Vision QA 作为唯一验证手段。
- 对每个 SRT entry，在其中间时间点 seek 提取帧验证
- 检查 entry 之间的**边界时间点**（entry 切换瞬间）
- 验证最后一个 entry 在视频末尾附近是否有字幕
- 音频时长 ≈ 视频时长（差值 < 1s）是硬性门控

## 竖屏 1080×1920 字幕标准（已确认）

| 参数 | 值 |
|------|-----|
| FontSize | 55 |
| PlayResX/Y | 1080×1920 |
| MarginV | 120px |
| Alignment | 2（底部居中） |
| 单行安全字数 | ≤18字符 |

## PlayRes 硬编码默认值问题

FFmpeg `subtitles` 滤镜默认 PlayRes=384×288。用 Python 生成 ASS 文件时，显式设置 `PlayResX: 1080 / PlayResY: 1920`，FFmpeg ASS 滤镜直接使用文件里的值，不再被默认值覆盖。
