# 草稿箱文件内容错位问题（2026-05-26）

## 问题现象

微信公众号草稿箱里有 13 篇草稿，但只有 3 篇是正确的。

具体问题：
- "AI造谣被处罚"草稿 → 实际内容是特朗普访华
- "实测豆包"草稿 → 实际内容是"大模型免费时代终结"
- "大模型免费时代"草稿 → 实际内容是"实测豆包预约餐厅"
- "10款AI视频"草稿 → 实际内容是中美元首会晤
- "阿里财报"草稿 → 实际内容是中美元首会晤

## 根本原因

多 agent 并行生成时，文件虽然放在了正确的项目目录里，但内容是错的。

三类错位：
1. **内容互换**：doubao-yuyue-canlou 和 doubao-shoufei-llm 两个子项目的 wechat_draft.html 内容互换了
2. **内容放错项目**：AI造谣被处罚的真实内容在 20260514_renda-speech 项目里，但草稿箱里放的是 trump-china-visit 项目的内容
3. **内容未生成**：10款AI视频这个 topic 根本没有生成正确内容

## 验证方法

每次上传草稿前，必须用 h1 标题交叉验证内容是否匹配（已固化到 wechat-upload-checklist skill 的 Gate 流程）：

```python
import re, json
from pathlib import Path

def verify_wechat_html_h1(html_path, project_info_path):
    with open(project_info_path, encoding='utf-8') as f:
        info = json.load(f)
    expected_topic = info.get("topic", "").strip()
    
    with open(html_path, encoding='utf-8') as f:
        html = f.read()
    h1_match = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.DOTALL)
    actual_h1 = re.sub(r'<[^>]+>', '', h1_match.group(1)).strip() if h1_match else ""
    
    if not actual_h1:
        return {"passed": False, "reason": "无h1标题"}
    
    topic_keywords = [w for w in expected_topic if len(w) >= 2][:4]
    if topic_keywords:
        match_ratio = sum(1 for kw in topic_keywords if kw in actual_h1) / len(topic_keywords)
        if match_ratio < 0.5:
            return {
                "passed": False,
                "reason": f"h1与topic不符：h1=\"{actual_h1}\" expected=\"{expected_topic}\""
            }
    
    return {"passed": True}
```

## 正确文件位置（2026-05-26 实测）

| 草稿名称 | 正确文件路径 |
|---------|------------|
| AI造谣被处罚 | `20260514_renda-speech/01_content/drafts/wechat/wechat_draft.html` |
| 实测豆包 | `20260519_092124_dual-topics/doubao-yuyue-canlou/01_content/drafts/wechat/wechat_draft.html` |
| 大模型免费时代 | `20260519_092124_dual-topics/doubao-shoufei-llm/01_content/drafts/wechat/wechat_draft.html` |
| 阿里财报 | `20260524_122819_dual-topics/ali-ali-reports/01_script/v1_raw/v1_ali_wechat.md` |
| 10款AI视频 | 未找到正确内容，需要重新生成 |

## 防御措施

1. **上传前验证 h1**（已固化到 wechat-upload-checklist skill 的 Gate 流程）
2. **同日期多话题项目命名**：20260519_092124_dual-topics/doubao-yuyue-canlou 和 doubao-shoufei-llm 结构完全相同，并行 agent 非常容易写错路径
3. **publish_log.json 里的 title 字段**：可以用来交叉验证草稿箱里的标题是否与 project_info 一致