# 话题新鲜度衰减

## 规则

- 采集当天 freshness_score = 10.0
- 第二天 = 9.0，第三天 = 8.0... 每天 -1
- 最低 6.0（不继续衰减）
- 不在采集当天扣分，从第二天才开始

## SQL 衰减更新（每日 07:30 执行）

```sql
UPDATE topics
SET freshness_score = MAX(
    6.0,
    10.0 - CAST(julianday('now') - julianday(created_at) AS INTEGER)
),
    updated_at = datetime('now')
WHERE status = 'pending' AND freshness_score > 6.0;
```

## 实时计算（查询时）

如果不需要持久化衰减，可以实时计算:

```sql
SELECT *,
    MAX(6.0, 10.0 - CAST(julianday('now') - julianday(created_at) AS INTEGER)) AS current_freshness
FROM topics
WHERE status = 'pending';
```

## 评分公式中的 freshness

- heat_score 范围 0-100，归一化: heat_score / 10 → 0-10
- freshness_score 范围 10.0-6.0
- correlation_score 范围 1-10

**引流款（growth）**:
  score = (heat_score/10) * 0.55 + correlation_score * 0.25 + freshness_score * 0.20
**业务款（business）**:
  score = (heat_score/10) * 0.25 + correlation_score * 0.55 + freshness_score * 0.20

---

## correlation_score 评分机制（score_correlation 函数）

位于 `auto_media_hot_collection.py`，关键词分级：

| 分级 | business分 | growth分 | 命中关键词示例 |
|------|----------|---------|--------------|
| Tier1 | 10 | 9 | AIGC/AI文案/AI视频/AI配音/数字人/内容生产/自媒体工具/DeepSeek/Kimi/Sora/可灵 |
| Tier2 | 8 | 7 | 大模型/GPT/深度学习/视频生成/语音合成/tts/英伟达/国产AI/OpenAI/Anthropic |
| Tier3 | 6 | 5 | 科技/互联网/芯片/新能源/电动汽车/电商/直播/短视频/数字化/出海 |
| Tier4 | 3 | 2 | 体育/足球/电影/综艺/游戏/天气/灾害/国际/外交/战争 |
| **Default** | **5** | **4** | 以上均未命中 |

### ⚠️ Default=5 过高导致的"行业概览PDF"问题（2026-05-24 新增）

**现象**：`[PDF] 行業概覽`（中国餐饮线上运营行业概览）综合分 4.917，排名 business TOP2。

**根因链条**：
1. `score_correlation()` 对"行业概览"等泛报告类标题不匹配任何 Tier → Default=5
2. 计算公式中 correlation 权重 55% × 5.0 = 2.75（占综合分 56%）
3. Tavily 流 freshness 默认 10.0（标准入库是 8.0，异常）→ 贡献 2.0（占 40%）
4. heat_score=0.6679 几乎无用（只贡献 3%）

**实际影响**：一个与壹目贯维业务（AI内容生产）gap 极大的餐饮行业报告，因为 freshness 异常偏高 + Default 相关性虚高，挤入 business TOP2。

**解法**：
- **A**：将 Default 降至 3（business）/2（growth）
- **B**：流2入库前加标题质量过滤，拒绝含"行业概览/行业报告/市场分析/PDF/市场报告"等关键词的泛报告类标题
- **C**（推荐）：Topic Selection Gate 增加判断——"这篇文章的结尾能否自然过渡到壹目贯维帮你做XXX"，不能则 Pipeline STOP

**实测数据**（2026-05-24）：
```
综合分 = 热度×0.25 + 相关性×0.55 + 新鲜度×0.20
       = 0.6679×0.25 + 5.0×0.55 + 10.0×0.20
       = 0.167 + 2.75 + 2.0 = 4.917

改 Default=3 后：
       = 0.6679×0.25 + 3.0×0.55 + 8.0×0.20
       = 0.167 + 1.65 + 1.6 = 3.417（跌至 business 中游）
```