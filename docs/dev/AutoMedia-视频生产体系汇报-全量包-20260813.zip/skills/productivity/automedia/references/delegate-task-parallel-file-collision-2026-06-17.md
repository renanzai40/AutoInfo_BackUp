# 并行 delegate_task 临时文件路径碰撞（2026-06-17）

## 症状

用 `delegate_task(tasks=[...])` 并行跑多个 subagent 写内容时，
每个 subagent 独立写临时文件到 `/home/renanzai/<filename>`。
如果多个 subagent 恰好用相同的文件名（如 `wechat_draft.html`），
后完成的 subagent 静默覆盖前一个的文件，主 agent 只拿到最后一个版本。

## 本次事故

**场景**：双话题（引流款 + 业务款）内容并行生产，用 delegate_task 3 个一批跑 2 批。

| 批次 | Task | 输出文件 | 结果 |
|------|------|---------|------|
| 第1批 | 引流款小红书 | `xiaohongshu-deepseek-copilot.md` ✅ | 唯一名，正常 |
| 第1批 | 引流款知乎 | `zhihu-copilot-deepseek-v4.md` ✅ | 唯一名，正常 |
| 第1批 | 业务款小红书 | `xiaohongshu-copilot-cowork-ga.md` ✅ | 唯一名，正常 |
| 第2批 | 引流款公众号 | `wechat_draft.html` ❌ | **被业务款公众号覆盖** |
| 第2批 | 业务款知乎 | `copilot-cowork-zhihu.md` ✅ | 唯一名，正常 |
| 第2批 | 业务款公众号 | `wechat_draft.html` ❌ | **覆盖了引流款版本** |

**后果**：引流款公众号内容丢失 → 主 agent 需手动重写（依据 research_notes + 回忆）。

**根因**：subagent 默认用 generic 文件名写入 `/home/renanzai/`，delegate_task `context` 中未要求使用 topic-unique 文件名。

## 防护规则

### 规则1：每个 subagent 用唯一文件名

在 delegate_task 的 `context` / `goal` 中显式指定包含 topic slug 的文件名：

```python
# ✅ 对
context="""
输出文件：/home/renanzai/wechat_draft_deepseek-v4.html
...
"""
```

### 规则2：固定文件名模板

| 平台 | 模板 |
|------|------|
| 公众号 | `wechat_draft_{topic_slug}.html` |
| 知乎 | `zhihu_{topic_slug}.md` |
| 小红书 | `xiaohongshu_{topic_slug}.md` |
| 视频脚本（通用） | `script_{topic_slug}.txt` |

### 规则3：复制后集中清理

```python
# 主 agent 中按 slug 模式匹配复制
import glob
for slug in ['deepseek-v4', 'copilot-cowork']:
    src = f"/home/renanzai/*{slug}*"
    # ...copy to project dir...

# 清理所有临时文件
import os
for f in os.listdir('/home/renanzai/'):
    if f.endswith(('.html', '.md', '.txt')) and not f.startswith('.'):
        os.remove(f'/home/renanzai/{f}')
```

### 规则4：断言防护

```python
import os
assert os.path.exists(f"/home/renanzai/wechat_draft_{slug_growth}.html"), \
    f"引流款公众号被覆盖或未生成"
assert os.path.exists(f"/home/renanzai/wechat_draft_{slug_biz}.html"), \
    f"业务款公众号被覆盖或未生成"
```

## 反模式

- ❌ 两个 subagent 写相同路径 + 文件名（即使不同批次）
- ❌ 只输出到 temp 不立即复制到项目目录（被覆盖后无备份）
- ❌ 误以为 subagent 的 `.md` / `.html` 输出会自动用不同名
