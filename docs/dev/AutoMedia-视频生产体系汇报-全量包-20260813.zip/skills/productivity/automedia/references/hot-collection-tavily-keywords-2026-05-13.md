# 流2 Tavily 关键词策略 (2026-05-13)

## 背景

流2 目的是为 business 池补充 AI内容生产行业 相关话题。
旧方案用宽泛关键词（"AI"/"大模型"/"LLM"）导致搜到大量 SEO 教程、LinkedIn 帖子，与业务无关。

新方案：**用 AI内容生产行业垂直关键词**，确保搜到的都是目标受众关心的内容。

## 最终验证有效的 8 组关键词

| # | 关键词 | 测试质量 |
|---|--------|---------|
| 1 | `AI 大模型 最新进展 新闻` | ✅ 稳定，真实媒体 |
| 2 | `AI视频生成 行业资讯` | ✅✅ 最佳，有真实融资/平台动态 |
| 3 | `AI配音 语音合成 新闻` | ✅ 好，CosyVoice2等技术新闻 |
| 4 | `AIGC 创作平台 新闻` | ⚠️ 一般，有好内容但有噪音 |
| 5 | `AI营销内容 工具动态` | ⚠️ 一般 |
| 6 | `AI 研究突破 最新资讯` | 待验证 |
| 7 | `AI 大模型 行业动态 最新` | 待验证 |
| 8 | `中国AI大模型 周调用量最新` | 待验证 |

## Tavily CLI 已知坑

- `--topic news` 参数有 bug（报错 `topic\n  Input should be 'general'`），**去掉不用**，只用 `--time-range day` 过滤即可

```bash
# 正确格式
tvly search "AI视频生成 行业资讯" --time-range day --max-results 15 --json
```

## rank 归一化公式

入库前对各来源按排名归一化，保证跨来源公平排序：

- 流1（各平台热搜）：`heat_score = 1.0 - (rank-1) × 0.067`（rank1=1.0, rank15=0.06）
- 流2（Tavily）：同样公式按 score 排序后的 rank 计算

这样知乎 rank1 和 Tavily rank1 的 score 都是 1.0，08:30 评分时各来源话题公平竞争。

## 调度器排错记录 (2026-05-13)

**问题**：cron tick 不执行任务，锁文件一直被 gateway 进程持有。

**诊断**：
```python
from cron.jobs import get_due_jobs
jobs = get_due_jobs()  # 查看当前有哪些任务到期
for j in jobs:
    print(j.get('name'), j.get('next_run_at'))
```

**根因**：PID 44015 的 gateway 进程持有 `.tick.lock` 独占锁，`fcntl.flock(lock_fd, LOCK_EX | LOCK_NB)` 失败导致 tick 直接返回 0。

**workaround**：绕过 scheduler 直接调用 `run_job()`：
```python
from cron.scheduler import run_job
from cron.jobs import get_job
job = get_job('job_id')
success, output, final_response, error = run_job(job)
```

**注意**：`trigger_job()` 只是把 `next_run_at` 设为当前时间，不会立即执行；下次 tick 才真正跑。

## 相关文档

- `references/hot-collection-4platform-2026-05-12.md` — 双流架构总览
- `references/cron-jobs-fix-2026-05-12.md` — Cron 任务配置记录
