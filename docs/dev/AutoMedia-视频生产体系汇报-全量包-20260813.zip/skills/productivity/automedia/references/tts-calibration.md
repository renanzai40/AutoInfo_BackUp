# TTS 速度标定 & Whisper 工作流

## MiniMax TTS 速度实测

模型: `speech-2.8-hd`, voice_id: `male-qn-qingse`

| Speed | 估算 chars/s | 271字耗时 |
|-------|-------------|-----------|
| 1.0 | ~5.0 | ~54s |
| 1.5 | ~7.9 | ~34s |
| 1.8 | ~9.1 | ~30s ← harness实测 |
| 2.0 | ~10.3 | ~26s |

Speed 估算公式:
```python
estimated_speed = (字数 / 目标时长) / 5.0
estimated_speed = max(1.0, min(2.0, estimated_speed))
```

## Whisper ASR

路径: `~/.hermes/hermes-agent/venv/bin/whisper`
模型目录: `~/.hermes/hermes-agent/venv/lib/python3.11/site-packages/whisper`
FFmpeg: `~/mamba/envs/ffmpeg/bin/ffmpeg`

⚠️ **GPU NaN Bug**: GTX 1660 Ti + PyTorch 2.11 + CUDA 驱动下，Whisper fp16 推理会在 encoder 输出 NaN。解法: 强制 `device='cpu'` (fp32)，速度可接受（30s音频约13s识别）。

```bash
env PATH=$FFMPEG_DIR:$PATH \
  whisper audio.wav \
  --model_dir ~/.hermes/hermes-agent/venv/lib/python3.11/site-packages/whisper \
  --model base \
  --language zh \
  --task transcribe \
  --output_format json \
  --output_dir /tmp/whisper/ \
  --device cpu
```

## 字幕标准（竖屏 1080×1920）

FFmpeg subtitles 滤镜的 `FontSize` 参数是相对于 ASS PlayRes（默认 384×288）渲染，不设置 PlayRes 实际字号会偏大约 5 倍（1920/384=5x）。

正确流程:
1. SRT 每行≤20字符（事前手动控制换行，不依赖 ASS 自动换行）
2. 转换 SRT→ASS，设置 PlayResX=1920 / PlayResY=1080
3. 烧录:
```bash
ffmpeg -y -i video_extended.mp4 -i audio_voiceover.wav \
  -vf "ass=/tmp/subtitle_for_burn.ass" \
  -map 0:v:0 -map 1:a:0 \
  -c:v libx264 -preset fast -crf 18 \
  -c:a aac -b:a 192k -shortest \
  video_final.mp4
```

字体参数: FontSize=20, MarginL=80, MarginR=80, MarginV=40, Alignment=2（底部居中）
