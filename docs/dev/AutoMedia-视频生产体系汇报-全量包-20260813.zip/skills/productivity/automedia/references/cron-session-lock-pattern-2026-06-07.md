# Cron Job session_lock 抢锁规范（2026-06-07 新增）

> 适用：所有 AutoMedia cron 触发（08:30 推送、Pre-production 抢锁等）使用 `session_lock.py` 的场景。

## 1. 两把锁的命名与职责

cron 8:30 推送阶段会用到 **两把不同的锁**，名字不同、职责不同：

| 锁名 | 触发时机 | 用途 |
|------|---------|------|
| `auto_media_top3_push` | 8:30 cron 推送前 | 防多 session 重复推送 TOP3 |
| `auto_media_pre_production` | 用户选完话题、Pre-production 启动前 | 防多 session 重复启动生产 |

**两次锁必须分别抢**，因为：
- 第一次抢（top3_push）= 推送期间防重复推送
- 第二次抢（pre_production）= 用户选择后到生产链路之间有用户思考期（5-30 分钟），期间其他 session 应可推送（如有），但生产一旦启动必须独占
- 锁名不同 → 不会误锁

## 2. 两种调用模式：CLI vs Context Manager

### 模式 A：CLI（`session_lock.py --name <lock> --hold N`）

```bash
python3 ~/.hermes/profiles/content/scripts/session_lock.py \
    --name auto_media_top3_push \
    --wait-timeout 5
```

**机制**：抢到锁后**持锁 `hold_sec` 秒**（默认 60s）后自动释放。
- `hold=0`（默认）→ `max(60, 0) = 60s`
- `hold=N`（N>0）→ N 秒
- `--wait-timeout N` → 抢不到锁时最多等 N 秒重试

### 模式 B：Python Context Manager（推荐用于 cron）

```python
import sys, os
sys.path.insert(0, "/home/renanzai/.hermes/profiles/content/scripts")
from session_lock import session_lock

with session_lock("auto_media_top3_push", timeout_sec=5, max_age_sec=3600) as got:
    if not got:
        print("⚠️ 抢不到 lock（其他 session 已在跑），静默退出")
        sys.exit(0)
    # 抢到锁后立即执行工作
    do_work()  # 持锁期间干完活
# 退出 with 块 → 自动释放 + unlink
```

**机制**：锁的持有时长 = `with` 块内代码执行时长。**没有空闲 sleep**。

## 3. ⚠️ 关键陷阱：CLI 模式 60s 默认持锁 vs 终端 60s 超时

### 症状

```
$ python3 session_lock.py --name auto_media_top3_push --wait-timeout 5
[Command timed out after 60s]  # 终端工具的默认超时
```

锁文件 `/tmp/session_lock_auto_media_top3_push.lock` 残留（0 字节）。

### 根因

1. `session_lock.py` CLI 默认 `hold_sec = max(60, args.hold) = 60`（因为 `args.hold` 默认 0）
2. 抢到锁后 `time.sleep(60)` 持锁
3. **Hermes 终端工具的默认超时也是 60s**（实测），terminal 把进程 SIGKILL
4. `fcntl.flock` 随进程退出由 kernel 自动释放 ✓
5. **但锁文件本身没被 unlink** ✗ —— `try/finally` 在 SIGKILL 下不执行
6. 下次启动 cron：lock 文件存在 → `_try_acquire_once` 第一次尝试 `flock(LOCK_EX|LOCK_NB)`：
   - flock 立即成功（因为之前 holder 已死）→ 理论上抢到锁
   - **真正问题**：多个 session 都用 CLI 模式跑 → 多个 60s 超时 → 多个 SIGKILL 累积

### 为什么不能完全靠 max_age 自动恢复

- `max_age_sec=3600`（1 小时）默认
- cron 8:30 触发的僵尸 lock 在 9:30 之前不会被自动 unlink
- 期间如果 flock 抢成功但 hold 又被 SIGKILL → 继续累积
- 飞书私聊用户收不到 TOP3 推送 → 用户在群里艾特、发现问题

## 4. ✅ 推荐修复：cron 用 Context Manager 模式

**核心**：把"抢锁 + 干完活 + 释放"塞进**一个 Python 脚本**，锁的持有时长 = 实际工作时间（< 5s），不用 CLI 的固定 60s sleep。

### 模板

```python
#!/usr/bin/env python3
"""AutoMedia cron 8:30 push — 一站式脚本（抢锁 + 查询 + 推送 + 备份 + 释放）。"""
import sqlite3, sys, os
from datetime import datetime

sys.path.insert(0, "/home/renanzai/.hermes/profiles/content/scripts")
from session_lock import session_lock

DB_PATH = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db"
LOCK_NAME = "auto_media_top3_push"
BACKUP_DIR = os.path.expanduser("~/.hermes/profiles/content/cron/output")
TODAY = datetime.now().strftime("%Y-%m-%d")
NOW_TS = datetime.now().strftime("%H:%M:%S")

with session_lock(LOCK_NAME, timeout_sec=5, max_age_sec=3600) as got:
    if not got:
        print("⚠️ 抢不到 lock（其他 session 已在跑），静默退出")
        sys.exit(0)
    # ↓ 持锁期间干所有活
    conn = sqlite3.connect(DB_PATH)
    # ... 查询、评分、生成推送文本 ...
    conn.close()
    # 写本地备份
    os.makedirs(BACKUP_DIR, exist_ok=True)
    with open(os.path.join(BACKUP_DIR, f"{TODAY}_0830_summary.md"), "w") as f:
        f.write(push_text)
# ↑ 退出 with 块 → 自动 unlink + 释放
```

### 优点

- 锁持有时长 < 5s（实际工作时间）
- SIGTERM 会触发 Python `finally`，正确 unlink（仅 SIGKILL 不会，但持有时间 < 5s 大幅降低概率）
- 多个 session 同时跑：先到的抢到锁，后到的 `sys.exit(0)` 静默退出
- 推送成功 + 备份完成都在锁内，最后输出最终推送文本

## 5. 🔧 僵尸 lock 应急恢复

如果发现 lock 文件残留（如 cron 推送失败）：

```bash
# 1. 确认是否真的有进程在持锁
lsof /tmp/session_lock_auto_media_top3_push.lock
# 期望：空输出（没有任何进程在用这个文件）

# 2. 手动 unlink（kernel 已自动释放 flock，安全）
python3 -c "
import os
p = '/tmp/session_lock_auto_media_top3_push.lock'
if os.path.exists(p):
    os.unlink(p)
    print('✅ unlinked:', p)
else:
    print('(file not present)')
"
```

**为什么安全**：
- fcntl.flock 在 inode 层面管理，unlink 文件只删目录项，不影响已建立的 flock
- 即使有进程"持锁"中，unlink 后新进程可以创建同名新文件 + flock 成功
- 双重保护：kernel 自动释放 + max_age 自动清理

## 6. 验证清单（每次 cron 推送后跑一次）

```bash
# 1. 锁文件应被自动清理
ls /tmp/session_lock_*.lock 2>/dev/null
# 期望：No such file or directory

# 2. 备份文件应存在
ls -la ~/.hermes/profiles/content/cron/output/$(date +%Y-%m-%d)_0830_summary.md
# 期望：文件存在，size > 1KB

# 3. pool.db 中推送的话题应保持 status=pending（cron 推送不修改 status）
python3 -c "
import sqlite3
conn = sqlite3.connect('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db')
cur = conn.cursor()
cur.execute(\"SELECT COUNT(*) FROM topics WHERE status='selected'\")
print('selected topics:', cur.fetchone()[0])
"
```

## 7. 相关文件

- `session_lock.py` — `~/.hermes/profiles/content/scripts/session_lock.py`
- 备份目录：`~/.hermes/profiles/content/cron/output/`
- pool.db：`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db`
- cron job 定义：`~/.hermes/cron/jobs.json`
