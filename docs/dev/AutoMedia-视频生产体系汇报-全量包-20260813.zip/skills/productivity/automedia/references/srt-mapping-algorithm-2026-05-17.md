# SRT字幕同步算法（2026-05-17 修订）

## 问题描述

SRT 字幕与音频不同步的根因：**Whisper segments 数 ≠ 脚本句子数时，无法用均分时长估算时间轴**。

### 错误做法（已废弃）

```python
# ❌ 错误：字数估算时长
estimated_chars_per_second = 5.0  # 假设语速
total_chars = len(script_text)
estimated_dur = total_chars / estimated_chars_per_second
per_sentence_dur = estimated_dur / len(sentences)
```

实测：音频 62.7s，脚本 331 字，估算得 `5.5 chars/s → 60.2s 估算时长`，第1句估算 `[0.00, 6.27]`，实际 Whisper 是 `[0.00, 8.08]`，偏差 **1.8秒/句**，累计误差。

## 正确做法：Whisper segment 边界映射

### 三步算法

**① 解析脚本句子**（保留标点）
```python
import re

def parse_sentences(script_text):
    parts = re.split(r'(?<=[。！？\n])', script_text)
    sentences = []
    for i in range(0, len(parts) - 1, 2):
        sentences.append(parts[i] + parts[i+1])
    return [s for s in sentences if s.strip()]
```

**② 按比例映射 Whisper segments**
```python
def build_srt_entries(whisper_json, sentences):
    segments = whisper_json['segments']
    n_whisper = len(segments)
    n_sent = len(sentences)
    segs_per_sent = n_whisper / n_sent  # e.g. 42/10 = 4.2

    entries = []
    for i, sent in enumerate(sentences):
        start_idx = int(i * segs_per_sent)
        end_idx = int((i + 1) * segs_per_sent)
        if i == n_sent - 1:
            end_idx = n_whisper

        start_ts = segments[start_idx]['start']
        end_ts   = segments[end_idx - 1]['end']
        entries.append((start_ts, end_ts, sent))
    return entries
```

**③ 超长 entry 拆分（>45字）**
```python
def split_long_entries(entries, max_chars=45):
    result = []
    for start_ts, end_ts, text in entries:
        if len(text) > max_chars:
            parts = re.split(r'([，,])', text)
            combined = []
            for j in range(0, len(parts) - 1, 2):
                combined.append(parts[j] + parts[j+1])
            sub_dur = (end_ts - start_ts) / len(combined)
            for k, sub_text in enumerate(combined):
                sub_start = start_ts + k * sub_dur
                sub_end   = start_ts + (k + 1) * sub_dur
                result.append((sub_start, sub_end, sub_text.strip()))
        else:
            result.append((start_ts, end_ts, text))
    return result
```

### 完整流程
```python
def generate_srt(whisper_json_path, script_path, output_srt_path):
    import json
    with open(whisper_json_path) as f:
        whisper = json.load(f)
    with open(script_path) as f:
        raw = f.read()
    lines = [l for l in raw.split('\n') if not l.startswith('【')]
    script_text = '\n'.join(lines).strip()

    sentences = parse_sentences(script_text)
    entries = build_srt_entries(whisper, sentences)
    entries = split_long_entries(entries)

    def fmt(t):
        h, m, s = int(t//3600), int((t%3600)//60), t % 60
        ms = int((t % 1) * 1000)
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    with open(output_srt_path, 'w') as f:
        for i, (s, e, t) in enumerate(entries, 1):
            f.write(f"{i}\n{fmt(s)} --> {fmt(e)}\n{t}\n\n")

    max_chars = max(len(e[2]) for e in entries)
    if max_chars > 45:
        raise Exception(f"SRT 自检失败：entry={max_chars}字 > 45字上限，需退回拆分")
    return entries
```

## 2026-05-17 实测案例

| 项目 | Whisper segments | 脚本句子 | segs/sent | 最大偏差 |
|------|-----------------|---------|-----------|---------|
| 引流款（特朗普） | 42 | 10 | 4.2 | ~1.8s/句 |
| 业务款（AI红利） | 27 | 10 | 2.7 | ~0.8s/句 |

**引流款第1句对比**：
- 均分估算：`[0.00, 6.27]`（误差 +1.8s）
- 正确映射：`[0.00, 8.08]`（Whisper segments 0-3 实际）

## Hook 集成

`auto_vision_qa.batch_vision_qa()` 已修复为 json 中转模式：
- 帧提取后写入 `/tmp/vqa_frames.json`
- 主 agent 用 `mcp_minimax_understand_image` 工具做 Vision 判断
- 失败则抛 Exception 阻止发送

## 已知限制

1. **比例映射仍是估算**：当 Whisper segment 边界和实际语音句子不完全对齐时，存在系统性偏移（约 0.2-0.4s）
2. **sub-entry 时段均分**：长句拆成 sub-entry 时，按时间均分，不考虑语速差异
3. **Whisper ASR 文本错误**：品牌名"壹目贯维"会被听成"壹目惯为"，**必须用脚本原文**，不要用 Whisper ASR 文本