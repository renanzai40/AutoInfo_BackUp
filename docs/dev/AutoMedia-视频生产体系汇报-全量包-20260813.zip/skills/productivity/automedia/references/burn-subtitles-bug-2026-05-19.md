# burn_subtitles.py Bug Record（2026-05-19）

## NoneType in-active_text Bug

**症状**：silent gap 帧（无字幕时段）渲染后为空白帧。

**触发条件**：`segments` 中某帧时间戳 t 不落在任何 entry 的 `[start, end]` 区间内 → `active_text=None` → 该帧执行了 Layer 1（大标题）但跳过了 Layer 2 → 视觉上只有大标题。

**根因**：
```python
# 错误代码
if '\n' in active_text:  # TypeError when active_text=None
```

**修复**（已在脚本中实现）：
```python
if not active_text:
    img.save(output_path, "JPEG", quality=92)
    return True
```

**教训**：处理可选值时，必须在字符串操作之前加 guard。
