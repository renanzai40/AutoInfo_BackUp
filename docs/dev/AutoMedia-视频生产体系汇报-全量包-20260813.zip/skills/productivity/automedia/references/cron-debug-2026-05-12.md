# Cron 任务故障诊断备忘（2026-05-12）

## 事件概要

三个 AutoMedia 定时任务（07:30/08:00/08:30）在 2026-05-12 全部未执行，`last_run_at` 始终为 null。

## 根因

`~/.hermes/cron/jobs.json` 中 `maintenance_01`（07:30 新鲜度维护）任务的 `schedule` 字段是**字符串** `'30 7 * * *'` 而不是 dict。

这导致 `tick()` → `get_due_jobs()` → `_get_due_jobs_locked()` 在处理该任务时崩溃：
```python
# cron/jobs.py 第 937 行
schedule = job.get("schedule", {})  # 返回字符串 '30 7 * * *'
kind = schedule.get("kind")         # AttributeError: 'str' object has no attribute 'get'
```

异常被静默捕获，**所有任务都无法执行**。

## 诊断过程

1. **确认 ticker 在跑**：gateway.log 有 "Cron ticker started" 但无 "stopped"
2. **检查 jobs.json**：发现 maintenance_01 的 schedule 是字符串
3. **直接调用 tick()**：抛出 AttributeError 而非正常执行
4. **修复**：将字符串 schedule 转为 dict

## 修复代码

```python
import sys
sys.path.insert(0, '/home/renanzai/.hermes/hermes-agent')
from cron.jobs import load_jobs, save_jobs

jobs = load_jobs()
for j in jobs:
    if isinstance(j.get('schedule'), str):
        expr = j['schedule']
        j['schedule'] = {'kind': 'cron', 'expr': expr, 'display': expr}
        print(f"Fixed: {j['name']}")
save_jobs(jobs)
```

## 验证

修复后调用 `tick()` 不再抛出异常，开始正常执行任务（可能因 MiniMax API 调用耗时长而超时，这是预期行为）。

## 预防措施

创建 cron 任务时，schedule 必须为 dict：
```python
{
  "schedule": {
    "kind": "cron",       # "cron" | "interval" | "once"
    "expr": "0 8 * * *",  # cron 表达式（kind="cron" 时）
    "display": "0 8 * * *"
  }
}
```

绝对不能直接传入字符串。Hermes cron 工具有效性检查应捕获此问题，但当前未捕获。

## 相关文件

- `~/.hermes/cron/jobs.json` — 任务定义
- `~/.hermes/hermes-agent/cron/scheduler.py` — tick() 实现
- `~/.hermes/hermes-agent/cron/jobs.py` — get_due_jobs() 实现
- `~/.hermes/logs/gateway.log` — cron ticker 日志

---

## 附：Cron Delivery 双重推送问题（2026-05-12）

### 症状
定时任务结果同时发到了**私聊和贯维内容生产群**两个地方。

### 根因
**AutoMedia 07:30** 任务的 `origin` 字段是布尔值 `true`（而非 dict）：
```json
{"origin": true, "deliver": "origin,feishu:oc_fb8771a1fb9b0214b99d7c28c03dbe7f"}
```

`_resolve_origin()` 对非 dict 类型返回 `None`，导致 `deliver="origin"` 解析失败，fallback 到 `FEISHU_HOME_CHANNEL`。

同时 `FEISHU_HOME_CHANNEL=feishu hermes`（`~/.hermes/.env`），该值无法被 `resolve_channel_name()` 解析成有效 chat_id，导致实际只发了 explicit DM 地址。但如果在某个时间点 `FEISHU_HOME_CHANNEL` 被设成过群 ID，就会变成**私聊 + 群的双重投递**。

08:00/08:30 的 `origin` 是正确的 dict，理论上不会触发此问题。

### 诊断命令
```python
cd ~/.hermes/hermes-agent && python3 -c "
from cron.scheduler import _resolve_delivery_targets
import json
with open('/home/renanzai/.hermes/cron/jobs.json') as f:
    jobs = json.load(f)['jobs']
for j in jobs:
    if 'AutoMedia' in j.get('name',''):
        targets = _resolve_delivery_targets(j)
        print(f'{j[\"name\"]}:')
        for t in targets:
            print(f'  -> {t}')
"
```

### 关键教训
- `origin` 必须是 dict，`{"platform": "feishu", "chat_id": "...", "thread_id": null}`
- `FEISHU_HOME_CHANNEL` 如果设成群 ID，`deliver="origin"` 就可能双重投递
- 排查时同时检查 `origin` 类型和 `FEISHU_HOME_CHANNEL` 当前值

### 双重投递修复（2026-05-12 已实施）

**需求**：任务结果要同时发到私聊和贯维内容生产群。

**方案**：在 `deliver` 里显式加上群 ID，不再依赖 `origin` 或 `FEISHU_HOME_CHANNEL`：

```
deliver: origin,feishu:oc_fb8771a1fb9b0214b99d7c28c03dbe7f,feishu:oc_fbc1c0b8faf60cf622b75904fd1f75cd
        ↑私聊(origin)  ↑私聊(explicit)   ↑贯维内容生产群(explicit)
```

调度器会自动去重，不会重复发送。Home Channel 保持私聊不变。

### 诊断命令（补充）

```python
# 验证 deliver 解析结果
cd ~/.hermes/hermes-agent && python3 -c "
from cron.scheduler import _resolve_delivery_targets
import json
with open('/home/renanzai/.hermes/cron/jobs.json') as f:
    jobs = json.load(f)['jobs']
for j in jobs:
    if 'AutoMedia' in j.get('name',''):
        targets = _resolve_delivery_targets(j)
        print(f'{j[\"name\"]}: {len(targets)} target(s)')
        for t in targets:
            print(f'  -> {t}')
"
```
正常：1个target（DM）。多个或出现群ID说明配置正确。

---

## 附：手动触发顺序（08:00 → 08:30 依赖）

### 教训（2026-05-12）
手动触发 08:30 之前，必须等 08:00 完成并验证 pool.db 有数据。

**原因**：
- 08:00 负责采集、去重、分类（growth/business）写入 pool.db
- 08:30 读取 pool.db 进行评分和汇总
- 如果 08:00 还没跑完或跑失败，pool.db 是旧数据或空数据，08:30 推的就是错误信息

**正确顺序**：
1. 确认 08:00 `last_status = ok` 且 pool.db 有今日数据
2. 再触发 08:30
3. 08:30 完成后（`last_status = ok`）才能触发生产链路

**验证命令**：
```bash
python3 -c "
import json, sqlite3
# 检查 job 状态
with open('/home/renanzai/.hermes/cron/jobs.json') as f:
    jobs = json.load(f)['jobs']
for j in jobs:
    if j['id'] in ('143d19e69a7c', '7671da210b69'):
        print(f'{j[\"name\"]}: last_run={j[\"last_run_at\"]}, status={j[\"last_status\"]}')
# 检查 pool.db 今日数据
db = '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db'
conn = sqlite3.connect(db)
cur = conn.cursor()
cur.execute(\"SELECT COUNT(*) FROM topics WHERE DATE(created_at) = DATE('now')\")
print(f'pool.db 今日入库: {cur.fetchone()[0]} 条')
cur.execute(\"SELECT COUNT(*) FROM topics WHERE category='business' AND status='pending'\")
print(f'business 池 pending: {cur.fetchone()[0]} 条')
conn.close()
"
```