# Remotion 视频工作流（2026-05-25 验证）

## 核心结论

Remotion 可以替代 automedia 的视频生产工作流，实现：
- **文字精确控制**：CSS 渲染，CJK 零乱码
- **字幕时间轴**：精确到帧（通过 TTS 实测时长计算）
- **动态内容**：数字滚动、粒子背景、关键词高亮、弹簧入场

---

## 完整工作流

```
1. TTS 生成（MiniMax hex 解码）
   - 每段生成独立 MP3
   - voice_id: "Chinese (Mandarin)_Radio_Host"

2. ffmpeg concat → 单 WAV 轨（解决5×<Audio>并发崩溃）
   - 原因：5×<Audio from={N}> 并发时 Remotion compositor 死锁
   - 修复：ffmpeg concat demuxer 预合并单 WAV，Remotion 用 1 个 <Audio> 组件

3. ffprobe 实测时长（音频是唯一真相）
   - wentech_concat.wav: 65.910s（TTS 报告 65.932s，差 0.022s）
   - s618_concat.wav: 102.741s（TTS 报告 102.807s，差 0.066s）
   - 必须用实测值建 Sequence，不用 TTS 报告的估算值

4. 计算帧边界（floor(dur × 30)）

5. Remotion 渲染（含 TTS 音频 + 字幕 + 动效）
```

---

## 关键修复：5×<Audio> 并发崩溃

**症状**：5 个 `<Audio src={segment}.mp3 from={N}>` 并发时
- Remotion compositor 在音频混合阶段死锁
- Chrome OOM / Session closed
- `wentech_concat.wav` 音频存在但输出视频损坏

**根因**：Remotion 的 Mediabunny 混合器在处理多并发音频时内存溢出

**解法**：
```bash
# Step 1: 每段转 WAV
for i in 1 2 3 4 5; do
  ffmpeg -y -i segment_${i}.mp3 -ar 24000 -ac 1 segment_${i}.wav
done

# Step 2: concat WAVs（demuxer）
echo "file 's1.wav'" > concat.txt
echo "file 's2.wav'" >> concat.txt
...
ffmpeg -y -f concat -safe 0 -i concat.txt -acodec pcm_s16le concat.wav

# Step 3: Remotion 只用 1 个 <Audio>
<Audio src={staticFile("audio/concat.wav")} />
```

---

## 动画特效能力

### 已验证可用

| 特效 | API | 示例 |
|------|-----|------|
| 弹簧弹入 | `spring({fps, config:{damping,stiffness}})` | 大标题、字幕、数据卡片入场 |
| 淡入淡出 | `interpolate()` opacity | 字幕淡入淡出、背景切换 |
| 粒子漂浮背景 | CSS `@keyframes` | `ParticleBackground` 组件（12粒子） |
| 数字滚动 | `spring()` + displayValue | 数据卡片（200亿/80亿） |
| 关键词高亮 | `dangerouslySetInnerHTML` + CSS | 闻泰/安世金色高亮 |
| 场景背景渐变 | `interpolate()` bgColor | 每段落切换背景色 |
| 工具卡片弹入（618） | `spring()` + 主题色边框 | 每款工具名弹入 |

### @remotion/transitions（已安装）

- `fade()` / `slide()` / `wipe()` / `flip()` / `iris()` / `zoomBlur()` / `dreamyZoom()` / `bookFlip()` / `linearBlur()` / `swap()` / `ripple()` / `crosswarp()` / `dissolve()` / `zoomInOut()`
- `<TransitionSeries>` + `<TransitionSeries.Transition>` + `<TransitionSeries.Overlay>`
- 注意：transition 期间两个场景同时渲染，总时长 = Σ(seq) - Σ(transition)

### Lottie（可选，需额外包）

```tsx
import { Lottie, LottieAnimationData } from "@remotion/lottie";
import { staticFile } from "remotion";
// JSON 放在 public/ 目录
<Lottie animationData={data} playbackRate={1} loop />
```

### 音频可视化（可选）

```tsx
import { visualizeAudio } from "@remotion/media-utils";
// 返回频谱数据，渲染柱状图/波形
```

### Skia（可选，GPU 加速）

```tsx
// bun add @remotion/skia @shopify/react-native-skia
// remotion.config.ts: enableSkia()
// index.ts: await LoadSkia() → registerRoot()
```

---

## 运行时关键

- **必须用 Bun**：npm 会触发 `@remotion/bundler` 内部 css-loader path 解析失败（Bun 正常）
- **React 18 而非 19**：Remotion 默认 React 19 有兼容问题，降级 `bun add react@18.2.0 react-dom@18.2.0`
- **无内置 Text 组件**：Remotion v4 无内置 `<Text>`，直接用 `<div>` + CSS
- **字体**：`fontFamily: "Arial, sans-serif"` 在 WSL 无需额外配置 CJK 回退

---

## 渲染命令

```bash
cd /home/renanzai/Remotion-Test
bunx remotion render src/index.ts <CompId> /tmp/out.mp4 \
  --browser-executable ~/.cache/ms-playwright/chromium-1217/chrome-linux64/chrome
```

---

## 已知限制

1. **Remotion 不是 After Effects**：复杂动画需要写 React/TypeScript 代码，不能"导入即用"
2. **Lottie JSON 需要外部准备**：Remotion 只负责播放，不生成动画文件
3. **粒子数量影响性能**：超过 12 个粒子可能影响渲染速度
4. **单 WAV 轨限制**：如需逐段独立音效控制，仍需回到多 Audio 轨方案（当前有崩溃风险）

---

## 引用文件

- 动画组件：`/home/renanzai/Remotion-Test/src/animations.tsx`
- 粒子 CSS：`/home/renanzai/Remotion-Test/src/index.css`
- 引流款组件：`/home/renanzai/Remotion-Test/src/WentechTTSComposition.tsx`
- 业务款组件：`/home/renanzai/Remotion-Test/src/SixOneEightTTSComposition.tsx`
- 调研参考：`lithStudy/remotion_demo`（GitHub：数据驱动动画 + TTS 同步）