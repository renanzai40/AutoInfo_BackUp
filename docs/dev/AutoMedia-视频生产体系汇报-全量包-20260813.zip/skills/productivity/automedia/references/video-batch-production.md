---
name: video-batch-production
description: AutoMedia 视频批量生产 4 阶段标准工作流（TTS + SRT + 帧图 + Remotion）。用于单话题项目视频生产环节（5 平台中的"视频"部分）。5 段式分镜（钩子/痛点/干货/高潮/CTA），subagent 并行制作模式。首次完整跑通：2026-06-02 m3 + hy-memory 2 段。
tags: [video, tts, srt, remotion, automedia, batch, 5-段式]
---

# 视频批量生产标准工作流

## 适用场景

- AutoMedia 单话题项目视频生产（Step 6）
- 5 平台中的"视频（抖音+B站共用 1 个）"
- 引流款/业务款均使用此流程

## 5 段式分镜标准（5 帧图模式）

| 段 | 内容 | 帧图 Prompt 风格 | 时长占比 |
|----|------|------------------|---------|
| S1 钩子 | 开场震撼/痛点引入 | abstract news burst / 数字球 | ~17% |
| S2 痛点 | 客户场景/反复改稿 | scattered fragments with red warning | ~4% |
| S3 干货 | 核心 3 大升级/能力 | three nodes connected / layered memory | ~33% |
| S4 高潮 | 6 倍效率/警示/质疑 | data acceleration / before-after | ~24% |
| S5 CTA | 关注引导/品牌收尾 | abstract logo in center | ~10% |

**5 段式 vs 7 段式选择**：
- 5 张帧图 → 5 段式（5 scene，每 scene 多 entry 字幕）
- 7+ 帧图 → 7 段式（每 E 一个 scene，参考 Remotion-Test/src/TrapDoorComposition.tsx 模板）

## 4 阶段流水线

### Stage 1: TTS 音频

**API**: MiniMax speech-2.8-hd
**Endpoint**: `POST https://api.minimaxi.com/v1/t2a_v2`
**返回**: `data.audio` 是 hex 编码字符串，需 `binascii.unhexlify()` 解码

```python
import re, json, subprocess, binascii

key = re.search(r'MINIMAX_API_KEY:\s*(\S+)', open('/home/renanzai/.hermes/config.yaml').read()).group(1)
text = '\n'.join(entries)  # 13-14 Entry 用 \n 拼接

payload = {
    "model": "speech-2.8-hd",
    "text": text,
    "voice_setting": {
        "voice_id": "male-qn-qingse",  # 男声磁性
        "speed": 1.0,  # 不要 1.3x，损失原汁原味
        "vol": 10,      # ⚠️ 整数！非 1.0（API 报 Mismatch type int64）
        "pitch": 0,     # ⚠️ 整数
    },
    "audio_setting": {
        "sample_rate": 32000,
        "bitrate": 128000,
        "format": "mp3"
    }
}

cmd = ["curl", "-s", "-X", "POST", "https://api.minimaxi.com/v1/t2a_v2",
       "-H", f"Authorization: Bearer {key}", "-H", "Content-Type: application/json",
       "-d", json.dumps(payload)]
result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
resp = json.loads(result.stdout)

audio_bytes = binascii.unhexlify(resp["data"]["audio"])
with open(out_path, "wb") as f:
    f.write(audio_bytes)
```

**实测参数**：
- 219 字 → 73.12s
- 244 字 → 79.31s
- 实际语速 ~3.0 字/秒（比理论 4.8 字/秒慢 ~37%）
- 60s 抖音限制下，最多容纳 200 字口播

### Stage 2: SRT 字幕

使用 `subtitle-srt-generation` skill v2.0 的"路径 B（纯比例分配）"。

```python
import subprocess, re

def get_mp3_duration(path):
    """用 ffmpeg 测 mp3 时长（ffprobe 未装）"""
    result = subprocess.run(["ffmpeg", "-i", path], capture_output=True, text=True)
    m = re.search(r'Duration:\s*(\d+):(\d+):(\d+\.\d+)', result.stderr)
    h, mn, s = m.groups()
    return int(h)*3600 + int(mn)*60 + float(s)

audio_dur = get_mp3_duration(tts_mp3)
total_chars = sum(len(s) for s in entries)
t = 0.0
srt_entries = []
for sent in entries:
    end_t = t + (len(sent) / total_chars) * audio_dur
    srt_entries.append([round(t,2), round(end_t,2), sent])
    t = end_t

def fmt_time(s):
    h, m, sec = int(s//3600), int((s%3600)//60), int(s%60)
    ms = int((s - int(s)) * 1000)
    return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"

with open(srt_path, "w", encoding="utf-8") as f:
    for i, (start, end, text) in enumerate(srt_entries, 1):
        text = text.replace("一目惯为", "壹目贯维")  # 品牌名兜底
        f.write(f"{i}\n{fmt_time(start)} --> {fmt_time(end)}\n{text}\n\n")
```

**铁律**：
- 脚本原文 = SRT 文本（绝对权威，Whisper 文本不写入 SRT）
- 字数 ≤45 字红线（每条 SRT 字幕在屏幕上的长度限制）
- 品牌名"壹目贯维"扫描（一目惯为 → 壹目贯维）

**Entry 拆分技巧**（超 45 字时）：
- 按"逗号"或"语义断点"拆分，保持叙事连贯
- m3 Entry 2 48 字 → 拆 2a (35字) + 2b (13字)，SRT entry 数从 13 → 14
- 拆分后 total_frames 重新计算

### Stage 3: 帧图生成

使用 MiniMax image-01 API，按 5 段式生成 5 帧图 + 3 封面。

**反文字/反人脸/反乱码 Prompt 模板**（关键避坑，详见 image-prompt skill）：

```
abstract {纯几何元素} in {位置}, dark blue background with subtle purple gradient glow,
blue and purple light effects, frosted glass aesthetic, 4K ultra detailed,
professional tech aesthetic, {aspect_ratio} composition,
NO text, NO letters, NO numbers, NO words, NO characters, NO symbols,
NO brand logo, NO readable characters anywhere, NO human figure, NO face, NO body shape
```

**5 段式帧图 Prompt 模板**（m3 引流款示例）：

```python
frames = [
    # S1 钩子：开场震撼
    "abstract news burst with glowing particles radiating outward, dark blue background with subtle purple gradient glow, ...",
    # S2 痛点：工具切换的混乱
    "scattered abstract digital tools floating chaotically, shattered glass fragments with glowing edges, dark blue background, ...",
    # S3 干货：3 大升级示意
    "three glowing nodes connected by light beams in horizontal sequence, abstract AI capability visualization, ...",
    # S4 高潮：6 倍效率冲击
    "abstract data acceleration visualization with light streaks converging into a central glow point, ...",
    # S5 CTA：品牌收尾
    "abstract geometric logo symbol in center, light rays in radial pattern, dark blue background with subtle glow, ..."
]
```

**Vision QA 必须项**（详见 image-prompt skill）：
1. 文字（中英文、任何字符）
2. 地图
3. 品牌 Logo
4. 人脸（即使是剪影/侧脸）
5. 乱码（"IWAT TEIC" / "minMax m3" 等无意义字符）

**重生成策略**：FAIL 后改 prompt 强化 "NO text" 声明，最多 2 次；超 2 次跳过该图继续其他素材。

### Stage 4: Remotion 渲染

**复用现有根项目** `/home/renanzai/Remotion-Test/`（不是新建项目）。

**Composition 模板**（5 段式）：

```tsx
// src/M3Composition.tsx
const S1_FROM = 0;     const S1_TO = 538;    // 钩子
const S2_FROM = 538;   const S2_TO = 779;    // 痛点
const S3_FROM = 779;   const S3_TO = 1768;   // 干货
const S4_FROM = 1768;  const S4_TO = 2169;   // 高潮
const S5_FROM = 2169;  const S5_TO = 2379;   // CTA

const TRANSITION_DUR = 15;
const S1_DUR = S1_TO - S1_FROM + TRANSITION_DUR; // 553
// ... 计算每段 duration
export const TOTAL_FRAMES = S1_DUR + S2_DUR + S3_DUR + S4_DUR + S5_DUR - 4 * TRANSITION_DUR; // 2379
```

**关键参数**：
- fps=30（实测稳定，不用 60）
- 分辨率 1080×1920（9:16 竖屏）
- 音频从 `public/audio/<slug>.mp3` 引用（`staticFile("audio/<slug>.mp3")`）
- 帧图从 `public/projects/<slug>/02_images/frame_N.png` 引用

**4:3 图在 9:16 视频的显示**（实测有效，不裁切主体）：
```tsx
<Img src={staticFile(src)} style={{
  width: "75%",
  aspectRatio: "3/4",   // 4:3 横版图放进 3:4 竖版框
  objectFit: "contain",  // 不裁切主体，留黑边
  borderRadius: 16,
  boxShadow: "0 20px 80px rgba(0,0,0,0.6)"
}} />
```

**字幕卡片**（来自 TrapDoor 模板，已验证兼容多 entry 场景）：
- fade-in 8-20f
- fade-out = max(10, duration × 85%) 帧
- spring 入场 + 呼吸动效

**TransitionSeries + fade 过渡**：TRANSITION_DUR=15 帧

**渲染命令**：
```bash
cd /home/renanzai/Remotion-Test
npx remotion render <CompositionID> out/xxx.mp4 --log=error
```

**编译验证**（每次修改 Composition 前必跑）：
```bash
node -e "require('esbuild').buildSync({entryPoints:['src/XxxComposition.tsx'],bundle:false,outfile:'/dev/null',logLevel:'error'})"
```

**渲染时间参考**：
- 73s 视频 → 2m42s
- 79s 视频 → 2m49s
- 约 2.2 倍视频时长

## Subagent 并行批量生产模式

2 个项目并行做素材生成（实测有效，subagent 会超时但素材全 OK）：

```python
delegate_task(tasks=[
    {
        "goal": "为 m3 项目生成 TTS + SRT + 5 帧图 + 3 封面",
        "toolsets": ["terminal", "file", "vision", "web"],
        "context": "AutoMedia 视频生产子任务，不要回退或修改视频脚本..."
        # 完整 prompt 含 API 代码、5 段式分镜、prompt 模板、输出路径、QA 要求
    },
    {
        "goal": "为 hy-memory 项目生成 TTS + SRT + 5 帧图 + 3 封面",
        "toolsets": ["terminal", "file", "vision", "web"]
    }
])
```

**实测结果**：
- m3 subagent：15 次 API 调用，35 个素材，600s 超时但素材全 OK
- hy subagent：20 次 API 调用，40 个素材，600s 超时但素材全 OK

**主 agent 接管**（subagent 完成后必做）：
1. Vision QA 抽查（不依赖 subagent 的 QA 报告）
2. SRT 比例分配重生成（必须按实测 TTS 时长，不要 subagent 的 SRT）
3. TTS 1.0x 重生成（每次时长有差异，按实测 SRT 重做）
4. Remotion 渲染

## 飞书视频发送（大小限制）

飞书个人 bot media 上限 ~30MB。超限处理：

```bash
# 32MB+ → 重压缩到 ~8MB
ffmpeg -y -i in.mp4 -c:v libx264 -crf 28 -preset fast \
       -c:a aac -b:a 96k -movflags +faststart out.mp4
```

**实测**：33MB mp4 → 7.7MB（CRF 28，视觉质量可接受）

## Checklist（5 段式 1 段视频生产）

- [ ] 13-14 Entry 视频脚本（已通过 4 Gate）
- [ ] MiniMax TTS 1.0x（保留原汁原味）
- [ ] SRT 比例分配（按实测音频时长，全部 ≤45 字，品牌名扫描）
- [ ] 5 帧图 + 3 封面（全部 Vision QA PASS）
- [ ] Remotion Composition 编译通过（`esbuild` 无错）
- [ ] `npx remotion render` 渲染完成（2-3 分钟）
- [ ] 抽 5 帧 Vision QA 验证（5% / 25% / 50% / 75% / 95%）
- [ ] 飞书发送（< 30MB 直接发，> 30MB 重压缩）

## 已知坑（必避）

1. **TTS 每次时长略有差异**（73.12s vs 76.0s）→ 重生成后必须按实测音频时长重算 SRT 时间戳
2. **"number X" 描述会画出数字** → 用 "crystal cluster" 替代
3. **"侧脸剪影" 会被 VLM 判人脸 FAIL** → 去掉 silhouette/face 关键词
4. **"飞舞的纸张" 会出乱码** → 强化 "NO readable characters anywhere"
5. **Remotion 帧边界必须用实测音频时长**（不是估算）→ 用 ffmpeg Duration: 字段
6. **subagent 不写 QA 报告** → 主 agent 必须自做 Vision QA
7. **飞书 30MB 上限** → 重压缩或分 zip
8. **TTS vol/pitch 必须是整数**（10 / 0）非浮点（1.0 / 0.0）否则 API 报 Mismatch type int64
9. **hy 类项目 SRT 累加时长 < TTS 实测时长**（2379f < 2468f）→ 用 SRT 累加值作 totalFrames，不要用 TTS × fps，否则视频会多出 2-3s 静音
