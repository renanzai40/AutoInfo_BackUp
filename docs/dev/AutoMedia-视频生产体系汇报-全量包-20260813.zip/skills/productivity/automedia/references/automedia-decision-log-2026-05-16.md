# AutoMedia 决策日志（2026-05-16）

## 今日事故与根因

### 事故1：发错视频文件（发了旧版，不是QA合格版）
**症状**：用户收到视频后说"中间还有字"。zip 里的 `video_final.mp4` 和 Vision QA 时检查的是不同文件。
**根因**：Vision QA 检查了 `/tmp/video1_final_v4.mp4`（2.4MB，合格）；打包时从项目目录取了 `video_final.mp4`（4.6MB，有问题的旧版）。两个文件同名，靠文件名无法区分。
**决策**：Hook 强制发文件前 Whisper 内容确认 + MD5 记录；`delivery_packaging.py` 显式接收 `video_src` 参数。

### 事故2：Zip 缺知乎/小红书内容
**根因**：打包时只扫描了 `01_content/` 直接子文件，没有递归扫描 `drafts/zhihu/` 和 `drafts/xiaohongshu/` 子目录。
**决策**：`delivery_packaging.py` 改用 `os.walk()` 递归扫描。

### 事故3：Subagent 超时丢 3/5 平台
**根因**：5个平台文案+视频生产全部塞进同一个 subagent，总时间 > 600s。subagent 内串行，总时长 = sum(所有步骤)。
**决策**：视频生产永远不进 subagent；subagent 返回后验证5个平台全部存在；缺失的直接主agent补全，不告知用户。

### 事故4：理解用户诉求
**用户原话**："视频中间有字幕" → 是现象描述，不是诊断。
**错误**：预设立场是"字幕层参数错了"。**正确**：先 Vision QA 截图定位问题层。

---

## 新增 Hooks

| Hook | 文件 | 集成位置 |
|------|------|---------|
| delivery-packaging | `delivery_packaging.py` | SKILL.md 打包节点 |
| pre-send Whisper | `hooks/pre_send_whisper_check.py` | SKILL.md 打包节点 |
| auto_vision_qa | `hooks/auto_vision_qa.py` | SKILL.md Step 7 |
| brand_name_killer | `hooks/brand_name_killer.py` | SKILL.md Brand-CTA Gate |
| production_metrics | `hooks/production_metrics.py` | 各生产步骤 |
| topic_deduplication | `hooks/topic_deduplication.py` | 项目启动时 |
| circuit_breaker_image | `hooks/circuit_breaker_image.py` | 封面图生成 |
| parallel_gates | `hooks/parallel_gates.py` | 三阶强制工序 |
| cron_watchdog | `scripts/cron_watchdog.py` | cron 09:30 |

---

## 关键设计决策

**永远不放进 subagent**：TTS / Whisper / SRT / 视频生产 / PIL字幕烧录 / Vision QA

**单文件多版本管理**：每个项目同一时刻只能有一个 `video_final.mp4`，禁止多版本并存。

**交付路径原则**：所有发给用户的文件路径在 `/tmp/`、打包前 Whisper 确认、发出路径=QA 路径（MD5 记录）。

---

## 技术债务

1. `parallel_gates.py` Gate 函数是占位符，需要 execute_code 调用 MiniMax
2. `cron_watchdog.py` 只写 `wdog_alert.json`，依赖 cron delivery 捡起推送
3. FALLBACK_COVER 生成依赖 PIL，PIL 不可用时降级为预设纯色图
