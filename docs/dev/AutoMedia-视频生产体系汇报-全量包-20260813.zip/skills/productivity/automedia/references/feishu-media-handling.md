---
name: feishu-media-handling
description: 飞书个人 bot 发送媒体文件的大小限制 + 重压缩方案。视频/zip/图片通用。首次记录：2026-06-02 视频交付。
tags: [feishu, media, ffmpeg, compression]
---

# 飞书 Media 发送大小处理

## 上限

飞书个人 bot（content profile 私聊 `oc_23809420584b118ca6df5c514067045b`）：
- **mp4 直发上限 ~30MB**（实测）
- **zip 发送上限 ~30MB**（实测）

**测试数据**：
| 文件 | 大小 | 发送结果 |
|------|------|---------|
| minimax-m3 mp4 | 16.6MB | ✅ 成功 |
| minimax-m3 zip | 15.3MB | ✅ 成功 |
| hy-memory mp4 | 33.0MB | ❌ 失败 |
| hy-memory 视频包 zip | 47.0MB | ❌ 失败 |
| 49MB zip（合并 m3+hy）| 47.0MB | ❌ 失败 |

## 重压缩方案（视频）

```bash
ffmpeg -y -i in.mp4 -c:v libx264 -crf 28 -preset fast \
       -c:a aac -b:a 96k -movflags +faststart out.mp4
```

**实测效果**：
- 33MB → 7.7MB（CRF 28，视觉质量可接受，1 分钟视频 79s）
- 视觉损失：细节略糊、动效边有轻微方块，但字幕/帧图主体清晰

**CRF 调参指南**：
| CRF | 视觉质量 | 文件大小（相对）|
|-----|---------|---------------|
| 23 | 视觉无损 | 100%（参考）|
| 26 | 良好 | ~60% |
| **28** | **可接受（推荐）** | **~23%** |
| 32 | 明显压缩 | ~12% |

## 重压缩方案（zip）

如必须用 zip 超过 30MB：
- 用 `split` 命令拆成多个 ≤25MB 的分卷
- 或用 `zip -s 25m big.zip` 创建分卷 zip

## 视频压缩清单（飞书发布前）

- [ ] 测 mp4 实际大小（`ls -la`）
- [ ] 超过 25MB → 用 ffmpeg 重压缩（CRF 28）
- [ ] 压缩后再次测大小
- [ ] 仍超过 25MB → 拆 zip 分卷
- [ ] 优先尝试 mp4 直发（飞书支持视频内联预览，比 zip 体验好）

## 已知坑

1. **ffmpeg `-movflags +faststart`** 必加：moov atom 移到文件头部，飞书在线预览更顺
2. **CRF 28 是甜点**：CRF 26 太大（>20MB），CRF 30 视觉损失太重
3. **音频 bitrate 96k** 足够：人声 TTS 96k 听感与 128k 几乎无差
4. **preset fast** 平衡速度与质量（preset slow 压缩率好但慢 3-4 倍）

## 相关工具

- `ffprobe` 未装 → 用 `ffmpeg -i` 测时长
- `mutagen` Python lib 可用（`pip install mutagen`）→ 测 mp3 时长
