# Hook vs Skill：两种执行约束的区别（2026-05-17）

## 核心区别

| | Skill | Hook |
|--|-------|------|
| 本质 | 文档 + 可执行代码 | 强制门控代码 |
| 触发 | agent 主动加载（可跳） | 执行路径上自动触发（难跳） |
| 失败后果 | agent 可能继续 | 抛 Exception，阻塞继续 |
| 典型示例 | `humanizer` / `copy-review` | `pre_wechat_upload.py` / `brand_name_killer.py` |

## 典型错误

❌ 把"必须加载 skill"写在 SKILL.md 里，期待 agent 遵守 → agent 可能跳。

✅ 把强制门控写成 hook，在执行路径上调用 → agent 难跳。

## Hook 分类

**Gate Hook**（失败即停）：
- `pre_wechat_upload.py` — WeChat 上传前 7步检查
- `brand_name_killer.py` — CTA 品牌名检查
- `auto_vision_qa.py` — 烧录后三帧检查
- `subagent_completion_check.py` — 5平台草稿完整性

**Fallback Hook**（失败降级不卡死）：
- `circuit_breaker_image.py` — 图片生成 3次重试失败降级封面
- `parallel_gates.py` — Gate 并行超时回退串行

**Observer Hook**（不阻断，只记录）：
- `production_metrics.py` — 每步耗时写 metrics.json
- `topic_deduplication.py` — 检测今日重复话题

## 什么时候用 Hook vs Skill

- **Workflow 描述** → Skill（`wechat-upload-checklist` 描述检查项）
- **强制执行** → Hook（`pre_wechat_upload.py` 自动化执行检查）
- **Skill 描述的规则** → 对应的 Hook 强制执行
- **Skill 不应该有内联 requests** → 用 Hook 封装 API 调用

## Hook 文件位置

统一在 `/home/renanzai/.hermes/skills/productivity/automedia/hooks/`

调用方式：
```python
import sys
sys.path.insert(0, '/home/renanzai/.hermes/skills/productivity/automedia/hooks')
from pre_wechat_upload import pre_wechat_upload_check
result = pre_wechat_upload_check(project_dir)
```

## WeChat 上传的特殊性

WeChat API 非幂等，脏内容上传 = 制造垃圾草稿，无法撤销。
`wechat-upload-checklist` skill 描述检查项，`pre_wechat_upload.py` 自动化执行。
上传前必须先过 `pre_wechat_upload_check()`，不能只加载 skill 描述。