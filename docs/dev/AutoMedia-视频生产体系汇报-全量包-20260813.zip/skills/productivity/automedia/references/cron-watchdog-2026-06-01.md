# Cron Watchdog 健康检查（2026-06-01）

## 事件概要

2026-06-01 实际跑 watchdog 时发现：现有 `scripts/cron_watchdog.py` 脚本有 **4 个潜在 bug**，
导致它在 content profile 下完全无法工作（`load_jobs` 路径错 + job 字段名错 + 没检查 delivery）。

另外发现一个 **核心认知陷阱**：`last_status="ok"` ≠ job 健康，
必须同时检查 `last_delivery_error`，否则会漏掉"脚本跑成功但推送失败"的情形。

## 4 个 Bug 与修复

### Bug 1：路径错误（`~/.hermes/cron/` 在 active profile 下不存在）

**症状**：
```python
jobs_path = os.path.expanduser("~/.hermes/cron/jobs.json")
# FileNotFoundError: [Errno 2] No such file or directory
```

**根因**：hermes 在 active profile 下把 HERMES_DIR 映射到
`~/.hermes/profiles/<profile>/`。CRON_DIR 解析为 `~/.hermes/profiles/<profile>/cron/`
而非 `~/.hermes/cron/`。`expanduser("~")` 在 hermes session 内还会被重映射到
`~/.hermes/profiles/<profile>/home`，进一步加剧混乱。

**修复**：用 hermes 自己的常量，不要拼字面路径：
```python
import sys
sys.path.insert(0, '/home/renanzai/.hermes/hermes-agent')
from cron.jobs import JOBS_FILE, OUTPUT_DIR
jobs_path = JOBS_FILE          # 自动跟随 active profile
alert_path = JOBS_FILE.parent / "wdog_alert.json"   # 与 jobs.json 同目录
```

### Bug 2：job 字段名错（用 `job_id` 实际是 `id`）

**症状**：watchdog 永远报告"job_id=X 未找到"，所有 job 都被误判为 unhealthy。

**根因**：`hermes cron create` 写入 `jobs.json` 时字段是 `"id"`，但旧 watchdog 脚本查找用的是 `j.get("job_id")`，永远不匹配。

**修复**：
```python
# 错
if j.get("job_id") == job_id:
# 对
if j.get("id") == job_id:
```

**验证命令**（写脚本前必跑）：
```python
from cron.jobs import load_jobs
jobs = load_jobs()
print(jobs["jobs"][0].keys())   # 确认实际字段名
# 预期：dict_keys(['id', 'name', 'schedule', 'state', 'last_status',
#                  'last_error', 'last_delivery_error', 'deliver', ...])
```

### Bug 3：未检查 `last_delivery_error`（最严重）

**症状**：脚本推送 Feishu 失败但 watchdog 报告"全部健康"。
用户看 watchdog 报告以为一切正常，实际什么都没收到。

**根因**：job 字段有两个独立错误：
- `last_error`：脚本本身执行失败（Python crash / API 异常）
- `last_delivery_error`：脚本跑成功但消息推送失败

`last_status` 由执行结果决定，跟 delivery 无关。**只有同时满足**：
- `last_status == "ok"`
- `last_error is None`
- `last_delivery_error is None`

才能算 job 真正健康。

**典型场景**（本次踩坑）：
- 08:00 / 08:05 / 07:30 三个 job 的 `last_status="ok"`（脚本跑成功）
- 但 `last_delivery_error="Feishu send failed: [230002] Bot/User can NOT be out of the chat."`
- 旧 watchdog 报告"3 个 job 全部健康"
- 实际所有推送都失败，用户没收到任何消息

**修复**：
```python
def is_job_healthy(job: dict) -> tuple[bool, str]:
    if job.get("last_error"):
        return False, f"execution_failed: {job['last_error'][:100]}"
    if job.get("last_delivery_error"):
        return False, f"delivery_failed: {job['last_delivery_error'][:100]}"
    if job.get("last_status") != "ok":
        return False, f"status={job.get('last_status')}"
    return True, "ok"
```

### Bug 4：日期解析脆弱

**症状**：
```python
last_dt = datetime.fromisoformat(last_run.replace("Z", "+00:00").replace("+08:00", ""))
# naive datetime, 跟 now()（naive local）比，时间差会偏移数小时
```

**根因**：粗暴去掉时区后变成 naive datetime，跟 `datetime.now()`（系统 local time）
直接相减；时区信息丢失导致 elapsed_min 计算不准确。

**修复**：保留时区信息，统一转 UTC 后再比较：
```python
from datetime import datetime, timezone

def parse_iso(s: str) -> datetime:
    # Python 3.11+ fromisoformat 已支持 'Z' 和 '+HH:MM'
    dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    return dt.astimezone(timezone.utc)

def minutes_since(iso_ts: str) -> float:
    if not iso_ts:
        return float("inf")
    return (datetime.now(timezone.utc) - parse_iso(iso_ts)).total_seconds() / 60
```

## 飞书 Delivery 错误码速查

| 错误码 | 含义 | 常见原因 | 修复路径 |
|--------|------|---------|---------|
| 230001 | invalid request parameter, ext=invalid receive_id | receive_id 格式错 / 对应群已解散 / 群类型不支持 bot | 重新核对 chat_id，确认群仍存在 |
| 230002 | Bot/User can NOT be out of the chat | 机器人被移出群 / 应用 `im:message` 权限被回收 / tenant_access_token 过期 | 1. 飞书后台核对权限<br>2. 把机器人重新拉入群<br>3. 检查 token 刷新机制 |
| 230020 | robot not in chat | 同 230002，alias | 同 230002 |
| 230021 | robot has no right to send group msg | 应用缺 `im:message.group_at_msg` 或类似权限 | 飞书后台权限管理 → 启用对应 scope |

**判断 chat_id 失效还是瞬时错误**：
- 永久失效：同一 chat_id 连续 3+ 次 send 失败
- 瞬时错误：job A send 失败 + job B send 成功（同一 chat） → 提示 token 临近过期或 rate limit

## Cron Watchdog 告警 JSON Schema

下游 reader 依赖结构化字段。推荐 schema：

```json
{
  "schema": "automedia.wdog_alert.v1",
  "generated_at": "2026-06-01T17:55:54+08:00",
  "watchdog_job_id": "wdog_auto_media",
  "summary": {
    "total_monitored": 3,
    "healthy": 0,
    "delivery_failed": 3,
    "execution_failed": 0
  },
  "jobs_monitored": [
    {
      "id": "143d19e69a7c",
      "name": "AutoMedia 08:00 热点采集",
      "schedule": "0 8 * * *",
      "last_run_at": "2026-06-01T17:31:44+08:00",
      "last_status": "ok",
      "last_error": null,
      "last_delivery_error": "delivery error: Feishu send failed: [230002] ...",
      "deliver": "origin,feishu:oc_fb87...,feishu:oc_fbc1...",
      "health": "healthy | delivery_failed | execution_failed",
      "issue": "feishu_230002_bot_not_in_chat",
      "severity": "high | medium | low | none"
    }
  ],
  "diagnosis": {
    "primary_error_code": "230002",
    "error_meaning_zh": "...",
    "affected_chat_ids": ["oc_..."],
    "intermittent_chat_id": "oc_...（job A 失败 / job B 成功）",
    "root_cause_hypothesis": "..."
  },
  "recommended_actions": [
    "1. ...",
    "2. ..."
  ],
  "actionable_command_suggestion": "hermes cron run <job_id>"
}
```

**关键约束**：
- `health` 字段三选一：`healthy` / `delivery_failed` / `execution_failed`
- `severity` 与 `health` 联动：`healthy` → `none`；其他 → `high`/`medium`/`low`
- 写到路径：**与 `jobs.json` 同目录的 `wdog_alert.json`**，不是 `~/.hermes/cron/wdog_alert.json`
- 下游 reader（如 `hermes cron run wdog_auto_media`）应 watch `<CRON_DIR>/wdog_alert.json` 而非 home-relative 路径

## 验证清单

watchdog 脚本部署后必跑：

```python
import sys
sys.path.insert(0, '/home/renanzai/.hermes/hermes-agent')
from cron.jobs import load_jobs, JOBS_FILE

# 1. 路径正确性
print(f"JOBS_FILE = {JOBS_FILE}")   # 应该是 ~/.hermes/profiles/content/cron/jobs.json
print(f"exists    = {JOBS_FILE.exists()}")

# 2. load_jobs 能解析所有 job（不被任意一个卡住）
data = load_jobs()
print(f"Total jobs: {len(data['jobs'])}")
for j in data['jobs']:
    print(f"  {j.get('id', 'NO_ID'):20s} {j.get('name', 'NO_NAME')}")

# 3. health 判定逻辑
for j in data['jobs']:
    health = "healthy"
    if j.get("last_error"): health = "execution_failed"
    elif j.get("last_delivery_error"): health = "delivery_failed"
    elif j.get("last_status") != "ok": health = "status_abnormal"
    print(f"  [{health:18s}] {j.get('name')}")
```

预期：4 个 AutoMedia job + 1 个 watchdog job 全部列出，health 字段对每个 job 都准确。

## 相关文件

- `/home/renanzai/.hermes/profiles/content/skills/productivity/automedia/scripts/cron_watchdog.py` — 已修复
- `/home/renanzai/.hermes/profiles/content/cron/jobs.json` — 任务定义（含 `id`/`last_error`/`last_delivery_error` 字段）
- `/home/renanzai/.hermes/profiles/content/cron/wdog_alert.json` — watchdog 告警输出
- `/home/renanzai/.hermes/hermes-agent/cron/jobs.py` — `JOBS_FILE`/`load_jobs` 定义
- `references/cron-jobs-fix-2026-05-12.md` — 2026-05-12 cron 修复记录（schedule 字段类型 bug）
- `references/cron-debug-2026-05-12.md` — 2026-05-12 cron 调试记录（双重投递 / 手动触发顺序）
