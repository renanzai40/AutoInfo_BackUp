# Whisper Pre-Send 关键词检查的局限性

**适用场景**：AutoMedia Post-render QA 阶段用 Whisper 转写 TTS 音频 + 检查关键词是否齐全。

## 关键限制

**Whisper small 模型在中文 + 英文品牌名混合场景下，识别不可靠**：

| 真实内容 | Whisper 转写结果 | 状态 |
|---------|----------------|------|
| Aleph 2.0 | Alif 2.0 | ❌ 品牌名识别错 |
| 壹目贯维 | 一目慣為 / 一目慣為 | ❌ 简繁+错字 |
| @runwayml | At Run 位母 / RUN-way-mo | ❌ 拆解为多个 token |
| dev.runwayml.com | Dev.RUN-way-mo.com | ❌ 拆解 |
| Gen4 Aleph | J4-Alif / 間四 Alif | ❌ |
| reveriemovies | Reverie Movies | ❌ 拆解 |
| Plug & Play | Plug and Play | ⚠️ 符号→文字 |

**Whisper 输出其他已知错**：
- "Plug & Play" → "Plug and Play"（符号→空格）
- "GMT" → "GMT-at-RUN-way-mo"（缩写拆解）
- "30 秒 1080p" → "30 秒 1080p"（数字偶尔保留）
- 中英标点 → 中文标点

## 实际含义

**Whisper 关键词检查 fail ≠ 视频错**。

视频的字幕和音频是 SRT 驱动 + TTS API 直接输出，**只要 SRT 校对过品牌名（独立 verify 全部正确）**，视频就是正确的。

Whisper 转写只是**音频"听起来像什么"的近似估计**——不是 ground truth。

## 正确使用

1. **跑 Whisper 关键词检查**作为**辅助参考**（确认音频在"说"相关内容）
2. **不作为 PASS/FAIL 决定依据**（关键词 fail 也不阻塞发布）
3. **真要确认视频**：
   - PIL 像素验证（底部字幕区亮像素 > 阈值）
   - Vision QA（mcp_minimax_understand_image 读顶部主标题 + 确认画面）
   - 独立 verify SRT（确保 SRT 文字与 TTS 原文一致）

## 2026-06-03 Runway 案例实测

| 检查 | 结果 | 结论 |
|------|------|------|
| 8 个关键词检查 | 4/8 ✅ 4/8 ❌ | Whisper 限制 |
| PIL 像素验证 11 帧 | 11/11 ✅ | 视频字幕全显示 |
| Vision QA frame 5 | 主标题 + 画面清晰 ✅ | 视频渲染正确 |
| SRT 独立 verify | 15 段品牌名全对 | SRT 驱动源正确 |
| 视频 MD5 + 尺寸 | 6.80MB / 75.7s | 文件完整 |

**最终判定**：视频正确，Whisper 误报，发布 PASS。

## 推荐做法

在 `04_review/post_render_qa_report.md` 里：
- ✅ 列 PIL 像素验证结果
- ✅ 列 Vision QA 抽帧结果
- ⚠️ Whisper 关键词 fail 时**标注"Whisper 模型限制，不影响视频正确性"**

不要在 QA 报告里把 Whisper fail 当成"视频不通过"的依据。

## 关联

- `remotion-post-render-qa` skill（post-render QA gate）
- `automedia-production-guard` skill（Pre-send Whisper 规范）
- `whisper-postprocess` skill（Whisper 文本后处理，处理标点/断句）
