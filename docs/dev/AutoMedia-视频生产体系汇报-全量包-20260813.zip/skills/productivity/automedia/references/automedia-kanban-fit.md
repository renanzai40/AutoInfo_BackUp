# AutoMedia × Kanban 适配性分析

> 基于 2026-05-16 对话记录。

## AutoMedia 工作流（现状）

```
串行（必须）：热点采集 → 评分排序 → 用户选话题
        ↓
  并行（已用 subagent）：口播/公众号/知乎/小红书/bilibili 文案生成（~248s）
        ↓
  串行（必须）：Humanizer → Copy-review → Brand-CTA review
        ↓
  串行（必须）：TTS → Whisper → SRT 建字幕
        ↓
  串行（必须）：图片生成 → FFmpeg 拼接 → PIL 烧录 → Vision QA
        ↓
  串行（必须）：打包 → 交付
```

## Kanban 适合的部分

**✅ 多平台文案并行生成（5个 task，可并行跑）**
- 5个平台（口播/公众号/知乎/小红书/bilibili）互相独立，无数据依赖
- 每个 task = 一个平台的文案生成（~248s subagent）
- 解决了 subagent 超时只完成部分平台的问题（5个 task 各跑各的，不互相阻塞）
- worker 数量 = 5 时，5个平台同时跑

**✅ 定时采集任务（08:00 热点采集）**
- 可作为独立的 kanban task 由 cron 触发

## Kanban 不适合的部分

**❌ 视频生产链路（串行依赖链）**
- TTS → Whisper → SRT → 图片生成 → FFmpeg → PIL → QA
- 每一步依赖前一步输出，无法拆分并行

**❌ 三阶强制工序**
- humanizer→copy-review→brand-cta-review 需要主 agent 判断通过/不通过，worker 不能自主决策

**❌ 打包交付**
- 最终核对必须主 agent 做，确保 zip 内容完整 + 视频路径正确

## 推荐接入方式

```
主agent：热点采集 → 用户选话题
        ↓
  Kanban 分发（5个 worker 各跑一个平台）
  主agent 收回所有结果
        ↓
主agent 串行：Humanizer → Copy-review → Brand-CTA → TTS → 视频生产 → QA → 交付
```

## 当前状态

| 检查项 | 状态 |
|--------|------|
| kanban.db | ✅ 存在 |
| kanban 插件代码 | ✅ 已安装 |
| gateway dispatcher | ✅ 运行中 |
| 已初始化 task | ❌ 0 条 |

**结论**：适合用 Kanban 解耦"多平台文案并行生成"，其他链路保持主 agent 串行。