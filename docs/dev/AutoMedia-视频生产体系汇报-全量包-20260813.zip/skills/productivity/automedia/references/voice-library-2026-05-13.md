# MiniMax TTS 音色库参考（2026-05-13）

## API调用规范
- 模型: `speech-2.8-hd`
- 端点: `https://api.minimaxi.com/v1/t2a_v2?GroupId={group_id}`
- `output_format=url`时，URL在`data.audio`，**不是**`data.audio_url`
- `voice_setting`只支持: `voice_id`, `speed`, `vol`，**不支持**`pitch`（会报2013）和`emotion`

## 中文（普通话）男声音色 — 共约30个

### 青年音色系
| Voice ID | 名称 | 备注 |
|----------|------|------|
| `male-qn-qingse` | 青涩青年音色 | 当前默认，偏年轻 |
| `male-qn-jingying` | 精英青年音色 | 比青涩更成熟 |
| `male-qn-badao` | 霸道青年音色 | 有气势 |
| `male-qn-daxuesheng` | 青年大学生音色 | |
| `male-qn-qingse-jingpin` | 青涩青年音色-beta | Premium版 |
| `male-qn-jingying-jingpin` | 精英青年音色-beta | Premium版 |
| `male-qn-badao-jingpin` | 霸道青年音色-beta | Premium版 |
| `male-qn-daxuesheng-jingpin` | 青年大学生音色-beta | Premium版 |

### 职业/风格音色
| Voice ID | 名称 | 特点 |
|----------|------|------|
| `Chinese (Mandarin)_Reliable_Executive` | 沉稳高管 | 直接标注"沉稳" |
| `Chinese (Mandarin)_Male_Announcer` | 播报男声 | 权威咬字清晰 |
| `Chinese (Mandarin)_Radio_Host` | 电台男主播 | 有播音腔 |
| `Chinese (Mandarin)_Gentleman` | 温润男声 | 稳重温和 |
| `Chinese (Mandarin)_Lyrical_Voice` | 抒情男声 | 偏文艺 |
| `Chinese (Mandarin)_Sincere_Adult` | 真诚青年 | 诚恳感 |
| `Chinese (Mandarin)_Gentle_Youth` | 温润青年 | |
| `Chinese (Mandarin)_Southern_Young_Man` | 南方小哥 | 带地方口音特点 |
| `Chinese (Mandarin)_Unrestrained_Young_Man` | 不羁青年 | |
| `Chinese (Mandarin)_Straightforward_Boy` | 率真弟弟 | |

### 卡通/角色音色（偏年轻向）
| Voice ID | 名称 |
|----------|------|
| `clever_boy` | 聪明男童 |
| `cute_boy` | 可爱男童 |
| `junlang_nanyou` | 俊朗男友 |
| `chunzhen_xuedi` | 纯真学弟 |
| `lengdan_xiongzhang` | 冷淡学长 |
| `badao_shaoye` | 霸道少爷 |
| `cartoon_pig` | 卡通猪小琪 |

## 视频配音选音建议
- **已确认默认（2026-05-13）**: `Chinese (Mandarin)_Radio_Host`（电台男主播）— 用户确认适合品牌调性，有播音腔但不飘
- **沉稳备选**: `Chinese (Mandarin)_Reliable_Executive`（沉稳高管）
- **青年成熟**: `male-qn-jingying-jingpin`（精英青年音色-beta，比普通版更成熟）
- **避免**: `male-qn-qingse`（青涩青年偏年轻，不适合品牌调性）
- 换音色前必须先用同一标准文本生成候选样音，发用户确认后再批量生成

## 测试音色流程
用同一标准文本（~40字）分别生成4-5个候选音色，发飞书用户确认为准。
