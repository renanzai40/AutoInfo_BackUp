# Subtitle Rebuild Workflow (2026-05-13)

## Symptom
SRT timestamps and audio are completely desynced — subtitles appear 10-20s late or early.

## Root Cause
Whisper ASR was run on a *different* audio file than the one used in the final video. This happens when:
1. TTS is regenerated (new audio file, different duration)
2. Whisper JSON was from the old audio file
3. Final video uses the new audio → timestamps don't match

## Fix: Complete Subtitle Rebuild

### Step 1: Identify the mismatch
```bash
# Audio used in final video
ffprobe -v quiet -show_entries format=duration -of csv=p=0 final_video_audio.mp3

# Audio Whisper was run on (check Whisper JSON's last segment end time)
python3 -c "import json; d=json.load(open('whisper_result.json')); print(d['segments'][-1]['end'])"
```

### Step 2: Re-run Whisper on the correct audio
```bash
export PATH=/home/renanzai/mamba/envs/ffmpeg/bin:$PATH
WHISPER_PY=/home/renanzai/mamba/envs/whisper/bin/python3

$WHISPER_PY -c "
import whisper, json
model = whisper.load_model('base', device='cpu')
result = model.transcribe('/path/to/THE_ACTUAL_FINAL_AUDIO.mp3', language='zh')
with open('/tmp/whisper_new.json', 'w') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(f'Done: {len(result[\"segments\"])} segs, ends at {result[\"segments\"][-1][\"end\"]:.2f}s')
"
```

### Step 3: Manually anchor script sentences to Whisper timestamps
Whisper segments are ~1-4s speech fragments. A full sentence spans multiple segments.
Strategy: read Whisper output, map each script sentence to the segment range that corresponds to it.

```python
# Example mapping (Trump case)
TRUMP = [
    (0.00,   2.52,  "特朗普回来了，这次不是总统身份，是带着一帮商人来的。"),
    (4.28,   9.64,  "上次他访华签了2535亿美元大单，这次会有什么不一样？"),
    # ...
]
# [start, end] = Whisper segment boundary timestamps from the NEW audio
```

### Step 4: Write SRT
```python
def ms(s):
    h, m = int(s//3600), int((s%3600)//60)
    sec, mil = int(s%60), int((s-int(s))*1000)
    return f"{h:02d}:{m:02d}:{sec:02d},{mil:03d}"

with open('output.srt', 'w') as f:
    for i, (s, e, t) in enumerate(entries, 1):
        f.write(f"{i}\n{ms(s)} --> {ms(e)}\n{t}\n\n")
```

### Step 5: Validate timestamps
- Last entry end ≈ audio duration (error < 1s)
- Each entry chars/s between 4-12 (outlier = wrong sentence-to-timestamp mapping)
- Entry with >15 chars/s likely means the sentence overflows its time window

### Step 6: Burn with PIL
```bash
PYPIL=/home/renanzai/.hermes/hermes-agent/venv/bin/python3
$PYPIL burn_subtitles.py video_with_audio.mp4 output.mp4 \
    --segments /tmp/segs.json --fps 2 --font-size 55 --margin-v 120
```

## Key Lesson
**Audio is the source of truth.** Whisper timestamps are bound to a specific audio file. If the audio changes, the timestamps are invalid — no partial fix, full rebuild required.
