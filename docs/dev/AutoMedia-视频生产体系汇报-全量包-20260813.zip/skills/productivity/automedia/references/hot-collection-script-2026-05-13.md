# 热点采集脚本技术细节（2026-05-13）

## 脚本位置
`scripts/auto_media_hot_collection.py`

## 核心架构

```
流1: uapis.cn(微博/知乎/抖音) + B站直连API → rank归一化 → MiniMax分类 → pool.db
流2: Tavily CLI搜索(8组关键词) → Tavily score归一化 → 直接标business → pool.db
```

## 关键技术决策

### 1. 为什么用 subprocess curl 而不是 Python requests？

在 WSL 环境下，`requests.post()` 到 `api.minimaxi.com` 会超时（HTTPS 连接问题），
但 `subprocess.run(['curl', ...])` 同样调用系统 curl 却可以正常工作。

```python
cmd = [
    'curl', '-s', '--max-time', '110',
    '-X', 'POST',
    '-H', 'Content-Type: application/json',
    '-H', f'Authorization: Bearer {api_key}',
    '-d', payload,
    'https://api.minimaxi.com/v1/chat/completions'
]
result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
```

### 2. MiniMax JSON 解析：去掉 <think> 思考标签

MiniMax 返回的 `content` 包含 `<think>...</think>` 标签和 ```json```  markdown 块，
直接 `json.loads(content)` 会失败。必须先清理：

```python
def extract_json(text):
    # 去掉<think>...</think>标签
    text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
    # 去掉markdown代码块
    text = re.sub(r'```json\s*', '', text)
    text = re.sub(r'```\s*', '', text).strip()
    try:
        return json.loads(text)
    except:
        # 找{...}块
        m = re.search(r'\{[\s\S]*\}', text)
        if m:
            return json.loads(m.group())
    return None
```

### 3. MiniMax batch_size=5 避免 token 限制

20条标题一次发给 MiniMax 会导致 JSON 输出不完整（只生成 thinking 没有 JSON）。
每批5条，20条分4批调用，`max_tokens=2000`，重试2次。

```python
def minimax_classify(titles, api_key, batch_size=5):
    for i in range(0, len(titles), batch_size):
        batch = titles[i:i+batch_size]
        # ... 调用 MiniMax ...
        for attempt in range(3):
            # curl subprocess 调用
            if success:
                break
```

### 4. uapis.cn JSON 结构

```python
# 错误 ❌
items = data.get('data', {}).get('list', [])[:15]

# 正确 ✅
items = data.get('list', [])[:15]  # 顶层 key 就是 list
```

### 5. 知乎热值格式

```python
import re
def parse_hot(raw):
    m = re.search(r'[\d.]+', str(raw))
    return float(m.group()) if m else 0

hot = parse_hot(item.get('hot_value', '0'))
# "2636 万热度" → 2636.0
# "1839196" → 1839196.0
```

### 6. B站 API 在 WSL 被封

```python
# curl -s "https://api.bilibili.com/x/web-interface/ranking/v2?rid=0&day=3"
# 返回 {"code":-352,"message":"-352","ttl":1}
# 无法使用，B站热搜跳过
```

### 7. 为什么流2不经过 MiniMax 分类？

Tavily 搜索的关键词已保证是 AI 内容生产行业相关（AI视频生成、AI配音、AIGC创作平台等），
时效性 AI 新闻天然具有专业/商业属性，不需要再调用 MiniMax 判断。

流1 热搜平台（微博/知乎/抖音）的话题混杂（娱乐明星、社会新闻都有），
必须经过 MiniMax 分类才能准确判断 growth/business。

### 8. rank 归一化在脚本里真正执行

旧架构问题：rank 归一化公式只是写在 cron job prompt 里的文字描述，
cron agent 执行时只调用工具，不执行 Python 运算，公式永远不会运行。

新架构：用 `no_agent=True` 的脚本模式，整个 Python 脚本在 cron 执行环境中运行，
rank 归一化、Tavily 搜索、MiniMax 分类都在脚本内真正执行。

## 当前状态（2026-05-13）

- 流1: 微博15条 + 知乎15条 + 抖音15条 = 45条原始数据 → 归一化取TOP20 → MiniMax分类
- 流2: 8组 Tavily × ~15条 = ~120条 → 去重取TOP15 → 直接标 business
- MiniMax分类结果: business=1, growth=19（热搜平台确实AI话题少）
- Tavily入库: 15条全部 business
- pool.db 最终: ~16条 business + ~19条 growth

## 待优化项

1. Tavily 结果含繁体中文和英文，需过滤
2. 08:00 cron job 还未更新为脚本模式（仍在用 prompt 描述）
3. MiniMax 超时重试机制可以更激进（当前2次，每次110s）
