# patch 工具 `\"` 转义漂移陷阱（2026-07-02 实测）

## 症状

用 `patch(mode='replace', old_string='...', new_string='...')` 编辑含中文双引号的内容时，
如果 old_string/new_string 中包含 `\"`（JSON/工具自动添加的转义双引号），
patch 工具报错 `Escape-drift detected`：

```
Error: Escape-drift detected: old_string and new_string contain the literal sequence '\\"'
but the matched region of the file does not. This is almost always a tool-call
serialization artifact where an apostrophe or quote got prefixed with a spurious backslash.
```

## 根因

Hermes 工具调用的 JSON 序列化过程中，`"` 被自动转义为 `\"`。
当 old_string 包含 `\"` 时，patch 工具在匹配文件内容时发现文件中的是真实 `"`（无反斜杠），
于是判定转义漂移，拒绝执行。

## 修复

**将 `\"` 替换为中文书名号 `「」` 再传入 old_string/new_string。**

### ❌ 错误用法
```
old_string='也说"双模型"策略'  → 序列化后变成 \"双模型\" → patch 报 Escape-drift
```

### ✅ 正确用法
```
old_string='也说「双模型」策略'  → 无转义问题 → patch 成功
```

## 关联陷阱

- **`automedia-project-init` skill 的 Gotcha #8**：JSON 文件中的中文引号逃逸（手写 JSON 时用 `"` 导致解析器提前终止字符串）。本陷阱是 patch 工具的转义序列化问题，不是 JSON 解析问题。
- 两个问题的解决方式相同：将英文双引号 `"` 替换为中文书名号 `「」`。

## 适用场景

编辑含有中文双引号引用的文件时：
- 引用他人说的话（"他表示…"）
- 引用文章标题或术语
- 任何包含 `"` 作为中文标点的文本
