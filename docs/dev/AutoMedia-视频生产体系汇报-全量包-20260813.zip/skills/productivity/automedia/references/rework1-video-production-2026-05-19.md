# Rework1 双层字幕视频生产全链路 (2026-05-19)

> 来源：2026-05-19 引流款+业务款 rework1 实测教训
> 永久固化，适用所有视频项目

---

## 双层字幕架构

| 层级 | 内容 | 颜色 | 位置 | 显示规则 |
|------|------|------|------|---------|
| Layer 1 大标题 | 视频主题词 | 黄色+黑色描边 | 画面上1/3处 | 每帧存在，从0s到结束 |
| Layer 2 口播字幕 | 说话台词 | 白色+黑色描边 | 画面底部偏上，距底部H/6（≈320px） | 仅说话时段 |

**burn_subtitles.py 调用**：
```bash
PYPIL=/home/renanzai/.hermes/hermes-agent/venv/bin/python3
$PYPIL burn_subtitles.py video_raw.mp4 video_final.mp4 \
  --segments /path/to/segs.json \
  --big-title "视频主题词" --title-font-size 72 --title-color 255,255,0 \
  --font-size 40 --subtitle-margin-bottom 320 --margin-h 60 --fps 2 \
  --audio-file /path/to/audio.wav
```

---

## 必检清单：烧录后必须验证（Hard Gate，不通过不得发送）

### ① 视频时长 ≈ 音频时长（误差 < 1s）

**2026-05-19 实测**：音频23.26s → 烧录输出46s（差22.74s）；音频32s → 输出53.5s（差21.5s）。
`-shortest` 不能保证精确截断，必须显式截断：
```bash
ffmpeg -y -i burned.mp4 -t AUDIO_DURATION -c:v copy -c:a copy final_trimmed.mp4
```

### ② Whisper 内容验证（失败=不发）

在最终视频（截断后）上跑 Whisper，检查关键词（壹目贯维、豆包等）是否存在。

### ③ Vision QA 三帧

- t=1s：字幕行数≤3，大标题存在
- t=总长×0.5：口播字幕与脚本一致
- t=总长-5s：字幕完整收尾，品牌名正确

### ④ 无禁止素材

地图 / 品牌Logo / 可辨识人脸 / 乱码文字

---

## SRT 构建决策树

Whisper ASR on TTS音频后：
- ASR文本≈脚本文本（无近音字错误）→ Whisper边界+脚本原文
- ASR≠脚本（如"壹目贯维"→"義務官為"）→ Whisper时间轴+脚本原文+比例分配时长

---

## burn_subtitles.py 已知 bug

1. `active_text=None` 时 `'\n' in active_text` 崩溃 → 修复：提前 `return True`
2. `-shortest` 不精确截断 → 修复：显式 `ffmpeg -t AUDIO_DURATION` 截断

---

## 关键路径

- burn_subtitles.py: `~/.hermes/skills/productivity/automedia/scripts/`
- PIL: `~/.hermes/hermes-agent/venv/bin/python3`
- FFmpeg: `~/mamba/envs/ffmpeg/bin/ffmpeg`
- Whisper: `~/mamba/envs/whisper/bin/python3`
- pre_send验证: `hooks/pre_send_whisper_check.py`（发送前必须调用）
