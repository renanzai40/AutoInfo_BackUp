#!/usr/bin/env python3
"""
validate_srt_timing.py — TTS音频字幕时间轴验证工具

用法:
  python3 validate_srt_timing.py <voiceover.mp3> <subtitle.srt> [threshold_ratio]

流程:
1. 对 TTS 音频做幅度分析，提取真实语音段
2. 按 SRT Entry 统计每个 Entry 的静音间隙比例
3. 标记 gap > threshold_ratio (默认30%) 的问题 Entry
4. 输出问题列表和修正建议

threshold_ratio: 静音间隙占 Entry 总时长的比例阈值，默认 0.30
  gap > 30% = WARN; gap > 50% = ERROR
"""

import sys, re, math, wave, json
from pathlib import Path

def parse_srt(path):
    with open(path) as f:
        content = f.read()
    entries = []
    for block in content.strip().split('\n\n'):
        lines = block.strip().split('\n')
        if len(lines) >= 3:
            tc = lines[1]
            m = re.match(r'(\d+):(\d+):(\d+),(\d+)\s*-->\s*(\d+):(\d+):(\d+),(\d+)', tc)
            if m:
                s = int(m.group(1))*3600 + int(m.group(2))*60 + int(m.group(3)) + int(m.group(4))/1000
                e = int(m.group(5))*3600 + int(m.group(6))*60 + int(m.group(7)) + int(m.group(8))/1000
                text = '\n'.join(lines[2:])
                entries.append({'start': s, 'end': e, 'text': text})
    return entries

def amplitude_analysis(wav_path):
    with wave.open(wav_path, 'rb') as w:
        n_frames = w.getnframes()
        rate = w.getframerate()
        frames = w.readframes(n_frames)
        audio = array.array('h', frames)
    step = rate // 10
    rms_list = [(i/rate, math.sqrt(sum(x*x for x in audio[i:i+step])/step))
                 for i in range(0, len(audio)-step, step)]
    thr = max(r for _,r in rms_list) * 0.1
    segs = []
    in_speech = False; seg_start = 0
    for t, r in rms_list:
        if r > thr and not in_speech:
            seg_start = t; in_speech = True
        elif r <= thr and in_speech:
            segs.append((round(seg_start,2), round(t,2))); in_speech = False
    if in_speech:
        segs.append((round(seg_start,2), round(rms_list[-1][0],2)))
    return segs, thr

import array
def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    audio_path = sys.argv[1]
    srt_path = sys.argv[2]
    threshold_ratio = float(sys.argv[3]) if len(sys.argv) > 3 else 0.30

    # Convert mp3 to wav if needed
    wav_path = audio_path
    if not audio_path.endswith('.wav'):
        import subprocess
        wav_path = '/tmp/validate_temp.wav'
        r = subprocess.run(['ffmpeg', '-y', '-i', audio_path,
                           '-ar', '8000', '-ac', '1', wav_path],
                          capture_output=True)
        if r.returncode != 0:
            print(f"ERROR: ffmpeg convert failed: {r.stderr.decode()[-200:]}")
            sys.exit(1)

    segs, thr = amplitude_analysis(wav_path)
    entries = parse_srt(srt_path)

    print(f"Audio: {audio_path}")
    print(f"SRT: {srt_path} ({len(entries)} entries)")
    print(f"Speech segments: {len(segs)}, threshold={thr:.0f}")
    print(f"Problem threshold: gap > {threshold_ratio:.0%}")
    print()
    print(f"{'Status':<6} {'#':<3} {'Start':>6} {'End':>6} {'Dur':>5} {'Speech':>6} {'Gap%':>5} {'Trail':>5}  Text")
    print("-" * 90)

    problems = []
    for i, e in enumerate(entries):
        s, e_end, text = e['start'], e['end'], e['text']
        sis = [(ss,se) for ss,se in segs if ss >= s-0.1 and se <= e_end+0.1]
        total_speech = sum(se-ss for ss,se in sis)
        dur = e_end - s
        gap_ratio = 1 - total_speech/dur if dur > 0 else 1
        trailing = e_end - sis[-1][1] if sis else dur

        if gap_ratio > 0.50:
            status = 'ERROR'
        elif gap_ratio > threshold_ratio:
            status = 'WARN'
        else:
            status = 'OK'

        if gap_ratio > threshold_ratio:
            problems.append(i+1)

        print(f"{status:<6} {i+1:<3} {s:>6.1f} {e_end:>6.1f} {dur:>5.1f}s {total_speech:>5.1f}s {gap_ratio:>5.0%} {trailing:>5.1f}s  {text[:35]}")

    print()
    if problems:
        print(f"WARN/ERROR entries ({len(problems)}/{len(entries)}): {problems}")
        print()
        print("修正建议:")
        print("  1. 用 Whisper 对 TTS 音频做 ASR 得到真实时间戳")
        print("  2. 按语音段边界拆分 SRT Entry（静音间隙 > 0.3s 处拆分）")
        print("  3. 静音间隙用空文本 SRT Entry 填充")
        print("  4. concat 时长 = next_entry.start - this_entry.start")
    else:
        print("所有 Entry 静音间隙比例 < {:.0%}，无需修正".format(threshold_ratio))

    # Clean up temp
    if wav_path != audio_path:
        Path(wav_path).unlink(missing_ok=True)

if __name__ == '__main__':
    main()
