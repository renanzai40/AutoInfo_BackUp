#!/usr/bin/env python3
"""
Burn subtitles into video using Pillow (bypasses FFmpeg's ASS CJK subtitle bugs).
Extracts frames at target fps, overlays subtitles, re-encodes.

Usage:
    python3 burn_subtitles.py video.mp4 output.mp4 --segs-json '[[0,2.52,"字幕"],[3.0,5.5,"第二句"]]'

Input segments JSON format:
    [[start_time, end_time, "subtitle text"], ...]
    times in seconds (float)

Recommended config for 9:16 1080x1920 vertical video:
    python3 burn_subtitles.py video.mp4 output.mp4 \
      --segs-json '...' \
      --font-size 55 \
      --margin-v 120 \
      --margin-h 80
"""
import subprocess
import os
import sys
import json
from concurrent.futures import ProcessPoolExecutor, as_completed

FFMPEG = "/home/renanzai/mamba/envs/ffmpeg/bin/ffmpeg"


def extract_frames(video_path, output_dir, fps=2):
    """Extract frames at specified fps to output directory"""
    os.makedirs(output_dir, exist_ok=True)
    pattern = os.path.join(output_dir, "frame_%06d.jpg")
    cmd = [
        FFMPEG, "-y", "-i", video_path,
        "-vf", f"fps={fps}",
        "-q:v", "2",
        pattern
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(f"FFmpeg extract error: {r.stderr[-500:]}")
        sys.exit(1)
    frames = sorted([f for f in os.listdir(output_dir) if f.endswith(".jpg")])
    return frames, fps


def add_subtitle_to_frame(args):
    """Add subtitle text overlay to a single frame image.
    
    Renders white text with black outline on dark background.
    """
    frame_path, segments, output_path, font_size, margin_v, margin_h = args
    from PIL import Image, ImageDraw, ImageFont

    try:
        img = Image.open(frame_path).convert("RGB")
        draw = ImageDraw.Draw(img)
        w, h = img.size

        # CJK fonts — WenQuanYi Zen Hei (primary), fallback chain
        font_paths = [
            "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
            "/usr/share/fonts/truetype/wqy/wqy-zenhei/wqy-zenhei.ttc",
            "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
            "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        ]

        font = None
        for fp in font_paths:
            if os.path.exists(fp):
                try:
                    font = ImageFont.truetype(fp, font_size)
                    break
                except Exception:
                    pass

        if font is None:
            font = ImageFont.load_default()

        # Get frame time from filename (frame_000001.jpg -> 1)
        frame_num = int(os.path.basename(frame_path).replace("frame_", "").replace(".jpg", ""))
        t = (frame_num - 1) / 2.0  # fps=2 assumed

        # Find active subtitle at time t
        active_text = None
        for start, end, text in segments:
            if start <= t <= end:
                active_text = text
                break

        if not active_text:
            img.save(output_path, "JPEG", quality=92)
            return True

        # Wrap text to fit within (w - 2*margin_h)
        max_w = w - 2 * margin_h
        lines = []
        words = active_text
        # Handle explicit newlines first — split and verify each line fits
        if '\n' in active_text:
            raw_lines = active_text.split('\n')
            for raw in raw_lines:
                raw_stripped = raw.strip()
                if not raw_stripped:
                    continue
                # Verify line fits
                try:
                    bbox = draw.textbbox((0, 0), raw_stripped, font=font)
                    if bbox[2] - bbox[0] <= max_w:
                        lines.append(raw_stripped)
                    else:
                        # Fallback: auto-wrap the oversized line
                        words2 = raw_stripped
                        while words2:
                            for i2 in range(len(words2), 0, -1):
                                test = words2[:i2]
                                try:
                                    bbox2 = draw.textbbox((0, 0), test, font=font)
                                    if bbox2[2] - bbox2[0] <= max_w:
                                        lines.append(test)
                                        words2 = words2[i2:]
                                        break
                                except Exception:
                                    lines.append(words2)
                                    words2 = ''
                                    break
                except Exception:
                    lines.append(raw_stripped)
            # Skip the while loop below since we handled newlines above
            words = None
        
        while words:
            for i in range(len(words), 0, -1):
                test_line = words[:i]
                try:
                    bbox = draw.textbbox((0, 0), test_line, font=font)
                    if bbox[2] - bbox[0] <= max_w:
                        lines.append(test_line)
                        words = words[i:]
                        break
                except Exception:
                    lines.append(words)
                    words = ""
                    break

        # Calculate layout: lines centered at bottom, above margin_v
        line_h = int(font_size * 1.4)
        total_h = len(lines) * line_h
        start_y = h - margin_v - total_h

        outline_width = 3  # validated: 3px gives clean readable outline at 55pt
        for line in lines:
            try:
                bbox = draw.textbbox((0, 0), line, font=font)
                text_w = bbox[2] - bbox[0]
                x = (w - text_w) // 2
                y = start_y
                # Shadow (2px offset)
                draw.text((x + 2, y + 2), line, font=font, fill=(0, 0, 0))
                # Outline: draw 8 directions (proper stroke, not just shadow)
                for dx in range(-outline_width, outline_width + 1):
                    for dy in range(-outline_width, outline_width + 1):
                        if dx != 0 or dy != 0:
                            draw.text((x + dx, y + dy), line, font=font, fill=(0, 0, 0))
                # White text on top
                draw.text((x, y), line, font=font, fill=(255, 255, 255))
                start_y += line_h
            except Exception as e:
                pass

        img.save(output_path, "JPEG", quality=92)
        return True
    except Exception as e:
        print(f"Error processing {frame_path}: {e}")
        return False


def process_video(video_path, output_video, segments,
                  font_size=55, margin_v=120, margin_h=80, fps=2,
                  audio_file=None):
    """Main pipeline: extract -> subtitle overlay -> encode"""
    work_dir = "/tmp/frames_work"
    frames_dir = os.path.join(work_dir, "frames")

    # Clean old frames
    if os.path.exists(frames_dir):
        for f in os.listdir(frames_dir):
            os.remove(os.path.join(frames_dir, f))
    else:
        os.makedirs(frames_dir, exist_ok=True)

    # Step 1: Extract frames
    print(f"Extracting frames from {video_path}... (fps={fps})")
    frames, fps = extract_frames(video_path, frames_dir, fps=fps)
    print(f"Extracted {len(frames)} frames")

    # Step 2: Process frames in parallel
    print(f"Processing {len(frames)} frames with subtitles...")
    output_dir = os.path.join(work_dir, "frames_subtitled")
    os.makedirs(output_dir, exist_ok=True)

    tasks = []
    for frame_file in frames:
        tasks.append((
            os.path.join(frames_dir, frame_file),
            segments,
            os.path.join(output_dir, frame_file),
            font_size,
            margin_v,
            margin_h,
        ))

    success_count = 0
    with ProcessPoolExecutor(max_workers=4) as executor:
        futures = {executor.submit(add_subtitle_to_frame, task): task for task in tasks}
        for future in as_completed(futures):
            if future.result():
                success_count += 1

    print(f"Processed {success_count}/{len(frames)} frames")

    # Step 3: Re-encode to video
    print(f"Encoding to {output_video}...")
    pattern = os.path.join(output_dir, "frame_%06d.jpg")
    # Use audio_file if provided, otherwise fall back to video_path's audio
    audio_src = audio_file if audio_file else video_path
    cmd = [
        FFMPEG, "-y",
        "-framerate", str(fps),
        "-i", pattern,
        "-i", audio_src,
        "-map", "0:v", "-map", "1:a",
        "-c:v", "libx264", "-preset", "fast", "-crf", "23",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "128k",
        "-shortest",
        output_video
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(f"FFmpeg encode error: {r.stderr[-800:]}")
        return False
    return True


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Burn subtitles into video using Pillow (bypasses FFmpeg ASS bugs)")
    parser.add_argument("video", help="Input video path")
    parser.add_argument("output", help="Output video path")
    parser.add_argument("--segments", default=None, help="JSON file path with segments")
    parser.add_argument("--segs-json", default=None, help="JSON string with segments")
    parser.add_argument("--fps", type=int, default=2, help="Frame extraction fps (default: 2)")
    parser.add_argument("--font-size", type=int, default=55,
                        help="Font size in pixels (default: 55 for 9:16 1080x1920)")
    parser.add_argument("--margin-v", type=int, default=120,
                        help="Bottom margin in pixels (default: 120)")
    parser.add_argument("--margin-h", type=int, default=80,
                        help="Left/right margin in pixels (default: 80)")
    parser.add_argument("--audio-file", default=None,
                        help="External audio file to use (overrides video's embedded audio)")

    args = parser.parse_args()

    if args.segs_json:
        segments = json.loads(args.segs_json)
    elif args.segments:
        with open(args.segments) as f:
            segments = json.load(f)
    else:
        print("Error: must provide --segments or --segs-json")
        sys.exit(1)

    print(f"Processing {args.video} -> {args.output}")
    print(f"Segments: {len(segments)}, font_size={args.font_size}, "
          f"margin_v={args.margin_v}, margin_h={args.margin_h}, fps={args.fps}")

    ok = process_video(
        args.video, args.output, segments,
        font_size=args.font_size,
        margin_v=args.margin_v,
        margin_h=args.margin_h,
        fps=args.fps,
        audio_file=args.audio_file,
    )
    print("SUCCESS" if ok else "FAILED")
