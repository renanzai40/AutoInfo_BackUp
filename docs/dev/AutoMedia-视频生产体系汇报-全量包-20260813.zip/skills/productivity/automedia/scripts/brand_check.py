#!/usr/bin/env python3
"""
brand_check.py — Whisper ASR 品牌名必死检测
检测 "壹目贯维" 的常见误识别模式并输出修正映射
"""
import json, sys

BRAND_ALIASES = [
    "壹目贯维",   # 正确
    "一目惯为",   # 常见误识别
    "壹目惯为",
    "壹目关维",
    "一木贯维",
    "一目关为",
]

def check_whisper_result(whisper_json_path):
    with open(whisper_json_path) as f:
        result = json.load(f)
    
    fixes = {}
    issues = []
    
    for i, seg in enumerate(result.get("segments", [])):
        text = seg["text"]
        for alias in BRAND_ALIASES:
            if alias in text and alias != "壹目贯维":
                issues.append(f"  Segment[{i}]: '{alias}' → 应为 '壹目贯维'")
                fixes[alias] = "壹目贯维"
    
    if issues:
        print("⚠️ 品牌名误识别检测到：")
        for issue in issues:
            print(issue)
    else:
        print("✅ 品牌名检测通过：无误识别")
    
    return fixes

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 brand_check.py whisper_result.json")
        sys.exit(1)
    
    whisper_path = sys.argv[1]
    fixes = check_whisper_result(whisper_path)
    
    if fixes:
        print("\n修正映射（可传入 generate_srt_safe 的 fixes 参数）：")
        print(json.dumps(fixes, ensure_ascii=False, indent=2))