#!/bin/bash
# audio_fade_out.sh — 给TTS音频加自然渐弱结尾
# 用法: bash audio_fade_out.sh <input.mp3> <output_fade.mp3> [fade_duration=0.6]
# 原理: ffmpeg afade=t=out 在音频末尾加淡出
INPUT="$1"
OUTPUT="${2:-${INPUT%.mp3}_fade.mp3}"
DURATION="${3:-0.6}"

# 获取音频总时长（秒，精确到小数）
TOTAL=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "$INPUT")
START=$(echo "$TOTAL - $DURATION" | bc)

echo "Audio fade-out: total=${TOTAL}s, fade from=${START}s, duration=${DURATION}s"
ffmpeg -y -i "$INPUT" -af "afade=t=out:st=${START}:d=${DURATION}" "$OUTPUT"
echo "Output: $OUTPUT"
