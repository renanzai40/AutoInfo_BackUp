"""
copy_review_gate.py
强制门控：文案生成后必须执行 humanizer → copy-review → brand-cta-review 三阶 Gate。
检查 04_review/ 目录下是否有对应平台的 copy-review 输出文件。
无文件 = Gate 被跳过 = Pipeline STOP。

用法：
    import sys
    sys.path.insert(0, '/home/renanzai/.hermes/skills/productivity/automedia/scripts')
    from copy_review_gate import enforce_copy_review_gates

    # 文案生成后立即调用
    enforce_copy_review_gates(project_dir="/path/to/project/")

    # 通过 → 继续进入 CTA / TTS
    # 失败 → 抛 Exception，Pipeline STOP
"""

import json
from pathlib import Path
from datetime import datetime, timezone

SCRIPT_VERSION = "1.0"
SCRIPT_UPDATED = "2026-05-22"


def get_project_review_log(project_dir: Path) -> dict:
    log_path = project_dir / "04_review" / "review_log.json"
    if log_path.exists():
        try:
            return json.loads(log_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def write_review_log(project_dir: Path, data: dict):
    log_path = project_dir / "04_review" / "review_log.json"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = log_path.with_suffix(".json.tmp")
    tmp_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp_path.rename(log_path)


def _platform_copy_review_exists(project_dir: Path, platform: str) -> bool:
    review_dir = project_dir / "04_review"
    file = review_dir / f"copy_review_{platform}.md"
    if file.exists() and file.stat().st_size > 100:
        return True
    if (review_dir / "brand_cta_review.md").exists():
        return True
    return False


def _brand_cta_review_exists(project_dir: Path) -> bool:
    review_dir = project_dir / "04_review"
    if (review_dir / "brand_cta_review.md").exists():
        content = (review_dir / "brand_cta_review.md").read_text(encoding="utf-8")
        if "✅" in content or "PASS" in content.upper():
            return True
    log = get_project_review_log(project_dir)
    if log.get("brand_cta_passed"):
        return True
    return False


def _gate_completed_in_log(project_dir: Path, gate_key: str) -> bool:
    return bool(get_project_review_log(project_dir).get(gate_key))


def _detect_generated_platforms(project_dir: Path) -> list:
    drafts = project_dir / "01_content" / "drafts"
    platforms = []
    if not drafts.exists():
        return platforms
    for item in drafts.iterdir():
        if item.is_dir() and item.name in ["wechat", "zhihu", "xiaohongshu", "bilibili", "tiktok"]:
            if any(item.iterdir()):
                platforms.append(item.name)
    return list(set(platforms))


def enforce_copy_review_gates(project_dir: str | Path) -> dict:
    """
    强制门控检查。

    Returns:
        dict: {"passed": True, "gates": {...}} — 通过
    Raises:
        Exception: 任意 Gate 失败，Exception.message 包含具体失败原因
    """
    project_dir = Path(project_dir)
    review_dir = project_dir / "04_review"
    review_dir.mkdir(parents=True, exist_ok=True)

    log = get_project_review_log(project_dir)
    failures = []
    gates_status = {}

    # Gate G1: Humanizer
    g1_passed = _gate_completed_in_log(project_dir, "humanizer_passed")
    if not g1_passed:
        humanizer_files = list(review_dir.glob("copy_review_*.md")) + list(review_dir.glob("humanizer_*.md"))
        if humanizer_files:
            g1_passed = True
            log["humanizer_passed"] = True
            log["humanizer_passed_at"] = datetime.now(timezone.utc).isoformat()

    gates_status["G1_humanizer"] = g1_passed
    if not g1_passed:
        failures.append("Gate G1 (Humanizer): 未执行。生成文案后必须加载 humanizer skill 去除AI写作模式。")

    # Gate G2: Copy-Review
    g2_passed = _gate_completed_in_log(project_dir, "copy_review_passed")
    if not g2_passed:
        generated_platforms = _detect_generated_platforms(project_dir)
        missing = [p for p in generated_platforms if not _platform_copy_review_exists(project_dir, p)]
        if not missing:
            g2_passed = True
            log["copy_review_passed"] = True
            log["copy_review_passed_at"] = datetime.now(timezone.utc).isoformat()

    gates_status["G2_copy_review"] = g2_passed
    if not g2_passed:
        failures.append(
            f"Gate G2 (Copy-Review): 以下平台缺少 copy-review 输出文件: {missing}。"
            f"文案生成后必须加载 copy-review skill 执行五轮结构审查。"
        )

    # Gate G3: Brand CTA (Hard Gate)
    g3_passed = _gate_completed_in_log(project_dir, "brand_cta_passed")
    if not g3_passed:
        g3_passed = _brand_cta_review_exists(project_dir)
        if g3_passed:
            log["brand_cta_passed"] = True
            log["brand_cta_passed_at"] = datetime.now(timezone.utc).isoformat()

    gates_status["G3_brand_cta"] = g3_passed
    if not g3_passed:
        failures.append(
            "Gate G3 (Brand CTA): 未通过。CTA 写作后必须加载 brand-cta-review skill 执行零容忍项检查。"
            "零容忍项：品牌身份未锚定 / 无CTA / 品牌名未出现 / 视频+文章CTA方向不同步。"
        )

    log["gates"] = gates_status
    log["gate_checked_at"] = datetime.now(timezone.utc).isoformat()
    log["gate_script_version"] = SCRIPT_VERSION
    write_review_log(project_dir, log)

    all_passed = all(gates_status.values())
    if not all_passed:
        failure_msg = "\n".join(failures)
        raise Exception(
            f"[COPY REVIEW GATE FAILED — Pipeline STOP]\n"
            f"项目: {project_dir.name}\n"
            f"检查时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"Gate 状态: {gates_status}\n"
            f"失败原因:\n{failure_msg}\n\n"
            f"─────────────────────────────────\n"
            f"⚠️  强制工序不可跳过。修复后重新调用 enforce_copy_review_gates()。"
        )

    return {"passed": True, "gates": gates_status}


def mark_gate_completed(project_dir: str | Path, gate_key: str):
    project_dir = Path(project_dir)
    log = get_project_review_log(project_dir)
    log[gate_key] = True
    log[f"{gate_key}_at"] = datetime.now(timezone.utc).isoformat()
    write_review_log(project_dir, log)
    print(f"[Gate] {gate_key} marked completed for {project_dir.name}")
