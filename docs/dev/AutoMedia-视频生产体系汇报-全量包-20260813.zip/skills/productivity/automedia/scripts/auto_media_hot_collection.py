#!/usr/bin/env python3
"""
AutoMedia 08:00 热点采集脚本
双流采集 -> rank归一化 -> 写入pool.db

用法: python3 auto_media_hot_collection.py

依赖: curl, python3 (标准库: json, subprocess, sqlite3, hashlib, re, urllib)
API密钥从 ~/.hermes/.env 读取 (MINIMAX_CN_API_KEY, TAVILY_API_KEY)
"""
import os
import sys
import json
import sqlite3
import hashlib
import subprocess
import re
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlencode

# ============================================================================
# 工具函数
# ============================================================================
def parse_hot(raw):
    """解析热度值，支持纯数字(int/float)和'2636 万热度'混合格式"""
    m = re.search(r'[\d.]+', str(raw))
    return float(m.group()) if m else 0

def curl_fetch(url, params=None):
    """用subprocess curl请求，返回解析后的JSON数据（比Python requests更稳定）"""
    cmd = ['curl', '-s', '--max-time', '15']
    if params:
        url_with_params = url + '?' + urlencode(params)
    else:
        url_with_params = url
    cmd.append(url_with_params)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return json.loads(result.stdout)
    except Exception as e:
        print(f"    curl失败: {e}, stdout: {result.stdout[:100]}")
        return {}

# ============================================================================
# 0. 加载API密钥
# ============================================================================
ENV_FILE = '/home/renanzai/.hermes/.env'
MINIMAX_KEY = None
TAVILY_KEY = None

if os.path.exists(ENV_FILE):
    with open(ENV_FILE) as f:
        for line in f:
            line = line.strip()
            if line.startswith('MINIMAX_CN_API_KEY=') and not line.startswith('#'):
                MINIMAX_KEY = line.split('=', 1)[1].strip()
            elif line.startswith('TAVILY_API_KEY=') and not line.startswith('#'):
                TAVILY_KEY = line.split('=', 1)[1].strip()

# ============================================================================
# 1. 流1: 4平台热搜采集
# ============================================================================
print("=== 流1: 4平台热搜采集 ===")
flow1_raw = []

# 微博
data = curl_fetch('https://uapis.cn/api/v1/misc/hotboard', {'type': 'weibo'})
for rank, item in enumerate(data.get('list', [])[:15], 1):
    title = item.get('title') or item.get('word', '')
    hot = parse_hot(item.get('hot_value', '0'))
    if title and hot:
        flow1_raw.append({'title': title, 'source': '微博', 'rank': rank, 'raw_score': hot})
print(f"  微博: {len(data.get('list', []))}条")

# 知乎
data = curl_fetch('https://uapis.cn/api/v1/misc/hotboard', {'type': 'zhihu'})
for rank, item in enumerate(data.get('list', [])[:15], 1):
    title = item.get('title') or item.get('word', '')
    hot = parse_hot(item.get('hot_value', '0'))
    if title and hot:
        flow1_raw.append({'title': title, 'source': '知乎', 'rank': rank, 'raw_score': hot})
print(f"  知乎: {len(data.get('list', []))}条")

# 抖音
data = curl_fetch('https://uapis.cn/api/v1/misc/hotboard', {'type': 'douyin'})
for rank, item in enumerate(data.get('list', [])[:15], 1):
    title = item.get('title') or item.get('word', '')
    hot = parse_hot(item.get('hot_value', '0'))
    if title and hot:
        flow1_raw.append({'title': title, 'source': '抖音', 'rank': rank, 'raw_score': hot})
print(f"  抖音: {len(data.get('list', []))}条")

# B站 (B站API从WSL调用返回-352错误，跳过)
# data = curl_fetch('https://api.bilibili.com/x/web-interface/ranking/v2', {'rid': '0', 'day': '3'})
# for rank, item in enumerate(data.get('list', [])[:15], 1):
#     title = item.get('title', '')
#     if title:
#         flow1_raw.append({'title': title, 'source': 'B站', 'rank': rank, 'raw_score': 15 - rank})

print(f"流1原始: {len(flow1_raw)}条")

# ============================================================================
# 2. 流1 内各平台 rank 归一化
# ============================================================================
def rank_normalize(raw_list, n=15):
    """按raw_score排序，rank1=1.0, rank15=0.06"""
    sorted_items = sorted(raw_list, key=lambda x: x['raw_score'], reverse=True)
    step = 0.93 / (n - 1)
    for i, item in enumerate(sorted_items):
        item['heat_score'] = 1.0 - i * step
    return sorted_items

flow1_by_source = {}
for item in flow1_raw:
    src = item['source']
    flow1_by_source.setdefault(src, []).append(item)

flow1_normalized = []
for src, items in flow1_by_source.items():
    ranked = rank_normalize(items)
    for it in ranked:
        flow1_normalized.append(it)

print(f"流1归一化: {len(flow1_normalized)}条")

# ============================================================================
# 3. 流2: Tavily AI搜索
# ============================================================================
TAVILY_QUERIES = [
    'AI 大模型 最新进展 新闻',
    'AI视频生成 行业资讯',
    'AI配音 语音合成 新闻',
    'AIGC 创作平台 新闻',
    'AI营销内容 工具动态',
    'AI 研究突破 最新资讯',
    'AI 大模型 行业动态 最新',
    '中国AI大模型 周调用量最新',
]

def tavily_search(query, max_results=15):
    env = {**os.environ}
    if TAVILY_KEY:
        env['TAVILY_API_KEY'] = TAVILY_KEY
    try:
        result = subprocess.run(
            ['tvly', 'search', query,
             '--time-range', 'day',
             '--max-results', str(max_results),
             '--json'],
            capture_output=True, text=True, timeout=30, env=env
        )
        data = json.loads(result.stdout)
        return [{'title': item['title'], 'score': item['score']}
                for item in data.get('results', [])]
    except Exception as e:
        print(f"  Tavily [{query[:15]}...]: {e}")
        return []

print("\n=== 流2: Tavily AI搜索 ===")
flow2_raw = []
with ThreadPoolExecutor(max_workers=8) as ex:
    futures = {ex.submit(tavily_search, q): q for q in TAVILY_QUERIES}
    for future in as_completed(futures):
        q = futures[future]
        try:
            results = future.result()
            print(f"  [{q[:20]}...]: {len(results)}条")
            flow2_raw.extend(results)
        except Exception as e:
            print(f"  [{q[:20]}]: 异常 {e}")

# 去重
seen = set()
flow2_unique = []
for item in flow2_raw:
    title = item['title'][:80]
    if title and title not in seen:
        seen.add(title)
        flow2_unique.append(item)

print(f"流2去重后: {len(flow2_unique)}条")

# Tavily score rank归一化
flow2_unique.sort(key=lambda x: x['score'], reverse=True)
step = 0.93 / max(len(flow2_unique) - 1, 1)
for i, item in enumerate(flow2_unique):
    item['heat_score'] = 1.0 - i * step
    item['source'] = 'Tavily'

flow2_normalized = flow2_unique[:15]
print(f"流2归一化后: {len(flow2_normalized)}条")

# ============================================================================
# 4. MiniMax 语义去重 (curl subprocess)
# ============================================================================
def minimax_dedup(titles, api_key):
    """用MiniMax判断同事件，返回去重后的标题列表（curl subprocess版，比requests稳定）"""
    if not titles:
        return []

    prompt_lines = '\n'.join([f'{i+1}. {t}' for i, t in enumerate(titles)])
    payload = json.dumps({
        'model': 'MiniMax-M2.7',
        'messages': [{
            'role': 'user',
            'content': f'''判断以下标题哪些说的是【同一事件】，同事件的只保留一个。

标题列表：
{prompt_lines}

输出JSON格式（严格，不能有其他内容）：
{{"groups": [["事件A代表标题", "重复标题1"], ["事件B代表标题"], ...]}}

规则：
- 同事件：说的是同一件事/同一个人/同一个话题
- 保留：热度排名最靠前（列表中位置最靠前）的那个
- groups里每个子数组第一个是保留项，其余是重复项'''
        }],
        'temperature': 0.1,
        'max_tokens': 2000
    })

    cmd = [
        'curl', '-s', '--max-time', '45',
        '-X', 'POST',
        '-H', 'Content-Type: application/json',
        '-H', f'Authorization: Bearer {api_key}',
        '-d', payload,
        'https://api.minimaxi.com/v1/chat/completions'
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=50)
        raw = result.stdout
        if not raw:
            print(f"  MiniMax返回空，保留全部{len(titles)}条")
            return titles
        try:
            result_data = json.loads(raw)
        except:
            print(f"  MiniMax JSON解析失败，保留全部{len(titles)}条 (raw: {raw[:100]})")
            return titles

        content = result_data.get('choices', [{}])[0].get('message', {}).get('content', '')
        try:
            parsed = json.loads(content)
        except:
            match = re.search(r'\{[\s\S]*\}', content)
            if match:
                parsed = json.loads(match.group())
            else:
                print(f"  MiniMax去重解析失败，保留全部{len(titles)}条")
                return titles

        groups = parsed.get('groups', [])
        kept = []
        for group in groups:
            if group:
                kept.append(group[0])

        dropped = sum(len(g) - 1 for g in groups)
        print(f"  MiniMax去重: {len(titles)}条 -> {len(kept)}条 (排除{dropped}条)")
        return kept

    except Exception as e:
        print(f"  MiniMax去重失败: {e}，保留全部{len(titles)}条")
        return titles

# 流1去重
flow1_titles = list({item['title']: item for item in flow1_raw}.keys())
flow1_kept = minimax_dedup(flow1_titles, MINIMAX_KEY) if flow1_titles else []
flow1_for_db = [item for item in flow1_raw if item['title'] in flow1_kept]
flow1_for_db.sort(key=lambda x: x['heat_score'], reverse=True)
flow1_top20 = flow1_for_db[:20]

# 流2去重
flow2_titles = list({item['title']: item for item in flow2_unique}.keys())
flow2_kept = minimax_dedup(flow2_titles, MINIMAX_KEY) if flow2_titles else []
flow2_top15 = [item for item in flow2_unique if item['title'] in flow2_kept][:15]

print(f"\n流1去重后: {len(flow1_top20)}条, 流2: {len(flow2_top15)}条")

# ============================================================================
# 5. 写入数据库
# ============================================================================
DB_PATH = '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db'
now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()

# 业务关键词（用于流1的business判断）
BIZ_KW = ['经济', '汽车', '股价', '市场', '销量', '手机', '电脑', '科技',
          'AI', '模型', '芯片', '新能源', '电动', '电池', '能源', '出口', '关税',
          '互联网', '电商', '投资', '金融', '创业', '融资', 'IPO']

# 流1入库
for item in flow1_top20:
    topic_id = hashlib.md5((item['title'] + item['source']).encode()).hexdigest()
    cat = 'business' if any(kw in item['title'] for kw in BIZ_KW) else 'growth'
    cur.execute("""INSERT OR IGNORE INTO topics
        (topic_id, title, category, heat_score, source, status, correlation_score, freshness_score, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'pending', 5.0, 8.0, ?, ?)""",
        (topic_id, item['title'], cat, item['heat_score'], item['source'], now_str, now_str))

# 流2入库（直接标business）
for item in flow2_top15:
    topic_id = hashlib.md5((item['title'] + 'Tavily').encode()).hexdigest()
    cur.execute("""INSERT OR IGNORE INTO topics
        (topic_id, title, category, heat_score, source, status, correlation_score, freshness_score, created_at, updated_at)
        VALUES (?, ?, 'business', ?, 'Tavily', 'pending', 5.0, 8.0, ?, ?)""",
        (topic_id, item['title'], item['heat_score'], now_str, now_str))

conn.commit()

# 统计
cur.execute("SELECT COUNT(*) FROM topics")
total = cur.fetchone()[0]
cur.execute("SELECT COUNT(*) FROM topics WHERE category='business'")
biz = cur.fetchone()[0]
cur.execute("SELECT COUNT(*) FROM topics WHERE category='growth'")
growth = cur.fetchone()[0]

print(f"\n=== 入库完成 ===")
print(f"总话题: {total}条 (growth:{growth} + business:{biz})")

# 打印business TOP5
print(f"\n=== business TOP5 (归一化后) ===")
cur.execute("SELECT title, heat_score, source FROM topics WHERE category='business' ORDER BY heat_score DESC LIMIT 5")
for i, row in enumerate(cur.fetchall(), 1):
    print(f"{i}. [{row[2]}] {row[1]:.4f} | {row[0][:50]}")

conn.close()
print("\n✅ 采集入库完成")
