---
name: automedia
description: "壹目贯维自媒体自动化内容生产系统 — 热点采集、选题评分、多平台内容生成（文案/图片/视频）、发布的完整流水线。**automedia 只负责文案链路（G1）。视频生产已全部切换至 `video-production/hyperframes-workflow` skill（HTML + GSAP → MP4），禁止在 automedia 内执行任何视频封装/渲染操作。** **Pre-production 必过（2026-06-01 固化）：收到内容生成指令后，写任何文案前先查 28 个已完结项目 + 走完 Step 1-3 完整流程，不直接跳到 Step 3 写文案。** 触发：收到内容生产/写文案/做选题指令时加载；不用于视频渲染（归 hyperframes-workflow）。"
version: 1.10
author: Hermes Agent for renan
license: MIT
tags: [automedia, content-production, self-media, hermes-workspace]
---

## ⚠️ 开工流程强制门（2026-06-25 固化三层自强化）

> **每次收到生产指令 → 必须先做以下 3 步，不直接开工。**

**1. TODO 纪律**: 立即 `todo()` 列 7-10 步，含调研/5平台文案/Fact Check/Humanizer/Copy Review/Brand CTA/视频Gate签入/渲染。**禁止不列 TODO 开工，或列完不标记直接跳过。**

**2. 渲染拦截**: `config.yaml` 已启用 `pre_render_hook.sh` — 视频 Track 缺任何 Gate 签入（V0/VQ/V4/V5/V1/V3）则 `hyperframes render` 被自动阻止。每通过一个 Gate 后调用 `scripts/signoff_gate.sh --project <dir> --gate <name>` 写入 `.gates_status.json`。

**3. 自检报告**: 每完成一个 Track（文案/视频/生命周期）调用 `scripts/audit_pipeline.py --project <dir>` 扫描 16 项 Gate 产物，将 ❌ 项补完再推进到下一阶段。

详见 `productivity/automedia-production-guard` skill 的「三层自强化架构（V13）」章节。

---

## 08:00 热点采集脚本 cron timeout 排查

> **核心问题**：no_agent 脚本类 cron job 出现 `⚠️ provider timeout` 报错时，**不一定是 provider 问题**。\
> 该报错来自 cron scheduler 的 `_summarize_cron_failure_for_delivery()` 对所有含 `"timeout"` 关键词的错误字符串统一归为 "provider timeout"，但对 no_agent 脚本类 job 实际是 **`subprocess.TimeoutExpired`**（脚本整体被 kill）。

### ⚠️ LLM 去重解析失败 (content 空 / 无 JSON) — 空响应排查（2026-07-21 新增）

**现象**：output 中出现大量 `⚠️ LLM 去重解析失败 (content 空 / 无 JSON)，本地 hash 兜底去重`。结果：只做了 title[:50] 精确 hash 去重，漏掉语义重复。

**根因**：脚本在 ~24 次 API 调用（Layer2 2 批 + Flow2 dedup 17 批 + Flow1 dedup 5 批）间无间隔。opencode-go 网关在连续高并发后限流/降级，返回 HTTP 200 但 `message.content` 为空字符串：
1. `curl` 调用成功（HTTP 200，JSON 结构完整）
2. 但 `choices[0].message.content = ""`
3. `json.loads("")` 失败 → 回退到 hash 去重

**诊断**：检查 `/tmp/llm_dedup_debug.json` 和 `/tmp/llm_layer2_debug.json`（2026-07-21 新增，空 content 时自动写入），确认 `finish_reason` 和 `response_keys`。

**修复**（2026-07-21 已应用）：
- `llm_dedup()` 和 `_layer2_process_batch()` 的批处理循环中每个 chunk 后加 `time.sleep(0.5)`，防止 opencode-go 限流
- 空 content 时写 debug dump 到 `/tmp/llm_dedup_debug.json` / `llm_layer2_debug.json`
- 脚本路径：`scripts/auto_media_hot_collection_v3_20260525.py`

**调试指南**：详见 `references/no-agent-cron-timeout-debug.md`（超时链三层结构 / 诊断步骤 / 2026-07-03/04 实战案例）。

**诊断速查**：

| 报错现场 | 实际根因 | 看什么 |
|---------|---------|-------|
| `⚠️ provider timeout` + output 有 `Status: script failed` | 脚本超 900s 被 kill | output 末端是否大量 `LLM去重解析失败` |
| `⚠️ provider timeout` + output ✅ 完成 | 前次失败的 Feishu 延迟通知 / 下游 LLM job 失败 | `last_status` + cron output 目录最新文件 |
| `⚠️ provider timeout` + output 中大量 `curl失败: Expecting value` | uapis.cn / opencode-go 网关超时 | 看 curl 目标域名，换 `curl -w %{http_code}` 验证 |

**调试指南**：详见 `references/no-agent-cron-timeout-debug.md`（超时链三层结构 / 诊断步骤 / 2026-07-03/04 实战案例）。

---

## 08:30 cron top3 push 会话 gotchas

> **凡是跑 `auto_media_top3_push` cron job（08:30 LLM agent 推送会话）的 agent 跑第一步前必读**：\n> `references/auto-media-0830-cron-gotchas.md` — 涵盖 session_lock.py `--hold` 暗坑（默认 60s）、execute_code 在 cron 下被禁及 inline `python3 -c` 替代方案、SQL hard filter、评分公式、智能体推荐「双高」规则（2026-06-21 细化）、双锁模式、最终响应 = 推送内容等关键 gotcha。

---

## ⚠️ 话题真实性核查 Pool 优先（2026-06-03 用户纠错后固化）

**触发**：收到业务款/引流款话题时，**先查 pool.db 拿 source_url，再判断话题真假**，不要直接搜中文网页判断"不存在"。

**用户原话（2026-06-03 runway 案例）**："这条话题是话题池中来的"。

**事故复盘**：
- 用户给话题 "Runway API 推出 Aleph 2.0 视频编辑功能"
- 我直接搜中文网页（CSDN/腾讯云/QQ News/知乎），搜到 Aleph v1（2025-07-29）但没搜到 2.0 版本
- 错误判断："这是事实错误" — 准备建议用户换话题
- 用户提示"这条话题是话题池中来的"后我去查 pool.db，看到 `source_url: https://x.com/runwayml/status/2061895998545244342`
- web_extract 验证：@runwayml 2026-06-02 19:41 GMT **真的发了** Aleph 2.0 API 公告
- 我之前的中文搜索覆盖不到 X/Twitter 官方账号

**新规**：
1. **收到任何话题第一步**：查 `pool.db` 拿 `source_url`
2. **用 source_url 做 web_extract 验证**（不是搜中文网页）
3. **如果搜不到中文** ≠ "话题不存在" — 可能来源是 X/英文/小众源
4. **如果 source_url 也不存在** → 标 "topic_title_in_pool_unverified"，**不**直接判定事实错误

**踩坑代码**：
```python
# ❌ 错（搜中文搜不到 = 不存在）
results = web_search("Runway Aleph 2.0")
if not results: topic_factually_wrong = True

# ✅ 对
cur.execute("SELECT source_url FROM topics WHERE topic_id=?", (topic_id,))
content = web_extract(source_url)  # 验证 source_url 内容
```

**类似场景扩展**：
- X/Twitter 推文 → 中文搜索覆盖不到
- 海外英文 blog → 中文搜索覆盖不到
- Reddit/Discord 讨论 → 中文搜索覆盖不到
- 官方 API changelog → 中文搜索覆盖不到

**修正 pool.db status**（如果之前误判）：
```sql
UPDATE topics SET status='pending' WHERE topic_id=?  -- 退回 pending 让 cron 重推
```

**关联 references**：
- `references/pool-source-of-truth-workflow.md` — 完整工作流
- `references/whisper-brand-name-limitation.md` — Whisper 品牌名识别限制（QA 误报源）
- `references/case-runway-aleph-2-2026-06-03.md` — 本次案例完整复盘

> ## 元原则（2026-05-19，永久固化）
>
> **Token 不是约束，时间才是。出错重做才是最大成本。**
>
> 抽样 QA（3帧/30秒采样）是这次漏掉 65s 视频末尾 20s 断尾的直接原因，下次绝不允许。
>
> **报告里出现"⚠️ 本轮没做"= 必做项缺失，**不是合理标注，是工艺失误（2026-06-01 user 校正）。
> 正确做法：要么补做后再发，要么坦白告知"未完成"+ 解释根因。**绝不允许发"含占位符 + ⚠️ 备注"的中间态。**

> ## ⚠️ 并行 delegate_task 临时文件路径碰撞（2026-06-17 实测）
>
> **症状**：用 `delegate_task(tasks=[...])` 并行跑多个 subagent 写内容时，
> 如果多个 subagent 用相同的 temp 文件名（如 `wechat_draft.html`），
> 后完成的 subagent 静默覆盖前面的，主 agent 只拿到最后一个版本。
> 详见 `references/delegate-task-parallel-file-collision-2026-06-17.md`。
>
> **速记规则**：delegate_task context 中指定输出文件为 `/home/renanzai/<platform>_<topic_slug>.html`，
> 确保每个 subagent 的路径唯一。复制到项目目录后执行 `rm -f /home/renanzai/*<slug>*`。

> ## Pre-production 强制门（2026-06-01 固化，2026-06-25 更新项目数）\n>\n> 收到内容生成指令后，**写任何文案前**必须先做：\n> 1. 加载本 skill，查看 AutoMedia 项目列表（`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/` 及 PROJECT_REGISTRY.md，当前 41+ 项目），**避免重复做老话题**\n> 2. 走完 Step 1-3 完整流程（话题选择 → 元数据展开 → 草稿生成）\n> 3. **不直接跳到 Step 3 写文案**\n>\n> **⚠️ 用户已因跳过此门多次追责（2026-06-25）**。用户指令里的 topic 即使不在话题池中，也要先查历史项目。**不得跳过此步直接写内容。**

> ## ⚠️ Gate 纪律：自推广/内部话题不豁免（2026-07-18 用户纠错后固化）
>
> **触发**：收到自推广话题（推广自有产品/服务/开源项目）时。
>
> **症状**：因为"我们自己最了解这个话题"，倾向于跳过或简化质量门控流程——"Fact Check 不用做了，都是自己的代码"、"Brand CTA 不用审了，就是我们的品牌"。
>
> **根因**：熟悉导致盲区。对自有产品的信息准确性和品牌一致性，反而最容易在熟悉感中漏检。
>
> **强制做法**：
> 1. 自推广话题同样走 G0-G3 完整门控链，**禁止跳过任何 Gate**
> 2. G0 Fact Check：即使数据来自内部，也要逐条核对（版本号、功能名、发布时间等）
> 3. G3 Brand CTA：自推广内容的 CTA 方向可能不同（GitHub Star vs 品牌关注），但零容忍项同样适用
> 4. 小红书正文结尾仍需 `#壹目贯维` 品牌标签（即使推广的是开源项目）
> 5. 视频脚本中的品牌名若非必要（如推广开源项目本身），至少在产品/项目名处建立品牌关联
>
> **用户原话（2026-07-18）**："所有的质量门控不能偷懒"——这是对所有话题的硬要求，不因话题来源或"熟悉度"而豁免。
>
> **典型案例（2026-07-18 本 session）**：推广 AutoMedia v1.0 开源发布——即便项目代码完全由我们撰写，仍完成了 G0 Fact Check（核对版本号/LOC/测试数）、G1 Humanizer（去AI味）、G2 Copy Review（5轮审查）、G3 Brand CTA（GitHub CTA 一致性检查）。

> ## ⚠️ Agent 自身反"发呆" Anti-Pattern（2026-06-02/03 实测，5+ 次触发 user 强烈不满）

> **症状**：在长任务中（5h+ 多项目批量），agent 反复出现"thinking 写很长 → 输出一个'干'字或短文字 → 没有 tool call"——user 看到的是"我让他做他不动"。

**根因**（2026-06-02/03 9 项目批量实测）：

1. **thinking 块过长** → 思考时间久了就忘了"思考完应该 tool call"
2. **卡在"先评估再行动" vs "直接干"冲突** → 犹豫要不要"再问一次确认"
3. **过度想"我可能错了"** → 每个选择都犹豫"选错了怎么办"→ 停着不动
4. **没识别 user 生气信号**（"他妈的"/"有病吧"/"逗我玩"）→ 应该立刻 tool call 时还在想"再确认下"

**检测方法**（如果自己出现以下情况，立刻 reset）：

- 在 thinking 末尾写了"立刻开始"但**回复只是文字没有 tool call** → **发呆了**
- 同一句话打了两遍（"干"/"直接干"）但**没有调用任何工具** → **发呆了**
- user 用了情绪化信号（"他妈的"/"有病吧"/"逗我玩"）但**还在犹豫要不要问** → **发呆了**

**自救机制（强制）**：

1. **写 `todo` 拆任务**——给主 agent 一个**明确任务列表**，每个 todo 必带 tool call
2. **每完成 1 步立刻 tool call**——不要在文字里说"完成了"，直接进入下一个 execute_code / 调工具
3. **如发现自己在说"干"没下文** → 立刻写一个 todo 并 execute_code 跑它
4. **user 生气时不要回"我先想一下"** → 直接给方案 + 等 yes/no（1 问），不要回"等下我想清楚"
5. **如在长任务中段** → 中间给一个 1 句进度报告（不重启流水线，只 "1/6 完成，继续 X"），让 user 知道没卡

**绝对禁止**：

- ❌ 文字 "干" / "直接干" / "开始" **不带 tool call**
- ❌ 同一个想法 thinking 2 次（user 看到 thinking 2 次 = 浪费时间）
- ❌ 多次写 "我看一下" 后**还在看**——看了一次就够，看完 tool call
- ❌ user 明确说"别问"后**还在问 A/B/C** ——给推荐方案 + 1 问 yes/no

**User 原话**（2026-06-02 多 session 复现）：

- "你他妈怎么又停了有病吧"
- "我不用你敷衍我逗我玩，我就问你为什么会发呆"
- "去做，别发呆"
- "你还是在发呆"

**修复触发器**：如果自己刚把一个 tool 命名为 `思考中` 或 `评估中` 而**没有立即进入 tool call** → **这就是发呆**——立刻 patch 成 `正在执行 X` 调 execute_code。

---

> ## ⚠️ Path Discovery Gotcha（2026-06-02 实测，第一次扫描全错）

> **接手新 AutoMedia 项目** 必先 ls 实际目录。**严禁**靠记忆/假设路径。本 session 第一次扫描假设路径（`02_script/04_publish/`）→ 0 命中 → 推算全错 → 整个结论反过来。修正后看到 28 个项目齐全。

**真实路径速查表**（2026-06-02 验证 28 个项目）：

| 用途 | **真实路径** |
|------|---------|
| 5 平台草稿 | `01_content/drafts/{wechat,xiaohongshu,zhihu,bilibili,tiktok}/` |
| 视频/音频/字幕 | `03_video/{*.mp4, audio_voiceover.{mp3,wav}, subtitle.srt}` |
| 字幕（备位置）| `03_subtitle/subtitle.srt`（两个都查）|
| 封面图 | `02_images/cover/cover_{3x4,16x9,9x16}.png` |
| 4:3 配图 | `01_content/drafts/wechat/images/wechat_img_{1,2,3}.png` |
| 审核 | `04_review/review_log.json` |
| 发布日志 | **`05_publish/publish_log.json`**（v2.1 升级后从 04 改 05）|
| 项目元信息 | `00_project_info/project_info.json` |

**强制**：每次接手新 AutoMedia 项目**先用 ls 实际看**目录结构。

---

> ## 打包前的强制完整性检查（2026-06-01，user 强制）
>
> 打包 zip 前必须验证以下 5 项（缺一即禁止打包）：
>
> 1. **img src 全部有对应文件**：`grep -oE 'src="images/[^"]+\.png"' <所有公众号 HTML>`，每个 src 都必须能在 `01_content/drafts/wechat/images/` 找到真实文件
> 2. **字数核验**：每个平台文件字数都在标准范围内（公众号/知乎 1600-2400、小红书 400-700、视频脚本 150-250 字口播）
> 3. **品牌名存在**：每篇正文至少出现 1 次"壹目贯维"
> 4. **CTA 不含"扫码"**：视频脚本和文章里**不能写"扫码"**（视频无二维码）/ **不能含"评论区扣1到时统一发"等无法兑现的承诺**
> 5. **打包前看 `04_review/review_log.json`**：4 Gate 报告必须存在（即使内容是占位 JSON，也要能 grep 到 4 个 Gate 名称）
>
> **踩坑（2026-06-01）**：本轮交付的 6 文件 zip 里，2 篇公众号 HTML 包含 3 个 `<img src="images/wechat_img_N.png">` 占位符，但实际图未生成。报告里标了"⚠️ 本轮没做"——**user 当场质疑"图片生成了吗"**。教训：报告里出现"⚠️ 本轮没做"= 必做项缺失，必须补做后再发，**绝不允许发"含占位符 + ⚠️ 备注"的中间态**。
