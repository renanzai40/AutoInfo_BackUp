---
name: automedia-fact-check
description: "AutoMedia 事实核查 Hard Gate (G0) — 在脚本/内容生成后、humanizer 之前运行，确保每一个数字、统计、日期、引用都有可验证的来源。与 automedia-production-guard 的 Gate C0 规格对齐。 触发：脚本/文案写完后、humanizer 前必加载；不用于无事实主张的纯观点内容。"
trigger: After script/content generation, before humanizer gate (G0 → G1)
purpose: Every factual claim (number, statistic, date, quote) in generated content must have a verifiable source; 5-step process aligned with automedia-production-guard Gate C0
workspace_path: /home/renanzai
output_dir: 04_review/
research_dir: 00_research/
---

# AutoMedia 事实核查 Hard Gate (G0)

> 本 skill 实现 `automedia-production-guard` 中 **Gate C0: Fact Check** 的具体核查逻辑。Gate C0 触发时加载本 skill 执行 5 步验证。

## 触发条件

**执行时机**：脚本/内容生成完成后 → **立即运行本 Gate** → 通过后才进入 Humanizer (G1)。

在 `automedia-production-guard` pipeline 中的位置：
- 上游：脚本生成完成（5 平台草稿 + script_final.txt）
- 当前：**🚦 Gate C0 — Fact Check**
- 下游：**🚦 Gate C1 — Humanizer**

## Gate 目的

生成的每一条事实性陈述（数字、统计、日期、引用、对具体公司/产品/人物的断言）都必须有可追溯的原始来源。**禁止无源数据**。

---

## 5 步核查流程（与 automedia-production-guard Gate C0 对齐）

| Step | 检查项 | 数据源 | 输出 |
|------|--------|--------|------|
| **1. 来源追溯** | 确认 00_research/sources.json 中每个 source_url 可访问、内容与引文一致 | source_url、web_extract 原文 | 来源可用性清单 |
| **2. 数字验证** | 交叉核对脚本中的数字/百分比/金额/排名，比对原文或权威来源 | sources.json + LLM 交叉验证 | 数字准确度报告 |
| **3. 日期/时间线校对** | 确认所有日期、时间线、事件顺序与原文一致 | sources.json + 原文 | 时间线一致性报告 |
| **4. 引文/语录原文核对** | 引文和语录必须逐字匹配来源，禁止 paraphrasing 替代直接引用 | 原文 + 脚本 | 引文准确度报告 |
| **5. 实体/专名消歧** | 公司名、人名、产品名、术语拼写和语境一致性 | 跨平台交叉比对 | 实体一致性报告 |

### Step 1（详细）：扫描事实性声明 — 来源追溯

扫描生成的脚本和文案，找出所有潜在的事实性声明，同时对 sources.json 中的来源 URL 做可达性验证。

**数字模式（Regex）**：
| 模式 | 示例 |
|------|------|
| `\\d+%` | 87%、30% |
| `\\d+倍` | 3倍、10倍 |
| `\\d+[万亿]` | 5万亿、8000亿 |
| `\\d{4}年\\d{1,2}月` | 2024年3月 |
| `\\d+元` | 99元、12800元 |

**引用模式（关键词）**：
- 据XX报道 / 报告显示 / 研究表明 / 数据显示 / 据统计

**命名声明**：任何对特定公司、产品、人物的断言。

**来源可用性检查**：对 sources.json 中的每个 url 执行 head 请求或 web_extract，确认可访问。404/403 → 标记不可用。

### Step 2（详细）：数字验证

对 Step 1 收集的每个数字声明，按以下优先级核查：

1. **查 `00_research/sources.json`** — 数字是否出现在 `extracted_data.numbers[]` 中？匹配 → **VERIFIED ✓**
2. **查 `00_research/source_article.md`** — 在原始研究文章中搜索该数字 → **VERIFIED ✓**（同时补充到 sources.json）
3. **web_extract 原文** — source_url 可用时重新提取原文交叉核对
4. **LLM 交叉验证** — 用 DeepSeek-v4-flash 做二次验证："这个数字在[原文]中出现过吗？"
5. **未找到 → UNVERIFIED ⚠️**

### Step 3（详细）：日期/时间线校对

- 抽取脚本中所有日期格式（YYYY年M月D日 / YYYY-MM-DD / 年月）
- 比对 sources.json 中的 relevant_dates[] 或原文中的时间线
- 检查事件顺序逻辑（如 A 发生在 B 之前，因果链条是否合理）
- 不一致 → UNVERIFIED ⚠️

### Step 4（详细）：引文/语录原文核对

- 抽取脚本中所有带引号的语句和"据XX""XX表示"等引用句式
- 必须在原文中找到逐字匹配的段落
- **禁止**：paraphrasing 替代直接引用（除非注明 paraphrase 且标注出处）
- 找不到原文 → UNVERIFIED ⚠️

### Step 5（详细）：实体/专名消歧

- 抽取专名：公司名、产品名、人名、地名、术语
- 跨平台交叉比对：同一实体在 5 个平台的脚本中拼写一致
- 语境一致性：实体在脚本中的角色/描述与原文一致
- 拼写错误/歧义 → 修正

---

## 决策

| 结果 | 动作 |
|------|------|
| 所有 5 Step **ALL PASS** ✅ | **Gate PASS** → 继续到 Humanizer (G1) |
| 任意 Step 存在 **UNVERIFIED** ⚠️ | **Pipeline STOP** ❌ |

**STOP 时的三种修复方式**（任选其一）：
- **(a) 引源**：找到真实来源并引用，将条目加入 `sources.json`
- **(b) 删除**：直接移除无法验证的声明
- **(c) 改为主观意见**：将事实性断言改为非事实性表达
  - ❌ "数据显示..." → ✅ "我倾向于认为..."
  - ❌ "根据统计..." → ✅ "我的观察是..."

**STOP 后必须修复所有 UNVERIFIED 才能重跑 Gate。**

---

## 输出报告格式

在 `04_review/` 目录下生成 `fact_check_report.md`（JSON 格式），供 automedia-production-guard 的 Gate C0 判定：

```json
{
  "gate": "C0",
  "status": "passed",
  "steps": {
    "source_traceability": {
      "status": "pass",
      "details": [
        {"url": "https://example.com/news", "accessible": true, "match": true}
      ]
    },
    "number_verification": {
      "status": "pass",
      "details": [
        {"claim": "市场占有率87%", "source": "sources.json[0]", "status": "verified"}
      ]
    },
    "date_timeline": {
      "status": "pass",
      "details": [
        {"date": "2025年3月", "verified": true}
      ]
    },
    "quote_verification": {
      "status": "pass",
      "details": [
        {"quote": "这是历史性突破", "source": "source_article.md para3", "exact_match": true}
      ]
    },
    "entity_disambiguation": {
      "status": "pass",
      "details": [
        {"entity": "DeepSeek-v4-flash", "consistent": true}
      ]
    }
  }
}
```

Gate C0 读取此文件，如 `status == "failed"` → Pipeline STOP。

---

## 失败处理

| 失败场景 | 动作 |
|----------|------|
| 数字/百分比与实际不符 | 修改脚本 → 重新 Humanizer |
| source_url 404 或不可达 | 标记为"无法验证"→ 从脚本移除该引用 |
| 引文/语录无法核对 | 用 paraphrasing 替代（注明来源） |
| 实体名称拼写错误 | 修正拼写 → 重新 Humanizer |
| **任意 Step FAIL** | **Pipeline STOP，不得进入 Gate C1** |

---

## 反模式（永久禁止）

- ❌ "脚本是 LLM 用内部知识写的，不需要 sources.json" — LLM 内部知识可能过时/幻觉
- ❌ "source_url 不存在就跳过核查" — source_url 缺失须主动 web_extract 补充
- ❌ "只在发布前检查一次" — 必须在 Humanizer 前检查，否则 Humanizer 后改的内容又引入新数字
- ❌ "用 LLM 的判断代替交叉验证" — LLM 倾向确认用户说的，交叉验证需外部工具

## 常见陷阱

- **LLM 幻觉**：大模型可能编造看起来合理的数字。不要轻信模型生成的数据——必须追溯来源。
- **模糊引用**："据报道""有研究显示"但没有具体出处 → 仍标记为 UNVERIFIED，除非能找到源文。
- **过时数据**：即使有来源，检查数据是否过期（例如 2021 年的行业报告在 2025 年可能已不适用）。标记为 ⚠️ STALE 并建议更新。
- **二手引用**：A 引用 B，B 引用 C → 尽量追溯到一手来源 C，否则标记为 ⚠️ SECONDARY。

## 误报模式（False Positive Patterns）

Regex 扫描数字时会捕获以下非事实性内容，需手动排除：

| 误报源 | 示例 | 处理方式 |
|--------|------|---------|
| **HTML/CSS 属性值** | `width:100%`、`font-size:48px`、`top:300px` | 跳过 CSS 属性值中的数字 |
| **元数据/字数统计** | `字数：172字`、`预计时长：约40秒`、`targetDuration: 54.7` | 跳过 script 文件尾部的元数据行 |
| **示意性举例** | "以前等 10 秒出一段文案"、"日均产出 10 篇内容" | 检查是否为合理推断，而非事实主张 |
| **近似取整** | 脚本写 "46%→96%" 但 research_notes 中的精确值为 "45.7%→95.7%" | 接受 ±1% 内的自然语言取整，在报告备注中标注 |
| **文件名/路径中的数字** | `cover_16x9.png`、`audio_voiceover.mp3` | 排除路径和文件名中的数字模式 |

**判定规则**：先判断数字是否为**事实性声明**再验证。上表中的模式**不是**事实声明，应标记为 `non-factual` 而非 `unverified`。

## 快速命令

```bash
# 在项目根目录运行 Gate
# 扫描脚本中所有声明，输出核查报告到 04_review/fact_check_report.md
# 详见 automedia-production-guard SKILL.md Gate C0 完整规范 中的实施代码
```

实际执行时按 5 步流程手动或通过脚本完成。实施代码示例见 `automedia-production-guard` SKILL.md 的 `### 🆕 Gate C0 完整规范` 章节。
