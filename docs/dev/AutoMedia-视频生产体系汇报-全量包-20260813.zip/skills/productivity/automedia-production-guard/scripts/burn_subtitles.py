#!/usr/bin/env python3
"""Burn SRT subtitles using ffmpeg drawtext with Chinese font support.

IMPORTANT: Always use a CLEAN (unsubbed) video source as VIDEO_SRC.
Never pass a file that already has burnt-in subtitles, or subtitles
will double-stack. Keep video_clean.mp4 as the unsubbed reference copy.
"""
import re, subprocess, sys, os

SRT_PATH = sys.argv[1]
VIDEO_SRC = sys.argv[2]
VIDEO_OUT = sys.argv[3]
FONT = "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"
FFMPEG = "/home/renanzai/mamba/envs/ffmpeg/bin/ffmpeg"

with open(SRT_PATH, encoding='utf-8') as f:
    srt = f.read()

entries = re.findall(r'(\d+:\d+:\d+[.,]\d+)\s*-->\s*(\d+:\d+:\d+[.,]\d+)\n(.+?)\n\n', srt, re.DOTALL)


def ts_to_sec(t):
    t = t.replace(',', '.')
    h, m, s = t.split(':')
    return int(h)*3600 + int(m)*60 + float(s)


filters = []
for i, (start, end, text) in enumerate(entries):
    s = ts_to_sec(start)
    e = ts_to_sec(end)
    txt = text.strip().replace("'", "’").replace(":", "：")

    # Auto-wrap long text at sentence boundaries (skip if already wrapped)
    if '\n' not in txt and len(txt) > 35:
        for sep in '。！？':
            idx = txt.rfind(sep, 0, 35)
            if idx != -1:
                txt = txt[:idx+1] + '\n' + txt[idx+1:]
                break
        else:
            for sep in '，；、':
                idx = txt.rfind(sep, 0, 35)
                if idx != -1:
                    txt = txt[:idx+1] + '\n' + txt[idx+1:]

    txt = txt.replace('%', '\\%')

    # Real newlines stay as-is. ffmpeg filter parser preserves literal
    # newlines inside '' quotes and passes them to drawtext as text content.
    # No \\n -> \\n conversion needed.

    f = (f"drawtext=text='{txt}'"
         f":fontfile={FONT}"
         f":fontsize=22"
         f":fontcolor=white"
         f":borderw=2"
         f":bordercolor=black"
         f":shadowx=1:shadowy=1"
         f":x=(w-tw)/2"
         f":y=h-180"
         f":text_align=C:line_spacing=10"
         f":enable='between(t,{s},{e})'")
    filters.append(f)

filter_str = ','.join(filters)
env = os.environ.copy()
env['LD_LIBRARY_PATH'] = '/home/renanzai/mamba/envs/ffmpeg/lib'

print(f"Burning {len(entries)} subtitle entries with font {os.path.basename(FONT)}...")
r = subprocess.run([FFMPEG, '-y', '-i', VIDEO_SRC, '-vf', filter_str, '-c:a', 'copy', VIDEO_OUT],
                   capture_output=True, text=True, timeout=180, env=env)

if r.returncode == 0:
    size = os.path.getsize(VIDEO_OUT) // 1024
    print(f"Done: {size}KB")
else:
    err = r.stderr[-300:]
    print(f"Failed: {err}")
    sys.exit(1)
