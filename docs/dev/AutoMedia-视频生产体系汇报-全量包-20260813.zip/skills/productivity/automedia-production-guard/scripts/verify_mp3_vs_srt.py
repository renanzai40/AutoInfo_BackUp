#!/usr/bin/env python3
"""
verify_mp3_vs_srt.py — Whisper pre-send 验证脚本（V5 Gate 实施）

> 用途：每次新生成 mp3 后、复用旧 mp3 + 新 SRT 时、TTS 引擎/voice 变化时
>       必跑此脚本，验证 mp3 朗读内容 100% = SRT 原文。
>
> 来源：6-05 终极 root cause 案例（session 113223 时代 mp3 ≠ SRT 错配）
>       + automedia-production-guard V5 Gate
>       + subtitle-srt-generation P0-1 铁律
>
> 用法：
>   python3 verify_mp3_vs_srt.py <mp3_path> <srt_path>
>   python3 verify_mp3_vs_srt.py <mp3_path> <srt_path> --threshold 90
>   python3 verify_mp3_vs_srt.py <mp3_path> <srt_path> --whisper-model small
>
> 返回：exit 0 = PASS / exit 1 = BLOCK
> 输出：覆盖率 + 缺失关键词清单 + 关键内容对照表

依赖：
- /home/renanzai/.hermes/hermes-agent/venv/bin/whisper
- 或 pip install openai-whisper
"""

import argparse
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

# Whisper 路径（hermes-agent venv）
WHISPER_BIN = "/home/renanzai/.hermes/hermes-agent/venv/bin/whisper"


def run_whisper(mp3_path: str, output_dir: str, model: str = "tiny") -> str:
    """运行 Whisper 转写 mp3，返回 SRT 路径"""
    cmd = [
        WHISPER_BIN,
        mp3_path,
        "--language", "zh",
        "--model", model,
        "--output_format", "srt",
        "--output_dir", output_dir,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    if result.returncode != 0:
        raise RuntimeError(
            f"Whisper failed (rc={result.returncode}):\n"
            f"STDOUT: {result.stdout[:500]}\n"
            f"STDERR: {result.stderr[:500]}"
        )

    # 输出文件 = <output_dir>/<mp3_basename>.srt
    mp3_basename = Path(mp3_path).stem
    srt_out = Path(output_dir) / f"{mp3_basename}.srt"
    if not srt_out.exists():
        raise FileNotFoundError(f"Whisper 输出未找到：{srt_out}")
    return str(srt_out)


def extract_chinese_words(text: str, min_len: int = 2) -> set:
    """提取 ≥2 字的中文词（忽略时间戳+英文+标点）"""
    return set(re.findall(rf'[\u4e00-\u9fff]{{{min_len},}}', text))


def extract_key_phrases(text: str) -> dict:
    """提取关键内容（公司名/产品名/品牌名/数字/动词）"""
    return {
        "公司名": set(re.findall(r'(?:Alphabet|Anthropic|OpenAI|Apple|Microsoft|Google|字节|腾讯|阿里|百度|华为|壹目贯维)', text)),
        "产品名": set(re.findall(r'(?:Codex|插件|库|模型|GPT|DeepSeek|Claude|Sora|文心一言)', text)),
        "数字": set(re.findall(r'\d+(?:\.\d+)?[万亿]?', text)),
        "中文2字以上": extract_chinese_words(text, 2),
    }


def compute_coverage(srt_path: str, whisper_path: str, threshold: float) -> tuple:
    """计算 SRT vs Whisper 文本覆盖率"""
    with open(srt_path, encoding="utf-8") as f:
        srt = f.read()
    with open(whisper_path, encoding="utf-8") as f:
        whisper = f.read()

    srt_words = extract_chinese_words(srt)
    whisper_words = extract_chinese_words(whisper)

    if not srt_words:
        return 0.0, [], srt_words, whisper_words

    common = srt_words & whisper_words
    coverage = len(common) / len(srt_words) * 100
    missing = list(srt_words - whisper_words)
    return coverage, missing, srt_words, whisper_words


def key_content_comparison(srt_path: str, whisper_path: str) -> dict:
    """关键内容对照（公司名/产品名/品牌名等必须 100% 匹配）"""
    with open(srt_path, encoding="utf-8") as f:
        srt = f.read()
    with open(whisper_path, encoding="utf-8") as f:
        whisper = f.read()

    srt_keys = extract_key_phrases(srt)
    whisper_keys = extract_key_phrases(whisper)

    result = {}
    for category, srt_set in srt_keys.items():
        if not srt_set:
            continue
        missing = srt_set - whisper_keys[category]
        if missing:
            result[category] = {
                "srt": list(srt_set),
                "whisper": list(whisper_keys[category]),
                "missing": list(missing),
            }
    return result


def main():
    parser = argparse.ArgumentParser(
        description="Whisper pre-send 验证：mp3 vs SRT 文本核验（V5 Gate）"
    )
    parser.add_argument("mp3", help="mp3 文件路径")
    parser.add_argument("srt", help="SRT 字幕文件路径")
    parser.add_argument("--threshold", type=float, default=80.0,
                        help="覆盖率阈值（默认 80%%）")
    parser.add_argument("--whisper-model", default="tiny",
                        help="Whisper 模型（tiny/small/medium/large，默认 tiny）")
    parser.add_argument("--output-dir", default=None,
                        help="Whisper 输出目录（默认 /tmp/whisper_pre_send）")
    parser.add_argument("--skip-whisper", action="store_true",
                        help="跳过 Whisper 调用（用于测试）")
    args = parser.parse_args()

    if not os.path.exists(args.mp3):
        print(f"❌ mp3 不存在：{args.mp3}", file=sys.stderr)
        sys.exit(1)
    if not os.path.exists(args.srt):
        print(f"❌ SRT 不存在：{args.srt}", file=sys.stderr)
        sys.exit(1)

    output_dir = args.output_dir or "/tmp/whisper_pre_send"
    os.makedirs(output_dir, exist_ok=True)

    # Step 1: Whisper 转写
    if args.skip_whisper:
        # 测试模式：找现有的 Whisper 输出
        mp3_basename = Path(args.mp3).stem
        whisper_srt = Path(output_dir) / f"{mp3_basename}.srt"
        if not whisper_srt.exists():
            print(f"❌ 测试模式：Whisper 输出不存在 {whisper_srt}", file=sys.stderr)
            sys.exit(1)
    else:
        print(f"🔍 跑 Whisper 转写：{args.mp3}")
        whisper_srt = run_whisper(args.mp3, output_dir, args.whisper_model)
        print(f"   ✅ Whisper 输出：{whisper_srt}")

    # Step 2: 关键词覆盖率
    coverage, missing, srt_words, whisper_words = compute_coverage(
        args.srt, whisper_srt, args.threshold
    )
    print()
    print(f"📊 覆盖率报告：")
    print(f"   SRT 关键词数：{len(srt_words)}")
    print(f"   Whisper 关键词数：{len(whisper_words)}")
    print(f"   共同关键词：{len(srt_words & whisper_words)}")
    print(f"   覆盖率：{coverage:.1f}%（阈值 {args.threshold}%）")

    # Step 3: 关键内容对照
    key_issues = key_content_comparison(args.srt, whisper_srt)
    if key_issues:
        print()
        print("🔑 关键内容对照（公司名/产品名/品牌名 必须 100% 匹配）：")
        for category, issue in key_issues.items():
            print(f"   ❌ {category}：")
            print(f"      SRT 关键: {issue['srt']}")
            print(f"      Whisper 听到: {issue['whisper']}")
            print(f"      缺失: {issue['missing']}")

    # Step 4: 决策
    print()
    if coverage < args.threshold:
        print(f"❌ V5 BLOCK：覆盖率 {coverage:.1f}% < {args.threshold}%")
        if missing:
            print(f"   缺失关键词：{missing[:10]}")
        print(f"   → mp3 朗读的不是 SRT 文本，必须重新生成 mp3")
        sys.exit(1)
    else:
        print(f"✅ V5 PASS：覆盖率 {coverage:.1f}% ≥ {args.threshold}%")
        if key_issues:
            print(f"   ⚠️  关键内容有差异：建议人工 review（详见上方）")
            sys.exit(0)
        sys.exit(0)


if __name__ == "__main__":
    main()
