# Shell Hooks & Gate Scripts

These scripts implement the three-layer enforcement architecture (V13).

| Script | Path (production) | Purpose |
|--------|------------------|---------|
| `pre_render_hook.sh` | `~/.hermes/profiles/content/scripts/pre_render_hook.sh` | Shell Hook — blocks render if video gates unsigned |
| `signoff_gate.sh` | `~/.hermes/profiles/content/scripts/signoff_gate.sh` | Sign off a gate as passed into `.gates_status.json` |
| `audit_pipeline.py` | `~/.hermes/profiles/content/scripts/audit_pipeline.py` | Full project self-check (16 gates) |

The canonical copies live in `~/.hermes/profiles/content/scripts/` (profile-level).  
This directory documents their API and purpose only.
