#!/usr/bin/env python3
"""
generate inline article images (PIL info-card style) for Gate II.
Usage:
    python3 gen_inline_images.py <project_dir> [--platforms wechat:3,zhihu:2,xiaohongshu:1] [--palette blue]

Dependencies: Pillow (pip install Pillow)
"""
import argparse, os, textwrap, json, re
from PIL import Image, ImageDraw, ImageFont

# ── config ──────────────────────────────────────────────────────────
WIDTH, HEIGHT = 800, 500
BG_COLORS = {
    "blue": (10, 30, 60), "dark": (15, 15, 25), "teal": (5, 45, 55),
    "purple": (30, 10, 50), "green": (10, 40, 20), "red": (50, 10, 10),
}
ACCENT = (0, 180, 255)
WHITE = (230, 230, 240)

# try load fonts, fallback to default (use WenQuanYi for CJK support)
try:
    FONT_TITLE = ImageFont.truetype("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc", 32)
    FONT_BODY = ImageFont.truetype("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc", 18)
    FONT_SMALL = ImageFont.truetype("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc", 14)
except:
    try:
        FONT_TITLE = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 32)
        FONT_BODY = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
        FONT_SMALL = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
    except:
        FONT_TITLE = FONT_BODY = FONT_SMALL = ImageFont.load_default()

# ── template functions ──────────────────────────────────────────────

def make_data_card(title, lines, palette="blue", subtitle=""):
    """Best for: 5-8 data entries with numbers"""
    bg = BG_COLORS.get(palette, BG_COLORS["blue"])
    img = Image.new("RGB", (WIDTH, HEIGHT), bg)
    draw = ImageDraw.Draw(img)
    draw.rectangle([0, 0, WIDTH, 6], fill=ACCENT)
    draw.text((40, 25), title, fill=ACCENT, font=FONT_TITLE)
    if subtitle:
        draw.text((40, 70), subtitle, fill=(180, 180, 200), font=FONT_SMALL)
    y = 115 if subtitle else 80
    for line in lines:
        for wrapped in textwrap.wrap(line, width=50):
            draw.text((40, y), wrapped, fill=WHITE, font=FONT_BODY)
            y += 28
        y += 8  # spacing between items
    draw.rectangle([0, HEIGHT-4, WIDTH, HEIGHT], fill=ACCENT)
    draw.text((WIDTH-140, HEIGHT-28), "壹目贯维", fill=ACCENT, font=FONT_SMALL)
    return img

def make_quickview(items, palette="teal"):
    """Best for: 6-number snapshot. items = [(emoji, label, value), ...]"""
    bg = BG_COLORS.get(palette, BG_COLORS["teal"])
    img = Image.new("RGB", (WIDTH, HEIGHT), bg)
    draw = ImageDraw.Draw(img)
    draw.rectangle([0, 0, WIDTH, 6], fill=ACCENT)
    draw.text((40, 20), "6 个数字看懂", fill=ACCENT, font=FONT_TITLE)
    y = 80
    for i, (emoji, label, value) in enumerate(items):
        col = i % 2
        x = 40 + col * 380
        row = i // 2
        ry = y + row * 120
        draw.text((x, ry), f"{emoji} {label}", fill=(180, 180, 200), font=FONT_BODY)
        draw.text((x+5, ry+30), value, fill=WHITE, font=FONT_TITLE)
    draw.rectangle([0, HEIGHT-4, WIDTH, HEIGHT], fill=ACCENT)
    draw.text((WIDTH-140, HEIGHT-28), "壹目贯维", fill=ACCENT, font=FONT_SMALL)
    return img

def make_insight_card(title, points, palette="purple", conclusion=""):
    """Best for: 1 core conclusion + 3 supporting points"""
    bg = BG_COLORS.get(palette, BG_COLORS["purple"])
    img = Image.new("RGB", (WIDTH, HEIGHT), bg)
    draw = ImageDraw.Draw(img)
    draw.rectangle([0, 0, WIDTH, 6], fill=ACCENT)
    draw.text((40, 25), title, fill=ACCENT, font=FONT_TITLE)
    y = 80
    for pt in points:
        draw.text((40, y), f"• {pt}", fill=WHITE, font=FONT_BODY)
        y += 35
    if conclusion:
        draw.rectangle([40, y+10, WIDTH-40, y+80], fill=(20, 50, 80), outline=ACCENT)
        draw.text((55, y+20), f"💡 {conclusion}", fill=ACCENT, font=FONT_BODY)
    draw.rectangle([0, HEIGHT-4, WIDTH, HEIGHT], fill=ACCENT)
    draw.text((WIDTH-140, HEIGHT-28), "壹目贯维", fill=ACCENT, font=FONT_SMALL)
    return img

# ── helpers ─────────────────────────────────────────────────────────

def save(img, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path, quality=92)
    size_kb = os.path.getsize(path) // 1024
    print(f"  ✅ {os.path.basename(path)} ({size_kb}KB)")

def parse_research_notes(project_dir):
    """Extract key numbers from research_notes.md if available"""
    path = os.path.join(project_dir, "00_research", "research_notes.md")
    if not os.path.isfile(path):
        return None
    with open(path, encoding='utf-8') as f:
        text = f.read()
    # extract numbered rows from markdown tables under Key Numbers
    numbers = []
    in_table = False
    for line in text.split('\n'):
        if 'Key Numbers' in line or '关键数据' in line:
            in_table = True
            continue
        if in_table and line.strip().startswith('|') and line.count('|') >= 3:
            cells = [c.strip() for c in line.split('|') if c.strip()]
            if len(cells) >= 2:
                numbers.append(cells[0])
        elif in_table and not line.strip().startswith('|') and line.strip():
            in_table = False
    return numbers[:8] if numbers else None

# ── main ────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Gen inline images for Gate II")
    parser.add_argument("project_dir", help="AutoMedia project directory")
    parser.add_argument("--platforms", default="wechat:3,zhihu:2,xiaohongshu:1",
                        help="e.g. wechat:3,zhihu:2,xiaohongshu:1")
    parser.add_argument("--palette", default="blue", choices=BG_COLORS.keys())
    parser.add_argument("--topic", default="data", help="topic descriptor for filename")
    args = parser.parse_args()

    assets_dir = os.path.join(args.project_dir, "02_images", "assets")
    numbers = parse_research_notes(args.project_dir)

    configs = {}
    for spec in args.platforms.split(","):
        plat, count = spec.split(":")
        configs[plat] = int(count)

    total = 0
    topic = args.topic

    # wechat: data cards
    if "wechat" in configs:
        for i in range(1, configs["wechat"] + 1):
            lines = numbers[3*(i-1):3*i] if numbers else [f"数据条目{i}.1", f"数据条目{i}.2", f"数据条目{i}.3"]
            img = make_data_card(f"数据分析 ({i}/{configs['wechat']})", lines, args.palette)
            save(img, os.path.join(assets_dir, f"wechat_0{i}_{topic}.png"))
            total += 1

    # zhihu: insight cards
    if "zhihu" in configs:
        for i in range(1, configs["zhihu"] + 1):
            img = make_insight_card(f"深度解读 ({i}/{configs['zhihu']})",
                                    [f"核心论点{i}.a", f"核心论点{i}.b", f"核心论点{i}.c"],
                                    args.palette)
            save(img, os.path.join(assets_dir, f"zhihu_0{i}_{topic}.png"))
            total += 1

    # xiaohongshu: quickview
    if "xiaohongshu" in configs:
        for i in range(1, configs["xiaohongshu"] + 1):
            items = [("📊", "数据1", "值1"), ("💰", "数据2", "值2"),
                     ("📈", "数据3", "值3"), ("🏛", "数据4", "值4"),
                     ("🔐", "数据5", "值5"), ("📌", "数据6", "值6")]
            img = make_quickview(items, args.palette)
            save(img, os.path.join(assets_dir, f"xiaohongshu_0{i}_{topic}.png"))
            total += 1

    print(f"\n🎉 Gate II: {total}张内文配图生成完成 → {assets_dir}")

if __name__ == "__main__":
    main()
