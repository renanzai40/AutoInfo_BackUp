"""
copy_review_gate.py v1.1
强制门控：文案生成后必须执行 humanizer → copy-review → brand-cta-review 三阶 Gate。
检查 04_review/ 目录下是否有对应平台的 copy-review 输出文件。

⚠️ 2026-05-22 教训：
- subagent  delegation 时报告可能写到错误目录（/home/renanzai/reports/ 而非项目 04_review/）
- 若文件不在项目的 04_review/ 内，Gate 失败，不是"自动通过"
- delegation 前必须告知 subagent：输出路径 = {project_dir}/04_review/

用法：
    import sys
    sys.path.insert(0, '/home/renanzai/.hermes/skills/productivity/automedia-production-guard/scripts')
    from copy_review_gate import enforce_copy_review_gates

    # 文案生成后立即调用
    enforce_copy_review_gates(project_dir="/path/to/project/")

    # 通过 → 继续进入 CTA / TTS
    # 失败 → 抛 Exception，Pipeline STOP
"""

import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone

SCRIPT_VERSION = "1.2"
SCRIPT_UPDATED = "2026-05-22"


def get_project_review_log(project_dir: Path) -> dict:
    """读取 review_log.json，不存在则返回空 dict。"""
    log_path = project_dir / "04_review" / "review_log.json"
    if log_path.exists():
        try:
            return json.loads(log_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def write_review_log(project_dir: Path, data: dict):
    """写入 review_log.json（原子写入，先写.tmp再rename）。"""
    log_path = project_dir / "04_review" / "review_log.json"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = log_path.with_suffix(".json.tmp")
    tmp_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp_path.rename(log_path)


def _platform_copy_review_exists(project_dir: Path, platform: str) -> bool:
    """
    检查某平台是否有 copy-review 输出文件（必须在项目的 04_review/ 目录内）。

    兼容以下所有命名格式：
    - copy_review_{platform}.md         ← 标准
    - copy_review_{platform}_report.md   ← 变体
    - {platform}_review_report.md        ← 变体
    - {platform}_review.md               ← 变体
    - {number}_{platform}_review.md     ← 编号（01_wechat_review.md 等）
    """
    review_dir = project_dir / "04_review"
    # 标准命名
    candidates = [
        review_dir / f"copy_review_{platform}.md",
        review_dir / f"copy_review_{platform}_report.md",
        review_dir / f"{platform}_review_report.md",
        review_dir / f"{platform}_review.md",
    ]
    for f in candidates:
        if f.exists() and f.stat().st_size > 100:
            return True
    # 编号文件（01_wechat_review.md, 04_xiaohongshu_review.md 等）
    for f in review_dir.glob(f"??_{platform}_review.md"):
        if f.stat().st_size > 100:
            return True
    # 兼容：brand_cta_review.md 存在即认为已过审（独立 brand CTA 文件）
    if (review_dir / "brand_cta_review.md").exists():
        return True
    return False


def _brand_cta_review_exists(project_dir: Path) -> bool:
    """
    检查 brand-cta-review 是否通过。
    优先找独立 brand_cta_review.md；
    否则从各平台 review 文件中检测是否有品牌 CTA 零容忍项通过记录。
    """
    review_dir = project_dir / "04_review"

    # 优先：独立 brand_cta_review.md
    brand_cta = review_dir / "brand_cta_review.md"
    if brand_cta.exists():
        content = brand_cta.read_text(encoding="utf-8")
        if "✅" in content or "PASS" in content.upper():
            return True

    # 兼容：从各平台 *_review*.md 中检测品牌 CTA 零容忍项
    # 策略：文件含"壹目贯维" + ("品牌身份" in content or "CTA" in content or "零容忍" in content)
    #       + ("✅" or "通过" in content) → 认为已做品牌 CTA 检查
    for f in review_dir.glob("*_review*.md"):
        content = f.read_text(encoding="utf-8")
        # 必须同时满足：品牌提及 + CTA/品牌相关关键词 + 有通过标记
        has_brand = "壹目贯维" in content
        has_cta_marker = any(kw in content for kw in ["零容忍", "品牌身份", "品牌CTA", "CTA检查", "Brand CTA"])
        has_pass = any(tok in content for tok in ["✅", "通过", "PASS", "可发布"])
        if has_brand and has_cta_marker and has_pass:
            return True

    log = get_project_review_log(project_dir)
    if log.get("brand_cta_passed"):
        return True
    return False


def _gate_completed_in_log(project_dir: Path, gate_key: str) -> bool:
    """检查 review_log.json 里某个 Gate 是否已记录为完成。"""
    return bool(get_project_review_log(project_dir).get(gate_key))


def _detect_generated_platforms(project_dir: Path) -> list:
    """从 01_content/drafts/ 推断生成了哪些平台的草稿。"""
    drafts = project_dir / "01_content" / "drafts"
    platforms = []
    if not drafts.exists():
        # 兼容：单层结构（如某些早期项目）
        content_dir = project_dir / "01_content"
        if content_dir.exists():
            for f in content_dir.rglob("wechat_draft.html"):
                platforms.append("wechat")
            for f in content_dir.rglob("zhihu*.md"):
                platforms.append("zhihu")
            for f in list(content_dir.rglob("xiaohongshu*.md")) + list(content_dir.rglob("*xiaohongshu*.md")):
                platforms.append("xiaohongshu")
        return list(set(platforms))
    for item in drafts.iterdir():
        if item.is_dir() and item.name in ["wechat", "zhihu", "xiaohongshu"]:
            if any(item.iterdir()):
                platforms.append(item.name)
    return list(set(platforms))


def enforce_copy_review_gates(project_dir: str | Path) -> dict:
    """
    强制门控检查。

    ⚠️ 关键：文件必须在 {project_dir}/04_review/ 内，不在则判定失败。
    subagent delegation 时必须告知输出路径 = {project_dir}/04_review/，
    不得写到 /home/renanzai/reports/ 等通用目录。

    Returns:
        dict: {"passed": True, "gates": {...}} — 通过
    Raises:
        Exception: 任意 Gate 失败，Exception.message 包含具体失败原因
    """
    project_dir = Path(project_dir)
    review_dir = project_dir / "04_review"
    review_dir.mkdir(parents=True, exist_ok=True)

    log = get_project_review_log(project_dir)
    failures = []
    gates_status = {}

    # Gate G1: Humanizer
    g1_passed = _gate_completed_in_log(project_dir, "humanizer_passed")
    if not g1_passed:
        # 兼容：标准 + 编号文件名
        humanizer_files = (
            list(review_dir.glob("copy_review_*.md")) +
            list(review_dir.glob("humanizer_*.md")) +
            list(review_dir.glob("??_wechat_review.md")) +
            list(review_dir.glob("??_zhihu_review.md")) +
            list(review_dir.glob("??_xiaohongshu_review.md"))
        )
        if humanizer_files:
            g1_passed = True
            log["humanizer_passed"] = True
            log["humanizer_passed_at"] = datetime.now(timezone.utc).isoformat()

    gates_status["G1_humanizer"] = g1_passed
    if not g1_passed:
        failures.append(
            "Gate G1 (Humanizer): 未执行。生成文案后必须加载 humanizer skill（creative/humanizer）去除AI写作9类模式。"
        )

    # Gate G2: Copy-Review
    g2_passed = _gate_completed_in_log(project_dir, "copy_review_passed")
    generated_platforms = _detect_generated_platforms(project_dir)
    missing = [p for p in generated_platforms if not _platform_copy_review_exists(project_dir, p)]
    if not g2_passed:
        if not missing:
            g2_passed = True
            log["copy_review_passed"] = True
            log["copy_review_passed_at"] = datetime.now(timezone.utc).isoformat()
            log["g2_platforms_checked"] = generated_platforms

    gates_status["G2_copy_review"] = g2_passed
    if not g2_passed:
        failures.append(
            f"Gate G2 (Copy-Review): 以下平台缺少 copy-review 输出文件: {missing}。"
            f"文案生成后必须加载 copy-review skill（productivity/copy-review）执行五轮结构审查。"
            f"⚠️ 报告必须写到 {project_dir}/04_review/，写到其他目录视为未执行。"
        )

    # Gate G3: Brand CTA (Hard Gate)
    g3_passed = _gate_completed_in_log(project_dir, "brand_cta_passed")
    if not g3_passed:
        g3_passed = _brand_cta_review_exists(project_dir)
        if g3_passed:
            log["brand_cta_passed"] = True
            log["brand_cta_passed_at"] = datetime.now(timezone.utc).isoformat()

    gates_status["G3_brand_cta"] = g3_passed
    if not g3_passed:
        failures.append(
            "Gate G3 (Brand CTA): 未通过。CTA 写作后必须加载 brand-cta-review skill（productivity/brand-cta-review）执行零容忍项检查。"
            "零容忍项：品牌身份未锚定 / 无CTA / 品牌名未出现 / 视频+文章CTA方向不同步 / 小红书无#壹目贯维标签。"
        )

    # 写回 review_log.json
    log["gates"] = gates_status
    log["gate_checked_at"] = datetime.now(timezone.utc).isoformat()
    log["gate_script_version"] = SCRIPT_VERSION
    write_review_log(project_dir, log)

    # 判定
    all_passed = all(gates_status.values())
    if not all_passed:
        failure_msg = "\n".join(failures)
        raise Exception(
            f"[COPY REVIEW GATE FAILED — Pipeline STOP]\n"
            f"项目: {project_dir.name}\n"
            f"检查时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"Gate 状态: {gates_status}\n"
            f"失败原因:\n{failure_msg}\n"
            f"─────────────────────────────────\n"
            f"⚠️  强制工序不可跳过。修复后重新调用 enforce_copy_review_gates()。"
        )

    return {"passed": True, "gates": gates_status}


def mark_gate_completed(project_dir: str | Path, gate_key: str):
    """
    各生产阶段完成后调用，主动标记 Gate 完成。
    用在：humanizer 跑完后、copy-review 跑完后、brand-cta-review 跑完后。
    """
    project_dir = Path(project_dir)
    log = get_project_review_log(project_dir)
    log[gate_key] = True
    log[f"{gate_key}_at"] = datetime.now(timezone.utc).isoformat()
    write_review_log(project_dir, log)
    print(f"[Gate] {gate_key} marked completed for {project_dir.name}")
