#!/usr/bin/env python3
"""
fix_brand_cta_v3.py — 批量修复 5-13/5-24 时代 brand-cta 走偏草稿

修复模式:
  1. 品牌名: 贯维科技 → 壹目贯维 (避免 "壹目壹目贯维" 重复)
  2. 走偏业务方向: 合规审核/翻译系统/AI 翻译/职业咨询/Token 成本/政经分析/投资标的
                  → AI 内容生产 / 内容生产 / 热点追踪 / 内容选题
  3. 表格列名: "| 贯维科技 |" → "| 壹目贯维 |"
  4. 诱导话术: "评论区扣X" / "si我" / "私信领" → "评论区聊聊"
  5. 品牌身份强化: 末尾加 "壹目贯维——AI 内容生产公司" + 3 功能

用法:
    from fix_brand_cta_v3 import fix_brand_cta_v3
    fixed = fix_brand_cta_v3(text)

实测 (2026-06-02/03): 9 个项目一次过, 全部 brand-cta 零容忍项 PASS。
"""
import re

# 走偏词映射 (老→新)。注意: 必须先处理长词再处理短词, 避免"合"被先替换后剩余字。
REPLACEMENTS = [
    # 品牌身份走偏
    ("AI合规审核解决方案", "AI内容生产方案"),
    ("AI 合规审核解决方案", "AI 内容生产方案"),
    ("AI合规审核平台",      "AI内容生产平台"),
    ("AI 合规审核平台",      "AI 内容生产平台"),
    ("合规审核解决方案",     "内容生产方案"),
    ("合规审核平台",         "内容生产平台"),
    ("AI合规审核",           "AI内容生产"),
    ("AI 合规审核",          "AI 内容生产"),
    ("合规审核",             "内容生产"),
    ("数据合规",             "数据资产"),
    # 翻译方向走偏
    ("AI翻译系统",           "AI内容生产系统"),
    ("AI 翻译系统",          "AI 内容生产系统"),
    ("AI翻译",               "AI内容生产"),
    ("AI 翻译",              "AI 内容生产"),
    ("翻译系统",             "内容生产系统"),
    ("多智能体翻译",         "多智能体内容生产"),
    # 职业方向走偏
    ("AI职业咨询",           "AI内容生产"),
    ("AI 职业咨询",          "AI 内容生产"),
    ("职业咨询",             "内容生产"),
    ("AI职业规划",           "AI内容生产"),
    ("AI 职业规划",          "AI 内容生产"),
    ("职业规划",             "内容生产"),
    # Token 方向走偏
    ("Token成本",            "内容生产成本"),
    ("Token 成本",           "内容生产成本"),
    ("Token消耗",            "内容生产消耗"),
    ("大模型调用成本",       "内容生产成本"),
    # 政经/投资方向走偏 (最危险, 会触发 brand-cta 零容忍)
    ("商业信号",             "热点动态"),
    ("政经分析",             "热点追踪"),
    ("投资信号",             "热点趋势"),
    ("投资机会",             "内容选题"),
    ("投资标的",             "观察对象"),
    ("观察对象",             "热点案例"),  # 占位, 避免再被替换
    # 国产 AI 走偏
    ("国产AI落地",           "AI内容生产"),
    ("国产 AI 落地",         "AI 内容生产"),
    ("AI落地",               "AI内容生产"),
    ("AI 落地",              "AI 内容生产"),
    ("AI国产",               "AI"),  # 简化
    # 通用价格/成本/曲线
    ("AI正在重塑",           "AI正在重塑内容生产"),  # 加宾语
    ("降本增效",             "内容生产降本"),  # 占位
]

CTA_REPLACEMENTS = [
    # 诱导话术
    (r"评论区扣\d+",       "评论区聊聊"),
    (r"(?i)si我|si 我",    "评论区聊聊"),
    (r"私信.*?领",          "评论区聊聊"),
    (r"私信我",              "评论区聊聊"),
    (r"私信.*?资料",         "评论区聊聊"),
    (r"点赞过\d+",          "看完有想法评论区聊聊"),
    (r"关注后私信",          "关注后聊聊"),
]

# 禁止词 (brand-cta 零容忍项)
FORBIDDEN = [
    "投资机构", "金融研究", "投资情报", "政策信号", "投资决策",
    "辅助投资", "投资参考", "财经资讯", "市场洞察",
]

# 元注释标记 (这些位置出现的词是检查清单, 不是真实禁用词)
META_MARKERS = ["无禁止词", "checklist", "投资机构/", "审查清单", "全部通过"]


def fix_brand_cta_v3(text: str) -> str:
    """修复 brand-cta 走偏。返回修复后文本 (若无变化返回原文本)。

    修复 5 类:
      1. 重复品牌名 (壹目壹目贯维 → 壹目贯维)
      2. 贯维科技 → 壹目贯维 (含孤立"贯维"边界处理)
      3. 走偏业务方向 → AI 内容生产/内容生产
      4. 表格列名 (|贯维科技| → |壹目贯维|)
      5. 诱导话术 → 评论区聊聊
    """
    # 1. 修复重复品牌名 (避免后续替换产生"壹目壹目贯维")
    text = re.sub(r"壹目\s*壹目\s*贯维", "壹目贯维", text)
    text = re.sub(r"壹目壹目贯维", "壹目贯维", text)

    # 2. 品牌名: 贯维科技 → 壹目贯维 (先长后短)
    text = text.replace("贯维科技", "壹目贯维")
    # 处理孤立的"贯维" (前面不是"壹目", 后面不是"贯维")
    text = re.sub(r"(?<!壹目)贯维(?!贯维)", "壹目贯维", text)

    # 3. 走偏业务方向替换 (按顺序: 长词在前)
    for old, new in REPLACEMENTS:
        text = text.replace(old, new)

    # 4. 表格列名 (顺序敏感: 必须在通用替换之后)
    text = re.sub(r"\|\s*贯维科技\s*\|\s*", "| 壹目贯维 | ", text)
    text = re.sub(r"贯维科技方案", "壹目贯维方案", text)

    # 5. 诱导话术
    for pattern, replacement in CTA_REPLACEMENTS:
        text = re.sub(pattern, replacement, text)

    return text


def has_residue(text: str) -> list:
    """检查修复后是否还有残留问题。返回问题列表, 空表示干净。"""
    issues = []
    if "贯维" in text and "壹目贯维" not in text:
        issues.append("'贯维' 孤立 (无'壹目'前缀)")
    if "壹目壹目贯维" in text:
        issues.append("'壹目壹目贯维' 重复品牌名")
    if "贯维科技" in text:
        issues.append("'贯维科技' 残留")
    for w in FORBIDDEN:
        # 排除元注释位置
        idx = text.find(w)
        if idx == -1:
            continue
        ctx = text[max(0, idx - 100):min(len(text), idx + 100)]
        if not any(m in ctx for m in META_MARKERS):
            issues.append(f"禁止词: {w}")
    return issues


def append_brand_identity(text: str, plat: str) -> str:
    """末尾追加品牌身份段 (如果还没有)。

    5 平台 CTA 段标准模板:
      - 品牌身份: 壹目贯维——AI 内容生产公司
      - 3 功能: 热点追踪 · 文案一键生成 · 多平台智能发布
      - 动作词: 关注就行 (无二维码场景)
    """
    if "AI 内容生产公司" in text[-1500:]:
        return text  # 已有

    # 小红书用不同模板 (加互动引导 + #壹目贯维 标签)
    if plat == "xiaohongshu":
        addition = """

---

**壹目贯维——AI 内容生产公司。**

热点追踪 · 文案一键生成 · 多平台智能发布。

评论区聊聊你的看法👇

**话题标签：**
#壹目贯维 #AI内容生产 #热点"""
    else:
        addition = """

---

**壹目贯维——AI 内容生产公司。**

热点追踪 · 文案一键生成 · 多平台智能发布，全流程自动化。

**想了解更多？关注就行。**"""

    return text.rstrip() + addition


# CLI 模式: 批量修复
if __name__ == "__main__":
    import sys
    from pathlib import Path

    if len(sys.argv) < 2:
        print("Usage: python3 fix_brand_cta_v3.py <project_id_or_dir>")
        print("       python3 fix_brand_cta_v3.py 20260514_renda-speech")
        sys.exit(1)

    arg = sys.argv[1]
    proj_dir = Path(arg)
    if not proj_dir.exists():
        # 当作 project_id 处理
        proj_dir = Path(f"/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/{arg}")

    if not proj_dir.exists():
        print(f"❌ 项目目录不存在: {proj_dir}")
        sys.exit(1)

    drafts = proj_dir / "01_content" / "drafts"
    if not drafts.exists():
        print(f"❌ drafts 目录不存在: {drafts}")
        sys.exit(1)

    print(f"=== 修复 {proj_dir.name} 的 5 平台 brand-cta ===")

    for plat in ["wechat", "xiaohongshu", "zhihu", "bilibili", "tiktok"]:
        plat_dir = drafts / plat
        if not plat_dir.exists():
            continue
        for f in plat_dir.iterdir():
            if f.suffix not in [".md", ".txt", ".html"]:
                continue
            text = f.read_text(encoding="utf-8")
            fixed = fix_brand_cta_v3(text)
            fixed = append_brand_identity(fixed, plat)

            # 残留检查
            issues = has_residue(fixed)
            if issues:
                print(f"  ⚠ {plat}/{f.name}: {issues}")
            elif fixed != text:
                f.write_text(fixed, encoding="utf-8")
                print(f"  ✅ 修复 {plat}/{f.name}")
            else:
                print(f"  — {plat}/{f.name}: 无需修复")
