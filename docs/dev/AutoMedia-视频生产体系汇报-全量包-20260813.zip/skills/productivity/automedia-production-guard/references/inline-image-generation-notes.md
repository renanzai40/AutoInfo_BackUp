# 内文配图生成方案（Gate II · PIL 信息卡片法）

> 对应 Gate II：Inline Image。本文记录 2026-06-15 首次实操中验证的方案。
> **场景**：B2B 文章的内文配图，核心需求是「数据可视化的信息卡片」，非创意视觉。

## 为什么用 PIL 而非 ComfyUI

| 维度 | ComfyUI | PIL 信息卡片 |
|------|---------|-------------|
| 速度 | ~2-5 min/张（SD 1.5 on 1660 Ti） | ~0.3秒/张 |
| 文字控制 | 不可靠（SD 生图经常乱码/缺字） | 精确控制 |
| 数据展示 | 不适合表格/数字卡片 | 专为数据可视化设计 |
| 内容相关性 | 需精心写 prompt + 可能偏题 | 直接从 research_notes.md 取数 |
| 风格一致性 | 依赖 seed + model | 统一配色+字体模板 |

**结论**：B2B 内文配图用 PIL 信息卡片方案更优。ComfyUI 保留用于封面图/视频帧图。

## 模板系统

4 种固定布局，通过 `--template` 参数选择：

| 模板 | 适用场景 | 典型内容 |
|------|---------|---------|
| `data_card` | 对比/数据条目 | Key Numbers + 条目列表 |
| `list_card` | 清单/分点 | 5-6 条要点 + 总结金句 |
| `quickview` | 速览/6数字 | 6 个关键数据一图看完 |
| `insight_card` | 核心观点论述 | 1个结论+3个论据 |

## 配色方案

```python
BG_COLORS = {
    "blue": (10, 30, 60),
    "dark": (15, 15, 25),
    "teal": (5, 45, 55),
    "purple": (30, 10, 50),
    "green": (10, 40, 20),
    "red": (50, 10, 10),
}
ACCENT = (0, 180, 255)  # 科技蓝
```

## 命名规范

```
02_images/assets/
├── wechat_01_{topic}.png
├── wechat_02_{topic}.png
├── wechat_03_{topic}.png
├── zhihu_01_{topic}.png
├── zhihu_02_{topic}.png
└── xiaohongshu_01_{topic}.png
```

## 快速命令

```bash
python3 scripts/gen_inline_images.py \
  /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/<project_id> \
  --platforms wechat:3,zhihu:2,xiaohongshu:1

# 仅微信
python3 scripts/gen_inline_images.py <project_dir> --platforms wechat:3

# 自定义色调
python3 scripts/gen_inline_images.py <project_dir> --palette teal
```

## 2026-06-15 实战数据

- 2 话题 × 6 张/话题 = 12 张图
- 总生成时间：< 5 秒
- 卡片尺寸：800×500px
- 文件大小：5-20KB/张
- QA 阈值：>5KB
