# 6 个老项目 brand-cta 走偏修复实录（2026-06-02/03 实测）

> 来源：原 `automedia-content-repair` skill 的 5 步工作流详情 + 6 项目实测 + 12 条教训。
> 已合并摘要到 `automedia-production-guard` SKILL.md **Gate F** 段。本文件保留完整修复函数 + 残留检查 + 6 项目全清单。

---

## 完整 `fix_brand_cta_v3` 修复函数（已在 `scripts/fix_brand_cta_v3.py`）

CLI 用法：
```bash
python3 ~/.hermes/profiles/content/skills/productivity/automedia-production-guard/scripts/fix_brand_cta_v3.py <project_id>
```

修复内容（自动检测，5 平台全文）：

| 类别 | 检测模式 | 修复动作 |
|------|---------|---------|
| 品牌名错 | "贯维科技" / "贯维 "（孤立）| → "壹目贯维" |
| 走偏业务 | "合规审核" / "翻译系统" / "AI 翻译" / "职业咨询" / "Token 成本" / "政经分析" / "投资标的" / "商业信号" | → "AI 内容生产" |
| 品牌身份段缺失 | 末尾 1500 字不含 "AI 内容生产公司" | 末尾追加"壹目贯维——AI 内容生产公司"段 |
| 小红书标签缺失 | 结尾无 `#壹目贯维` | 追加 "#壹目贯维 #AI内容生产 #热点" 标签 |
| 重复品牌名 | "壹目壹目贯维" | → "壹目贯维" |
| 残留检查 | grep "贯维孤立" / "贯维科技残留" | 报告需人工处理 |

> ⚠️ **bilibili/tiktok 视频脚本**：元注释里的"扫码"等词不是真 CTA，**不替换**

---

## 修复前必做：备份规范

```bash
# 1. 创建任务备份目录
BACKUP_DIR="/tmp/audit_backup_$(date +%Y%m%d)_task${TASK}_fix_brand_cta"
mkdir -p "$BACKUP_DIR"

# 2. 备份 5 平台草稿
for plat in wechat xiaohongshu zhihu bilibili tiktok; do
    cp -r "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/${PID}/01_content/drafts/${plat}" \
          "$BACKUP_DIR/${plat}_before_fix"
done

# 3. 备份 publish_log.json
cp "/mnt/d/Hermes-Workspace/01-Projects/AutoProjects/projects/${PID}/05_publish/publish_log.json" \
   "$BACKUP_DIR/publish_log.json.bak.$(date +%H%M%S)"

# 4. 写 backup_log.txt
echo "Task ${TASK}: 6 projects brand-cta fix → $BACKUP_DIR" >> /tmp/audit_backup_${date}_task${TASK}/backup_log.txt
```

---

## 6 项目修复全清单（2026-06-02 首批）

| PID | 话题类型 | 走偏词 | 修复动作 | 备份位置 |
|-----|---------|--------|---------|---------|
| 20260513_ai-model-usage | 业务款 | "Token 成本" / "投资标的" | Token 成本 → 内容生产 ; 投资标的 → 热点追踪 | `/tmp/audit_backup_20260602_taskA/` |
| 20260513_trump-china-visit | 引流款 | "政经分析" | 政经分析 → 热点追踪 | 同上 |
| 20260524_xxx-1 | 业务款 | "贯维科技" | 贯维科技 → 壹目贯维 + 末尾补品牌身份段 | 同上 |
| 20260524_xxx-2 | 业务款 | "翻译系统" | 翻译系统 → AI 内容生产 | 同上 |
| 20260524_xxx-3 | 引流款 | "合规审核" | 合规审核 → 多平台发布 | 同上 |
| 20260524_xxx-4 | 业务款 | "商业信号" | 商业信号 → 热点追踪 | 同上 |

**6/6 全部修复成功**，4 gates 全过，5 平台推送到 wechat 草稿箱。

---

## 9 in_flight → draft_uploaded 完整流水线（2026-06-02 23:44 推送）

第二批 9 个项目从 `in_flight` 推到 `draft_uploaded` 完整流程（5h 实测）：

| 步骤 | 动作 | 耗时 | 关键点 |
|------|------|------|--------|
| 1. 路径确认 | `ls` 项目目录 | 5min | 路径不能假设 |
| 2. 缺什么素材 | 5 平台盘点表 | 10min | bilibili 必补 5/9 |
| 3. 补 bilibili 草稿 | 5 段式脚本 | 5-10min/项目 | CTA 用"关注就行"非"扫码" |
| 4. 缺字幕 → Whisper | `whisper` CLI | 10min/项目 | **必人工校对**专有名词 |
| 5. 生图 6 张 | MiniMax image-01 | 2-3min/张 | 9:16 触发 `input new_sensitive` 用抽象词 fallback |
| 6. wechat 上传 5 步 | access_token → 3 图 → 封面 → HTML → draft/add | 5min/项目 | ⚠️ **unicode escape 乱码** |
| 7. 更新 publish_log | 标 `draft_uploaded` + 双记录 | 1min | `publog.status` = `platforms.wechat.status` 必须同步 |
| 8. 重跑 compute_status | `compute_project_status.py` | 5min | 验证最终状态 |
| 9. 报告 user | N 个项目 + content_id | 5min | 等用户在公众号草稿箱点发布 |

**9 个项目 content_id** 在 `/tmp/wechat_fix_results_*.json`。

---

## 6-03 unicode escape 乱码 9 项目修复全过程

### 现象
公众号草稿箱 9 个新草稿**全部**显示为 unicode escape 形式（`\u51fa\u54c1\uff1a\u58f9\u76ee\u8d2f\u7ef4` 而不是 `出品：壹目贯维`）。

### 根因
昨晚那个 main-agent-2026-06-02 的 `execute_code` 里用了：
```python
resp = requests.post(url, json=payload, timeout=30)
```
`requests.post()` 的 `json=` 参数**内部调 `json.dumps(payload, ensure_ascii=True)`**（requests 默认），把中文 escape 成 `\uXXXX`。

**HTML 源文件本身完全干净**（只是经过 API 这一层被 escape）。

### 修法（5 步）

1. **不要 inline 写 API**——必须用 skill 的 `upload_draft.py`（已 `ensure_ascii=False`）或新写的 `safe_upload_wechat.py`（4 步硬门控）
2. **先 draft/delete 旧 content_id**（按 wechat-upload-checklist Step 0.5 流程）
3. **用 `data=json.dumps(payload, ensure_ascii=False).encode("utf-8")`** 显式 ensure_ascii=False
4. **更新 publish_log.json 双记录**（v1_drafts=deleted, v2_drafts=active）
5. **跑 A 验证**（`verify_published_content.py`）确认新 payload 重建后无 unicode escape

### 永久预防（3 个硬门控，已落地）

| 方案 | 文件 | 功能 |
|---|---|---|
| **A post-verification** | `~/.hermes/profiles/content/skills/productivity/automedia/hooks/verify_published_content.py` | 对每个 draft_uploaded 项目重建 payload，验证无 unicode escape |
| **B unit test** | `~/.hermes/profiles/content/skills/productivity/automedia/hooks/test_upload_draft_ensure_ascii.py` | 守住所有 wechat 上传脚本的 `ensure_ascii=False`，6/6 检查 |
| **C 唯一安全入口** | `~/.hermes/profiles/content/skills/productivity/automedia/hooks/safe_upload_wechat.py` | 4 步硬门控：pre_check + self_check + upload + log |

**SKILL.md L1420 已加 🚨 硬条款**：禁止 `requests.post(json=...)` 写法，agent 调 `safe_upload_wechat.py`。

### 6-03 修复的 9 个项目

- 0424_rare-earth-leak / 0424_ai-translation / 0507_ai-career-10jobs
- 0508_ai-career-replacement / 0508_ai-domestic / 0513_ai-model-usage
- 0513_trump-china-visit / 0526_deepseek / 0526_lorai-marketing

全部 9/9 修复成功，9 个新 content_id 在 `/tmp/wechat_fix_results_*.json`。

### 永久禁止（写进 automedia/SKILL.md L1420）

- ❌ `requests.post(url, json=payload)` — requests 默认 ensure_ascii=True
- ❌ inline `json.dumps(payload).encode("utf-8")` — 漏 ensure_ascii=False
- ❌ inline urllib + 默认 `json.dumps(...)` — 同上
- ❌ 跳过 `safe_upload_wechat.py` 直接调 `upload_draft.py`（失去 self_check 兜底）

**Step 2 self_check 是最后一道闸**：模拟序列化 payload 并检测 unicode escape，发现立即 exit 1，不调用 API。

---

## 12 条教训（2026-06-02/03 实测）

1. **不要逐个手动改 5 平台**——批量跑 `fix_brand_cta_v3` 函数，5 分钟搞定 6 个项目
2. **不要相信"已交付项目不改进"**——本 Gate 是"修缺陷"不是"改进内容"，不违反 memory §11
3. **不要在修复前忘记备份**——`/tmp/audit_backup_<date>_<task>/` 必备
4. **修复后必跑 4 gates**——任何 1 项失败都不能上传
5. **品牌身份段必加**——只改品牌名不够，必须有"壹目贯维——AI 内容生产公司"明确段
6. **6/9 项目都有相同 pattern**——以后看到 5-13/5-24 时代项目直接走本 Gate 不用评估
7. **subagent 跑完整流水线会超时 (600s 不够)**——subagent 适合"补素材不跑上传"等小任务；主 agent 跑 gates + wechat 上传
8. **路径假设会全错**——接手项目**先 ls 看真实目录**（详见"真实项目目录结构"表格）。第一次扫描用错误路径 0 命中 = 灾难
9. **Whisper 输出必人工校对**——专有名词错率高（"一目惯为" / "议员" / "县方案"等）。时间戳保留，文字按原文校对
10. **MiniMax image `image_urls` 复数**（不是 image_url）。9:16 比例可能触发 `input new_sensitive` 敏感词——用抽象提示词 fallback
11. **publog.status 与 platforms.wechat.status 必须同步**——user 标 published 时只改 platforms 不改顶层 = compute_status 推算错
12. **08:30 cron 推送 + 6 项目补传并行执行**——单 agent 串行不现实，subagent 并发也常超时。**主 agent 串行 6 个项目 ≈ 1.5-2 小时**（每项目 15-20 分钟）
