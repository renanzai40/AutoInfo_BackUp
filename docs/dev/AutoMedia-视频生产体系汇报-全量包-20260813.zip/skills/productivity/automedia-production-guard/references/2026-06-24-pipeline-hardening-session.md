# 2026-06-24 Pipeline 硬化事故复盘

## 触发

选题推送当天，用户发现视频时长 16s 而非应有的 60s，语音为乱码（"7500 AI" 音节碎片）。

## 根因链

| 层 | 问题 | 类型 |
|----|------|------|
| L1 | 用了 text_to_speech 工具（hermes 内置 TTS），非 edge-tts CLI | 工具选择错误 |
| L2 | voice_compatible: false 被忽略（工具明确告知不可用） | Gate V4 未执行 |
| L3 | TTS 后未做 Whisper 验证（渲染前跑 Whisper 会立刻发现"7500 AI"） | Gate V5 未执行 |
| 本质 | 三个 Gate 都是 doc-only（"agent 别忘了检查"），没有 exit code 拦阻 | 系统级缺陷 |

## 当天修复的三层

| 层 | 修复 | 文件 |
|----|------|------|
| 1 脚本层 | tts_produce.py: edge-tts + 自动 fallback + Whisper 验证 + exit code | scripts/tts_produce.py |
| 2 Gate 硬化 | V4/V4.5/C3.5 从 doc 文字改为 exit code 强制执行 | 合入 tts_produce.py |
| 3 数据固化 | zh-CN-YunjianNeural 写入 memory + 禁用 text_to_speech | memory |

## 二阶段发现的另一断点

Pipeline 完成后发现 WeChat 上传和博客发布也是 doc-only：

| Gate | doc 标注 | 实际执行 |
|------|---------|---------|
| 公众号上传 | wechat-upload-checklist ← 强制 | agent 从未调 upload_draft.py |
| Gate B0 | Blog Auto-Publish ← 自动 | 无代码级触发 |

修复：pipeline_post_production.py — 管线出口唯一脚本，exit 0。

## 硬化方法论（本 session 固化的类级教训）

1. doc 里的「强制/自动」如果背后没有独立脚本 + exit code，等于没写
2. 发现 doc-only Gate → 三步修复：写脚本 → 注册到「执行入口」→ smoke test
3. 脚本不能保证外部 API 成功，但能保证「一定会被尝试，失败一定有记录」
