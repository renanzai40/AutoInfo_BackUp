# 字幕文本来源：MTV ≠ AutoMedia（2026-05-23 新增）

## 两者都对，是场景不同

MTV 和 AutoMedia 的字幕文本来源规则不同，不是矛盾：

| 场景 | 音频内容 | 文本权威来源 | 为什么 |
|------|---------|------------|--------|
| AutoMedia（subtitle-srt-generation） | TTS 照着脚本读 | **脚本文本** | 脚本已知正确，不需要 Whisper 听写 |
| MTV（creative-mtv） | MiniMax 音乐模型**自编歌词** | **Whisper ASR 实际演唱文本** | 模型唱的可能和歌词文件文字不同 |

## MTV 用 Whisper 文本的原因

MiniMax 音乐模型不照歌词文件唱歌——它把歌词当参考，自己生成语义相似但文字不同的演唱版本。

例如：歌词写了"如此生活三十年"，模型可能唱"我三十年"。

如果用歌词文件文本做字幕 → 文字与演唱内容不符，用户看到字幕和唱的不一样。

## AutoMedia 用脚本文本的原因

TTS 是照着脚本生成的，脚本 = 已知正确的文本。用比例分配时间轴即可。

## 规律

- **"照稿读"** → 脚本权威（Whisper 只辅助时间轴）
- **"创作生成"** → Whisper 权威（Whisper 是唯一真相来源）

## MTV 是 subtitle-srt-generation 的例外场景

MTV skill（`creative-mtv/SKILL.md`）已注明这是例外，AutoMedia 使用 subtitle-srt-generation skill 的标准流程，两者不矛盾。
