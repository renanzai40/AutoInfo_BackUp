# Cron 作业 Schema Gate（2026-06-01 新增，预条件）

## Cron 作业 Schema Gate（2026-06-01 新增，预条件）

> **本 Gate 是 5 个生产 Gate 的预条件**：cron 作业 schema 不对 → 脚本跑不起来 / 跑完推不出去 → 后续 Gate 全无意义。
> 触发时机：每次改 `~/.hermes/profiles/content/cron/jobs.json` 之前，每次改 `Scripts/auto_media_hot_collection_v3_*.py` 之前。

**4 个必查字段 schema**（每个都有专门 skill + Pitfall 章节）：

| 字段 | 合法值 | 失败现象 | 修法 skill |
|------|--------|---------|-----------|
| `deliver` | 显式 `feishu:oc_xxx`，逗号分隔 | 单独 `origin` 报 [230001]/[230002] | `cron-deliver-format` |
| `repeat` | dict `{"times": N or null, "completed": 0}` | 字符串 `"forever"` 在 run action 报 `'str' has no attribute 'get'` | `cron-repeat-schema` |
| `LLM 模型名` | 全文统一（当前 `deepseek-v4-flash`） | 旧名 MiniMax 调用返回 4xx | `model: deepseek-v4-flash`（2026-06-09 迁移） |
| `print` 模板 | 只打 `type(e).__name__` | `f"失败: {e}"` 暴露 `CalledProcessError.cmd` 含 API key | `cron-output-redaction` |

**完整排查 transcript + 修复前后 jobs.json 对照**：见 `references/cron-job-schema-2026-06-01.md`

**修法铁律**：
1. 改 jobs.json 之前 `cp jobs.json jobs.json.bak.$(date +%Y%m%d_%H%M%S)_<what-fix>`
2. 改完用 `send_message action='send'` 直接测目标 ID 可达
3. **不要相信 `cronjob run` 后 `last_delivery_error` 的状态变化**（不真跑），等真到 cron 时间验证
4. 脚本路径不能在 `scripts/` 外，symlink 会被 `_validate_cron_script_path` 拦，要 `cp` 进去
