# #🆕 Gate R0 完整规范：Research（2026-06-15 新增）

### 🆕 Gate R0 完整规范：Research（2026-06-15 新增）

> **对应缺口**：GAP-R1（素材研究环节缺失）。话题确认后、脚本写作前，必须从 `source_url` 读原文，提取硬数据，建立可溯源档案。

**核心原则**：所有脚本中的事实主张必须有据可查。禁止仅凭 LLM 内部知识写脚本。

#### 执行流程（3 步，必跑）

```
Step 1: 查 source_url
  → sqlite3 pool.db "SELECT source_url FROM topics WHERE topic_id='$TOPIC_ID'"
  → 有 source_url → Step 2
  → 无 source_url → 跳 Step 3

Step 2: 读原文
  → web_extract(source_url) → 00_research/source_article.md
  → 提取关键数据到 00_research/research_notes.md
  → 写入 00_research/sources.json（含数字/引文/实体/日期）

Step 3: 无 URL 补救
  → web_search 2-3 个权威来源
  → 读搜索结果，选最相关的主要来源
  → 写入 sources.json（标记 primary_source + supplementary）
```

#### 产出物

```bash
00_research/
├── source_article.md    # 原始文章全文（Step 2）
├── research_notes.md    # 结构化调研笔记（Key Numbers / Quotes / Entities / Dates）
└── sources.json         # 机器可读源记录档案
```

完整规范见 `automedia-research` skill。

#### V13(2026-06-25) 单 Profile 三层自强化架构

> **核心认知**：所有 Gate 都可以被我跳过。逐项审计结果：23 个 Gate 中，L3（doc-only）轻松跳过，L2（有脚本但 agent 需主动调）可跳过，L1（exit code 拦截）也在 2026-06-25 被跳过（绕过 tts_produce.py 直调 edge-tts）。不存在「不太可能被跳过」的 Gate。
>
> **修复思路**：不是追求物理不可绕过（单 profile 做不到），而是追求「每次 bypass 都需要做额外一步，那一步用户会看见」。
