# ❗ LLM-driven job（有 prompt 字段）不需要 script 字段，修正前的老检查会误报 3 个健康 job 为 broken。

## ❗ LLM-driven job（有 prompt 字段）不需要 script 字段，修正前的老检查会误报 3 个健康 job 为 broken。
python3 -c "
import json
d = json.load(open('/home/renanzai/.hermes/profiles/content/cron/jobs.json'))
broken = []
for j in d.get('jobs', []):
    has_script = bool(j.get('script'))
    has_prompt = bool(j.get('prompt'))
    if not has_script and not has_prompt:
        broken.append(j)
    elif has_script and '--' in str(j.get('script', '')):
        broken.append(j)
for j in broken:
    print(f'❌ {j[\"id\"]} | script={j.get(\"script\")} | prompt={bool(j.get(\"prompt\"))}')
# 输出空 = 段 1 健康；有输出 = 段 1 错，STOP

# Step 2: 任务执行层（last_status + 输出文件）
hermes cron list | head -50
ls -la ~/.hermes/profiles/content/cron/output/<关键 job_id>/  # mtime 应为今日

# Step 3: 业务副作用层（**关键！** 必查 db delta）
sqlite3 /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db \
  "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL"
# 数值应该随 cron 跑下降。**长期不变 = 段 2/3 静默坑**

# Step 4: 手动跑一次 m3 验证（生产前必跑）
before=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL")
HERMES_CRON_SCRIPT_TIMEOUT=1800 python \
  ~/.hermes/profiles/content/scripts/judge_topics_angle.py --limit 50
after=$(sqlite3 pool.db "SELECT COUNT(*) FROM topics WHERE angle_score IS NULL")
echo "delta: $((before-after))"
# delta > 0 = 健康；delta=0 = 静默坑，需查 references/cron-silent-noop-patterns.md
```

**3 段全 PASS 才放行**，任一失败 → Pipeline STOP，**禁止启动生产链路**。

**反模式（永久禁止）**：
- ❌ "last_status=ok 就够了"——这是 2026-06-06 单日发现 5 个静默坑的根因
- ❌ "cron 跑了很久了，肯定没问题"——audit_08x05 静默 no-op 26 天
- ❌ "今天没时间跑 Pre-flight，直接进生产"——上游数据问题会让下游生产 100% 返工

**完整诊断方法 + 4 大类反模式**：见 `automedia-topic-pool/references/cron-silent-noop-patterns.md`

**与现有 Watchdog（09:30 daily）的关系**：
- Watchdog 是"事后发现"（每天 09:30 跑，发现昨日问题）
- Pre-flight Gate 是"事前拦截"（生产启动前强制验证）
- 两者互补，**Pre-flight 不可省**——Watchdog 间隔 24h 内如果 cron 突然挂，Pre-flight 是唯一拦截点

---
