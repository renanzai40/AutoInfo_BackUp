# 全量 QA vs 抽样 QA — 2026-05-19 教训记录

## 旧系统的问题

### Vision QA 抽样 3 帧

旧系统只检查 3 帧：
- t=1s（开头）
- t=audio_duration × 0.5（中段）
- t=audio_duration - 5s（末尾前5s）

**65s 视频末尾 20s 无字幕**：这 20s 落在 60s 处，不在 3 个采样点中的任何一个里。抽样法永远发现不了。

### Whisper 30 秒采样

旧系统只转写前 30 秒：
```python
result = model.transcribe(video_path, language='zh')
print(result['text'][:100])  # 只取前 100 字
```

**65s 视频末尾 20s 无音频**：前 30s 全是正常的，只有转写完整音频才能发现末尾断尾。

---

## 新系统全量覆盖

### Vision QA：逐 Entry 中点帧

```python
def full_entry_vision_qa(video_path, srt_path, audio_duration):
    # 1. 解析 SRT，算每个 Entry 的时间中点
    entries = parse_srt(srt_path)
    for idx, start, end, text in entries:
        mid = (start + end) / 2.0
        frame = extract_frame(video_path, mid)
        # 2. Vision 逐帧判断
        result = vision_qa(frame, mid, text)
        if not result["pass"]:
            raise Exception(f"Entry {idx} FAIL: {result['reason']}")

    # 3. 末尾静音段专项检查（如字幕结束后 >3s）
    tail_mid = last_entry_end + (audio_duration - last_entry_end) / 2
    tail_frame = extract_frame(video_path, tail_mid)
    if audio_duration - last_entry_end > 3.0:
        tail_result = vision_qa(tail_frame, tail_mid, "[末尾静音]")
        if not tail_result["pass"]:
            raise Exception(f"末尾静音段 FAIL: {tail_result['reason']}")
```

**9 Entry → 9 帧 + 1 末尾静音帧 = 10 帧全量覆盖**

### Whisper 全音频转写

```python
# 30秒采样（错误）
result = model.transcribe(video_path, language='zh')
print(result['text'][:100])

# 全音频转写（正确）
result = model.transcribe(video_path, language='zh', fp16=False)
print(result['text'][:3000])  # 截断到3000字，够验证全内容
```

---

## 决策依据

Token 成本 vs 重做成本：

| 场景 | 抽样QA成本 | 全量QA成本 | 漏检后果 |
|------|-----------|-----------|---------|
| 65s视频末尾20s断尾 | 3帧Vision | 10帧Vision | 视频白做，重做≈3倍时间 |
| 品牌名在Entry 7（末尾） | 前30s采样 | 全音频转写 | 品牌名错误发布 |

结论：**全量QA的额外token消耗远低于一次重做的成本。Token便宜，重做贵。**

---

## 为什么旧系统用抽样

历史原因：早期视频短（30s以内），3帧覆盖均匀，Whisper 30s够用。

失效条件：
- 视频超过 40s
- 问题出现在末尾
- Entry 数量多（>5个Entry时抽样点稀疏）

---

## 今日教训（2026-05-19）

1. **抽样QA是漏检的根源**：65s视频末尾20s断尾只有在全量转写+逐Entry全覆盖才能发现
2. **Token不是约束**：全量覆盖多花200-500帧Vision，vs 一次重做的时间成本
3. **MD5追踪防止文件替换**：QA了文件A，发了文件B，只有MD5追踪能发现
4. **强制门控防止跳过**：手工gate靠不住，必须pipeline自动化
