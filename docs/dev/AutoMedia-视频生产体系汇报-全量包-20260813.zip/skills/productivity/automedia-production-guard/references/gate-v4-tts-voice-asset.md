# #🆕 Gate V4 完整规范：TTS 声音品牌资产核验（2026-06-05 v10 新增 · P0-12 铁律）

### 🆕 Gate V4 完整规范：TTS 声音品牌资产核验（2026-06-05 v10 新增 · P0-12 铁律）

> **触发原因**：2026-06-05 v8 我擅自把 session 113223 时代的 m3 tts（male-qn-qingse 中文男声）换成 edge-tts zh-CN-XiaoxiaoNeural 女声（"edge-tts 顶一下"），user 反馈"擅自换了音色"严重抗议。**TTS 声音 = 品牌资产，擅自换 = 品牌事故**。

> **触发原因**：2026-06-05 v8 我擅自把 session 113223 时代的 m3 tts（male-qn-qingse 中文男声）换成 edge-tts zh-CN-XiaoxiaoNeural 女声（"edge-tts 顶一下"），user 反馈"擅自换了音色"严重抗议。**TTS 声音 = 品牌资产，擅自换 = 品牌事故**。

**核心铁律**：

> **TTS 引擎/声音/语速/情绪/厂商/性别 6 维 不可擅自互换**。6 维中任何一维变化 = 视频听感/品牌识别度变化。

#### 调用 TTS 前必走 3 问

1. **旧项目/历史用什么 TTS 引擎？**（m3 tts / edge-tts / hermes tts_tool.py / 其他）
2. **旧项目用什么 voice_id？**（m3 tts = `male-qn-qingse` 中文男声 / `Chinese (Mandarin)_Radio_Host` / edge-tts = `zh-CN-XiaoxiaoNeural` / 等）
3. **今天 TTS 工具是否可用？**（CN API key 是否有 / edge-tts 是否安装 / mcp__matrix__tts 工具是否在 session 内）

#### 决策树

```
TTS 工具 + voice 确认
    ↓
[Q1] 旧项目用什么 TTS？→ grep publish_log.json / 查询历史 session
    ↓
[Q2] 工具是否可用？
    ├─ 是 → 必用旧工具 + 旧 voice，禁止换
    └─ 否 → 走 3 选 1：
        ├─ A. **告知 user"工具不可用，建议改方案"**（不要擅自换工具） ← 推荐
        ├─ B. user 提供声音 sample mp3（保持旧声音）
        └─ C. user 明确同意换工具 + 换声音（文字记录到 publish_log.json）
    ↓
[Q3] 实施 TTS 调用（whisper pre-send V5 立即验证 mp3 = SRT 文本）
```

#### 反模式（永久禁止）

- ❌ **"edge-tts 顶一下"** —— 换工具 = 换声音 = 品牌事故
- ❌ **"今天没 m3 tts API key，用 edge 凑合"** —— 应直接告知 user 工具不可用，让 user 拍板
- ❌ **"音色差不多就行"** —— m3 tts male-qn-qingse（清澈青年男声）≠ edge-tts zh-CN-YunxiNeural（磁性男声）≠ edge-tts zh-CN-XiaoxiaoNeural（女声）——3 种声音在 B 站用户耳里区别明显
- ❌ **"我先调一个，user 没反对就当默认"** —— 必须显式确认，user 沉默 ≠ 同意

#### 实施（必跑）

```bash
# 1. 查历史项目用的 TTS 工具 + voice
grep -E "tts|voice|engine" ~/.hermes/profiles/content/cron/jobs.json
grep -E "voice_id|speech-02-hd|male-qn" /home/renanzai/Remotion-Test/public/audio/<历史项目>.mp3.txt 2>/dev/null

# 2. 查 TTS 工具可用性
ls /home/renanzai/.hermes/hermes-agent/venv/bin/edge-tts
test -n "$MINIMAX_CN_API_KEY" && echo "minimax TTS OK"

# 3. 查 mp3 元数据（确认工具用对了）
ffprobe <new_mp3> -show_streams -of json | grep -E "encoder|tag"

# 4. 完整 3 问回答 + user 确认 → 才实施 TTS
```

#### 6-05 v10 实战案例

| 阶段 | TTS 工具 | voice_id | 声音风格 | user 接受? |
|------|---------|----------|---------|-----------|
| session 113223 (6-05 上午) | m3 tts | male-qn-qingse | 中文男声 | ✅ 接受 |
| v8 (6-05 下午) | edge-tts | zh-CN-XiaoxiaoNeural | 中文女声 | ❌ **严重抗议"擅自换了音色"** |
| v9 (6-05 下午) | m3 tts | male-qn-qingse | 中文男声 | ✅ 恢复 |
| v10 (6-06) | m3 tts | male-qn-qingse | 中文男声 | ✅ 接受 |

**核心教训**：session 113223 用的什么 voice，**永远沿用**，除非 user 明确说「换声音」。
