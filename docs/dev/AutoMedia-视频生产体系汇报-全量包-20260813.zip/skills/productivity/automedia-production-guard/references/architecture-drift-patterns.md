# Architecture Drift Patterns in Skill Systems

**Created**: 2026-05-23  
**Lesson source**: Two full workflow reviews (automedia + MTV), found 14 total issues across P0–P3.

---

## The Core Problem

Skills get written. The workflow that should invoke them does not change. Result: the skill exists but is never called.

```
Skill written → documented correctly
                → workflow not updated to call it
                → skill is dead code in the library
```

This happened at least 4 times in the 2026-05-23 review:
- Topic Selection Gate skill existed; automedia pipeline had no call node
- Wechat Upload Checklist existed; timing was documented wrong
- blog-automation had no Gate-status check before migration
- MTV had a subtitle流程 inline instead of referencing subtitle-srt-generation

---

## The Structural Pattern

Two shapes of drift:

### Shape 1: Skill Written After Pipeline (孤岛型)
1. A problem is discovered in production
2. A skill is written to prevent recurrence
3. The skill is written as a standalone document
4. **The pipeline that caused the problem is never updated to call the new skill**
5. The problem recurs because the pipeline is still unchanged

**Prevention**: When writing a new skill, immediately identify the pipeline step that should invoke it, and update that pipeline step in the same session.

### Shape 2: Parallel Implementation (平行实现型)
1. Two skills solve overlapping problems with different logic
2. Neither skill references the other
3. Over time they diverge (like MTV vs subtitle-srt-generation subtitle文本sources)
4. Neither is wrong individually, but the system appears contradictory

**Prevention**: When a new skill overlaps with an existing one, write a "relationship note" in both skills explicitly stating which scenario uses which approach.

---

## Systematic Review Triggers

Run this check after any of:

1. **Writing a new skill** → ask: "which pipeline step calls this? is that step documented?"
2. **Reviewing a workflow** → ask: "which skills does this workflow reference? are there skills with similar scope that aren't mentioned?"
3. **User reports a recurring problem** → ask: "was there a skill written for this? why isn't it being called?"
4. **Two skills have overlapping descriptions** → ask: "are they intentionally different, or did they drift apart?"

---

## Signals That Indicate Drift Is Happening

- A skill has rich content but appears nowhere in the workflow that should invoke it
- A guard/checklist/exclusion list exists but problems it should catch keep recurring
- Two skills give different rules for the same artifact (SRT文本, brand CTA, etc.)
- A script exists in `scripts/` but the SKILL.md never mentions it
- A skill references another skill by name but the referenced skill has no knowledge of this

---

## The Audit Script Pattern

When reviewing skills for drift, the most efficient scan:

```bash
# Find skills with scripts/ that the SKILL.md doesn't reference
for skill in ~/.hermes/skills/productivity/*/; do
  skill_name=$(basename $skill)
  script_count=$(ls $skill/scripts/*.py 2>/dev/null | wc -l)
  mentions_scripts=$(grep -c "scripts/" $skill/SKILL.md 2>/dev/null || echo 0)
  if [ $script_count -gt 0 ] && [ $mentions_scripts -eq 0 ]; then
    echo "ORPHAN SCRIPTS: $skill_name ($script_count scripts, SKILL.md mentions 0)"
  fi
done
```

```bash
# Find skills with "Gate" or "check" in the name whose SKILL.md doesn't reference any other skill
for skill in ~/.hermes/skills/productivity/*/; do
  name=$(basename $skill)
  if echo "$name" | grep -qi "gate\|check\|guard\|review"; then
    ref_count=$(grep -c "skill_view\|load.*skill\|加载.*skill" $skill/SKILL.md 2>/dev/null || echo 0)
    if [ $ref_count -eq 0 ]; then
      echo "ISOLATED GUARD: $name — no other skill referenced"
    fi
  fi
done
```

---

## Recovery Protocol

When drift is found:

1. **Identify the caller**: which workflow step should invoke this skill?
2. **Verify actual invocation**: grep the workflow's SKILL.md for the skill name
3. **Add call node**: update the pipeline's SKILL.md with explicit invocation step
4. **Test with real case**: confirm the skill's guard fires in a real production run
