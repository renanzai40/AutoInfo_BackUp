# 并行双 Track 生产原则（2026-05-19 固化）

## 并行双 Track 生产原则（2026-05-19 固化）

> **文案 Track 和视频 Track 是两条独立流水线，各自在自己的阶段完成审查，互不等待。**
> 文案 Track 审查失败 → 不影响视频 Track 继续生产，但文案 Track 必须修复后才能发布。
> 视频 Track 审查失败 → 不影响文案 Track 继续生产，但视频 Track 必须修复后才能发送用户。

```
话题确认
    ↓
  Gate R0: Research ← 强制，加载 automedia-research
  读 source_url → 产出 00_research/{sources.json,research_notes.md}
    ↓
  Gate PT: Template Selection ← 按话题类型加载 content-prompt-templates
  业务款/引流款/热点/争议 → 差异化结构
    ↓
    ┌──────────────────────────────────────────┐
    │  文案 Track（独立进行）                     │
    │  [写草稿前加载 platform-differentiation]   │
    │  subagent 或主agent生成                    │
    │  5平台草稿（含差异化）                     │
    │    ↓                                       │
    │  fact-check Gate (C0) ← 强制              │
    │    ↓                                       │
    │  humanizer Gate (C1) ← 强制                │
    │    ↓                                       │
    │  copy-review Gate (C2) ← 强制              │
    │    ↓                                       │
    │  brand-cta-review Gate (C3) ← 强制          │
    │    ↓                                       │
    │  wechat-upload-checklist ← 强制             │
    │  （标题≤9字/digest≤20字）                  │
    │ 草稿生成前就触发，不是之后                  │
    │    ↓                                       │\n    │  Gate II: Inline Image ← 强制              │\n    │  公众号≥3图 / 知乎≥2图 / 小红书≥1图       │\n    │    ↓                                       │\n    │  🆕 Gate B0: Blog Auto-Publish ← 自动     │\n    │  符合条件 → MDX → 官网博客目录              │\n    │  不符合 → 跳过，不阻塞                      │\n    │    ↓                                       │\n    │  文案 Track 锁定 → 不得修改                │
    └──────────────────────────────────────────┘
    ┌───────────────────────────────────────────────┐
    │  视频 Track（独立进行）                          │
    │  Step 1: 选主题（theme-palettes.json 36主题）   │
    │  Step 2: 定布局（visual-layouts.md 6种类型）    │
    │    → 5段 ≥ 4种不同布局，相邻不得重复            │
    │  Step 3: 写 composition（手动/每个场景独立设计）  │
    │    ↓                                             │
    │  Gate VQ: Design Quality ← 强制                 │
    │  布局多样性≥4种/主题变量≥6个/动画≥2种easing     │
    │    ↓                                             │
    │  TTS → Whisper → SRT → lint → render             │
    │  [生图时参考 cover-prompt-library]               │
    │    ↓                                             │
    │  🔥 字幕烧录（强制：scripts/burn_subtitles.py）   │
    │  → 使用 drawtext 滤镜 + WenQuanYi 中文字体        │
    │  → 禁止使用 ffmpeg subtitles 滤镜（libass 依赖）  │
    │  → 烧录前检查 wqy-zenhei.ttc 字体存在             │
    │  → 烧录后抽帧验证字幕区域有可见文字
  │  → 必须从 video_clean.mp4（无字幕原片）取源，禁止用已烧录过的 video_final.mp4
  │  → 脚本已内置长句自动换行（35字阈值，句号/问号/逗号处拆行）
  │  → drawtext 内用真实换行符（ASCII 10），不做 \\n 转义（filter 解析器不处理 \\n）
  │  → 烧录后 cp 为 video_final.mp4，同时保留 video_clean.mp4 供后续重烧
    │  全量 Vision QA ← 强制                          │
    │  全量 Whisper 验证 ← 强制                       │
    │    ↓                                             │
    │  视频 Track 锁定 → 不得修改                     │
    └───────────────────────────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  🆕 后生产发布（出口 Gate · 2026-06-24 新增）
  python3 pipeline_post_production.py <project_dir>
  ├── WeChat 草稿上传（阻塞级别：执行+记录，不 exit 1）
  ├── 博客 MDX 生成（非阻塞：仅业务款+有内容）
  ├── 更新 publish_log + project_info.status
  └── exit 0 放行（失败有记录，不阻塞管线）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---
