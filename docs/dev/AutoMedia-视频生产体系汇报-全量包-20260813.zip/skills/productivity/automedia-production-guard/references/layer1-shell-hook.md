# #Layer 1: Shell Hook 配置

### Layer 1: Shell Hook 配置

```yaml
# config.yaml
hooks_auto_accept: true
hooks:
  pre_tool_call:
    - command: ~/.hermes/gate/pre_render_hook.sh
      matcher: "terminal"
      timeout: 30
```

**脚本协议**：
- **stdin**（JSON）：`{"hook_event_name": "pre_tool_call", "tool_name": "terminal", "tool_input": {"command": "..."}}`
- **stdout**（JSON，阻止时返回）：`{"action": "block", "message": "blocked: pre-render gates not passed"}`
- **stdout**（空或非匹配 JSON）= 通过

**hook 脚本检查项**（`pre_render_hook.sh` 示例）：
```bash
# 从 stdin 读命令
CMD=$(echo "$JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['tool_input']['command'])")
# 如果是 render 命令
if echo "$CMD" | grep -q "hyperframes render"; then
  # 检查 VQ 文件
  if [ ! -f "video/VQ/validate_layout.txt" ]; then
    echo '{"action":"block","message":"❌ 缺少 VQ 文件，render 被阻止"}'
    exit 0
  fi
  # 检查 V5 匹配报告
  if [ ! -f "video/V5/mp3_vs_srt_match.json" ]; then
    echo '{"action":"block","message":"❌ 缺少 V5 匹配报告，render 被阻止"}'
    exit 0
  fi
fi
# 通过 → 不输出 block 指令
```

**shell hook 的局限**（诚实地告诉你）：
- hook 脚本放在 `~/.hermes/profiles/content/` 下，我能修改
- 要真物理加固需要放另一个 profile（`~/.hermes/profiles/gate/`），3 profile 不够用时不强求
- 即使能改，改 hook 的行为在飞书可见——friction 有效
