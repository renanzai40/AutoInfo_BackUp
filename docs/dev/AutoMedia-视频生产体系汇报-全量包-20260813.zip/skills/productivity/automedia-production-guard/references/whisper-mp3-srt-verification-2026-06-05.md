# Whisper pre-send 验证：mp3 vs SRT 文本核验

> **触发场景**：每次新生成 mp3 后、复用旧 mp3 + 新 SRT 时、TTS 引擎/voice 变化时——**必须**用 Whisper 转写 mp3 实际内容 + diff SRT 文本，确认 100% 匹配再发飞书。
>
> **6-05 终极 root cause 案例**：session 113223 时代 mp3 朗读 "GPT5 工具红利期"（6-02/6-03 m3 tts 旧产物），SRT 文本 "Alphabet 800亿"（session 113223 新写）——**两套完全错配**，user 反馈"音画同步还是不符合铁律"+"字幕和 tts 语音对不上"。

## 完整工作流（5 步）

### Step 1: Whisper 转写 mp3 实际内容

```bash
whisper <mp3_path> --language zh --model tiny \
    --output_format srt --output_dir /tmp/whisper_pre_send/
# 输出：/tmp/whisper_pre_send/<mp3_name>.srt
```

> **tiny 模型 30s 内出结果**（CPU 即可）。大项目用 small 慢但更准。
> **whisper 路径**：`/home/renanzai/.hermes/hermes-agent/venv/bin/whisper`（hermes-agent venv 已装 openai-whisper + faster-whisper）。

### Step 2: 提取关键词（忽略时间戳，只比文本）

```python
import re

srt = open('/path/to/subtitle.srt').read()
whisper = open('/tmp/whisper_pre_send/<mp3_name>.srt').read()

# 提取 ≥2 字中文词（忽略时间戳+英文+标点）
srt_texts = set(re.findall(r'[\u4e00-\u9fff]{2,}', srt))
whisper_texts = set(re.findall(r'[\u4e00-\u9fff]{2,}', whisper))
```

### Step 3: 关键词覆盖率比对

```python
common = srt_texts & whisper_texts
coverage = len(common) / len(srt_texts) * 100 if srt_texts else 0
print(f"SRT 关键词: {len(srt_texts)} | Whisper: {len(whisper_texts)} | 共同: {len(common)} | 覆盖率: {coverage:.1f}%")
```

**阈值规则**：
- `coverage ≥ 80%` → ✅ V5 PASS
- `coverage 60-80%` → ⚠️ WARN（Whisper 误识别容忍）
- `coverage < 60%` → ❌ V5 BLOCK（mp3 与 SRT 完全错配）

### Step 4: 失败处理

```python
if coverage < 80:
    missing = list(srt_texts - whisper_texts)[:10]
    raise Exception(
        f"❌ V5 mp3 vs SRT 文本错配：覆盖率 {coverage:.1f}% < 80%\n"
        f"   缺失关键词: {missing}\n"
        f"   → mp3 朗读的不是 SRT 文本，必须重新生成 mp3"
    )
```

### Step 5: 验证 Whisper 听到的 SRT 关键内容

**Whisper 转写经常有 ASR 误识别**（"800亿" → "810美元"、"拟融资" → "泥融资"），但**核心内容（公司名/产品名/动作）应该对**：

| SRT 关键内容 | Whisper 转写应该听到 | 容差 |
|--------------|-------------------|------|
| 公司名（Alphabet/Anthropic/OpenAI）| 同名 | 必须 100% 匹配 |
| 产品名（Codex/插件/库）| 同名或近音 | 必须 100% 匹配 |
| 数字（800亿/4倍）| 同数字或近音 | 容忍 Whisper 误识别 |
| 品牌名（壹目贯维）| 同名（防"一目惯为"误识别） | 必须 100% 匹配 |
| 动词（"拟融资"/"提交 IPO"/"推出"）| 同动词 | 必须 100% 匹配 |

## 6-05 v10 实战案例

### Case 1: alphabet 视频（修复后）

| SRT 关键内容 | Whisper 实际听到 | 状态 |
|--------------|----------------|------|
| "AI 行业八月的头条" | "AI 行业 8 月的头条" | ✅ 匹配 |
| "Alphabet 拟融资 800 亿美元" | "Alphabet 拟融资 810 美元" | ⚠️ 数字误识别（810 vs 800）但核心内容对 |
| "Anthropic 同步提交 IPO 申请" | "Anthropic 同步提交 IPO 申请" | ✅ 完全匹配 |
| "两笔交易合计规模超过千亿" | "两笔交易合计规模超过千亿" | ✅ 完全匹配 |
| "军备竞赛阶段" | "军备竞赛阶段" | ✅ 完全匹配 |
| "关注壹目贯维" | "关注一目冠维" | ⚠️ 误识别（冠 vs 贯）但核心词对 |

**V5 覆盖率 95%+ → PASS**（容忍 ASR 误识别）

### Case 2: openai 视频（修复后）

| SRT 关键内容 | Whisper 实际听到 | 状态 |
|--------------|----------------|------|
| "OpenAI 又放大招" | "OpenAI 又放大招" | ✅ 完全匹配 |
| "Codex 推出团队专属插件" | "Codex 推出团队专属插件" | ✅ 完全匹配 |
| "编程场景的团队协作正式登陆" | "编程场景的团队协作正式登陆" | ✅ 完全匹配 |
| "现在团队能用同一套配置" | "现在团队能用同一套配置" | ✅ 完全匹配 |
| "关注壹目贯维" | "关注一幕关为" | ⚠️ 严重误识别但核心词对 |

**V5 覆盖率 95%+ → PASS**

## 反模式（永久禁止）

- ❌ **"我用 SRT 文本作为 TTS 输入，mp3 朗读必然 = SRT"**——6-05 案例 mp3 是旧版 m3 tts，**TTS 输入不是今天的 SRT**
- ❌ **"Whisper 听到的跟 SRT 差不多就行"**——V5 阈值 80%，< 80% = mp3 跟 SRT 是两套
- ❌ **只校验时间戳偏差（sync_check）**——sync_check 只查"字幕时机对不对"，**不查"字幕内容对不对"**
- ❌ **"v3-v7 跑过 vision QA 了，没问题"**——vision QA 5 帧全在 S1 段 = 误判"对得上"（采样偏差陷阱）

## 6-05 终极 root cause 还原

| 阶段 | mp3 来源 | SRT 来源 | 视频状态 | user 反馈 |
|------|---------|---------|---------|----------|
| **session 113223 (6-05 上午)** | m3 tts 旧版（"GPT5 工具红利期"） | session 113223 新写（"Alphabet 800亿"） | **两套错配** | "音画同步不符合铁律" |
| **v3-v4 (我手写)** | 同 session 113223 旧 mp3 | 改 SRT 文本对齐 mp3 | 字幕改短/新增 | "字幕和 TTS 对不上" |
| **v8 (edge-tts)** | edge-tts 重生成（xiaoxiaoNeural 女声）| 仍是 session 113223 SRT | 文本对但擅自换声音 | "擅自换了音色" |
| **v10 (m3 tts + Whisper 校准)** | m3 tts 重生成（male-qn-qingse 男声）| Whisper 校准真实句尾 | **3 套全对齐** | ✅ 接受 |

**关键**：v10 真正修复 = **3 套全对齐**（mp3 朗读 = SRT 文本 = Composition 字幕）+ TTS 声音 = 旧项目声音 + 音画同步 = Whisper 真实句尾校准。

## 触发条件速查

| 触发场景 | 必跑 V5? | 备注 |
|---------|---------|------|
| 新生成 mp3 后 | ✅ 必跑 | 标准流程 |
| **复用旧 mp3 + 新 SRT** | ✅ **必跑**（最危险，session 113223 案例）| 6-05 终极 root cause |
| TTS 引擎变化 | ✅ 必跑 | m3 → edge / hermes tts_tool |
| TTS voice_id 变化 | ✅ 必跑 | male → female |
| SRT 文本修改 | ✅ 必跑 | mp3 可能读旧文本 |
| Composition 重渲染但 mp3 不变 | ❌ 可不跑 | mp3 没变 |

## 工具链

- **Whisper CLI**：`/home/renanzai/.hermes/hermes-agent/venv/bin/whisper <mp3>`
- **MiniMax CN TTS API**：`https://api.minimaxi.com/v1/t2a_v2` + `MINIMAX_CN_API_KEY`（在 .env）
- **Whisper 路径**：`/home/renanzai/.hermes/hermes-agent/venv/bin/whisper`（hermes-agent venv 已装）
- **mp3 实际时长**：`/home/renanzai/bin/ffprobe -v error -show_entries format=duration -of json <mp3>`
- **mp3 静音点**：`/home/renanzai/bin/ffmpeg -i <mp3> -af "silencedetect=noise=-30dB:d=0.3" -f null - 2>&1 | grep "silence_end"`

## 相关 skills / references

- `subtitle-srt-generation` skill P0-1 铁律（Whisper mandatory）+ P0-2 铁律（word_timestamps canonical）
- `subtitle-srt-generation` skill Gotcha #12（mp3 vs SRT 内容错配案例）
- `remotion-workflow` skill P0-12 铁律（TTS 声音是品牌资产不可擅自换）
- `remotion-workflow` skill P0-13 铁律（Whisper pre-send 必验证）
- `automedia-production-guard` skill Gate V4 (TTS 声音品牌资产核验) + Gate V5 (mp3 vs SRT 文本核验)
