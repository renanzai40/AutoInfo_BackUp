# MTV 独立创作项目（MiniMax 视频+音乐全家桶）

## MTV 独立创作项目（MiniMax 视频+音乐全家桶）

项目目录：`/mnt/d/Hermes-Workspace/01-Projects/MTV/`

用户配额（2026-05-20 实测）：
- `MiniMax-Hailuo-2.3-6s-768p`：每日 2 次
- `MiniMax-Hailuo-2.3-Fast-6s-768p`：每日 2 次
- `music-2.6`（原创歌曲）：100首/天
- `music-cover`（翻唱）：100首/天

**流水线**：I2V×2（6s+6s 开头）→ T2V×2（6s+6s 承接）→ music-cover 翻唱 → FFmpeg 合并 → 24s 成品

### MTV 专项 QA 标准（2026-05-23 新增）

MTV 项目必须遵守以下标准，否则视为工艺失误：

#### 1. 字幕双层架构标准
MTV 使用**双层字幕**，与 AutoMedia 商业视频的单层字幕不同：

| 层级 | 内容 | 颜色 | 位置 | FontSize |
|------|------|------|------|---------|
| Layer 1 大标题 | 视频主题词 | 黄色 + 黑边 | 上1/3处 | 72pt |
| Layer 2 口播字幕 | 说话台词 | 白色 + 黑边 | 底部 H/6 | 40pt |

**禁止**：单层字幕 / 白色大标题 / 大标题不全程显示

#### 2. Fallback 图备份强制（2026-05-23 新增）
每次重新烧录字幕前，**必须**备份现有 frames：
```bash
# 错误：直接覆盖，没有备份
cp frames/frame_*.jpg /tmp/backup/  # 没有日期戳，重复备份会覆盖

# 正确：带日期戳备份
BACKUP_DIR="frames_backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
cp frames/frame_*.jpg "$BACKUP_DIR/"
echo "备份于: $BACKUP_DIR"
```
**没有备份就重新烧录 = 工艺失误**。如果 frames 被污染后无法恢复，立即回退到上一次备份。

#### 3. MTV 歌词结构标签自动化检查（2026-05-23 新增）
MTV 歌词写完后，必须执行自动化检查（见 `minimax-music-guide/scripts/validate_lyrics.py`）：
```python
import sys
sys.path.insert(0, '/home/renanzai/.hermes/skills/minimax-music-guide/scripts')
from validate_lyrics import validate_lyrics

result = validate_lyrics('music/lyrics.txt')
if not result['passed']:
    raise Exception(f"MTV歌词检查失败: {result['errors']}")
```

#### 4. MTV 项目禁止事项
- ❌ 不加载 `minimax-music-guide` skill 就开始 MTV 项目
- ❌ Fallback 图重新烧录前不备份 frames
- ❌ 不检查 `--bpm` / `--key` / `--vocals` 参数就生成音乐
- ❌ 迭代时用新版视频轨道覆盖已知良品（应回退到已知良品，只替换音频/字幕）

详见：`references/mtv-project-2026-05-20.md`

### 已确认 Bug：推荐列表包含已选话题（2026-05-24）

**症状**：生成 TOP3 推荐时，把 `status='selected'` 的话题也推荐给了用户，导致误选。

**根因**：生成推荐时没有在 SQL 查询里加 `status='pending'` 过滤。

**正确做法**：任何查询候选话题的场景（生成推荐列表、打分排序、选话题）必须加 `WHERE status='pending' AND review_status='approved'`：

```sql
-- ✅ 正确（双过滤）
SELECT topic_id, title, category, heat_score, correlation_score, freshness_score
FROM topics
WHERE status='pending' AND review_status='approved' AND category='business'
ORDER BY heat_score DESC

-- ❌ 错误（缺少任一过滤都会出问题）
SELECT topic_id, title, category, ...
FROM topics WHERE category='business'  -- ❌ 会含 selected
```

### 已确认 Bug：business 款 approved 目录名不一致（2026-05-24）

**症状**：subagent 完成时，引流款创建了 `06_approved/`，但业务款创建了 `approved/`（无数字前缀）。

**正确目录名（统一）**：所有话题类型统一用 `06_approved/`（不带数字前缀）。

### 已确认问题：抖音脚本文件名后缀（2026-05-24）

**症状**：subagent 写抖音口播脚本到 `v5_ali_douyin_approved.md`（`.md` 后缀），但标准应该是 `.txt`。

**正确文件名**：`script.txt`（不是 `.md`）。

### 已确认问题：subagent 生成的 Bridge+CTA 链路断裂（2026-05-24）

**症状**：subagent 生成文案通过了 humanizer/copy-review/brand-cta-review 三阶 Gate，但：
- 正文结尾 → 直接跳 CTA，中间没有过渡句（bridge 缺失）
- CTA 说"批量生产全包服务"而非"壹目贯维是AI内容生产公司"（品牌身份说虚了）
- 过渡方向与品牌业务不一致

**实测案例**：
- 引流款（阿里财报）：正文结尾"你跟还是不跟？" → 直接跳"壹目贯维均提供批量生产全包服务"
- 业务款（10款AI视频）：正文结尾"保存！备用！" → 直接跳"壹目贯维均提供全流程服务"

**正确 Bridge 结构**（必须同时满足）：
1. **过渡句**：承接正文结尾的话题词，引到"内容生产/多平台发布"方向
2. **品牌身份**：明确说"壹目贯维——AI内容生产公司"
3. **价值主张**：具体功能（热点追踪/文案生成/多平台发布）
4. **行动引导**：明确（"关注后丝我" / "扫码" / "评论区打出来"）

**2026-05-24 教训**：即使三阶 Gate 全过，main agent 仍需人工复查 Bridge+CTA 的质量——零容忍项里没有"Bridge 是否存在"这一条，skill 再完善也覆盖不了所有边界情况。
