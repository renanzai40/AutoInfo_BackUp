# Image Generation via ComfyUI (2026-06-25 固化)

## 当前后端
- **ComfyUI** 本地运行（GTX 1660 Ti 6GB, SD 1.5）
- **端口**：127.0.0.1:8188
- **旧方案已停用**：MiniMax image-01

## 批量生图脚本
`scripts/gen_ui_images.py`（位于 content profile scripts 目录）

### 自动生成
| 类型 | 数量 | 路径 |
|------|------|------|
| 内文配图 | 3 张 | `01_content/drafts/wechat/images/wechat_img_1/2/3.png` |
| 封面 16:9 | 1 张 | `02_images/cover/cover_16x9.png` |
| 封面 9:16 | 1 张 | `02_images/cover/cover_9x16.png` |
| 封面 3:4 | 1 张 | `02_images/cover/cover_3x4.png` |

### 用法
```bash
python3 scripts/gen_ui_images.py <project_dir>
```

脚本自动从 `00_research/research_notes.md` 和 `03_video/script.txt` 提取主题上下文，用于 prompt 生成。

## 已知问题
- `run_workflow.py`（ComfyUI skill 脚本）对标准 SD 1.5 txt2img 工作流返回 500 错误
- **修复**：`gen_ui_images.py` 使用直接 REST API（`POST /prompt` → `GET /history/{id}`）绕过此问题
- 如果 gen_ui_images.py 失败：手动用 `curl -X POST http://127.0.0.1:8188/prompt` 提交工作流

## II Gate（内文配图）
生成后审计检查：
```bash
ls project/01_content/drafts/wechat/images/ | wc -l  # 应 ≥ 3
ls project/02_images/cover/ | wc -l                    # 应 ≥ 3
```
