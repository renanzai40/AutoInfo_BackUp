# copy_review_gate.py Usage Reference — 2026-05-22

## 快速调用

```python
import sys
sys.path.insert(0, '/home/renanzai/.hermes/skills/productivity/automedia-production-guard/scripts')
from copy_review_gate import enforce_copy_review_gates, mark_gate_completed

# 强制门控检查（Gate失败 → Exception → Pipeline STOP）
enforce_copy_review_gates(project_dir="/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/<项目>/")

# 手动标记某Gate完成（在subagent中review跑完后调用）
mark_gate_completed(project_dir, "humanizer_passed")
mark_gate_completed(project_dir, "copy_review_passed")
mark_gate_completed(project_dir, "brand_cta_passed")
```

## enforce_copy_review_gates 行为

| 情况 | 返回/抛出 |
|------|---------|
| 三个Gate全部通过 | `{"passed": True, "gates": {"G1_humanizer": True, "G2_copy_review": True, "G3_brand_cta": True}}` |
| 任一Gate失败 | `Exception("[COPY REVIEW GATE FAILED — Pipeline STOP]...")` |

## G2 Copy-Review 文件检测逻辑（v1.2）

检测 `{project}/04_review/` 目录，支持以下命名格式：

| 格式 | 示例 | 状态 |
|------|------|------|
| `copy_review_{platform}.md` | `copy_review_wechat.md` | ✅ 标准 |
| `copy_review_{platform}_report.md` | `copy_review_wechat_report.md` | ✅ 兼容 |
| `{platform}_review_report.md` | `wechat_review_report.md` | ✅ 兼容 |
| `{platform}_review.md` | `wechat_review.md` | ✅ 兼容 |
| `??_{platform}_review.md` | `01_wechat_review.md` | ✅ 兼容（编号） |

**平台列表**：`wechat`, `zhihu`, `xiaohongshu`（bilibili/tiktok 视频脚本不在G2检查范围内）

**检测条件**：文件存在 + 大于100字节

## G3 Brand CTA 检测逻辑（v1.2）

三条件同时满足才算通过：
1. 文件含"壹目贯维"
2. 文件含 CTA 相关关键词之一：`零容忍` / `品牌身份` / `品牌CTA` / `CTA检查` / `Brand CTA`
3. 文件含通过标记之一：`✅` / `通过` / `PASS` / `可发布`

独立 `brand_cta_review.md` 文件：含 `✅` 或 `PASS` 即通过。

## 2026-05-22 发现的问题（已修复）

**Bug 1 — G2 failure logic 误报**：
- 原代码：`if not g2_passed and not missing:` — 当 `missing=[]` 时条件为 False，failure不加入列表，但 `gates_status["G2_copy_review"] = False` 未改
- 导致：无missing时仍然报G2失败
- 修复：`if not g2_passed:` 独立，failure 始终加入

**Bug 2 — bilibili/tiktok 被检测为文章平台**：
- `_detect_generated_platforms` 返回 bilibili/tiktok（视频脚本目录）
- 但 review 只做公众号/知乎/小红书，video script 不在 review 范围
- 导致：G2 对有 bilibili/tiktok 但无对应 review 的项目误报 missing
- 修复：platform 列表只保留 `["wechat", "zhihu", "xiaohongshu"]`

**Bug 3 — xiaohongshu glob 语法错误**：
- `content_dir.rglob("xiaohongshu*.md") or content_dir.rglob("*xiaohongshu*.md")`
- Python `or` 用于 generators 无短路，求值顺序错
- 修复：`list(...) + list(...)`

**Bug 4 — subagent 写到错误目录**：
- subagent 默认写到 `/home/renanzai/reports/`，不在项目 `04_review/`
- 导致：文件存在但 gate 检测找不到，误判失败
- 修复：delegation prompt 必须明确告知输出路径 + script 检查项目 `04_review/` 目录

## subagent delegation 输出路径规范

**必须包含**：
```
输出路径格式：/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/{项目名}/04_review/copy_review_{platform}.md
```

**禁止使用**：
- ❌ `/home/renanzai/reports/`
- ❌ `~/reports/`
- ❌ 任何非 `{project_dir}/04_review/` 的路径

**验证方法**：review 跑完后，主 agent 调用 `enforce_copy_review_gates()`，文件不在 `04_review/` → Exception → 修复后才能继续。
