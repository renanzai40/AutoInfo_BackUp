# Gate E：项目完整性强制检查（交付前 Hard Gate）

## Gate E：项目完整性强制检查（交付前 Hard Gate）

> **2026-05-26 教训固化**：Wentech/litigation 项目在 WeChat draft 上传后被标记为"done"，但实际缺失：B站 copy-review 报告、知乎品牌 CTA（全文无"壹目贯维"）、frame_002 帧图、所有封面图。QA Gates 过了 ≠ 资产完整。
>
> **触发时机**：项目声称"完成"之前（无论 WeChat draft 是否已上传）。每次说"这个项目完成了"之前必须执行。

### 完整性检查（4 项，全部通过才允许标记"done"）

**检查 A：帧图完整性**

```python
import os, re

assets_dir = f"{project_dir}/02_images/assets"
if os.path.isdir(assets_dir):
    frames = sorted([f for f in os.listdir(assets_dir) if f.startswith('frame_') and f.endswith('.jpg')])
    # 从脚本/SRT推断应有帧数（如9个场景=9帧）
    expected_count = 9  # 或从项目记录读取
    if len(frames) < expected_count:
        missing = [f"frame_{i:03d}.jpg" for i in range(1, expected_count+1) if f"frame_{i:03d}.jpg" not in frames]
        raise Exception(f"帧图缺失: {missing}")
else:
    raise Exception("assets/ 目录不存在")
```

**检查 B：封面图完整性**

```python
cover_dir = f"{project_dir}/02_images/cover"
required_covers = {'cover_16x9.jpg', 'cover_1x1.jpg', 'cover_3x4.jpg', 'cover_9x16.jpg'}
existing = set(os.listdir(cover_dir)) if os.path.isdir(cover_dir) else set()
missing = required_covers - existing
if missing:
    raise Exception(f"封面图缺失: {missing}")
```

**检查 C：Copy-review 全平台覆盖**

```python
review_dir = f"{project_dir}/04_review"
platforms = {'wechat', 'zhihu', 'xiaohongshu', 'tiktok', 'bilibili'}
found = set()
for f in os.listdir(review_dir):
    for p in platforms:
        if p in f.lower() and 'copy_review' in f.lower():
            found.add(p)
missing = platforms - found
if missing:
    raise Exception(f"Copy-review 缺失: {missing}（必须在 04_review/ 目录）")
```

**检查 D：品牌 CTA 全平台存在性**

```python
# 知乎：全文必须含"壹目贯维"
zhihu_file = f"{project_dir}/01_content/drafts/zhihu/zhihu_article.md"
with open(zhihu_file) as f:
    content = f.read()
if '壹目贯维' not in content:
    raise Exception(f"知乎文章品牌CTA缺失: {zhihu_file}")

# 小红书：正文末尾必须有 #壹目贯维 标签
xhs_file = f"{project_dir}/01_content/drafts/xiaohongshu/xiaohongshu_post.md"
with open(xhs_file) as f:
    content = f.read()
if '#壹目贯维' not in content:
    raise Exception(f"小红书品牌标签缺失: {xhs_file}")
```

**4 项全部通过 → 允许标记"done"。任意一项失败 → Pipeline STOP，禁止声明完成。**

|> ⚠️ **WeChat draft 上传 ≠ 项目完成**：草稿上传后仍需完成剩余资产（其他平台文案、帧图、封面）。草稿上传只是文案 Track 完成，不是项目完成。
