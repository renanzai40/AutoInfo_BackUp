# MD5 追踪机制

## MD5 追踪机制

每个Gate完成后记录产物MD5到 `{project_dir}/pipeline_md5.json`。Pre-send Gate核验：发出文件的MD5必须与QA时记录的MD5一致，否则Pipeline STOP。

**防止「QA的是一个文件，发送的是另一个文件」**。
