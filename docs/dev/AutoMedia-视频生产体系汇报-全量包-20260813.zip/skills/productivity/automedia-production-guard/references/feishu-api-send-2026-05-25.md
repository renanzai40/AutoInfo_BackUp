# Feishu API 发送方案（2026-05-25 验证）

## 场景
cron 独立脚本发送飞书消息，不走 Hermes gateway（gateway 在 cron 环境下难以加载）。

## 正确方案：直接 REST API

```python
import json, os, requests

APP_ID = os.environ['FEISHU_APP_ID']
APP_SECRET = os.environ['FEISHU_APP_SECRET']

def get_token():
    resp = requests.post(
        "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        json={"app_id": APP_ID, "app_secret": APP_SECRET}, timeout=10
    )
    return resp.json()['tenant_access_token']

def send_message(token, chat_id, text):
    url = "https://open.feishu.cn/open-apis/im/v1/messages"
    params = {"receive_id_type": "chat_id"}
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    payload = {
        "receive_id": chat_id,
        "msg_type": "text",
        "content": json.dumps({"text": text})   # ← 必须是 JSON 字符串，不是 '{%s}' % repr(msg)
    }
    resp = requests.post(url, params=params, headers=headers, json=payload, timeout=30)
    result = resp.json()
    if result.get('code') != 0:
        raise Exception(f"Feishu API error {result}")
    return result
```

## 常见错误

| 错误码 | 原因 | 正确写法 |
|--------|------|---------|
| 230001 | `content` 不是 JSON 字符串 | `json.dumps({"text": msg})`，**不是** `'{"text": %s}' % repr(msg)` |

## 已确认 ID（2026-05-25）

| 名称 | ID |
|------|-----|
| renan 私聊 | `oc_fb8771a1fb9b0214b99d7c28c03dbe7f` |
| 贯维内容生产群 | `oc_fbc1c0b8faf60cf622b75904fd1f75cd` |

## 环境变量加载
飞书凭证存在 `~/.hermes/.env`，加载方式：
```python
hermes_env = os.path.expanduser('~/.hermes/.env')
with open(hermes_env) as f:
    for line in f:
        line = line.strip()
        if '=' in line and not line.startswith('#'):
            k, v = line.split('=', 1)
            os.environ[k] = v
```