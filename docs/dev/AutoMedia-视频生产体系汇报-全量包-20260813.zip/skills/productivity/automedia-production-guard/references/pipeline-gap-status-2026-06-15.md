# 🔧 Content Quality Warning: Pipeline Gap Status（2026-06-15 审计发现 · 2026-06-15 修复更新）

## 🔧 Content Quality Warning: Pipeline Gap Status（2026-06-15 审计发现 · 2026-06-15 修复更新）

> **本小节记录内容生产管线中已验证存在的系统性缺口及修复状态。** 各缺口标注当前状态（✅已修复/⚠️部分缓解/❌未解决），以及对应修复所在的 skill 或 Gate。

### 缺口清单（按修复状态排序）

| # | 缺口 | 影响 | 修复 Skill / Gate | 状态 |
|---|------|------|-------------------|:----:|
| **GAP-R2** | **事实核查完全缺失**——Scripts 内数字/日期/引用未经任何验证 | 品牌风险：发布不准确数据损害可信度 | `automedia-fact-check` + **Gate C0**（脚本后·Humanizer前强制跑5步核查，输出 `04_review/fact_check_report.md`） | ✅ **已修复** |
| **GAP-R1** | **素材研究环节缺失**——`source_url` 从未在生产链路中被读取，脚本只依赖标题+LLM内部知识 | 内容深度浅、数据可能不准确 | `automedia-research` + **Gate R0**（话题确认后强制加载：读原文 → 提取数字/引文/实体 → 产出 `00_research/{sources.json,research_notes.md}`） | ✅ **已修复** |
| **GAP-R3** | **无分类型 Prompt 模板**——业务款/引流款/热点/争议共用同一套临场生成逻辑 | 内容质量不稳定，高价值选题与低价值话题同级别 prompt | `content-prompt-templates` + **Gate PT**（脚本前强制按话题类型选差异化结构） | ✅ **已修复** |
| **GAP-R4** | **5 平台文案无差异化**——抖音=B站完全相同，知乎≈公众号 | 平台适配性差 | `platform-differentiation` + **Gate PD**（写草稿前加载，platform-specific 字数/语气/结构/图片规格） | ✅ **已修复** |
| **GAP-R6** | **封面/配图 prompt 无模板**——每次从头写，无分类模板 | 重复劳动、视觉风格不统一 | `cover-prompt-library`（Type×Style×Palette 参考库，8个参考案例 + 参数速查） | ✅ **已修复** |
| **GAP-R5** | **内文配图完全缺失**——审计 3 项目，`02_images/assets/` 全部为空 | 内容完整度差：文章无视觉元素 | `project-init` 已加配图规范 + **Gate II** + `scripts/gen_inline_images.py` 一键生成（PIL 信息卡片，自动从 research_notes 提取数据） | ✅ **已修复**（PIL 信息卡片法，非 ComfyUI） |
| **GAP-R7** | **非公众号平台无自动化发布**——知乎/小红书/抖音/B站 只有 content_ready | 交付是半成品 | 无（知乎/B站无公开 API；XHS/抖音有浏览器自动化但脆弱） | ❌ **未解决**（见下方说明） |

> **GAP-R7 说明**：非公众号平台发布自动化涉及独立基建。小红书和抖音已有 Playwright 浏览器自动化脚本（见 `xiaohongshu-publisher` / `douyin-publisher` skill），但知乎和 B站无公开内容发布 API，需要开发独立的浏览器发布流水线。受影响的平台：知乎(❌无)、B站(❌无)、小红书(⚠️脆弱)、抖音(⚠️脆弱)。**此项作为独立任务在后续 session 处理，不影响当前生产。**

### 触发

本清单在加载 `automedia-production-guard` 时自动可见。启动新项目时提醒自己各环节的 Gate 要求。

### 当前应对策略（GAP-R5/R7 未完全解决前的主动补偿）

- GAP-R5：执行 `python3 scripts/gen_inline_images.py <project_dir>` 一键生成配图（自动从 research_notes 取数）
- GAP-R7：交付时主动告知用户「非公众号平台请手动发布」，附各平台发布指引

---
