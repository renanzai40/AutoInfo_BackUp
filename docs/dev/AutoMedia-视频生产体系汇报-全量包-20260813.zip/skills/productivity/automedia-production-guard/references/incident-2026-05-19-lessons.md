# ⚠️ 2026-05-19 事故教训（永久固化）

## ⚠️ 2026-05-19 事故教训（永久固化）

引流款+业务款文案在 subagent 生成后，wechat-upload-checklist 没有被触发，
导致公众号标题超9字（引流款10字/业务款25字），草稿不能直接上传。
根因：wechat-upload-checklist 的触发条件是「生成草稿之前」，但 subagent 执行时跳过了。
skill 里写得再清楚，执行时跳过 = 零。

**Token 不是约束**：全量 QA 消耗 10 倍 token 也接受，质量比 token 成本重要得多。

### ⚠️ Gate 橡皮图章反模式（2026-06-25 用户纠错固化）

> **核心问题**：agent 把 Gate 做成「写报告」而不是「做检查」。具体表现为：写一份「✅ Sweep 1-5 全部通过」的报告，但实际上没有通读内容、没有逐轮审视——只是看了文件标题和字数就盖章 PASS。这比跳过 Gate 更隐蔽，因为报告存在但检查不存在。

**症状**：
- copy-review 报告的 Sweep 1-5 全部 ✅ 通过，但问用户一个问题就被发现内容没真读过
- wechat-upload-checklist 报告写「✅ PASS」但实际 HTML 标签数量为 0
- review_log.json 写好了但找到的具体问题为零（Gate C0/C1/C2 无任何 findings）

**根因**：agent 把「检查」理解成「写报告」，把「完成」理解成「有文件」。报告文件存在 ≠ 检查做了。

**硬规则**：
1. **Sweep 1-5 每一轮都必须输出至少一个具体的发现**（即使是通过，也要写一句具体说明如「S1: 无歧义句 ✅」而不是空泛的「✅ 通过」）
2. **审核报告不能只给结论**：必须有具体的原文+问题+对应行号或段落
3. **发现 = 0 = 异常**：如果一轮审查下来「没有任何问题」，说明审查走得太浅——回去重审，找到至少一个可改进的点（即使是小问题也算，如「OSTP 缩写在首次出现时未展开」）
4. **G2-C2 是读取+判断，不是格式转换**：不应用 `delegate_task` 生成 review 报告——review 是主 agent 的深度判断义务，不能外包

**检查方法**（写 review_log 前自问）：
- 我真正读了这份内容的每一段了吗？
- 我能不能说出这篇文章的三个具体缺点？
- 如果用户追问「这里有什么问题」，我能立刻回答还是只能说「都挺好」？

**反模式（永久禁止）**：
- ❌ review 报告全 ✅ 且无任何具体发现
- ❌ 只检查文件存在性和字数，不检查内容质量
- ❌ 用 subagent 代审（review 是主 agent 的深度判断义务）
- ❌ 发现「这内容有点 AI 腔」但不具体指出来是哪几行、属于什么模式
- ❌ 「内容是从 source_url 摘录的所以应该没问题」跳过核查

### 🆕 CJK 字体前置检查（2026-06-15 硬门控）

> **根因**：2026-06-15 发现在同一个 session 中，**两个独立脚本**因使用 DejaVuSans 字体（无 CJK 字形）导致中文文本不可见：(1) `scripts/burn_subtitles.py` 字幕烧录 (2) `scripts/gen_inline_images.py` 内文配图生成。两个脚本均为 2026-06-15 当天创建，均默认选择 DejaVuSans。之后 `burn_subtitles.py` 已修复使用 wqy-zenhei，`gen_inline_images.py` 已修复使用 wqy-zenhei。

**核心铁律**：**系统中所有生成中文文本的脚本/工具必须使用支持 CJK 的字体。** DejaVuSans（Linux 系统默认）不包含中文字形，使用它渲染中文会产生不可见/方块字符。

**强制 fontfile 白名单**：
| 字体 | 用途 | 路径 |
|------|------|------|
| WenQuanYi Zen Hei | 字幕烧录、PIL 配图 | `/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc` |
| Noto Sans CJK | 备选（未安装时） | `/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc` |

**触发时机**（任何以下操作前必检查）：
- 新建/修改任何含 PIL `ImageFont.truetype()` 的脚本 → 确认字体路径指向 wqy-zenhei
- 新建/修改任何含 ffmpeg `drawtext` 滤镜的脚本 → 确认 `fontfile` 指向 wqy-zenhei
- 新建/修改任何含 ffmpeg `subtitles` 滤镜的脚本 → 禁止使用（libass 依赖不稳定），用 drawtext 替代
- 引用 `scripts/gen_inline_images.py` 或 `scripts/burn_subtitles.py` 时 → 确认已使用正确字体

**验证命令**：
```bash
# 确认字体可用（返回非空路径为 OK）
ls /usr/share/fonts/truetype/wqy/wqy-zenhei.ttc

# 测试 PIL 能否正确渲染中文
python3 -c "
from PIL import ImageFont
f = ImageFont.truetype('/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc', 20)
print(f'✅ CJK font OK: {f}')
"
```

> **反模式**（永久禁止）：
> - ❌ 新脚本默认使用 DejaVuSans（因为它存在且易写）
> - ❌ 假设 PIL 或 ffmpeg 会 fallback 到系统 CJK 字体（不会——它们使用精确字体路径）
> - ❌ 修好了字幕脚本但没检查内文配图脚本（同 session 踩坑）
>
> ### 🆕 字幕长句自动换行逻辑（2026-06-19）
>
> `scripts/burn_subtitles.py` 内置自动换行逻辑：当字幕文本超过 35 字且没有手动换行时，会在句号/问号/叹号（。！？）处自动拆行，其次在逗号/分号/顿号（，；、）处拆行。已有手动换行的条目不受影响。
>
> 触发条件：文本长度 > 35 字符 且 文本中不含 `\n`（已有手动换行则跳过）。
>
> 拆行优先级：句号/问号/叹号（最后一个位置 ≤ 35 字处）→ 逗号/分号/顿号 → 不拆（保留原长文本）。
>
> 此逻辑已在 `burn_subtitles.py` L27-L37 代码级实现，无需手动干预。
