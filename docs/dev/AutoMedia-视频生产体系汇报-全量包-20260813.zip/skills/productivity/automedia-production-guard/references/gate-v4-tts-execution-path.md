# #🆕 V4 新增（2026-06-24 事故固化）：TTS 生产执行路径 + Voice 资产锁定

### 🆕 V4 新增（2026-06-24 事故固化）：TTS 生产执行路径 + Voice 资产锁定

> **事故**：2026-06-24 用 `text_to_speech` 工具（Hermes 内置 TTS）生成中文音频，工具返回 `voice_compatible: false`（默认 voice 不支持中文），我忽略该警告继续渲染，导致音频变成音节碎片（「7500 AI」、「30i」），视频从应有 60s 骤降到 16s。**两层 Gate 被绕过才能发生的故障：V4（voice 品牌）没执行 + V5（Whisper 验证）没跑。**

**默认 Voice（2026-06-24 用户确认）：**
`edge-tts --voice zh-CN-YunjianNeural`
中文男声，所有 AutoMedia 视频 TTS 使用此 voice。

**Fallback 链（自上而下尝试，任一成功即停）：**
1. `zh-CN-YunjianNeural`（✅ 用户确认的默认 voice，2026-06-24）
2. `zh-CN-YunxiNeural`（男声备选，默认 voice 服务端不可用时）
3. `zh-CN-XiaoxiaoNeural`（女声备选，前两个均不可用时的兜底）

**强制执行路径（唯一允许的 TTS 生产方式）：**

```bash
python3 ~/.hermes/profiles/content/scripts/tts_produce.py \
  --text "<纯净口播文本>" \
  --output 03_video/audio_voiceover.mp3
# 脚本内部自动完成：
#   1. edge-tts 生成（禁止用 text_to_speech 工具）
#   2. Fallback 链重试（Yunjian→Yunxi→Xiaoxiao）
#   3. Whisper 关键词验证（命中率 ≥ 30%）
#   4. exit 0 = 成功 / exit 1 = Pipeline STOP
```

`tts_produce.py` 是 TTS 生产的唯一入口。任何其他方式（`text_to_speech` 工具、`edge-tts` 直调不验证、m3 tts 等）均违反本 Gate。

**代码级 Guard（2026-06-24 新增）：**
脚本返回 `voice_compatible: false` 时 → hermes 侧自动抛出 PipelineError，阻塞 render。
脚本 exit code != 0 → 下游 compose/render 不得启动。

**禁止项：**
- ❌ 禁止使用 `text_to_speech` 工具生成 AutoMedia TTS — 其 `voice_compatible` fallback 行为对中文不可控，已导致 2026-06-24 事故
- ❌ 禁止 `edge-tts` 直调不跑验证（tts_produce.py 已内置验证，手动跑 edge-tts 不会自动验证）
- ❌ 禁止将 TTS 输出直接送入渲染管线而不经 Whisper 验证
