# #🆕 Gate B0 完整规范：博客自动发布（2026-06-22 新增）

### 🆕 Gate B0 完整规范：博客自动发布（2026-06-22 新增）

> **核心逻辑**：项目文案锁定后（Gate II 通过后），自动判断是否适合官网博客。博客是增量发布，不阻塞视频/社交发布管线。本 Gate 由 `scripts/auto_blog_publish.py` 实现。

#### 触发条件

```
1. Gate II（Inline Image）已通过 → 文案锁定
2. 项目不是引流款/政经类（不适合博客的类型已过滤）
3. 有知乎文章且 > 2000B（有深度内容）
4. 该话题未在官网博客中存在（auto_blog_publish.py --all 会自动对比）
```

#### 执行

```bash
# 生成博客 MDX（不自动部署）
python3 /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/scripts/auto_blog_publish.py <project_dir>

# 生成 + 自动部署（build 验证通过后自动 git push 🔥）
python3 /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/scripts/auto_blog_publish.py <project_dir> --deploy
```

#### 产出物

- 博客 MDX 文件：`Official_Website/src/content/docs/blog/[slug].mdx`
- `--deploy` 模式：**自动** `git add → npx astro build验证 → git commit → git push origin main`
- 自动部署失败时：回滚 `git add`，输出错误日志，不阻塞流水线

#### 实现细节

| 环节 | 处理 | 位置 |
|------|------|------|
| 资格判断 | 检查项目类型/内容深度/是否重复 | `auto_blog_publish.py` 资格判断函数 |
| 标题提取 | 从 zhihu 文章 `# H1` 提取 | `auto_blog_publish.py` extract_title() |
| 内容清洗 | 品牌名统一/移除旧CTA/移除平台标识/统一CTA | `auto_blog_publish.py` clean_content_for_blog() |
| Slug 生成 | 英文小写，从中文话题提取关键词 | `auto_blog_publish.py` generate_slug_from_topic() |
| Frontmatter | title/description/pubDate/type | `auto_blog_publish.py` generate_frontmatter() |

#### 反模式

- ❌ 博客生成阻塞视频发布（Gate B0 是 non-blocking Gate）
- ❌ 未 build 验证就 git push（必须 `npx astro build` 通过再推）
- ❌ 不改 nav-config 导致新文章不可见（Starlight 自动扫描 blog/ 目录，无需手动加链接）

---
