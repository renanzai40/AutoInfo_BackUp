# #三层架构

### 三层架构

| 层 | 机制 | 触发方式 | 防御住什么 |
|----|------|---------|----------|
| **Layer 1: Shell Hook** | config.yaml `hooks.pre_tool_call` 自动拦截 render 等敏感命令 | Hermes 每次调 tool 时自动触发 | render 前检查 VQ/V4/V5 等 gate 产物是否存在 |
| **Layer 2: Self-Check** | 每完成一个 Track（文案/视频/生命周期）运行 audit 脚本扫描项目目录 | agent 主动调（skill 强制）+ 汇报给用户 | 抓漏网之鱼 — 缺少的 gate 产物/报告/文件 |
| **Layer 3: TODO 纪律** | 进入新阶段前调 todo() 列项，完成一项标一项，向用户汇报 | agent 习惯层（skill 强制） | 防串流程忘步骤 |
