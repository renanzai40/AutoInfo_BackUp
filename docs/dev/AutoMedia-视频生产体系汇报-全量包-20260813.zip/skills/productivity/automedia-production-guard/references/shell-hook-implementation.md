# Shell Hook 实现参考（pre_tool_call）

## 配置格式

`~/.hermes/profiles/content/config.yaml`:

```yaml
hooks_auto_accept: true
hooks:
  pre_tool_call:
    - command: /absolute/path/to/hook_script.sh
      matcher: "terminal|execute_code"   # Regex: tool_name 匹配
      timeout: 15
```

- `hooks_auto_accept: true` 必须在非 TTY 环境（飞书/Telegram）使用，否则每次 session 启动需 TTY 确认
- `matcher` 是 regex `fullmatch()`，默认可选。省略则对所有 tool 触发
- `timeout` 默认 60s，建议 15-30s（hook 应快速返回）

## Wire Protocol

Shell hook 每次触发时，stdin 收到 JSON：

```json
{
    "hook_event_name": "pre_tool_call",
    "tool_name": "terminal",
    "tool_input": {
        "command": "bun x hyperframes render --quality draft"
    },
    "session_id": "sess_abc123",
    "cwd": "/home/user/project",
    "extra": {}
}
```

### stdout 响应

**拦截**（任意一种格式）：
```json
{"action": "block", "message": "❌ Render blocked — missing gates: VQ V4"}
{"decision": "block", "reason": "Forbidden command"}
```

**放行**：
- 空 stdout
- 不匹配以上格式的任意 JSON

## 脚本要点

```bash
#!/bin/bash
set -euo pipefail

INPUT=$(cat)
COMMAND=$(echo "$INPUT" | python3 -c "
import json, sys
d = json.load(sys.stdin)
ti = d.get('tool_input', {}) or {}
cmd = ti.get('command', ti.get('python_code', ''))
print(cmd)
")

# 筛选特定命令
echo "$COMMAND" | grep -qE 'hyperframes render' || exit 0

# 检查条件...
# ...

# 阻止
echo '{"action": "block", "message": "..."}'
exit 0   # exit code 被忽略，决策看 stdout 内容
```

## 已知局限

| 局限 | 说明 | 缓解 |
|------|------|------|
| 同 profile 可改 | hook 脚本和 config.yaml 在同一 profile 下，agent 可修改 | 靠用户可见性 |
| execute_code subprocess | execute_code 内 `subprocess.run(["bun",...])` 绕过 terminal hook | 靠 audit 层事后检测 |
| 仅 pre_tool_call 可拦截 | post_tool_call / transform 系列 hook 为观察者，不能 block | — |

## 验证命令

```bash
echo '{"hook_event_name":"pre_tool_call","tool_name":"terminal","tool_input":{"command":"bun x hyperframes render"},"cwd":"/tmp/test"}' | bash /path/to/hook_script.sh
```

预期输出（条件未满足时）：`{"action": "block", "message": "..."}`
