# #Layer 3: TODO 纪律

### Layer 3: TODO 纪律

**强制规则**：每次进入新阶段前（R0/文案 Track/视频 Track/生命周期），先调 `todo()` 列分段计划。

```markdown
TODO 示例：
1. todo(id="r0", content="R0: Research 调研来源", status="in_progress")
2. todo(id="script", content="写 5 段式脚本", status="pending")
3. todo(id="copy-c0", content="C0: 事实核查", status="pending")
4. todo(id="copy-c1", content="C1: Humanizer 改写", status="pending")
...
```

**纪律要求**：
- 每完成一步 → `todo(id="xxx", status="completed")`，并发用户一条 1 句进度
- 跳过步骤 → 用户对照 TODO 发现少了
- 禁止一次性全标 completed 而未逐个验证
