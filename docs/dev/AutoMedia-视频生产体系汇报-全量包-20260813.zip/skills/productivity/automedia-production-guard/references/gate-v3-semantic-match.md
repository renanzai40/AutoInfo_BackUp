# #Gate V3 完整规范：Content Semantic Match（2026-06-05 P0-5 新增）

### Gate V3 完整规范：Content Semantic Match（2026-06-05 P0-5 新增）

> **触发原因**：2026-06-05 user 反馈"今天这两个视频生产出来的质量如此离谱"——诊断发现 codex 视频 5s 帧 vision 看到"护肤品/化妆品"（v10 美容 SCENE 视觉残留），V1 Gate 只检查"字幕像素亮度" + V2 只检查"Whisper 转写关键词"——**都没要求含今天话题关键词**。本 Gate 补完。

**核心问题**：现在 V1/V2 只能检测"有字幕"、"有音频"、"字幕音频对得上"——**检测不到"内容是不是今天的话题"**。V3 补完。

#### 检查流程（必跑，3 步）

```
1. 从 pool.db 动态提取今天话题关键词清单
   - 读 00_project_info.json.reuse_decision.scores（如果存在）
   - 或读 pool.db 当前 topic 的 title，做中文分词 + 命名实体识别
   - 输出关键词数组：["Alphabet", "Anthropic", "800亿", "IPO", "融资", ...]
   - 至少 5 个关键词（数字/专有名词/核心动词）

2. 多源关键词匹配（3 源全部比对）
   - 源 A：视频 SRT 文本
   - 源 B：Whisper 转写文本
   - 源 C：5 段视觉抽帧 OCR 文本
   - 命中率：关键词在 3 源中出现的比例
   - 阈值：≥ 80% 关键词必须出现在 ≥ 2 源中

3. 失败处理
   - 命中率 < 80% → BLOCK_send
   - 单一源缺失（如 SRT 不含但 Whisper 含）→ 警告但不阻塞
   - 3 源都不含的关键词 → 列出缺失关键词清单
```

#### 6-05 实战案例（user 反馈 bug 触发本 Gate 设立）

| 检查 | v10 套用结果 | V3 应检出 |
|------|------------|----------|
| 今天话题 "OpenAI Codex 团队插件" | codex 5s 帧 vision 看："护肤品/化妆品" | ❌ 关键词 "OpenAI" / "Codex" / "插件" 全无 |
| 今天话题 "Alphabet 800亿 + Anthropic IPO" | alphabet 5s 帧 vision 看：v10 片尾 CTA "关注壹目贯维" | ❌ 关键词 "Alphabet" / "Anthropic" / "800" / "IPO" 视觉无 |
| **V3 应输出** | "❌ 关键词覆盖率 0%，BLOCK_send" | **必拦** |

#### 实施

```python
import sqlite3, jieba, subprocess, json

# 1. 读 pool.db 当前话题
conn = sqlite3.connect("/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db")
cur = conn.cursor()
cur.execute("""
    SELECT title FROM topics
    WHERE status='pending' AND review_status='approved'
      AND angle_score IS NOT NULL AND angle_score >= 7
    ORDER BY category, heat_score DESC
""")
titles = [r[0] for r in cur.fetchall()][:6]  # TOP3 引流 + TOP3 业务

# 2. 提取关键词
keywords = set()
for t in titles:
    for word in jieba.cut(t):
        if len(word) >= 2 and not word.isdigit() or word.replace('.','').isdigit():
            keywords.add(word)
# 也加纯数字（800/100/IPO 等）
import re
for t in titles:
    keywords.update(re.findall(r'\d+\.?\d*[万亿]?', t))
# 去通用词
STOP_WORDS = {"的", "是", "在", "了", "和", "与", "或", "等", "等"}
keywords = [k for k in keywords if k not in STOP_WORDS and len(k) >= 2][:10]

# 3. 多源比对
# 源 A：SRT
srt_text = open("03_video/subtitle.srt").read()
# 源 B：Whisper 转写（已有）
whisper_text = open("03_video/whisper_output.txt").read()
# 源 C：5 段视觉 OCR（用 ComfyUI + OCR，旧方案 mcp_minimax 已停用）
ocr_texts = []
for t in [2, 5, 8, 11, 14]:  # 5 段中点秒
    ffmpeg_cmd = ["ffmpeg", "-y", "-ss", str(t), "-i", "03_video/video_final.mp4",
                  "-frames:v", "1", f"/tmp/peek_{t}.jpg"]
    subprocess.run(ffmpeg_cmd, capture_output=True)
    # OCR via ComfyUI screenshot + PIL/tesseract（旧 MiniMax MCP 已停用）
    # 简化：此处用 vision_analyze 替代

# 4. 命中率
def hit(kw, src): return kw in src
hit_count = sum(1 for kw in keywords
                if hit(kw, srt_text) or hit(kw, whisper_text))
rate = hit_count / len(keywords) * 100

# 5. 决策
if rate < 80:
    missing = [kw for kw in keywords
               if not (hit(kw, srt_text) or hit(kw, whisper_text))]
    raise Exception(
        f"❌ V3 Content Semantic Match FAILED\n"
        f"   关键词覆盖率: {rate:.1f}% < 80%\n"
        f"   缺失关键词: {missing}\n"
        f"   → Pipeline STOP，BLOCK_send"
    )
print(f"✅ V3 PASS: 关键词覆盖率 {rate:.1f}%")
```

#### 反模式（永久禁止）

- ❌ **关键词清单写死**"AI" / "模型" / "数据" 等通用词——必须从 pool.db 动态提取
- ❌ **只用 SRT 一源匹配**——单源失败率高，必须 3 源（详见 m3 案例 + 6-05 codex 案例）
- ❌ **阈值 < 80%**——放过就是允许模板套用
- ❌ **跳过 Gate V3 改用 V1/V2 替代**——V1/V2 检测不到内容错位

#### 配套 Gate（与 P0-3 SRT 缺失门控互补）

- **P0-3 srt-must-exist**：SRT 文件必须存在（防"没字幕的 mp4"）
- **P0-5 V3 Content Semantic Match**：SRT 必须含今天话题关键词（防"空 SRT" / "模板套用 SRT"）
- 两者串联：SRT 存在 + SRT 含今天关键词 + 视觉 OCR 验证 = 三道防线

#### 6-05 user 反馈的 2 个具体 case

| Case | 视频 | V3 应输出 | V1/V2 没拦住的原因 |
|------|------|----------|-------------------|
| codex 5s 帧"护肤品" | 0 字幕 + v10 视觉 | "关键词 'OpenAI/Codex/团队/插件' 覆盖率 0%" | V1 只看像素亮度 = 0 字幕时 return "ok"；V2 Whisper = 没字幕就报错"无音频"（但仍可发） |
| alphabet 5s 帧 v10 片尾 CTA | v10 视觉 + v10 字幕 | "关键词 'Alphabet/Anthropic/800亿/IPO' 视觉无；SRT 未必有" | V1 看到字幕存在 = ok；V2 Whisper 转写 = 看到的"800亿"勉强 1 命中，但视觉错位漏检 |

**V3 必检视觉 OCR**——这是和 V1/V2 的本质区别：  
- V1/V2 检查"有没有字幕/音频"  
- V3 检查"字幕/音频/视觉讲的是不是今天话题"
