# #🆕 Gate VQ 完整规范：Video Design Quality（2026-06-15 新增）

### 🆕 Gate VQ 完整规范：Video Design Quality（2026-06-15 新增）

> **触发原因**：2026-06-15 事故——两个视频 5 段全部使用同一布局、同一动画、无主题、无视觉多样性。根因是视频 Track 走了「一键自动生成」思维，跳过了设计环节。

**核心铁律**：视频是设计产物，不是脚本的视觉转译。写 composition 前必须先做设计决策。

**🔥 重做锚定原则（2026-06-15 新增）**：当需要重做/重新渲染一个已通过验收的视频时，**必须默认使用上次验收通过时的主题/设计语言**。禁止凭空选择新主题。只有用户明确要求换设计时才换。

> **事故案例**：2026-06-15 同一 session 内，下午私聊已通过验收的视频使用 `pitch-deck-vc`（Anthropic）和 `tokyo-night`（MiniMax），但后续重做时擅自换用 `deep-ocean` 和 `forest-dark` 新主题，导致观感下降被用户质疑。根因：重做时没有回看最近一次验收通过的版本用了什么设计。

**正确做法**：
1. 重做前先查最近一次通过用户验收的 publish_log / 检查飞书聊天记录
2. 确定当时使用的主题名和 CSS 变量
3. 用同主题 + 同布局方案重写 composition
4. 重做完成后与旧版本做并排对比（动画节奏 / 配色层次 / 视觉深度）
5. 只有用户说「换个风格」时才选新主题

#### 3 步预设计流程（写 composition 前必跑）

```bash
# Step 1: 选主题
# 加载 hyperframes-workflow skill → references/theme-palettes.json（36主题）或 od-themes.json（8品牌）
# 选 1 个主题，记录其 CSS 变量
cat > /tmp/theme_vars.txt << 'EOF'
--bg: #1a1b26
--surface: #24283b
--accent: #7aa2f7
--text-1: #c0caf5
--grad: linear-gradient(135deg,#7aa2f7,#bb9af7)
--radius: 12px
EOF

# Step 2: 定布局序列
# 加载 references/visual-layouts.md → 6种类型
# 写 layout_seq = [type1, type2, type3, type4, type5]
# 约束：≥4种不同 + 相邻不同
python3 << 'CHECK'
seq = [6, 4, 2, 1, 5]  # 替换为实际布局类型编号
unique = set(seq)
assert len(unique) >= 4, f"❌ 只有 {len(seq)}-{len(unique)}={len(seq)-len(unique)}种重复布局，需要 ≥4"
for i in range(len(seq)-1):
    assert seq[i] != seq[i+1], f"❌ S{i+1}和S{i+2}布局重复 ({seq[i]})"
print(f"✅ 布局序列通过: {len(unique)}种, 相邻无重复")
CHECK

# Step 3: 参考组件的 CSS 骨架
# 每种布局类型在 visual-layouts.md 中有对应的 CSS skeleton
# 直接复制粘贴到 composition 中使用，修改内容即可
```

#### 布局类型 ↔ 场景角色速查

| 场景角色 | 推荐布局 | 备选布局 |
|---------|---------|---------|
| 开场钩子 | 全屏叙事型 (6) / 居中大字型 (1) | 数据面板型 (4) |
| 痛点/问题 | 卡片网格型 (3) | 水平分栏型 (2) |
| 分析/论证 | 数据面板型 (4) | 水平分栏型 (2) |
| 对比/方案 | 水平分栏型 (2) | 数据面板型 (4) |
| 洞察/观点 | 居中大字型 (1) / 全屏叙事型 (6) | — |
| CTA/品牌 | 流程步骤型 (5) / 居中大字型 (1) | 全屏叙事型 (6) |

#### Gate VQ 自检清单

| # | 检查项 | 标准 | 失败后果 |
|---|--------|------|---------|
| 1 | 主题已选 | 从 theme-palettes.json 或 od-themes.json 中选 | Pipeline STOP |
| 2 | CSS 变量数 | ≥ 6 个（--bg/--surface/--accent/--text-1/--grad/--radius 等） | Pipeline STOP |
| 3 | 布局多样性 | 5 段 ≥ 4 种不同布局 | Pipeline STOP |
| 4 | 相邻布局不同 | 每对相邻场景布局类型不同 | Pipeline STOP |
| 5 | 动画多样性 | ≥ 2 种不同 easing 函数（power3.out / back.out / power2.out 等） | Pipeline STOP |
| 6 | 每场景 clip 数 | 每场景 ≥ 2 个 clip 元素（不仅是单行文字） | Pipeline STOP（此前为WARN → 2026-06-15升级：避免单元素简陋场景） |
| 7 | 场景-旁白覆盖 | 每个场景的视觉元素覆盖对应 narration 关键点 | Pipeline STOP（此前为WARN → 2026-06-15升级） |
| 8 | **🔥 视觉丰富度审核（2026-06-15 新增）** | 渲染前 agent 自审：是否有足够视觉深度（配色层次/卡片阴影/渐变/边框细节）？animation 是否有节奏变化？是否跟上一版已通过的标准匹配？**纯 inline text + 简单背景 = 不合格** | **Pipeline STOP** |

**所有必检项（1-5）全部 PASS 才能往下写 composition。**

#### 反模式（永久禁止）

- ❌ 用自动生成脚本（如 `create_hf_project.py`）替代手动 composition 设计
- ❌ 5 段全部同一布局（「居中大字型」是最大频错误）
- ❌ 不选主题直接手写 `--bg: #0f172a` 等零散 CSS
- ❌ 所有场景用同一套 GSAP 动画参数（opacity/y/duration 全相同）
- ❌ composition 写完才发现布局单调
