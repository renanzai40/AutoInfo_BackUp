# ⚠️ Subagent "timeout" 不等于 "未完成"（2026-06-05 实测固化）

## ⚠️ Subagent "timeout" 不等于 "未完成"（2026-06-05 实测固化）

> **核心铁律**：**subagent 汇报 timeout / error 时，必须先 verify 文件落地状态再决定是否重试。**
> "trust but verify" 适用于 subagent 返回的所有错误状态——不仅限于 timeout。

### 触发场景

| subagent 状态 | 工具返回的 `summary` 字段 | 实际任务状态 | 主 agent 错误反应 |
|---|---|---|---|
| `timeout` (exit_reason=timeout) | `null` | **可能已完成**（仅超时未及时回执） | 立即重试 = 浪费 600s + 重复文件 |
| `error`（某 API 失败）| 错误堆栈 | **可能核心产物已落地** | 立即重试 = 重复文件 / 覆盖 |
| `completed` | 有 summary | 已完成 | 验证即可 |

### 6-05 实测案例

- 2 个 subagent 并行写引流款 + 业务款 5 平台草稿（10 文件）
- 工具返回 `status: timeout`, `summary: null`, **2 个 subagent 都 600s 超时**
- 立即按"已交付不改进"铁律硬重试 = 600s × 2 = 1200s 浪费 + 10 个文件被覆盖风险
- 实际 `ls` 验证：10 个草稿文件**全部存在**且非空（tiktok/wechat/zhihu/xiaohongshu/4 平台 × 2 话题 + bilibili 副本）
- subagent **只是没时间返回 summary**，实际任务完成

### 强制验证流程（subagent timeout/error 后必跑）

```bash
# 1. 列出所有 5 平台草稿文件
ls -la {project_dir}/01_content/drafts/{tiktok,bilibili,wechat,zhihu,xiaohongshu}/
# 2. 验证文件大小（>200B 才有意义）
for plat in tiktok bilibili wechat zhihu xiaohongshu; do
  size=$(stat -c%s "{project_dir}/01_content/drafts/$plat/"* 2>/dev/null | head -1)
  echo "$plat: ${size}B (≥200B = OK)"
done
# 3. 验证中文字符数（每个文件 ≥300 字）
python3 -c "
import os
for p in ['tiktok','bilibili','wechat','zhihu','xiaohongshu']:
    f = '{project_dir}/01_content/drafts/'+p+'/'
    for name in os.listdir(f):
        full = f+name
        c = open(full, encoding='utf-8').read()
        chs = sum(1 for x in c if 0x4e00<=ord(x)<=0x9fff)
        print(f'{p}/{name}: {len(c)}B / {chs} 汉字')
"
```

### Decision Tree

```
subagent 返回 status='timeout' 或 'error'
    ↓
[Step 1] 立即列文件 / 读 project_dir 状态
    ↓
    ├─ 5 平台文件全部存在 + size 合理 + 字符数达标
    │   → ✅ 任务实际完成
    │   → 不重试！直接进入 Gate C1 Humanizer
    │   → subagent 的"timeout" 只是回执超时
    │
    ├─ 部分文件存在
    │   → 主 agent 立即补全缺失的（不告知 user, 不重试 subagent）
    │   → 缺失的用 DeepSeek-v4-flash / 主 agent 直接写
    │
    └─ 5 平台文件全无 / 全空
        → 重试 subagent（这次只跑缺失平台，避免再次 600s）
        → 或主 agent 接手全部 5 平台
```

### 反模式（永久禁止）

| ❌ 反模式 | ✅ 正确做法 |
|---|---|
| subagent timeout → 立即重试 | timeout → 立即 verify 文件 → 文件在 = 不重试 |
| subagent timeout → 告知 user "失败" | 实际完成但误报"失败" = 给 user 假警报 + 浪费信任 |
| subagent timeout → 等下一个 session | 主 agent 必须立即补全/重试，不阻塞 session |
| subagent "completed" 但实际文件无 | 同样要 verify（不只是 timeout/error 状态要查） |

### 🔥 Subagent "completed" 也未必真过（2026-06-07 实测再次强化）

> **2026-06-07 教训**（在 6-05 之上再次强化）：即使是 `status="completed"` + summary 显式 "5 平台完成 / 字数达标" 的 subagent，**仍然可能报告 ≠ 实际**。subagent 不会主动 ls 文件统计字数 / grep 品牌名——它的"完成"判断是基于"我写了 write_file" 而非"我 verify 了文件内容"。

**实测 6-07 案例**（2 个 subagent 并行 5 平台，10 文件）：

| subagent 自报告 | 主 agent 实际 verify |
|---|---|
| "5 平台完成 + 3/5 review" | ✅ 10 草稿文件落地 |
| "5 平台都含'壹目贯维' 1-3 次" | ❌ **实际最初 = 0 次**（subagent 报告虚） |
| "字数达标 wechat 2000 字" | ❌ **实际 1237-1453 字**（普遍不达标） |
| "tiktok/bilibili review 已写" | ❌ **实际 M3 漏 2 个 review 报告**（subagent 没写完） |

**根因**：
- subagent 的 `write_file` 成功 ≠ 文件内容含期望字段
- subagent 看到 prompt 要求 "确保含壹目贯维 1 次"，但实际写的内容未必真的含
- 字数同理：subagent 报告"目标 2000 字"但实际写到 1200-1500 字也认为"达标"

**主 agent 强制 verify 流程（subagent 返回后必跑，包含 completed/timeout/error 全部状态）**：

```bash
# 1. 5 平台文件落地（先确认文件存在）
for plat in tiktok bilibili wechat zhihu xiaohongshu; do
  ls -la "{project_dir}/01_content/drafts/$plat/" 2>/dev/null
done

# 2. 字数 + 品牌名 + 禁词 + think 标签 4 项必查
python3 << 'EOF'
import os, re
for plat in ['tiktok', 'bilibili', 'wechat', 'zhihu', 'xiaohongshu']:
    p = f"{{project_dir}}/01_content/drafts/{plat}/"
    if not os.path.isdir(p):
        print(f"❌ {plat}: 目录不存在")
        continue
    for name in os.listdir(p):
        full = p + name
        if not os.path.isfile(full):
            continue
        c = open(full, encoding="utf-8").read()
        chs = sum(1 for x in c if 0x4e00 <= ord(x) <= 0x9fff)
        brand = c.count("壹目贯维")
        has_think = len(re.findall(r"<think>[\s\S]*?</think>", c))
        bad = {"扫码", "限时优惠", "立即抢购", "私信就送", "评论区扣1", "错过就没了", "投资情报", "金融分析", "扫码立减"}
        bad_hits = {b: c.count(b) for b in bad if c.count(b) > 0}
        status = "✅" if (brand >= 1 and has_think == 0 and not bad_hits) else "❌"
        print(f"{status} {plat}/{name}: 字={chs} 品牌={brand} think={has_think} 禁词={bad_hits}")
EOF

# 3. 缺失 review 报告检查
for plat in tiktok bilibili wechat zhihu xiaohongshu; do
  f="{project_dir}/04_review/copy_review_${plat}.md"
  [ ! -f "$f" ] && echo "❌ 缺 review: $f"
done
```

**4 项 verify 结果 → 4 种应对**：

| 情况 | 动作 |
|---|---|
| ✅ 全部通过 | 进入 Gate C1 Humanizer，不阻塞 |
| ❌ 部分文件字数不达标 | 主 agent 立即用 DeepSeek-v4-flash 补字数（不依赖 subagent 重试） |
| ❌ 品牌名"壹目贯维"缺失 | 主 agent 立即追加 CTA 段（包含品牌身份说明） |
| ❌ review 报告缺失 | 主 agent 立即用模板补写（不重试 subagent） |
| ❌ 禁词命中 | 主 agent 立即替换（如有敏感词 + 智能替换 = 工艺失误） |

**核心教训**：
- subagent 的"completed + summary" ≠ "Gate 实际通过"
- 主 agent **永远必须跑 verify 脚本**，不能用 subagent summary 当成 verify 替代
- 一旦发现 subagent 虚报，**绝不重试 subagent**（已写入的文件 + subagent 不可信 = 主 agent 自己补完最快）

### 🆕 6-07 强化："completed" 状态加进强制 verify 触发条件

修改原 verify 决策树：

```
subagent 返回任意状态（completed / timeout / error）
    ↓
[必跑] 主 agent ls + 字数 + 品牌 + 禁词 4 项 verify
    ↓
    ├─ 全部 ✅ → 任务实际完成，进入 Gate C1
    ├─ 部分 ❌ → 主 agent 立即补全（不重试 subagent）
    └─ 全部 ❌ → 重试 subagent（这次只跑缺失平台，避免再次 600s）
```

**禁止**：
- ❌ "subagent 报 completed 就是过了"——2026-06-07 实测 5/10 文件 verify 不通过
- ❌ "verify 太慢，信任 summary"——verify 脚本 5s 跑完，比"信任 → user 发现 → 重做"快 10 倍
- ❌ "字数差一点没关系"——renan 确认的字数标准（公众号 2000 / 知乎 2000 / 小红书 500 / 抖音 150-200）**是硬要求**，不是参考值

### 与"subagent 600s timeout 避免做视频 Track"铁律的关系

- **旧铁律**（2026-05-25）：视频 Track 禁入 subagent（防超时丢帧图/音频）
- **新铁律**（2026-06-05）：**所有** subagent 任务 timeout 后必须 verify（不止视频 Track）
- 两者互补：旧铁律防"开始就 fail"，新铁律防"完成后误报 fail"
