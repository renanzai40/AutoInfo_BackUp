# TTS+SRT 同步铁律 & 飞书发送路径规范（2026-05-26）

## 1. TTS 重建后必须同步更新 SRT 和帧边界

**铁律：TTS 和 SRT 是成对出现的，每次 TTS 重建必须同步重建 SRT，不得单独使用旧版 SRT。**

### 典型失误场景（2026-05-26 实测）

项目：DeepSeek v1-v6 / Lorai v1-v6

1. 初始脚本写 5 条 entry → 生成 TTS + SRT（5条）
2. CTA 审查后修正 CTA → 重新生成 TTS（含新 CTA，内容变为 6 条 entry）
3. **SRT 未同步更新**（仍是 5 条）→ 视频里 CTA 字幕缺失（连续 6 个版本都缺失）
4. 音频最后一帧是 37.6s，但 SRT 最后一 entry 只到 35.2s → 末尾 2.4s 无字幕

### 根因分析

- TTS 重生成后，音频时长变了（旧 44s → 新 43s），但帧边界常量没更新
- SRT 还是旧的 5 条 entry，Entry 6（CTA）的时间轴根本没写
- Composition 里 `SCENE_SUBTITLES` 的 duration 数组也没更新
- 导致 Scene 6 字幕存在但时间轴错位，CTA 字幕完全不显示

### 正确流程

```
CTA 修正
  → 重新生成完整 TTS（全部 N 条 entry，包括新 CTA）
  → ffprobe 读取每段实际时长
  → 重新计算帧边界：T1_FROM/TO、T2_FROM/TO...
  → 更新 SRT 时间轴（与帧边界完全一致）
  → 更新 SCENE_SUBTITLES 数组的 duration 字段
  → 验证：音频总时长 ≈ 最后一个 SRT entry 的 end 时间
  → 才进入视频渲染
```

### Remotion 项目额外检查项

每次 TTS 重建后，必须检查以下常量和数组是否全部更新：

| 检查项 | 位置 | 更新依据 |
|--------|------|---------|
| 帧边界常量（T1_FROM, T1_TO...） | Composition.tsx | ffprobe 实测时长 × fps |
| TOTAL_FRAMES | Composition.tsx | 最后 entry end × fps |
| SCENE_SUBTITLES[].duration | Composition.tsx | 各 entry 时长（秒） |
| SRT 时间轴 | projects/*/03_subtitle/subtitle.srt | 与帧边界一致 |

### 验证命令

```bash
# 验证 SRT 最后一条时间轴与音频时长匹配（误差 < 1s）
ffprobe -v error -show_entries format=duration -of json /tmp/concat.wav
python3 -c "
import json, sys
r = json.loads(sys.stdin.read())
audio_dur = float(r['format']['duration'])
print(f'音频总时长: {audio_dur:.3f}s')
# 读取 SRT 最后 entry
# 比对误差
"

# 验证帧数一致性
python3 -c "
# DeepSeek v7 实测
# 音频总时长: 43.944s
# 帧率: 30fps
# 总帧数: int(43.944 * 30) = 1319
# 最后 entry (CTA) end: ~43.6s
# 误差: 43.944 - 43.6 = 0.344s < 1s ✅
"
```

---

## 2. 飞书发送视频文件前必须先复制到 Hermes 缓存目录

**症状**：直接用 `MEDIA:/path/to/video.mp4` 发送失败，日志报错：
```
Skipping unsafe MEDIA directive path outside allowed roots
validate_media_delivery_path returned null
```

**根因**：Hermes 安全验证只允许特定目录下的文件上传到飞书，原始路径不在白名单。

### 正确流程

```bash
# 1. 复制到缓存目录
cp /home/renanzai/Remotion-Test/out/deepseek_v7.mp4 ~/.hermes/cache/videos/

# 2. 用缓存路径发送（MEDIA: 后面跟 ~ 展开的绝对路径）
MEDIA:/home/renanzai/.hermes/cache/videos/deepseek_v7.mp4
```

### 允许的根目录

| 目录 | 用途 |
|------|------|
| `~/.hermes/cache/videos/` | 视频文件 |
| `~/.hermes/cache/audio/` | 音频文件 |
| `~/.hermes/cache/documents/` | 文档文件 |

### 不要这样做

- ❌ `MEDIA:/home/renanzai/Remotion-Test/out/video.mp4`（不在白名单，静默失败）
- ❌ `MEDIA:/mnt/d/...`（Windows 路径，不在白名单）
- ❌ `MEDIA:~/...`（飞书不支持 `~` 路径展开，必须用绝对路径）

---

## 3. 教训清单

| # | 教训 | 影响 | 防止措施 |
|---|------|------|---------|
| 1 | TTS 重生成后 SRT 没同步更新 | CTA 字幕连续 6 个版本缺失 | TTS 更新 → 立即重新计算帧边界 + 更新 SRT |
| 2 | 帧边界常量没更新 | 字幕与语音完全错位 | Composition.tsx 里的帧常量必须与 TTS 时长绑定 |
| 3 | SCENE_SUBTITLES.duration 没更新 | 某些 entry 时长错误 | 每次 TTS 更新后重新计算整个数组 |
| 4 | 直接用原始路径发送飞书 | 文件静默跳过，用户没收到 | 先复制到 `~/.hermes/cache/videos/` 再发送 |