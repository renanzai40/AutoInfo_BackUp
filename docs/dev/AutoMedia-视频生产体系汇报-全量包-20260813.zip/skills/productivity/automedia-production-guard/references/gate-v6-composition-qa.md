# #Gate V6 完整规范：Composition QA（2026-06-25 新增）

### Gate V6 完整规范：Composition QA（2026-06-25 新增）

**Gate 时机**：V0 (lint) 通过后、render 前

**检查工具**：`scripts/check_composition_qa.py <path/to/index.html>`

**Gate 脚本**：`python3 scripts/check_composition_qa.py` — 扫描 HTML composition，5 项检查：

| 编号 | 规则 | 检测方法 | 案例 |
|------|------|---------|------|
| V6-1 | **字号 ≥ 20px** | 扫描 `font-size:XXpx`，若存在 < 20px 报错 | 14px `.kicker` → 20px |
| V6-2 | **前景元素 top ≥ 300px** | 扫描 `position:absolute; top:XXXpx`，排除全屏背景，若 top < 300px 报错 | "3 秒解决" 在 250px → 300px |
| V6-3 | **前景元素 top ≤ 1620px**（距底 ≥ 300px） | 同 V6-2，若 top > 1620px 报错 | — |
| V6-4 | **无重复 class 属性** | 扫描同一标签内的 `class="..."` 出现 2+ 次，`id=` / `style=` 同理 | `class="clip" class="body-text"` 重复 |
| V6-5 | **无 CSS 语法错误** | 扫描 `style="..."` 内 `prop=XXpx` 模式（应为 `prop:XXpx`） | `top=660px` → `top:660px` |

**自动化**：`pre_render_hook.sh` 在 render 前自动检测 V6 状态。若 V6 未签入，自动运行 check 脚本并在通过后自动签名。无需手动操作。

**根因预防**：
- Subagent 输出后必跑 `check_composition_qa.py` 验证
- `class="clip"` 与样式类必须合并为 `class="clip classname"`，不允许两个 `class=` 属性
- CSS `style` 属性中所有属性值必须用 `:` 分隔，禁止用 `=`
- 字号底限 20px 由 `component-patterns.md` 中所有组件定义固化，12 处已全部更新
- 上边距底限 300px 在 composition 设计阶段由 VQ 约束布局时同步考虑

---
