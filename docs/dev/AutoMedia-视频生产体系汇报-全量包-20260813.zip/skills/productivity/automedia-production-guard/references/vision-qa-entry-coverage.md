# Vision QA 逐 Entry 覆盖原理

## Vision QA 逐 Entry 覆盖原理

```
SRT Entry 1:  0.0s ─────── 3.76s  → 中点  1.88s → 提取帧 → 亮度验证
SRT Entry 2:  3.76s ─────── 7.52s  → 中点  5.64s → 提取帧 → 亮度验证
...
SRT Entry N:  last ─────── 音频尾  → 中点 → 提取帧 → 亮度验证
末尾静音段:    音频尾 ─────── 音频尾+3s → 末尾干净验证
```

**为什么中点**：Entry持续时间内任意时刻字幕都已渲染，中点=最具代表性时刻。
**为什么末尾静音段单独检查**：字幕结束后视频内容不消失，需验证画面干净无字幕残留。

**⚠️ Vision QA 可靠性陷阱（2026-05-19 教训）：**

| 方法 | 可靠性 | 说明 |
|------|--------|------|
| **像素亮度验证** | ✅ 高 | 提取帧 → 扫描字幕区域高亮像素（RGB>100）→ 有像素=有字幕，可脚本化全量执行 |
| **Vision AI 随机采样** | ❌ 低 | 视觉模型有随机性，3帧采样可能全对但实际7个entry有字幕的只检3个 → 漏检 |
| **Vision AI 全量Entry** | ⚠️ 可用但贵 | 逐Entry送 Vision 比亮度验证慢10倍且答案不稳定，适合文本内容校验，不适合「有没有字幕」的二元判断 |

**教训**：发了QA路径以外的文件 → 用户直接看到bug → MD5追踪缺失的典型后果。

**教训（2026-05-19）**：
- 65s视频末尾20s无音频，3帧抽样法漏检 → 改为逐Entry全量
- 发了QA路径以外的文件 → 用户直接看到bug → MD5追踪缺失的典型后果
- brand-cta-review被跳过 → 脚本走偏 → 65s视频白做
- Vision QA 随机采样3帧全部PASS，但实际字幕有7个entry只检了3个entry → **用像素亮度验证替代随机Vision采样**

**像素亮度验证执行方法（每 Entry 中点帧）：**
```python
import subprocess, re

def pixel_brightness_check(video_path, t_sec, region_px=50):
    """扫描字幕区域是否有高亮像素（>100=有字幕）"""
    # 提取帧 at t_sec
    frame_path = f"/tmp/vqa_{t_sec}.jpg"
    subprocess.run([
        "ffmpeg", "-y", "-ss", str(t_sec), "-i", video_path,
        "-frames:v", "1", "-q:v", "2", frame_path
    ], capture_output=True)
    # 用 PIL 扫描底部 1/6 区域
    from PIL import Image
    img = Image.open(frame_path)
    W, H = img.size
    region = img.crop((0, int(H*5/6), W, H))
    pixels = list(region.getdata())
    bright = sum(1 for r,g,b in pixels if max(r,g,b) > 100)
    return bright > region_px  # >50 bright pixels = 有字幕

# 全量检查（逐Entry）
for entry_t_start, entry_t_end, text in srt_entries:
    mid = (entry_t_start + entry_t_end) / 2
    has_sub = pixel_brightness_check(video_path, mid)
    print(f"t={mid:.2f}s: {'✅' if has_sub else '❌ MISSING'} {text[:20]}")
```

### 🆕 QA7: 图片完整性检查（2026-06-15 新增）

> **触发时机**：封面图/帧图生成后、进入下一生产环节之前。图片损坏或规格缺失会直接导致平台上传失败或视觉体验降级。

**核心原则**：所有生成的图片资产必须（1）符合规格要求（2）文件非损坏。

#### 检查项

| 检查项 | 要求 | 失败后果 |
|--------|------|---------|
| 封面 4 规格齐全 | `cover_16x9.jpg`, `cover_9x16.jpg`, `cover_3x4.jpg`, `cover_1x1.jpg` 全部存在 | → 补缺失规格，Pipeline STOP |
| 最小文件大小 | 每张图片 > 5KB（< 5KB = 损坏/空白图） | → 删除损坏图重新生成 |
| 帧图完整性 | `frame_001.jpg` 至 `frame_N.jpg` 连续无断号 | → 补缺失帧图 |

#### 实施

```python
import os, sys

image_dir = f"{project_dir}/02_images"
cover_dir = f"{image_dir}/cover"
assets_dir = f"{image_dir}/assets"
errors = []

# 检查 1: 封面 4 规格
required_covers = {'cover_16x9.jpg', 'cover_9x16.jpg', 'cover_3x4.jpg', 'cover_1x1.jpg'}
existing_covers = set(os.listdir(cover_dir)) if os.path.isdir(cover_dir) else set()
missing_covers = required_covers - existing_covers
if missing_covers:
    errors.append(f"封面缺失规格: {missing_covers}")

# 检查 2: 每图 > 5KB
for root, dirs, files in os.walk(image_dir):
    for f in files:
        if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp')):
            fp = os.path.join(root, f)
            size_kb = os.path.getsize(fp) / 1024
            if size_kb < 5:
                errors.append(f"图片疑似损坏: {fp} ({size_kb:.1f}KB < 5KB)")

# 检查 3: 帧图连续
if os.path.isdir(assets_dir):
    frames = sorted([f for f in os.listdir(assets_dir) if f.startswith('frame_') and f.lower().endswith('.jpg')])
    if frames:
        # 提取编号
        nums = []
        for f in frames:
            try:
                nums.append(int(f.replace('frame_', '').replace('.jpg', '')))
            except ValueError:
                continue
        if nums:
            expected = list(range(min(nums), max(nums) + 1))
            missing_frames = [f"frame_{i:03d}.jpg" for i in expected if i not in nums]
            if missing_frames:
                errors.append(f"帧图断号: {missing_frames}")

if errors:
    for e in errors:
        print(f"❌ QA7: {e}")
    print("→ Pipeline STOP")
    sys.exit(1)
print("✅ QA7: 图片完整性检查 PASS（封面齐全 | 文件完好 | 帧图连续）")
```

**⚠️ 2026-06-15 注意**：封面图目前已全部迁移至 ComfyUI 本地生成（非旧版 PIL/text-based fallback）。ComfyUI 生图如果出现全黑/全白/尺寸异常，PIL fallback 仍在 `cover-generation-notes.md` 中保留作为兜底方案。5KB 阈值能有效检测全黑/空白 ComfyUI 输出。

#### 反模式

- ❌ **只检查文件名不检查大小**——空白/全黑图同样有文件名，但文件体积极小
- ❌ **只检查封面不检查帧图**——帧图损坏在视频最终输出时才会暴露
- ❌ **允许用户"后期补"**——缺失的规格必须在生成阶段补完，不留给发布环节

> ⚠️ **视频 Track 禁止进 subagent delegation**（2026-05-25 确认）：
> subagent delegation timeout = 600s，但视频 Track（TTS+Whisper+SRT+帧图+烧录）通常超过 600s。
> 2026-05-25 引流款+业务款 subagent 均超时，导致帧图不完整/音频未生成。
> **视频 Track 所有步骤在主 agent 执行**，subagent 只负责文案 Track。
