# #Layer 2: Self-Check 审计协议

### Layer 2: Self-Check 审计协议

**强制规则**：每完成一个 Track（文案/视频/生命周期），立刻调用审计脚本扫描项目，结果发给用户。

**审计脚本检查逻辑**：
```
# 文案 Track 检查项
- 01_content/drafts/ 下 5 平台文件都存在
- 04_review/ 下有 humanizer + copy-review + brand-cta 报告
- 每篇正文 ≥1 次品牌名
- 字数都在标准范围内
- CTA 不含「扫码」和零承诺措辞

# 视频 Track 检查项
- video/VQ/validate_layout.txt 存在
- video/V5/mp3_vs_srt_match.json 存在 + 命中率 ≥ 80%
- TTS 文件存在（mp3）
- SRT 文件存在
- Vision QA 抽样报告存在

# 生命周期检查项
- 封面图 3 种规格存在
- 内文配图按平台最低要求（公众号≥3/知乎≥2/小红书≥1）
- publish_log.json 存在
- 博客 .mdx 存在（引流款跳业务款时）
```

**通过/阻断规则**：
- 任何检查项 ❌ → 阻止进入下一阶段，要求立即补做
- 全部 ✅ → 生成「✅ [Track] 审计通过」消息发给用户
