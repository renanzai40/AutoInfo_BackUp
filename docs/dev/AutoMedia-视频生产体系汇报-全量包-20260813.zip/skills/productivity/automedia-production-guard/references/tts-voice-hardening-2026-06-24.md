# TTS Voice Hardening — 2026-06-24 事故修复

> 本文件记录 2026-06-24 TTS 事故（错误 voice fallback → 音频乱码 → 视频时长骤降）的根因分析 + 三层次修复方案。以后任何 TTS 相关问题以此为起点调查。

## 事故概述

| 项 | 值 |
|---|---|
| 日期 | 2026-06-24 |
| 症状 | 视频 16s（预期 60s），中文 TTS 读出音节碎片（"7500 AI"、"A2023"、"30i"、"i510"） |
| 直接原因 | 使用 `text_to_speech` 工具（Hermes 内置 TTS）生成中文音频，工具返回 `voice_compatible: false` 但被忽略 |
| 根因链 | 错误 tool → 忽略警告 → 无 Whisper 验证 → 渲染通过 → 用户收到 |
| 用户反馈 | 「重大问题，警告，警告警告！！！」 |

## 三层次修复

### 层 1: 脚本硬化 — `tts_produce.py`

**路径**: `~/.hermes/profiles/content/scripts/tts_produce.py`
**职责**: TTS 生产的唯一入口。禁止任何其他工具（`text_to_speech`、`edge-tts` 直调等）

特性:
- edge-tts CLI 直调（不用 hermes 内置 TTS tool）
- 自动 fallback 链: `zh-CN-YunjianNeural → zh-CN-YunxiNeural → zh-CN-XiaoxiaoNeural`
- Whisper tiny 关键词验证: 提取输入文本中的数字、专名、中文词，在 Whisper 转写中匹配
- 命中率 ≥ 30% 才通过，否则 exit 1（Pipeline STOP）
- 输出 `TTS_VOICE=` 和 `TTS_DURATION=` 供下游使用

### 层 2: Tool 级 Guard — `voice_compatible` 拦截

`text_to_speech` 工具返回 `voice_compatible: false` 时:
- 脚本侧: `tts_produce.py` 不使用该工具，不存在此问题
- 万一未来有其他路径调用该工具: 返回 false 时 hermes 侧必须抛出 PipelineError

### 层 3: 内容级 Whisper 验证

`tts_produce.py` 内置 Whisper tiny 验证:
- 提取关键词: `re.findall(r'[\u4e00-\u9fff]{2,}')` + 数字 + 英文词
- 过滤停用词, 取前 8 个关键词
- 匹配率 ≥ 30% → pass; < 30% → exit 1 + 删文件

## 默认 Voice 资产

```
2026-06-24 用户确认: edge-tts zh-CN-YunjianNeural (男声)
Fallback 链:
  1. YunjianNeural (用户默认)
  2. YunxiNeural (男声备选)
  3. XiaoxiaoNeural (女声备选兜底)
```

## 验证方法

```bash
# 正常路径
python3 tts_produce.py --text "文本" --output /tmp/test.mp3
echo $?  # 应为 0

# 空文本失败
python3 tts_produce.py --text "" --output /tmp/test.mp3
echo $?  # 应为 2

# 不可写路径
python3 tts_produce.py --text "a" --output /nonexistent/x.mp3
echo $?  # 应为 1
```

## 关联 Gate

| Gate | 修改 | 文件 |
|---|---|---|
| Gate V4 | fallback 链修正 + `tts_produce.py` 强制路径 | SKILL.md §V4 |
| 执行入口 | TTS 生产段写死为 `tts_produce.py` | SKILL.md §执行入口 |
| 新脚本 | `tts_produce.py` | `scripts/tts_produce.py` |

## 后续改进建议

- V4.5（TTS 输入品牌核验）应合入 `tts_produce.py`（预检查输入文本含"壹目贯维"）
- C3.5（视频脚本结构检查）应合入 `tts_produce.py`（检查输入文本末尾有品牌 CTA 段）
- 所有标注「Pipeline STOP」的 Gate 应考虑逐步迁移到 exit-code 机制
