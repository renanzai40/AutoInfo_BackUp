# AutoMedia 话题池采集系统（from `auto-media-hot-collection`）

## 架构演进

| 版本 | 内容 |
|------|------|
| v1 | 单流（热搜TOP20） |
| v2 | 双流（热搜 + Tavily AI网搜） |
| **v3 (当前)** | **三流（热搜 + Tavily + AIHOT公开API）** |

---

## 三流采集

### 流1：热搜（微博/知乎/抖音）

**API**: uapis.cn
```bash
GET https://uapis.cn/api/v1/misc/hotboard?type=weibo|zhihu|douyin
```
- 返回格式：`{"list": [...]}` 在**顶层**（不是 `data.list`）
- 知乎热值：`"2636 万热度"` → 用 `re.search(r'[\d.]+', hot_str)` 提取

**归一化**: `heat_score = 1.0 - (rank - 1) × 0.067`（rank1=1.0, rank15=0.06）

### 流2：Tavily AI网搜

**搜索**: `tvly search "关键词" --time-range day --max-results 15 --json`
- 必须用 `--time-range day`
- **不要加 `--topic news`**（有bug，报 `topic\n Input should be 'general'`）

**8组关键词**:
1. `AI 大模型 最新进展 新闻` ✅
2. `AI视频生成 行业资讯` ✅✅
3. `AI配音 语音合成 新闻` ✅
4. `AIGC 创作平台 新闻` ⚠️
5. `AI营销内容 工具动态` ⚠️
6. `AI 研究突破 最新资讯`
7. `AI 大模型 行业动态 最新`
8. `AI 大模型 周调用量 最新排名` ✅（去掉了繁体/Instagram噪音）

**注意**: Tavily 流**不经过 MiniMax 分类**，直接标 `category=business`。

### 流3：AIHOT 公开API

**Endpoint**: `GET https://aihot.virxact.com/api/public/items?mode=selected&since=<ISO>&take=20`

**认证**: 无需 token，需 `User-Agent` header。限速 600 req/min/IP。

**Category 映射**:
| AIHOT category | pool.db category |
|---|---|
| `ai-models`, `products`, `industry` | `business` |
| `tip` | `growth` |

**字段**: `id`, `title`, `title_en`, `url`（注意key是`url`不是`source_url`), `source`, `publishedAt`, `summary`, `category`

---

## 两层过滤

### Layer1：域名黑名单（采集时实时拦截）

**表结构**（pool.db）:
```sql
CREATE TABLE blocked_domains (
    domain TEXT PRIMARY KEY,
    reason TEXT,
    added_at TEXT DEFAULT (datetime('now'))
);
```

**当前24条**，最近新增:
- `www.aikuaixun.com`（AI快讯网）
- `news.17173.com`
- `www.aastocks.com`
- `www.china-aii.com`

**拦截时机**: 采集时实时检查，**不进审核层**

### Layer1.5：标题正则黑名单（无URL的spam）

**8条正则**:
```python
TITLE_BLACKLIST = [
    r'AI快讯网',           # 站点名伪装
    r'AI工具导航',         # 站点名伪装
    r'什么值得买',         # 导购spam
    r'\(2026年最新\)',     # 标题党
    r'，\w+技巧$',        # 末尾"技巧"
    r'^如何\w+',          # "如何..."标题党
    r'^AIGC?\w*[资工具导]', # AIGC工具/AIGC资讯类
    r'\| ?AI工具导航',     # "标题 | AI工具导航"格式
]
```

**关键逻辑**:
- 标题命中 **且** 无 `source_url` → 丢弃
- 标题命中 **但有** 有效URL → 保留（来自合法站点的正常文章）

**效果**: 每轮拦截12-15条，MiniMax SEO调用量降低60%

---

## source_url 字段陷阱

| 来源 | URL字段名 | 备注 |
|------|-----------|------|
| Tavily | `source_url` | 始终有 |
| AIHOT | `url` | 可能有，可能无 |

**写入 pool.db 时统一用 `source_url` 字段名**：
```python
item["source_url"] = item.get("source_url") or item.get("url")
```

---

## 快速命令

```bash
# 手动跑采集
cd /mnt/d/Hermes-Workspace/01-Projects/AutoMedia
python3 Scripts/auto_media_hot_collection_v3_20260525.py

# 查看 blocked_domains
sqlite3 Pool/pool.db "SELECT * FROM blocked_domains ORDER BY added_at DESC LIMIT 10;"

# 添加新域名
sqlite3 Pool/pool.db "INSERT OR IGNORE INTO blocked_domains (domain, reason) VALUES ('新域名.com', '原因');"
```

---

## 已知文件

- 采集脚本: `Scripts/auto_media_hot_collection_v3_20260525.py`
- pool.db: `/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db`
