# TTS API 修复记录（2026-05-21）

## TTS 模型名称修正

**错误**: `speech-2.8-hd`（旧版 skill 文档）
**正确**: `speech-02-hd`（2026-05-21 实测有效）

```python
payload = {
    "model": "speech-02-hd",   # 不是 speech-2.8-hd
    "text": script_text,
    "voice_setting": {
        "voice_id": "Chinese (Mandarin)_Radio_Host",
        "speed": 1.0,
        "vol": 1,
        "pitch": 0
    },
    "audio_setting": {
        "sample_rate": 32000,
        "bitrate": 128000,
        "format": "mp3",
        "channel": 1
    },
    "output_format": "url"
}
```

## TTS 日额度耗尽错误

**错误码**: `2056`
**错误信息**: `usage limit exceeded, 5-hour usage limit reached for Token Plan Max (0/0 used), resets at 2026-05-21T15:00:00+08:00`

**含义**: TTS 每日额度在 5 小时窗口内耗尽，需等待刷新（通常是整点）

**处理**: 等待重置后重试，无需修改代码

## 其他已知 TTS 错误

| 错误码 | 错误信息 | 根因 | 解法 |
|--------|---------|------|------|
| `2013` | `invalid params: voice_setting emotion` | `emotion` 不在 `voice_setting` 支持字段内 | 删除 `emotion` 字段 |
| `40001` | `access_token expired` | 微信公众号 token 过期 | 用 `stable_token` 刷新，缓存路径 `~/.hermes/skills/wechat-official-account-publisher/.token_cache.json` |
