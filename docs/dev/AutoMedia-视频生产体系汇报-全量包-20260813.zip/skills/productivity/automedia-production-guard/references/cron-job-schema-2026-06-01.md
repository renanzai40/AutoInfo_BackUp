# Cron Job Schema Discoveries（2026-06-01）

> 本文档记录 2026-06-01 排查 AutoMedia 5 个 cron job 推送失败时发现的 4 个 Hermes cron job schema 陷阱，配套 4 个独立 skill 永久固化。
> 完整修复脚本路径：`~/.hermes/profiles/content/cron/jobs.json`

## 4 个新 Skill（class-level，已固化）

| Skill | 解决什么问题 |
|-------|-------------|
| `cron-deliver-format` | `deliver: "origin"` 在 cron 环境解析失败 → [230001]/[230002]；必须用显式 `feishu:oc_xxx` |
| `cron-repeat-schema` | `repeat: "forever"` 字符串在 `run` action 报 `'str' has no attribute 'get'`；必须改 dict `{"times": null, "completed": 0}` |
| `automedia-m3-upgrade` | MiniMax M2.7→M3 升级时 3 处调用点要同步改 + curl `--max-time 45`→`120` 避免 dedup 超时 |
| `cron-output-redaction` | `print(f"失败: {e}")` 把 `CalledProcessError.cmd` 完整输出含 API key；改用 `print(f"失败 ({type(e).__name__})")` |

加载时机：任何改 `~/.hermes/profiles/content/cron/jobs.json` 之前，先看 `cron-deliver-format` + `cron-repeat-schema`；任何改 `Scripts/auto_media_hot_collection_v3_*.py` 之前看 `automedia-m3-upgrade` + `cron-output-redaction`。

## 1. 错私聊 ID 的来源（"oc_fb8771a1..."）

这个 ID 是 **default profile** 私聊（`renan` 的 default bot DM），不是 content profile。content profile 私聊 = `oc_23809420584b118ca6df5c514067045b`。

`jobs.json` 迁移到 content profile 时 5 个 job 的 `deliver` 字段没改，5 个全有这问题：
- 07:30/08:00/08:30：原 deliver 用了 `oc_fb87...`（default 私聊）+ 群
- 08:05/Watchdog：原 deliver 用了 `origin`（cron 环境解析失败）

**修法**：`oc_fb87...` → `oc_238094...`（content 私聊），并把 `origin` 删掉（`origin` 在 cron 跑的 session 里可能解析成 default 私聊，环境依赖不可靠）。

**所有飞书目标以 `send_message action='list'` 实时输出为准**。不同 profile bot ID 不一样，文档/历史 ID 不可信。

## 2. `cronjob run` 不一定真跑

多次 `cronjob action='run' --job_id <id>` 后观察到：

- `next_run_at` 更新到 ~30 分钟后
- `last_run_at` 不更新（仍是上一次的真跑时间）
- `last_delivery_error` 不更新
- 实际不发生真跑，等下次 cron tick 才会跑

**验证 deliver 是不是真修好的正确做法**：
1. 先 `send_message action='send' --target <id> --message "测试"` 验证 bot 可达（已验证私聊+群都 OK）
2. 等真到 cron 时间（07:30/08:00/08:05/08:30/09:30）跑完看 `last_delivery_error` 是不是 null

不要相信 `cronjob run` 后的 `last_delivery_error` 状态变化。

## 3. Watchdog 自报告（17:56 改 deliver 之前）

```
08:30 推送 ✅ ok（Agent 类，自己 send_message，能拿到 session context）
07:30 推送 ❌ [230001] + [230002]（脚本类，cron 自动推，bot identity 不可达）
08:00 推送 ❌ [230002]（同上）
```

**根因**：
- 脚本类 job（07:30/08:00）跑完 v3 脚本后，hermes cron delivery service 用独立 bot identity 推（无 session context，access token 权限不全）
- Agent 类 job（08:30）跑完自己 `send_message`，用 session 的 .env 拿 token，bot 有效

**修法选项**（2026-06-01 决定 **C：暂不修**）：
- A. 改 07:30/08:00 不用脚本改用 Agent prompt — 大改
- B. v3 脚本末尾加 `send_message` 自己推（用 .env token）— 中改
- C. 不修，watchdog 报告异常，08:30 仍能推 TOP5 — 0 改
- D. 检查 hermes cron delivery 的 token / bot 配置 — 改 hermes

**为什么选 C**：核心价值是 08:30 TOP5 选题推送，**那个是 OK 的**。07:30/08:00 推送是 nice-to-have，失败用户能从 watchdog 报告 + pool.db 看到结果。出错重做才是最大成本，watchdog 是兜底。

## 4. v3 脚本 M3 升级三件套

升级 `MiniMax-M2.7` → `MiniMax-M3` 时**必须同步**改 3 处：

1. **3 个调用点的模型名**（L335/L432/L519 旧位置）
2. **端点**：M3 chat/completions 端点 HTTP 200，**不需要 GROUP_ID**（TTS 才要 GroupId）
3. **curl --max-time**：M3 生成更长，原来 `--max-time 45` 不够。改 `--max-time 120`：
   - L359 SEO 描述生成
   - L457 Layer 2 相关性
   - L540 dedup 去重

**为什么 120 秒够**：
- 08:00 跑 → 08:05 跑间隔 5 分钟 > 4.5 分钟最长耗时，at-most-once 保证不丢
- 07:30/08:30/09:30 间隔 30+ 分钟，绝对安全

## 5. API key 暴露的隐蔽路径

`v3_20260525.py` L580 用了 `print(f"失败: {e}")`：

```python
except subprocess.CalledProcessError as e:
    print(f"失败: {e}")  # ← e.cmd 含完整 curl 命令含 -H "Authorization: Bearer sk-..."
```

`CalledProcessError.__str__` 会输出 `cmd: <完整cmd> returncode: <N> output: <output>`，**curl 的 Authorization header 直接进 output 文件**。

**2026-06-01 已发现 1 个 output 文件被污染**：
- `~/.hermes/profiles/content/cron/output/143d19e69a7c/2026-06-01_17-31-41.md`
- 修复：sed mask + 备份原文件 + 改 v3 脚本 3 处 print 模板

**预防**：写 cron 脚本的 `try/except` 时**只用异常类型/returncode**，不打印 e 本身。详见 `cron-output-redaction` skill。

## 6. v3 脚本路径问题（cron 不允许 scripts/ 外）

Hermes cron `_validate_cron_script_path` 不允许 `scripts/` 外的路径，**symlink 会被拦**（realpath 逃出 scripts/）。

**修法**：把脚本**复制**到 `~/.hermes/profiles/<profile>/scripts/` 下，不要用 symlink。

```bash
cp <原始路径> ~/.hermes/profiles/content/scripts/
```

## 验证清单

每次改 `jobs.json` 后必跑：
- [ ] `cronjob action='list'` 不报 `'str' object has no attribute 'get'`
- [ ] 5 个 job 的 `deliver` 字段都显式（无 `origin`）
- [ ] 5 个 job 的 `repeat` 字段都是 dict
- [ ] 私聊 `send_message action='send'` 收到
- [ ] 群 `send_message action='send'` 收到
- [ ] 备份存在（`cp jobs.json jobs.json.bak.<timestamp>_<what-fix>`）
