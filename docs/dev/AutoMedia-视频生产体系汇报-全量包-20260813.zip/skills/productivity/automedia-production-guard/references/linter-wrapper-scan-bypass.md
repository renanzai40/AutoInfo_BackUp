# ⚠️ linter wrapper 全 src/ 扫老的 Composition 触发 FAIL 的绕过方法（2026-06-03 实测）

## ⚠️ linter wrapper 全 src/ 扫老的 Composition 触发 FAIL 的绕过方法（2026-06-03 实测）

**症状**：`bash scripts/render_with_qa.sh <ID> out/<file>.mp4` 第 1 步 linter FAIL，输出：
```
❌ BLOCK_render: 5 file(s) 违反 A/V 同步铁律
📄 /home/renanzai/Remotion-Test/src/WentechComposition.tsx
  ---- | R2-missing-srtTimeToFrame-import
📄 /home/renanzai/Remotion-Test/src/SixOneEightComposition.tsx
  ---- | R2-missing-srtTimeToFrame-import
... (5 个老 Composition 全部 FAIL)
```

**根因**：`render_with_qa.sh` 第 1 步 linter 扫**整个 src/ 目录**，不只扫新 Composition。已交付老 Composition（Wentech/SixOneEight/Composition.tsx/TrapDoor 等）当年没用 srtTimeToFrame 模式——按"★ 已交付项目不改进铁律"**不能改它们**，但 wrapper 仍会 FAIL。

**绕过方法**（2026-06-13 更新：以下为 Remotion 旧红线，已归档。HyperFrames 新红线见 `video-production/hyperframes-workflow` 的 Gate 链）：

```bash
# ⚠ Remotion 已归档，详见 video-production/hyperframes-workflow
# HyperFrames 红线：
# bun x hyperframes lint → 通过后
# bun x hyperframes render --quality standard → 输出 MP4
```

**关键决策记录**：
- **不能改**老 Composition（按铁律）
- **不能跳过**新 Composition 的 linter（会失去 R1 拦截硬编码的能力）
- **可以**绕开 wrapper（第 2 步直接 npx render，因为单文件 linter 已 PASS 证明新 Composition 本身合规）
- **必须**保留所有 wrapper 的 QA 能力（linter + 像素验证 + Whisper），只是不通过 wrapper 串联

**wrapper 设计改进建议**（待 P1 修复）：`LINT_TARGET_FILE` 环境变量支持单文件 lint，避免扫整个 src/：
```bash
LINT_TARGET_FILE=src/NewComposition.tsx bash scripts/render_with_qa.sh NewComposition out/file.mp4
```

---
