# TTS 输入纯净度 + SRT 精确时间戳（2026-06-12 实战教训）

## 问题 1：TTS 输入含段标题

**症状**（2026-06-12 user 反馈"重大失误"）：音频里念出了「开场钩子」「痛点问题」等段标题。

**根因**：tiktok/script.txt 脚本文件包含 5 段式标记：
```
【开场钩子】Google 的 Gemini 模型...
【痛点问题】但这跟普通创作者有什么关系？
```
直接 `edge-tts --text "$(cat script.txt)"` 把标记也喂进去了。

**修复**：TTS 前剥离段标题，只保留口播文本：
```bash
# 错误
edge-tts --voice zh-CN-YunxiNeural --text "$(cat script.txt)" --write-media out.mp3

# 正确：提取纯净口播文本
CLEAN=$(sed 's/^【.*】//' script.txt | tr '\n' ' ')
edge-tts --voice zh-CN-YunxiNeural --text "$CLEAN" --write-media out.mp3
```

**预防**：在 `01_content/script_final.txt` 中额外保存一份纯净版（仅口播，无标记），TTS 只用纯净版。

## 问题 2：SRT 时间分配不能基于字数比例

**症状**：字幕与语音不同步 — 因为 SRT 时间线是用「每段文字字数占总字数的比例 × 音频总时长」算的，但实际朗读速度不均匀（开头慢、高潮快、结尾有停顿）。

**根因**：
```python
# ❌ 错误：按字数比例分配时间（2026-06-12 踩坑）
ratio = len(segment_text) / total_text_length
duration = ratio * total_audio_duration  # 实际语音节奏 ≠ 字数比例
```

**修复步骤**：
1. edge-tts 生成 mp3
2. Whisper medium 模型转写，获取 word-level 时间戳
3. 用 Whisper 输出的 `segments[].start` / `segments[].end` 作为 SRT 时间
4. 按 5 段式结构将 Whisper entries 分组，映射到 scene-data.ts 的 subtitles

```python
import whisper
model = whisper.load_model('medium', device='cpu')
result = model.transcribe('audio.mp3', language='zh', fp16=False)
# result.segments 包含每句的精确 start/end 时间
for seg in result['segments']:
    # seg['start'], seg['end'] — 精确到毫秒级
    # 用这些时间戳构建 SRT，而不是按字数计算
```

**Why medium not tiny**：medium 模型的中文识别率远高于 tiny（30-40% 误识别率 → <10%），且在 GTX 1660 Ti 上 50s 音频只需 ~50s 转写时间。

## 补充：Whisper 转写文本修正

Whisper 对中文品牌名「壹目贯维」存在误识别（「一目貫為」「一目贯为」等），SRT 和 scene-data 的 subtitle 文本必须用原始脚本文字覆盖，不可直接使用 Whisper 输出的 ASR 文本。
