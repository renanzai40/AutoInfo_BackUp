# #已知绕过路径

### 已知绕过路径

| 绕过 | 难度 | 可见性 | 推荐修复 |
|------|------|--------|---------|
| 直接调 `bun` 绕过 terminal hook | 中（需写 Python subprocess） | 低（audit 仍可检） | 层3 audit |
| 删/改 config.yaml 中的 hooks 行 | 低（需改文件） | 高（你在飞书看到 config 变更） | 不可自动修复，靠流程 |
| `touch .gates_status.json` 伪造签入 | 低 | 中（audit 交叉验证产物存在性） | 层3 audit 查实际产物 |
| 不列 TODO 直接开工 | 低 | 高（你问"列了吗"） | 流程约束 |

---
