# ⚠️ Backup-First 铁律（2026-06-02 用户明确要求固化）

## ⚠️ Backup-First 铁律（2026-06-02 用户明确要求固化）
> **任何对工作流 / 脚本 / Gate / Hook / Skill / 配置文件 / Composition 源码 / 数据库的修改之前，先备份再动手。**
> 不备份就改 = 工艺失误，即使改动正确也属风险作业。

**触发场景**（任意一条即触发）：

- 改 `~/.hermes/profiles/*/cron/jobs.json` / `config.yaml` / `auth.json`
- 改 skill 的 `SKILL.md` / `references/*.md` / `scripts/*.py` / `templates/*.tsx`
- 改 Remotion `src/*.tsx`（Composition 源码）
- 改 Remotion `scripts/render_with_qa.sh`（hook 脚本）
- 改 `~/.hermes/cron/wdog_alert.json` / `pool.db` / `publish_log.json`
- 改 AutoMedia 项目目录结构（`mv` 顶层项目到 `archive/`）
- 改任何 `gate_*` / `*_check*.py` 脚本

**备份目录规范**：

```
/tmp/audit_backup_<YYYYMMDD>_task<A字母>/

例：
/tmp/audit_backup_20260602_taskA/render_with_qa.sh.bak
/tmp/audit_backup_20260602_taskD/m3_publish_log.json.bak
/tmp/audit_backup_20260602_taskF/LoraiComposition.tsx.bak
```

**备份命名**（用 cp -r / cp 单文件 + 后缀）：

- 配置文件 / 单文件 → `<原文件名>.bak`
- 含 mtime 信息 → `<原文件名>.bak.<date +%Y%m%d_%H%M%S>`
- 目录整体 → `cp -r <原目录> <备份目录>/<同名目录>/`

**写入备份记录**（可选但推荐）：

```bash
echo "task X 备份: $src → $dst" >> /tmp/audit_backup_<date>_taskX/backup_log.txt
```

**恢复方式**（如果改错了）：

```bash
cp /tmp/audit_backup_<date>_task<X>/<file>.bak <原路径>
# 或目录
rm -rf <错误目录> && cp -r /tmp/audit_backup_<date>_task<X>/<原目录> <原路径>
```

**例外**（不需要备份的"修改"）：

- 改 `/tmp/` 下的临时文件
- 改 session 内的中间产物（不持久化）
- rename 文件（`mv`）—— 文件保留，只是名字变
- 删除 out/ 中已搬走的内容（前提：archive/ 已有完整副本 + 备份记录）

**配套的"双保险"模式**（高风险操作推荐）：

1. `cp` 到 `/tmp/audit_backup_...`（安全网）
2. 再 `cp` 到 archive/（workspace 整理）
3. 操作前先验证两个副本都在

**实际案例（2026-06-02 8 任务批量）**：

- A 任务：备份 `render_with_qa.sh` → `taskA/`
- C 任务：备份 wdog 告警内容 → `taskC/wdog_alert.json.original.bak`
- D 任务：备份 2 个 `publish_log.json` → `taskD/`
- E 任务：备份 2 个项目目录到 `taskE/projects_before_archive/`
- F 任务：备份 4 个 Composition `.tsx` → `taskF/*.tsx.bak`
- G 任务：备份 `remotion-workflow/SKILL.md` → `taskG/SKILL.md.bak`
- H 任务：记录 `move_log.txt`（不 cp，只记 mv 路径）

**为什么这条铁律重要**：

- 用户 2026-06-02 明确说"涉及到工作流、脚本、gate\hook等改动时，先备份再做"
- 这是**风险厌恶型工作风格**的体现（用户对不可逆操作的容忍度低）
- **违反** = 即使改动正确，用户也会质疑"为什么没有备份？"
