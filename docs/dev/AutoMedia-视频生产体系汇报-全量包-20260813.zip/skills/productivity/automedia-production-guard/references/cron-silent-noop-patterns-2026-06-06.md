# Cron 静默 No-Op 模式（2026-06-06 follow-up：3 个 m3 脚本本身的 fix）

> **本文件是 `references/cron-silent-noop-patterns.md` 的 2026-06-06 follow-up**。
> 主文件已涵盖 4 大类反模式（last_status 不可信 / scheduler script 字段是纯路径 / session_lock 参数错配 / depends_on + exit 1 = 下游 skip）+ Pre-flight Gate 4 步升级。
> **本文件新增**：2026-06-06 发现的 3 个 m3 任务**核心脚本本身**的 bug（不在 jobs.json / wrapper 层面），及对应单行 fix。

## 3 个 m3 脚本 bug（2026-06-06 实测，全部 `last_status=ok` 但业务 0 价值）

### Bug 5：`judge_topics_angle.py` `--source` 默认值静默过滤中文平台

- **症状**：3 个 m3 cron 任务（8:10/12:00/16:00）跑了 6+ 天，每天 last_status=ok，**但从未处理任何中文平台话题**（微博/知乎/抖音 159 条 approved+NULL 永久 NULL）
- **根因**：
  ```python
  # 旧默认值（before 2026-06-06）
  parser.add_argument("--source", default="Tavily,AIHOT", help="...")
  ```
  + SQL 硬过滤：`WHERE source IN ('Tavily', 'AIHOT')` → 全部 159 条 approved+NULL（都是中文平台）被 WHERE 过滤掉
- **修法（双层防御）**：
  1. **改 m3 脚本默认值**（手动跑也覆盖全 source）：
     ```python
     # L205
     parser.add_argument("--source", default="微博,知乎,抖音,Tavily,AIHOT", help="优先级 source 列表（逗号分隔）")
     ```
  2. **改 wrapper `judge_angles_cron.sh` 显式传**（cron 跑不依赖脚本默认值）：
     ```bash
     # ~/.hermes/profiles/content/scripts/judge_angles_cron.sh
     exec /home/renanzai/.hermes/hermes-agent/venv/bin/python3 \
         /home/renanzai/.hermes/profiles/content/scripts/judge_topics_angle.py \
         --limit 200 \
         --source 微博,知乎,抖音,Tavily,AIHOT   # ← 显式传
     ```
- **验证**：手动跑 159 条 → NULL 数 0 / 角度分进库 159 条
- **预防**：
  - **任何 cron 跑的脚本**默认 `--source` / `--limit` / `--min-corr` 等过滤参数**必为全开**（cron 跑就是生产路径，不该被人工调整）
  - **wrapper bash 脚本显式传**所有影响行为的参数（不依赖被调脚本默认值）

### Bug 6：`judge_topics_angle.py` L355 `sys.exit(0 if stats["fail"] == 0 else 1)`

- **症状**：m3 任务跑 67 分钟，145 ok + 7 fail（m3 API 偶发 JSON parse fail）→ exit 1 → cron 标 `last_status=error` → depends_on 链 → 8:30 推送 skip
- **根因**：把"fail > 0"等同"任务失败"——但长跑批量 LLM 任务偶发 fail 是正常
- **真正的任务失败定义**：`ok == 0`（一个都没成功）或 DB delta 持续 0
- **修法（单行）**：
  ```python
  # L355（2026-06-06 修复）
  sys.exit(0 if stats["ok"] > 0 else 1)
  # 或更激进：永不失败（详情在 stats 报告里）
  sys.exit(0)
  ```
- **预防规则（写任何批量处理脚本通用）**：
  ```python
  # 3 种状态 → 3 种 exit code
  if stats["ok"] == 0:           # 完全失败
      sys.exit(1)                # 让 cron 报
  elif stats["fail"] > 0:        # 部分成功
      sys.exit(0)                # 详情在 stats/log
  else:                          # 完全成功
      sys.exit(0)
  ```

### Bug 7：`judge_angles_cron.sh` wrapper 不显式传 `--source`

- **症状**：依赖 `judge_topics_angle.py` 默认值 → 与 Bug 5 同根
- **修法**：见 Bug 5 第二条（wrapper 显式传所有参数）
- **预防（永久规则）**：
  - ✅ wrapper 必显式传**所有**影响行为的参数（`--source` / `--min-corr` / `--dry-run` / `--limit`）
  - ❌ 永远不写 `exec python judge_xxx.py` 不带参数（依赖默认值）
  - ❌ 永远不写 `exec python judge_xxx.py $@` 透传 CLI（cron scheduler 不支持）
  - wrapper 注释必写明"防御 X 脚本默认值被改坏"

## 核心教训

1. **last_status 不可信**（见主文件陷阱 17）——4 步验证必查 db delta
2. **m3 脚本默认值要全开**（影响行为的过滤参数不要默认窄值）
3. **wrapper 显式传所有参数**（cron 跑是生产路径，不依赖默认值）
4. **批量任务 exit code 设计要"有数据就算成功"**（不全 0 失败 = 部分成功 = exit 0）
5. **bash `output=$()` 静默截断**（见主文件陷阱 19）——长跑脚本必用 `tee` 写盘 + `grep` 文件

## 与主文件的关系

| 主题 | 主文件 | 本文件 |
|------|--------|--------|
| 4 大类反模式（last_status / scheduler / session_lock / depends_on）| ✅ 主文件 | 不重复 |
| Pre-flight Gate 4 步升级 | ✅ 主文件 | 不重复 |
| 4 步诊断手册 | ✅ 主文件 | 不重复 |
| m3 脚本本身 3 个 bug（source 默认 / sys.exit / wrapper --source）| ❌ 没 | ✅ 本文件 |
| m3 实测耗时基线（8-15 分钟）| ❌ 没 | 引用主文件陷阱 14 |
| cron 静默坑 4 大类总览 | ✅ 主文件 | 不重复 |

**触发加载**：
- 主文件：任何 cron 任务异常 / 静默坑排查
- 本文件：修改 `judge_topics_angle.py` 或 `judge_angles_cron.sh` 时 / 排查 m3 任务行为
