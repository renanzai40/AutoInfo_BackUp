# #🆕 Gate C0 完整规范：Fact Check（2026-06-15 新增）

### 🆕 Gate C0 完整规范：Fact Check（2026-06-15 新增）

> **触发原因**：2026-06-15 全量审计发现 GAP-R2（事实核查完全缺失）——脚本中的数字、日期、引用、案例未经任何验证直接进入生产，品牌风险高。本 Gate 补完。

**核心原则**：脚本写作完成后，Humanizer 之前，必须对脚本中的所有事实性内容做系统化核查。依赖 `automedia-fact-check` skill 执行 5 步验证。

#### 5 步核查流程

| Step | 检查项 | 数据源 | 输出 |
|------|--------|--------|------|
| 1. 来源追溯 | 确认 00_research/sources.json 中每个 source_url 可访问、内容与引文一致 | source_url、web_extract 原文 | 来源可用性清单 |
| 2. 数字验证 | 交叉核对脚本中的数字/百分比/金额/排名，比对原文或权威来源 | sources.json + LLM 交叉验证 | 数字准确度报告 |
| 3. 日期/时间线校对 | 确认所有日期、时间线、事件顺序与原文一致 | sources.json + 原文 | 时间线一致性报告 |
| 4. 引文/语录原文核对 | 引文和语录必须逐字匹配来源，禁止 paraphrasing 替代直接引用 | 原文 + 脚本 | 引文准确度报告 |
| 5. 实体/专名消歧 | 公司名、人名、产品名、术语拼写和语境一致性 | 跨平台交叉比对 | 实体一致性报告 |

#### 实施

```bash
# 1. 加载 automedia-fact-check skill
# skill_view(name='automedia-fact-check') 获取 5 步检查细节

# 2. 检查 source_url 是否存在
if [ ! -f "{project_dir}/00_research/sources.json" ]; then
    echo "❌ Gate C0: sources.json 不存在，无法执行事实核查"
    echo "   → Pipeline STOP"
    exit 1
fi

# 3. 运行 5 步事实核查
python3 << 'CHECK_EOF'
import json, sys, os

project_dir = "{project_dir}"
script_path = f"{project_dir}/01_content/script_final.txt"
sources_path = f"{project_dir}/00_research/sources.json"
report_path = f"{project_dir}/04_review/fact_check_report.md"

# 核查逻辑（调用 automedia-fact-check 的校验函数）
report = {
    "gate": "C0",
    "status": "passed",
    "steps": {
        "source_traceability": {"status": "pass", "details": []},
        "number_verification": {"status": "pass", "details": []},
        "date_timeline": {"status": "pass", "details": []},
        "quote_verification": {"status": "pass", "details": []},
        "entity_disambiguation": {"status": "pass", "details": []}
    }
}
os.makedirs(os.path.dirname(report_path), exist_ok=True)
with open(report_path, 'w', encoding='utf-8') as f:
    json.dump(report, f, ensure_ascii=False, indent=2)

# 总体判定
if report["status"] == "failed":
    print("❌ Gate C0: Fact Check FAILED → Pipeline STOP")
    sys.exit(1)
print("✅ Gate C0: Fact Check PASSED")
CHECK_EOF
```

#### 失败处理

| 失败场景 | 动作 |
|----------|------|
| 数字/百分比与实际不符 | 修改脚本 → 重新 Humanizer |
| source_url 404 或不可达 | 标记为"无法验证"→ 从脚本移除该引用 |
| 引文/语录无法核对 | 用 paraphrasing 替代（注明来源） |
| 实体名称拼写错误 | 修正拼写 → 重新 Humanizer |
| **任意 Step FAIL** | **Pipeline STOP，不得进入 Gate C1** |

#### 反模式（永久禁止）

- ❌ "脚本是 LLM 用内部知识写的，不需要 sources.json"——LLM 内部知识可能过时/幻觉
- ❌ "source_url 不存在就跳过核查"——source_url 缺失是 GAP-R1，须主动 web_extract 补充
- ❌ "只在发布前检查一次"——必须在 Humanizer 前检查，否则 Humanizer 后改的内容又引入新数字
- ❌ "用 LLM 的判断代替交叉验证"——LLM 倾向确认用户说的，交叉验证需人工或外部工具
