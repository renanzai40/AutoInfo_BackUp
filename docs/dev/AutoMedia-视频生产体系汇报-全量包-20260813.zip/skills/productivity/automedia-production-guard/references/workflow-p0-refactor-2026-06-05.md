# Workflow P0 大改造记录（2026-06-05 user 拍板）

> **触发事件**：2026-06-05 user 反馈"你发我的视频不太对吧，有一个是昨天的视频，而不是今天这两个项目的视频"——诊断发现 6-05 当天 2 个视频（Alphabet 800亿引流款 + OpenAI Codex 业务款）被另一个 session（113223）套了 6-04 v10 视频的视觉框架，**subtitle.srt 完全缺失**，**多 session 并行抢活**。
>
> **根因**：6-04 抽组件时漏写"复用边界"、6-02 m3 案例后只加 `timecode-bound-to-srt` Gate 没加 SRT 缺失门控、6-05 我（当前 session）问"要不要启动 Pre-production"反而触发多 session 抢活。
>
> **user 决策**：A. 全部 5 项 P0 立刻做 + 然后重做今天的视频（4+1.5 小时）。

## 5 项 P0 改造（user 拍板）

### P0-1: Selection Reuse Decision Gate（patch 进 automedia skill）

**触发问题**：6-04 抽组件时没写"复用边界"——6-05 session 113223 看到 v10 组件就"全自动套"到完全不同话题的视觉。

**改造**：
- 4 维相似度判断：话题类型（30%）+ 5 段叙事结构（30%）+ 视觉表达（25%）+ 桥接方向（15%）
- 总分 ≥ 70 + 任一维"完全不同" → 强制 brand_new
- 任何 1 维"完全不同" → 强制 brand_new（无需总分）
- 输出 `00_project_info.json.reuse_decision = {"decision": "reuse|brand_new", "scores": {...}, "rationale": "..."}`

**6-05 实战决策（Alphabet 800亿 + OpenAI Codex vs 6-04 Runway Aleph 2.0）**：
- 话题类型：70%（都是 AI 行业）
- 5 段叙事：80%（都是 5 段）
- 视觉表达：**20%**（今天纯 DATA 融资数字 vs 6-04 DATA+SCENE 数据+美容）**← 完全不同**
- 桥接方向：80%
- 加权：30×70+30×80+25×20+15×80 = 62 < 70 → **强制 brand_new**
- 视觉象限 1 维"完全不同" → **强制 brand_new**（P0-1 触发条件）

### P0-2: Reuse Boundary Checklist（patch 进 remotion-workflow skill）

**触发问题**：6-04 抽组件时漏写"哪些可复用、哪些必须重做"边界。

**改造**：
- ✅ 可复用 100%：通用组件 / 5 段骨架 / timecode 工具 / linter
- ❌ 必须重做 100%：每段视觉内容 / 5 段叙事结构 / S1 钩子视觉 / SRT 文本 / TTS 音色参数
- ⚠️ 段边界重算（m3 案例）：从 SRT 真实时间戳读取，不硬编码

**6-05 实战（codex 5s 帧"护肤品"）**：session 113223 套 v10 视觉 → 5s 帧含"护肤品/化妆品"（v10 美容 SCENE 视觉残留）→ P0-2 强制按今天话题重做所有视觉。

### P0-3: SRT 缺失门控（patch 进 remotion-pre-render-gate skill）

**触发问题**：6-05 codex 视频 `03_video/` 目录有 audio_voiceover.mp3 但**没有 subtitle.srt**——Remotion 渲染跑通但 SRT 字幕从未烧进视频。

**改造**：加第 4 Gate `srt-must-exist`（BLOCK_render）：
1. SRT 文件必须存在
2. 文件大小 > 200B
3. SRT entry 数 ≥ 5
4. 最后一 entry 的 end_time 与 TTS 音频时长差 < 1.5s
5. 关键词密度：SRT 文本必须含今天话题的至少 3 个关键词

**配套脚本**：`remotion-pre-render-gate/scripts/check_srt_must_exist.py`（待创建）

### P0-4: Multi-session Lock（cron + session_lock.py）

**触发问题**：飞书私聊同一 message 触发了 2-3 个 session 并行抢活（session 103322 + session 113223 + 14:00 第三次渲染）。

**改造**：
- 新建脚本 `~/.hermes/profiles/content/scripts/session_lock.py`（fcntl.flock 跨进程互斥）
- patch cron 8:30 prompt（job `7671da210b69`）加强制首步抢锁
- 抢锁失败 → 静默退出（不重复推送）
- cron prompt 第七步"Pre-production 启动"前也抢锁

**session_lock.py 关键设计**：
```python
# 参数：--name（锁名）--hold（持锁时长，0=默认 60s）--wait-timeout（抢不到锁时重试，默认 5s）
python3 session_lock.py --name auto_media_top3_push --hold 60
```

**踩坑（永久固化）**：
- ❌ `--timeout` 命名易混淆（最初被理解为"等待"实际"持锁"）→ 已重命名为 `--hold`
- ❌ `sys.exit(0)` 立刻退出导致持锁 0 秒（其他进程自然能抢到）→ 改成 `time.sleep(hold_sec)`
- ❌ `--hold 5` 被错误解读为"等 5s 抢锁" → 已加 `--wait-timeout` 区分

**5 个 smoke test 全 PASS**（2026-06-05 验证）：
- [Test 1] check-only 无锁 → exit 0
- [Test 2] --hold 3 持锁 3s → 实际耗时 3.0s
- [Test 3] 锁被占时前台抢锁 → "⚠️ 抢不到 lock（其他 session 已在跑），静默退出"
- [Test 4] 锁释放后能再抢
- [Test 5] check-only 锁存在 → exit 1（看穿锁状态）

### P0-5: V3 Content Semantic Match（patch 进 automedia-production-guard skill）

**触发问题**：现有 V1/V2 Gate 只检查"有没有字幕"、"Whisper 转写关键词"——**没要求含今天话题关键词**。6-05 codex 视频 5s 帧"护肤品" + alphabet 视频 5s 帧 v10 片尾 CTA 都没被 V1/V2 拦下。

**改造**：加 Gate V3（BLOCK_send）：
1. 从 pool.db 动态提取今天话题关键词清单（5-10 个：专有名词/数字/核心动词）
2. 3 源比对：SRT 文本 + Whisper 转写 + 5 段视觉 OCR
3. 命中率 ≥ 80% 关键词必须出现在 ≥ 2 源中
4. 阈值 < 80% → BLOCK_send

**6-05 实战**：codex 视频 0 关键词命中（V3 必拦） + alphabet 视频视觉无关键词（V3 必拦）。

## 重做决策树（user 拍板后立刻开干）

### A. P0-1 决策跑法（4 维相似度）

对今天 2 个话题 vs 6-04 最近已交付项目：
- 4 维加权平均 < 70 → brand_new
- 任一维"完全不同" → brand_new（无需看总分）
- 否则 reuse（仍需按 P0-2 重做视觉内容）

### B. 8 步重做流程（每个视频串行做，避免多 session 抢活）

1. 写 brand new 5 段脚本（~150 字口播，5 关键词分布）
2. TTS 生成（含今天话题关键词）
3. SRT 生成（13 entry，brand new 内容）
4. 5 段 frame 生图（brand new 视觉，零 v10 元素）
5. 写 brand new Composition（不套 v10）
6. 渲染（用 render_with_qa.sh wrapper）
7. 5 Gate 验证（V0/V1/V2/**V3** + L1）
8. 发飞书（私聊 + 打包）

### C. 关键门控（按新 P0）

- P0-3 srt-must-exist：渲染前 SRT 必须存在
- P0-5 V3 content semantic match：SRT/Whisper/视觉 3 源 ≥80% 含今天关键词
- P0-2 Reuse Boundary：5 段视觉 100% 重做，零 v10 视觉残留

## 反模式（永久禁止）

- ❌ 看到 NSegmentSkeleton 就默认"可复用视觉"——错，骨架可复用，**视觉内容必重做**
- ❌ "这个视觉今天也适用"= 复用——错，按 4 维分数判断
- ❌ "我看着像"= 可复用——错，按 P0-1 + P0-2 决策
- ❌ 跳过 P0-3 渲染前 SRT 门控——会放过"没字幕的 mp4"
- ❌ 跳过 P0-5 V3 语义级 Verify——会放过"内容错位"的视频
- ❌ 不抢 session_lock 就跑 Pre-production——多 session 抢活
- ❌ 改 v10/v10.1 源码适配今天话题（违反"已交付不改进"铁律），**写新 Composition**
- ❌ 重做视频套 v10 视觉（违反 P0-2）

## 责任认领（自审）

- **6-04 我（自己）抽 v10 组件时漏写"复用边界"** → P0-2 设立
- **6-02 我（自己）m3 案例后只加 timecode-bound-to-srt Gate** → P0-3 设立
- **6-05 我（当前 session）问"要不要启动 Pre-production"**反而触发多 session → P0-4 设立

3 个责任都是 agent 端失误，**不是工具/环境问题**——是工作流设计缺失。

## 相关 skill 改动（备份位置）

- `automedia/SKILL.md`：+2959 bytes (3.9%) — 加 Selection Reuse Decision Gate
- `remotion-workflow/SKILL.md`：+3660 bytes (7.0%) — 加 Reuse Boundary Checklist
- `remotion-pre-render-gate/SKILL.md`：+2079 bytes (47.5%) — 加 srt-must-exist Gate
- `automedia-production-guard/SKILL.md`：+6066 bytes (8.8%) — 加 Gate V3
- `cron jobs.json`：+1463 chars 8:30 prompt — 加 session_lock 强制首步
- `~/.hermes/profiles/content/scripts/session_lock.py`：4608 bytes 新建

**备份位置**：`/tmp/audit_backup_20260605_workflow_p0_refactor/`

## 实战案例：6-05 引流款 brand_new 5 段脚本设计

| 段 | 内容 | 关键词 |
|---|------|--------|
| S1 钩子 | "AI 行业八月的头条，全被一笔融资和一份招股书抢走了。" | AI/行业/融资/招股书 |
| S2 痛点/背景 | "Alphabet 拟融资 800 亿美元，Anthropic 同步提交 IPO 申请——两笔交易合计规模超过千亿。" | **Alphabet/800亿/Anthropic/IPO/千亿** |
| S3 干货 | "Alphabet 现金储备超 950 亿，Anthropic 估值半年翻 4 倍。机构为什么突然重仓 AI？" | **Alphabet/950亿/Anthropic/AI** |
| S4 高潮/桥接 | "因为算力即内容产能——AI 内容生产赛道进入军备竞赛阶段。" | **算力/AI 内容生产/军备竞赛** |
| S5 CTA | "关注壹目贯维，AI 内容生产公司——帮你实时追踪 AI 行业热点，生成多平台内容。" | **壹目贯维/AI 内容生产/追踪/生成/多平台** |

**关键词总覆盖**：Alphabet × 2, Anthropic × 2, 800亿 × 1, IPO × 1, AI × 4, 内容生产 × 2, 算力 × 1 = **5 关键词** 100% 覆盖 P0-5 V3 阈值。

**视觉方案（brand_new，零 v10）**：
- S1：深蓝 + "800亿" 巨型数字 + "Alphabet" 标签
- S2：双柱状图（Alphabet vs Anthropic 估值）+ "1000亿+"
- S3：时间线（6 个月 4× 翻倍曲线）
- S4：算力→内容产能 流程图（3 个方块）
- S5：纯代码 InkRevealLogo + "壹目贯维" + "AI 内容生产公司"

## 触发条件（future session 用）

**任何时候出现以下信号，立即加载本 references**：
- user 反馈"视频质量离谱"/"视频是昨天的"
- session 套 v10/v9 视觉到不同话题
- cron 多 session 并行抢活
- Pre-production 启动前
- 6 项生产 Gate 跑失败
- 选完话题后、开始生产前（必跑 P0-1）
