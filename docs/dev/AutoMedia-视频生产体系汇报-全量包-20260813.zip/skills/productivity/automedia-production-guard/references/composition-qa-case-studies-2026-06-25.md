# Composition QA Case Studies — 2026-06-25

Three concrete bugs found in one production session, each driving a V6 Gate rule.

## Case 1: Duplicate `class=` → Styles silently ignored

**Bug**: Element had `class="clip"` on line N, then `class="body-text"` on line N+1 (same element, two HTML `class` attributes).

```html
<!-- ❌ 两个 class 属性，第二个被浏览器忽略 -->
<div id="s1-sub" class="clip" data-start="3.5" data-duration="6.6"
     class="body-text" style="...">
```

**Effect**: The `.body-text { font-size: 36px }` class never applied. Browser used the first `class="clip"` only. Text rendered at default ~16px. User: "太小了".

**Scope**: 18 instances across 2 video compositions (7 in Confucius4-TTS, 11 in OpenAI IPO).

**Root cause**: Subagent was writing `class="clip"` inline (required by HyperFrames for clip detection) and then adding styling classes as a separate `class` attribute. HTML parsers ignore duplicate attributes — only the first is used.

**Fix**: Merge into single attribute → `class="clip body-text"`.

**Gate rule**: V6-4 — scan for any tag with two+ `class=` attributes. Also check `id=` and `style=` duplicates.

---

## Case 2: CSS `=` instead of `:` → Element at top of screen

**Bug**: `style="position:absolute;top=660px;left:80px;width:920px;"` — `top=660px` instead of `top:660px`.

```html
<div id="s3-card2" class="clip card" style="position:absolute;top=660px;left:80px;width:920px;">
  🌍 14 语种 · 无口音  ← 渲染在屏幕最顶端
```

**Effect**: CSS `=` is a syntax error — the `top` declaration is dropped. `position:absolute` falls back to `top: auto` → element renders at `top: 0` (top of viewport). User: "离视频最上边的距离几乎为0了".

**Root cause**: Subagent confused CSS syntax with JavaScript object syntax (`{top: 660px}` vs `top: 660px`).

**Fix**: Replace `=` with `:` in all style values.

**Gate rule**: V6-5 — scan `style="..."` for `prop=value` patterns that should be `prop:value`.

---

## Case 3: Font size below 20px → Text too small on 1080×1920

**Bug**: Component patterns defined `.kicker { font-size: 14px }`, `.stat-label { font-size: 16px }`, etc.

**Effect**: At 1080×1920 resolution, 14px text is physically tiny on a phone screen. User: "14太小了".

**Scope**: 12 definitions in `component-patterns.md` (both copies: `video-production/references/` and `video-production/hyperframes-workflow/references/`).

**Fix**: All bumped to 20px minimum.

**Gate rule**: V6-1 — scan all `font-size:XXpx` in the composition HTML. Flag any < 20px.

---

## Systematic issues found

| Issue | Mitigation |
|-------|-----------|
| Subagent writes invalid HTML | V6 auto-check in pre_render_hook.sh runs before every render |
| No CSS syntax validation | V6-5 catches `=` for `:` |
| Font sizes not validated | V6-1 catches sub-20px sizes |
| Duplicate attributes not flagged | V6-4 catches duplicate `class=`/`id=`/`style=` |
| Element positioning unchecked | V6-2 (top ≥ 300px) and V6-3 (top ≤ 1620px) |
