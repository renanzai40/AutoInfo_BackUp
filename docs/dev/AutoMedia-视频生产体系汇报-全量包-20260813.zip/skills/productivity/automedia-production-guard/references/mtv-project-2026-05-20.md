# MTV 独立创作项目（2026-05-20）

## 项目身份

- **目标**：用 MiniMax 全家桶（视频生成 + 歌曲生成）做 24 秒原创视频，发 B 站
- **性质**：个人创作表达，不再是 AutoMedia 商业内容
- **目录**：`/mnt/d/Hermes-Workspace/01-Projects/MTV/`

## MiniMax 配额（Token Plan，每日刷新）

```
GET https://api.minimaxi.com/v1/token_plan/remains
Authorization: Bearer $MINIMAX_CN_API_KEY
```

返回 `model_remains[]`，每个模型字段：`model_name`, `current_interval_total_count`, `current_interval_usage_count`

| 模型 | 每日额度 | 已用 | 说明 |
|------|---------|------|------|
| `MiniMax-Hailuo-2.3-6s-768p` | 2 | 0 | I2V+T2V 通用，1080P 仅 6s |
| `MiniMax-Hailuo-2.3-Fast-6s-768p` | 2 | 0 | 快速版，同分辨率 |
| `music-2.6` | 100 | 0 | 原创歌曲，从歌词生成 |
| `music-cover` | 100 | 0 | 翻唱，需 preprocess |

## 视频生成（异步三步）

```
1. POST /v1/video_generation  →  task_id
2. GET  /v1/query/video_generation?task_id=xxx  →  file_id（轮询10s间隔）
3. GET  /v1/files/retrieve?file_id=xxx  →  download_url
```

### I2V（图生视频）

```python
payload = {
    "model": "MiniMax-Hailuo-2.3",
    "first_frame_image": "https://...",      # 公网URL 或 base64
    "prompt": "描述画面如何从静态图动态演变",
    "duration": 6,
    "resolution": "1080P"
}
```

### T2V（文生视频）

```python
payload = {
    "model": "MiniMax-Hailuo-2.3",
    "prompt": "画面描述 [+ camera commands]",
    "duration": 6,
    "resolution": "1080P"
}
```

Camera 指令：`[Pan left]`, `[Push in]`, `[Static shot]`, `[Zoom in]` 等

## 音乐生成

### 原创（music-2.6）

```python
payload = {
    "model": "music-2.6",
    "prompt": "曲风描述，例：Indie folk, melancholic, coffee shop",
    "lyrics": "[Verse]\n歌词...\n[Chorus]\n歌词...",
    "audio_setting": {"sample_rate": 44100, "bitrate": 256000, "format": "mp3"},
    "output_format": "url"
}
```

### 翻唱（music-cover，两步）

**Step 1：Preprocess**

```python
# POST https://api.minimaxi.com/v1/music_cover_preprocess
payload = {
    "model": "music-cover",
    "audio_url": "https://参考歌曲URL.mp3"   # 6s-6min，<50MB
}
# 返回：cover_feature_id, formatted_lyrics, structure_result（各段落起止时间）
```

**Step 2：生成翻唱**

```python
# POST https://api.minimaxi.com/v1/music_generation
payload = {
    "model": "music-cover",
    "cover_feature_id": "xxx",     # Step1 返回的ID，有效24h
    "prompt": "目标曲风描述",
    "lyrics": "[Verse]\n新歌词...\n[Chorus]\n新歌词...",
    "output_format": "url"
}
```

歌词结构标签：`[Intro]`, `[Verse]`, `[Pre-Chorus]`, `[Chorus]`, `[Interlude]`, `[Bridge]`, `[Outro]`, `[Hook]`, `[Build Up]`

## 工作流

```
用户创意 + 参考曲风
    ↓
music_cover_preprocess（参考歌曲）→ cover_feature_id + 原始歌词结构
    ↓
OL（或其他LLM）改写歌词
    ↓
music_generation + cover_feature_id → AI翻唱音频
    ↓
MiniMax I2V × 2（6s+6s 视频开场图生视频）
    ↓
MiniMax T2V × 2（6s+6s 视频承接文生视频）
    ↓
FFmpeg 合并 4 段视频 + 音频 → 24s 成品
    ↓
发 B 站
```

## 注意事项

- 视频生成是异步，轮询间隔 10s
- cover_feature_id 有效期 24h
- 音乐 API 返回 `data.audio` 是 URL 或 hex，取决于 `output_format`
- API key 用 `MINIMAX_CN_API_KEY`，endpoint 用 `api.minimaxi.com`（中国区）
