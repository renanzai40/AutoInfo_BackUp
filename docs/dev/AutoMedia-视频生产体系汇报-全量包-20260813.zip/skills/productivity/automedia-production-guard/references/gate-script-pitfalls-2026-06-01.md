# Gate 脚本高频踩坑（2026-06-01 增补）

> 触发时机：写/改 Gate C1/C2/C3/C4 自动扫描脚本时立即读本文件。

## 坑 1：HTML 文件取前 N 字符当"首段"是 bug

**症状**：检查 `text[:300]` 找"首段钩子/痛点"时，如果 text 是 HTML 原文，前 300 字符是 `<!DOCTYPE html><html>...<head>...<meta>...`，**不是真实首段**。导致 R1 检查大面积假阴性。

**正确做法**：先 `html.parser.HTMLParser` 提取文本，再检查：

```python
from html.parser import HTMLParser

class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.skip = False
    def handle_starttag(self, tag, attrs):
        if tag in ["script", "style"]:
            self.skip = True
    def handle_endtag(self, tag):
        if tag in ["script", "style"]:
            self.skip = False
    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)
    def get_text(self):
        return " ".join(self.parts)

def get_text(path, content):
    if path.endswith(".html"):
        p = TextExtractor()
        p.feed(content)
        return p.get_text()
    return content
```

**另一相关坑**：HTML 的段落用 `<p>` 标签切，不是 `\n\n`：

```python
def get_paragraphs(path):
    if path.endswith(".html"):
        with open(path) as f:
            html = f.read()
        return re.findall(r'<p[^>]*>([^<]+)</p>', html)
    return [p for p in re.split(r'\n\n+', open(path).read()) if p.strip()]
```

## 坑 2：em-dash（——）和"万字"在中文场景过严匹配

**症状**：用 `r'[—-]{1,}.*?[—-]{1,}'` 匹配 em-dash 时，会把中文破折号 —— 算 1 处，公众号 17-20 处 / 1600 字被严重高估。用 `r'万字'` 检查营销词时，把"100 万字上下文"误判为"万字长文"。

**正确做法**：

**em-dash 比例**（中文场景）：
- 0.8-1.2% 是正常中文写作比例，不要 flag
- 精确计数用 `content.count("——")` 而不是泛 dash 正则
- 仅在比例 > 2% 时才考虑是 AI 模式

**"万字"匹配**（带排除）：
```python
# ❌ 错误：把"100 万字上下文"误判为"万字长文"
r'震惊|必看|惊呆|不看亏|一文|深度好文|万字|一文读懂'

# ✅ 正确：排除"100万字""1万字"等技术/数字搭配
r'(?<![百万\d])震惊|必看|惊呆|不看亏|一文(?!读懂)|深度好文|万字长文|一文读懂'
```

**"序数第一" vs "绝对化第一"**：
- "第一层、第二层、第三层" / "第一时间" / "第一天" / "第一反应" / "不写第一稿" → 序数用法，**不是** AI 套话
- 真正绝对化 = "壹目贯维是最强的" / "史上最大" / "100% 有效"

```python
# ✅ 正确：仅匹配品牌宣传/绝对化
r'((?:壹目贯维|我们)[^，。\n]{0,15}?(?:最强|最大|第一|唯一|顶级))'
```

## 坑 3：数字+空格的正则不匹配

**症状**：中文文本常写"4 小时"、"40 分钟"、"7.5 倍"，但 `r'\d+(?:小时|分钟)'` 不会匹配（中间有空格）。导致 R4"具体数据"检查失败。

**正确做法**：在数字和单位之间加 `\s*`：

```python
# ❌ 错误
r'\d+(?:[%倍万千]|小时|分钟)'

# ✅ 正确
r'\d+(?:\.\d+)?(?:\s*[%倍万千]|\s*(?:小时|分钟|秒|天|周|月|年|字|个|款|次|人|元|块|%|条|篇|成|分))'
```

## 坑 4：CTA 关键词按平台差异化

**症状**：用统一的"关注/私信/查看"作为 CTA 检查关键词，但小红书的 CTA 是"评论互动"不是"关注公众号"，导致小红书 R3 检查大面积假阴性。

**正确做法**：

```python
cta_keywords_by_platform = {
    "video": ["关注", "实测", "下期"],
    "xhs":   ["关注", "评论", "聊聊", "扣", "看看", "更多", "下期", "你们"],
    "wechat":["关注", "下期", "查看", "我们", "联系"],
    "zhihu": ["关注", "下期", "讨论", "查看", "知乎"],
}
```

**反例**：xhs 平台用"私信"作为 CTA 关键词 = false positive 频发，因为 xhs 文案几乎不用"私信"。

## 坑 5：公众号图占位要真生成

**症状**：HTML 里有 `<img src="images/wechat_img_1.png">` 占位，Gate C1/C2 全过，但**图根本没生成**。打包时图片不存在，HTML 在公众号/本地浏览器都是 broken image。

**正确做法**：
- Gate C1/C2 全过 ≠ 资产完整
- 公众号发布前**必须额外验证**：HTML 里的每个 `<img src=...>` 都能解析到 `01_content/drafts/{platform}/images/` 下的实际文件
- 图片生成属于**必做**，不是"加分项"

**验证代码**：
```python
import re, os
html = open(html_path).read()
img_dir = os.path.join(os.path.dirname(html_path), "images")
for src in re.findall(r'<img[^>]*src="([^"]+)"', html):
    img_file = os.path.join(img_dir, os.path.basename(src))
    if not os.path.exists(img_file):
        raise Exception(f"HTML 引用了 {src} 但 {img_file} 不存在")
```

## 坑 6：f-string 内的反斜杠报错

**症状**：在 `execute_code` 里写 `f"匹配: {sum(len(re.findall(r'[\u4e00-\u9fff]', x)) for x in items)}"` 会报 `SyntaxError: f-string expression part cannot include a backslash`。

**正确做法**：先把正则赋给变量，再在 f-string 里引用：
```python
chinese_re = r"[\u4e00-\u9fff]"
total = sum(len(re.findall(chinese_re, x)) for x in items)
print(f"匹配: {total}")
```

## 坑 7：HTML 内的反引号引号 + 中文弯引号不匹配

**症状**：正则 `r'"(.+?)"'` 在中文文本里只匹配直引号 `"..."`，不匹配弯引号 `"..."`（U+201C/U+201D）。但 m3_tiktok 视频脚本里口播用了弯引号 `""...`，导致 Entry 解析为 0 句。

**正确做法**：
```python
# ❌ 错误
r'Entry \d+："(.+?)"'

# ✅ 正确（同时匹配直/弯引号）
r'Entry \d+：[""「](.+?)[""」]'
```

或者按行号定位口播段落（更可靠）：
```python
parts = re.split(r'## 【', content)
for p in parts[1:]:
    dialogues = re.findall(r'[""「](.+?)[""」]', p, re.DOTALL)
    # ...
```

## 坑 8：MCP MiniMax 图片下载需要 User-Agent

**症状**：`urllib.request.urlopen(MiniMax_image_url)` 经常返回 403 Forbidden。

**正确做法**：
```python
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
with urllib.request.urlopen(req, timeout=30) as r:
    with open(local_path, "wb") as f:
        f.write(r.read())
```

**完整 URL 必须用**：MiniMax 返回的 URL 是带签名的 `?Expires=...&Signature=...`，任何截断都会 401/403。

## 坑 9：subagent 报告路径要写到项目子目录

**症状**：subagent 跑完 copy-review，报告写到 `/home/renanzai/reports/` 或 `/tmp/`，`copy_review_gate.py` 找不到 → 报"Gate 失败"。

**正确做法**：subagent delegation prompt 显式指定：
```
输出路径：/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/{项目名}/04_review/copy_review_{平台}.md
```

详细见 `references/copy-review-gate-usage-2026-05-22.md`。
