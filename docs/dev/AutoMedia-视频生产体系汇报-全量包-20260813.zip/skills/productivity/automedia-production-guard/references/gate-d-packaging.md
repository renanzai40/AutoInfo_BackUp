# Gate D：打包完整性检查（交付前 Hard Gate）

## Gate D：打包完整性检查（交付前 Hard Gate）

> 本节内容原为独立 skill `automedia-packaging-check`，已并入 `automedia-production-guard`。2026-05-16 教训固化。

**触发时机**：项目打包发送给用户之前。每次打包后必须验证。

### 打包完整性验证（8 文件强制检查）

用 Python zipfile 读取 namelist，验证以下文件**全部存在**：

```
03_video/video_final.mp4
03_video/audio_voiceover.mp3
03_video/subtitle.srt
01_content/script_final.txt
01_content/wechat_draft.html
01_content/drafts/zhihu/zhihu_article.md
01_content/drafts/xiaohongshu/xiaohongshu_post.md
02_images/cover_9x16.png
```

**典型失误（2026-05-16）**：
- drafts 子目录的 md 文件路径写错（`drafts/zhihu.md` 而非 `drafts/zhihu/zhihu_article.md`）
- 项目目录有文件 ≠ zip 里有文件
- 禁止凭"应该打包了"的假设跳过验证

```python
import zipfile
with zipfile.ZipFile('/path/to/package.zip') as z:
    names = z.namelist()
required = [
    '03_video/video_final.mp4',
    '03_video/audio_voiceover.mp3',
    '03_video/subtitle.srt',
    '01_content/script_final.txt',
    '01_content/wechat_draft.html',
    '01_content/drafts/zhihu/zhihu_article.md',
    '01_content/drafts/xiaohongshu/xiaohongshu_post.md',
    '02_images/cover_9x16.png',
]
missing = [f for f in required if f not in names]
if missing:
    raise Exception(f"zip 缺文件: {missing}")
```

### Pre-send Whisper 验证

**① 音频内容确认（Whisper 10秒采样）**
```bash
WHISPER=/home/renanzai/mamba/envs/whisper/bin/python3
$WHISPER -c "
import whisper
model = whisper.load_model('small', device='cpu')
result = model.transcribe('待发视频.mp4', language='zh', fp16=False)
print(result['text'][:100])
"
```
话题不符 → 不发，立即排查文件路径。

**② 发出路径 = QA 路径**
- 发送前记录：`/tmp/video1_final_v4.mp4`（举例）
- 发出去的就是这同一个文件，不是项目目录里的同名文件

**③ 发完自检**
- 用 Whisper 重新检查刚发出的文件，确认内容无误

### 历史教训（2026-05-16）

- `/tmp` 里多版本并存（`video1_final.mp4` / `video1_final_new.mp4` / `video1_final_v4.mp4`），文件名相似但内容不同
- Vision QA 检查了文件 A，发送了文件 B（项目目录的同名旧版）
- **规则**：视频来源必须是 `/tmp` 里经 Vision QA 验证过的版本，不得从项目目录取同名文件替换
