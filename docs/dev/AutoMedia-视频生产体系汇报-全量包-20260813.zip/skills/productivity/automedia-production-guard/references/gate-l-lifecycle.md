# 🆕 项目生命周期 Gate (Gate L) — 2026-06-02 新增

## 🆕 项目生命周期 Gate (Gate L) — 2026-06-02 新增

> **本节是 5 个生产 Gate 的预/后置条件**：项目生命周期状态不对 → publish/archive 都会错位 → 后续 Gate 全无意义。
> 完整设计见 `publish-log-schema` skill（含 5 状态、9 INV、per-platform 推算、archive 强校验规则）。

### Gate L1: publish_log v2.1 schema 合规（写入前必跑）

**触发时机**：每次新写或更新 `05_publish/publish_log.json` 之前。

**检查项**：

| 检查项 | 失败行为 |
|---|---|
| `platforms` map 存在（5 平台 key 齐）| Pipeline STOP（不写文件）|
| 每个 platform 的 `status` ∈ {pending, content_ready, draft_uploaded, published} | Pipeline STOP |
| 视频相关字段（`video_path` / `video_av_sync_qa`）有则填，无则可省 | WARN（不阻塞）|
| 顶层 `_computed_status`（如保留）= platforms 推算结果 | WARN（提示漂移）|

```python
import json, jsonschema
schema = json.load(open('~/.hermes/profiles/content/skills/publish-log-schema/schema.json'))
log = json.load(open('publish_log.json'))
try:
    jsonschema.validate(log, schema)
except jsonschema.ValidationError as e:
    raise Exception(f"publish_log 不符合 v2.1 schema: {e.message}")
```

### Gate L2: archive 强校验（写入前必跑）

**铁律（2026-06-02 多次擅自归档教训固化）**：

> **agent 不得把项目目录 mv 到 archive/，除非 project.status == "published"。**
> 例外：user 显式 `archive_project.py --force <id> --reason "..."` 绕过。

**check**:

```python
import sys
sys.path.insert(0, '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts')
from compute_project_status import compute_status_full
from pathlib import Path
import json

proj_dir = Path("<project_dir>")
# 读 project_info
info = json.load(open(proj_dir / "00_project_info.json"))
# 读 publish_log
log = json.load(open(proj_dir / "05_publish" / "publish_log.json"))
platforms = log.get("platforms", {})
project_type = info.get("type") or info.get("category") or "其他"
explicit = info.get("status")

status = compute_status_full(proj_dir, platforms, project_type, explicit)

if status != "published" and not getattr(args, 'force', False):
    raise Exception(
        f"❌ Project status = '{status}', not 'published'\n"
        f"❌ Archive denied. Use --force to override with reason."
    )
```

**`--force` 必须配合 `--reason`**：reason 必填，写入 `publish_log.json._force_archived_reason` 永久留档。

### Gate L3: 平台素材完整性（INV-9 守门）

**触发时机**：任何 mv 到 archive/ 之前。

**铁律**：

> 即使 wechat published，wechat 素材（02_images/03_video/05_publish/...）**不得单独移到 archive/**。
> 只有项目整体 archive 时，所有素材一起搬。

**反例（2026-06-02 案例）**：

- ❌ mv `projects/m3/05_publish` 到 `archive/m3/05_publish`（wechat 单独 archive）
- ✓ mv `projects/m3/*` 到 `archive/m3/*`（项目整体 archive）

**check**: 任何只动 `archive/_orphans/` 之外的 archive 操作，必须包含项目下所有子目录。

### 5 状态 + 9 INV 速查（详见 publish-log-schema skill）

**5 状态**：

```
selected → in_flight → awaiting_publish → published
                  ↓
              cancelled (user 显式)
```

**9 INV（不变量）核心 4 条**（其他 5 条见 publish-log-schema）：

| INV | 内容 |
|---|---|
| INV-6 | publish_log 必须含 `platforms` map（5 平台 key 齐）|
| INV-8 | agent 不得 archive project，除非 published（user --force 绕过）|
| INV-9 | 任何 platform 素材不得单独归档 |
| (其余 6 条) | topic ↔ project 联动 / dual-topics / selected 必带 topic / review_log 4-gate 等 |

**`compute_project_status.py` 是单一 source of truth**：

```python
import sys
sys.path.insert(0, '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts')
from compute_project_status import compute_status, compute_status_full
# 不要自己写推算逻辑!
```

**为何单一实现**：m3 案例 + 28 项目 audit 证明，多份算法必漂移。修了 1 个算法后，其他 4 份还是旧的 → 永远追不上。

### 反模式

- ❌ mv `projects/<id>` 到 `archive/` 不验证 published（违反 INV-8）
- ❌ mv 单个子目录（如 05_publish）到 archive/（违反 INV-9）
- ❌ 各脚本自己写 status 推算逻辑（5 份算法 5 份 bug）
- ❌ agent 主动 archive（archive 是 user 决策，不是 agent 决策）
- ❌ 顶层 `status` 字段手工写（与 platforms 漂移是必然）

### 实战案例（2026-06-02 教训）

- 早期 session 多次擅自归档 m3/hy/deepseek/lorai 4 个项目（全是 awaiting_publish 状态）
- 当天 17:00 移回 active，所有项目重新计算正确 status
- 强制加 Gate L1/L2/L3，agent 物理上无法再"误归档"

---
