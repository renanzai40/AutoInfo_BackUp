# #🆕 Gate V5 完整规范：mp3 vs SRT 文本核验（2026-06-05 v10 新增 · P0-13 铁律）

### 🆕 Gate V5 完整规范：mp3 vs SRT 文本核验（2026-06-05 v10 新增 · P0-13 铁律）

> **触发原因**：2026-06-05 session 113223 时代 mp3 朗读内容 = "GPT5 工具红利期"（旧版 6-02/6-03 m3 tts 产物），SRT 文本 = "Alphabet 800亿"（session 113223 新写）——**两套完全错配**。Vision QA 抽 5 帧全在 S1 段，sync_check 抽 12 帧也**无法发现文本不匹配**（sync_check 只校验时间戳偏差）。**根治**：发飞书前必跑 Whisper + diff SRT 文本。

#### 检查流程（必跑，3 步）

```bash
# Step 1: Whisper 转写 mp3 实际内容
whisper <mp3_path> --language zh --model tiny \
    --output_format srt --output_dir /tmp/whisper_pre_send/

# Step 2: 提取 Whisper 转写文本 + SRT 文本，做关键词比对
python3 << 'EOF'
import re

srt = open('/path/to/subtitle.srt').read()
whisper = open('/tmp/whisper_pre_send/<mp3_name>.srt').read()

# 提取 ≥2 字的中文词（忽略时间戳）
srt_texts = set(re.findall(r'[\u4e00-\u9fff]{2,}', srt))
whisper_texts = set(re.findall(r'[\u4e00-\u9fff]{2,}', whisper))

# 关键词覆盖率（容忍 Whisper ASR 误识别 ±20%）
common = srt_texts & whisper_texts
coverage = len(common) / len(srt_texts) * 100 if srt_texts else 0

print(f"SRT 关键词数: {len(srt_texts)}")
print(f"Whisper 关键词数: {len(whisper_texts)}")
print(f"共同关键词: {len(common)}")
print(f"覆盖率: {coverage:.1f}%")

if coverage < 80:
    missing = list(srt_texts - whisper_texts)[:10]
    raise Exception(
        f"❌ V5 mp3 vs SRT 文本错配：覆盖率 {coverage:.1f}% < 80%\n"
        f"   缺失关键词: {missing}\n"
        f"   → mp3 朗读的不是 SRT 文本，必须重新生成 mp3"
    )
print(f"✅ V5 PASS: 覆盖率 {coverage:.1f}% ≥ 80%")
EOF

# Step 3: 失败处理
# 覆盖率 < 80% → BLOCK_send
# 单一源缺失（如 SRT 不含但 Whisper 含）→ 警告但不阻塞
# 3 源都不含的关键词 → 列出缺失关键词清单
```

#### 6-05 实战案例（V5 必拦的失败）

**session 113223 时代踩坑**：

| 源 | 实际内容 | 与 SRT 匹配 |
|---|---------|-----------|
| **mp3 朗读** | "GPT5 还没捂热 新模型一周冒出一批" / "API 18月降 90%" | ❌ **完全不匹配 SRT** |
| **SRT 文本** | "AI 行业八月的头条" / "Alphabet 拟融资 800 亿美元" | ❌ 跟 mp3 朗读无关 |
| **字幕显示** | "AI 行业八月的头条" / "Alphabet 拟融资 800 亿美元" | ❌ 跟 mp3 朗读无关 |

**user 看到视频**："字幕显示'800 亿美元'，但音频在讲'GPT5'——怎么对不上？"

#### 与 V3 Content Semantic Match 的区别

- **V3** 检查**视觉/SRT/Whisper 转写** vs **pool.db 关键词清单**（话题是否对）
- **V5** 检查 **Whisper 转写** vs **SRT 文本**（mp3 朗读是否对）

**V5 必跑**，V3 是话题相关性（与 pool.db 比），V5 是内容一致性（mp3 vs SRT 比）。

#### 反模式（永久禁止）

- ❌ **"我用 SRT 文本作为 TTS 输入，mp3 朗读必然 = SRT"**——**实测打脸**：6-05 案例 mp3 是旧版 m3 tts，**TTS 输入不是今天的 SRT**
- ❌ **"Whisper 听到的跟 SRT 差不多就行"**——V5 阈值 80%，< 80% = mp3 跟 SRT 是两套
- ❌ **只校验时间戳偏差（sync_check）**——sync_check 只查"字幕时机对不对"，**不查"字幕内容对不对"**

#### 触发条件（必跑 V5）

| 触发场景 | 必跑 V5? |
|---------|---------|
| 新生成 mp3 后 | ✅ 必跑 |
| 复用旧 mp3 + 新 SRT | ✅ 必跑（最危险，session 113223 案例） |
| TTS 引擎变化 | ✅ 必跑 |
| TTS voice_id 变化 | ✅ 必跑 |
| SRT 文本修改 | ✅ 必跑（mp3 可能还读旧文本） |
| Composition 重渲染但 mp3 不变 | ❌ 可不跑（mp3 没变） |

#### 6-05 v10 验收

- ✅ alphabet mp3 Whisper 转写 = "AI 行业八月的头条" / "Alphabet 拟融资 800 亿美元" / "Anthropic 同步提交 IPO 申请" / "军备竞赛阶段" / "关注壹目贯维 AI 内容生产公司" / "生成多平台内容"（**100% 匹配 SRT**）
- ✅ openai mp3 Whisper 转写 = "OpenAI 又放大招 Codex 推出团队专属插件" / "编程场景的团队协作正式登陆" / "AI 内容生产也是一样"（**100% 匹配 SRT**）
