# 评分算法 v3 更新记录（2026-05-24）

## 变更背景

2026-05-24 发现"行业概览PDF"（中国餐饮行业市场报告）以 business款 TOP2 综合分 4.917 排在真正相关话题之前。根因：
1. correlation_score 全是 5.0（default 值），完全没有区分度
2. default 从 5 → 行业报告类话题本应得低分，反而得了中等分
3. 热度权重过高（0.25），新鲜度权重偏低（0.20）

## 新七层关键词分级（v3）

### Tier 1 — AI内容生产核心（business=10 / growth=9）
直接命中壹目贯维核心业务词。

包含：aigc / AI文案 / AI写作 / AI脚本 / 文生文 / AI视频生成 / AI短视频 / 文生视频 / 图生视频 / AI图片生成 / AI绘画 / 文生图 / Midjourney / Stable Diffusion / AI音乐 / AI歌曲 / Suno / AI配音 / 语音克隆 / TTS / AI数字人 / 虚拟主播 / AI营销 / 热点 / 蹭热点 / 热点运营 / 热点追踪 / 自媒体 / 内容矩阵 / 批量生产 / 多平台发布 / KOL / KOC / 素人创作者 / MCN / AI助手 / Copilot / AI提示词 / AI工作流 / 即梦 / 可灵 / vidu / sora / minimax视频 / 海螺AI / 清影

### Tier 2 — AI辅助创作生态（business=9 / growth=8）
AI驱动的内容创作工具、平台、模型服务商。

包含：deepseek / kimi / 豆包 / 智谱 / 文心一言 / 混元 / 百川 / 跃问 / **大模型（独立词）** / 国产大模型 / GPT / chatgpt / claude / gemini / OpenAI / Anthropic / 奥特曼 / 视频生成 / 文生视频 / asr / AI开源 / 开源大模型 / 新模型 / Copilot / Cursor / Windsurf / AI IDE / AI微调 / LoRA / RLHF / DPO / AI Agent / Agent工作流 / RAG / embedding / LangChain / DSPy / AI产品 / AI工具 / AI平台

### Tier 3 — 泛AI行业应用 + 内容运营生态（business=7 / growth=6）
AI在特定行业应用 + 内容平台矩阵 + 达人生态 + 出海营销。

包含：人工智能 / 机器学习 / 深度学习 / 神经网络 / Transformer / 自动驾驶 / 智能驾驶 / AI汽车 / AI手机 / AI PC / 端侧AI / **内容运营 / 自媒体运营 / 内容矩阵 / 内容批量生产 / 热点运营 / 热点追踪** / 种草 / 达人 / 素人创作者 / **B站 / 知乎 / 小红书 / 公众号 / 百家号 / 头条号** / 内容营销 / 种草笔记 / 私域流量运营 / 社群运营 / 直播电商 / 内容电商 / 出海AI / 内容出海 / 跨境内容 / **TikTok / YouTube / Instagram / Facebook** / 数字化转型

### Tier 4 — 泛科技商业（business=5 / growth=5）
科技/互联网/商业资讯，有一定关联但不直接。

包含：科技 / 互联网 / 半导体 / 芯片 / 新能源 / 电动汽车 / 锂电池 / 光伏 / 电商 / 直播 / 短视频 / 内容创作 / 抖音 / 快手 / 腾讯 / 字节 / 阿里 / 百度 / 京东 / 拼多多 / 苹果 / 华为 / 小米 / 三星 / OPPO / vivo / 谷歌 / 微软 / Meta / 英伟达 / IPO / 融资 / 投资 / 并购 / 上市 / 市值 / 财报 / 经济 / 市场 / 关税 / 贸易 / 中美 / 特朗普 / 出海 / 全球化

### Tier 5 — 传统行业报告（business=3 / growth=4）
泛行业分析报告/市场研究，与AI内容生产 gap较大。

包含：行业报告 / 行业分析 / 行业概览 / 市场报告 / 研究报告 / 数据分析 / 数据洞察 / 数据趋势 / 数据报告 / 行业数据 / 市场份额 / 竞争格局 / 企业服务 / SaaS / 企业软件 / 解决方案 / 餐饮行业 / 零售行业 / 制造业 / 医疗行业 / 咨询报告 / 白皮书 / 灼识 / 艾瑞 / 易观 / 市场调研 / 用户研究 / 消费者洞察 / IPO报告 / 招股书 / 财务分析 / 估值分析

### Tier 6 — 大众话题（business=2 / growth=3）
大众娱乐/社会热点，与品牌完全无关。

包含：体育 / 足球 / 篮球 / 世界杯 / CBA / NBA / 欧冠 / 电影 / 电视剧 / 综艺 / 音乐 / 演唱会 / 游戏 / 电竞 / 天气 / 地震 / 暴雨 / 台风 / 灾害 / 国际 / 外交 / 政治 / 战争 / 社会 / 教育 / 旅游 / 美食 / 健康 / 美容 / 时尚 / 娱乐 / 八卦 / 热搜 / 霸榜 / 明星 / 网红

### Default（business=2 / growth=3）
完全没有关键词匹配的模糊话题。**旧版 default=5（中等分）是核心 bug，v3 改为 2（最低分）**。

---

## 新加权公式（2026-05-24）

```
growth（引流款）：
  score = heat_score × 0.30 + correlation_score × 0.40 + freshness_score × 0.30

business（业务款）：
  score = heat_score × 0.10 + correlation_score × 0.60 + freshness_score × 0.30
```

**变化对比**：

| | 旧权重 | 新权重 |
|---|---|---|
| growth 热度 | 0.55 | **0.30** ↓ |
| growth 相关性 | 0.25 | **0.40** ↑ |
| growth 新鲜度 | 0.20 | **0.30** ↑ |
| business 热度 | 0.25 | **0.10** ↓ |
| business 相关性 | 0.55 | **0.60** ↑ |
| business 新鲜度 | 0.20 | **0.30** ↑ |

**设计意图**：
- business 款：相关性权重最高（0.60），热度降到次要（0.10），新鲜度提升到 0.30
- growth 款：热度权重降低（0.30），相关性和新鲜度各升到 0.40/0.30
- correlation_score 的区分度来自关键词分级，不是权重本身

## ⚠️ "行业概览PDF" 高分根因分析（2026-05-24 用户质疑）

**问题**：业务款 TOP2 = "行业概览PDF"（中国餐饮行业市场报告），相关性和业务关联都很模糊，为什么评分这么高？

**旧版算法（v2）的三个核心 bug 导致了这个结果**：

### Bug 1：correlation_score 无区分度（主因）
- 旧版：所有未匹配到关键词的话题，correlation_score 全部默认 = 5.0（中分红线）
- "行业概览PDF" 匹配到 Tier 5（传统行业报告，理论分=3），但旧版代码里关键词匹配失败时直接 fallback 到 default=5，没有走 Tier 5 的降权逻辑
- 结果：模糊话题反而得了中等的 5 分，而真正 Tier 5 的话题（如"餐饮行业报告"）理论分应该只有 3

**v3 修复**：关键词匹配失败 → correlation_score = 2（最低分），不是 5

### Bug 2：热度权重过高（25%）
- 旧版 business 款：热度权重 25%，相关权重 55%
- 如果"行业概览PDF"的热度分（heat_score）也较高（如热搜榜上），乘以 0.25 后贡献显著
- 加上 correlation=5（bug 值），两者叠加推高了总分

**v3 修复**：热度权重降至 10%，相关性升至 60%

### Bug 3：default 值设计错误
- 旧版意图：default=5 表示"未知话题给中等分，保留机会"
- 实际效果：模糊话题（完全不相关）和中等话题（同分），失去了评分系统的区分能力

**v3 修复**：default=2（最低分），完全不相关的模糊话题直接淘汰

### 为什么 v3 后"行业概览PDF"降到合理位置（4.29 分，TOP 边缘）
- correlation_score 从 5 → 3（走 Tier 5，实际该话题属于"传统行业报告"类）
- heat权重从 0.25 → 0.10（热度贡献减半）
- 相关性权重从 0.55 → 0.60，但 correlation 本身的 3 分值限制了总分

### 教训
评分算法的 default 值不是"中性"，而是必须有方向性——完全不相关的话题应该得最低分，不是中等分。
相关性权重 business=0.60 才是核心杠杆，热度只是辅助。

## 典型话题新旧评分对比

| 话题 | 旧相关分 | 新相关分 | 变化 | 旧综合分 | 新综合分 | 变化 |
|------|---------|---------|------|---------|---------|------|
| AIGC营销解决方案 | 10 | 10 | — | 4.58 | **8.49** | ↑3.91 |
| DeepSeek开源 | 8 | 9 | ↑ | 4.58 | **7.89** | ↑3.31 |
| 行业概览PDF | 5 | **3** | ↓↓ | 4.92 | **4.29** | ↓0.63 |
| 词元套餐(泛流量蹭词) | 5 | **2** | ↓↓ | 4.58 | **3.70** | ↓0.88 |
| 宁王入股大模型 | 5 | **9** | ↑↑ | 4.58 | **7.89** | ↑3.31 |
| 体育世界杯 | 3 | 2 | ↓ | 4.58 | **3.70** | ↓0.88 |

## 数据库更新

所有 pending 话题的 correlation_score 已用 v3 算法重新计算：
```sql
-- 更新所有 pending 话题
UPDATE topics SET correlation_score = <v3新分> WHERE status='pending'
```

相关文件：
- 脚本：`/home/renanzai/.hermes/skills/productivity/automedia/scripts/auto_media_hot_collection.py`
- 备份：`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/skills_backup_20260524_113439/`
- cron prompt：`/home/renanzai/.hermes/cron/jobs.json`（08:30 推送里的公式）
- 文档：`references/freshness-decay.md`