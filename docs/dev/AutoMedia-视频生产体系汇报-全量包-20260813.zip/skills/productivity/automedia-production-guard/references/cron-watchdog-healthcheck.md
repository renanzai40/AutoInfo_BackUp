# 🆕 Cron 健康检查 Watchdog（from `automedia-cron-watchdog`，2026-06-04 daily 09:30）

## 🆕 Cron 健康检查 Watchdog（from `automedia-cron-watchdog`，2026-06-04 daily 09:30）

> **何时启用本 Gate**：每日 09:30 cron `wdog_auto_media` 触发时加载；或用户提到「watchdog」/「wdog_alert.json」/「健康检查 cron」时立即加载。
> **与 Cron 作业 Schema Gate 的关系**：Schema Gate（预条件）确保 job 字段合法；本 Gate（监控层）确保实际运行时健康。

### 监控目标

| Slot | Job ID | Schedule | 用途 |
|------|--------|----------|------|
| **07:30** | `maintenance_01` | `30 7 * * *` | AutoMedia 新鲜度维护 |
| **08:00** | `143d19e69a7c` | `0 8 * * *` | AutoMedia 热点采集 |
| **08:30** | `7671da210b69` | `30 8 * * *` | AutoMedia 话题池汇总推送 |
| **08:05**（附加）| `audit_08x05` | `5 8 * * *` | 语义审核 + 黑名单更新（**同源跟踪**） |

### 4 步执行流程

1. **读 jobs.json 探查 schema** — 健康字段在**顶层**（`last_status` / `last_run_at` / `last_error` / `last_delivery_error`），**不**在 `last_run` 嵌套下
2. **逐 job 健康判定** — `last_status=ok` + `last_error=None` + `last_delivery_error=None` = healthy
3. **交叉验证输出文件存在** — `~/.hermes/profiles/content/cron/output/<job_id>/<date>.md` 必须存在（防假阳性）
4. **写告警 / 归档 wdog_alert.json**
   - **failure 路径**：写 `wdog_alert.json`（schema `automedia.wdog_alert.v1`）→ cron delivery 捡起飞书推送
   - **healthy 路径**：**先归档昨天** `wdog_alert.json → .resolved.<ts>`（rename 不 delete）→ 停止投递

### 状态转换（关键生命周期）

```
[无文件]
  ↓ 今日有 failure → 写 wdog_alert.json
[wdog_alert.json 存在]   ← cron delivery 会捡起飞书推送
  ↓ 今日全部 healthy → rename → wdog_alert.json.resolved.YYYYMMDD_HHMMSS
[无文件]                  ← 投递停止
```

> ⚠️ **rename 而不是 delete**：(1) 保留历史取证 (2) rename 后 cron delivery 不会再匹配 (3) 外部脚本想看"最近一次失败"直接 glob `wdog_alert.json.resolved.*` 最新一份

### Feishu 错误码速查

| 错误码 | 含义 | 典型原因 |
|--------|------|----------|
| `[230002]` | Bot/User can NOT be out of the chat | bot 被移出群 / 应用无 `im:message` 权限 |
| `[230001]` | Your request contains an invalid request parameter | `origin` 解析失败 / ID 格式错 |

**intermittent_chat_id 模式**：同一 chat_id 在某个 job 失败、另一个 job 成功 → 不是 chat 完全失效，是飞书侧/单次抖动。

### 9 个常见 Pitfalls（永久记录）

1. **检查 schedule 字段类型** — 看到 `schedule` 是字符串的 job，watchdog 应同时报告 + 修复
2. **同源跟踪** — 08:05 audit_08x05 不在任务字面要求内，但历史上多次与 08:00/08:30 同源失败
3. **last_run_at 时间窗判定** — 每日 09:30 跑，所有目标 job 应在 07:30-08:30 窗口内完成
4. **不混淆 `last_error` 和 `last_delivery_error`** — 前者任务崩溃，后者投递失败
5. **rename 而不是 delete** — 见上
6. **多次重跑（recheck）** — 每次跑都生成新 `wdog_alert.json`，**不是 update**
7. **python 字符串 schedule format 报错** — schedule 是 dict 需 `sched.get('display')`，不能直接 `{sched:12s}`
8. **`hermes cron list` AttributeError** — `repeat_info` 字段为 None 抛错，改用 `python3 -c "import json; ..."` 直接读 jobs.json
9. **输出文件存在性 = 真健康信号** — `last_status=ok` + 输出文件存在 + `last_delivery_error=null` 才作数

> 📖 完整 watchdog 报告模板 + diagnosis schema + recommended_actions：见 `references/cron-watchdog-pattern-2026-06-04.md`

---
