# TTS API 修复记录（2026-05-25 更新）

## ✅ 正确 TTS 调用方式

**错误方法（❌ 2013 invalid params）**：
- `speech-02-hd` + `output_format: "url"` → 返回 2013 错误
- `response_format: "url"` → 无效参数，不返回 URL

**正确方法（✅ 实测有效，2026-05-25）**：

```python
import urllib.request, json, os

api_key = os.environ.get("MINIMAX_CN_API_KEY")
base_url = "https://api.minimaxi.com/v1"

payload = {
    "model": "speech-2.8-hd",          # ✅ 正确模型名（不是 speech-02-hd）
    "text": script_text,
    "voice_setting": {
        "voice_id": "Chinese (Mandarin)_Radio_Host",
        # speed/vol 可选，不加 emotion（会报 2013）
    },
    "audio_setting": {
        "sample_rate": 24000,
        "bitrate": 128000,
        "format": "mp3"
    }
}

url = base_url + "/t2a_v2"
headers = {"Authorization": "Bearer " + api_key, "Content-Type": "application/json"}
req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers=headers, method="POST")

with urllib.request.urlopen(req, timeout=120) as resp:
    result = json.loads(resp.read())

if result.get("base_resp", {}).get("status_code") == 0:
    audio_hex = result["data"]["audio"]       # ✅ hex 编码字符串，不是 URL
    audio_bytes = bytes.fromhex(audio_hex)     # ✅ fromhex，不是 base64
    with open("output.mp3", "wb") as f:
        f.write(audio_bytes)
    # 文件头应为 49443304（MP3 sync word）
```

**关键要点**：
- 模型：`speech-2.8-hd`（不是 `speech-02-hd`）
- 音频返回格式：**hex 编码字符串**，在 `result["data"]["audio"]`，不是 URL
- 解码：`bytes.fromhex(audio_hex)`
- `response_format: "url"` 是无效参数，不要用
- 不用加 `GroupId` 查询参数（Bearer token 认证即可）

## ⚠️ ffprobe 无法读取 hex MP3 时长

**症状**：ffprobe 对 MiniMax TTS 生成的 MP3 返回 exit code 8（AVERROR_EOF），`-of default=noprint_wrappers=1:nokey=1` 输出空字符串。但音频文件本身可正常播放和解码。

**Workaround**：转 WAV 后读取时长。
```python
def get_dur_via_wav(mp3_path):
    wav_path = mp3_path.replace(".mp3", "_tmp.wav")
    subprocess.run([
        "/home/renanzai/mamba/envs/ffmpeg/bin/ffmpeg", "-y",
        "-i", mp3_path, "-ac", "1", wav_path
    ], capture_output=True, timeout=60)
    import wave
    with wave.open(wav_path, 'rb') as w:
        return w.getnframes() / w.getframerate()
```

## ⚠️ Whisper CPU + ffmpeg 找不到

**症状**：`whisper.load_model()` 成功，但 `model.transcribe()` 报 `FileNotFoundError: ffmpeg`

**根因**：hermes-agent venv 的 Python 在 sandbox 中，PATH 不含 mamba ffmpeg 路径。

**解法**（只需执行一次）：
```python
import os
if not os.path.exists("/home/renanzai/.hermes/hermes-agent/venv/bin/ffmpeg"):
    os.symlink(
        "/home/renanzai/mamba/envs/ffmpeg/bin/ffmpeg",
        "/home/renanzai/.hermes/hermes-agent/venv/bin/ffmpeg"
    )
```

## burn_subtitles.py 执行模式

`burn_subtitles.py` 需要 **raw 视频文件**（用于帧提取），**不是**音频文件。

```bash
# Step 1: ffmpeg concat 把图片序列合成 raw 视频
ffmpeg -y -f concat -safe 0 -i concat_list.txt \
  -vsync vfr -pix_fmt yuv420p raw_video.mp4

# Step 2: burn_subtitles.py 烧录 + 合成音频
python3 burn_subtitles.py raw_video.mp4 output.mp4 \
  --segs-json '[[0, 3.5, "字幕文本"], ...]' \
  --fps 2 \
  --font-size 55 \
  --subtitle-margin-bottom 120 \
  --margin-h 60 \
  --audio-file audio.mp3
```

**Gotcha**：`burn_subtitles.py` 第一个参数是**视频**，用于按 `--fps` 提取帧。不要传音频文件作为第一个参数。

## subagent 超时 → 帧图不完整

subagent delegation timeout（600s）会导致部分帧图未生成（如 frame_002/008/009 缺失）。

**应急处理**：
1. 复制现有帧图中最接近的填充缺失位置
2. 用循环复制使 `帧数 × 每帧时长 ≥ 音频时长`
3. 继续执行 burn_subtitles.py

**推荐**：主 agent 直接生成关键帧图，不依赖 subagent 完成视频 Track 帧图部分。

## 其他已知错误

| 错误码 | 根因 | 解法 |
|--------|------|------|
| `2013` + `voice_setting emotion` | `emotion` 不在 `voice_setting` 支持字段 | 删除 `emotion` 字段 |
| `40001` | 微信公众号 token 过期 | 用 `stable_token` 刷新 |
| `1004` | API key 认证失败 | 检查 Bearer token 格式 |
| `2056` | TTS 日额度耗尽 | 等待整点重置，无需改代码 |
