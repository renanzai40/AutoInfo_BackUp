# 🔧 Gate F: 已有草稿 brand-cta 走偏批量修复（from `automedia-content-repair`，2026-06-02 实测 9 项目）

## 🔧 Gate F: 已有草稿 brand-cta 走偏批量修复（from `automedia-content-repair`，2026-06-02 实测 9 项目）

> **何时启用本 Gate**：5-13/5-24 时代老项目（已知 6/6 有 brand-cta 走偏）推到 `draft_uploaded` 之前必走；或 brand-cta-review Gate 跑失败需修复后重跑。
> **与 brand-cta-review Gate 的区别**：brand-cta-review 审查新草稿，本 Gate 修复老草稿。两者同源（零容忍项一致），但触发时机不同。

### 触发条件（任一即加载）

1. 项目 `status=in_flight` 准备推到 `draft_uploaded`
2. 草稿里 grep 出 `贯维科技`（非`壹目贯维`）/ `合规审核` / `翻译系统` / `AI 翻译` / `Token 成本` / `政经分析` 等走偏词
3. brand-cta-review Gate 失败需修复后重跑

### 5 步工作流（强制顺序，**修缺陷 ≠ 改进内容**）

> **2026-06-02 教训**：本 Gate 是"修缺陷"不是"改进内容"，不违反"已交付项目不改进"铁律。修品牌名/走偏词/CTA 段 vs 改已交付视频是两码事。

| Step | 动作 | 输出 |
|------|------|------|
| **1. 扫描 5 平台草稿** | `01_content/drafts/{platform}/*.md` 全文 grep `CHECK_WORDS` | 每个文件的走偏词清单（命中=0 才跳过本 Gate） |
| **2. 应用 `fix_brand_cta_v3`** | `scripts/fix_brand_cta_v3.py` 自动修复 | 5 平台草稿更新（修前**必备份**到 `/tmp/audit_backup_<date>_<task>/`） |
| **3. 残留检查 + 品牌身份段补全** | grep `贯维孤立` / `重复品牌名` / `贯维科技残留` + 末尾追加 "壹目贯维——AI 内容生产公司"段 + 小红书加 `#壹目贯维` 标签 | 5 平台全部干净 |
| **4. 4 gates 验证** | 跑 G1 humanizer + G2 copy-review + G3 brand-cta + G4 format，写 `04_review/review_log.json` | 全 4 gates 通过才能进 Step 5 |
| **5. 推送 wechat 草稿箱** | `safe_upload_wechat.py` 4 步硬门控（pre_check + self_check + upload + log） | `publish_log.json` 标 `draft_uploaded` |

**必查项清单（6 项零容忍）**：
- [ ] `grep "贯维科技"` = 0
- [ ] `grep "壹目贯维"` ≥ 1
- [ ] `grep "合规审核|翻译系统|AI 翻译|Token 成本|政经分析|投资标的"` = 0
- [ ] 末尾 1500 字含 "AI 内容生产公司"
- [ ] 末尾 1500 字含 CTA 动作词
- [ ] 小红书结尾有 `#壹目贯维` 标签

### 真实项目目录结构（2026-06-02 教训：不要假设路径）

> ⚠️ 路径假设 = 整个扫描推算 0 命中。第一次扫描用错误路径，结果 0 个项目有草稿——所有结论反过来。第二次用真实路径才看到 28 个项目齐全。
>
> 真实路径：`01_content/drafts/{wechat,xiaohongshu,zhihu,bilibili,tiktok}/{md,html,txt}`；`03_subtitle/subtitle.srt` **或** `03_video/subtitle.srt`（两个都查）；`05_publish/publish_log.json`（不是 `04_publish`——v2.1 升级时改的）
>
> **强制**：每次接手新 AutoMedia 项目**先用 `ls` 实际看**目录结构，不要靠记忆/假设。

### 关键坑（修复后必知）

- **修复前必备份**：`/tmp/audit_backup_<date>_<task>_fix_brand_cta/`
- **bilibili/tiktok 视频脚本**：元注释里的"扫码"等词不是真 CTA，**不替换**
- **`requests.post(json=...)` 触发 unicode escape 乱码**（2026-06-03 实测 9 项目）：必须用 `safe_upload_wechat.py` 4 步硬门控（`data=json.dumps(payload, ensure_ascii=False).encode("utf-8")`）
- **publog.status 与 platforms.wechat.status 必须同步**：user 标 published 时只改 platforms 不改顶层 = `compute_status` 推算错
- **subagent 跑完整流水线会超时 (600s 不够)**：subagent 适合"补素材不跑上传"等小任务；主 agent 跑 gates + wechat 上传

> 📖 完整 6 项目修复实录（9 in_flight → draft_uploaded 流水线 5h 实测）：见 `references/automedia-content-repair-2026-06-02.md`

### 相关 skills

- `brand-cta-review`（审查阶段）
- `wechat-upload-checklist`（8 步上传清单）
- `wechat-official-account-publisher`（upload_draft.py 上传脚本）
- `safe_upload_wechat.py`（4 步硬门控，2026-06-03 落地，防 unicode escape）

---
