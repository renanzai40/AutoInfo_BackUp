# 支持文件

## 支持文件

| 文件 | 作用 |
|------|------|
| `scripts/full_qa_checker.py` | 6项全量QA执行器，生产中+内部QA共用 |
| `scripts/pipeline_orchestrator.py` | 强制门控流水线引擎 |
| `scripts/copy_review_gate.py` | **文案三阶Gate强制检查**：humanizer → copy-review → brand-cta-review。自动检查 04_review/ 目录，文件缺失则抛 Exception，Pipeline STOP。[使用手册](references/copy-review-gate-usage-2026-05-22.md) |
| `scripts/fix_brand_cta_v3.py` | **（2026-06-02 from `automedia-content-repair`）** 已交付老草稿 brand-cta 走偏批量修复函数：5 平台全文替换"贯维科技→壹目贯维" + 走偏业务词→AI 内容生产 + 末尾追加"壹目贯维——AI 内容生产公司"段 + 小红书加 `#壹目贯维` 标签。CLI: `python3 scripts/fix_brand_cta_v3.py <project_id>`。**修前必备份**到 `/tmp/audit_backup_<date>_<task>/` |
| `scripts/gen_inline_images.py` | **（2026-06-15 新增）** PIL 信息卡片生成器 — 一键生成内文配图。运行：`python3 scripts/gen_inline_images.py <project_dir>`。含 data_card/list_card/quickview/insight_card 4 种模板 |
| `AutoMedia/scripts/auto_blog_publish.py` | **（2026-06-22 新增）** 博客自动发布 — MDX生成+自动deploy。对应Gate B0 |
| `hooks/pre_send_whisper_check.py` | 全音频转写 + MD5持久化 |
| `references/business-topic-repetitiveness-20260601.md` | 业务款话题集中度问题：TOP20 中35%为AI视频相关，过滤逻辑+非AI视频候选列表 |
| `references/score-correlation-v3-2026-05-24.md` | 评分算法v3：七层关键词分级 + 新加权公式 + 典型话题新旧评分对比 |
| `references/feishu-api-send-2026-05-25.md` | **（2026-05-25 新增）** cron 独立脚本直接调用飞书 REST API 发送消息的正确方式（避免 `repr()` 格式化导致的 230001 错误）；含已确认的群ID/私聊ID |
| `references/cron-job-schema-2026-06-01.md` | **（2026-06-01 新增）** 4 个 cron job schema 陷阱（deliver format / repeat schema / M3 upgrade / print redaction），含 Watchdog 自报告 transcript + 修法 A/B/C/D 选项分析 |
| `references/cron-watchdog-pattern-2026-06-04.md` | **（2026-06-04 from `automedia-cron-watchdog`）** 09:30 watchdog 完整执行报告模板 + `wdog_alert.json` schema + diagnosis/recommended_actions 结构 + 与 cron 作业 Schema Gate 的配合关系 |
| **`references/whisper-mp3-srt-verification-2026-06-05.md`** | **（2026-06-05 V5 Gate 新增）** mp3 vs SRT 文本错配根因案例（session 113223 时代 mp3 ≠ SRT）+ Whisper pre-send 验证流程（tiny 模型 30s 内出结果）+ 关键词覆盖率比对算法（阈值 80%）+ 6-05 v10 实战案例（alphabet/openai mp3 Whisper 转写 100% = SRT 文本）+ 触发条件速查表 + 工具链清单。**V5 Gate 实施必加载** |
| **`references/cron-silent-noop-patterns-2026-06-06.md`** | **（2026-06-06 follow-up，3 个 m3 脚本本身的 fix）** 主文件 `cron-silent-noop-patterns.md` 已涵盖 4 大类反模式 + 4 步诊断手册。本文件新增 3 个 m3 任务核心脚本 bug：Bug 5 `judge_topics_angle.py --source Tavily,AIHOT` 默认值静默过滤中文平台 159 条 / Bug 6 L355 `sys.exit(0 if stats["fail"] == 0 else 1)` 让 145 ok + 7 fail 看起来全失败 / Bug 7 `judge_angles_cron.sh` wrapper 不显式传 `--source` 依赖默认值。**触发：改 `judge_topics_angle.py` / 改 `judge_angles_cron.sh` / 排查 m3 任务行为** |
| `references/automedia-content-repair-2026-06-02.md` | **（2026-06-02 from `automedia-content-repair`）** 6 个老项目（0424_rare-earth-leak 等）完整 brand-cta 走偏修复实录 + 9 in_flight → draft_uploaded 完整流水线 5h 实测 + unicode escape 乱码 9 项目修复全过程 |
| `references/lorai-cta-error-2026-05-26.md` | CTA 文案错误案例：Lorai 原始 CTA"AI营销工具"与品牌定位不符，附正确版本 |
| `references/copy-review-gate-usage-2026-05-22.md` | copy-review Gate 使用手册 |
| `references/copy-review-common-patterns.md` | copy-review 高频问题速查：过度绝对表述/公益科普CTA缺失/小红书品牌标签 |
| `references/gate-script-pitfalls-2026-06-01.md` | **（2026-06-01 新增）** Gate 脚本 9 个高频踩坑：HTML parser / em-dash 中文比例 / 数字+空格 / 平台 CTA 关键词差异 / 图占位必须真生成 / f-string 反斜杠 / 弯引号 / User-Agent 下载 / subagent 报告路径 |
| `references/architecture-drift-patterns.md` | Skill 系统性架构偏移模式：技能写了但工作流未调用、平行实现分化。包含审计脚本和恢复协议。 |
| `references/inline-image-generation-notes.md` | **（2026-06-15 新增）** PIL 信息卡片法生成内文配图的技术参考 + 2026-06-15 实战数据 |
| `references/full-qa-vs-sampling-2026-05-19.md` | 全量QA vs 抽样QA详细论证 |
| `references/tts-input-purity-and-srt-timing-2026-06-12.md` | **🆕 2026-06-12** TTS 输入须为纯净口播文本（禁止段标题）+ SRT 须用 Whisper 精确时间戳而非字数比例分配 |
| `references/mtv-project-2026-05-20.md` | MTV独立创作项目：视频+翻唱MiniMax全家桶攻略 |
| `references/workflow-p0-refactor-2026-06-05.md` | **（2026-06-05 P0 改造）** 5 项 P0 改造详情 + Selection Reuse Decision Gate + Reuse Boundary Checklist + SRT 缺失门控 + Multi-session Lock（session_lock.py 踩坑）+ V3 Content Semantic Match + 重做决策树 + 6-05 引流款 brand_new 5 段脚本设计 |\n| `references/cover-generation-notes.md` | **（2026-06-10 新增）** 封面图生成策略：ComfyUI 路径 + 500 故障处理 + PIL 文字封面 fallback 代码 + 4 种规格对照表 |
| `references/tts-srt-sync-2026-05-26.md` | TTS+SRT同步铁律 / 飞书发送路径规范（2026-05-26固化） |
| `references/auto-media-hot-collection-2026-05-28.md` | **（from `auto-media-hot-collection`）** 话题池采集系统：流1热搜+流2Tavily+流3AIHOT三层过滤+Layer1域名黑名单+Layer1.5标题正则黑名单 |
| `references/auto-media-workspace-consolidation-2026-06-02.md` | **（2026-06-02 新增）** Workspace consolidation 模式：Remotion out/ 旧视频 + 顶层旧项目 → archive/ 标准化结构。5 步法 + 自动化脚本 + 孤儿兜底方案 |
