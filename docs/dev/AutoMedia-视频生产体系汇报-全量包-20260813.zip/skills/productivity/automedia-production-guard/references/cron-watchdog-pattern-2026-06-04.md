# AutoMedia Cron Watchdog 详细执行模式（2026-06-04 落地）

> 来源：原 `automedia-cron-watchdog` skill 的完整 4 步执行细节 + 9 个 Pitfalls + 报告模板。
> 已合并摘要到 `automedia-production-guard` SKILL.md **Cron 健康检查 Watchdog** 段。
> 本文件保留完整执行脚本模式 + `wdog_alert.json` schema 详细 + 5 步工作流代码。

---

## 1. 读 jobs.json 探查 schema（实测 2026-06-01）

```python
import json
from pathlib import Path

JOBS_FILE = Path("/home/renanzai/.hermes/profiles/content/cron/jobs.json")
jobs = json.loads(JOBS_FILE.read_text())

# 关键发现：健康字段在顶层，不在 last_run 嵌套下
for j in jobs:
    print(f"id: {j.get('id')} | last_status: {j.get('last_status')} | "
          f"last_run_at: {j.get('last_run_at')}")
    print(f"  schedule: {j.get('schedule')} (type: {type(j.get('schedule')).__name__})")
    print(f"  last_error: {j.get('last_error')}")
    print(f"  last_delivery_error: {j.get('last_delivery_error')}")
```

**输出格式**（每行一个 job）：
```
id: maintenance_01 | last_status: ok | last_run_at: 2026-06-04T07:31:20+08:00
  schedule: {'kind': 'cron', 'expr': '30 7 * * *', 'display': '30 7 * * *'} (type: dict)
  last_error: None
  last_delivery_error: None
```

⚠️ **不要去 `j['last_run']['status']` 找，全是 None**。

---

## 2. 健康判定函数（完整版）

```python
def assess(j):
    if not j:
        return "missing"
    last_status = j.get('last_status', 'never')
    last_err = j.get('last_error') or ''
    last_delivery_err = j.get('last_delivery_error') or ''
    if last_status == 'never':
        return "never_ran"
    if last_status == 'ok' and not last_err and not last_delivery_err:
        return "healthy"
    if last_status == 'ok' and last_delivery_err:
        return "delivery_failed"
    if last_status in ('failed', 'error', 'crashed'):
        return "execution_failed"
    return f"unknown:{last_status}"
```

---

## 3. 交叉验证输出文件存在

每个目标 job 在 cron 输出目录应有今日 md 落盘：

```
/home/renanzai/.hermes/profiles/content/cron/output/<job_id>/<date>_<HH-MM-SS>.md
```

**`last_status=ok` 但输出文件不存在 → 异常**（任务可能走了空路径或被误标 ok）。**`last_status=ok` + 输出文件存在 + `last_delivery_error=null` = 真健康**。

---

## 4. 写告警 / 归档（关键生命周期）

### 4.1 写告警（failure 路径）

```python
import json
from datetime import datetime, timezone, timedelta

now = datetime.now(timezone(timedelta(hours=8)))
alert = {
    "schema": "automedia.wdog_alert.v1",
    "generated_at": now.isoformat(),
    "watchdog_job_id": "wdog_auto_media",
    "watchdog_run_at": now.isoformat(),
    "summary": {
        "total_monitored": 3,
        "healthy": 0,         # ← 计数
        "delivery_failed": 0,
        "execution_failed": 0,
        "note": "...",
    },
    "jobs_monitored": [...],   # 3 个目标 job
    "jobs_extra": [...],       # 08:05 等附加跟踪
    "diagnosis": {...},        # 错误码 + 根因假设
    "recommended_actions": [...],
    "actionable_command_suggestion": "hermes cron run <id>",
}
with open('/home/renanzai/.hermes/profiles/content/cron/wdog_alert.json', 'w') as f:
    json.dump(alert, f, ensure_ascii=False, indent=2)
```

### 4.2 归档（healthy 路径）—— 关键陷阱

> ⚠️ **如果今天全部健康但 `wdog_alert.json` 还是昨天留下的失败告警**，cron delivery 会把昨天的失败当新告警重复推送（false alarm）。**必须先归档昨天的，再不写今天的**。

```python
import os
now = datetime.now(timezone(timedelta(hours=8)))
alert_path = '/home/renanzai/.hermes/profiles/content/cron/wdog_alert.json'
if os.path.exists(alert_path):
    backup = f"{alert_path}.resolved.{now.strftime('%Y%m%d_%H%M%S')}"
    os.rename(alert_path, backup)
    # 不要 delete——保留取证，方便趋势分析
```

**为什么 rename 不 delete**：
1. 保留历史取证（同一 chat_id 反复失败时直接 diff 看趋势）
2. rename 后 cron delivery 不会再匹配（`wdog_alert.json` 不存在 → 无投递）
3. 外部脚本想看「最近一次失败」直接 glob `wdog_alert.json.resolved.*` 最新一份

---

## 5. 报告模板（agent final response）

```markdown
# AutoMedia Watchdog Report — <YYYY-MM-DD HH:MM +08>

**轮询结果：3/3 目标任务全部健康** ✅   (or `1/3 失败，详情见告警文件`)

| Slot | Job | ID | 状态 | 最近运行 |
|---|---|---|---|---|
| 07:30 | AutoMedia 07:30 新鲜度维护 | maintenance_01 | ✅ healthy | 2026-06-02 07:31:20 |
| 08:00 | AutoMedia 08:00 热点采集 | 143d19e69a7c | ✅ healthy | 2026-06-02 08:03:23 |
| 08:30 | AutoMedia 08:30 话题池汇总推送 | 7671da210b69 | ✅ healthy | 2026-06-02 08:32:41 |

(08:05 audit_08x05 附加观察 — 如有失败/恢复，提一句)

## 关键变化
(对比上一份 wdog_alert.json 写的变化)

## 告警文件动作
(写了 wdog_alert.json / 归档了 .resolved.<ts> / 不需要操作)

## 结论
(all healthy / N failures，需不需要人工干预)
```

---

## 6. Feishu 错误码诊断（详细版）

仅 `delivery_failed` 路径需要查（详见 `cron-deliver-format` skill）：

| 错误码 | 含义 | 典型原因 | 修法 |
|--------|------|----------|------|
| `[230002]` | Bot/User can NOT be out of the chat | bot 被移出群 / 应用无 `im:message` 权限 | `send_message action='list'` 拿当前 profile 真实 chat_id 重写 `deliver` |
| `[230001]` | Your request contains an invalid request parameter | `origin` 解析失败 / ID 格式错 | 检查 `chat_id` 格式（私聊/群 ID 不能混用） |
| `[230020]` | Bot is not in the chat | 同 [230002] 但具体路径不同 | 同上 |
| `[230021]` | chat_id invalid | chat_id 是其他 bot 的 ID | 重新查 `send_message action='list'` |

**`intermittent_chat_id` 模式**（关键诊断信号）：同一 chat_id 在某个 job 失败、另一个 job 成功 → 不是 chat 完全失效，是飞书侧/单次抖动。

---

## 7. 与 cron 作业 Schema Gate 的关系

| 维度 | Schema Gate（预条件）| Watchdog（监控层）|
|------|----------------------|------------------|
| 时机 | 改 jobs.json 之前 | 每日 09:30 cron 触发 |
| 检查 | 字段类型 / 必填字段 | 运行时健康（status + 输出文件 + delivery） |
| 失败处理 | 阻止改 jobs.json | 写 wdog_alert.json 触发飞书告警 |
| 谁执行 | main agent | watchdog cron job |
| 修复 | 直接改 jobs.json | 调查运行时 + 必要时改 jobs.json |

**两者缺一不可**：
- Schema Gate 防"任务根本定义错"
- Watchdog 防"任务定义了但实际没跑成功"

---

## 8. 与脚本版 watchdog 的区别

| 维度 | 脚本版（`scripts/cron_watchdog.py`）| LLM 版（本 skill）|
|------|-----------------------------------|---------------------|
| 触发 | 独立 cron job | 09:30 agent 收 prompt |
| 探查深度 | `last_status` + 时间窗口 | `last_status` + `last_error` + `last_delivery_error` + 输出文件 + 错误码诊断 |
| 输出 | stdout | `wdog_alert.json` + markdown 报告 + 飞书推送 |
| 用途 | 轻量监控 | 富文本告警 + diagnosis + recommended_actions |

**两者监控目标相同**（07:30/08:00/08:30 + 08:05 附加）。LLM 版输出 `wdog_alert.json` 由 cron delivery 系统捡起飞书推送。

---

## 9. 相关文件

- `automedia-cron-watchdog/SKILL.md`（已合并 → 父 skill `automedia-production-guard`）
- `automedia-production-guard/references/cron-job-schema-2026-06-01.md` — Schema Gate 4 个陷阱
- `~/.hermes/profiles/content/cron/jobs.json` — 任务定义
- `~/.hermes/profiles/content/cron/wdog_alert.json` — 告警产物
- `~/.hermes/profiles/content/cron/output/wdog_auto_media/` — watchdog 历史输出
- `cron-deliver-format` skill — Feishu 错误码 + 私聊/群 ID 格式
