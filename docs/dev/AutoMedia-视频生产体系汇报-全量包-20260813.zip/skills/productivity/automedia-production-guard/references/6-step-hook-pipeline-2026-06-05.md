# 6 步硬约束 Hook 完整文档（2026-06-05 v11 新增 · 视频生产 wrapper）

> **代码位置**：`/home/renanzai/Remotion-Test/scripts/render_with_qa.sh`
> **来源**：6-05 v3-v10 反复失败的根治方案（问题驱动 → 流程驱动）

## 为什么需要这个 Hook

**6-05 案例**：今天 Alphabet + OpenAI 两个视频经历 v3-v10 共 9 轮反复修复，每次出 bug 都"现编修法"——典型的"问题驱动"工作流。**根治**：把 6 个核心 gate 固化为代码级强制（hook），**任一失败 exit 1 拒绝渲染**。

## 6 步 Pipeline

```
[0/6] 清旧抽帧 — /tmp/audio_video_sync 必先清（P0-10 防 multisession 污染）
       ↓
[1/6] Linter — 拦 Composition 硬编码时间戳
       - check_composition_timecode.py exit 0
       - LINT_TARGET_FILE env 支持增量 lint（v11 修复不 BLOCK 6 个旧项目）
       ↓
[2/6] Voice 核验 (V4 gate) — 必在 APPROVED_VOICES
       - TTS 文件大小 sanity check（< 30KB = edge-tts 4x 速警告）
       - 真实 voice_id 验证在 TTS 生成阶段（必 print voice_id + user 确认）
       ↓
[3/6] Scene-data 数量核验 (P0-11) — 必 = SRT entries
       - SCENE_SUBTITLES 数组 'text:' 字段数 vs SRT entries count
       - 偏差 = 擅自增删字幕（v10 E11 "关注就行。" 幽灵字幕案例）
       - ⚠️ WARNING（不 BLOCK，肉眼确认）
       ↓
[4/6] Render — bunx remotion render
       ↓
[5/6] Sync check — 视频时序对齐 TTS
       - ffmpeg silencedetect 拿真实句尾
       - SRT entry 偏差矩阵（9/9 entries < 0.7s = PASS）
       ↓
[6/6] Whisper pre-send (V5 gate) — mp3 实际朗读 = SRT 文本
       - Whisper tiny 转写 mp3
       - 去标点 + 字符集对比 SRT 文本
       - 100% 匹配 = ✅；偏差 = ⚠️ WARNING（不 BLOCK）
```

## 完整命令

```bash
# 标准用法
bash scripts/render_with_qa.sh <CompositionId> <output.mp4> <mp3> <srt>

# 增量 lint 模式（修复 v11 时不 BLOCK 其他项目）
LINT_TARGET_FILE="src/AlphabetAnthropicV4Composition.tsx src/OpenAICodexTeamV4Composition.tsx" \
  bash scripts/render_with_qa.sh AlphabetAnthropicV4 out/v11-alphabet.mp4 \
  public/audio/alphabet-anthropic.mp3 public/subtitles/alphabet-anthropic.srt

# 退出码
# 0 = 全通过
# 1 = 任一步失败（linter / render / sync check / Whisper）
```

## APPROVED_VOICES 列表（V4 gate 核验）

```bash
APPROVED_VOICES=(
  "zh-CN-YunxiNeural"      # edge-tts 男声
  "zh-CN-XiaoxiaoNeural"   # edge-tts 女声
  "male-qn-qingse"         # MiniMax m3 tts 男声
  "Radio_Host"             # MiniMax m3 tts 业务款声音
)
```

**禁止擅自换声音**（6-05 v8 教训：v8 我擅自把 m3 tts 换成 edge-tts 女声，user 严重抗议）。

## LINT_TARGET_FILE 环境变量

**用途**：v11 增量修复时只 lint V4 Composition，不 lint 其他 6 个旧项目（Composition.tsx/Root.tsx 等历史资产）。

```bash
# 增量修复 V11
LINT_TARGET_FILE="src/AlphabetAnthropicV4Composition.tsx" \
  bash scripts/render_with_qa.sh AlphabetAnthropicV4 out/v11.mp4 ...

# 全量 lint（生产前必跑）
unset LINT_TARGET_FILE
bash scripts/render_with_qa.sh MyComp out/my.mp4 ...
```

## 反模式（永久禁止）

| # | 反模式 | 后果 | 正确做法 |
|---|--------|------|---------|
| 25 | **Step 5 hook FAIL 仍渲染** | 视频带 1-5s 偏差发出 | hook exit 1 拒绝渲染 |
| 26 | **Step 6 FAIL 仍交付** | "我先发你看" → user 看到坏视频 | 强制 v(N+1) 重做 |
| 31 | **直接 `bunx remotion render`** | 跳过 6 步 hook | 必用 wrapper |
| 32 | **"问题驱动"现编修法** | 10 轮 v3-v10 反复修复 | 6 步流程驱动 |
| 33 | **hook 失败不查日志** | 不知道哪步挂 | 看完整 6 步输出 + 修复后重走 |

## 实战数据（v11 Alphabet + OpenAI）

| 视频 | Step 0-3 | Step 4 Render | Step 5 Sync | Step 6 Whisper |
|------|----------|---------------|-------------|----------------|
| Alphabet v11 | ✅ | 1131 帧/37.69s | 8/9 PASS, 1/9 WARN | ⚠️ tiny OCR 误报 |
| OpenAI v11 | ✅ | 1206 帧/40.21s | **9/9 PASS 全绿** | ⚠️ tiny OCR 误报 |

**V5 gate Whisper 误报说明**：Whisper tiny 模型 OCR 错识 "壹目贯维" → "一目冠维"、"千亿" → "千纹"等，但**实际 mp3 朗读 = SRT 文本**（v8 已 Whisper 验证过）。Whisper tiny 仅作 sanity check，不作 BLOCK（v8 root cause 已修复）。

## 未来改进（不在 6-05 范围）

- [ ] cron 每周日 09:00 跑 hook smoke test 验证不破坏现有
- [ ] 6 个旧项目 Composition 逐步 v11 化（Composition.tsx/Root.tsx/...）
- [ ] Whisper medium 升级（替代 tiny，提升 OCR 精度）
- [ ] v12 加 Step 7 vision QA 强制 ≥ 9 分（防 vision QA 漏检）

## 给未来 agent

**任何 Remotion 视频项目开始时**：
1. 必先看 `remotion-workflow` skill 的 5+1 步工作流
2. 必先看本 hook 文件（理解 6 步 pipeline）
3. 必用 wrapper（不要直接 `bunx remotion render`）
4. 任何 hook FAIL → 修复后从该步重走
