# 封面图生成笔记（2026-06-10）

## 策略

1. **ComfyUI 本地生图** — 优先尝试 `sd15_txt2img.json` 工作流
2. **PIL 文字封面 fallback** — ComfyUI 不可用/报错时

## ComfyUI 路径（2026-06-10 实测）

```bash
cd ~/.hermes/profiles/content/skills/creative/comfyui

# 1. 检查 server 是否运行
curl http://127.0.0.1:8188/system_stats

# 2. 检查可用模型（只有 v1-5-pruned-emaonly 时用 sd15 工作流）
comfy model list

# 3. 先检查依赖（避免 500）
python3 scripts/check_deps.py workflows/sd15_txt2img.json

# 4. 运行
python3 scripts/run_workflow.py \
  --workflow workflows/sd15_txt2img.json \
  --args '{"prompt": "...", "seed": -1, "steps": 25}' \
  --output-dir /tmp/covers
```

## 500 Internal Server Error（实测踩坑）

**根因**：workflow 引用了未安装的 custom node。`check_deps.py` 可检。有时 500 是 server 内部随机状态。

**处理**：确认 server 日志 → 只有 SD1.5 时别用 sdxl/flux 工作流 → 持续 500 则 fallback 到 PIL

## PIL Fallback

```python
from PIL import Image, ImageDraw, ImageFont
def make_cover(title, subtitle, accent, out, w=1280, h=720):
    img = Image.new("RGB", (w, h), (15, 15, 35))
    d = ImageDraw.Draw(img)
    fp = "/home/renanzai/Remotion-Test/public/fonts/TeHei_Heavy.otf"
    try: f = ImageFont.truetype(fp, 48)
    except: f = ImageFont.load_default()
    d.text((w//2+2, h//2-30+2), title, fill=(0,0,0), font=f, anchor="mm")
    d.text((w//2, h//2-30), title, fill=(255,255,255), font=f, anchor="mm")
    if subtitle:
        d.text((w//2, h//2+30), subtitle, fill=accent, font=f, anchor="mm")
    d.text((w//2, int(h*0.88)), "壹目贯维", fill=accent, font=f, anchor="mm")
    img.save(out, "JPEG", quality=92)
```

## 规格

| 文件 | 尺寸 | 用途 |
|------|------|------|
| `cover_16x9.jpg` | 1280×720 | 公众号thumb、知乎、B站 |
| `cover_9x16.jpg` | 864×1152 | 抖音 |
| `cover_3x4.jpg` | 864×1152 | 小红书竖版 |
| `cover_1x1.jpg` | 864×864 | 小红书方图 |
