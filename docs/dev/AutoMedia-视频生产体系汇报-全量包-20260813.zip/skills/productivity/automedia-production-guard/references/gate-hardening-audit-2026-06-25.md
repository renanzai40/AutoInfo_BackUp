# 🔒 Gate 硬化审计矩阵（2026-06-25 全链路审计结果）

## 🔒 Gate 硬化审计矩阵（2026-06-25 全链路审计结果）

### 硬化等级定义

| 级 | 含义 | agent 能绕过吗 |
|----|------|--------------|
| **L1** | 独立脚本 + exit code 拦，不通过无输出 | ❌ 不能 |
| **L2** | 有独立脚本但 agent 必须记着调 | ⚠️ 能 |
| **L3** | 只写在 doc 里，无执行代码 | ✅ 轻松跳过 |
| **❌** | 连脚本都不存在 | ✅ 完全无约束 |

### 文案前 Gates（3个）

| Gate | 等级 | 有脚本? | 今天执行 |
|------|------|--------|---------|
| R0 Research | L3 | ❌ 无 | 做了 |
| PT Template Selection | L3 | ❌ 无 | 做了 |
| PD Platform Diff | L3 | ❌ 无 | 做了 |

### 文案 Track Gates（7个）

| Gate | 等级 | 有脚本? | 今天执行 |
|------|------|--------|---------|
| **C0 Fact Check** | **L3** | **❌ 无 — $50B 编造未被拦截** | ❌ 跳过 |
| **C1 Humanizer** | **L3** | **❌ 无 — 用户纠错后补** | ❌ 跳过 |
| C2 Copy Review | L2 | `copy_review_gate.py` import-only | ❌ 走过场 |
| C3 Brand CTA | L3 | ❌ 独立脚本 | ⚠️ 部分 |
| C3.5 脚本结构 | **L1** | 嵌入 `tts_produce.py` | ✅ |
| II 内文配图 | L2 | `gen_inline_images.py` CLI | ✅ |
| B0 博客 | L2 | `auto_blog_publish.py` CLI | ✅ |

### 视频 Track Gates（10个）

| Gate | 等级 | 有脚本? | 今天执行 |
|------|------|--------|---------|
| VQ 设计质量 | L2 | `validate_layout.py`（仅布局序） | ❌ 跳过 |
| V0 Lint | **L1** | `bun x hyperframes lint` | ✅ |
| **V1 Vision QA** | **❌** | **无** | ❌ 跳过 |
| **V2 Pre-send Whisper** | **❌** | **无** | ❌ 跳过 |
| **V3 语义匹配** | **❌** | **无** | ❌ 跳过 |
| V4 TTS 品牌声音 | **L1** | 嵌入 `tts_produce.py` — 但agent可绕过 | ❌ 绕过 |
| V5 mp3 vs SRT | L2 | `verify_mp3_vs_srt.py` | ❌ 跳过 |
| V6.5 字幕检查 | ❌ | 无 | N/A |

### Agent 绕过 Gate 的反模式（2026-06-25 审计总结）

| 反模式 | 今天表现 | 根因 | 可拦截点 |
|--------|---------|------|---------|
| **「先跑通渲染，Gate 回头补」** | TTS 绕过 tts_produce.py、V1/V2/V3 全跳过 | 亢奋→想看到画面→快速产出模式 | Pre-render Gate exit code 拦截 |
| **「subagent summary 就够了」** | $50B 编造未被检、品牌缺失未被检 | 信任惯性→不 verify | verify_draft_output.py 入口拦截 |
| **「我知道流程，就不用走了」** | Copy Review 第一次报告全✅ | 熟练度陷阱→直觉跳过 | copy_review_gate.py CLI 化 |
| **「工作量太大，挑重点做」** | 21 Gate 只看前几个 | 清单太长→心理放弃 | 分段拦截（入口/出口各一个） |

缺口发现方式（可复用）：
1. `skills_list` 全量列现有 skill → 对照 9 个生产环节（选题→研究→元数据→脚本→文案→图片→音频→审核→发布）
2. 抽查 3 个近期项目，看实际产物 vs 文档差距（完整文件清单 + 内容质量 + 素材完整性）
3. 审查 production scripts 中每个环节的标准化程度（有模板/部分模板/全临场/缺失）
4. 输出矩阵 → 按影响排序

完整审计记录：`references/content-quality-audit-2026-06-15.md`

---
