# 重做时全量标准不降级

## 重做时全量标准不降级

重做时不得降低QA要求：
- 音频重建 → Whisper全音频验证（不是30秒采样）
- SRT重建 → 每Entry逐字检查（≤45字，时间轴连续）
- 脚本重写 → Brand CTA全平台检查（视频+公众号+知乎+小红书）
- 视频重建 → Vision QA逐Entry覆盖（全部Entry中点帧）
- 任意一项QA失败 → Pipeline STOP，不发用户
