# Gate II: 内文配图 — ComfyUI 生成

> **2026-06-25 用户纠错**：内文配图通过 **ComfyUI** 本地生成（SD 1.5），**禁用 MiniMax**。MiniMax 仅用于音乐和视频生成。

## 一键生成

```bash
python3 scripts/gen_ui_images.py --project <project_dir>
```

自动产出：
- `01_content/drafts/wechat/images/wechat_img_{1,2,3}.png`（512×512）
- `02_images/cover/cover_16x9.png`（640×360）
- `02_images/cover/cover_9x16.png`（360×640）
- `02_images/cover/cover_3x4.png`（512×512）

## ComfyUI 状态

| 项目 | 值 |
|------|-----|
| 地址 | `http://127.0.0.1:8188` |
| Checkpoint | `v1-5-pruned-emaonly.safetensors` |
| GPU | GTX 1660 Ti 6GB |
| 工作流 | sd15_txt2img（直接 REST API） |
| 启动 | `comfy launch --background` |

## 调用方式

直接通过 REST API 提交 prompt，不依赖 `run_workflow.py`。
steps=20, cfg=7, negative: `blurry, low quality, distorted, watermark, text, signature`

## 参考

- `creative/comfyui` skill — 完整文档和工作流
- `automedia` skill → `references/comfyui-image-generation-for-automedia.md`
