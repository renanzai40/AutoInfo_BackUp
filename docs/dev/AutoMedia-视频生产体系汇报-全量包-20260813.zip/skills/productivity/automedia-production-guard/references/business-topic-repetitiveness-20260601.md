# 业务款话题集中度问题 · 2026-06-01

## 问题现象

用户反馈：「AI视频生成相关都做过类似的，能不能换一批」

业务款话题池 TOP20 中，「AI视频生成」相关话题占比高达 35%（7/20 条），导致：
- 用户感觉话题重复，缺乏新鲜感
- 推送的话题质量虽高，但多样性不足
- 品牌内容差异化价值无法体现

## 根因分析

业务款评分公式：
```
score = (heat_score/10)*0.10 + correlation_score*0.60 + freshness_score*0.30
```

correlation_score 权重 = 0.60（最高），而爬取的话题中「AI视频生成」类话题的相关性得分系统性偏高，因为：
1. 话题池爬取源（Tavily/知乎/微博）大量覆盖 AI 视频工具类内容
2. 「AI视频生成」与壹目贯维品牌核心能力「AI内容生产」语义高度相关
3. 高相关性 → 高评分 → 排序靠前 → 过度曝光

这不是 bug，是**评分公式与话题池内容分布共同作用的结果**。

## 实测数据（2026-06-01 08:30 pool.db 查询）

业务款 approved 池共 132 条，TOP20 关键词分布：

| 排名 | 综合评分 | 来源 | 标题 | 是否AI视频 |
|------|---------|------|------|-----------|
| 1 | 7.8096 | Tavily | 我的第一支AIGC短片 | ⚠️ |
| 2 | 7.8093 | Tavily | AI视频生成 | ⚠️ |
| 3 | 7.8088 | Tavily | 排行榜型：2024年最佳AI视频生成工具推荐 | ⚠️ |
| 4 | 7.2100 | Tavily | 字节豆包登顶视觉榜、Qwen代码反超 | ✅ |
| 5 | 7.2094 | Tavily | 视频生成 - AI快讯网 | ⚠️ |
| 6 | 7.2093 | Tavily | 自家AI太强人类会危险：封印Mythos大模型 | ✅ |
| 7 | 7.2090 | Tavily | 大模型头部玩家吸干一级市场 | ✅ |
| 8 | 7.2089 | Tavily | 自家AI太强人类会危险_2 | ✅ |
| 9 | 7.2087 | Tavily | 视频生成，影视制作，参考生成 | ⚠️ |
| 10 | 7.2087 | Tavily | AI大模型重大利好，宁王入股 | ✅ |
| 11 | 7.2086 | Tavily | DeepSeek官宣永久降价 | ✅ |
| 12 | 7.2086 | Tavily | 视频生成_雷峰网 | ⚠️ |
| 13 | 7.2082 | Tavily | 价格屠夫DeepSeek再度出手 | ✅ |
| 14 | 7.2073 | 知乎 | 俄银行采购中国芯片为大模型提供算力 | ✅ |
| 15 | 7.2040 | Tavily | 牛津微软等9机构发布音视频智能综述 | ✅ |
| 16 | 7.2027 | Tavily | 音视频智能综述_新浪财经 | ✅ |
| 17 | 7.2020 | Tavily | 完善大模型评测体系提升中国话语权 | ✅ |
| 18 | 7.2020 | Tavily | OpenAI首席执行官奥尔特曼 | ✅ |
| 19 | 6.6099 | Tavily | 同期美国AI大模型周调用量3.76万亿 | ✅ |
| 20 | 6.6090 | Tavily | 邮件营销 - AI工具网 | ❌ 低相关 |

**AI视频相关：7 条（35%）**
**非AI视频类优质候选：13 条**

## 推荐的非AI视频类业务款话题

从 TOP20 过滤掉 AI视频相关后，适合推荐：

1. **字节豆包登顶视觉榜、Qwen代码反超**（AI竞争格局）
2. **自家AI太强人类会危险：封印Mythos大模型**（AI安全/监管）
3. **大模型头部玩家吸干一级市场**（AI投资趋势）
4. **DeepSeek官宣永久降价**（价格战/商业策略）
5. **俄银行采购中国芯片为大模型提供算力**（出海/算力）
6. **牛津微软等9机构发布音视频智能综述**（学术报告解读）
7. **完善大模型评测体系提升中国话语权**（政策/标准）
8. **OpenAI首席执行官奥尔特曼**（人物/公司动态）

## 解决方向

1. **短期（推荐策略）**：TOP20 推荐前过滤 AI视频关键词，展示多样化候选
2. **中期（话题池扩展）**：主动采集更多非AI视频的业务话题（出海/本地化/内容运营/数据营销）
3. **长期（评分公式调优）**：对高相关话题做 diversity penalty，避免同一关键词的话题连续出现

## 参考命令

```python
import sqlite3
conn = sqlite3.connect('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db')
cur = conn.cursor()

# 查 business 池全部 approved 并打分
cur.execute("""
    SELECT topic_id, title, heat_score, correlation_score, freshness_score, source
    FROM topics
    WHERE status='pending' AND review_status='approved' AND category='business'
    ORDER BY (heat_score/10)*0.10 + correlation_score*0.60 + freshness_score*0.30 DESC
""")
# ... 在 Python 中过滤非AI视频类，打印结果
```
