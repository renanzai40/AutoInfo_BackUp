# AutoMedia Workspace Consolidation Pattern

**触发场景**：AutoMedia 项目交付后，workspace 出现"散落文件"或"out/ 目录堆积旧版本"。

**模式来源**：2026-06-02 审计任务 H 任务（同时合并 E 任务的"项目归档"操作）。

---

## 散落文件的两个来源

### 来源 A：Remotion `out/` 目录堆积

**症状**：
```
/home/renanzai/Remotion-Test/out/
├── deepseek.mp4, deepseek_v2.mp4, ... v7.mp4    (7 个版本)
├── lorai.mp4, lorai_v2.mp4, ... v7.mp4          (7 个版本)
├── hy-memory.mp4, hy-memory_v1_compressed.mp4, ...  (4 个版本)
├── minimax-m3.mp4, minimax-m3_v1_known_audio_desync.mp4
├── runway.mp4, runway_v2.mp4                      (孤儿)
├── trapdoor.mp4, v2, v3                          (孤儿)
├── test_deepseek.mp4                             (孤儿)
```
25+ 个 mp4 混在一起，无项目归属 = 维护噩梦。

### 来源 B：顶层 `projects/` 旧项目未归档

**症状**：
```
/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/
├── 20260424_1610_rare-earth-leak/
├── 20260424_1616_ai-translation-multiagent/
├── ...
├── 20260526_deepseek-75-discount/                ← 已交付，未归档
├── 20260526_lorai-marketing/                     ← 已交付，未归档
├── archive/                                       ← 仅 2 个新项目
├── delivery/
```

---

## 正确归档结构

每个归档项目必须有**标准子目录**（参考 `archive/20260601_201455_minimax-m3/`）：

```
projects/archive/<项目名>/
├── 00_project_info/         项目元数据
├── 01_content/              文案草稿（按平台分）
├── 02_images/               帧图 + 封面
├── 02_tts/                  TTS 源文件
├── 03_subtitle/             SRT 字幕
├── 03_video/                ← 视频文件最终归宿（含所有版本）
├── 04_review/               4 个平台的 review 报告
├── 05_publish/              publish_log.json
└── remotion/                （可选）Remotion 项目副本
```

---

## 合并操作 5 步法（实测可行）

### Step 1：盘点 + 映射

```bash
# 列出 out/ 所有 mp4
ls /home/renanzai/Remotion-Test/out/*.mp4

# 对每个 mp4 前缀，匹配 archive/ 或顶层 projects/ 项目
# 例: out/deepseek.* → projects/archive/20260526_deepseek-75-discount/03_video/
# 例: out/runway.*  → projects/archive/_orphans/ (无项目目录)
```

### Step 2：cp 不 mv（双保险）

```python
import shutil
from pathlib import Path

# 先 cp 到 archive（out/ 保留作回退）
shutil.copy2(src, archive_target)
# 验证 archive 存在 + 字节数匹配
assert archive_target.exists()
assert archive_target.stat().st_size == src.stat().st_size
```

### Step 3：验证 archive 副本

```bash
# 抽查字节数 + 用 ffprobe 确认视频可播放
md5sum <archive_target> <src>  # 必须一致
ffprobe <archive_target>  # 不能有 "moov atom not found" 错误
```

### Step 4：删 out/ 原文件

```python
# 验证 archive 副本存在后才删
archive_target = Path(archive_path)
if not archive_target.exists():
    raise FileNotFoundError(f"archive 副本不存在,不能删 {src}")

src.unlink()
```

### Step 5：更新 publish_log.json video_path

如果原 video 路径在 publish_log.json 中被引用（如 m3 的 `/home/renanzai/Remotion-Test/out/minimax-m3.mp4`），必须同步更新到 archive 路径。

**schema 兼容字段**（publish-log-schema v2）：
- `current.video_path` → 相对路径如 `03_video/minimax-m3.mp4`
- `current.video_path_full` → 绝对路径如 `/mnt/d/.../archive/20260601_201455_minimax-m3/03_video/minimax-m3.mp4`

---

## 孤儿文件处理

无项目目录的 mp4（如 `runway_*.mp4` / `trapdoor_*.mp4`）：

**方案 A**（推荐）：建 `_orphans/` 目录兜底
```
projects/archive/_orphans/
├── runway.mp4, runway_v2.mp4
├── trapdoor.mp4, trapdoor_v2.mp4, trapdoor_v3.mp4
├── test_deepseek.mp4
```

**方案 B**（不推荐）：删除孤儿 = 丢失内容

**方案 C**（更深入）：追溯 orphan 来自哪个 `delivery/` 子项目，建对应项目目录

---

## 路径引用规范化

**黄金规则**：项目内部的视频引用都用**相对路径**（`03_video/xxx.mp4`），不要用绝对路径。

**为什么**：
- 项目目录可能在不同 WSL/macOS 路径下（`/mnt/d/...` vs `/home/renanzai/...`）
- 项目可能在不同 profile 之间迁移
- 绝对路径硬编码 = 迁移时全断

**publish_log.json 模板**（v2 schema）：

```json
{
  "current": {
    "video_path": "03_video/minimax-m3.mp4",
    "video_path_full": "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/archive/20260601_201455_minimax-m3/03_video/minimax-m3.mp4"
  }
}
```

两个字段都填：相对路径给人看 + 绝对路径给程序用。

---

## 实测案例（2026-06-02 H 任务）

**搬移统计**：
- 7 个 deepseek_*.mp4 → archive/20260526_deepseek-75-discount/03_video/
- 7 个 lorai_*.mp4 → archive/20260526_lorai-marketing/03_video/
- 2 个 minimax-m3_*.mp4 → archive/20260601_201455_minimax-m3/03_video/
- 4 个 hy-memory_*.mp4 → archive/20260601_201455_hy-memory/03_video/
- 2 个 runway_*.mp4 → archive/_orphans/
- 3 个 trapdoor_*.mp4 → archive/_orphans/
- 1 个 test_deepseek.mp4 → archive/_orphans/

**总计**：26 文件，328.9MB 整理完毕。

**耗时**：3.43 秒（cp + 验证 + rm 自动化）。

**备份**：`/tmp/audit_backup_20260602_taskH/move_log.txt` 记录所有 mv 路径。

---

## 自动化脚本（推荐封装）

```python
#!/usr/bin/env python3
"""workspace_consolidate.py — 把 Remotion-Test/out/ 的旧视频归档到 projects/archive/"""

import shutil, sys
from pathlib import Path

OUT_DIR = Path("/home/renanzai/Remotion-Test/out")
ARCHIVE_BASE = Path("/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/archive")

# 项目前缀 → archive 项目名映射（手动维护或从 pool.db 查）
PROJECT_MAP = {
    "deepseek": "20260526_deepseek-75-discount",
    "lorai": "20260526_lorai-marketing",
    "minimax-m3": "20260601_201455_minimax-m3",
    "hy-memory": "20260601_201455_hy-memory",
    # 孤儿前缀不放这里,自动进 _orphans/
}

ORPHAN_PREFIXES = ["runway", "trapdoor", "test_"]

for f in sorted(OUT_DIR.glob("*.mp4")):
    prefix = f.name.split("_")[0].split(".")[0]  # 粗略前缀
    target_dir = None
    for k, v in PROJECT_MAP.items():
        if f.name.startswith(k):
            target_dir = ARCHIVE_BASE / v / "03_video"
            break
    if not target_dir:
        for k in ORPHAN_PREFIXES:
            if f.name.startswith(k):
                target_dir = ARCHIVE_BASE / "_orphans"
                break
    if not target_dir:
        print(f"⚠️ {f.name} 无映射,跳过")
        continue
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / f.name
    if target.exists():
        print(f"  skip {f.name} (archive 已存在)")
        continue
    shutil.copy2(f, target)
    print(f"✓ {f.name} → {target}")
    f.unlink()  # 验证 archive 后删除原文件
```

**未来用法**（每月跑一次）：
```bash
python3 workspace_consolidate.py --dry-run  # 先看会动什么
python3 workspace_consolidate.py            # 真跑
```

---

## 教训（2026-06-02 实战）

1. **out/ 长期不管 = 必然爆仓**——每个新项目都会留 1-7 个版本
2. **顶层 projects/ 旧目录 = 视觉债**——用户问"workspace 怎么这么乱"时这就是源头
3. **不要用 mv 直接搬**——用 cp + 验证 + rm 三步，万一 archive 副本坏了原文件还在
4. **路径规范化**——publish_log.json 永远用相对路径 + 绝对路径双字段
5. **孤儿兜底**——`_orphans/` 目录是必备基础设施，没有它就丢内容
