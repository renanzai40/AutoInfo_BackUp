---
name: automedia-production-guard
description: "壹目贯维视频生产强制门控 + 全量QA体系。**必须加载此skill才能启动视频生产。** 25个强制Gate：G0.5(双重检查) + 文案前3(R0/PT/PD) + 文案9(PQ,AF,C0-C3,C3.5,B0) + 视频11(V0-V7,V4.5,VQ,V6) + 生命周期3(L1-L3)。**V16(2026-07-11)**：新增 Gate PQ(Prompt Quality) + Gate AF(AI Flavor Check)。配套 `content-generation-prompt` skill（通用注入块+平台层注入块）和 `check_output_ai_flavor.py` post-generation gate。**V15(2026-06-26)**：G0.5 扩展为双重检查——(A)话题去重查重+(B)项目初始化完整性检查。新增 init_project.py（新建项目的唯一入口）+ check_production_init.py（预检+自动修复）。**V14(2026-06-25)**：新增 Gate V6(Composition QA)，固化最小字号20px、最小上下边距300px、禁止重复class属性、禁止CSS语法错误。**V13(2026-06-25)**：单 Profile 三层自强化架构——Shell Hook（自动拦截）+ Self-Check（自查）+ TODO（纪律）。加入 Gate 鲁棒性分类框架（L1/L2/L3/❌）。**V12(2026-06-22)**：新增 Gate B0(博客自动发布)+auto_blog_publish.py脚本。**V10(2026-06-15)**：新增 Gate R0/PT/PD/II/VQ。"
version: 1.9
author: Hermes Agent for renan
license: MIT
tags: [automedia, qa, pipeline, gate, full-coverage, hermes-workspace, lifecycle, publish-log-schema]
---

## 三层自强化架构（V13 · 2026-06-25）

> **单 profile 下无法物理不可绕过，但三层加码使跳过成本 > 走流程成本。**
> 
> ```
> 层1: TODO 工具（纪律层）   → 每段开工前列7-10步 TODO，逐项标记
> 层2: Shell Hook（拦截层）  → pre_render_hook.sh 自动拦截未签入 Gate 的 render
> 层3: Audit（检测层）       → audit_pipeline.py 扫描 Gate 产物，缺口暴露给用户
> ```

### 层1: TODO 纪律

**开工前必做**：写新话题 → 立即调用 `todo()` 列项，含以下必含项：

```
1. 话题调研 + 元数据展开
2. 5 平台文案（差异化）
3. Fact Check（C0）+ Humanizer（C1）+ Copy Review（C2）
4. Brand CTA 审核（C3）
5. 视频 Composition
6. 逐 Gate 签入（见下）
7. 渲染 + 交付
```

**每完成一项**：`todo(merge=True, ...status='completed')`

**禁止**：不列 TODO 直接开工，或列完后不标记直接跳过。

### 层2: Shell Hook 拦截

`config.yaml` 配置：

```yaml
hooks_auto_accept: true
hooks:
  pre_tool_call:
    - command: /home/renanzai/.hermes/profiles/content/scripts/pre_render_hook.sh
      matcher: "terminal|execute_code"
      timeout: 15
```

**Hook 行为**（`scripts/pre_render_hook.sh`）：
1. 每次 `terminal()` / `execute_code()` 调用前自动触发
2. 匹配命令含 `hyperframes render` → 查项目下 `.gates_status.json`
3. 缺少任何视频 Gate（V0/VQ/V4/V5/V1/V3）→ 返回 `{"action": "block", ...}` → render 命令被拦截
4. 不触发 render 的命令 → 静默放行（exit 0）

**绕过检测**：Hook 只检查 `terminal|execute_code` tool。如果用 execute_code 内嵌 `subprocess.run(["bun", ...])` 可绕过。此路径依赖 layer 3 审计发现。

### 层3: Audit Pipeline 自检

**每完成一个 Track 结尾**（或 render 前）调用：

```bash
# 全量审计（文案 + 视频 + 生命周期）
python3 scripts/audit_pipeline.py --project <project_dir>

# 仅视频 Track（render 前快速检查）
python3 scripts/audit_pipeline.py --project <project_dir> --track video

# 输出 JSON 格式
python3 scripts/audit_pipeline.py --project <project_dir> --json
```

**Gate 签入流程**：

```bash
# 每通过一个视频 Gate（V0/VQ/V4/V5/V1/V3），立即可选签入
scripts/signoff_gate.sh --project <project_dir> --gate V0
scripts/signoff_gate.sh --project <project_dir> --gate VQ
scripts/signoff_gate.sh --project <project_dir> --gate V4
scripts/signoff_gate.sh --project <project_dir> --gate V5
scripts/signoff_gate.sh --project <project_dir> --gate V1
scripts/signoff_gate.sh --project <project_dir> --gate V3
```

gate 签入文件 `.gates_status.json` 被 pre_render_hook 读取以决定是否放行 render。

## 🛑 Gate G0.5：生产前双重检查（2026-06-15 + 2026-06-26 扩展）

> **触发原因**：
> - 2026-06-15 事故：已交付的话题被重复生产
> - 2026-06-26 事故：已交付的话题因 pool.db 未同步，次日再次出现在推送中
>
> **核心铁律**：启动生产前，必须确认两件事——(A) 话题没有重复项目；(B) 项目初始化完整。

### 检查 A：话题已有项目检查（2026-06-15 新增）

话题关键词变了但实质相同（如「Anthropic IPO」和「Anthropic 秘密申请上市」），先查 pool.db + projects/ 目录，避免重复制作。

**强制检查流程：**

```bash
# 1. 在 pool.db 搜话题
sqlite3 /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Pool/pool.db \
  "SELECT topic_id, title, status FROM topics WHERE title LIKE '%关键词%' LIMIT 5"

# 2. 在 projects/ 目录搜近似项目目录
ls -la /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/ | grep -i "关键词"

# 3. 如果找到项目且 status=pending/awaiting_publish/published
#    → 直接使用已有产物，禁止重做
#    → 需要告知用户：这个话题已有项目，可以直接交付

# 4. 如果没找到项目 → 正常进入生产 Gate 链
```

**反模式**（永久禁止）：
- ❌ 用户提一个之前做过的话题时，不检查就直接新开项目
- ❌ 话题关键词变了但实质相同（如「Anthropic IPO」和「Anthropic 秘密申请上市」）
- ❌ 新开项目做得不如上一版还发出去

**与 topic-pool 的关系**：pool.db 中 topic 的 status=selected/approved 并不代表已有视频项目。本 Gate 检查的是 `projects/` 目录，不是 pool.db。

### 检查 B：项目初始化完整性检查（2026-06-26 新增）

新项目启动时，确认初始化步骤没有被跳过。如果跳过，自动修复。

**强制流程（加载 automedia-production-guard 后在 R0 前必跑）：**

```bash
# 检查 00_project_info 是否存在 + pool.db 是否同步
python3 ~/.hermes/profiles/content/scripts/check_production_init.py \
  --project-dir /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/<project_id>
```

**check_production_init.py 检查项：**
1. `00_project_info/project_info.json` 存在 + `topic_id` 非空
2. `source` 字段非空（pool/manual）
3. pool.db 中对应 topic 的 `status` 是否为 `selected`（仅 pool 来源）

**自动修复策略：**
- 缺少 `project_info.json` → 调用 `init_project.py` 补建
- pool.db 未同步 → 调用 `pool_sync.py` 更新

**返回码**：0=通过（含修复后通过），1=无法修复

**反模式**（永久禁止）：
- ❌ 直接用 `mkdir` 建项目目录绕过 init_project.py
- ❌ 选题确认后直接 R0 调研，跳过初始化
- ❌ project_info.json 的 `topic_id` 留空或编造 `manual_xxx`

## 8 个强制 Gate（文案前 3 + 文案 5 + 视频 8 + 生命周期 3）

> **⚠️ 2026-06-15 更新**：从原 5 Gate 扩展为 8 Gate（新增 Gate R0/PT/PD/II），对应补全的 6 个生产缺口（R1-R6）。

**文案前 Gates（话题确认后·脚本写作前，强制顺序）：**

| Gate | 时机 | 检查项 | 失败后果 |
|------|------|--------|---------|
| **Gate R0: Research** | 话题确认后，脚本前 | 加载 `automedia-research` skill → 查 pool.db 的 `source_url` → web_extract 读原文 → 提取关键数字/引文/实体 → 产出 `00_research/sources.json` + `research_notes.md`。**source_url 为空时**：web_search 补充 2-3 个权威来源。 | → **Pipeline STOP，不得进入脚本阶段** |
| **Gate PT: Template Selection** | Research 后，脚本前 | 判定话题类型（业务款/引流款/热点/争议）→ 加载 `content-prompt-templates` skill → 按类型选差异化结构（4段式/5段式/B2B映射/争议框架）→ 输出给脚本生成 prompt | → **Pipeline STOP，不得无模板进入脚本** |
| **Gate PD: Platform Differentiation** | 脚本后，5 平台草稿前 | 加载 `platform-differentiation` skill → 按 5 平台各自的受众/篇幅/语气/结构/图片要求确认写稿方向 → subagent prompt 注入平台差异要求（非统一 prompt） | → **Pipeline STOP，不得无差异化写草稿** |

**文案 Track Gates（并行进行，不得跳过）：**

| Gate | 时机 | 检查项 | 失败后果 |
|------|------|--------|---------|
| **Gate C0: Fact Check** | 脚本写作后,Humanizer前 | **5-step自动化事实核查**：加载 automedia-fact-check skill → 追溯 source_url 原始来源 → 数字/百分比/金额交叉验证 → 日期/时间线一致性校对 → 引文/语录原文核对 → 实体/专名消歧。输出 04_review/fact_check_report.md。 | → **Pipeline STOP** |
| **Gate C1: Humanizer** | 文案生成后 | 9类AI写作模式扫描 | → 文案打回修改 |
| **Gate C2: Copy-review** | Humanizer后 | 五轮结构审查 | → 文案打回修改 |
| **Gate C3: Brand CTA** | Copy-review后 | 零容忍项：品牌身份/过渡同向/禁止词/视频+文章同步/小红书品牌标签 | → **Pipeline STOP** |
| **🆕 Gate C3.5: 视频脚本结构检查（2026-06-22 新增）** | Copy-review后、TTS前 | **tiktok/script.txt 和 bilibili/script.txt 必须含品牌/CTA段落**——检查脚本是否包含 `【品牌留痕】` 或 `【低门槛闭环】` 或 `【结尾引导】` 段（即最后一段是品牌CTA），且 `壹目贯维` 出现 ≥ 1 次。**根因（2026-06-22 事故）**：subagent 委托时约束过紧导致视频脚本被压缩为纯新闻简报，无品牌。 | → **Pipeline STOP，脚本打回重写** |
| **Gate C4: Wechat-checklist + G5 HTML 硬门控** | 公众号草稿生成前 | 标题≤9字/digest≤20字/HTML格式干净 + **G5（2026-06-05 加）：HTML 标签 `<p>/<h2>/<blockquote>` 数量必 ≥ 5 + 无 Markdown 触发器（head -5 必查 `#` / `##`）**。详见 `wechat-upload-checklist` skill Pitfall 13/14 + G4/G5 章节。 | → 立即修标题再继续，**不得带着超限标题进下一步** |
| **Gate II: Inline Image** | 文案锁定前、发布前 | **5 平台配图完整性检查**：公众号正文配图≥3、知乎≥2、小红书≥1。图片文件存于 `02_images/assets/`，每图 >5KB 防损坏。详见下方「🆕 Gate II: Inline Image」节。 | → **Pipeline STOP，补图再发** |
| **🆕 Gate B0: 博客自动生成（2026-06-22 新增）** | 文案锁定后（Gate II 之后） | 判断当前项目是否适合官网博客：查看项目类型（业务款优先）、内容深度（zhihu > 2000B）、topic 是否已存在于官网。达标的自动调用 `scripts/auto_blog_publish.py` 生成 MDX 到官网博客目录。详见下方「🆕 Gate B0: 博客自动发布」节。 | → **不阻塞 Pipeline**（博客是增值发布，不防碍视频/社交发布），仅记录生成结果 |

**Gate C3 零容忍项 Checklist（逐项核验，全部通过才放行）**：
- [ ] 品牌身份：全文任何位置说清"壹目贯维是一家AI内容生产公司"
- [ ] 无 CTA：尾部无任何行动引导 → Pipeline STOP
- [ ] 品牌名未出现：全文搜不到"壹目贯维" → Pipeline STOP
- [ ] 视频+文章不同步：视频脚本过了但公众号/知乎/小红书没同步 → Pipeline STOP
- [ ] 小红书使用了诱导话术："评论区扣1/私信领资料/点赞过100" → Pipeline STOP
- [ ] **小红书正文结尾无 `#壹目贯维` 品牌话题标签**（2026-05-22 review发现：极易漏检，零容忍）
- [ ] **CTA 内容与视频正文描述的能力一致**：视频讲"内容产能"但 CTA 说"AI营销工具实际测评" → CTA 与视频内容/品牌业务不符，Pipeline STOP
- [ ] **CTA 关键词与品牌业务相关**：壹目贯维 = AI内容生产，CTA 提到"AI营销工具"与品牌定位不匹配 → Pipeline STOP
- [ ] 全文无禁止词（投资情报/金融分析等）
- [ ] **tiktok/script.txt 和 bilibili/script.txt 必须含品牌**（尾部品牌留痕段，不能豁免）。视频脚本不是纯粹的口播稿——它是 TTS 的输入，TTS 说什么视频就说什么。视频脚本无品牌 = 整条视频零品牌价值（2026-06-22 新增）

**视频 Track Gates（设计 + 渲染 + QA，强制顺序）：**

> **2026-06-15 新增 Gate VQ**：视频设计质量门控，在写 composition 前强制选主题+定布局+多样性检查。解决"5段全同一布局"问题。

| Gate | 时机 | 检查项 | 失败后果 |
|------|------|--------|---------|
| **Gate VQ: Design Quality** | 写 composition 前 | **选主题**（theme-palettes.json 36 主题或 OD 8 主题）→ **定布局**（visual-layouts.md 6 种类型）→ **布局多样性**：5 段 ≥ 4 种不同布局，相邻不得重复 → **动画多样性**：≥ 2 种 easing 函数 → **主题变量**：≥ 6 个 CSS 变量。详见下方「🆕 Gate VQ 完整规范」。 | → **Pipeline STOP，不写 composition** |
|| Gate V0: Lint + HyperFrames Validate | HTML composition 写完后、render 前 | **HyperFrames 版**：`bun x hyperframes lint` 通过（需 0 errors）才放行。详见 `video-production/hyperframes-workflow` 的 Gate 链。 | → **Pipeline STOP，不渲染** |
|| **Gate V6: Composition QA** | render 前（V0 后） | **`scripts/check_composition_qa.py` 通过**：<br>(1) 所有 font-size ≥ 20px<br>(2) 前景元素 top ≥ 300px<br>(3) 前景元素 top ≤ 1620px（距底 ≥ 300px）<br>(4) 无重复 class 属性<br>(5) 无 CSS 语法错误（`=` 代替 `:`）<br>详见下方「Gate V6 完整规范」。Hook 自动检测，V6 缺失时自动运行。 | → **Pipeline STOP，不渲染** |
|| Gate V1: Vision QA | 视频烧录后 |
| Gate V2: Pre-send Whisper | 发文件前 | Whisper全音频内容验证 + **MD5=QA时同一文件** | → **Pipeline STOP，不发** |
| Gate V3: Content Semantic Match | render 后 + V1/V2 通过后 | **视频内容必须含今天话题关键词**——SRT 文本 + Whisper 转写 + 5 段视觉 OCR 全部比对 pool.db 当前 topic 动态关键词清单（**不是写死的通用词**）。详见本节下方"V3 语义级 Verify 完整规范"。 | → **Pipeline STOP，不发** |
| **🆕 Gate V6.5: 字幕实际渲染检查（2026-06-06 新增，2026-06-15 更新）** | render 后 + Gate V1 同一阶段 | **vision QA 抽 8 帧用 PIL 像素亮度法验证字幕区域**（画面底部 1/6，亮像素 >30 = 有字幕）。**6-06 案例**：配音师+红果短剧首次渲染后 7/8 帧字幕区域亮像素=0（仅 S5 末帧有字幕）→ 根因 `segments[i].subtitles: []` 空数组。**6-15 补充**：必须先确认中文字体 `wqy-zenhei.ttc` 可用（`ls /usr/share/fonts/truetype/wqy/wqy-zenhei.ttc`），否则字体缺失时 drawtext 静默使用 fallback 拉丁字体，CJK 字符渲染为不可见方块 → 同样会导致 8/8 帧字幕区域亮像素=0。**修复**：烧录前必查字体存在 + `scripts/burn_subtitles.py` 强制使用 `fontfile=/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc`。 | → **Pipeline STOP，不交付，必须重渲染** |
| **🆕 Gate V4: TTS 声音品牌资产核验（2026-06-05 v10 新增）** | TTS 调用后、render 前 | **TTS 声音是品牌资产**——必查：(1) 旧项目用什么 TTS 引擎 + 什么 voice_id？(2) 今天是否保持？(3) 工具是否可用？**禁止擅自换 TTS 引擎/声音/语速/情绪/厂商/性别**。详见下方"V4 TTS 声音品牌资产"节。 | → **Pipeline STOP，必先问 user** |
| **🆕 Gate V4.5: TTS 输入品牌核验（2026-06-22 新增）** | TTS 调用前 | **TTS 输入文本必须含品牌名**——grep 输入文本 `壹目贯维` >= 1 次，否则 STOP。输入文本须为纯净口播文字（已去段标题标记），但品牌 CTA 必须保留。**根因（2026-06-22 事故）**：60-80字脚本被压缩到无品牌，TTS 输入直接取此文本，导致视频全程无品牌提及。 | → **Pipeline STOP，补齐脚本品牌段再 TTS** |
| **🆕 Gate V5: mp3 vs SRT 内容核验（2026-06-05 v10 新增）** | mp3 生成后、烧字幕前 | **mp3 朗读文本必须 100% = SRT 原文**——session 113223 时代踩坑：mp3 是"GPT5 工具红利期"旧内容，SRT 是"Alphabet 800亿"新内容，两套完全错配。必跑 `whisper <mp3>` + diff SRT 文本（容忍 ASR 误识别 ±20%）。详见下方"V5 mp3 vs SRT 文本核验"节 + `subtitle-srt-generation` skill P0-1 铁律。 | → **Pipeline STOP，重新生成 mp3** |

**Token 不是约束**：全量 QA 消耗 10 倍 token 也接受，质量比 token 成本重要得多。

## 验收 Gate

- [ ] `00_research/sources.json` 存在且非空
- [ ] `00_research/research_notes.md` 含至少 3 条关键数据/引用
- [ ] 脚本中每个数字都可从上述文件追溯
- [ ] `source_url` 不可用时，已注明补救来源

#### 反模式

- ❌ 跳过调研直接写脚本
- ❌ web_extract 失败了就不调研（改用 lynx/curl 降级）
- ❌ 原文数据模糊时编造精确数字
- ❌ 只创建目录不填内容（空壳 research 等于没做）

## 🆕 Gate II 完整规范：Inline Image（2026-06-15 新增）

#### 配图数量标准

| 平台 | 最低配图数 | 存放路径 |
|------|-----------|---------|
| 微信公众号 | ≥3 | `02_images/assets/wechat_*.png` |
| 知乎 | ≥2 | `02_images/assets/zhihu_*.png` |
| 小红书 | ≥1 | `02_images/assets/xiaohongshu_*.png` |
| 抖音 | 0 | 视频自带画面，无需额外配图 |
| B站 | 0 | 同上 |

#### 图片规范

- **尺寸**：宽 640-900px，统一居中
- **格式**：JPG/PNG/WebP
- **最小文件大小**：每图 >5KB（<5KB = 损坏/空白图）
- **内容**：与对应段落内容相关（非通用素材图）
- **来源**：优先 ComfyUI 本地生成，需 Vision QA 通过。**B2B 数据卡片推荐 PIL 信息卡片法**（见 `references/inline-image-generation-notes.md`）——速度更快、文字精确可控、内容相关性强。直接运行 `python3 scripts/gen_inline_images.py <project_dir>` 一键生成所有配图

#### 生成命令（可复用脚本）

```bash
# 一键生成（默认 wechat:3, zhihu:2, xiaohongshu:1）
python3 /home/renanzai/.hermes/profiles/content/skills/productivity/automedia-production-guard/scripts/gen_inline_images.py <project_dir>

# 自定义平台配图数
python3 gen_inline_images.py <project_dir> --platforms wechat:2,zhihu:1,xiaohongshu:2

# 仅预览
python3 gen_inline_images.py <project_dir> --dry-run
```

**脚本特性**：
- 自动从 `00_research/research_notes.md` 提取 Key Numbers 填充卡片内容
- 4 种模板（data_card / list_card / quickview / insight_card），按平台自动分配
- 品牌色统一（#4361ee 科技蓝紫）、壹目贯维水印
- **CJK 字体**：强制使用 wqy-zenhei.ttc（DejaVuSans 无中文，踩坑经验）
- 每图 >5KB 自动重试（quality=98）

**快捷方式**（推荐，与 Gate II 检查同文件位置）：
```bash
# 直接从项目目录执行
python3 ~/.hermes/profiles/content/skills/productivity/automedia-production-guard/scripts/gen_inline_images.py <project_dir>
```

#### 检查命令

```bash
# 配图完整性检查
python3 << 'EOF'
import os, sys
errors = []
project_dir = "/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects/<project_id>"
assets_dir = os.path.join(project_dir, "02_images", "assets")

for plat, min_count in [("wechat", 3), ("zhihu", 2), ("xiaohongshu", 1)]:
    pattern = f"{plat}_"
    files = [f for f in os.listdir(assets_dir) if f.startswith(pattern) and os.path.getsize(os.path.join(assets_dir, f)) > 5120]
    if len(files) < min_count:
        errors.append(f"{plat}: 需≥{min_count}图，当前{len(files)}")
    for f in files:
        if os.path.getsize(os.path.join(assets_dir, f)) < 5120:
            errors.append(f"{f} 疑似损坏")

if errors:
    for e in errors: print(f"❌ Gate II: {e}")
    sys.exit(1)
print("✅ Gate II: 内文配图完整性 PASS")
EOF
```

#### 反模式

- ❌ 只检查文件名不检查文件大小
- ❌ 允许"后续再补"（缺失配图必须在文案锁定前生成）
- ❌ 用通用素材图代替与段落相关的配图
- ❌ 配图不经过 Vision QA（可能出现乱码/地图/Logo）

## 执行入口

### TTS 生产（前置 Gate，所有视频生产必经入口）

automedia 管线进入视频生产环节后，TTS 生成的**唯一路径**：

```bash
python3 ~/.hermes/profiles/content/scripts/tts_produce.py \
  --script 01_content/drafts/tiktok/script.txt \
  --text "$(cat 01_content/drafts/tiktok/tts_input.txt)" \
  --output 03_video/audio_voiceover.mp3
# ↑ 内部自动完成：Gate C3.5(脚本结构) → Gate V4.5(品牌核验) → 音频生成 → Gate V4(Whisper验证)
# exit 0 才往下走，exit 1 = Pipeline STOP
```

**禁止**：
- `text_to_speech` 工具
- `edge-tts` 直调（无验证）
- m3 tts 或其他引擎
- 任何未走 `tts_produce.py` 的路径

### 渲染前检查（Gate VQ + V0）

```bash
# Gate VQ: 布局多样性检查（写 composition 后、render 前）
python3 ~/.hermes/profiles/content/scripts/validate_layout.py index.html
# exit 0 放行 / exit 1 STOP

# Gate V0: HyperFrames lint
bun x hyperframes lint
# exit 0 放行 / exit 1 STOP
```

### QA 链路（TTS 通过后执行）

### 🚨 自媒体生产管线 自驱动规则（2026-06-24 固化）

**问题**：agent 完成 content_ready（文案+视频+封面）后停在原地，不继续推进上传/发布。用户追问才补。这不是「用户没说要上传」，是 pipeline 没自驱。

**强制规则**：content_ready 之后，agent 必须**自动推进**以下步骤，不得等用户催：

```
content_ready
  ↓
[自动] 公众号草稿上传 → upload_draft.py（引流款+业务款都做）
  ↓
[自动] Gate B0 博客发布 → auto_blog_publish.py（仅业务款/有干货的）
  ↓
[自动] 通知用户：上传状态 + 发布指引
```

**反模式**（永久禁止）：
- ❌ 做完 content_ready 就说「做好了」等用户提上传
- ❌ 「用户没说要上传公众号」作为不做的理由——管道设计里有这步
- ❌ 「太晚了明天传」——除非用户明确说

### Gate 执行级别（2026-06-24 分类）

解决「doc 写了强制但 agent 跳过」的系统性问题。每个 Gate 按实际执行方式分三级：

| 级别 | 含义 | 例子 | 状态 |
|------|------|------|:----:|
| **L1: 代码拦** | 有独立脚本 + exit code，不通过则下游无法启动 | `tts_produce.py` / `hyperframes lint` | ✅ 硬化 |
| **L2: 脚本可调** | 有独立脚本但 agent 必须记着调 | `validate_layout.py` / `upload_draft.py` / `auto_blog_publish.py` | ⚠️ 半硬化 |
| **L3: doc 依赖** | 只写在 skill 文档里，靠 agent 自觉 | C0/C1/C2 审核门控 | ❌ 未硬化 |

**持续硬化目标**：把 L3 → L2（写脚本），L2 → L1（串进自动链）。
import sys
sys.path.insert(0, '/home/renanzai/.hermes/skills/productivity/automedia/scripts')
from full_qa_checker import FullQAChecker

qa = FullQAChecker(project_dir, topic)

qa.run_srt_check()           # QA1
qa.run_duration_check()      # QA2
qa.run_brand_check()         # QA3
qa.run_vision_qa_setup()     # QA4 前置：提取全部Entry中点帧 → /tmp/vqa_frames.json
# 主agent逐帧送 ComfyUI 截图 + OCR → write_vision_results()
qa.wait_vision_qa_results()  # QA4 核验：全部PASS才通过
qa.run_whisper_check()       # QA5：全音频转写
qa.run_md5_check()           # QA6：MD5追踪

passed, report = qa.get_report()

### 后生产发布（出口 Gate · 管线最后一步）

所有 Gate 通过后、宣布项目完成前，**必经**：

```bash
# 自动：WeChat 上传 + 博客 MDX 生成 + 状态更新
python3 ~/.hermes/profiles/content/scripts/pipeline_post_production.py <project_dir>
# exit 0 放行（失败记录到 publish_log.known_issues，不阻塞管线）
```

**禁止**：
- 在 `pipeline_post_production.py` 未运行的情况下宣布项目完成
- 手动跳过 WeChat 上传（引流款无 wechat 内容也跑——脚本会自动跳过）

### Pipeline Gate 硬化方法论（2026-06-24 固化）

> **根因模式**：多个事故的重复模式是「doc 写了『强制/自动』，但 agent 跳过 = 0」。TTS 乱码、公众号不上传、博客不发布均属此类。**修复不是再写一行 doc，而是把 Gate 变成独立脚本 + exit code。**

**硬化判断标准**：
- ❌ doc 级别：`wechat-upload-checklist ← 强制`（写在管道图里，但 agent 不跑 = 0）
- ✅ 脚本级别：`python3 tts_produce.py --script ... --text ... --output ...`（exit code 拦，调一次执行一次）

**硬化步骤**（发现 doc-only Gate 时执行）：
```
1. 确认该 Gate 的「最后守门位置」（TTS → tts_produce.py / 项目出口 → pipeline_post_production.py）
2. 写独立脚本：输入 → 执行 → exit 0/1
3. 在「执行入口」段注册为必经步骤
4. 删除 doc 中对应的「强制」文字（现在代码是强制）
5. smoke test 验证 exit code 拦截
```
```


---

## 章节导航（JiT Loading）

> 主文件保留核心流程（407 行）。以下章节已移至 references/，执行到对应 Gate 时按需加载：

| 章节 | Reference | 行数 |
|------|-----------|------|
| ⚠️ Subagent "timeout" 不等于 "未完成"（2026-06-05 实测固化） | `references/subagent-timeout-vs-incomplete.md` | 169 |
| 核心原则（2026-05-19 固化，2026-05-20 追加政治话题CTA守则） | `references/core-principles.md` | 167 |
| Vision QA 逐 Entry 覆盖原理 | `references/vision-qa-entry-coverage.md` | 135 |
| 🆕 项目生命周期 Gate (Gate L) — 2026-06-02 新增 | `references/gate-l-lifecycle.md` | 126 |
| Gate V3 完整规范：Content Semantic Match（2026-06-05 P0-5 新增） | `references/gate-v3-semantic-match.md` | 123 |
| MTV 独立创作项目（MiniMax 视频+音乐全家桶） | `references/mtv-independent-projects.md` | 111 |
| 🆕 Gate V5 完整规范：mp3 vs SRT 文本核验（2026-06-05 v10 新增 · P0-13 铁律） | `references/gate-v5-mp3-srt-verification.md` | 88 |
| ⚠️ 2026-05-19 事故教训（永久固化） | `references/incident-2026-05-19-lessons.md` | 84 |
| 🆕 Gate VQ 完整规范：Video Design Quality（2026-06-15 新增） | `references/gate-vq-design-quality.md` | 84 |
| 🆕 Gate C0 完整规范：Fact Check（2026-06-15 新增） | `references/gate-c0-fact-check.md` | 79 |
| 并行双 Track 生产原则（2026-05-19 固化） | `references/parallel-dual-track-principle.md` | 74 |
| ⚠️ Backup-First 铁律（2026-06-02 用户明确要求固化） | `references/backup-first-rule.md` | 74 |
| 教训记录（2026-05-19） | `references/lessons-2026-05-19.md` | 74 |
| Gate E：项目完整性强制检查（交付前 Hard Gate） | `references/gate-e-project-integrity.md` | 73 |
| Gate D：打包完整性检查（交付前 Hard Gate） | `references/gate-d-packaging.md` | 72 |
| ⚠️ 已交付项目不改进铁律（2026-06-02 用户明确纠错固化） | `references/delivered-project-freeze-rule.md` | 69 |
| 🆕 Gate V4 完整规范：TTS 声音品牌资产核验（2026-06-05 v10 新增 · P0-12 铁律） | `references/gate-v4-tts-voice-asset.md` | 68 |
| 🔒 Gate 硬化审计矩阵（2026-06-25 全链路审计结果） | `references/gate-hardening-audit-2026-06-25.md` | 63 |
| 🆕 Cron 健康检查 Watchdog（from `automedia-cron-watchdog`，2026-06-04 daily 09:30） | `references/cron-watchdog-healthcheck.md` | 60 |
| 🔧 Gate F: 已有草稿 brand-cta 走偏批量修复（from `automedia-content-repair`，2026-06-02 实测 9 项目） | `references/gate-f-brand-cta-repair.md` | 58 |
| ❗ LLM-driven job（有 prompt 字段）不需要 script 字段，修正前的老检查会误报 3 个健康 job 为 broken。 | `references/llm-job-no-script-note.md` | 50 |
| ⚠️ "全干"≠"无差别做所有项"（2026-06-02 F 任务反思固化） | `references/all-in-vs-blind-execution.md` | 49 |
| 🆕 Gate B0 完整规范：博客自动发布（2026-06-22 新增） | `references/gate-b0-blog-autopublish.md` | 47 |
| 🆕 Gate R0 完整规范：Research（2026-06-15 新增） | `references/gate-r0-research.md` | 42 |
| Layer 1: Shell Hook 配置 | `references/layer1-shell-hook.md` | 42 |
| 🆕 Gate PT 完整规范：Template Selection（2026-06-15 新增） | `references/gate-pt-template-selection.md` | 42 |
| 🆕 Gate PD 完整规范：Platform Differentiation（2026-06-15 新增） | `references/gate-pd-platform-differentiation.md` | 38 |
| 🆕 V4 新增（2026-06-24 事故固化）：TTS 生产执行路径 + Voice 资产锁定 | `references/gate-v4-tts-execution-path.md` | 37 |
| ⚠️ linter wrapper 全 src/ 扫老的 Composition 触发 FAIL 的绕过方法（2026-06-03 实测） | `references/linter-wrapper-scan-bypass.md` | 36 |
| 支持文件 | `references/support-files.md` | 33 |
| Layer 2: Self-Check 审计协议 | `references/layer2-self-check.md` | 31 |
| 🔧 Content Quality Warning: Pipeline Gap Status（2026-06-15 审计发现 · 2026-06-15 修复更新） | `references/pipeline-gap-status-2026-06-15.md` | 29 |
| ⚠️ Gate 橡皮图章反模式（2026-06-25 用户纠错固化） | `references/gate-rubber-stamp-antipattern.md` | 29 |
| Gate V6 完整规范：Composition QA（2026-06-25 新增） | `references/gate-v6-composition-qa.md` | 27 |
| Cron 作业 Schema Gate（2026-06-01 新增，预条件） | `references/cron-schema-gate.md` | 22 |
| Layer 3: TODO 纪律 | `references/layer3-todo-discipline.md` | 18 |
| 全量 QA 标准（vs 旧抽样法） | `references/full-qa-standard.md` | 17 |
| 🆕 TTS 输入品牌核验（2026-06-22 新增） | `references/gate-v4-tts-brand-check.md` | 16 |
| 🔧 Pre-flight Gate：Cron 健康检查（启动生产链路前必跑，2026-06-06 新增） | `references/preflight-cron-health.md` | 15 |
| 7 项全量 QA 检查 | `references/seven-qa-checks.md` | 12 |
| 已知绕过路径 | `references/known-bypass-paths.md` | 11 |
| ⚠️ 生产路径变更铁律（2026-06-22 新增） | `references/production-path-change-rule.md` | 9 |
| Gate 鲁棒性分类 | `references/gate-robustness-classification.md` | 9 |
| 重做时全量标准不降级 | `references/redo-full-qa-standard.md` | 9 |
| 各层覆盖范围 | `references/layer-coverage.md` | 8 |
| 三层架构 | `references/three-layer-architecture.md` | 8 |
| 全量审计交付物 | `references/full-audit-deliverables.md` | 6 |
| MD5 追踪机制 | `references/md5-tracking.md` | 6 |
