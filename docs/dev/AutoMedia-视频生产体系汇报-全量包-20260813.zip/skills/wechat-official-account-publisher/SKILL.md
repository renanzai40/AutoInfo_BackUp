---
name: wechat-publisher
description: Publish articles to WeChat Official Account (微信公众号) draft box via API. 使用前必须加载本 skill。绝不写内联 requests 上传——所有上传走 scripts/ 目录，禁止自行调用 API。
---

# WeChat Publisher Skill

> ⚠️ **强制规则：上传前必须加载本 skill 和 wechat-upload-checklist。禁止写内联 Python/curl 调试上传。所有上传走 scripts/ 目录。**

## ⚠️ 致命反模式：requests.post(json=payload) — 2026-06-02 实测 9 个草稿全乱码

**禁止任何 inline 写 `requests.post(url, json=payload, ...)`**。`requests` 库 `json=` 参数**默认 `ensure_ascii=True`**，会变 unicode escape 乱码，user 揭穿后明确说"公众号上传有 skill 可以用的"。

**正确路径（4 选 1）**：
1. **推荐**：`python3 /home/renanzai/.hermes/profiles/content/skills/productivity/automedia/hooks/safe_upload_wechat.py --pid <id>` — 4 步硬门控（pre_check + self_check + upload + log）
2. `python3 scripts/upload_draft.py --html <file> --title "..." --thumb-media-id "..." --digest "..."` — 本 skill 自带，已 ensure_ascii=False
3. 手工 `urllib`：`data=json.dumps(payload, ensure_ascii=False).encode("utf-8")`
4. ❌ 任何 `requests.post(..., json=...)` 变体 — 禁止

**检测 hook**（在 `productivity/automedia/hooks/` 下）：
- `verify_published_content.py` — post-verification 扫
- `test_upload_draft_ensure_ascii.py` — unit test
- `safe_upload_wechat.py` — 统一入口

## credential 配置

凭证已配置在 `config.json`：
- AppID: `wx40665d17fc4ed506`
- AppSecret: `26e3f56b6a1fa59cb46b1badc6c51f85`

读取方式：脚本从 `config.json` 读，不需要手动传参。

## 字段限制（实测 2026-05-15）

| 字段 | 硬性限制 | 超出报错 | 正确做法 |
|------|---------|---------|---------|
| `title` | **≤9个中文字符** | 45003 | 截断到9字，用 ASCII `-` `:` 分隔，不用 `｜``—``·` |
| `digest` | **≤20个纯文本字符** | 45004 | 纯中文，不用全角符号 |
| `author` | **留空 `""`** | 45110 | 一定留空，不填品牌名 |

## 自动 Pre-flight Check（强制）

**`upload_draft.py` 已在入口处内建 check，不可绕过。**

每次调用 `upload_draft.py --html ...` 时，脚本自动调用 `pre_upload_check.py`，以下校验未通过则脚本退出、不调用任何 API：

| 检查项 | 失败行为 |
|--------|---------|
| HTML 含 `<think>` 或 `</think>` 标签 | exit 1，打印 "HTML 中仍含 思考 标签" |
| 标题 > 9 个汉字 | exit 1，打印 "标题超限" |
| 标题含 `｜—·` 全角符号 | exit 1，打印 "含禁止字符" |
| 摘要 > 20 字符 | exit 1，打印 "摘要超限" |
| HTML 含完整 `<html>/<head>` | 自动提取 `<body>` 内部内容 |

> **注意**：`--html-content` 直接传内容时 bypass 此检查。仅 `--html <文件路径>` 触发自动校验。

## Workflow

### Step 0 — 检查 publish_log.json（强制）

读取 `<project>/05_publish/publish_log.json`：

```
如果 status == "draft_uploaded" 且存在有效 content_id：
  → 跳过上传说为。草稿已在草稿箱。
  → 除非内容已大幅更新，否则不要重新上传。

如果不存在或 status 不是 draft_uploaded：
  → 继续 Step 1。
```

**每次上传前必做。publish_log.json 不存在 → 正常上传。**

### Step 0b — 检查 Gate 记录（强制，2026-05-28 新增）

读取 `<project>/04_review/review_log.json`：

如果 `review_log.json` 不存在，或任意 Gate 项为 `false`：
  → **禁止上传**。必须先完成 copy-review → brand-cta → humanizer → G4 排版检查，再执行上传。
  → 这是最常见的 Gate 绕过场景：生产链路直接跳到了 Remotion 渲染，跳过了 review step。

### Step 1 — 提取文章内容

从 `01_content/drafts/ai_xxx_content.md` 提取对应平台 section：

- **公众号**：找 `## 二、微信公众号` section（V2.0 版本），跳过 `【初稿 V1.0】` 等标记行
- 保存为 `/tmp/<project>_wechat.md`

### Step 2 — 封面上传

```bash
SKILL=/home/renanzai/.hermes/skills/wechat-official-account-publisher
THUMB_ID=$(python3 $SKILL/scripts/upload_thumb.py 封面图路径)
```

### Step 3 — MD → HTML

```bash
python3 $SKILL/scripts/md_to_html.py /tmp/<project>_wechat.md > /tmp/<project>.html
```

### Step 4 — 上传草稿

```bash
python3 $SKILL/scripts/upload_draft.py \
  --title "标题（≤9字）" \
  --html /tmp/<project>.html \
  --thumb-media-id "$THUMB_ID" \
  --author "" \
  --digest "摘要（≤20字，纯中文）"
```

### Step 5 — 更新 publish_log.json

上传成功后更新 `<project>/05_publish/publish_log.json`：
```json
{
  "topic": "...",
  "platform": "wechat",
  "content_id": "<返回的media_id>",
  "status": "draft_uploaded",
  "manual_action": "后台发布",
  "short_title": "≤9字标题"
}
```

### Step 6 — 告知用户

告知草稿已上传、media_id、后台地址 `https://mp.weixin.qq.com → 草稿箱`

## MiniMax Image API 参考（2026-05-23 新增）

> 详情见 `references/wechat-image-api-quirks-2026-05-23.md`
>
> 关键结论：
> - MiniMax image-01 不支持 4:3，只支持 **3:2**（公众号内文图比例容差接受）
> - 响应格式：`data.image_urls[0]`（不是 `data[0].url`）
> - 凭证路径：`~/.hermes/auth.json`（不是 `~/.netrc`）
> - 公众号内文配图生成用：`automedia/scripts/wechat_image_orchestrator.py`

## 读取已发布文章 (freepublish API)

除上传草稿外，本skill也支持**读取已发布文章**，用于对比草稿vs发布版本、学习编辑改进模式。

### 相关API

| 用途 | 端点 | 备注 |
|------|------|------|
| 获取已发布文章列表 | `POST /cgi-bin/freepublish/batchget` | 只返回通过「发布能力」发布的文章（新版），不包含旧版群发 |
| 获取单篇正文 | `POST /cgi-bin/freepublish/getarticle` | **不是** `freepublish/get`（那会报47001）|
| 获取草稿箱列表 | `POST /cgi-bin/draft/batchget` | 可看到未发布的草稿 |
| 获取草稿正文 | `POST /cgi-bin/draft/get` | 需要media_id |

### 关键发现（2026-06-12实测）

1. **`freepublish/batchget` 返回`total_count`不等于全量**：只包含新版发布系统的文章（实测14篇）。旧版群发发布的文章需通过URL直接访问。
2. **`freepublish/get` 报47001**：正确端点是 `freepublish/getarticle`。
3. **公众号文章URL可直接HTTP访问**：用 `curl + 手机UA` 可以绕过验证页拿到完整HTML。浏览器访问会触发验证码，但HTTP直连可通。
4. **`datacube/getarticlesummary` 已废弃**：返回"this api is offline"。
5. **`material/batchget_material?type=news` 返回0**：该账号无永久素材记录。

### 脚本

`scripts/wechat_get_published.py` — 一键拉取已发布文章列表+正文，保存到本地。
用法见脚本注释。

### 草稿vs已发布对比流水线

```mermaid
flowchart LR
    A[freepublish/batchget] --> B[文章列表]
    B --> C[freepublish/getarticle]
    B --> D[用户提供旧版URL]
    D --> C
    C --> E[已发布正文HTML]
    E --> F[与草稿HTML逐篇对比]
    F --> G[提取改进patterns]
    G --> H[更新copy-review等skill]
```

### 已发布文章正文提取（纯文本）

微信富文本编辑器使用 `<section>` 代替 `<h2>/<h3>` 作为标题标签。提取结构时**不能只看HTML标题标签**，需检查 `<section>` 内的短文本（<30字符）发现类标题元素。详情见 `references/wechat-published-article-api-2026-06-12.md`。

## 错误处理

| 错误码 | 含义 | 处理 |
|--------|------|------|
| 45003 | 标题超9字或含全角符号 | 截断标题，禁用 `｜``—` |
| 45004 | digest 超20字符 | 缩短digest |
| 45110 | author 非空 | 改为空字符串 `""` |
| 40001 | token 无效（过期 或 IP 不在白名单） | 先检查错误信息是否含 `invalid ip`——含 `invalid ip` → 40164处理；不含 → 删除 `.token_cache.json` 重试 |
| 40164 | IP 不在白名单 | 在微信公众平台 → 基本配置 → IP白名单，加入 WSL 出口 IP `112.41.58.21` |

## 禁止事项

- ❌ 写内联 `requests.post` 调试 API
- ❌ 在上传过程中反复调用 API 测试参数
- ❌ 不检查 publish_log.json 就上传
- ❌ 不加载 wechat-upload-checklist 就上传
- ❌ **写内联 `requests.post(url, json=payload)` 绕开本 skill —— 2026-06-03 9 草稿批量乱码事故根因**。`requests` 库的 `json=` 参数内部调 `json.dumps(payload, ensure_ascii=True)`，会把所有中文 escape 成 `\u51fa\u54c1\uff1a...` 形式，公众号原样显示成乱码。**必须**用本 skill 的 `scripts/upload_draft.py`（已 `ensure_ascii=False`），或显式 `data=json.dumps(payload, ensure_ascii=False).encode("utf-8")`。详见 `wechat-upload-checklist` SKILL.md 的 "Pitfall 11" 章节（包含完整修复脚本 + 检测 assert + 9 个事故 content_id 追溯）。
