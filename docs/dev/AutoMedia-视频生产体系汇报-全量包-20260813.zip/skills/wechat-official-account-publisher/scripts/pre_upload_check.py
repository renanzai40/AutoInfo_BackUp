#!/usr/bin/env python3
"""
Pre-upload check for WeChat draft.

MUST be called before any draft/add API call.
Enforces:
  1. No MiniMax 思考标签污染
  2. No 【约XXX字】标记
  3. Title ≤ 9 Chinese chars
  4. Digest ≤ 20 chars
  5. No full-width separators in title/digest
  6. HTML must be <body> inner content only

Usage:
  python3 pre_upload_check.py --html article.html --title "标题" --digest "摘要"

Exit code 0  = pass
Exit code 1  = validation error (prints error to stderr)
"""

import re, sys
import argparse
from pathlib import Path

# Full-width / special separators that trigger WeChat 45003/45004
FORBIDDEN_TITLE_CHARS = '｜—·'     # U+FF5C U+2014 U+00B7
FORBIDDEN_DIGEST_CHARS = '｜—·'    # same set

def clean_thinking_tags(html: str) -> str:
    """Remove </think>/<think> blocks and markers."""
    cleaned = re.sub(r'<\/思考>', '', html)
    cleaned = re.sub(r'<think>[\s\S]*?</think>', '', cleaned)
    return cleaned

def remove_word_count_markers(text: str) -> str:
    return re.sub(r'【约\d+字】', '', text)

def validate_title(title: str) -> str:
    """Validate title and return cleaned version. Raises ValueError on fail."""
    t = title.strip()
    if not t:
        raise ValueError("标题不能为空")

    # Count Chinese chars (CJK Unified Ideographs + common Chinese punctuation)
    chinese_chars = len(re.findall(r'[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]', t))
    # ASCII chars count as half for display but full for limit
    # WeChat limit is bytes; Chinese ≈ 3 bytes each, so 9 Chinese chars is the practical limit
    # Simple heuristic: reject if more than 9 chars that look like Chinese words
    if chinese_chars > 9:
        raise ValueError(
            f"标题超限：含 {chinese_chars} 个汉字（上限 9 个）"
        )

    for ch in FORBIDDEN_TITLE_CHARS:
        if ch in t:
            raise ValueError(
                f"标题含禁止字符 [{ch}]，改用 ASCII `-` `:` `|` 分隔"
            )

    return t

def validate_digest(digest: str) -> str:
    """Validate digest and return cleaned version. Raises ValueError on fail."""
    d = digest.strip()
    # Rough char count (each Chinese char ≈ 2 bytes, ASCII ≈ 1 byte)
    # 20 bytes practical limit → ~13-15 Chinese chars or 20 ASCII chars
    # Use simple char count as proxy; WeChat counts bytes
    display_len = len(d)
    if display_len > 20:
        raise ValueError(
            f"摘要超限：{display_len} 字（上限 20 字）"
        )

    for ch in FORBIDDEN_DIGEST_CHARS:
        if ch in d:
            raise ValueError(
                f"摘要含禁止字符 [{ch}]，改用 ASCII 分隔"
            )

    return d

def extract_body_content(html: str) -> str:
    """
    Extract content inside <body> tag.
    If no <body> found, assume the HTML is already body-inner content.

    G5 硬门控（2026-06-05 v11 加，6-05 codex 排版乱掉事故）：
    - HTML 必须含 <p> 段落 ≥ 5
    - HTML 必须含 <h2>/<h3> 标题 ≥ 3
    - HTML 必须含 <blockquote> 引用 ≥ 1
    - HTML 必须含 <strong> 强调 ≥ 2
    任一不达标 → 立即 raise ValueError（防 raw Markdown 伪装 HTML 上传）
    """
    body_match = re.search(r'<body[^>]*>(.*?)</body>', html, re.DOTALL)
    if body_match:
        body = body_match.group(1).strip()
    else:
        # No body tag — assume raw body content
        body = html.strip()

    # G5 HTML 结构硬要求
    p_count = len(re.findall(r'<p[\s>]', body))
    h2_count = len(re.findall(r'<h[23][\s>]', body))
    blockquote_count = len(re.findall(r'<blockquote[\s>]', body))
    strong_count = len(re.findall(r'<strong[\s>]', body))
    if p_count < 5:
        raise ValueError(
            f"G5 硬门控 FAIL: <p> 段落仅 {p_count} 个 (要求 ≥ 5)。"
            f"HTML 可能是 Markdown 伪装，建议先用 `pandoc -f markdown -t html5 input.md -o output.html` 转换。"
        )
    if h2_count < 3:
        raise ValueError(
            f"G5 硬门控 FAIL: <h2>/<h3> 标题仅 {h2_count} 个 (要求 ≥ 3)。"
            f"可能是缺二级标题分级，建议加 ##/### 结构。"
        )
    if blockquote_count < 1:
        raise ValueError(
            f"G5 硬门控 FAIL: <blockquote> 引用 0 个 (要求 ≥ 1)。"
            f"建议在文章开头加 1 段 > 引言做导读。"
        )
    if strong_count < 2:
        raise ValueError(
            f"G5 硬门控 FAIL: <strong> 强调仅 {strong_count} 个 (要求 ≥ 2)。"
            f"建议在关键数据/洞察处加 **bold** 强调。"
        )
    return body

def check_forbidden_in_html(html: str) -> str:
    """Check for thinking tags in HTML, raise if found."""
    if '<think>' in html or '<\/思考>' in html:
        raise ValueError("HTML 中仍含 思考 标签，上传前必须清理")
    return html

def run(html_path: str, title: str, digest: str) -> dict:
    """
    Run all checks. Returns dict with cleaned fields.
    Raises ValueError on any validation failure.
    """
    html_raw = Path(html_path).read_text(encoding='utf-8')

    # 1. Clean thinking tags from HTML
    html_clean = clean_thinking_tags(html_raw)
    html_clean = remove_word_count_markers(html_clean)

    # 2. Extract body content
    body_content = extract_body_content(html_clean)

    # 3. Check no residual thinking tags
    check_forbidden_in_html(body_content)

    # 4. Validate title
    title_clean = validate_title(title)

    # 5. Validate digest
    digest_clean = validate_digest(digest)

    return {
        'title': title_clean,
        'digest': digest_clean,
        'html_content': body_content,
        'html_clean': html_clean,
    }


def main():
    parser = argparse.ArgumentParser(description="WeChat pre-upload validation")
    parser.add_argument('--html', required=True, help='Path to HTML file')
    parser.add_argument('--title', required=True, help='Article title')
    parser.add_argument('--digest', required=True, help='Article digest/summary')
    args = parser.parse_args()

    try:
        result = run(args.html, args.title, args.digest)
        print(f"OK: title={result['title']} digest={result['digest']} chars", file=sys.stderr)
        sys.exit(0)
    except ValueError as e:
        print(f"VALIDATION FAILED: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
