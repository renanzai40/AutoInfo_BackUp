#!/usr/bin/env python3
"""
读取微信公众号已发布文章列表 + 单篇正文。

Usage:
  python3 wechat_get_published.py --list       # 列出已发布文章
  python3 wechat_get_published.py --full       # 下载全部文章正文
  
APIs:
  POST /cgi-bin/freepublish/batchget    — 文章列表
  POST /cgi-bin/freepublish/getarticle   — 单篇正文（注意不是/freepublish/get）
  
注意：
  - freepublish/batchget 只返回通过「发布能力」发布的文章（约14篇）
  - 旧版群发发布的文章需要通过URL直接访问
  - 公众号文章URL可用 curl + 手机UA 绕过验证页
  - datacube API 已废弃，返回"this api is offline"
  - material/batchget_material?type=news 返回0（无永久素材记录）
"""
import json, sys, time, urllib.request, argparse
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
TOKEN_SCRIPT = SCRIPT_DIR / "get_token.py"

BATCHGET_URL = "https://api.weixin.qq.com/cgi-bin/freepublish/batchget"
GET_URL = "https://api.weixin.qq.com/cgi-bin/freepublish/getarticle"


def get_token():
    import subprocess
    result = subprocess.run(["python3", str(TOKEN_SCRIPT)], capture_output=True, text=True)
    if result.returncode != 0:
        print(f"ERROR: get_token failed: {result.stderr}", file=sys.stderr)
        sys.exit(1)
    return result.stdout.strip()


def api_post(url, payload):
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data,
                                  headers={"Content-Type": "application/json; charset=utf-8"},
                                  method="POST")
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())


def fetch_all_published_articles(token, batch_size=20):
    """Fetch all published articles (paginated)."""
    all_items = []
    offset = 0
    total = None

    while True:
        url = f"{BATCHGET_URL}?access_token={token}"
        payload = {"offset": offset, "count": batch_size, "no_content": 1}
        resp = api_post(url, payload)

        if "errcode" in resp and resp["errcode"] != 0:
            print(f"ERROR: batchget failed: {resp}", file=sys.stderr)
            break

        if total is None:
            total = resp.get("total_count", 0)
            print(f"Total published: {total}", file=sys.stderr)

        items = resp.get("item", [])
        if not items:
            break

        for item in items:
            article_id = item.get("article_id", "")
            content = item.get("content", {})
            news_items = content.get("news_item", [])
            for ni in news_items:
                all_items.append({
                    "article_id": article_id,
                    "title": ni.get("title", ""),
                    "url": ni.get("url", ""),
                    "digest": ni.get("digest", ""),
                    "cover_url": ni.get("thumb_url", ""),
                    "create_time": content.get("create_time", 0),
                    "update_time": content.get("update_time", 0),
                })

        offset += len(items)
        if offset >= total:
            break
        time.sleep(0.3)

    return all_items


def fetch_article_detail(token, article_id):
    url = f"{GET_URL}?access_token={token}"
    payload = {"article_id": article_id}
    return api_post(url, payload)


def extract_article_body(detail):
    item = detail.get("news_item", [{}])[0] if detail.get("news_item") else {}
    return item.get("content", "")


def main():
    parser = argparse.ArgumentParser(description="Read WeChat published articles")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--output-dir", default="/tmp/wechat_published")
    args = parser.parse_args()

    token = get_token()
    articles = fetch_all_published_articles(token)

    if args.limit and len(articles) > args.limit:
        articles = articles[:args.limit]

    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)

    if args.list:
        import datetime
        for a in articles:
            ct = datetime.datetime.fromtimestamp(a.get("create_time", 0)).strftime("%m-%d %H:%M")
            print(f"{a['title'][:40]:<40} {ct} {a['article_id'][:30]}...")
        (output / "articles_list.json").write_text(
            json.dumps(articles, ensure_ascii=False, indent=2), encoding="utf-8")

    elif args.full:
        results = []
        for i, a in enumerate(articles):
            print(f"[{i+1}/{len(articles)}] {a['title'][:30]}", file=sys.stderr)
            detail = fetch_article_detail(token, a["article_id"])
            if detail:
                body = extract_article_body(detail)
                safe_name = f"{a['article_id']}.html"
                (output / safe_name).write_text(body or "", encoding="utf-8")
                a["body_html_path"] = str(output / safe_name)
                a["body_length"] = len(body or "")
            results.append(a)
            time.sleep(0.5)

        (output / "articles.json").write_text(
            json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Done: {len(results)} articles -> {output}", file=sys.stderr)
    else:
        print(json.dumps(articles, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
