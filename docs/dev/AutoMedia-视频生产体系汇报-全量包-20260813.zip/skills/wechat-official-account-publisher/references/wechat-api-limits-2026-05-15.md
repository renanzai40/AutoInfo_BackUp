# WeChat Draft API 已知限制（实测）

## 标题限制
- 限制：约 9 个中文字符以内
- 超出 → `errcode: 45003 (title size out of limit)`
- 实测通过：`"AI产业日报"` (5字)、`"百度一镜数字人升级"` (9字)

## Digest 限制
- 限制：约 20 个纯文本字符以内（去除 HTML 标签后的纯文本）
- 超出 → `errcode: 45004 (description size out of limit)`
- 解法：取 `纯文本[:20].strip()`

## Author 限制
- **正确做法：留空 `""`**，不要填品牌名
- 实测：`""` 通过，`"壹目"` 通过，`"壹目贯维"` 报 45110

## Content 格式
- WeChat 草稿 API 接受 HTML 片段（不含 `<html>/<head>/<body>` 结构标签）
- 禁止上传完整 HTML 文档（`<!DOCTYPE html><html>...`）——会显示为乱码
- 只上传 `<body>` 内的内容，或用 `scripts/md_to_html.py` 转换后的纯内容片段
- Smart quotes（`"` `"`）建议转换后再上传

## Thumb Media ID
- 必须来自 `add_material`（永久素材），不能用 `media/upload`（临时素材）

## 调试原则
- 永远不要在执行过程中反复调用草稿创建 API 来调试参数
- 先在命令行单独测试极限值，找到 safe 值后再执行一次上传
- 每次调试产生的垃圾草稿只能用户在微信后台手动删除
