# WeChat Publisher — Session Learnings (2026-05-24)

## 业务款上传标准路径（已验证）

针对 AutoMedia 项目，业务款公众号上传完整路径：

```
01_content/drafts/<topic>_content.md
    ↓ （提取对应平台section）
approved/v4_<topic>_wechat_approved.md
    ↓ （转为HTML）
06_publish/assets/wechat_article.html      ← HTML纯正文（<body>内容）
06_publish/assets/wechat_cover.png        ← 封面图（3:2 / 1248×832）
    ↓
封面图 → upload_thumb.py → media_id
HTML → upload_draft.py → content_id
    ↓
06_publish/publish_log.json               ← 上传记录（不是05_publish）
```

**注意**：`publish_log.json` 放在 `06_publish/` 下（和 assets 同级），不是 `05_publish/`。

---

## Title/Digest 快速决策（实测通过）

| 原标题（超限） | 截断后 | 汉字数 |
|---------------|--------|-------|
| 10款AI视频生成工具，1天能快速生成100+条视频？（实测收藏） | 10款AI视频生成工具实测 | 9 ✅ |

| 原摘要（超限） | 截断后 | 字符数 |
|---------------|--------|-------|
| 亲测10款主流工具，从生成速度、画面质量、多镜衔接做横向对比（30字） | 亲测10款主流AI视频工具 | 15 ✅ |

**规则**：标题先截断到9汉字，再看digest是否也超限。Digest从后往前删，不用从前删。

---

## MiniMax API Key 格式（已验证可工作）

环境变量 `MINIMAX_CN_API_KEY` 的值必须包含完整的 `sk-cp-` 前缀：

```bash
# ✅ 正确 — 从 auth.json 读取完整 token（含 sk-cp- 前缀）
export MINIMAX_CN_API_KEY="sk-cp-CAPjdmwYi7mVzEjlbnCpHfGAi2h07_EUM3..."

# ❌ 错误 — 只截取了前半段
export MINIMAX_CN_API_KEY="sk-cp-CAPjdmwYi7mVzE"  # 登录失败，1004
```

auth.json 中的 `access_token` 字段即完整 key，勿拆分。

---

## Vision QA 通过记录（封面图）

生图 Prompt：
```
floating video player icons arranged in a 5x2 grid pattern, 
each icon glowing with soft blue light, 
connected by thin light beam lines forming a neural network pattern, 
dark blue background with subtle purple gradient glow, 
frosted glass aesthetic, cinematic lighting, 
4K ultra detailed, professional tech aesthetic, 
blue and purple color palette, 
NO large text in center, NO title text, 
NO big characters overlaid on the image, NO readable characters anywhere
```

结果：1248×832，Vision QA 五项全部 NO（无文字、无地图、无乱码、无Logo、无肖像）。