# WeChat Publisher · Session Learnings (2026-05-16)

## pre_upload_check.py 已替代手动 checklist

`upload_draft.py` 已在入口处集成 `pre_upload_check.py` 调用，所有校验（`` 污染、标题≤9汉字、摘要≤20字、全角符号、body 内容提取）全部自动化。

**以后不需要手动执行 wechat-upload-checklist 的 Step 1-8。**
只要通过 `upload_draft.py --html <文件>` 上传，校验自动完成、失败则 exit 1。

wechat-upload-checklist 的 8 步清单现在只有教育/复核价值，不作为强制 gate。

---

## pool.db status CHECK 约束

```
topics.status CHECK: IN ('pending', 'selected', 'writing', 'published', 'archived')
```

**'producing' 不是合法状态。** 更新 topic 状态时必须用 'selected'（已选入生产）或其他合法值。

合法流转：`pending` → `selected` → `writing` → `published` → `archived`

---

## 草稿文件路径约定

生产 subagent 写的公众号草稿可能出现在两个位置：
- `<project>/wechat_draft.html`（subagent 根目录产出）
- `<project>/01_content/wechat_draft.html`（规范路径）

上传前用 `glob` 扫描两个位置，取存在的那个。

---

## 并行生产：delegate_task 多项目模式

多项目并行时，用 `tasks` 数组同时 spawn，每个 subagent 的 `context` 必须包含：
- `project_path`
- `topic_id`
- `category`（引流款/业务款）
- `topic`
- `bridge` 策略
- `CTA` 策略

禁止让 subagent 自己从 pool 查 project_path——直接传，避免歧义。
