# 微信公众号已发布文章读取 API 实测

> 2026-06-12 实测
> 账号: 壹目贯维 (biz=MzYzNzI1NjM2MQ==)

---

## 一、可用API汇总

### 1.1 已发布文章列表 — freepublish/batchget

```
POST https://api.weixin.qq.com/cgi-bin/freepublish/batchget?access_token={token}
{
  "offset": 0,        // 偏移量
  "count": 20,        // 每页数量(≤20)
  "no_content": 1     // 1=不返回正文(更快), 0=返回正文(更大)
}
```

**注意**：
- 只返回通过新版「发布能力」发布的文章
- 旧版群发系统发布的文章**不在此列表**中
- 可通过 `total_count` 判断全量
- 实测该账号 `total_count: 14`

**响应结构**：
```json
{
  "total_count": 14,
  "item": [
    {
      "article_id": "RC_ezfu...KHGz",
      "content": {
        "news_item": [
          {
            "title": "AI造谣被罚了",
            "url": "http://mp.weixin.qq.com/s?__biz=...",
            "digest": "摘要",
            "thumb_url": "https://mmbiz.qpic.cn/..."
          }
        ],
        "create_time": 1779959568
      },
      "update_time": 1779959600
    }
  ]
}
```

### 1.2 单篇正文 — freepublish/getarticle

```
POST https://api.weixin.qq.com/cgi-bin/freepublish/getarticle?access_token={token}
{
  "article_id": "RC_ezfu...KHGz"
}
```

**⚠️ 关键坑**：端点是 `getarticle` **不是** `get`。`freepublish/get` 会返回 `{"errcode": 47001, "errmsg": "data format error"}`。

**响应结构**：
```json
{
  "news_item": [
    {
      "title": "AI造谣被罚了",
      "author": "贯维背后的男人",
      "digest": "摘要",
      "content": "<section>...正文HTML...</section>",
      "url": "http://mp.weixin.qq.com/s/..."
    }
  ]
}
```

`content` 字段即文章正文HTML（微信富文本section格式）。

### 1.3 草稿箱列表 — draft/batchget

```
POST https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token={token}
{
  "offset": 0,
  "count": 20,
  "no_content": 0
}
```

实测该账号有 33 个草稿项。部分草稿可能已发布但仍在草稿箱中留存。

### 1.4 已废弃接口

以下接口返回 "this api is offline, please use the new api"：
- `POST /cgi-bin/datacube/getarticlesummary`
- `POST /cgi-bin/datacube/getarticletotal`
- `POST /cgi-bin/material/batchget_material?type=news`（返回0条）

---

## 二、浏览器验证绕过

微信文章URL可通过 `curl + 手机User-Agent` 直接访问，浏览器会触发验证码。

```bash
curl -s -L \
  -A "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36" \
  "https://mp.weixin.qq.com/s/1_OUlIK1Z65K0gwTH_0SHA" \
  -o article.html
```

返回完整HTML（约3MB，含JS/CSS），正文在 `<div id="js_content">` 内。

正文提取：
```python
import re
body = re.search(r'id="js_content"[^>]*>(.*?)</div>\s*<script', html, re.DOTALL)
```

标题从 `og:title` 取：
```python
og_title = re.search(r'<meta[^>]+property="og:title"[^>]+content="([^"]+)"', html)
```

---

## 三、获取全量文章的方案

1. **新版发布系统文章** → `freepublish/batchget` + `freepublish/getarticle` (自动)
2. **旧版群发文章** → 需要用户从公众号后台提供文章URL (手动)
3. **草稿箱内容** → `draft/batchget` + `draft/get` (自动)

---

## 四、正文结构特点

微信富文本编辑器输出与普通HTML不同：
- 标题**不使用** `<h2>/<h3>`, 改用 `<section>` 包裹短文本
- 段落用 `<section style="...">` + `<p>` 嵌套
- 加重用 `<strong>`（可用，raw HTML中有）
- 图片用 `<img data-src="...">`（懒加载，非标准src）
- 整体是微信专属的XML/HTML混合格式

**提取结构的方法**：统计 `<section>` 内的短文本（<30字符，非图片描述）作为"类标题"元素。

---

## 五、相关文件

- 本skill主文件: `SKILL.md`
- 批量拉取脚本: `scripts/wechat_get_published.py`
- 已拉取正文: `/tmp/wechat_published/`
