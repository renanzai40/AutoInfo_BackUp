# MiniMax Image API · WeChat Article Quirk Notes (2026-05-23)

## Response format: `data.image_urls[]`, not `data[].url`

MiniMax image generation v1 uses a nested response structure:

```json
{
  "data": {
    "image_urls": ["https://cdn.url/xxx.jpeg?..."]
  },
  "base_resp": { "status_code": 0, "status_msg": "success" }
}
```

**Not** `data[0].url`. The OSS CDN URL is in `data.image_urls[0]`.

```python
# Correct
img_url = result["data"]["image_urls"][0]

# Wrong (will KeyError)
img_url = result["data"][0]["url"]
```

Handle both patterns:

```python
if "data" in result and "image_urls" in result["data"] and result["data"]["image_urls"]:
    img_url = result["data"]["image_urls"][0]
elif "data" in result and isinstance(result["data"], list) and "url" in result["data"][0]:
    img_url = result["data"][0]["url"]
else:
    raise Exception(f"Unexpected image API response: {result}")
```

## Aspect ratio: MiniMax does not support 4:3

MiniMax `image-01` accepts `3:2` as the closest to WeChat article 4:3 standard.

| Use | Ratio | Supported |
|-----|-------|-----------|
| 公众号内文配图（横版） | **4:3** (1.333) | ❌ not available |
| Fallback (实际) | 3:2 (1.500) | ✅ `aspect_ratio: "3:2"` |

Use `aspect_ratio: "3:2"` and accept ±5% tolerance in verification.

## Image download: file may be JPEG regardless of path

MiniMax always returns JPEG content. The CDN URL extension may be `.jpeg` with a query string:

```python
if img_url.lower().endswith(".jpeg") or img_url.lower().endswith(".jpg"):
    out_path = str(Path(output_path).with_suffix(".jpg"))
else:
    out_path = output_path
```

## Credential source: `~/.hermes/auth.json`

```python
from pathlib import Path
import json
auth_path = Path.home() / ".hermes" / "auth.json"
with open(auth_path) as f:
    auth = json.load(f)
key = auth["credential_pool"]["minimax-cn"][0]["access_token"]
```

Base URL: `https://api.minimaxi.com/v1` (not `api.minimax.io`).

## Orchestrator script

`wechat_image_orchestrator.py` auto-generates 3-6 WeChat article images and inserts `![alt](images/wechat_img_XX.png)` into `draft.md`:

```
/home/renanzai/.hermes/skills/productivity/automedia/scripts/wechat_image_orchestrator.py
```

Usage:
```bash
python3 .../wechat_image_orchestrator.py "/path/to/project/" [--force]
```
