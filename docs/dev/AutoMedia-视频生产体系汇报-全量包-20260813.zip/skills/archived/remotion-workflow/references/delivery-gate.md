# Remotion Delivery Gate

**Trigger**: Remotion 视频通过 post-render-qa 后，准备发送给用户前。

## Gates

### size-check
飞书 bot 单文件上传实际限制 ~30MB。
- ≤25MB：直接上传
- >25MB 且 ≤30MB：直接上传但接近限制
- >30MB：先 re-encode（ffmpeg crf 28 + aac 96k）
- >50MB 且 re-encode 仍 > 30MB：分 2 卷 zip

**Re-encode command**:
```bash
ffmpeg -i INPUT.mp4 -c:v libx264 -crf 28 -preset fast \
       -c:a aac -b:a 96k -movflags +faststart -y OUTPUT_compressed.mp4
```

### manifest-required
manifest.json 必须包含：version, date, project, files（含 name/size/md5/description）, qa_status, qa_report_path.

### whisper-pre-send (BLOCK_DELIVERY)
⚠️ P0-13 铁律：mp3 实际朗读和 SRT 文本必须 100% 匹配。

强制验证 4 步：
```bash
# Step 1: Whisper tiny 转写 mp4/mp3 实际内容
whisper /path/to/output.mp4 --language zh --model tiny --output_format srt --output_dir /tmp/whisper_pre_send/

# Step 2: 抽帧验证
python3 audio_video_sync_check.py out/final.mp4 /path/to/audio.mp3 /path/to/srt

# Step 3: diff Whisper SRT vs 项目 SRT
diff /tmp/whisper_pre_send/output.srt /path/to/srt

# Step 4: 报告
```

### split-naming
使用 `_p1.zip / _p2.zip / _p3.zip` 后缀。不要用 `.aa/.ab/.ac`。

### merge-instructions
飞书消息必须包含 Windows 合并命令：
```
copy /b project_p1.zip + project_p2.zip [+ project_p3.zip] output.mp4
```

## Output

```
## Remotion Delivery Gate Report

| Gate | Status | Detail |
|------|--------|--------|
| size-check | ✅ X MB | 需分N卷 / 直接上传 |
| manifest | ✅ | manifest.json 已生成 |
| whisper-pre-send | ✅/❌ | ... |
| split-naming | ✅ | _p1.zip / _p2.zip |
| merge-instructions | ✅ | 已附上 |

**Gate Result**: READY_TO_DELIVER | BLOCKED
```

若 gate 返回 BLOCK：列出失败项，修复后重新执行 gate，不得绕过。

交付完成后：将 manifest.json 和 QA 截图存档到项目目录，更新 changelog.md，清理 /tmp。
