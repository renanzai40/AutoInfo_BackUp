<!--
SubtitleCard component implementation pattern for Remotion videos.
This component handles word-level highlighting and caption display.
-->

# Subtitle Component Pattern

## SubtitleCard Component

Positioned at the bottom H/6 of the video. Uses `useCurrentFrame()` frame-relative timing.

```tsx
interface SubtitleCardProps {
  sentences: Sentence[];
  frame: number;
}

interface Sentence {
  text: string;
  start: number;   // 全局 frame
  duration: number; // 帧数
}
```

The component renders each sentence when `frame >= sentence.start && frame < sentence.start + sentence.duration`.
Word-level highlighting uses `@remotion/captions` if available.

## Key Rules

- `<Sequence>` 内 `useCurrentFrame()` 返回**段内相对 frame**（0-based），`TransitionSeries.Sequence` 内也是段内相对
- SCENE_SUBTITLES entry 的 start/duration 必须是段内相对 frame（匹配 useCurrentFrame() 行为）
- 段内 frame 计算方法：全局帧号 - 段起点全局帧号
