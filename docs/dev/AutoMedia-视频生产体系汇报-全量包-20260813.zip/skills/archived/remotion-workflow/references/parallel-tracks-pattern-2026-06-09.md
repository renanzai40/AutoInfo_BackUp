# 并行 Track 模式：文案 Track vs 视频 Track（2026-06-09 固化）

## 背景

2026-06-09 生产 session 中，agent 完成视频渲染+QA 后，等用户提醒才上传公众号草稿。
用户纠正："微信公众号草稿上传为什么要接在 remotion 工作流后面，不是应该在微信公众号文案和图片以及排版做好就可以触发了吗"

## 根因

remotion-workflow 的 6+1 步工作流把"5 平台文案"和"视频"放在同一个交付步骤里，
但实际上两条链的依赖不同：

| 环节 | 依赖 | 触发时机 |
|------|------|---------|
| 公众号上传 | 文案 G1-G3 通过 + 封面图就绪 | → 可立即触发 |
| 知乎/小红书发布 | 文案 G1-G3 通过 | → 可立即触发 |
| 视频交付 | TTS + SRT + Remotion 渲染 + QA | → 需等渲染完成 |

## 正确触发点

```
选题确认
    ↓
┌─ 文案 Track ─────────────────┐  ┌─ 视频 Track ────────────────┐
│ 写 5 平台内容                  │  │ 写视频脚本                    │
│ humanizer/copy-review/brand-cta│  │ TTS + Whisper + SRT          │
│ 生成封面图 + 上传拿 thumb_id   │  │ Remotion 渲染                 │
│ [公众号上传] ← 放这里          │  │ post-render QA                │
│ 知乎/小红书待发布              │  │ 视频交付                      │
└───────────────────────────────┘  └──────────────────────────────┘
```

**公众号上传的精确触发条件**（全部满足）：
1. 公众号文案完成 humanizer → copy-review → brand-cta-review 全部通过
2. 封面图（16:9 横版）生成并上传至微信，拿到 thumb_media_id
3. publish_log.json 中 wechat.title/digest/thumb_media_id 字段齐全
4. 上述全部满足后 → 自动执行 `safe_upload_wechat.py`

## 反模式（永久禁止）

| 反模式 | 后果 |
|--------|------|
| 等视频渲染完才上传公众号 | 用户需主动提醒，打断交付流畅度 |
| 先修视频再写文案 | 6-05 chaos 教训，22:30 才抢救文案 |
| 公众号上传前不检查封面图就绪 | safe_upload Step 1 fail，白跑一轮 |

## 检查清单（每次项目启动时确认）

- [ ] 文案 Track 和视频 Track 同时启动（不是先 A 后 B）
- [ ] 公众号上传不依赖视频渲染完成
- [ ] 封面图（16:9）在文案 G1-G3 通过后立即生成
- [ ] 封面图就绪后立即调 `upload_thumb.py` 拿 media_id
- [ ] publish_log 中 wechat 字段齐全后立即调 `safe_upload_wechat.py`
