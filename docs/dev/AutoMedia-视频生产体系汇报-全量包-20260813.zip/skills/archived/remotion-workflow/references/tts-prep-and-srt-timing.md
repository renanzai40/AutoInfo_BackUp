# TTS 预处理 + SRT 精确时间戳

## TTS 预处理：剥离段标题

**禁止**直接喂带【段标题】的脚本文件给 TTS。

脚本文件 `tiktok/script.txt` 的结构：
```
【开场钩子】Google 的 Gemini 模型...
【痛点问题】...
```

直接 `edge-tts --text "$(cat script.txt)"` 会导致 TTS 朗读出「开场钩子」等段标题。

**正确做法**：
```bash
# 提取纯净口播文本（去掉【】内的段标题）
CLEAN=$(sed 's/^【.*】//' script.txt | tr -s '\n' ' ')
edge-tts --voice zh-CN-YunxiNeural --text "$CLEAN" --write-media out.mp3
```

**建议**：在 `01_content/` 下保存一份 `script_tts.txt`（仅口播文本，无标记），TTS 只用此文件。

## SRT 时间戳：必须用 Whisper 精确时间

**禁止**按字数比例分配 SRT 时间。语音节奏不均匀，比例分配必定不同步。

**正确流程**：
1. TTS 生成 mp3
2. Whisper medium 模型转写（`whisper.load_model('medium', device='cpu')`）
3. 直接从 `result['segments'][]['start']` / `['end']` 获取精确时间戳
4. 用这些时间戳构建 SRT
5. SRT 文本用原始脚本文字覆盖 Whisper ASR 的误识别

## 检验方法

Whisper 转写 mp3 实际内容，与 SRT 原文做关键词覆盖率比对（≥80% 通过）。详见 `automedia-production-guard` skill 的 V5 Gate + `references/tts-input-purity-and-srt-timing-2026-06-12.md`。
