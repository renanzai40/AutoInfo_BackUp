# NSegmentSkeleton 集成坑（2026-06-06 实战，新写 Composition 必读）

> 6-04 抽出的 `NSegmentSkeleton` + 12 通用组件是 v10 标准（按 P0-8 必继承），但首次接入时踩了 3 个独立的坑，浪费 ~30 分钟调试。**未来新写 Composition 用 NSegmentSkeleton 前必读本 reference**，避免重复踩。

## 坑 1：`audioSrc` 不可调 `staticFile()`（Remotion 4.x 静默报双前缀错误）

**症状（webpack 报）**：
```
Error: The value "/public/audio/voice-actor-ai-crisis.mp3" is already prefixed
with the static base /public. You don't need to call staticFile() on it.
    at staticFile (.../bundle.js:160876:21)
    at NSegmentSkeleton (.../bundle.js:117841:77)
```

**根因**：`NSegmentSkeleton` 内部 L169 已经写了：
```typescript
<Audio src={staticFile(audioSrc)} />
```
即**骨架已经调了 `staticFile()`**。如果调用方再包一层 `staticFile("audio/...")`，路径变成 `/public/public/audio/...`（双前缀）→ 渲染时 throw。

**正确做法（与 6-05 v4 一致）**：
```typescript
// ✅ 正确：传纯字符串字面量
<NSegmentSkeleton
  audioSrc="audio/voice-actor-ai-crisis.mp3"
  ...
/>

// ❌ 错误：再调一次 staticFile
<NSegmentSkeleton
  audioSrc={staticFile("audio/voice-actor-ai-crisis.mp3")}  // 双前缀！
  ...
/>
```

**6-05 v4 reference 写法**（`AlphabetAnthropicV4Composition.tsx`）：
```typescript
audioSrc="audio/alphabet-anthropic.mp3"
```

**铁律**：NSegmentSkeleton / 5-segment-skeleton 的 `audioSrc` prop 必传**纯字符串字面量**（如 `"audio/xxx.mp3"`），不要调 `staticFile()` 包装。

---

## 坑 2：从 `src/<Topic>Composition.tsx` import `templates/n-segment-skeleton` 必须 `../`（跳 src/）

**症状（webpack 报）**：
```
Can't resolve './templates/n-segment-skeleton' in '/home/renanzai/Remotion-Test/src'
```

**根因**：`n-segment-skeleton.tsx` 实际位置是 `Remotion-Test/templates/`（**项目根下**），不是 `Remotion-Test/src/templates/`。`src/` 下的 Composition 想 import 它，必须用 `../templates/n-segment-skeleton` 跳出 `src/` 目录。

**正确做法**：
```typescript
// src/VoiceActorComposition.tsx

// ✅ 正确：../ 跳出 src/
import { NSegmentSkeleton, SegmentData, SegmentBoundary } from "../templates/n-segment-skeleton";

// ❌ 错误：./templates 在 src/ 下找（不存在）
import { NSegmentSkeleton, SegmentData, SegmentBoundary } from "./templates/n-segment-skeleton";
```

**项目目录速查**：
```
Remotion-Test/
├── src/                    ← 你的 Composition 在这里
│   ├── VoiceActorComposition.tsx
│   ├── effects-v9.tsx
│   └── Root.tsx
├── templates/              ← NSegmentSkeleton 在这里
│   ├── n-segment-skeleton.tsx
│   └── 5-segment-skeleton.tsx
└── public/
    └── audio/              ← mp3 必放这里
```

**铁律**：从 `src/` 出发到 `templates/` 必 `../templates/xxx`；到 `src/effects-v9` 必 `./effects-v9`（同目录）。

---

## 坑 3：从 `src/<Topic>Composition.tsx` import `effects-v9` 必 `./`（同目录），不是 `../`

**症状（webpack 报）**：
```
Can't resolve '../effects-v9' in '/home/renanzai/Remotion-Test/src'
```

**根因**：`effects-v9.tsx` 实际位置是 `Remotion-Test/src/effects-v9.tsx`（**同目录**），不是 `Remotion-Test/effects-v9.tsx`。6-05 v4 没直接 import effects-v9（只通过 NSegmentSkeleton 间接用），所以没有先例可循。

**正确做法**：
```typescript
// src/VoiceActorComposition.tsx

// ✅ 正确：同目录
import { MainTitle, WordHighlight } from "./effects-v9";

// ❌ 错误：../ 跳到项目根（没有 effects-v9）
import { MainTitle, WordHighlight } from "../effects-v9";
```

**注意**：`templates/n-segment-skeleton.tsx` 内部 import 用的是 `../src/effects-v9`（从 `templates/` 跳到 `src/`）——**那是 templates 文件自己的视角**，不是 src 下的 Composition 的视角。

**铁律**：
- `src/XxxComposition.tsx` → import `effects-v9` 必 `./effects-v9`
- `templates/n-segment-skeleton.tsx` → import `effects-v9` 必 `../src/effects-v9`

---

## 3 个坑联合反查清单（写新 Composition 前必过）

| # | 检查 | 正确 | 错误 |
|---|------|------|------|
| 1 | NSegmentSkeleton `audioSrc` prop | `"audio/xxx.mp3"` 字符串 | `staticFile("audio/...")` |
| 2 | `import` NSegmentSkeleton 路径 | `../templates/n-segment-skeleton` | `./templates/n-segment-skeleton` |
| 3 | `import` effects-v9 路径（src/ 下） | `./effects-v9` | `../effects-v9` |

**任何 1 项写错 → webpack 报 "Module not found" 或 "double prefix" 错误**。

---

## 实战对比（6-06 修复链）

| 渲染尝试 | 错误 | 修复 |
|---------|------|------|
| 1 | `./templates/n-segment-skeleton` 找不到 | 改 `../templates/n-segment-skeleton` |
| 2 | 编译通过但 webpack 报 "../effects-v9" 找不到 | 删 `../effects-v9` import（NSegmentSkeleton 间接用） |
| 3 | 编译通过但 webpack 报 "double prefix /public" | `audioSrc={staticFile(...)}` 改 `audioSrc="audio/..."` |
| 4 | 渲染成功 ✅ | 全部 3 项修对 |

**踩坑总耗时 ~15 分钟**。如果新 agent 知道这 3 个坑，**0 调试时间**。

---

## Reference 项目

- 6-06 修复后可用 Composition：`/home/renanzai/Remotion-Test/src/VoiceActorComposition.tsx` + `HongguoComposition.tsx`
- 6-05 V4 reference：`/home/renanzai/Remotion-Test/src/AlphabetAnthropicV4Composition.tsx`（audioSrc 字符串字面量）
- NSegmentSkeleton 内部实现：`/home/renanzai/Remotion-Test/templates/n-segment-skeleton.tsx`（L169 调 `staticFile(audioSrc)`）
