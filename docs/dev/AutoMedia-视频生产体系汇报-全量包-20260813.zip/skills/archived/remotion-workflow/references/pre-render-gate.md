# Remotion Pre-Render Gate

**Trigger**: Remotion 项目初始化完成后、执行 render 命令前。

## Gates

### assets-ready
- TTS 音频文件（.mp3/.wav）
- 字体文件（.ttf/.otf）
- 背景图片（若场景需要）
- 数据文件（若使用 DataOverlay）
- Remotion 项目 src/ 目录完整

### composition-defined
- composition ID 已定义
- 帧范围（startFrame, endFrame, fps）已确认
- output path 指向 /tmp 或 output 目录

### timecode-bound-to-srt (BLOCK_render if violated)
1. Composition 5 段帧边界必须从 SRT 真实 entry 算出，**禁止硬编码**
2. 段内 SCENE_SUBTITLES 每条 entry 的 start/duration 必须直接来自 SRT 时间戳
3. 总帧数必须 = TTS 时长 × fps（用 `assertTotalFrames()` 校验）
4. 计算工具：用 `srtTimeToFrame("00:00:04,169")` → 125 帧

**必跑命令**：
```bash
python3 ~/.hermes/profiles/content/skills/remotion-workflow/scripts/check_composition_timecode.py src/
```

### srt-must-exist (BLOCK_render if violated — 6-05 新增)
1. SRT 文件必须存在
2. 文件大小 > 200B
3. SRT entry 数 >= 5
4. 最后一 entry 的 end_time 与 TTS 音频时长差 < 1.5s
5. 关键词密度：SRT 文本含今天话题至少 3 个关键词

**必跑命令**：
```bash
python3 ~/.hermes/profiles/content/skills/remotion-pre-render-gate/scripts/check_srt_must_exist.py 03_video/subtitle.srt 03_video/audio_voiceover.mp3
```

## Output

```
## Remotion Pre-Render Gate Report

| Gate | Status | Detail |
|------|--------|--------|
| assets-ready | ✅/❌ | ... |
| composition-defined | ✅/❌ | ... |
| timecode-bound-to-srt | ✅/❌ | linter exit code |
```

**BLOCK_render** → 修复后重过本 gate，不得跳过。
