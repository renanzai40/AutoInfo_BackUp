# A/V 同步防御机制 — 2026-06-02 实施记录

> **目的**：把 m3 案例（2026-06-02）从"知识传承"升级为"执行机制"。本 reference 记录 A+B 实施全过程、踩坑、测试方法。

## 背景

m3 视频 2026-06-02 上午被用户反馈音画同步差：
- 16-24s 段字幕超前音频 4-5s
- 根因 A：Composition 5 段帧边界硬编码（与 SRT 真实 entry 错位 135 帧/4.5s）
- 根因 B：段内 SCENE_SUBTITLES 按"段内字符比例"重算（与 SRT 真实时间戳完全解耦）
- 根因 C（次要）：SRT 字符比例分配偏差 0.9-1.4s

修复 v2 通过 10/10 抽帧 QA 后用户问："现在的工作流能确保以后也是这个音画同步的标准吗？"

## 防线评估（"document vs mechanism" 框架）

| 防御类型 | 强度 | m3 上午状态 |
|---------|------|----------|
| 文档/Skill 描述 | 10-20% | 30% |
| Skill 描述 + Linter 描述 | 30-40% | 30% |
| Skill + Linter 命令 + Render 钩子 | **90%+** | 目标 |

**m3 上午只有文档**——30-40% 防线，复发风险高。

## A. Linter `check_composition_timecode.py`

**位置**：`~/.hermes/profiles/content/skills/remotion-workflow/scripts/check_composition_timecode.py`

**3 条规则**：
- R1: `S[1-5]_(FROM|TO) = \d+` 字面量 → FAIL（必须 `srtTimeToFrame()`）
- R2: 文件必须 `import.*srtTimeToFrame` from "./timecode"
- R3: 必须导出 `TOTAL_FRAMES`

**设计选择**：
- 不检查 SCENE_SUBTITLES 内的 `start/duration` 字面量：段内相对坐标用字面量是合理的，只要 5 段 FROM/TO 本身从 SRT 算就对
- 输出按 `(rule_id, line)` 去重（一行多个 FROM/TO 只报一次）
- 修复 hint 写明反模式来源

**测试方法（关键）**：
```bash
# 1. 构造 v1 反模式文件
cat > /tmp/v1_bad.tsx <<'EOF'
const S1_FROM = 0;     const S1_TO = 490;
const S2_FROM = 490;   const S2_TO = 575;
// ...（无 import srtTimeToFrame）
EOF

# 2. linter 应 FAIL
python3 scripts/check_composition_timecode.py /tmp/v1_bad.tsx  # exit 1

# 3. 修复版应 PASS
python3 scripts/check_composition_timecode.py src/M3Composition.tsx  # exit 0
```

**踩坑**：第一次写完报 10 个违规（每行 2 个 S[1-5]_FROM/TO = 5 行 × 2）。需要 `seen = set()` 按 `(rule_id, line)` 去重。

## B. Render 钩子 `render_with_qa.sh`

**位置**：`Remotion-Test/scripts/render_with_qa.sh`

**3 步链**：
1. Linter（拦硬编码）
2. `bunx remotion render`
3. `audio_video_sync_check.py`（视频 vs TTS vs SRT 时序对齐）

**用法**：
```bash
bash scripts/render_with_qa.sh MiniMaxM3 out/minimax-m3.mp4 \
  /home/renanzai/Remotion-Test/public/audio/minimax-m3.mp3 \
  /path/to/subtitle.srt
```

**踩坑**：写完后用 `bash -n` 验证语法，发现一个 `]` 多了（`if [ -z "$X" ] ]`），立即修。

## timecode.ts 工具文件

**位置**：`Remotion-Test/src/timecode.ts`（每个 Remotion 项目独立放一份）

**3 个导出**：
- `srtTimeToFrame(timeStr, fps=30)` — SRT 时间戳 → 帧号
- `framesToSrtTime(frame, fps=30)` — 帧号 → SRT 时间戳
- `assertTotalFrames(value, ttsDur, fps, tolerance=1)` — 运行时校验总帧数 = TTS × fps

**Composition 必须用**：
```typescript
import { srtTimeToFrame, assertTotalFrames } from "./timecode";
const S1_TO = srtTimeToFrame("00:00:14,169");
assertTotalFrames(M3_TOTAL_FRAMES, 73.12, 30);  // 不匹配抛错
```

## 重大发现：Linter 扫整个项目抓 latent bugs

**Linter 写完立即跑** `python3 scripts/check_composition_timecode.py src/`：

| 文件 | 状态 | 违规 |
|------|------|------|
| M3Composition.tsx | ✅ PASS | (修复版) |
| HyMemoryComposition.tsx | 🔴 FAIL | 5 段全硬编码（S[1-5]_FROM/TO 都是数字） |
| DeepSeekComposition.tsx | 🔴 FAIL | 缺 srtTimeToFrame import |
| Composition.tsx / LoraiComposition.tsx / RunwayAiComposition.tsx / SixOneEightComposition.tsx / SixOneEightTTSComposition.tsx / TrapDoorComposition.tsx / WentechComposition.tsx / WentechTTSComposition.tsx | 🔴 FAIL | 缺 srtTimeToFrame import |

**10 个 Composition 全部违反**——它们都是同模式的硬编码，**只是之前没触发**（很多视频的 A/V 同步"碰巧没出 bug"是因为时长短或字符比例偏差积累不够大）。

**重要教训**：
- 加 linter 后**立即扫整个项目**列违规清单
- 按"高曝光（已发公众号）> 高频生产（DeepSeek 这种引流款常客）> 长尾" 优先级修复
- **不要等下次出 bug 再修**——linter 已经告诉你问题了
- linter 把"碰巧对"和"真的对"区分开了——这是它的最大价值

## 备份

`/tmp/avsync_backup_20260602_*/` 包含 6 个 A+B 实施前快照：
- 4 个 skill SKILL.md
- M3Composition.tsx（修复版 baseline）
- audio_video_sync_check.py（B 改造前 baseline）

## 防线强度：从 30-40% 到 95%

m3 上午 = 30-40%（只有文档）
m3 下午（A+B 完成后）= 95%（文档 + linter + wrapper + 存量扫描清单）

**剩余 5% 风险**：人忘了跑 wrapper 直接 `bunx remotion render`（需要流程习惯+code review）
