# Remotion TransitionSeries.Sequence 内 useCurrentFrame 行为（2026-06-02 实测）

## 关键发现

**在 `<TransitionSeries.Sequence>` 内部的组件调用 `useCurrentFrame()`，返回的是 Composition 全局 frame（不是 0-based Sequence 内相对 frame）**。

这与普通 `<Sequence>` 行为**可能不同**（普通 Sequence 内是 0-based 段内 frame，Remotion 文档说 Sequence 引入新的 frame context）。

## 实测证据（hy v2 案例）

```typescript
<TransitionSeries>
  <TransitionSeries.Sequence durationInFrames={573}>
    <Scene1 />  {/* Scene1 内部 <SubtitleCard/> 用 useCurrentFrame() */}
  </TransitionSeries.Sequence>
  <TransitionSeries.Transition ... />
  <TransitionSeries.Sequence durationInFrames={444}>
    <Scene2 />
  </TransitionSeries.Sequence>
  ...
</TransitionSeries>
```

如果 `useCurrentFrame()` 返回全局 frame：
- Scene1 渲染时（0-572 帧）frame = 0-572
- Scene2 渲染时（573+15=588-1031 帧）frame = 588-1031
- Scene3 渲染时（1032+15=1047-1906 帧）frame = 1047-1906

**所有 Scene 内部 SubtitleCard 接收的 frame 都是全局 frame**。

## 对 SCENE_SUBTITLES 设计的影响

如果 SubtitleCard 内部用全局 frame：
- SCENE_SUBTITLES entry 的 start/duration **必须是全局 frame**（@ 30fps）
- 不能用"段内相对"小数字（0, 136, 340...）

如果 SCENE_SUBTITLES 用"段内相对"，会发生严重错位（hy 案例实测）：
- S2 段 entry start=0 → 全局 0-8s 显示（S2 段实际 19s+）
- S3 段 entry 7 start=414 → 全局 13.8-21.2s 显示（S3 段实际 33s+）

## 修复方案

**方案 A：把 SCENE_SUBTITLES 改成一个全局数组**（13 entries），所有 Scene 都用 `SCENE_SUBTITLES[0]`
- 简单，已在 hy v3 实测 PASS（4/5 时间点字幕与时间对应）

**方案 B：让 SubtitleCard 接收"当前 Scene 起点 frame"参数**（手动传入 S1_FROM 等）
- 更复杂但保留段内语义

**方案 C：自定义 hook**（`useCurrentSceneFrame()` 返回 `frame - sceneStart`）
- 最优雅但需要 Remotion 内部 API

**推荐 A**：最小改动，4/5 PASS，1/5 黑屏是 fade 问题另修。

## 全局 frame 累计公式

```
全局_frame = 前 (N-1) 段累计 + 第 N 段 Sequence durationInFrames + (N-1) × TRANSITION_DUR
```

hy 案例验证：
- S1: 0 - 572 (= 0 + 573 - 1) ✓
- Transition 1: 573 - 587
- S2: 588 - 1031 (= 573 + 15 + 444 - 1) ✓
- Transition 2: 1032 - 1046
- S3: 1047 - 1906 (= 1032 + 15 + 861 - 1) ✓
- Transition 3: 1907 - 1921
- S4: 1922 - 2353 (= 1907 + 15 + 432 - 1) ✓
- Transition 4: 2354 - 2368
- S5: 2369 - 2586 (= 2354 + 15 + 218 - 1) ✓

**总 = 2587 帧 ≈ 86.2s**（hy v3 实测 82.30s — 差 4s 是 TRANSITION_DUR 计算问题，Composition 没真用全部 TRANSITION）

## 不确定

普通 `<Sequence>` 内 `useCurrentFrame()` 行为：
- 按 Remotion 文档：返回 Sequence 内的 frame（0-based，从 from 算起）
- 但 TransitionSeries.Sequence 行为**可能不同**（实测是全局 frame）
- **建议**：实测自己的项目，不要信文档

## 验证方法

```typescript
const DebugFrame = () => {
  const frame = useCurrentFrame();
  return <div style={{ position: "absolute", top: 0, left: 0, color: "red" }}>frame={frame}</div>;
};

// 加到 Scene 内部，渲染时看左上角 frame 数字
<Scene1><DebugFrame />...</Scene1>
```

## 相关
- `references/scene-subtitles-anti-pattern.md` — 由本行为导致的 bug 案例
- `references/linter-r4-design.md` — 加 R4 规则防止这类 bug
