# SRT-driven vs Character-ratio vs Global-frame：Remotion 字幕时间戳反模式详解

> **2026-06-02 m3 案例 + 2026-06-02 hy v2 案例二次发现**。本文档解释 4 种反模式根因 + 修复方法 + 验证命令。
>
> 与 SKILL.md 的"反模式案例"段互补 — 本文偏参考，SKILL.md 偏操作流程。

## 4 种反模式

### 反模式 A：硬编码段边界（5 段式）

```typescript
// ❌ 错：5 段长度硬编码，不依赖 SRT
const S1_FROM = 0;     const S1_TO = 490;    // 钩子 E1-E3
const S2_FROM = 490;   const S2_TO = 575;    // 痛点 E4
const S3_FROM = 575;   const S3_TO = 1475;   // 干货 E5-E9
const S4_FROM = 1475;  const S4_TO = 2092;   // 高潮 E10-E13
const S5_FROM = 2092;  const S5_TO = 2194;   // CTA E14
```

**问题**：硬编码 S1_TO=490 帧（16.33s），但 SRT E1+E2+E3 真实合计 20.83s（625 帧）。差 135 帧 = 4.5s 字幕提前。

**为什么会出现**：5 段式视频常见做法是"钩子 5-10s + 痛点 5s + 干货 15-20s + 高潮 10s + CTA 5-10s"，作者**按经验估时长**而不查 SRT 真实 entry 边界。

**修复**：用 `srtTimeToFrame()` 从 SRT 算段边界（详见 SKILL.md 步骤 2）。

### 反模式 B：SCENE_SUBTITLES 按段内字符比例重算

```typescript
// ❌ 错：每条字幕用"段内字符占比 × 段长"算 duration
{ text: "原生多模态，图片、视频、文档一起喂，不用再分工具。", start: 169, duration: 169 },
// 上面 169 帧 = 段内 21%~42% 区间，与 SRT 真实时间戳无关
```

**问题**：即使段边界改对了，段内字幕起始/长度仍和 SRT 真实 entry 错位。

**为什么会出现**：作者想把"5 段式"的段长均分到字幕 entry（按字符数等比），但**TTS 实际节奏由标点/语气决定**，不是字符数。

**修复**：每条字幕的 start/duration 直接对应 SRT 真实 entry 边界。

### 反模式 C：SRT 字符比例分配偏差

5 条短 entry 时长偏差 0.9-1.4s。根因是"按字符数算 duration"忽略了 TTS 标点停顿。

**修复**：用 `ffmpeg silencedetect` 找 TTS 真实断句点（`audio_video_sync_check.py` 已实现），或用 Whisper word-level timestamp 反推（详见 skill 推荐）。

### 反模式 D：SCENE_SUBTITLES entry 是"段内相对"但 useCurrentFrame 是全局（2026-06-02 hy v2 二次发现）

```typescript
// SubtitleCard 内部：
const SubtitleCard: React.FC<{sentences: ...}> = ({ sentences }) => {
  const frame = useCurrentFrame();
  // ...
  const current = sentences.reduce((acc, s) => {
    if (acc) return acc;
    return frame >= s.start && frame < s.start + s.duration ? s : null;
  }, null);
};

// 调用方式（HyMemoryComposition.tsx 行 215）：
<SubtitleCard sentences={SCENE_SUBTITLES[idx]} />
```

```typescript
// SCENE_SUBTITLES 写法（HyMemory 原版，硬编码字面量）：
const SCENE_SUBTITLES = [
  // S1 钩子：E1-E3
  [
    { text: "AI 助手...", start: 0, duration: 136 },
    { text: "上周帮客户...", start: 136, duration: 204 },
    { text: "改了 3 遍...", start: 340, duration: 198 },
  ],
  // S2 痛点：E4
  [
    { text: "Hy-Memory 是什么...", start: 0, duration: 241 },
  ],
  // S3 干货：E5-E9
  [
    { text: "它能跨对话...", start: 0, duration: 173 },
    { text: "以前写公众号...", start: 173, duration: 241 },
    { text: "长期记忆激活后...", start: 414, duration: 222 },
    // ...
  ],
  // ...
];
```

**问题**：`useCurrentFrame()` 在 `TransitionSeries.Sequence` 内部返回**全局 frame**（Remotion 2024+ 行为），不是 0-based 段内 frame。如果按"段内相对坐标"写 start=0, 136, 340，全局解读会变成 0-538 帧（视频 0-17.9s），与 S2/S3/S4/S5 段错位：
- S1 段 entry 1 start=0 → 全局 0-136 帧 ✓ (0-4.5s)
- S1 段 entry 2 start=136 → 全局 136-340 帧 ✓ (4.5-11.3s)
- S1 段 entry 3 start=340 → 全局 340-538 帧 ✓ (11.3-17.9s)
- **S2 段 entry 4 start=0 → 全局 0-241 帧 ❌** (0-8s，S2 段实际在 18.59s+)
- **S3 段 entry 7 start=414 → 全局 414-636 帧 ❌** (13.8-21.2s，S3 段实际在 32.9s+)

**为什么会出现**：作者可能假设"Scene 在自己的 Sequence 内，frame 应该是段内 0-based"，但 Remotion TransitionSeries.Sequence 内部 `useCurrentFrame()` 是**全局 frame**。

**为什么 m3 v2 修复没踩这个坑**：
- m3 是 5 段式 + 14 entries
- m3 S1 钩子段有 4 entries (E1-E4)，但 S1 段只占 0-19.2s
- **m3 S1 段 SCENE_SUBTITLES 内的 4 entries 范围（0-557 帧）与 S1 段全局 frame 范围（0-573 帧）几乎完全重合** — 即使错位也不明显
- m3 视频 10 帧抽帧 vision OCR 看到字幕内容大致对（受 OCR 不可靠影响，未发现）
- **但 hy 是 5 段式 + 13 entries，跨段严重错位** — vision OCR 看 t=0.5s 显示 E7（"长期记忆激活后..."）但 t=0.5s 应该看到 E1

**修复方法**：

**方法 1（推荐）：SCENE_SUBTITLES entry 全部用全局 frame**
```typescript
// 算 S1 段 entry 1 在全局 frame 的范围：0 + 0 = 0，0 + 136 = 136
// S2 段 entry 4：S1 段总帧 + S2 段内 start = 573 + 0 = 573
// 用 srtTimeToFrame 算
const S1_E1_START = srtTimeToFrame("00:00:00,000");  // 0
const S1_E1_DUR = srtTimeToFrame("00:00:04,700") - srtTimeToFrame("00:00:00,000");  // 141
const S2_E4_START = srtTimeToFrame("00:00:18,589");  // 558，全局
// ...
```

**方法 2：让 SubtitleCard 接收 entry start 是段内 frame，需要 Sequence 内部用 `useCurrentFrame` 上下文**
- 在 Scene 外层包 `<Sequence from={S1_FROM} durationInFrames={S1_DUR}>` 强制 Sequence 上下文
- 这样 useCurrentFrame 才是 0-based 段内

按"先做必做然后做选做" — **方法 1** 更稳（不依赖 Sequence 行为，runtime 显式计算）。

## 修复模板（方法 1）

```typescript
// 1. 算全局 frame 范围（从 SRT 真实 entry）
const S1_E1_START = srtTimeToFrame("00:00:00,000");  // 0
const S1_E1_DUR = srtTimeToFrame("00:00:04,700") - 0;  // 141
const S1_E2_START = srtTimeToFrame("00:00:04,700");    // 141
const S1_E2_DUR = srtTimeToFrame("00:00:11,750") - srtTimeToFrame("00:00:04,700");  // 211
// ... 为每个 SRT entry 算一对

// 2. SCENE_SUBTITLES 用全局 frame（不是段内）
const SCENE_SUBTITLES = [
  [
    { text: "AI 助手...", start: 0, duration: 141 },  // S1 entry 1
    { text: "上周帮客户...", start: 141, duration: 211 },  // S1 entry 2
  ],
  [
    { text: "Hy-Memory 是什么...", start: 558, duration: 250 },  // S2 entry 4, S2 起点 = 558
  ],
  // ...
];
```

**不推荐**：让 SubtitleCard 用段内 frame（方法 2）— 依赖 Sequence 行为，未来 Remotion 升级可能改变。

## 验证命令

```bash
# 1. 渲染后抽 5+ 关键帧 vision OCR
# 重点：S1 段起点 + S2/S3/S4/S5 段起点
# 期望：每个时间点显示该 SRT entry 真实文字

# 2. 跑 audio_video_sync_check.py（自动判断）
# 但注意：这个工具只判断 SRT entry end vs TTS 静音点偏差
# 不能判断字幕是否错位（需要 vision OCR 对比）

# 3. 如果 vision OCR 不可靠（mcp_minimax_understand_image 间歇失败）
# 用 PIL 像素检查字幕区是否有文字 + 颜色对比
```

## 历史案例

- **m3 v1 (2026-06-01)**：反模式 A 触发，16-24s 字幕超前 4-5s。2026-06-02 v2 修复（用 srtTimeToFrame）
- **hy v2 (2026-06-02)**：反模式 A 已修（linter PASS），但**反模式 D 触发**，t=0.5s 显示 E7 字幕。**未发布**（等 SubtitleCard 修复）
- **DeepSeek (2026-06-02)**：反模式 A 修（T6_TO 1319→1318，1 帧偏差 33ms），反模式 D 未测（linter PASS，但 6 段式字幕 entry 是否错位待验证）

## 相关文件

- SKILL.md（操作流程）
- check_composition_timecode.py（Linter）
- timecode.ts（srtTimeToFrame + assertTotalFrames）
- audio_video_sync_check.py（来自 `remotion-post-render-qa` skill）
- render_with_qa.sh（Remotion 项目内）
