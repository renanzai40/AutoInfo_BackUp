# 已知 Composition 违规清单（2026-06-02 实测）

> m3 案例触发后，用 linter 扫整个 `~/Remotion-Test/src/`，共 11 个 Composition，**10 个违规**。本文件是盘点快照，下个 session 接手时先查这里再决定修哪些。

## 违规清单

### ✅ 已修（1 个）

| 文件 | 修复方式 | 验证 |
|------|----------|------|
| `M3Composition.tsx` | 5 段 FROM/TO 全部用 `srtTimeToFrame()` 算 + 加 `assertTotalFrames()` 运行时校验 | linter PASS + 10/10 抽帧 vision OCR 全对齐 |

### 🔴 待修（10 个，按优先级）

#### 高优先级（已发或高频用）

| 文件 | 关联项目 | 状态 | 修复法 |
|------|----------|------|--------|
| `HyMemoryComposition.tsx` | 2026-06-01 业务款（已发公众号） | 5 段全硬编码 + 字符比例 SCENE_SUBTITLES | 同 m3 修复法 |
| `DeepSeekComposition.tsx` | 2026-05-25 业务款（DeepSeek 75% 折扣） | 缺 srtTimeToFrame import | 加 import + 改 5 段 |

#### 中优先级（早期/历史）

| 文件 | 关联项目 | 状态 | 修复法 |
|------|----------|------|--------|
| `LoraiComposition.tsx` | 2026-05-25 业务款 | 缺 srtTimeToFrame import | 同上 |
| `RunwayAiComposition.tsx` | 2026-05-24 业务款 | 缺 srtTimeToFrame import | 同上 |
| `TrapDoorComposition.tsx` | (不在 29 个 archived 里，可能未入库) | 缺 srtTimeToFrame import | 同上 |
| `WentechTTSComposition.tsx` | 2026-05-25 引流款（闻泰/安世） | 5 段全硬编码 | 同 m3 修复法 |

#### 低优先级（早期/历史，可能不修）

| 文件 | 状态 | 建议 |
|------|------|------|
| `SixOneEightComposition.tsx` | 缺 import（早期 618 手工版，已被 TTS 版替代） | 不修 |
| `SixOneEightTTSComposition.tsx` | 缺 import（早期 618 TTS 版） | 不修 |
| `WentechComposition.tsx` | 缺 import（早期闻泰手工版，已被 TTS 版替代） | 不修 |
| `Composition.tsx` | MyComposition 模板占位，从来不是项目 | 不修 |

## 修复法（标准模板，4 步）

```typescript
// 1. 顶部加 import
import { srtTimeToFrame, assertTotalFrames } from "./timecode";

// 2. 5 段 FROM/TO 全部用 srtTimeToFrame
const S1_FROM = srtTimeToFrame("00:00:00,000");
const S1_TO = srtTimeToFrame("00:MM:SS,mmm");  // E1+E2+E3 累计
const S2_FROM = S1_TO;
const S2_TO = srtTimeToFrame("00:MM:SS,mmm");  // E4+E5 累计
// ... S3/S4/S5 同理

// 3. M3_TOTAL_FRAMES 加断言
const M3_TOTAL_FRAMES_RAW = S1_DUR + S2_DUR + S3_DUR + S4_DUR + S5_DUR - 4 * TRANSITION_DUR;
assertTotalFrames(M3_TOTAL_FRAMES_RAW, TTS_DURATION_SEC, 30);
export const M3_TOTAL_FRAMES = M3_TOTAL_FRAMES_RAW;

// 4. SCENE_SUBTITLES 内字面量**保持不变**（段内相对坐标用字面量合理）
```

## 修复后必须做

1. 跑 linter → 必须 PASS
2. 跑 `bash scripts/render_with_qa.sh <Comp> <output> [tts] [srt]` → 必须通过 audio-video sync check
3. 抽 8-10 帧 vision OCR → 必须全对齐 SRT
4. 更新 publish_log.json known_issues（如有）

## 修复经验：避免重蹈覆辙

**不要**只修最严重的（Hy + DeepSeek），认为"其他不活跃就不动"。linter 守住**未来**写法，但**过去**的违规视频如果重新渲染就会暴露 bug。**修法同质化**：用 m3 模板可以一次性修完所有高频 Composition（4-6h）。
