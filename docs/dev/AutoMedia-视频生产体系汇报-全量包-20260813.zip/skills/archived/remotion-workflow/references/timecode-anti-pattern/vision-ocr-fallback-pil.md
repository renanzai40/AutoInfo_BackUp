# vision OCR 完全不可靠 — PIL 像素 fallback 模式（2026-06-02 实测）

## 核心结论

**在 content profile session 中，`mcp_minimax_understand_image` 完全不可靠**。多次返回错误识别，且**多次返回同一错误文字**（不是随机错识）。

**`vision_analyze` 完全看不到图片**（返回"对话中没有图片"）。

**正确做法：用 PIL 直接看像素**（不依赖任何 vision AI）。

## 不可靠的证据（2026-06-02 hy v2 案例）

抽 5 张帧，用 mcp_minimax_understand_image 读字幕：

| 时间 | 期望字幕 | vision OCR 报告 |
|------|----------|----------------|
| t=0.5s | E1: "AI 助手..." | E7: "长期记忆激活后..." |
| t=18.6s | E4: "Hy-Memory..." | E7: "长期记忆激活后..." |
| t=32.9s | E5/E6 过渡 | E7: "长期记忆激活后..." |
| t=47.0s | E7/E8 | E7: "长期记忆激活后..." |
| t=78.6s | E13: "关注壹目贯维..." | E13: "关注壹目贯维..." ✓ |

**4/5 报告看到同一 E7 文字**（不是随机错，是系统性错）。

## PIL 像素 fallback 标准做法

```python
from PIL import Image
import numpy as np
import os

# 1. 抽帧（ffmpeg）
os.makedirs("/tmp/qa", exist_ok=True)
for t, label in [(0.5, "开头"), (8.2, "E2中点"), ...]:
    os.system(f"ffmpeg -y -ss {t} -i video.mp4 -frames:v 1 -q:v 2 /tmp/qa/t{t:05.1f}.jpg")

# 2. 字幕区白像素统计（不依赖 vision OCR）
W, H = 1080, 1920
for t in [0.5, 8.2, ...]:
    for f in os.listdir("/tmp/qa"):
        if f.startswith(f"t{t:05.1f}"):
            img = Image.open(f"/tmp/qa/{f}")
            arr = np.array(img.crop((0, int(H*5/6), W, H)))  # 底部 1/6
            white_count = ((arr.min(axis=2)) > 200).sum()
            total = arr.shape[0] * arr.shape[1]
            ratio = white_count / total * 100
            print(f"t={t}s: 白像素 {white_count} ({ratio:.1f}%)")
```

## 像素读数含义

| 白像素占比 | 含义 |
|------------|------|
| **0%** | 完全黑屏（fade out 间隙 或 没字幕） |
| **1-2%** | 短字幕 |
| **2-4%** | 中等字幕 |
| **4-6%** | 长字幕 |

**不同时间点白像素数差异 = 字幕在变化**（不是同一字幕）。

**5 张图白像素数完全相同 = OCR 错的概率大**（同一字幕不可能显示 30+ 秒）。

## 进阶：hash 比对字幕区

```python
def hash_region(t):
    for f in os.listdir("/tmp/qa"):
        if f.startswith(f"t{t:05.1f}"):
            img = Image.open(f"/tmp/qa/{f}")
            arr = np.array(img.crop((0, int(H*5/6), W, H)))
            return hash(arr.tobytes())

# 比对不同时间点字幕区是否相同
h_24 = hash_region(2.4)
h_78 = hash_region(78.6)
if h_24 == h_78:
    print("⚠️ 字幕完全相同 — 字幕错位或 OCR 错")
```

## 多区域分析（找字幕实际位置）

```python
# 字幕可能在底部 1/6，但有时 SubtitleCard 在中部
for name, y_start, y_end in [
    ("顶部 1/6", 0, H//6),
    ("上中部 1/6", H//6, H//3),
    ("中部 1/3", H//3, 2*H//3),
    ("下中部 1/6", 2*H//3, 5*H//6),
    ("底部 1/6", 5*H//6, H),
]:
    region = arr[y_start:y_end]
    white_count = ((region.min(axis=2)) > 200).sum()
    total = region.shape[0] * region.shape[1]
    print(f"  {name}: {white_count} ({white_count/total*100:.1f}%)")
```

## 最终验证：发图给用户

**PIL 像素 + vision OCR 都只是间接证据**。最可靠 = **直接发图给用户看**。

按 memory "发给我看看" = 直接发文件。让用户自己看图判断：
- 字幕实际显示什么
- 字幕与 SRT 该时刻 entry 是否一致
- 字幕是否错位

```
MEDIA:/tmp/qa/t002.4_E1中点.jpg
MEDIA:/tmp/qa/t008.2_E2中点.jpg
...
```

## 验证标准（hy v3 案例）

用 PIL 验证 4/5 时间点字幕白像素 > 0%（字幕在显示）+ 与 SRT entry 期望相符。

| 方法 | 可靠性 | 用途 |
|------|--------|------|
| **PIL 白像素** | ✅ 高（hy v3 用此确认 4/5 PASS） | 主要验证手段 |
| **PIL hash 比对** | ✅ 高 | 快速发现"字幕错位" |
| **mcp_minimax OCR** | ❌ 低 | 仅作为辅助参考 |
| **vision_analyze** | ❌ 不可用 | 不要用 |
| **发图给用户** | ✅✅ 最高 | 最终验证 |

## 教训

1. **不依赖 vision OCR 做关键判断**（hy v2 错位识别成"5/5 一致"）
2. **PIL 像素 + hash 是快速诊断工具**（hy v3 用 30 秒判断 4/5 PASS）
3. **关键判断需要发图给用户**（最终验证）
4. **vision OCR 看到同一文字重复多次 = 字幕错位或 OCR 错**（要进一步验证）

## 相关
- `references/scene-subtitles-anti-pattern.md` — hy v2 错位被 OCR 误导，hy v3 用 PIL 确认
