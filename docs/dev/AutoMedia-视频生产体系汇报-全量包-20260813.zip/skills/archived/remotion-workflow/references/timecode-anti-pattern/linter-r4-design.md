# Linter R4 设计：SCENE_SUBTITLES entry 检查（2026-06-02 hy 案例驱动）

## 背景

当前 `check_composition_timecode.py` 有 3 条规则：
- R1: 5 段 `S[1-5]_(FROM|TO)` 硬编码数字
- R2: 必须 import `srtTimeToFrame`
- R3: 必须导出 `TOTAL_FRAMES`

**漏洞**：R1-R3 不查 `SCENE_SUBTITLES` 数组的 entry。**hy 案例**SCENE_SUBTITLES entry 用"段内相对"小数字（0, 136, 340）— **linter 没抓到**，导致字幕严重错位。

## R4 设计方案

```python
# 规则：SCENE_SUBTITLES entry 的 start/duration 必须是 srtTimeToFrame() 调用，不能是字面量数字
R4_SENTENCES_PATTERN = re.compile(
    r"\{\s*text:\s*[\"'].*[\"'],\s*start:\s*(\d+)\s*,\s*duration:\s*(\d+)\s*\}"
)
# 匹配: { text: "...", start: 136, duration: 204 }  ← 字面量数字

# 修复提示：改用 srtTimeToFrame("HH:MM:SS,mmm") - srtTimeToFrame("HH:MM:SS,mmm")
R4_FIX = "改用 srtTimeToFrame(\"HH:MM:SS,mmm\") - srtTimeToFrame(\"HH:MM:SS,mmm\") 算全局 frame"
```

## 为什么需要 R4

- m3 案例：R1 抓到 5 段硬编码 → ✅
- hy 案例：R1 PASS（5 段已用 srtTimeToFrame），**但 SCENE_SUBTITLES entry 错位** → R1 漏 ❌

R4 是 R1 的**逻辑延伸** — 不仅段边界要从 SRT 算，**字幕 entry 也要从 SRT 算**。

## R4 实施细则

```python
# 在 check_file() 函数中添加
content = file_path.read_text(encoding="utf-8")

# R4: SCENE_SUBTITLES entry 字面量数字
# 简单实现：找 "{ text: "..." 模式，看 start 后面是不是纯数字
sentences_pattern = re.compile(
    r'text:\s*[\'"][^\'"]+[\'"],\s*start:\s*(\d+)\s*,',
    re.MULTILINE
)
for m in sentences_pattern.finditer(content):
    line_no = content[: m.start()].count("\n") + 1
    violations.append({
        "rule": "R4-hardcoded-subtitle-entry",
        "line": line_no,
        "snippet": content.split("\n")[line_no - 1].strip()[:90],
        "msg": "SCENE_SUBTITLES entry start 是字面量数字 — 违反 m3/hy 案例铁律",
        "fix": "改用 srtTimeToFrame(\"HH:MM:SS,mmm\") 算全局 frame 编号（@ 30fps）",
    })
```

## R5 候选：Scene 工厂 + SCENE_SUBTITLES 索引

hy 案例另一个 bug：`SCENE_SUBTITLES[idx]` 当 idx > SCENE_SUBTITLES.length 时返回 undefined → TypeError

**预防**：扫 `SCENE_SUBTITLES[` 出现次数和 SCENE_SUBTITLES 数组定义，确认引用都在范围内。

实际**更好的修复**：linter 不强制这个，但**设计时**建议 SCENE_SUBTITLES 始终用单一全局数组（所有 Scene 用 `SCENE_SUBTITLES[0]`）。

## R6 候选：字幕 fade 时机

hy v3 案例：t=45.1s 字幕区 0% 白像素（黑屏）— 可能是 SubtitleCard 的 fadeThreshold 算错。

**R6 设计**：
- 扫 SubtitleCard 的 fadeThreshold 计算：`Math.max(10, Math.floor(duration * X))`
- 检查 X 比例（如 0.85）是否合理
- 太低（如 0.5）→ fade out 早于字幕结束 → 字幕提前消失
- 太高（如 0.99）→ fade out 几乎不存在 → 字幕突兀

## 实施优先级

按"先做必做然后做选做"：

| Rule | 优先级 | 工作量 |
|------|--------|--------|
| **R4 (SCENE_SUBTITLES)** | 🔴 P0 | 30 min |
| R5 (Scene idx 范围) | 🟡 P1 | 1h |
| R6 (fade threshold) | 🟡 P1 | 30 min |

**R4 最优先** — 因为已有反模式案例（hy 错位），加 R4 立即堵住同类 bug。

## 完整 R4 patch

```python
# 加到 check_composition_timecode.py
VIOLATIONS.append({
    "id": "R4-hardcoded-subtitle-entry",
    "description": "SCENE_SUBTITLES entry start/duration 必须是 srtTimeToFrame() 调用",
    "pattern": re.compile(
        r'text:\s*[\'"][^\'"]+[\'"],\s*start:\s*(\d+)\s*,',
        re.MULTILINE
    ),
    "fail_msg": "SCENE_SUBTITLES entry start 是字面量数字 — SubtitleCard 在 TransitionSeries.Sequence 内用全局 frame",
    "fix_hint": "改用 srtTimeToFrame(\"HH:MM:SS,mmm\") 算全局 frame：\n"
                "  start: srtTimeToFrame(\"00:00:14,169\"),\n"
                "  duration: srtTimeToFrame(\"00:00:18,589\") - srtTimeToFrame(\"00:00:14,169\")",
})
```

## 测试用例

```python
# 在 /tmp/ 放测试文件，跑 linter 验证

# Case 1: 应 FAIL（hy v2 风格）
test_v2 = '''const SCENE_SUBTITLES = [
  [ { text: "E1", start: 0, duration: 136 } ],
  [ { text: "E2", start: 0, duration: 241 } ],
];'''

# Case 2: 应 PASS（hy v3 修复版）
test_v3 = '''const SCENE_SUBTITLES = [
  [ { text: "E1", start: srtTimeToFrame("00:00:00,000"), duration: srtTimeToFrame("00:00:04,700") - srtTimeToFrame("00:00:00,000") } ],
];'''
```

## 相关
- `references/scene-subtitles-anti-pattern.md` — 完整反模式案例
- `references/transition-sequence-frame-behavior.md` — `useCurrentFrame` 行为
