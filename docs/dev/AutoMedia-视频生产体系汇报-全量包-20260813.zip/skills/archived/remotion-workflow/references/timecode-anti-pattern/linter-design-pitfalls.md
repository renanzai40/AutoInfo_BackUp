# Linter 设计踩坑（2026-06-02）

> m3 案例后写的 `check_composition_timecode.py` 经历 2 轮迭代才稳定。记录决策原因和坑。

## 反复过的设计选择

### ❌ 第一版：把"SCENE_SUBTITLES 内字面量"也列为违规

最初设计：
```python
# 规则: { text: "...", start: 0, duration: 125 }  → 报硬编码
pattern = r"\{\s*text:\s*\"[^\"]*\",\s*start:\s*(\d+),\s*duration:\s*(\d+)\s*\}"
```

**问题**：m3 修复版的 SCENE_SUBTITLES 写的是：
```typescript
{ text: "等等——MiniMax M3 真的来了。", start: 0, duration: 125 }
```

`start: 0`（段内开头）和 `duration: 125`（段内相对帧数）**都是字面量，但都是合理的**。段内相对坐标用字面量是 OK 的，只要 5 段 FROM/TO 本身从 SRT 算就对。

**结果**：第一版 linter 把 v2 修复版也误报为违规。

### ✅ 第二版：只查 5 段 FROM/TO 的硬编码

最终设计：
```python
# 只查 const S[1-5]_(FROM|TO) = \d+;
pattern = r"(?:const|let|var)\s+S[1-5]_(?:FROM|TO)\s*=\s*(\d+)\s*;"
```

**理由**：
1. **根因 A 是 5 段硬编码**（不是 SCENE_SUBTITLES 字符比例 — 那已经被 m3 修复版用 SRT 时间戳直接绑帧号解决了）
2. 段内相对坐标（start/duration）= 段内偏移，用字面量是合理的
3. 让 v2 修复版 PASS，把 v1 反模式 FAIL — 区分精确

### ❌ 第一版：每行报所有匹配的违规

最初逻辑：每行匹配到 `S1_FROM = 0;     const S1_TO = 490;` → 报 2 次违规（FROM + TO）。

**问题**：用户看到 10 个 R1 违规，但实际只有 5 个真违规（每行 2 个 = 10 匹配）—— 噪音大。

**修法**：用 `seen = {(rule_id, line_no)}` 去重，同一行只报 1 次。

### ❌ 第一版：单行 import 检查

最初设计要求每行有 import，但 import 只在文件顶部一次。

**修法**：用 `re.MULTILINE` 全文件搜 + 缺 import 才报违规。

## 关键洞见

1. **Linter 规则越严越好是错的** —— 必须让修复版 PASS，否则 linter 自身不可信
2. **"硬编码"≠"字面量数字"** —— 段内相对坐标用字面量合理，绝对坐标必须函数调用
3. **去重** —— 同一 (rule, line) 多次匹配要 dedup，否则用户被噪音淹没
4. **测试用例必须包含"修复版"** —— 验证修复版 PASS 才能保证规则不误报
5. **断言函数** —— `assertTotalFrames(value, ttsDur, fps)` 在 Composition 顶部调用，运行时会 panic，**比 linter 早一步发现问题**

## 教训：linter 不能取代断言

linter 拦截**未来写法**（写 Composition 时就被拦），但**已渲染的视频**怎么办？需要：
- **A** 层（linter）—— 写时拦截
- **B** 层（render 钩子 + audio_video_sync_check.py）—— render 完兜底
- **C** 层（assertTotalFrames 运行时 panic）—— render 时立即报错

三层缺一不可。**只有 A = 漏已发布的视频；只有 B = 漏 render 期间 linter 没跑；只有 C = 漏静态检查。**
