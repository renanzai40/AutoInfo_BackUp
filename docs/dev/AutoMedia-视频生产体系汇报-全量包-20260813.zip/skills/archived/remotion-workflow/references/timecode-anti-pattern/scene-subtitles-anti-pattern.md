# SCENE_SUBTITLES 反模式（2026-06-02 hy 案例 · ⚠️ 已部分过期）

> **⚠️ 2026-06-03 实测修正（重要，读这文件前必看）**：
>
> 本 reference 描述的 2026-06-02 hy 案例根因（"TransitionSeries.Sequence 内 useCurrentFrame() 返回全局 frame"）**已被后续实测推翻**。
>
> **当前权威结论**（来自 SKILL.md 主文档 2026-06-03 修正段 + Runway Aleph 2 v6/v7 实测）：
> - `TransitionSeries.Sequence` 内的 `useCurrentFrame()` **返回段内相对 frame**（0-based），不是全局 frame
> - SCENE_SUBTITLES entry 写**段内相对 frame**（`start: 0, duration: 151`）是**正确**做法
> - 写**全局 frame**（`start: 307, duration: 136`）反而会**错位**（Runway v1 案例：8/10 帧字幕错位）
>
> **保留本文作为历史案例记录**：下面记录的"hy 案例"现象（t=0.5s 显示 E7 字幕）仍真实，但根因不是"坐标系错"，而是 hy 案例**另有独立 bug**（具体未复现，可能是 SubtitleCard fade 时机问题）。
>
> **未来 agent 不要被本 reference 误导**——以 SKILL.md 主文档"反模式 D 实测修正"段为准。

---

## 现象（与 m3 案例类似但根因不同 · 2026-06-02 历史记录）

- 视频时长 82.30s vs TTS 82.26s（**段边界正确**，差 33ms）
- 2468 帧 = TTS × 30fps ✓
- **但字幕严重错位**：t=0.5s 应该显示 E1，实际显示 E7（41-49s 段）
- vision OCR 报告前 4 个抽帧时间点都看到 E7 文字

## 根因（hy 案例 2026-06-02 当时推断，**已被 2026-06-03 实测推翻**）

m3 案例根因：Composition 5 段 `S?_FROM/TO` 硬编码数字（**段边界错**）

**hy 案例根因（2026-06-02 推断）**：5 段 `S?_FROM/TO` 已用 `srtTimeToFrame()` 算对了（**段边界对**），但 SCENE_SUBTITLES entry 的 `start/duration` 用"段内相对"小数字（0, 136, 340, ...）— **SubtitleCard 内部 `useCurrentFrame()` 在 `TransitionSeries.Sequence` 内返回的是全局 frame，不是 0-based 段内 frame**。

```typescript
// ⚠️ 此结论已被 2026-06-03 实测推翻：
// 实测证实 TransitionSeries.Sequence 内 useCurrentFrame() 返回段内相对 frame
const SCENE_SUBTITLES = [
  [  // S1 段
    { text: "E1...", start: 0, duration: 136 },
    { text: "E2...", start: 136, duration: 204 },
    { text: "E3...", start: 340, duration: 198 },
  ],
  [  // S2 段
    { text: "E4...", start: 0, duration: 241 },
  ],
  // ...
];
```

## 2026-06-03 实测结论（权威）

**`TransitionSeries.Sequence` 内 `useCurrentFrame()` 实测返回段内相对 frame**（与普通 Sequence 一致）：

| 项目 | SCENE_SUBTITLES 坐标系 | 渲染结果 |
|------|--------------------|----------|
| m3 v2（2026-06-02 修复版） | 段内相对 | ✅ 字幕全显示 |
| Runway v1（2026-06-03 尝试"全局 frame"） | 全局 | ❌ 8/10 帧字幕错位 |
| Runway v2（2026-06-03 改用段内 frame） | 段内相对 | ✅ 11/11 帧字幕全过 |

**结论**：SCENE_SUBTITLES 必须用**段内相对 frame**（`start: 0, duration: 200`），不是全局 frame。

## 验证（2026-06-02 hy v3 实测）

PIL 字幕区白像素分析（5 个 entry 中点）：

| 时间 | SRT | 期望 | 底部白像素 | 状态 |
|------|-----|------|------------|------|
| 2.4s | E1 | AI 助手... | 2.0% | ✅ 有字幕 |
| 8.2s | E2 | 上周帮客户... | 3.3% | ✅ 有字幕 |
| 22.7s | E4 | Hy-Memory 是什么... | 1.7% | ✅ 有字幕 |
| 45.1s | E7 | 长期记忆激活后... | **0%** | ❌ **黑屏（fade 间隙）** |
| 78.6s | E13 | 关注壹目贯维... | 2.0% | ✅ 有字幕 |

**4/5 PASS**（字幕与时间对应），但 **t=45.1s 黑屏**（fade out 时机不对，见 SubtitleCard fade 逻辑问题）。

## 关键教训（2026-06-03 更新版）

1. **m3 案例和 hy 案例是同症状但不同根因**：
   - m3 = Composition 段边界硬编码
   - hy = SubtitleCard fade 间隙 + 其他未复现 bug（**不是**坐标系错）
2. **linter R1+R2+R3 只查段边界**，**没查 SCENE_SUBTITLES entry** — 这是当前 linter 漏洞
3. **SubtitleCard 内部 frame 上下文**：实测**段内相对 frame**（不是全局）——这是 2026-06-03 修正的最终结论
4. **修复 SCENE_SUBTITLES 后字幕与时间对应**（PIL 白像素验证），但 fade out 时机是另一个问题

## Linter 扩展建议（见 references/linter-r4-design.md）

加 R4 rule：
- 扫 `SCENE_SUBTITLES` 定义
- 找 `{ text: "...", start: <数字>, duration: <数字> }` pattern
- 检查 start/duration 不是字面量数字（如 `start: 136`）—— 必须是 `srtTimeToFrame(...)` 调用或变量
- FAIL 提示：SCENE_SUBTITLES entry 必须用 srtTimeToFrame 算全局 frame

## 相关发现

- **vision OCR 完全不可靠**（多次返回错误识别）—— 详见 `references/vision-ocr-fallback-pil.md`
- **TransitionSeries.Sequence 内 useCurrentFrame 行为**——详见 `references/transition-sequence-frame-behavior.md`
- **2026-06-03 实测修正结论**——详见 SKILL.md 主文档"后续发现"段
