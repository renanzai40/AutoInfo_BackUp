# NSegmentSkeleton 段边界间隙陷阱（2026-06-09 实测）

> **症状**：Remotion 渲染时 panic `assertTotalFrames runtime panic - computed vs declared mismatch`。Declared 值与 computed 值不一致，差 64 帧（约 2.1s），超出默认 tolerance 60。

## 根因

NSegmentSkeleton 的帧数计算方式（`templates/n-segment-skeleton.tsx` L141-146）：

```typescript
// 每段 duration = (to - from) + TRANSITION_DUR（首 N-1 段含过渡，末段无）
const segmentDurs = boundaries.map((b, i) =>
  b.to - b.from + (i < N - 1 ? TRANSITION_DUR : 0)
);
// 总帧数 = SUM - (N-1) * TRANSITION_DUR（过渡帧重复计算需扣除）
const totalFrames = segmentDurs.reduce((s, d) => s + d, 0) - (N - 1) * TRANSITION_DUR;
```

化简：
- `totalFrames = SUM(to - from)`  （因为 +TRANSITION_DUR 和 -TRANSITION_DUR 正好抵消）

**关键约束**：`|totalFrames - totalTtsDuration * fps| ≤ tolerance`（默认 tolerance=60 帧 ≈ 2s）

## 问题场景

当 5 段间各有 16 帧间隙（过渡缓冲）时：

```
S1: from=0    to=195   (195 帧)
S2: from=211  to=540   (329 帧)  ← gap 16f
S3: from=556  to=1070  (514 帧)  ← gap 16f
S4: from=1086 to=1475  (389 帧)  ← gap 16f
S5: from=1491 to=1923  (432 帧)  ← gap 16f
                              SUM = 1859
```

若 TTS 音频 = 64.1s × 30fps = 1923 帧：
- `|1859 - 1923| = 64 > 60` → **FAIL**

## 修法

**解法 A（推荐）**：扩展最后一个 Segment 的 `to` 值吸收间隙

```
S5: from=1491 → to=1987  (+64 帧)
SUM = 1859 + 64 = 1923
|1923 - 1923| = 0 ≤ 60 → ✅ PASS
```

**为什么扩展 S5**：
- S5 通常是 CTA/品牌段，结尾多几帧静默画面不影响观感
- 不需要重新分配所有段的边界
- 已有 subtitles 在 S5 内部用相对 start 坐标，不受影响

**解法 B**：减小段间间隙 TRANSITION_DUR（不推荐，影响过渡动画效果）

## 计算公式

```python
audio_frames = ceil(audio_duration_seconds * fps)
current_sum = sum(b.to - b.from for b in boundaries)
gap = audio_frames - current_sum

if abs(gap) > 60:  # tolerance
    # 扩展 S5.to
    boundaries[-1].to += gap
```

## 验证

调整后重算：
```python
new_sum = sum(b.to - b.from for b in boundaries)
assert abs(new_sum - audio_frames) <= 60
```

## 预防（写 scene-data.ts 时）

写完 BOUNDARIES 后立即计算 SUM(to - from) 并与 ceil(TTS_DURATION × fps) 对比：

```typescript
// 在 scene-data.ts 末尾加验证注释
// SUM(to - from) = 1923  (S1:195 + S2:329 + S3:514 + S4:389 + S5:496)
// ceil(TTS_DURATION × fps) = ceil(64.1 × 30) = 1923
// diff = 0 ✅
```

## 参考

- 案例文件：`src/blocks/douyin-baike-qwen/scene-data.ts`（2026-06-09 修复）
- NSegmentSkeleton 源码：`templates/n-segment-skeleton.tsx`
