# Remotion Post-Render QA Gate

**Trigger**: Remotion render completes successfully (exit code 0), before delivery.

## Gates

### thumbnail-extracted (BLOCK_delivery)
Extract ≥3 keyframes:
- Video start (5%), middle (50%), end (95%)
- Additional frames at each scene transition

```bash
ffmpeg -ss 00:01 -i OUTPUT.mp4 -vframes 1 thumb_001_start.png
ffmpeg -ss 00:15 -i OUTPUT.mp4 -vframes 1 thumb_002_mid.png
ffmpeg -ss 00:30 -i OUTPUT.mp4 -vframes 1 thumb_003_end.png
```

### duration-verified (BLOCK_delivery)
ffprobe actual duration vs expected — within ±5s.

### pixel-brightness-qa (BLOCK_delivery)
Scan subtitle region (bottom H/6) for bright pixels (>50 bright = subtitle present).
Check all SRT entry midpoints + silent end segment.
**Replaces random Vision AI sampling** (too high miss rate).

### audio-video-sync-qa (BLOCK_delivery if >0.7s off)
3-step diagnosis:
1. ffprobe video vs TTS duration — difference < 0.5s
2. ffmpeg silencedetect for TTS real pause points
3. Extract 10+ frames, vision OCR subtitle text vs SRT

**P0-11**: Must extract ≥10 frames (not 5 — 5 can all land in S1).
**P0-10**: Check frame mtime before vision QA (multisession pollution).

### visual-inspection-logged (BLOCK_delivery)
Check and log: subtitle completeness, animation smoothness, data accuracy,
transition smoothness, audio sync, aspect ratio (9:16), brand CTA presence.

### file-size-reasonable (BLOCK_delivery)
- 9:16 portrait 720p: 8-15MB/min
- **HARD LIMIT: >30MB can't send via Feishu bot**
- >30MB → ffmpeg compress (crf 28 + aac 96k)

## Automation Script

```bash
python3 ~/.hermes/profiles/content/skills/remotion-workflow/scripts/audio_video_sync_check.py \
  out/video.mp4 public/audio/tts.mp3 03_video/subtitle.srt
```

## Key Rules

- **Never** reuse old frame captures from /tmp/audio_video_sync/ — `rm -rf` and regerate after every re-render
- **Multi-session pollution**: /tmp/audio_video_sync/ is shared across sessions; check mtime < 5 min
- **Vision OCR fallback chain**: qwen3.7-plus → PIL pixel check → vision_analyze
- **No single OCR result is trustworthy** — cross-validate with ≥2 tools
