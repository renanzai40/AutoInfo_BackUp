# Remotion Composition Timecode Anti-Pattern

> **Rule (2026-06-02 case solidified)**: Composition frame boundaries and subtitle entry start/duration **MUST directly bind to SRT real timestamps** — never hardcode segment lengths or use character-ratio recalculation.
>
> **Violating this rule = 100% reproducing the m3 case 16-24s subtitle-leading-audio-by-4-5s bug.**

## Root Cause

### A: Hardcoded segment boundaries
```typescript
// ❌ Wrong: 5 segment lengths hardcoded, not derived from SRT
const S1_FROM = 0;  const S1_TO = 490;
// SRT entries E1+E2+E3 sum to 20.83s (625 frames), but S1_TO=490 (16.33s) — 4.5s early
```

### B: Character-ratio subtitle recalculation
```typescript
// ❌ Wrong: subtitle start/duration from "char ratio × segment length", not SRT
{ text: "Multimodal native...", start: 169, duration: 169 }, // no relation to SRT entry
```

## Correct Approach

### Step 1: Frame numbers FROM SRT
```typescript
function srtTimeToFrame(timeStr: string, fps = 30): number {
  const [h, m, rest] = timeStr.split(':');
  const [s, ms] = rest.split(',');
  return Math.round((+h*3600 + +m*60 + +s + +ms/1000) * fps);
}
```

### Step 2: Segment boundaries via SRT entry cuts
```typescript
const S1_TO = srtTimeToFrame("00:00:14,169");  // E1+E2+E3 end
const S2_FROM = S1_TO;                           // E4 start
const S2_TO = srtTimeToFrame("00:00:23,750");    // E5 end
```

### Step 3: SCENE_SUBTITLES bound to real SRT
```typescript
// S2 (segment frames 425-712, segment-relative 0-287):
[{ text: "Each switch resets style...", start: 0, duration: 200 },    // E4: 425-625
 { text: "M3 focuses on 3 things—", start: 200, duration: 87 }]        // E5: 625-712
```

### Step 4: Verify total frames = TTS duration × fps
```typescript
// 73.12s × 30fps = 2194 frames
assertTotalFrames(TOTAL, 73.12, 30, 60);  // tolerance=60 absorbs transition overlap
```

## Related files

Detailed references in `references/timecode-anti-pattern/`:
- `audio-video-sync-defense-2026-06-02.md` — A+B implementation log
- `known-composition-violations-2026-06-02.md` — 10 violated Compositions
- `srt-driven-vs-character-ratio.md` — Detailed root cause A/B/C/D
- `scene-subtitles-anti-pattern.md` — Subtitle coordinate anti-pattern
- `linter-design-pitfalls.md` — Linter iteration history
- `linter-r4-design.md` — R4 rule design
- `transition-sequence-frame-behavior.md` — useCurrentFrame() behavior
- `document-vs-mechanism.md` — Defense strength evaluation framework
- `vision-ocr-fallback-pil.md` — OCR fallback approach

Scripts in `scripts/`:
- `check_composition_timecode.py` — Linter (exit 0=PASS, 1=BLOCK)
- `srtTimeToFrame.py` — SRT→frame converter + 5-segment boundary template generator

Templates in `templates/`:
- `segment-boundary-from-srt.tsx` — Correct 5-segment Composition template
- `long-narration-subtitles.ts` — 5-segment × N-entry subtitle builder

## Known Anti-Patterns

| # | Anti-Pattern | Fix |
|---|-------------|-----|
| 1 | Hardcoded segment FROM/TO | Use `srtTimeToFrame()` |
| 2 | Character-ratio subtitle duration | Use SRT entry real timestamps |
| 3 | Nested components using absolute frames | Use `relFrame = frame - appearAt` |
| 4 | assertTotalFrames default tolerance=1 | Pass explicit tolerance=60 |
| 5 | S5_TO based on SRT final entry | S5_TO = TTS end (ffprobe measured) |
| 6 | TransitionSeries import from "remotion" | Import from "@remotion/transitions" |
| 7 | Video dimension mis-calculation (1080×1920 vs 1920×1080) | Always verify with PIL/ffprobe |

## Tools

```bash
# Linter
python3 ~/.hermes/profiles/content/skills/remotion-workflow/scripts/check_composition_timecode.py src/

# SRT to frame converter
python3 ~/.hermes/profiles/content/skills/remotion-workflow/scripts/srtTimeToFrame.py subtitle.srt 30

# Sync check (from remotion-post-render-qa)
python3 ~/.hermes/profiles/content/skills/remotion-post-render-qa/scripts/audio_video_sync_check.py out/video.mp4 audio.mp3 subtitle.srt
```
