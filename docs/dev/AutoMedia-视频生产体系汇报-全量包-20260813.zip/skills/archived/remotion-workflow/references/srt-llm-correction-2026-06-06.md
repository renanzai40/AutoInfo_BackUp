# SRT LLM 校正 Pipeline（2026-06-06 实战）

> **触发条件**：Whisper medium 模型转写中文 SRT 后仍有 ~10% 关键术语误识别，必须用 LLM 校正。Tiny 模型误识别率 30-40%，**禁止使用**。

## 背景

2026-06-06 配音师困在 AI 里（业务款）+ 红果短剧收益断崖（引流款）生产时：

| 模型 | entry 数 | 误识别率 | 关键术语 |
|---|---|---|---|
| Whisper tiny | 41 (voice) / 37 (hongguo) | ~30-40% | "三秒生音素财"代替"3秒声音素材"，"佩营是"代替"配音师"，"千字"误为"签字" |
| Whisper medium | 21 (合并更连贯) | ~10% | "一目贯为"代替"壹目贯维"，"阴谋"代替"殷某"，"名法点"代替"民法典"，"预值"代替"阈值" |

**结论**：必须用 medium + LLM 校正，tiny 不可用。

## 完整 Pipeline（4 步）

### Step 1: Whisper medium 转写（不要用 tiny）

```python
import whisper
m = whisper.load_model('medium', device='cpu')  # 关键: medium 不是 tiny
r = m.transcribe(mp3, language='zh', word_timestamps=True, fp16=False)

# 写 SRT（标准 HH:MM:SS.mmm 格式）
for i, seg in enumerate(r['segments'], 1):
    s_h, s_m, s_s = int(seg['start']//3600), int((seg['start']%3600)//60), seg['start']%60
    e_h, e_m, e_s = int(seg['end']//3600), int((seg['end']%3600)//60), seg['end']%60
    f.write(f"{i}\n{s_h:02d}:{s_m:02d}:{s_s:06.3f} --> {e_h:02d}:{e_m:02d}:{e_s:06.3f}\n{seg['text'].strip()}\n\n")
```

**为什么用 medium**：
- tiny ~390M 参数 → 中文误识别率高，关键术语全错
- medium ~769M 参数 → 大部分内容可读，仅术语级误识别
- large 更好但慢（30s 音频要 2-3 分钟），medium 是性价比甜点

### Step 2: LLM 校正（DeepSeek-v4-flash + 原文对比）

**关键技巧**：把"原始正确文本"（truth）+ "ASR 转写"（按 entry 编号）一起给 LLM，让 LLM 输出"按 ASR entry 编号顺序的校正文本"。

```python
# 把 ASR entry 编号化
asr_lines = [f"{i+1}. {text}" for i, text in enumerate(entries)]
asr_text = '\n'.join(asr_lines)

# Prompt 模板（实测有效）
prompt = f"""你是中文ASR校正专家。我会给你Whisper ASR转写（含大量误识别）和原始正确文本（权威）。

【原始正确文本】：
{truth}

【Whisper ASR转写】（共{n}条）：
{asr_text}

请输出{n}行校正后的文本，每行格式：编号. 文本
- 严格保持{n}条
- 编号从1开始连续
- 校正ASR误识别（如"一目贯为"→"壹目贯维"，"阴谋"→"殷某"，"名法点"→"民法典"，"预值"→"阈值"等）
- 文本要短（每条约5-15字），与ASR分段对应
- 不要思考/解释，只输出{n}行文本
"""
```

**Prompt 关键要素**：
1. **truth 段必须完整**（不是 partial，LLM 需要全上下文）
2. **明确 entry 数量约束**（"严格保持 {n} 条"）
3. **明确编号格式**（"编号从1开始连续"）
4. **明确长度约束**（"每条约 5-15 字"）——避免 LLM 把多条合并成一条
5. **明确禁思考**（"不要思考/解释"）——节省 max_tokens
6. **温度 0.0**——校正任务要确定性

**API 调用**：
```python
url = "https://opencode.ai/zen/go/v1/chat/completions"
payload = {
    "model": "deepseek-v4-flash",
    "messages": [{"role": "user", "content": prompt}],
    "temperature": 0.0,
    "max_tokens": 4000,  # 必须 ≥ 实际输出，21 entry 校正约 600-800 tokens
}
headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
```

**注意 .env 文件 \r 换行**（6-06 实战踩坑）：
```bash
# ❌ 用 export $(cat .env | xargs) 会带 \r
# ✅ 正确: export $(cat .env | tr -d '\r' | xargs)
```

### Step 3: 数量对齐 + 时间戳保留

LLM 输出 21 行（因为 medium SRT 是 21 entry）→ 1-1 映射到 medium SRT entry，**保留 ASR 时间戳，用 LLM 校正文本**：

```python
# LLM 输出解析
items = []
for line in corrected.split('\n'):
    m = re.match(r'(\d+)\.\s*(.+)', line.strip())
    if m: items.append((int(m.group(1)), m.group(2).strip()))

# 数量对齐
if len(llm_output) >= len(asr_entries):
    corrected_text = [t for n, t in sorted(llm_output)[:len(asr_entries)]]
else:
    # 不足用原文 fallback
    corrected_text = [t for n, t in sorted(llm_output)]
    while len(corrected_text) < len(asr_entries):
        corrected_text.append(asr_entries[len(corrected_text)][3])

# 构造新 entry（保留时间戳 + LLM 文本）
new_entries = []
for i, (idx, start, end, _) in enumerate(asr_entries):
    new_entries.append((idx, start, end, corrected_text[i]))
```

### Step 4: 注入 segments 数组（必填 SRT entry）

```typescript
const segments: SegmentData[] = [
    { idx: 0, label: "钩子", baseHue: 0, subtitles: [
        { text: "三秒声音素材就能克隆出你的声音", start: 0, duration: 124 },
    ], NumberBlock: S1VoiceClone },
    // ... 5 段共 21 entry
];
```

**start 必填绝对帧**（Composition 全局），不是段内相对。SubtitleCard 用 `frame >= s.start && frame < s.start + s.duration` 判断显示。

## 常见 ASR 误识别清单

| ASR 输出 | 正确 | 来源 |
|---|---|---|
| "一目贯为" / "一目贯维" | "壹目贯维" | 品牌名 |
| "阴谋" | "殷某" | 配音师姓名 |
| "名法点" | "民法典" | 法律名称 |
| "预值" | "阈值" | 短剧术语 |
| "千字" → "签字" | "千字" | 价格单位 |
| "都底" → "兜底" | "兜底" | 投资术语 |
| "纷张" → "分账" | "分账" | 短剧术语 |
| "聲音" → "声音" | "声音" | 简繁混用 |
| "ROR" → "ROI" | "ROI" | 投资指标 |
| "外国网红中国搭便车" | 正确 | 偶发 |

## 必读清单（首次跑前必看）

1. ✅ **Whisper medium** 不要用 tiny
2. ✅ **truth 完整 + 数量约束 + 温度 0.0**
3. ✅ **max_tokens ≥ 4000**（tiny LLM 思考会占满 2000 token）
4. ✅ **.env 读 \r**（`tr -d '\r'`，否则 Header 报错）
5. ✅ **数量对齐**（LLM 输出数 vs ASR entry 数）
6. ✅ **保留 ASR 时间戳**（不是 LLM 给的时间戳）
7. ✅ **注入 segments**（不要让 subtitles: [] 留着——6-06 首次渲染踩坑）
8. ✅ **vision QA 抽 8 帧验证字幕**（像素亮度法，>30 亮像素 = 有字幕）

## 6-06 实战数据

| 视频 | ASR 误识别 | LLM 校正后 | 渲染后 vision QA |
|---|---|---|---|
| 配音师业务款（77.7s）| 12/21 错（"一目贯为"等）| 21/21 正确（"壹目贯维"等）| 8 帧字幕全显示（亮像素 >100）|
| 红果短剧引流款（79.2s）| 9/21 错 | 21/21 正确 | 8 帧字幕全显示 |

**质量对比**：
- 校正前字幕：用户看到"配音师阴谋获赔 25 万元"（语义错乱）
- 校正后字幕：用户看到"配音师殷某获赔 25 万元"（原文准确）

## 工具脚本（建议沉淀到 scripts/）

未来可以做：
```python
# llm_correct_srt.py - 完整 pipeline 封装
# 入参: mp3_path, truth_path, output_srt_path
# 步骤: 1) whisper medium 2) LLM 校正 3) 输出 SRT
```

这是 6-06 踩出来的标准 pipeline，下个视频项目应该直接调用。
