# Remotion Project Initialization

## Trigger

话题已确认、脚本已通过 Humanizer/Copy-review/Brand CTA 后，开始制作 Remotion 视频之前。

## Steps

### Step 1: Create Project Directory Structure

Remotion 项目统一在 `/home/renanzai/Remotion-Test/` 根项目。所有话题的 Composition.tsx 写到 `src/` 顶层，`public/audio/` 共享 TTS 音频。

### Step 2: Define Composition Parameters

```tsx
// src/index.tsx（入口文件，每个项目必须有）
import { registerRoot } from "remotion";
import { RemotionRoot } from "./Root";
registerRoot(RemotionRoot);

// src/Root.tsx（注册 Composition）
```

**Checks:**
- Composition ID 与视频主题匹配
- `durationInFrames`: 基于 TTS 音频时长计算（`ceil(seconds × 30)`）
- fps: 30
- width/height: 1080 × 1920（竖屏 9:16）
- 音频时长 → 帧数：`frames = ceil(audio_duration_seconds × fps)`

### Step 3: Establish Scene List

对照脚本，将视频分成 N 个场景，每个有独立 Scene*.tsx 组件和明确的帧范围。

- 5 段式脚本 → 5-7 个场景
- 每个场景对应脚本的一个段落

### Step 4: Confirm TTS Audio Ready

- TTS 音频文件在 `public/audio/`
- 音频时长已记录（用于计算 totalFrames）
- 音频格式为 mp3

### Step 5: Project Structure Verification

| 错误 | 症状 | 解法 |
|------|------|------|
| `index.tsx` 缺失 | "Could not find entry point" | 创建 `src/index.tsx` |
| Root.tsx 从 `@remotion/cli` import | React error 130 | 改用 `import { Composition } from "remotion"` |
| `node_modules` 是 symlink | bundler 行为不一致 | 统一在 Remotion-Test/ 根项目管理 |
| `Text` 组件渲染为 undefined | React error 130 | 用 div-based `SubtitleText` 组件替代 |

### key Command

```bash
# Render test
npx remotion render <ID> out/test.mp4 --log=error
```
