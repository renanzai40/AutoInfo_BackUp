---
name: remotion-workflow
description: > 
  Remotion 短视频生产完整工作流 — 从话题确认到视频交付的全链路 gate+步骤。 每次 Remotion 视频制作必须按此链路顺序执行，任何 gate 失败都必须修复后重走， 不得跳过已失败的 gate 继续推进。 强制铁律（P0-7~P0-16，2026-06-05 v10 + 2026-06-06 NSegmentSkeleton 实战固化）：P0-7 重渲染必重跑 sync_check 抽新帧；P0-8 重做必继承 v10 NSegmentSkeleton + 12 通用组件；P0-9 terminal cwd 必设 + ffprobe 必 hardcode 路径；P0-10 vision QA 必先看抽帧 mtime 防 multisession 污染；P0-11 vision QA 必抽 ≥10 帧防采样偏差；P0-12 TTS 声音是品牌资产不可擅自换；P0-13 Whisper pre-send 必验证 mp3 实际内容 = SRT 文本（防 session 113223 时代 mp3 ≠ SRT 错配）；**P0-14 segments[i].subtitles 必填 SRT entry 数组（传 `[]` = 视频无字幕，6-06 配音师+红果短剧首次渲染踩坑）；P0-15 audioSrc 必传字符串字面量不调 staticFile（双前缀报错）；P0-16 Whisper 中文用 medium 模型 + LLM 校正（tiny 误识别率 30-40%）**。

  本 skill 是入口，总览链路。具体步骤的详细规范在对应 sub-skill 中。
  不得跳过已失败的 gate 继续推进。
category: remotion
related_skills:
  - remotion-image-qa
  - publish-log-schema
  - short-video-script
  - humanizer
  - copy-review
  - brand-cta-review
trigger: |
  任何 Remotion 视频项目开始时（写 Composition / 改 SRT / 渲染 / 交付）。
  加载本 skill 后,所有 related_skills 都会自动加载。
---

# Remotion 短视频生产完整工作流

> **入口 skill**——本文件只放总览、链接、6+1 步工作流。具体步骤的详细规范在对应 sub-skill 中。

## ⚠️ 前置必读（2026-06-02 G 任务新增）

**任何 Remotion Composition 写 FROM/TO 帧边界或 SCENE_SUBTITLES entry 前，必须先读 `references/timecode-anti-pattern.md`**。硬编码段边界 + 字符比例分配 = m3 案例（16-24s 字幕超前音频 4-5s）。违反 = 100% 复现 bug。详细参考文件在 `references/timecode-anti-pattern/`。

**写 publish_log.json 前必读 `publish-log-schema` skill**（schema v2，jsonschema 验证可用）。

**改本工作流任何文件（Composition .tsx / scripts/ / SKILL.md / 配置文件）前必读 `automedia-production-guard` skill 的 Backup-First 铁律段**（2026-06-02 用户明确要求）。备份目录规范：`/tmp/audit_backup_<YYYYMMDD>_task<X>/`，**必写 `MANIFEST.md` 含备份证据 + patch 计划 + diff 预览 + 验证清单 + 回滚方案**（2026-06-06 workflow-clarification 方法论固化）。详见 `workflow-clarification` skill 6 步执行工作流。

## 🆕 新增坑（2026-06-06 实战）—— NSegmentSkeleton 首次接入必读

详见 `references/6-06-nsegment-skeleton-integration-gotchas.md`（坑 1: audioSrc 必传字符串字面量不调 staticFile；坑 2: import 路径 `../templates/`；坑 3: import effects-v9 必 `./` 同目录）。

**Bug 解法表新增 3 行**（NSegmentSkeleton 集成必查）：

| **NSegmentSkeleton `audioSrc` 必传字符串字面量**（6-06 实战，**首次接入 NSegmentSkeleton 必读**）| `NSegmentSkeleton` 内部 L169 已调 `staticFile(audioSrc)`，调用方**禁止再包** `staticFile("audio/...")` ——会变 `/public/public/audio/...` 双前缀报错。`audioSrc="audio/xxx.mp3"` 即可。详见 `references/6-06-nsegment-skeleton-integration-gotchas.md`（坑 1）|
| **从 `src/XxxComposition.tsx` import 路径**（6-06 实战）| `import NSegmentSkeleton from "../templates/n-segment-skeleton"`（跳出 `src/`）+ `import effects-v9 from "./effects-v9"`（同目录）。**绝不能** `../templates/...` 写成 `./templates/...`（在 `src/templates/` 找不存在），也**绝不能** `./effects-v9` 写成 `../effects-v9`（跳到项目根错位置）。详见 `references/6-06-nsegment-skeleton-integration-gotchas.md`（坑 2+3）|
| **🚨 segments[i].subtitles 必填 SRT entry 数组**（6-06 实战，**最严重踩坑**）| `NSegmentSkeleton` 内部 `<SubtitleCard sentences={segment.subtitles} />`（templates/n-segment-skeleton.tsx L169 附近）直接读 subtitles 渲染。**传 `subtitles: []` = 视频帧上完全无字幕**（音画同步 OK 但用户看不到任何文字）。6-06 配音师+红果短剧首次渲染后 vision QA 抽 8 帧验证字幕区域亮像素 = **7/8 帧为 0**。**正确做法**：①解析 SRT（medium 模型，详见 P0-16）→ ②按 5 段时间窗分配到 segments[i].subtitles → ③每段 subtitles = `[{text, start, duration}, ...]`，start 是**绝对帧**（Composition 全局），duration 是 entry 持续帧数。详见 `references/6-06-nsegment-skeleton-integration-gotchas.md`（坑 4）|

## 🆕 6+1 步工作流（v12 2026-06-09 修正：公众号上传在文案 Track，不在视频 Track）

### 核心设计：两条并行 Track

```
0. 选题确认（user 拍板）
    ↓
┌──────────────────────────────────────────────────────────┐
│  ═══ 文案 Track（不依赖视频） ═══     ═══ 视频 Track ═══  │
│                                                          │
│  G1 三阶 gate（全 5 平台）          Step 1 模板覆盖分析    │
│  (humanizer→copy-review            Step 2 资产 Whisper   │
│   →brand-cta-review)               Step 3 Composition    │
│       ↓                              Step 4 scene-data   │
│  封面图生成 + 上传获取 thumb        Step 5 渲染前门控     │
│       ↓                              Step 6 渲染+QA      │
│  [公众号上传] ← **放这里**               ↓                │
│  不依赖视频渲染完成                  视频交付              │
│  G1-G3 全部通过 + 封面就绪                               │
│  = 可上传                                               │
└──────────────────────────────────────────────────────────┘
```

**关键规则**：公众号上传触发条件是「文案 Track G1-G3 通过 + 封面图就绪」，不是「视频渲染完成」。两条 Track 并行推进，谁先到终点谁先触发。

## 6+1 步工作流（v12 终极固化，2026-06-09 加公众号自动上传）

```
0. 选题确认（user 拍板）
    ↓
[Step 1] 模板覆盖分析 (agent 自判断, 10 min)
[Step 2] 资产 Whisper 5 件套验证 (agent 跑, 5 min)
[Step 3] Composition 模板选型 (agent 决定, 5 min, 必用 v10 资产)
[Step 4] scene-data SRT 驱动 (agent 写, 15 min, SRT 为唯一事实源)
[Step 5] 渲染前门控 (hook 强制, 5 min)
[Step 6] 渲染后回滚门 (agent 自跑 QA, 10 min)

=== 并行分支 ===
文案 Track（与视频 Track 同时启动，不依赖 Remotion 渲染）：
  5 平台文案 → humanizer → copy-review → brand-cta-review
    ↓ G1-G3 全部通过后，**自动触发**：
    ├── ① 生成封面图（ComfyUI 或 PIL）
    ├── ② 上传封面到公众号获取 thumb_media_id
    ├── ③ 检查 HTML 排版（G4/G5 门控）
    └── ④ safe_upload_wechat.py（自动上传草稿）
    ↓
  知乎/小红书/抖音/B站 文案待发布

视频 Track：
  TTS → Whisper SRT → Remotion 渲染 → post-render QA → delivery gate
    ↓
  交付：视频 + SRT + 5 平台文案 + 4 审核 + publish_log
```
（公众号草稿在文案 Track 独立触发，不在此步等待）
```

**agent 自驱铁律**：❌ 禁止 "dry-run 给 user 审" / "A/B/C 选哪个" / "我建议呢" / "我先发你看"（甩锅）→ ✅ agent 自驱 + hook 兜底 + user 看交付。

## Gate 链

| # | Gate | 失败后果 |
|---|------|---------|
| G1 | 文案三阶 gate（humanizer + copy-review + brand-cta） | Pipeline STOP，不得进入 remotion |
| G2 | remotion-image-qa | Pipeline STOP，不渲染 |
| G3 | pre-render-gate | Pipeline STOP，不渲染 |
| G4 | post-render-qa | Pipeline STOP，不交付 |
| G5 | delivery-gate（+ Whisper） | Pipeline STOP，不发送 |

## 16 个强制铁律（v10 + 6-06 NSegmentSkeleton 实战固化）

- **P0-7** 重渲染必重跑 sync_check 抽新帧
- **P0-8** 重做必继承 v10 NSegmentSkeleton + 12 通用组件
- **P0-9** terminal cwd 必设 + ffprobe 必 hardcode 路径
- **P0-10** vision QA 必先看抽帧 mtime 防 multisession 污染
- **P0-11** vision QA 必抽 ≥10 帧防采样偏差
- **P0-12** TTS 声音是品牌资产不可擅自换
- **P0-13** Whisper pre-send 必验证 mp3 实际内容 = SRT 文本
- **P0-14** 🆕 6-06 实战：segments[i].subtitles 必填 SRT entry 数组（传 `[]` = 视频无字幕）
- **P0-15** 🆕 6-06 实战：audioSrc 必传字符串字面量不调 staticFile（双前缀报错）
- **P0-16** 🆕 6-06 实战：Whisper 中文用 medium 模型 + LLM 校正（tiny 误识别率 30-40%）
- **P0-17** 🆕 6-09 实战：**公众号上传触发时机 = 文案 Track G1-G3 全部通过 + 封面图就绪**，不是视频渲染完成后。两条 Track 并行，谁先到谁先触发。等待用户问公众号草稿上传了吗才上传 = workflow 缺陷。
- **P0-18** 🆕 6-12 实战：**TTS 输入必须使用纯净口播文本**。禁止将含段标题标记的脚本文件直接喂给 TTS。TTS 前必 strip 所有【】段标题标记。详见 short-video-script skill 的 TTS 输入规则章节。

## 相关 sub-skill / reference 链接

### Sub-skills (standalone)
- `remotion-best-practices`（必读）— 官方最佳实践
- `remotion-image-qa`（必读）— 帧图 Vision QA

### References (merged into this skill)
- `references/project-init.md` — 项目初始化（原 `remotion-project-init`）
- `references/pre-render-gate.md` — 渲染前硬门控（原 `remotion-pre-render-gate`）
- `references/delivery-gate.md` — 交付前门控（原 `remotion-delivery-gate`）
- `references/timecode-anti-pattern.md` — Composition 时间戳反模式（原 `remotion-timecode-anti-pattern`，含脚本在 `scripts/`，模板在 `templates/`）
- `references/post-render-qa.md` — 渲染后 QA（原 `remotion-post-render-qa`，含脚本在 `scripts/`）

### External skills
- `automedia-production-guard`（必读）— 文案+视频门控
- `automedia-project-init`（必读）— 项目结构
- `short-video-script`（必读）— 5 段式口播脚本
- `tts-voice-asset`（必读）— TTS 声音品牌资产库
- `humanizer`（必读）— 去 AI 味
- `copy-review`（必读）— 五轮结构审查
- `brand-cta-review`（必读）— CTA 零容忍项

## References

- `references/2026-06-05-v3-redo-fail-and-v4-fix.md` — 6-05 v3 失败 + v4 修复
- `references/2026-06-05-v5-subtitle-text-mismatch-fix.md` — 字幕错配
- `references/2026-06-05-p0-12-13-voice-and-whisper.md` — TTS 声音 + Whisper 验证
- `references/6-06-nsegment-skeleton-integration-gotchas.md` — **🆕 6-06 实战** NSegmentSkeleton 集成坑（audioSrc + import 路径 + segments.subtitles 空数组）
- `references/nsegment-skeleton-boundary-gap.md` — **🆕 6-09 实战** 段边界间隙陷阱：assertTotalFrames 失败时如何扩展 S5 `to` 吸收间隙
- `references/srt-llm-correction-2026-06-06.md` — **🆕 6-06 实战** Whisper medium + LLM 校正 SRT 完整 pipeline（prompt 模板 + 误识别常见清单 + 数量对齐方法）
- `references/audio-video-sync-2026-06-02.md` — m3 案例研究
- `references/redesign-rebuild-workflow.md` — v6.2/v7/v8/v9 完整案例
- `references/visual-plan-decision-tree.md` — 17 反模式索引
- `references/brand-new-5-segment-template-2026-06-05.md` — Brand new 5 段模板
- `references/2026-06-05-v11-recovery-checklist.md` — 8 机制 + 4 验证脚本
