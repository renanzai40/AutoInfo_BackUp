/**
 * long-narration-subtitles.ts — 5 段 × N entry 长解说 SCENE_SUBTITLES 模板
 *
 * 用途：SRT 多 entry（13+）+ 5 段切分 → 自动生成 SCENE_SUBTITLES
 *       start/duration 用「全局 frame」（不是段内相对），配 SubtitleCard 直接用
 * 解决：WentechTTS 5×13 / MiniMax-M3 5×14 / 未来 60s+ 中文长解说项目
 *
 * 设计要点：
 *   1. start/duration 是「全局 frame」——SubtitleCard 用 frame >= sub.start 即可命中
 *      不需要 m3 v1 那种"段内相对 + 累加"逻辑
 *   2. 段切分点是「用户决定的」——5 段 vs N entry 没有标准答案（运营节奏决定）
 *   3. 完整修复 WentechTTS 反模式：5 段 vs 13 entry 不再需要"段内字符比例"硬猜
 *
 * 用法（复制本文件到 src/，确保 timecode.ts 在同目录）：
 *   import { buildLongNarrationSubtitles } from "./long-narration-subtitles";
 *
 *   const SRT = parseSrt("path/to/subtitle.srt");  // 见下 SrtEntry[]
 *   const SCENE_SUBTITLES = buildLongNarrationSubtitles(
 *     SRT,
 *     [0, 3, 6, 9, 11],  // 5 段切分：段0含 entry 0-2, 段1含 entry 3-5, ...
 *     30
 *   );
 *   // SCENE_SUBTITLES[0] = [{text, start, duration}, ...]  // 段0的所有 entry
 *   // SCENE_SUBTITLES[1] = [...]  // 段1的所有 entry
 *   // ...
 *
 * Linter：~/.hermes/.../remotion-timecode-anti-pattern/scripts/check_composition_timecode.py
 * 详见 skill: remotion-timecode-anti-pattern
 */

// ⚠️ 复制到项目后取消下一行注释；skill 目录里这行注释掉是为了不被 tsc 误编译
// import { srtTimeToFrame } from "./timecode";

// ─── 内联 srtTimeToFrame（让模板可独立测试）───────────
// 真实项目用 ./timecode.ts 的版本（带 assertTotalFrames 等）
// 复制到项目后**删除这段** + 取消上面 import 注释
function srtTimeToFrame(timeStr: string, fps: number = 30): number {
  if (typeof timeStr !== "string" || !timeStr.trim()) {
    throw new Error(`[timecode] srtTimeToFrame: 输入必须是非空字符串，得到: ${JSON.stringify(timeStr)}`);
  }
  const parts = timeStr.split(":");
  if (parts.length !== 3) {
    throw new Error(`[timecode] srtTimeToFrame: SRT 时间戳格式应为 "HH:MM:SS,mmm"，得到: "${timeStr}"`);
  }
  const [h, m, rest] = parts;
  const secParts = rest.split(",");
  if (secParts.length !== 2) {
    throw new Error(`[timecode] srtTimeToFrame: SRT 时间戳格式错（毫秒部分），得到: "${timeStr}"`);
  }
  const hours = parseInt(h, 10);
  const minutes = parseInt(m, 10);
  const seconds = parseInt(secParts[0], 10);
  const millis = parseInt(secParts[1], 10);
  if ([hours, minutes, seconds, millis].some(Number.isNaN)) {
    throw new Error(`[timecode] srtTimeToFrame: SRT 时间戳含非数字，得到: "${timeStr}"`);
  }
  const totalSec = hours * 3600 + minutes * 60 + seconds + millis / 1000;
  return Math.round(totalSec * fps);
}

export interface SrtEntry {
  start: string;  // "00:00:07,261"
  end: string;    // "00:00:13,964"
  text: string;
}

export interface SubtitleEntry {
  text: string;
  start: number;    // 全局 frame（不是段内相对）
  duration: number; // 全局 frame
}

/**
 * SRT entries → SCENE_SUBTITLES（5 段 × N entry）
 *
 * @param srtEntries 全部 SRT entry（按时间排序）
 * @param segmentCuts 段切分点（entry 索引）
 *   例 [0, 3, 6, 9, 11] 表示 5 段：
 *     - 段0: entry[0..2]
 *     - 段1: entry[3..5]
 *     - 段2: entry[6..8]
 *     - 段3: entry[9..10]
 *     - 段4: entry[11..12]
 *   segmentCuts 长度 = 段数 + 1；首值必须 0；末值 ≤ entries.length
 * @param fps 帧率（默认 30）
 * @returns SCENE_SUBTITLES: Array<Array<SubtitleEntry>>，可直接喂给 SubtitleCard
 */
export function buildLongNarrationSubtitles(
  srtEntries: SrtEntry[],
  segmentCuts: number[],
  fps: number = 30
): SubtitleEntry[][] {
  // 校验
  if (segmentCuts.length < 2) {
    throw new Error(
      `[long-narration] segmentCuts 至少 2 个值（首尾切分点），得到 ${segmentCuts.length} 个`
    );
  }
  if (segmentCuts[0] !== 0) {
    throw new Error(
      `[long-narration] segmentCuts[0] 必须 0（视频开头），得到 ${segmentCuts[0]}`
    );
  }
  if (segmentCuts[segmentCuts.length - 1] > srtEntries.length) {
    throw new Error(
      `[long-narration] segmentCuts 末值 ${segmentCuts[segmentCuts.length - 1]} > entries.length ${srtEntries.length}`
    );
  }
  for (let i = 1; i < segmentCuts.length; i++) {
    if (segmentCuts[i] <= segmentCuts[i - 1]) {
      throw new Error(
        `[long-narration] segmentCuts 必须严格递增，segmentCuts[${i}]=${segmentCuts[i]} <= segmentCuts[${i-1}]=${segmentCuts[i-1]}`
      );
    }
  }

  const numSegments = segmentCuts.length - 1;
  const result: SubtitleEntry[][] = [];

  for (let seg = 0; seg < numSegments; seg++) {
    const startIdx = segmentCuts[seg];
    const endIdx = segmentCuts[seg + 1]; // exclusive
    const sceneSubs: SubtitleEntry[] = [];

    for (let i = startIdx; i < endIdx; i++) {
      const entry = srtEntries[i];
      if (!entry) {
        throw new Error(
          `[long-narration] segment ${seg} 引用了不存在的 entry 索引 ${i}（entries.length=${srtEntries.length}）`
        );
      }
      const startFrame = srtTimeToFrame(entry.start, fps);
      const endFrame = srtTimeToFrame(entry.end, fps);
      const duration = endFrame - startFrame;
      if (duration <= 0) {
        throw new Error(
          `[long-narration] entry ${i} 时长 ≤ 0 帧（${entry.start} → ${entry.end} = ${duration} 帧），SRT 时间戳可能反了`
        );
      }
      sceneSubs.push({
        text: entry.text,
        start: startFrame,
        duration: duration,
      });
    }

    result.push(sceneSubs);
  }

  return result;
}

/**
 * 段边界 → srtTimeToFrame 表达式
 * 配套用：段 FROM/TO 也要从 SRT 算，与 buildLongNarrationSubtitles 同步
 *
 * 用法：
 *   const S1_FROM = srtTimeToFrame("00:00:00,000");
 *   const S1_TO   = srtTimeToFrame(srtEntries[2].end);  // 段0末 entry 的 end
 *   ...
 */
export function segmentEndFrame(
  srtEntries: SrtEntry[],
  segmentCuts: number[],
  segmentIdx: number,
  fps: number = 30
): number {
  if (segmentIdx >= segmentCuts.length - 1) {
    throw new Error(
      `[long-narration] segmentIdx ${segmentIdx} 越界（segmentCuts 长度 ${segmentCuts.length} = ${segmentCuts.length - 1} 段）`
    );
  }
  const lastEntryInSeg = srtEntries[segmentCuts[segmentIdx + 1] - 1];
  if (!lastEntryInSeg) {
    throw new Error(
      `[long-narration] 段 ${segmentIdx} 没有 entry（segmentCuts[${segmentIdx+1}]=${segmentCuts[segmentIdx+1]}）`
    );
  }
  return srtTimeToFrame(lastEntryInSeg.end, fps);
}
