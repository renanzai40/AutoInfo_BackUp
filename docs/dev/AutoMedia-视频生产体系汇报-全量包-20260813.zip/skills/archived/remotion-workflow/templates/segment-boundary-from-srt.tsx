/**
 * segment-boundary-from-srt.tsx — 5 段式 Composition 正确写法模板
 *
 * 用途：复制此模板到新项目的 src/<Name>Composition.tsx，然后改：
 *   1. SRT 真实时间戳（已经用 srtTimeToFrame() 算出，零硬编码）
 *   2. SCENE_SUBTITLES 内的 entry 文本（保留 start/duration 计算式）
 *   3. M3_TOTAL_FRAMES → 改名为你的 TOTAL_FRAMES 常量
 *   4. TTS_DURATION_SEC = ffprobe 你的 TTS 音频
 *
 * 配套工具：src/timecode.ts（srtTimeToFrame + assertTotalFrames）
 * Linter：~/.hermes/.../remotion-timecode-anti-pattern/scripts/check_composition_timecode.py
 * Render 钩子：scripts/render_with_qa.sh
 * 详见 skill: remotion-timecode-anti-pattern
 */

import "./index.css";
import {
  AbsoluteFill, useCurrentFrame, interpolate, spring,
  useVideoConfig, Img, staticFile,
} from "remotion";
import { Audio } from "@remotion/media";
import { ParticleBackground } from "./animations";
import { srtTimeToFrame, assertTotalFrames } from "./timecode";

// ─── 帧边界（5 段式，全部从 SRT 真实时间戳算）──────────
// 把右侧的 SRT 时间戳改成你的 SRT entry 真实起止时间即可
const S1_FROM = srtTimeToFrame("00:00:00,000");
const S1_TO = srtTimeToFrame("00:00:14,169");    // 钩子段尾
const S2_TO = srtTimeToFrame("00:00:23,750");    // 痛点段尾
const S3_TO = srtTimeToFrame("00:00:53,539");    // 干货段尾
const S4_TO = srtTimeToFrame("00:01:05,620");    // 高潮段尾
const S5_TO = srtTimeToFrame("00:01:13,120");    // CTA 段尾
const S2_FROM = S1_TO;
const S3_FROM = S2_TO;
const S4_FROM = S3_TO;
const S5_FROM = S4_TO;

const TRANSITION_DUR = 15;
const S1_DUR = S1_TO - S1_FROM + TRANSITION_DUR;
const S2_DUR = S2_TO - S2_FROM + TRANSITION_DUR;
const S3_DUR = S3_TO - S3_FROM + TRANSITION_DUR;
const S4_DUR = S4_TO - S4_FROM + TRANSITION_DUR;
const S5_DUR = S5_TO - S5_FROM;                  // 末段无过渡

const TOTAL_FRAMES_RAW =
  S1_DUR + S2_DUR + S3_DUR + S4_DUR + S5_DUR
  - 4 * TRANSITION_DUR;
assertTotalFrames(TOTAL_FRAMES_RAW, 73.12, 30); // ⚠️ 改成你的 TTS 时长

export const TOTAL_FRAMES = TOTAL_FRAMES_RAW;

// ─── SCENE_SUBTITLES 模板 ───────────────────────────
// 把 S1/S2/.../S5 段内的 entry 改成你的文案
// start/duration 用"段内相对"坐标：start = 0 表示段开头
// 实际计算时把 SRT entry 起始时间 - 段起点 即可
const SCENE_SUBTITLES = [
  // S1 钩子（段内 0-S1_DUR）
  [
    { text: "...", start: 0, duration: 125 },
    // 每条 entry 的 start 累加前一条 duration
  ],
  // S2 痛点（段内 0-S2_DUR）
  [
    { text: "...", start: 0, duration: 200 },
  ],
  // ... 同样模式
];

// ─── Composition 组件 ─────────────────────────────
export const MyComposition: React.FC = () => {
  const frame = useCurrentFrame();

  // 段判定（用累计 dur 反查当前段）
  let accDur = 0;
  let sceneIdx = 0;
  let relFrame = frame;
  const sceneDurs = [S1_DUR, S2_DUR, S3_DUR, S4_DUR, S5_DUR];
  for (let i = 0; i < sceneDurs.length; i++) {
    if (frame < accDur + sceneDurs[i]) {
      sceneIdx = i;
      relFrame = frame - accDur;
      break;
    }
    accDur += sceneDurs[i];
  }

  // 当前段的字幕 entry
  const subs = SCENE_SUBTITLES[sceneIdx] || [];
  const sub = subs.find(s =>
    relFrame >= s.start && relFrame < s.start + s.duration
  );

  return (
    <AbsoluteFill>
      <ParticleBackground />
      {/* 这里放帧图 + 字幕渲染 */}
      {sub && <SubtitleText text={sub.text} />}
    </AbsoluteFill>
  );
};
