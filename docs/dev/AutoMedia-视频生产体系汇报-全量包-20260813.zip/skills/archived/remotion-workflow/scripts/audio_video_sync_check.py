#!/usr/bin/env python3
"""
Audio-Video Sync Check · Remotion Post-Render QA Gate

Usage:
  python3 audio_video_sync_check.py VIDEO.mp4 TTS.mp3 subtitle.srt [--times "0.5,4.2,..."] [--out-dir DIR]

Output (5 项):
  1. 时长对齐报告
  2. TTS 真实静音点列表
  3. SRT entry 偏差矩阵（每个 entry 对比真实句尾静音点）
  4. 抽帧路径列表（待 vision 读字幕做终检）
  5. 总判定: PASS / WARN / BLOCK

判定矩阵：
  - 时序偏差 < 0.3s   → ✅ PASS
  - 0.3-0.7s          → 🟡 WARN
  - > 0.7s            → 🔴 BLOCK

Reference: remotion-workflow/references/audio-video-sync-2026-06-02.md
Source case: minimax-m3.mp4 (2026-06-01 渲染，2026-06-02 用户反馈音画同步差)
"""

import subprocess
import re
import os
import sys
import json
from datetime import datetime

# ffmpeg/ffprobe 路径（2026-06-05 patch: hardcode 绝对路径，避免 PATH 不可靠）
FFMPEG = "/home/renanzai/bin/ffmpeg"
FFPROBE = "/home/renanzai/bin/ffprobe"


def probe_duration(path):
    r = subprocess.run(
        [FFPROBE, "-v", "error", "-show_entries", "format=duration", "-of", "json", path],
        capture_output=True, text=True,
    )
    return float(json.loads(r.stdout)["format"]["duration"])


def parse_srt(path):
    """解析 SRT → list of {idx, start, end, dur, text}"""
    entries = []
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    blocks = re.split(r"\n\n+", text.strip())
    for b in blocks:
        lines = b.strip().split("\n")
        if len(lines) < 3:
            continue
        try:
            idx = int(lines[0])
        except ValueError:
            continue
        m = re.match(
            r"(\d+):(\d+):(\d+),(\d+) --> (\d+):(\d+):(\d+),(\d+)", lines[1]
        )
        if not m:
            continue
        h, mn, s, ms = map(int, m.groups()[:4])
        start = h * 3600 + mn * 60 + s + ms / 1000
        h, mn, s, ms = map(int, m.groups()[4:])
        end = h * 3600 + mn * 60 + s + ms / 1000
        content = "\n".join(lines[2:])
        entries.append(
            {"idx": idx, "start": start, "end": end, "dur": end - start, "text": content}
        )
    return entries


def get_silence_starts(wav_path, noise_db=-30, min_dur=0.15):
    """
    用 ffmpeg silencedetect 找静音段。
    silence_start = 句尾静音的起点 = 真实 entry 边界。
    m3 案例：73s TTS 找到 50 段静音，对应 14 个 SRT entry 加句内停顿。
    """
    r = subprocess.run(
        [FFMPEG, "-i", wav_path, "-af", f"silencedetect=noise={noise_db}dB:d={min_dur}",
         "-f", "null", "-"],
        capture_output=True, text=True,
    )
    starts = [float(m) for m in re.findall(r"silence_start: ([-0-9.]+)", r.stderr)]
    ends = [float(m) for m in re.findall(r"silence_end: ([-0-9.]+)", r.stderr)]
    return starts, ends


def extract_frame(video_path, t_sec, out_dir):
    """抽 1 帧 PNG，返回路径"""
    os.makedirs(out_dir, exist_ok=True)
    out = f"{out_dir}/t{t_sec:05.1f}.png"
    subprocess.run(
        [FFMPEG, "-y", "-ss", str(t_sec), "-i", video_path,
         "-frames:v", "1", "-q:v", "2", out],
        capture_output=True,
    )
    return out


def judge(diff):
    """判定 emoji（输出用）"""
    ad = abs(diff)
    if ad < 0.3:
        return "🟢"
    if ad < 0.7:
        return "🟡"
    return "🔴"


def auto_times_from_srt(entries, head=0.5, tail_extra=0.5):
    """自动生成抽帧时间点：开头 + 每 entry 中点 + 末尾额外"""
    times = [head]
    for e in entries:
        mid = (e["start"] + e["end"]) / 2
        times.append(round(mid, 2))
    if entries:
        times.append(round(entries[-1]["end"] + tail_extra, 2))
    return times


def main():
    if len(sys.argv) < 4:
        print(
            "Usage: audio_video_sync_check.py VIDEO TTS SRT "
            "[--times '0.5,4.2,7.7'] [--out-dir DIR] [--noise -30] [--min-dur 0.15]",
            file=sys.stderr,
        )
        sys.exit(1)

    video, tts, srt = sys.argv[1], sys.argv[2], sys.argv[3]

    # 默认参数
    out_dir = "/tmp/audio_video_sync"
    times = None
    noise_db = -30
    min_dur = 0.15

    # 解析可选参数
    args = sys.argv[4:]
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--times" and i + 1 < len(args):
            times = [float(t) for t in args[i + 1].split(",")]
            i += 2
        elif a == "--out-dir" and i + 1 < len(args):
            out_dir = args[i + 1]
            i += 2
        elif a == "--noise" and i + 1 < len(args):
            noise_db = int(args[i + 1])
            i += 2
        elif a == "--min-dur" and i + 1 < len(args):
            min_dur = float(args[i + 1])
            i += 2
        else:
            i += 1

    print("=" * 72)
    print(f"Audio-Video Sync Check · {datetime.now().isoformat(timespec='seconds')}")
    print(f"  VIDEO: {video}")
    print(f"  TTS:   {tts}")
    print(f"  SRT:   {srt}")
    print("=" * 72)

    # === Step 1: 时长对齐 ===
    print("\n[Step 1] 时长对齐")
    v_dur = probe_duration(video)
    t_dur = probe_duration(tts)
    diff = v_dur - t_dur
    print(f"  视频时长: {v_dur:.2f}s")
    print(f"  TTS 时长:  {t_dur:.2f}s")
    print(f"  差值:      {diff:+.2f}s")
    step1_pass = abs(diff) < 0.5
    print(f"  判定:      {'✅ PASS' if step1_pass else '🔴 BLOCK'} (阈值 0.5s)")
    if not step1_pass:
        print("\n" + "=" * 72)
        print("🔴 总判定: BLOCK — 视频与 TTS 长度差 > 0.5s，先修复")
        print("=" * 72)
        sys.exit(1)

    # === Step 2: TTS 真实断句定位 ===
    print("\n[Step 2] TTS 真实断句定位（silence_start = 句尾）")
    wav = "/tmp/_tts_tmp_audio_video_sync.wav"
    r = subprocess.run(
        [FFMPEG, "-y", "-i", tts, "-ar", "16000", "-ac", "1", wav],
        capture_output=True, text=True,
    )
    if r.returncode != 0:
        print(f"  ⚠️  TTS 转 wav 失败: {r.stderr[:200]}", file=sys.stderr)
        silence_starts, silence_ends = [], []
    else:
        silence_starts, silence_ends = get_silence_starts(wav, noise_db, min_dur)
    print(f"  共 {len(silence_starts)} 个静音段")
    if silence_starts:
        preview = [f"{s:.2f}s" for s in silence_starts[:10]]
        print(f"  前 10 段: {preview}")

    # === Step 3: SRT entry 偏差矩阵 ===
    print("\n[Step 3] SRT entry 偏差矩阵")
    entries = parse_srt(srt)
    print(f"  共 {len(entries)} entries")
    print(f"  {'#':>3}  {'SRT end':>8}  {'TTS静音':>8}  {'差值':>7}  {'判定':<5}  文本")
    print(f"  {'-' * 72}")
    pass_count = warn_count = block_count = 0
    block_entries = []
    for e in entries:
        # 找 e.end 后最近的 silence_start（字幕结束应紧跟句尾静音）
        candidates = [s for s in silence_starts if s >= e["end"] - 0.05]
        if not candidates:
            closest = silence_starts[-1] if silence_starts else e["end"]
        else:
            closest = min(candidates, key=lambda x: abs(x - e["end"]))
        diff_e = e["end"] - closest
        j = judge(diff_e)
        if j == "🟢":
            pass_count += 1
        elif j == "🟡":
            warn_count += 1
        else:
            block_count += 1
            block_entries.append((e["idx"], diff_e, e["text"][:30]))
        print(f"  #{e['idx']:2d}  {e['end']:7.2f}  {closest:7.2f}  {diff_e:+6.2f}  {j}    {e['text'][:30]}")
    print(f"\n  汇总: PASS={pass_count}  WARN={warn_count}  BLOCK={block_count}")
    if block_entries:
        print("  BLOCK entries:")
        for idx, d, t in block_entries:
            print(f"    #{idx}  diff={d:+.2f}s  {t}")

    # === Step 4: 抽帧 ===
    if times is None:
        times = auto_times_from_srt(entries)
    print(f"\n[Step 4] 抽帧 {len(times)} 张（待 vision 读字幕做终检）")
    frame_paths = []
    for t in times:
        p = extract_frame(video, t, out_dir)
        frame_paths.append(p)
        print(f"  t={t:5.2f}s → {p}")

    # === Step 5: 总判定 ===
    if block_count > 0:
        verdict = "🔴 BLOCK"
        msg = f"发现 {block_count} 个 SRT entry 时序偏差 > 0.7s，必须修复后重渲染"
    elif warn_count > 0:
        verdict = "🟡 WARN"
        msg = f"发现 {warn_count} 个 SRT entry 时序偏差 0.3-0.7s，标注但不阻塞"
    else:
        verdict = "✅ PASS"
        msg = "全部 SRT entry 时序偏差 < 0.3s"

    print("\n" + "=" * 72)
    print(f"总判定: {verdict}")
    print(f"  {msg}")
    print(f"\n  抽帧路径: {out_dir}/")
    print(f"  下一步: 用 mcp_minimax_understand_image 读每帧字幕，对照 SRT 内容")
    print(f"  重点检查: 段边界（S1→S2、S2→S3）、短 entry（<3s）、视频首尾 5s")
    print("=" * 72)

    # 输出 JSON 供程序消费
    summary = {
        "video_duration": v_dur,
        "tts_duration": t_dur,
        "duration_diff": diff,
        "srt_entries": len(entries),
        "pass": pass_count,
        "warn": warn_count,
        "block": block_count,
        "verdict": verdict,
        "frame_paths": frame_paths,
        "block_entries": [
            {"idx": idx, "diff": d, "text": t} for idx, d, t in block_entries
        ],
    }
    summary_path = f"{out_dir}/summary.json"
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"\n  Summary JSON: {summary_path}")

    sys.exit(1 if block_count > 0 else 0)


if __name__ == "__main__":
    main()
