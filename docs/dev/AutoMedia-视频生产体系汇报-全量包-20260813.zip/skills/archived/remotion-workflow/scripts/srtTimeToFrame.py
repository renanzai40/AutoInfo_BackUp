#!/usr/bin/env python3
"""
srtTimeToFrame.py — SRT → 帧号 + 5 段边界建议 + Composition 模板输出

用途：写 Composition 之前先跑这个，避免手算时间戳错误。
防 m3 案例（2026-06-02）A/V 同步 bug 复发。
详见 skill: remotion-timecode-anti-pattern

Usage:
  python3 scripts/srtTimeToFrame.py <subtitle.srt> [fps=30]
  python3 scripts/srtTimeToFrame.py /path/to/subtitle.srt 30

Output:
  - 每个 SRT entry 的起止帧（@ fps）
  - 5 段边界建议（按 5 段式 1:1.5:3.5:1.5:1 比例切，可调）
  - TypeScript 代码片段（直接复制到 Composition.tsx 顶部）

如果你的视频不是 5 段式，编辑 SEGMENT_RATIOS 调整比例。
"""

import re
import sys
from pathlib import Path

# 5 段式比例（钩子:痛点:干货:高潮:CTA）
SEGMENT_RATIOS = [1.0, 1.5, 3.5, 1.5, 1.0]


def parse_srt(srt_path: str) -> list:
    """解析 SRT → [{idx, start, end, text}]"""
    with open(srt_path, "r", encoding="utf-8") as f:
        text = f.read()
    blocks = re.split(r"\n\n+", text.strip())
    entries = []
    for b in blocks:
        lines = b.strip().split("\n")
        if len(lines) < 3:
            continue
        try:
            idx = int(lines[0])
        except ValueError:
            continue
        m = re.match(
            r"(\d+):(\d+):(\d+),(\d+) --> (\d+):(\d+):(\d+),(\d+)",
            lines[1]
        )
        if not m:
            continue
        h, mn, s, ms = map(int, m.groups()[:4])
        start = h * 3600 + mn * 60 + s + ms / 1000
        h, mn, s, ms = map(int, m.groups()[4:])
        end = h * 3600 + mn * 60 + s + ms / 1000
        entries.append({
            "idx": idx, "start": start, "end": end,
            "text": "\n".join(lines[2:])
        })
    return entries


def time_to_frame(time_sec: float, fps: int) -> int:
    return round(time_sec * fps)


def srt_to_ts(s: float) -> str:
    """秒 → SRT 时间戳格式 HH:MM:SS,mmm"""
    h = int(s // 3600)
    m = int((s % 3600) // 60)
    sec = int(s % 60)
    ms = int(round((s - int(s)) * 1000))
    return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"


def suggest_segments(entries: list, total_sec: float) -> list:
    """按 5 段比例切分 TTS 总时长，给 5 个段尾时间点"""
    ratios_sum = sum(SEGMENT_RATIOS)
    cum_ratios = []
    acc = 0
    for r in SEGMENT_RATIOS[:-1]:
        acc += r
        cum_ratios.append(acc / ratios_sum)
    # 找每个累计比例对应的 SRT 真实 entry 边界
    segment_ends = []
    for ratio in cum_ratios:
        target = ratio * total_sec
        # 找 SRT entry 中 end 最接近 target 的（end < target）
        candidates = [e for e in entries if e["end"] <= target + 0.05]
        if candidates:
            segment_ends.append(candidates[-1]["end"])
        else:
            segment_ends.append(entries[0]["end"])
    segment_ends.append(entries[-1]["end"])  # 末段
    return segment_ends


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 srtTimeToFrame.py <subtitle.srt> [fps=30]")
        sys.exit(1)

    srt_path = sys.argv[1]
    fps = int(sys.argv[2]) if len(sys.argv) > 2 else 30

    if not Path(srt_path).exists():
        print(f"ERROR: file not found: {srt_path}")
        sys.exit(1)

    entries = parse_srt(srt_path)
    if not entries:
        print("ERROR: no valid SRT entries found")
        sys.exit(1)

    total_sec = entries[-1]["end"]
    total_frames = time_to_frame(total_sec, fps)
    seg_ends_sec = suggest_segments(entries, total_sec)
    seg_ends_frame = [time_to_frame(s, fps) for s in seg_ends_sec]
    seg_starts_frame = [0] + seg_ends_frame[:-1]
    seg_names = ["S1_钩子", "S2_痛点", "S3_干货", "S4_高潮", "S5_CTA"]

    print("=" * 72)
    print(f"SRT → Frame Conversion · fps={fps} · {srt_path}")
    print("=" * 72)
    print(f"  Total: {total_sec:.2f}s = {total_frames} 帧")
    print(f"  Entries: {len(entries)}")
    print()

    print("[每条 SRT entry 的帧号]")
    print(f"  {'#':>3}  {'start':>5}-{'end':<5}  {'duration':>5}")
    for e in entries:
        print(f"  #{e['idx']:2d}  {time_to_frame(e['start'], fps):5d}-{time_to_frame(e['end'], fps):<5d}  {time_to_frame(e['end']-e['start'], fps):5d}  {e['text'][:40]}")

    print()
    print("[5 段边界建议]")
    for i, (name, s, e) in enumerate(zip(seg_names, seg_starts_frame, seg_ends_frame)):
        seg_dur = e - s + 15 if i < 4 else e - s  # 前 4 段 +TRANSITION_DUR
        print(f"  {name}: 帧 {s:4d} - {e:4d}  (段长 {e-s} 帧 +15过渡)")

    print()
    print("[TypeScript 段边界片段（复制到 Composition.tsx 顶部）]")
    print("```typescript")
    print('import { srtTimeToFrame, assertTotalFrames } from "./timecode";')
    print()
    for i, (s, e, name) in enumerate(zip(seg_starts_frame, seg_ends_frame, seg_names), 1):
        s_sec = s / fps
        e_sec = e / fps
        if i == 1:
            print(f"const S1_FROM = srtTimeToFrame(\"{srt_to_ts(s_sec)}\");  // {s} 帧, {name} 起点")
            print(f"const S1_TO = srtTimeToFrame(\"{srt_to_ts(e_sec)}\");    // {e} 帧, {name} 终点")
        else:
            prev_name = seg_names[i-2].split("_")[0]
            print(f"const {prev_name}_TO = S{i}_TO_FROM = S{i}_TO;")
            print(f"const S{i}_FROM = S{i-1}_TO;")
            print(f"const S{i}_TO = srtTimeToFrame(\"{srt_to_ts(e_sec)}\");    // {e} 帧, {name} 终点")
    print()
    print("const TRANSITION_DUR = 15;")
    print("const S1_DUR = S1_TO - S1_FROM + TRANSITION_DUR;")
    print("const S2_DUR = S2_TO - S2_FROM + TRANSITION_DUR;")
    print("const S3_DUR = S3_TO - S3_FROM + TRANSITION_DUR;")
    print("const S4_DUR = S4_TO - S4_FROM + TRANSITION_DUR;")
    print("const S5_DUR = S5_TO - S5_FROM;")
    print()
    print(f"const TOTAL_RAW = S1_DUR + S2_DUR + S3_DUR + S4_DUR + S5_DUR - 4 * TRANSITION_DUR;")
    print(f"assertTotalFrames(TOTAL_RAW, {total_sec:.2f}, {fps});")
    print("export const TOTAL_FRAMES = TOTAL_RAW;")
    print("```")
    print()
    print("⚠️  Linter 验证: python3 ~/.hermes/profiles/content/skills/remotion-timecode-anti-pattern/scripts/check_composition_timecode.py src/")
    print("⚠️  Render 用 wrapper: bash scripts/render_with_qa.sh <CompositionId> out/<name>.mp4 [tts] [srt]")


if __name__ == "__main__":
    main()
