#!/usr/bin/env python3
"""
check_composition_timecode.py — 拦 Remotion Composition 硬编码时间戳反模式

触发：Remotion render 之前、CI lint 阶段
用途：把"反模式"从文档升级为代码级强制（详见 skill `remotion-timecode-anti-pattern`）

规则（任一违反 = exit 1，BLOCK_render）：
  R1. 5 段帧边界 S[1-5]_(FROM|TO) 必须是 srtTimeToFrame(...) 函数调用，
      不能是数字字面量（如 `const S1_TO = 425` 直接 FAIL）
  R2. 文件必须 import srtTimeToFrame（证明时间戳来源是 SRT）
  R3. 文件必须导出 TOTAL_FRAMES（防段边界拼错没自动校验）

不检查 SCENE_SUBTITLES 内的字面量：段内相对坐标用字面量是合理的，
只要 5 段 FROM/TO 本身从 SRT 算就对。

Usage:
  python3 check_composition_timecode.py <file1.tsx> [file2.tsx ...]
  python3 check_composition_timecode.py src/                       # 扫目录
  python3 check_composition_timecode.py src/*Composition.tsx       # 全部
  python3 check_composition_timecode.py src/M3Composition.tsx      # 单个

Exit codes:
  0 = PASS (所有文件符合 A/V 同步标准)
  1 = FAIL (有违反规则，输出具体行号 + 反模式 skill 链接)

案例（2026-06-02 m3）：
  v1 Composition 硬编码 `S1_TO = 490` → 报 R1 FAIL
  v2 Composition 改用 `srtTimeToFrame("00:00:14,169")` → PASS
"""

import re
import sys
from pathlib import Path

# 规则的"违规模式"（re.Pattern） + 描述 + 修复建议
VIOLATIONS = [
    {
        "id": "R1-hardcoded-segment-boundary",
        "description": "5 段帧边界 S[1-5]_(FROM|TO) 必须是 srtTimeToFrame() 调用，禁止数字字面量",
        # 匹配 const/let/var + S1_FROM/S1_TO/S2_FROM/.../S5_TO + = + 纯数字 + ;
        "pattern": re.compile(
            r"(?:const|let|var)\s+S[1-5]_(?:FROM|TO)\s*=\s*(\d+)\s*;",
            re.MULTILINE
        ),
        "fail_msg": "硬编码数字字面量 — 违反 m3 案例铁律（16-24s 字幕超前音频 4-5s）",
        "fix_hint": "改用 srtTimeToFrame(\"HH:MM:SS,mmm\") 从 SRT 真实时间戳算。例如：\n"
                    "  const S1_TO = srtTimeToFrame(\"00:00:14,169\");  // 425",
    },
]

# 规则的"必含模式"（missing = 违规）
REQUIRED = [
    {
        "id": "R2-missing-srtTimeToFrame-import",
        "description": "文件必须 import srtTimeToFrame（证明时间戳来自 SRT）",
        "pattern": re.compile(r"^import\s+.*\bsrtTimeToFrame\b.*from", re.MULTILINE),
        "fail_msg": "未 import srtTimeToFrame，Composition 可能未从 SRT 算时间戳",
        "fix_hint": "import { srtTimeToFrame, assertTotalFrames } from \"./timecode\";"
    },
    {
        "id": "R3-missing-TOTAL_FRAMES-export",
        "description": "文件必须导出 TOTAL_FRAMES（防段边界拼错没自动校验）",
        "pattern": re.compile(r"^export\s+const\s+\w*TOTAL_FRAMES\s*=", re.MULTILINE),
        "fail_msg": "未发现 TOTAL_FRAMES 导出",
        "fix_hint": "export const M3_TOTAL_FRAMES = ...  并用 assertTotalFrames(value, ttsDur, fps) 校验"
    },
]


def check_file(file_path: Path) -> list:
    """检查单个 Composition 文件，返回违规列表"""
    if not file_path.exists():
        return [{
            "rule": "file-not-found",
            "line": 0,
            "snippet": "",
            "msg": f"File not found: {file_path}",
            "fix": "",
        }]

    content = file_path.read_text(encoding="utf-8")
    violations = []

    # 1) 检查违规模式（硬编码数字字面量）
    # 按 (rule_id, line) 维度去重（一行多个 FROM/TO 只报一次）
    seen = set()
    for rule in VIOLATIONS:
        for m in rule["pattern"].finditer(content):
            line_no = content[: m.start()].count("\n") + 1
            line_text = content.split("\n")[line_no - 1].strip()[:90]
            # 收集该行所有违规变量名（避免一行多匹配只显示 1 个）
            key = (rule["id"], line_no)
            if key in seen:
                continue
            seen.add(key)
            violations.append({
                "rule": rule["id"],
                "line": line_no,
                "snippet": line_text,
                "msg": rule["fail_msg"],
                "fix": rule["fix_hint"],
            })

    # 2) 检查必含模式（import / export）
    for rule in REQUIRED:
        if not rule["pattern"].search(content):
            violations.append({
                "rule": rule["id"],
                "line": 0,
                "snippet": "",
                "msg": rule["fail_msg"],
                "fix": rule["fix_hint"],
            })

    return violations


def main():
    if len(sys.argv) < 2:
        print("Usage: check_composition_timecode.py <file1.tsx> [file2.tsx ...]")
        print("       check_composition_timecode.py src/         # 扫目录")
        sys.exit(1)

    files = []
    for arg in sys.argv[1:]:
        p = Path(arg)
        if p.is_dir():
            files.extend(sorted(p.glob("*Composition.tsx")))
        elif p.exists():
            files.append(p)
        else:
            print(f"WARN: not found, skip: {arg}", file=sys.stderr)

    if not files:
        print("No *Composition.tsx files found")
        sys.exit(1)

    all_violations = {}
    for f in files:
        v = check_file(f)
        if v:
            all_violations[str(f)] = v

    # 输出
    if all_violations:
        print("=" * 72)
        print(f"❌ BLOCK_render: {len(all_violations)} file(s) 违反 A/V 同步铁律")
        print("=" * 72)
        for f, vlist in all_violations.items():
            print(f"\n📄 {f}")
            for v in vlist:
                if v.get("line"):
                    print(f"  L{v['line']:>4} | {v['rule']}")
                    print(f"           {v['msg']}")
                    if v.get("snippet"):
                        print(f"           代码: {v['snippet']}")
                else:
                    print(f"  ---- | {v['rule']}")
                    print(f"           {v['msg']}")
                if v.get("fix"):
                    print(f"           💡 修复:")
                    for line in v["fix"].split("\n"):
                        print(f"              {line}")
        print("\n" + "=" * 72)
        print("📚 详细反模式: skill `remotion-timecode-anti-pattern`")
        print("   (含正确做法 + srtTimeToFrame 工具函数 + 修复流程)")
        print("=" * 72)
        sys.exit(1)
    else:
        print("=" * 72)
        print(f"✅ PASS: {len(files)} file(s) 全部符合 A/V 同步标准")
        print("=" * 72)
        for f in files:
            print(f"  ✓ {f}")
        sys.exit(0)


if __name__ == "__main__":
    main()
