---
name: brand-animation-spec
description: >
  壹目贯维 Logo 动效规范 — 定义品牌 Logo 在 Remotion 视频中的使用场景、动效方向、参数规格。
  触发：Remotion 视频中含 BRAND 类型 entry 时，或需要品牌 Logo 出现的任何场景。
  Logo 文件：/mnt/d/Hermes-Workspace/01-Projects/Official_Website/public/brand/yimuguanwei_logo.jpg
category: remotion
---

# Brand Animation Spec · 品牌动效规范

## Logo 素材规格

**文件**：`brand/logo.jpg`
**内容**：壹目贯维四字，纯黑白宋体字标（Wordmark），无图形、无颜色、无边框
**尺寸**：竖屏场景下 Logo 高度基准 180-220px

**Logo 特征决定动效选择**：
- ✅ 纯字标 → 适合 INK REVEAL（字逐个淡入）
- ❌ 无几何图形 → 不适合 Geometric Reveal / Radial Sweep
- ⚠️ 黑白单色 → 反白/发光效果有限，需依赖背景衬托

---

## 壹目贯维品牌色（Remotion 变量）

```tsx
// 在 src/index.css 或 Remotion 组件内使用
const BRAND_LOGO_COLOR = "#000000";    // Logo 本身是黑色
const BRAND_BG_LIGHT  = "#ffffff";    // 浅色背景
const BRAND_BG_DARK   = "#0d1b2a";    // 深蓝背景（主推）
const BRAND_ACCENT    = "#FFD700";    // 金色（用于主标题/强调，非 Logo）
const BRAND_PURPLE    = "#7209b7";    // 辅助色（装饰性渐变）
```

---

## 动效方向（已验证）

### 1. INK REVEAL ✅ 已确认

**适用场景**：开场首个场景、BRAND 类型 entry 出现时

**效果**：四字逐个从透明淡入，同时字间距从紧到松渐开

**Remotion 实现**（已验证可运行）：
```tsx
// src/animations.tsx
export const InkRevealLogo: React.FC<{
  duration: number;   // 场景总帧数
  fontSize?: number;   // 默认 120
  color?: string;     // 默认 "#000"
  fontFamily?: string; // 默认 "SimSun, Songti SC, serif"
}> = ({ duration, fontSize = 120, color = "#000" }) => {
  const frame = useCurrentFrame();

  // 0-30f: 整体淡入
  const containerOpacity = interpolate(frame, [0, 30], [0, 1], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });

  // 30-90f: 四字逐个淡入，每字间隔15f
  const charOpacities = [0, 1, 2, 3].map((i) =>
    interpolate(frame, [30 + i * 15, 45 + i * 15], [0, 1], {
      extrapolateLeft: "clamp", extrapolateRight: "clamp",
    })
  );

  // 90-120f: 字间距渐开（tracking 效果）
  const letterSpacing = interpolate(frame, [90, 120], [0, 12], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });

  const chars = ["壹", "目", "贯", "维"];

  return (
    <div style={{ opacity: containerOpacity, display: "flex", flexDirection: "row", gap: `${letterSpacing}px` }}>
      {chars.map((char, i) => (
        <span key={i} style={{
          fontFamily: "SimSun, Songti SC, serif",
          fontSize,
          color,
          opacity: charOpacities[i],
          textShadow: "2px 2px 0 rgba(0,0,0,0.1)",
          userSelect: "none",
        }}>{char}</span>
      ))}
    </div>
  );
};
```

**使用方式**：
```tsx
// 在 Scene 组件中
{isBrandEntry && <InkRevealLogo duration={sceneDuration} />}
```

---

### 2. CONTRAST FLASH（BRAND 结尾 CTA）

**适用场景**：视频结尾 CTA 场景（最后 1-2 个 entry）

**效果**：黑白↔反白 快速切换，每 15f 切换一次

**参数**：
```tsx
const flashF = frame % 30; // 每30帧一个完整周期
const isFlipped = flashF < 15;
```

**注意**：Logo 本身是黑白的，反白后 Logo 变成白色。**必须配合深色背景**（`#0d1b2a`），否则 Logo 消失在白底上。

```tsx
// ✅ 正确：深色背景 + 反白 Logo
<AbsoluteFill style={{ backgroundColor: "#0d1b2a" }}>
  <img src={logoPath} style={{ filter: "invert(1)", opacity: 0.9 }} />
</AbsoluteFill>

// ❌ 错误：浅色背景 + 反白 Logo（Logo 消失）
<AbsoluteFill style={{ backgroundColor: "#fff" }}>
  <img src={logoPath} style={{ filter: "invert(1)" }} /> {/* Logo 不可见 */}
</AbsoluteFill>
```

---

### 3. SHAKE + FLOAT（装饰性）

**适用场景**：过渡场景、品牌展示场景（非 CTA）

**参数**：
```tsx
const floatY = interpolate(frame, [0, sceneDuration], [0, 10], {
  extrapolateLeft: "clamp", extrapolateRight: "clamp",
});
const shakeX = interpolate(
  Math.sin(frame * 0.8) * 10,
  [-10, 10],
  [-3, 3],
  { extrapolateLeft: "clamp", extrapolateRight: "clamp" }
);
```

**慎用**：抖动效果在正式品牌内容中可能显得不严肃，优先用 INK REVEAL。

---

### 4. SHADOW DEPTH（立体感）

**适用场景**：品牌强调时刻，配合深色背景

**参数**：
```tsx
const shadowSpread = interpolate(frame, [0, 60], [0, 12], {
  extrapolateLeft: "clamp", extrapolateRight: "clamp",
});
const shadowOpacity = interpolate(frame, [0, 60], [0, 0.45], {
  extrapolateLeft: "clamp", extrapolateRight: "clamp",
});
```

---

## 场景触发规则

| 视频位置 | 动效方向 | 背景要求 | 备注 |
|---------|---------|---------|------|
| 开场（第1个 scene） | INK REVEAL | 深蓝渐变 | Logo 作为开场视觉锚点 |
| BRAND 类型 entry | INK REVEAL（轻量版，缩短时长） | 随场景背景 | 不抢 SCENE/ABSTRACT 内容注意力 |
| 结尾 CTA | CONTRAST FLASH | 深色背景（#0d1b2a） | 制造视觉高潮 |
| 装饰性过渡 | SHAKE + FLOAT 或不用 | 随场景背景 | 慎用，优先级最低 |

---

## 硬性禁止规则

| 禁止 | 原因 |
|------|------|
| Logo 叠加彩色 MiniMax 场景图 | 黑白 Logo 在彩色图上对比度差，视觉混乱 |
| 在浅色背景用 CONTRAST FLASH | Logo 是黑白的，反白后白字在白底上消失 |
| Logo 叠加品牌蓝（#4361ee）发光 | Logo 本身黑白，发光效果无意义 |
| 动态背景上的 INK REVEAL | 背景动效干扰字间距渐开效果 |
| 在非深色背景用 Shadow Depth | 阴影效果依赖深色背景才有层次感 |

---

## 动效组合使用示例

```tsx
// 完整 Brand Scene 组件示例
const BrandScene: React.FC<{ duration: number; effect: "ink" | "flash" | "shadow" }> = ({
  duration, effect
}) => {
  const frame = useCurrentFrame();

  if (effect === "ink") {
    return (
      <AbsoluteFill style={{ backgroundColor: "#0d1b2a", justifyContent: "center", alignItems: "center" }}>
        <ParticleBackground particleCount={4} />
        <InkRevealLogo duration={duration} />
        <SentenceSubtitle sentences={["壹目贯维专注AI内容生产"]} duration={duration} />
      </AbsoluteFill>
    );
  }

  if (effect === "flash") {
    const isFlipped = (frame % 30) < 15;
    return (
      <AbsoluteFill style={{ backgroundColor: "#0d1b2a", justifyContent: "center", alignItems: "center" }}>
        <img src="./brand/logo.jpg" style={{
          height: 200,
          filter: isFlipped ? "invert(1)" : "none",
        }} />
        <SentenceSubtitle sentences={["关注壹目贯维，看透商业背后的逻辑"]} duration={duration} />
      </AbsoluteFill>
    );
  }

  return null;
};
```

---

## 文件路径约定

```
remotion-video-{topic}/
  public/
    brand/
      logo.jpg          ← 壹目贯维官方 Logo（复制自官网）
  src/
    animations.tsx      ← InkRevealLogo 等品牌动效组件
    BrandScene.tsx      ← 品牌专用场景组件
```

**Logo 文件获取**：
```bash
mkdir -p public/brand
cp /mnt/d/Hermes-Workspace/01-Projects/Official_Website/public/brand/yimuguanwei_logo.jpg \
   public/brand/logo.jpg
```
