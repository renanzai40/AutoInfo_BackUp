---
name: tts-voice-asset
description: TTS 声音品牌资产库 —— 严禁擅自换声音。集中维护 APPROVED_VOICES（edge-tts 为主）+ 调用方式 + voice_id 验证 + 踩坑教训。触发：任何 TTS 工具调用 / 任何 safe_upload_wechat.py V4 voice gate / 任何声音方案选择。v8 教训：2026-06-05 擅自换声音 → 严重抗议。v9 更新：2026-06-08 MiniMax 订阅到期 → edge-tts 升为主力。
tags: [tts, voice, brand-asset, edge-tts, safe-upload, v4-gate]
---

## 🆕 TTS 输入纯净规则（2026-06-12 新增，P0-18 铁律）

> **事故**：2026-06-12 Gemini/IBM 两个话题的 TTS 输入用了含【段标题】的脚本文件，音频直接念出"开场钩子"。

**TTS 调用前必做 3 步**：
1. 确认输入文本不包含 `【...】` 段标题标记
2. 确认输入文本不包含 `======` 分隔线、`*段*` 注释等元数据
3. 输入文本 = 纯口播文字（无格式、无标记、无注释）

**检测方式**：
```bash
grep -qE '【.*】|===' <input.txt> && echo "❌ 含段标题/分隔符" || echo "✅ 纯净"
```

**反模式**（永久禁止）：
- ❌ 直接把 tiktok/script.txt 或 bilibili/script.txt 当 TTS 输入
- ❌ TTS 前不检查输入文本是否含标记
- ❌ "文本看起来干净"的假设（必须 grep 验证）

---

# TTS 声音品牌资产库（v9 更新 2026-06-08）

> **核心铁律**：TTS 声音 = 品牌资产。**严禁擅自换**。任何 TTS 工具调用前必先确认 voice_id ∈ APPROVED_VOICES。
>
> **v9 重大变更（2026-06-08）**：MiniMax 订阅到期 → MiniMax TTS（`male-qn-qingse` / `Radio_Host`）**不可用**。edge-tts 升为所有场景的主选引擎。
>
> **踩坑教训（2026-06-05 v8）**：擅自把 session 113223 时代的 m3 tts `Radio_Host`（男声）换成 edge-tts `zh-CN-XiaoxiaoNeural`（女声）——user 严重抗议"擅自换声音"。**修复路径**：V4 gate hook（`safe_upload_wechat.py --voice-id`）强制 voice_id 核验。

## APPROVED_VOICES（4 声音白名单）

| voice_id | 引擎 | 性别 | 适用场景 | 状态 |
|----------|------|------|---------|------|
| **`zh-CN-YunxiNeural`** | edge-tts | 男 | **业务款首选**（当前唯一品牌男声） | ✅ 可用 |
| **`zh-CN-XiaoxiaoNeural`** | edge-tts | 女 | 引流款 / 业务款备选 | ✅ 可用 |
| `zh-CN-YunjianNeural` | edge-tts | 男 | 备选（体育/激情向） | ✅ 可用 |
| `zh-CN-XiaoyiNeural` | edge-tts | 女 | 备选（卡通/活泼向） | ✅ 可用 |
| ~~`male-qn-qingse`~~ | MiniMax m3 tts | 男 | ~~业务款首选~~ | ❌ 订阅到期 |
| ~~`Radio_Host`~~ | MiniMax m3 tts | 男 | ~~业务款备选~~ | ❌ 订阅到期 |

**不在白名单的声音 → V4 gate 立即 exit 1，不上传公众号草稿**。

## 可用声音特性对比

| 维度 | `zh-CN-YunxiNeural` (edge) | `zh-CN-XiaoxiaoNeural` (edge) |
|------|------|------|
| **性别** | 男 | 女 |
| **语速** | 偏快（比 MiniMax TTS 快约 4 倍） | 偏快 |
| **音质** | 较机械但稳定 | 较机械但稳定 |
| **品牌契合** | **当前默认** | 备选女声 |
| **可用性** | ✅ 免费，本地运行 | ✅ 免费，本地运行 |

### edge-tts 语速补偿

edge-tts 比 MiniMax TTS 快约 4 倍，**同文本时长显著偏短**。补偿措施：

1. **Remotion 视频**：在 `src/` 的 Timeline 中适当增加每段时长（通过 `durationInFrames` 或 `fps`）
2. **Whisper 验证**：跑完 TTS 后必须跑 Whisper 验证 mp3 ↔ SRT 对齐
3. **备用 voice_id**：如果 YunxiNeural 太快，换 XiaoxiaoNeural（女声偏慢）或 YunjianNeural

## 调用方式

### edge-tts（主选）

```bash
# CLI
edge-tts --voice "zh-CN-YunxiNeural" \
         --text "完整口播脚本" \
         --write-media /path/to/output.mp3
```

```python
# Python
import edge_tts
import asyncio

async def gen_tts(text, voice, out_path):
    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(out_path)

asyncio.run(gen_tts("完整脚本", "zh-CN-YunxiNeural", "/path/to/output.mp3"))
```

```python
# 通过 Hermes 工具（自动用配置的默认 voice）
text_to_speech(text="完整脚本")
```

### ~~MiniMax m3 tts~~（已不可用，保留调用格式作参考）

```python
# 2026-06-08 起不可用（订阅到期）
# resp = requests.post(
#     "https://api.minimax.chat/v2/t2a_v2",
#     headers={"Authorization": f"Bearer {MINIMAX_API_KEY}"},
#     json={"model": "speech-01", "text": "...", "voice_id": "male-qn-qingse",
#           "speed": 1.0, "vol": 10, "pitch": 0}
# )
```

## V4 Voice Gate（强制核验）

**触发场景**：任何 `safe_upload_wechat.py` 上传前。

```bash
python3 safe_upload_wechat.py --pid <project_id> --voice-id "zh-CN-YunxiNeural"
# → [V4 GATE OK] voice_id 在 APPROVED_VOICES
# 或 [V4 GATE FAIL] voice_id 不在 APPROVED_VOICES (禁用上传)
```

**核心代码**（`safe_upload_wechat.py` L242-256）：
```python
APPROVED_VOICES = {"zh-CN-YunxiNeural", "zh-CN-XiaoxiaoNeural",
                   "zh-CN-YunjianNeural", "zh-CN-XiaoyiNeural",
                   "male-qn-qingse", "Radio_Host"}  # m3 保留但不可用
if args.voice_id:
    if args.voice_id not in APPROVED_VOICES:
        print(f"[V4 GATE FAIL] voice_id `{args.voice_id}` 不在 APPROVED_VOICES")
        print(f"  TTS 声音是品牌资产，禁止擅自换（6-05 v8 教训）")
        sys.exit(1)
    # 额外检查：如果 voice_id 是 m3 tts，给出不可用提示
    if args.voice_id in {"male-qn-qingse", "Radio_Host"}:
        print(f"[V4 GATE WARN] MiniMax 订阅已到期，`{args.voice_id}` 不可用，建议换 edge-tts")
```

## 5 件套 Whisper 验证（防 mp3 ≠ SRT 错配）

**触发场景**：任何新 mp3 生成后必跑。

```bash
~/.hermes/hermes-agent/venv/bin/whisper <mp3> --language zh --model tiny \
    --output_format srt --output_dir /tmp/whisper_pre_send/
diff /tmp/whisper_pre_send/*.srt <project.srt>
# 100% 匹配 → ✅
# 不匹配 → ❌ 重生成 mp3
```

**6-05 教训**：v3-v7 6 轮没跑这步 = mp3 ≠ SRT 错配一直未发现。

## 七大反模式（永久禁止）

| # | 反模式 | 后果 | 正确做法 |
|---|--------|------|---------|
| 1 | **擅自换 voice_id**（不查 APPROVED_VOICES）| 声音是品牌资产，v8 教训 | 必先 print voice_id + 查白名单 + user 确认 |
| 2 | ~~edge-tts 生成业务款主视频~~（v9 已解除禁令） | ~~4x 速 → mp3 偏短~~ | **现在只有 edge-tts 可用**，须做语速补偿 |
| 3 | **生成 mp3 不跑 Whisper 验证** | mp3 ≠ SRT 错配，6 轮修复无效 | 必跑 5 件套 Whisper 验证 |
| 4 | ~~声音参数 vol/pitch 用 float~~（edge-tts 无此参数） | 不适用 | edge-tts 无 vol/pitch 参数，直接传 voice |
| 5 | **用 m3 tts voice_id 但不检查可用性** | 静默失败 → 无 mp3 输出 | 调用前确认 voice_id 当前可用 |

## TTS 工具选型决策树（v9）

```
场景: 生成新 mp3
    ↓
[Q1] 需要什么声音?
    ├─ 业务款男声 → zh-CN-YunxiNeural（当前默认品牌男声）
    ├─ 引流款女声 → zh-CN-XiaoxiaoNeural
    ├─ 备选男声 → zh-CN-YunjianNeural
    └─ 备选女声 → zh-CN-XiaoyiNeural
    ↓
[Q2] edge-tts 语速调节（v9 新增）
    ├─ 默认语速 → 直接用 edge-tts CLI
    ├─ 需要稍慢 → 换女声（XiaoxiaoNeural 自然偏慢）
    └─ 需要大幅调慢 → 用 ffmpeg 降速（atempo）
       ffmpeg -i input.mp3 -filter:a "atempo=0.8" output.mp3
    ↓
[Q3] 必跑 5 件套 Whisper 验证
    ├─ ✅ mp3 = SRT 100% 匹配 → 上传 safe_upload
    └─ ❌ 不匹配 → 重生成 mp3 + 重跑 Whisper
    ↓
[Q4] safe_upload V4 gate
    ├─ ✅ voice_id 在 APPROVED_VOICES → 上传
    └─ ❌ 不在白名单 → exit 1，禁止上传
```

## 实战案例 v9

```python
# 2026-06-08 后标准做法
import edge_tts
import asyncio

async def main():
    communicate = edge_tts.Communicate(
        "OpenAI 又放大招——Codex 推出团队专属插件...",
        "zh-CN-YunxiNeural"  # 当前业务款男声
    )
    await communicate.save("/path/to/output.mp3")

asyncio.run(main())
# 必跑 Whisper 验证 → 100% 匹配 → 上传 safe_upload --voice-id zh-CN-YunxiNeural ✅
```

## 历史记录

| 版本 | 日期 | 变更 |
|------|------|------|
| v8 | 2026-06-05 | 4 声音白名单 + V4 gate 建立。业务款必 m3 tts，引流款 edge 备选 |
| v9 | 2026-06-08 | MiniMax 订阅到期 → edge-tts 升为主力。反模式 #2 解除。语速补偿加入 |

## 关联 skill

- `automedia-production-guard`（V4 声音品牌资产核验）
- `wechat-upload-checklist`（V4 voice gate）
- `remotion-workflow`（Step 2 必含 voice_id 核验 + 5 件套 Whisper）

## 一句话

**TTS 声音 = 品牌资产 = 不可擅自换**。MiniMax 订阅已到期，当前仅 edge-tts 可用。**业务款首选用 `zh-CN-YunxiNeural`（男声），引流款 `zh-CN-XiaoxiaoNeural`（女声）**。所有 mp3 必跑 Whisper 验证 100% = SRT，以及注意 edge-tts 语速偏快需补偿。
