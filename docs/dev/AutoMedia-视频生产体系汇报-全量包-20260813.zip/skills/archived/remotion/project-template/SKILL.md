---
name: project-template
description: >
  壹目贯维 Remotion 标准项目模板 — 每次新建 Remotion 视频项目时，
  必须基于本模板初始化，禁止从零手写项目结构。
category: remotion
---

# Remotion 标准项目模板

## 快速初始化

```bash
# 1. 创建项目目录
TOPIC=wentech  # 替换为实际话题
mkdir -p ~/Remotion-Test/projects/$TOPIC
cd ~/Remotion-Test/projects/$TOPIC

# 2. 复制模板
cp -r ~/.hermes/skills/remotion/project-template/template/* ./

# 3. 复制 Logo
mkdir -p public/brand
cp /mnt/d/Hermes-Workspace/01-Projects/Official_Website/public/brand/yimuguanwei_logo.jpg \
   public/brand/logo.jpg

# 4. 安装依赖
bun install

# 5. 替换占位符
TOPIC=wentech ID=WentechTTS ./fix_topic.sh   # 见下方说明

# 6. 确认 TTS 音频
# 将音频文件放入 public/audio/tts.wav
# 运行 ffprobe 获取实际时长（秒），记录下来

# 7. 开始开发场景
# 编辑 src/scenes/Scene0.tsx, Scene1.tsx ...
```

---

## 目录结构

```
remotion-video-{topic}/
├── package.json
├── remotion.config.ts
├── tsconfig.json
├── bun.lock
├── public/
│   ├── brand/
│   │   └── logo.jpg              ← 壹目贯维官方 Logo
│   ├── fonts/
│   │   ├── YanSong_Regular.otf   ← 研宋体（主标题）
│   │   └── TeHei_Heavy.otf      ← 特黑体（字幕）
│   └── audio/
│       └── tts.wav               ← TTS 音频（必须）
├── src/
│   ├── index.ts                  ← Remotion CLI 入口（通常不改）
│   ├── index.css                 ← 全局 CSS 变量
│   ├── Root.tsx                  ← Composition 注册表
│   ├── animations.tsx             ← 可复用动画组件库
│   ├── scenes/
│   │   ├── Scene0.tsx            ← 逐个实现
│   │   ├── Scene1.tsx
│   │   ├── ...
│   │   └── SceneN.tsx
│   └── composition/
│       └── MainComposition.tsx   ← 主 Composition（整合 scenes + TransitionSeries）
├── output/                        ← 渲染输出
└── qa_thumbnails/                 ← QA 截图
```

---

## 关键占位符（初始化后替换）

| 占位符 | 替换值 | 示例 |
|--------|--------|------|
| `{TOPIC}` | 话题名（kebab-case） | `wentech` |
| `{ID}` | Composition ID（PascalCase） | `WentechTTS` |
| `{AUDIO_DURATION}` | TTS 音频时长（秒） | `65.9` |
| `{FPS}` | 帧率 | `30` |

替换脚本 `fix_topic.sh`：
```bash
#!/bin/bash
TOPIC=$1
ID=$2
DURATION=${3:-60}

# 替换 Root.tsx 中的占位符
sed -i "s/{TOPIC}/$TOPIC/g; s/{ID}/$ID/g" src/Root.tsx

# 替换 MainComposition.tsx 中的时长
sed -i "s/{AUDIO_DURATION}/$DURATION/g; s/{FPS}/30/g" src/composition/MainComposition.tsx
```

---

## Root.tsx 结构说明

```tsx
// src/Root.tsx
import { Composition } from "remotion";
import { MainComposition, MAIN_TOTAL_FRAMES } from "./composition/MainComposition";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="{ID}"
        component={MainComposition}
        durationInFrames={MAIN_TOTAL_FRAMES}
        fps={30}
        width={1080}
        height={1920}
      />
    </>
  );
};
```

### ⚠️ Root.tsx 语法陷阱（2026-05-26 新增）

**症状**：Remotion bundling 失败，报 `Expected ")" but found end of file`

**根因**：TSX patch 操作后文件尾部缺失闭合 `);` 和 `};`

**修复**：每次 patch Root.tsx 后，确认文件以 `};` 结尾（两行：`);` 和 `};`），不是只有 `</>`。用以下命令验证：
```bash
tail -3 src/Root.tsx
# 期望输出：
#     </>
#   );
# };
```

## staticFile() 路径规范（2026-05-26 新增）

**规则**：`staticFile()` 里的路径必须相对于 `public/` 目录，不写 `public/` 前缀。

| 资源 | 正确写法 | 错误写法 |
|------|---------|---------|
| 音频 | `staticFile("audio/deepseek_concat.mp3")` | `staticFile("projects/deepseek/02_tts/audio.mp3")` |
| 图片 | `staticFile("projects/deepseek/02_images/img.jpg")` | `staticFile("/public/audio/img.jpg")` |

**部署流程**：生成文件后，必须手动复制到 `public/` 下的对应路径：
```bash
# 复制音频
cp projects/deepseek/02_tts/audio_voiceover.mp3 public/audio/deepseek_concat.mp3
# 复制图片
cp projects/deepseek/02_images/*.jpg public/projects/deepseek/02_images/
```

---

## MainComposition.tsx 结构说明

```tsx
// src/composition/MainComposition.tsx
// 包含 TransitionSeries、音频、过渡音效

import { Audio } from "@remotion/media";
import { staticFile } from "remotion";
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import { whoosh } from "@remotion/sfx";

// ─── 音频时长（ffprobe 实测）──────────────────────────
const AUDIO_DURATION = {AUDIO_DURATION}; // 秒

// ─── 帧数常量 ────────────────────────────────────────
export const MAIN_TOTAL_FRAMES = Math.ceil(AUDIO_DURATION * 30);

// ─── SRT entry 帧范围（visual-plan 生成后填写）───────
// 例：
// const T1_FROM = 0;
// const T1_TO   = 263;  // 8.789s → 263f
// const T2_FROM = 263;
// ...

// ─── 过渡配置 ────────────────────────────────────────
const TRANSITION_DUR = 15; // 过渡帧数

// ─── Whoosh 触发帧 ──────────────────────────────────
const WHOOSH1_FRAME = ...; // 第一个过渡开始帧

// ─── 场景定义 ───────────────────────────────────────
const scenes = [
  { duration: S1_DUR, subtitleIdx: 0 },
  // ... 来自 visual_plan.json
];

export const MainComposition: React.FC = () => {
  return (
    <AbsoluteFill style={{ backgroundColor: "#0d1b2a" }}>
      {/* TTS 主音频 */}
      <Audio src={staticFile("audio/tts.wav")} />

      {/* 过渡音效（每场景切换点） */}
      <Audio src={whoosh} from={WHOOSH1_FRAME} />
      {/* ... 更多 whoosh */}

      {/* 场景序列 */}
      <TransitionSeries>
        {scenes.map((scene, i) => (
          <React.Fragment key={i}>
            <TransitionSeries.Sequence durationInFrames={scene.duration}>
              <Scene idx={i} duration={scene.duration} subtitleIdx={scene.subtitleIdx} />
            </TransitionSeries.Sequence>
            {i < scenes.length - 1 && (
              <TransitionSeries.Transition
                presentation={fade()}
                timing={linearTiming({ durationInFrames: TRANSITION_DUR })}
              />
            )}
          </React.Fragment>
        ))}
      </TransitionSeries>
    </AbsoluteFill>
  );
};
```

---

## src/scenes/ 目录说明

**重要**：场景组件必须用 `.ts` 文件（不是 `.tsx`）！

Remotion bundler 在 `.tsx` 入口时存在 [P0 bug](#p0-tsx-bundler-404)，所有场景文件必须用 `.ts` + `React.createElement()` 编写。

| 文件 | 扩展名 | 原因 |
|------|--------|------|
| Scene0.tsx ~ SceneN.tsx | **`.ts`** | `.tsx` 触发 bundler 404 |

正确示例（`src/scenes/Scene0.ts`）：
```tsx
import { AbsoluteFill } from "remotion";
import React from "react";

export const Scene0 = ({ duration }: { duration: number }) => {
  return React.createElement(AbsoluteFill, {
    style: { backgroundColor: "#1a1a2e" }
  });
};
```

错误示例（会触发 bundler 404）：
```tsx
// src/scenes/Scene0.tsx ❌ — JSX 语法触发 @remotion/studio/renderEntry 404
import { AbsoluteFill } from "remotion";
export const Scene0 = () => (
  <AbsoluteFill style={{ backgroundColor: "#1a1a2e" }}>
    ...
  </AbsoluteFill>
);
```

### P0: `.tsx` bundler 404 Bug（2026-05-28 确认）

**触发**：任何 `.tsx` 入口或场景文件含 JSX 时，`remotion bundle` 失败。

**症状**：
```
Cannot find module '@remotion/studio/renderEntry'
```

**根因**：`@remotion/bundler` 的 webpack alias 指向文件而非目录，enhanced-resolve 拼接子路径失败。

**Workaround**：所有组件用 `.ts` + `React.createElement()`，禁止 JSX 语法。

---

## 场景开发顺序

1. **确认 timing 常量**：从 visual_plan.json 读取各 entry 的 start/end 秒数 → 乘以 30 = 帧数
2. **定义 scenes 数组**：每个 scene = `{ duration, subtitleIdx }`
3. **逐个实现 Scene0.ts ~ SceneN.ts**：先画骨架，确认编译通过
4. **接入 TTS 音频**：Audio 组件声明，验证播放同步
5. **添加过渡音效**：whoosh from 帧点
6. **Pre-render gate**：过完所有检查项后再渲染

---

## animations.tsx 组件库

模板中的 `src/animations.tsx` 包含以下已验证组件：

| 组件 | 用途 | 动画类型 |
|------|------|---------|
| `ParticleBackground` | 粒子背景装饰 | 帧驱动 sin/cos |
| `AnimatedCounter` | 数字滚动（带弹跳过冲） | bezier 曲线 |
| `AnimatedDataCard` | 数据展示卡片 | spring 弹簧 |
| `InkRevealLogo` | 壹目贯维 Logo 动效 | 字逐个淡入 |
| `SentenceSubtitle` | 句级字幕（支持工具名高亮） | spring + opacity 分离 |
| `ToolCard` | 工具名高亮卡片 | spring 弹簧 |
| `ToolBarChart` | 工具对比柱状图 | spring 展开 |

所有动画**基于 `useCurrentFrame()` + `interpolate()`**，禁止 CSS @keyframes。

---

## 字体注册

`src/index.css`：
```css
@font-face {
  font-family: "YanSong";
  src: url("./public/fonts/YanSong_Regular.otf") format("opentype");
}
@font-face {
  font-family: "TeHei";
  src: url("./public/fonts/TeHei_Heavy.otf") format("opentype");
}

:root {
  --font-yansong: "YanSong", "SimSun", serif;
  --font-tehei: "TeHei", "Source Han Sans SC", sans-serif;
}
```

---

## package.json 关键依赖

```json
{
  "scripts": {
    "dev": "remotion preview",
    "render": "remotion render src/index.ts {ID} /tmp/output.mp4 --browser-executable ~/.cache/ms-playwright/chromium-1217/chrome-linux64/chrome",
    "still": "remotion still src/index.ts {ID} --frame=0 --scale=0.25"
  },
  "dependencies": {
    "remotion": "^4.0.0",
    "@remotion/transitions": "^4.0.0",
    "@remotion/sfx": "^4.0.0",
    "@remotion/media": "^4.0.0"
  }
}
```

---

## QA 截图提取

```bash
# 在项目目录执行
DURATION=$(ffprobe -v error -show_entries format=duration -of json public/audio/tts.wav | python3 -c "import sys,json; print(round(float(json.load(sys.stdin)['format']['duration'])))")
FPS=30
TOTAL=$((DURATION * FPS))

ffmpeg -ss $((DURATION/20)) -i public/audio/tts.wav -vframes 1 qa_thumbnails/frame_0p05.png
ffmpeg -ss $((DURATION/2))  -i public/audio/tts.wav -vframes 1 qa_thumbnails/frame_0p50.png
ffmpeg -ss $((DURATION*95/100)) -i public/audio/tts.wav -vframes 1 qa_thumbnails/frame_0p95.png
```

---

## ⚠️ NSegmentSkeleton 模式（2026-06-04+ 新项目首选）

**Scene-based 模板（上文文档）用于 2026-05 及之前的项目。2026-06-04 起所有新项目改用 NSegmentSkeleton 模式，更简洁高效。**

完整引导见 `references/n-segment-skeleton-bootstrapping.md`。

速览：创建 4 个文件即可完成新 Composition：
```
src/blocks/<topic>/scene-data.ts   ← 5 段元数据 + 字幕
src/blocks/<topic>/blocks.tsx      ← 5 个 NumberBlock 组件
src/<Topic>Composition.tsx         ← NSegmentSkeleton 包装
src/Root.tsx 注册                  ← import + <Composition>
```

无需 Audio 组件、无需 TransitionSeries、无需逐场景 Scene 文件。

## 模板文件列表

模板文件存放在：
`~/.hermes/skills/remotion/project-template/template/`

| 文件 | 说明 |
|------|------|
| `package.json` | 依赖配置 |
| `remotion.config.ts` | Remotion 配置（jpeg输出、tailwind禁用） |
| `tsconfig.json` | TypeScript 配置 |
| `src/index.ts` | CLI 入口 |
| `src/index.css` | CSS 变量 + 字体声明 |
| `src/Root.tsx` | Composition 注册表 |
| `src/animations.tsx` | 动画组件库（完整实现） |
| `src/composition/MainComposition.tsx` | 主 Composition 模板 |
| `src/scenes/SceneTemplate.tsx` | 场景组件骨架 |
| `fix_topic.sh` | 话题占位符替换脚本 |
