import React from "react";
import { Composition } from "remotion";
import { MainComposition, MAIN_TOTAL_FRAMES } from "./composition/MainComposition";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="{ID}"
        component={MainComposition}
        durationInFrames={MAIN_TOTAL_FRAMES}
        fps={30}
        width={1080}
        height={1920}
      />
    </>
  );
};
