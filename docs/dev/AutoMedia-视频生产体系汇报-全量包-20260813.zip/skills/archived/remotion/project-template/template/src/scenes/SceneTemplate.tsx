/**
 * Scene{N}.tsx · 场景 {N} 模板
 *
 * 复制此文件为 Scene0.tsx, Scene1.tsx ... 然后实现具体视觉。
 * 规则：
 * 1. duration = 场景总帧数（包含过渡延长）
 * 2. opacity 只用 fadeIn/fadeOut，不在 AbsoluteFill 上加
 * 3. spring 只驱动 transform，不驱动 opacity
 * 4. 内部动画用 relFrame = frame（已经是相对帧）
 */

import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  interpolate,
  spring,
  useVideoConfig,
} from "remotion";
import {
  ParticleBackground,
  AnimatedCounter,
  SentenceSubtitle,
} from "../animations";

type SceneProps = {
  duration: number;    // 场景总帧数（含 TRANSITION_DUR 延长）
  subtitleIdx: number; // 字幕数组索引
};

export const Scene{N}Template: React.FC<SceneProps> = ({ duration, subtitleIdx }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // ─── 相对帧（组件自己的 0 基点）─────────────────────
  // 注意：TransitionSeries.Sequence 内 frame 已是相对帧
  // 不需要再减偏移量

  // ─── 示例：淡入淡出（opacity 独立于 transform）────────
  const fadeIn  = interpolate(frame, [0, 20], [0, 1], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  const fadeOut = interpolate(frame, [duration - 20, duration], [1, 0], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  const opacity = Math.min(fadeIn, fadeOut);

  // ─── 示例：弹簧入场（spring 只驱动 transform）────────
  const springVal = spring({
    frame: Math.min(frame, 30), // clamp 防止负帧
    fps,
    config: { damping: 16, stiffness: 140 },
  });
  const scale     = interpolate(springVal, [0, 1], [0.88, 1]);
  const translateY = interpolate(springVal, [0, 1], [16, 0]);

  // ─── 视觉组件（根据 visual_plan 填入）───────────────
  // import { MiniMaxImage } from "../MiniMaxImage";
  // import { AnimatedCounter } from "../animations";

  return (
    <AbsoluteFill style={{ backgroundColor: "#0d1b2a" }}>
      {/* 粒子背景装饰 */}
      <ParticleBackground particleCount={6} />

      {/* 字幕（必须有） */}
      {/* <SentenceSubtitle
        sentences={["第1句", "第2句"]}
        duration={duration}
      /> */}

      {/* TODO: 根据 visual_plan.json 的 visual_type 填入具体视觉 */}
      {/* DATA: <AnimatedCounter end={300} suffix="%" /> */}
      {/* SCENE: <MiniMaxImage src="..." /> */}
    </AbsoluteFill>
  );
};
