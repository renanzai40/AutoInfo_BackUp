/**
 * MainComposition.tsx · 主 Composition 模板
 *
 * 使用方法：
 * 1. 复制到 src/composition/MainComposition.tsx
 * 2. 替换下面的 SRT entry 帧常量（来自 visual-plan 输出的 timing）
 * 3. 在 scenes 数组填入各 scene 的 duration 和 subtitleIdx
 * 4. 在各 Scene 组件中实现具体视觉
 */

import React from "react";
import "./index.css";
import {
  AbsoluteFill,
  useCurrentFrame,
  interpolate,
  spring,
  useVideoConfig,
  Img,
} from "remotion";
import { Audio } from "@remotion/media";
import { staticFile } from "remotion";
import { TransitionSeries, linearTiming } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import { whoosh } from "@remotion/sfx";
import {
  ParticleBackground,
  SentenceSubtitle,
} from "../animations";

// ─── TTS 音频实测时长（ffprobe）──────────────────────────
const AUDIO_DURATION = {AUDIO_DURATION}; // 秒
export const MAIN_TOTAL_FRAMES = Math.ceil(AUDIO_DURATION * 30);

// ─── SRT entry 帧范围（visual-plan 输出后填写）───────────
// 格式：const T{N}_FROM = 帧起点; const T{N}_TO = 帧终点;
{SRT_TIMING_BLOCK}

// ─── 过渡配置 ───────────────────────────────────────────
const TRANSITION_DUR = 15;

// ─── Whoosh 音效触发帧 ──────────────────────────────────
// {WHOOSH_BLOCK}

// ─── 场景定义（visual-plan 生成后填写）───────────────────
const scenes = [
  // { duration: S1_DUR, subtitleIdx: 0 },
  // { duration: S2_DUR, subtitleIdx: 1 },
  // ...
];

// ─── 场景组件占位符（需实现具体视觉）──────────────────────
const Scene: React.FC<{ idx: number; duration: number; subtitleIdx: number }> = ({
  idx, duration, subtitleIdx,
}) => {
  const frame = useCurrentFrame();
  const SCENE_COLORS = [
    "#0d1b2a", "#1a2f1a", "#1a1a2f",
    "#2f1a2f", "#1a2f2f", "#0d1b2a",
  ];

  return (
    <AbsoluteFill style={{ backgroundColor: SCENE_COLORS[idx] || "#0d1b2a" }}>
      {/* 粒子背景（所有场景） */}
      <ParticleBackground particleCount={6} />

      {/* TODO: 在此实现具体场景视觉 */}
      {/* 例如：MiniMax 生图、AnimatedCounter、ToolCard 等 */}

      {/* 句级字幕（示例） */}
      {/* <SentenceSubtitle
        sentences={["这里是字幕内容"]}
        duration={duration}
      /> */}
    </AbsoluteFill>
  );
};

// ─── 主 Composition ──────────────────────────────────────
export const MainComposition: React.FC = () => {
  return (
    <AbsoluteFill style={{ backgroundColor: "#0d1b2a" }}>
      {/* TTS 主音频 */}
      <Audio src={staticFile("audio/tts.wav")} />

      {/* 过渡音效（每场景切换点） */}
      {/* <Audio src={whoosh} from={WHOOSH1_FRAME} /> */}
      {/* 更多 whoosh 音效... */}

      {/* 场景序列 */}
      <TransitionSeries>
        {scenes.map((scene, i) => (
          <React.Fragment key={i}>
            <TransitionSeries.Sequence durationInFrames={scene.duration}>
              <Scene
                idx={i}
                duration={scene.duration}
                subtitleIdx={scene.subtitleIdx}
              />
            </TransitionSeries.Sequence>
            {i < scenes.length - 1 && (
              <TransitionSeries.Transition
                presentation={fade()}
                timing={linearTiming({ durationInFrames: TRANSITION_DUR })}
              />
            )}
          </React.Fragment>
        ))}
      </TransitionSeries>
    </AbsoluteFill>
  );
};
