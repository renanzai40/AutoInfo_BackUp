/**
 * Remotion 动画组件库 · 壹目贯维标准模板
 * 规则：所有动画基于 useCurrentFrame() + interpolate()，禁止 CSS @keyframes
 */

import React from "react";
import {
  useCurrentFrame,
  interpolate,
  spring,
  useVideoConfig,
  AbsoluteFill,
  Easing,
  Img,
} from "remotion";

/* ─────────────────────────────────────────────────────────────────
 * PARTICLE — 粒子背景装饰（帧驱动三角函数）
 * ───────────────────────────────────────────────────────────────── */
type ParticleDef = {
  baseX: number; baseY: number; size: number;
  speed: number; phase: number; amplitude: number;
  opacity: number; color: string;
};

const PARTICLES: ParticleDef[] = [
  { baseX: 10, baseY: 20, size: 4,  speed: 0.018, phase: 0,    amplitude: 8,  opacity: 0.35, color: "#ffffff" },
  { baseX: 85, baseY: 15, size: 3,  speed: 0.015, phase: 1.2,  amplitude: 6,  opacity: 0.25, color: "#ffffff" },
  { baseX: 30, baseY: 70, size: 5,  speed: 0.022, phase: 2.4,  amplitude: 10, opacity: 0.20, color: "#ffffff" },
  { baseX: 70, baseY: 60, size: 3,  speed: 0.017, phase: 0.8,  amplitude: 7,  opacity: 0.30, color: "#ffffff" },
  { baseX: 50, baseY: 40, size: 4,  speed: 0.020, phase: 3.6,  amplitude: 9,  opacity: 0.20, color: "#ffffff" },
  { baseX: 20, baseY: 85, size: 3,  speed: 0.016, phase: 1.6,  amplitude: 5,  opacity: 0.25, color: "#ffffff" },
  { baseX: 90, baseY: 50, size: 4,  speed: 0.019, phase: 4.8,  amplitude: 8,  opacity: 0.20, color: "#ffffff" },
  { baseX: 45, baseY: 90, size: 3,  speed: 0.014, phase: 2.0,  amplitude: 6,  opacity: 0.30, color: "#ffffff" },
];

export const ParticleBackground: React.FC<{
  particleCount?: number;
  color?: string;
}> = ({ particleCount = 8, color = "#ffffff" }) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ overflow: "hidden", pointerEvents: "none" }}>
      {PARTICLES.slice(0, particleCount).map((p, i) => {
        const offsetX = Math.sin(frame * p.speed + p.phase) * p.amplitude;
        const offsetY = Math.cos(frame * p.speed * 0.7 + p.phase + 1) * p.amplitude;
        const flicker = interpolate(
          frame * p.speed * 3 + p.phase,
          [0, Math.PI * 0.5, Math.PI, Math.PI * 1.5, Math.PI * 2],
          [1, 0.6, 1, 0.6, 1],
          { extrapolateRight: "clamp" }
        );
        const opacity = p.opacity * flicker;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: `${Math.max(0, Math.min(100, p.baseX + offsetX))}%`,
              top: `${Math.max(0, Math.min(100, p.baseY + offsetY))}%`,
              width: p.size, height: p.size, borderRadius: "50%",
              backgroundColor: color,
              opacity,
              boxShadow: `0 0 ${p.size * 3}px ${color}`,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/* ─────────────────────────────────────────────────────────────────
 * ANIMATED COUNTER — 数字滚动（bezier 弹跳过冲）
 * ───────────────────────────────────────────────────────────────── */
type AnimatedCounterProps = {
  end: number;
  start?: number;
  delay?: number;
  duration?: number;
  prefix?: string;
  suffix?: string;
  fontSize?: number;
  color?: string;
  fontFamily?: string;
};

export const AnimatedCounter: React.FC<AnimatedCounterProps> = ({
  end, start = 0, delay = 0, duration = 60,
  prefix = "", suffix = "", fontSize = 72,
  color = "yellow", fontFamily = "Arial, sans-serif",
}) => {
  const frame = useCurrentFrame();
  const progress = Math.max(0, Math.min(1, (frame - delay) / duration));
  const eased = interpolate(progress, [0, 1], [0, 1], {
    easing: Easing.bezier(0.34, 1.56, 0.64, 1),
    extrapolateRight: "clamp",
  });
  const displayValue = Math.round(start + (end - start) * eased);
  const opacity = interpolate(progress, [0, 0.08, 0.92, 1], [0, 1, 1, 0], {
    extrapolateRight: "clamp",
  });
  if (frame < delay || frame > delay + duration + 15) return null;
  return (
    <div style={{
      fontSize, fontWeight: "bold", color, fontFamily,
      opacity,
      textShadow: "0 0 20px rgba(255,200,0,0.5), 2px 2px 0 #000",
    }}>
      {prefix}{displayValue.toLocaleString("zh-CN")}{suffix}
    </div>
  );
};

/* ─────────────────────────────────────────────────────────────────
 * ANIMATED DATA CARD — 数据展示卡片（spring 弹簧入场）
 * ───────────────────────────────────────────────────────────────── */
type DataCardProps = {
  label: string;
  value: string;
  unit?: string;
  delay?: number;
  duration?: number;
  borderColor?: string;
  style?: React.CSSProperties;
};

export const AnimatedDataCard: React.FC<DataCardProps> = ({
  label, value, unit = "", delay = 0, duration = 30,
  borderColor = "rgba(255,200,0,0.8)", style = {},
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const relFrame = Math.max(0, frame - delay);
  const springVal = spring({
    frame: relFrame, fps,
    config: { damping: 10, stiffness: 100 },
    durationInFrames: duration,
  });
  const scale = interpolate(springVal, [0, 1], [0.6, 1]);
  const opacity = interpolate(springVal, [0, 1], [0, 1]);
  if (relFrame >= duration + 10) return null;
  return (
    <div style={{
      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
      padding: "20px 40px",
      border: `3px solid ${borderColor}`,
      borderRadius: 12,
      backgroundColor: "rgba(0,0,0,0.7)",
      transform: `scale(${scale})`, opacity,
      ...style,
    }}>
      <div style={{ fontSize: 18, color: "rgba(255,255,255,0.7)", fontFamily: "Arial", marginBottom: 8, letterSpacing: 2 }}>
        {label}
      </div>
      <div style={{ fontSize: 48, fontWeight: "bold", color: "yellow", fontFamily: "Arial",
        textShadow: "0 0 20px rgba(255,200,0,0.6), 2px 2px 0 #000" }}>
        {value}<span style={{ fontSize: 24, marginLeft: 4 }}>{unit}</span>
      </div>
    </div>
  );
};

/* ─────────────────────────────────────────────────────────────────
 * INK REVEAL — 壹目贯维 Logo 动效（品牌规范）
 * ───────────────────────────────────────────────────────────────── */
type InkRevealLogoProps = {
  duration: number;
  fontSize?: number;
  color?: string;
  fontFamily?: string;
};

export const InkRevealLogo: React.FC<InkRevealLogoProps> = ({
  duration, fontSize = 120, color = "#000",
  fontFamily = "SimSun, Songti SC, serif",
}) => {
  const frame = useCurrentFrame();
  const containerOpacity = interpolate(frame, [0, 30], [0, 1], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  const charOpacities = [0, 1, 2, 3].map((i) =>
    interpolate(frame, [30 + i * 15, 45 + i * 15], [0, 1], {
      extrapolateLeft: "clamp", extrapolateRight: "clamp",
    })
  );
  const letterSpacing = interpolate(frame, [90, 120], [0, 12], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  const chars = ["壹", "目", "贯", "维"];
  return (
    <div style={{ opacity: containerOpacity, display: "flex", flexDirection: "row",
      gap: `${letterSpacing}px`, userSelect: "none" }}>
      {chars.map((char, i) => (
        <span key={i} style={{
          fontFamily, fontSize, color,
          opacity: charOpacities[i],
          textShadow: "2px 2px 0 rgba(0,0,0,0.1)",
        }}>{char}</span>
      ))}
    </div>
  );
};

/* ─────────────────────────────────────────────────────────────────
 * SENTENCE SUBTITLE — 句级字幕（工具名高亮版）
 * ⚠️ opacity 和 transform 用独立时序，禁止耦合
 * ───────────────────────────────────────────────────────────────── */
type SentenceSubtitleProps = {
  sentences: string[];
  duration: number;
  highlight?: string | null;
  fontSize?: number;
  bottom?: number;
};

export const SentenceSubtitle: React.FC<SentenceSubtitleProps> = ({
  sentences, duration, highlight = null,
  fontSize = 48, bottom = 130,
}) => {
  const frame = useCurrentFrame();
  const totalChars = sentences.reduce((sum, s) => sum + s.length, 0);
  const baseFrames = Math.floor(duration * 0.92);
  const avgCharFrames = baseFrames / totalChars;
  const froms: number[] = [0];
  for (let i = 0; i < sentences.length - 1; i++) {
    froms.push(Math.round(froms[i] + sentences[i].length * avgCharFrames));
  }
  let activeIdx = sentences.length - 1;
  for (let i = 0; i < sentences.length; i++) {
    if (frame < froms[i]) { activeIdx = i - 1; break; }
  }
  activeIdx = Math.max(0, activeIdx);
  const sentence = sentences[activeIdx] ?? "";
  const progress = frame - froms[activeIdx];

  // opacity 独立淡入淡出（独立于 spring）
  const fadeIn  = interpolate(frame, [0, 12], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const fadeOut = interpolate(frame, [duration - 20, duration], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const opacity = Math.min(fadeIn, fadeOut);

  // spring 只驱动 translateY/scale，不驱动 opacity
  const springVal = spring({ frame: Math.min(progress, 30), fps: 30, config: { damping: 16, stiffness: 140 } });
  const scale     = interpolate(springVal, [0, 1], [0.92, 1]);
  const translateY = interpolate(springVal, [0, 1], [10, 0]);

  const renderText = () => {
    if (!highlight) return <span>{sentence}</span>;
    const idx = sentence.indexOf(highlight);
    if (idx === -1) return <span>{sentence}</span>;
    return (
      <>
        <span>{sentence.slice(0, idx)}</span>
        <span style={{ background: "rgba(255,235,59,0.35)", borderRadius: 4, padding: "0 4px" }}>{highlight}</span>
        <span>{sentence.slice(idx + highlight.length)}</span>
      </>
    );
  };

  return (
    <div style={{
      fontSize, color: "white", fontFamily: "Arial, sans-serif",
      position: "absolute", bottom, left: 60, right: 60, textAlign: "center",
      opacity, transform: `scale(${scale}) translateY(${translateY}px)`,
      textShadow: "0 4px 24px rgba(0,0,0,0.8)", lineHeight: 1.6, padding: "0 20px",
    }}>
      {renderText()}
    </div>
  );
};

/* ─────────────────────────────────────────────────────────────────
 * TOOL CARD — 工具名高亮卡片（工具测评视频专用）
 * ───────────────────────────────────────────────────────────────── */
type ToolCardProps = {
  toolName: string;
  toolIndex: number;
  duration: number;
  borderColor: string;
};

const TOOL_INDEX_MAP: Record<string, number> = {
  "通义万相": 1, "字节即梦": 2, "Liblib": 3, "AISpeed": 4,
};

export const ToolCard: React.FC<ToolCardProps> = ({
  toolName, toolIndex, duration, borderColor,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // opacity 独立淡入淡出
  const fadeIn  = interpolate(frame, [0, 20], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const fadeOut = interpolate(frame, [duration - 20, duration], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const opacity = Math.min(fadeIn, fadeOut);

  // spring 只驱动 scale
  const springVal = spring({ frame, fps, config: { damping: 15, stiffness: 110 } });
  const scale = interpolate(springVal, [0, 1], [0.65, 1]);

  // 内部 stagger：序号先出，工具名延迟8帧
  const labelSpring = spring({ frame, fps, config: { damping: 16, stiffness: 130 } });
  const nameSpring  = spring({ frame: Math.max(0, frame - 8), fps, config: { damping: 16, stiffness: 130 } });
  const labelScale  = interpolate(labelSpring, [0, 1], [0.5, 1]);
  const nameScale   = interpolate(nameSpring,  [0, 1], [0.5, 1]);
  const labelOpacity = interpolate(labelSpring, [0, 1], [0, 1]);
  const nameOpacity  = interpolate(nameSpring,  [0, 1], [0, 1]);

  return (
    <div style={{
      position: "absolute", top: "42%", left: 0, right: 0,
      display: "flex", justifyContent: "center",
      opacity, transform: `scale(${scale})`,
      pointerEvents: "none", zIndex: 5,
    }}>
      <div style={{
        padding: "16px 48px",
        border: `3px solid ${borderColor}`,
        borderRadius: 16,
        backgroundColor: "rgba(0,0,0,0.7)",
        boxShadow: `0 0 30px ${borderColor}66`,
      }}>
        <div style={{
          fontSize: 18, color: borderColor, fontFamily: "Arial, sans-serif",
          letterSpacing: 4, marginBottom: 4,
          opacity: labelOpacity, transform: `scale(${labelScale})`,
        }}>
          第{TOOL_INDEX_MAP[toolName] ?? toolIndex}款
        </div>
        <div style={{
          fontSize: 56, fontWeight: "bold", color: "white", fontFamily: "Arial, sans-serif",
          textShadow: `0 0 20px ${borderColor}99`,
          opacity: nameOpacity, transform: `scale(${nameScale})`,
        }}>
          {toolName}
        </div>
      </div>
    </div>
  );
};

/* ─────────────────────────────────────────────────────────────────
 * TOOL BAR CHART — 工具对比柱状图（工具测评视频专用）
 * ───────────────────────────────────────────────────────────────── */
type ToolBarChartProps = {
  tools: { name: string; score: number; color: string }[];
  activeTool: string | null;
};

export const ToolBarChart: React.FC<ToolBarChartProps> = ({ tools, activeTool }) => {
  const frame = useCurrentFrame();
  const appearAt = 10;
  const relFrame = Math.max(0, frame - appearAt);
  const opacity = interpolate(relFrame, [0, 20], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const springVal = spring({ frame: relFrame, fps: 30, config: { damping: 13, stiffness: 90 } });
  const barOpen = interpolate(springVal, [0, 1], [0, 1]);

  const BAR_AREA_WIDTH = 700;
  const BAR_HEIGHT = 36;
  const BAR_GAP = 24;
  const MAX_SCORE = 100;

  return (
    <div style={{ position: "absolute", top: 80, right: 30, opacity, pointerEvents: "none" }}>
      <svg width={BAR_AREA_WIDTH} height={tools.length * (BAR_HEIGHT + BAR_GAP) + BAR_GAP}
           viewBox={`0 0 ${BAR_AREA_WIDTH} ${tools.length * (BAR_HEIGHT + BAR_GAP) + BAR_GAP}`}>
        {tools.map((tool) => {
          const isActive = tool.name === activeTool;
          const barWidth = (tool.score / MAX_SCORE) * (BAR_AREA_WIDTH - 200) * barOpen;
          const y = BAR_GAP + tools.indexOf(tool) * (BAR_HEIGHT + BAR_GAP);
          return (
            <g key={tool.name}>
              <text x={0} y={y + BAR_HEIGHT / 2 + 7}
                fill={isActive ? tool.color : "rgba(255,255,255,0.45)"}
                fontSize={22} fontFamily="Arial"
                fontWeight={isActive ? "bold" : "normal"}>
                {tool.name}
              </text>
              <rect x={160} y={y} width={BAR_AREA_WIDTH - 200} height={BAR_HEIGHT}
                fill="rgba(255,255,255,0.06)" rx={6} />
              <rect x={160} y={y} width={barWidth} height={BAR_HEIGHT}
                fill={isActive ? tool.color : "rgba(255,255,255,0.25)"}
                rx={6} opacity={isActive ? 1 : 0.5} />
              <text x={BAR_AREA_WIDTH - 25} y={y + BAR_HEIGHT / 2 + 7}
                textAnchor="end"
                fill={isActive ? tool.color : "rgba(255,255,255,0.45)"}
                fontSize={22} fontFamily="Arial"
                fontWeight={isActive ? "bold" : "normal"}>
                {isActive ? Math.round(tool.score * barOpen) : tool.score}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
};

/* ─────────────────────────────────────────────────────────────────
 * CONTRAST FLASH LOGO — 结尾 CTA 专用（黑白↔反白切换）
 * ───────────────────────────────────────────────────────────────── */
type ContrastFlashLogoProps = {
  duration: number;
  logoSrc?: string;
};

export const ContrastFlashLogo: React.FC<ContrastFlashLogoProps> = ({
  duration, logoSrc = "./brand/logo.jpg",
}) => {
  const frame = useCurrentFrame();
  const isFlipped = (frame % 30) < 15;
  return (
    <img
      src={logoSrc}
      style={{
        height: 200,
        filter: isFlipped ? "invert(1)" : "none",
        opacity: 0.9,
      }}
    />
  );
};
