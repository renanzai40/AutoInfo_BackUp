#!/bin/bash
# fix_topic.sh — 替换 Remotion 项目模板中的占位符
# 用法：./fix_topic.sh <TOPIC> <ID> <AUDIO_DURATION_SECONDS>
#
# 示例：./fix_topic.sh wentech WentechTTS 65.9

TOPIC=${1:-wentech}
ID=${2:-WentechTTS}
DURATION=${3:-60}

echo "Replacing placeholders:"
echo "  TOPIC:    $TOPIC"
echo "  ID:       $ID"
echo "  DURATION: ${DURATION}s"

# 替换 Root.tsx
sed -i "s/{TOPIC}/$TOPIC/g; s/{ID}/$ID/g" src/Root.tsx

# 替换 MainComposition.tsx 中的时长
sed -i "s/{AUDIO_DURATION}/$DURATION/g; s/{FPS}/30/g" src/composition/MainComposition.tsx

# 替换 MainComposition.tsx 中的场景编号占位符
sed -i "s/{SRT_TIMING_BLOCK}//g; s/{WHOOSH_BLOCK}//g" src/composition/MainComposition.tsx

# 替换 SceneTemplate.tsx 中的编号
sed -i "s/{N}/0/g" src/scenes/SceneTemplate.tsx

# 替换 package.json 中的 ID
sed -i "s/{ID}/$ID/g" package.json

echo "Done. Next steps:"
echo "  1. Put TTS audio at public/audio/tts.wav"
echo "  2. Run: bun install"
echo "  3. Run: bunx remotion preview (to preview)"
echo "  4. Fill in SRT timing constants in src/composition/MainComposition.tsx"
