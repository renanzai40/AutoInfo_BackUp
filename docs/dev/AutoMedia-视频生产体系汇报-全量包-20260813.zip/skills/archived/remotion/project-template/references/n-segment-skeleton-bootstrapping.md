# NSegmentSkeleton Composition 快速引导

> 2026-06-04 定型的 Remotion Composition 模式。比 Scene-based 模板更简洁：所有 5 段集成在单个 Composition + `scene-data.ts` + `blocks.tsx` 三文件中，无需逐场景创建 `.ts` 文件。
>
> 当前已有 10+ 生产的视频使用此模式（从 AlphabetAnthropicV4 起全部新项目）。

## 需要创建的 3 个文件 + 1 处注册

### 1. `src/blocks/<topic-slug>/scene-data.ts`

定义 5 段的时间边界、字幕组、和每个段的视觉组件引用。

```ts
import type { SegmentData, SegmentBoundary } from "../../../templates/n-segment-skeleton";
import { S1Hook, S2Pain, S3Data, S4Climax, S5CTA } from "./blocks";

export const TOTAL_FRAMES = 1228;   // ceil(TTS_DURATION × 30) + gap 帧
export const TTS_DURATION = 40.94;  // ffprobe 精确秒数

export const SCENE_SUBTITLES = [
  [ // S1
    { text: "第一句", start: 0, duration: 65 },
    { text: "第二句", start: 70, duration: 55 },
  ],
  // S2 … S5
];

export const BOUNDARIES: SegmentBoundary[] = [
  { from: 0,    to: 195  },  // S1
  { from: 210,  to: 480  },  // S2 (后接 15 帧间隙)
  // S3 S4 S5
];

export const SEGMENTS: SegmentData[] = [
  { idx: 0, label: "钩子", baseHue: 210, subtitles: SCENE_SUBTITLES[0], NumberBlock: S1Hook },
  { idx: 1, label: "痛点", baseHue: 0,   subtitles: SCENE_SUBTITLES[1], NumberBlock: S2Pain },
  { idx: 2, label: "干货", baseHue: 140, subtitles: SCENE_SUBTITLES[2], NumberBlock: S3Data },
  { idx: 3, label: "高潮", baseHue: 50,  subtitles: SCENE_SUBTITLES[3], NumberBlock: S4Climax },
  { idx: 4, label: "CTA",  baseHue: 280, subtitles: SCENE_SUBTITLES[4], NumberBlock: S5CTA },
];
```

字段说明：`baseHue`=段背景色调(0-360)、`subtitles`=段内字幕数组（start/duration 为段内帧偏移）、`NumberBlock`=组件引用。

### 2. `src/blocks/<topic-slug>/blocks.tsx`

5 个 NumberBlock 组件，使用 `.tsx`（用 JSX 语法）。`useCurrentFrame()` 返回段内 0-based 帧。

```tsx
import React from "react";
import { useCurrentFrame, interpolate, spring, Easing, useVideoConfig } from "remotion";
const EASE_OUT = Easing.bezier(0.16, 1, 0.3, 1);

export const S1Hook: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  // interpolate/spring 驱动动画...
};
export const S2Pain: React.FC = () => { /* ... */ };
export const S3Data: React.FC = () => { /* ... */ };
export const S4Climax: React.FC = () => { /* ... */ };
export const S5CTA: React.FC = () => { /* ... */ };
```

### 3. `src/<Topic>Composition.tsx`

```tsx
import React from "react";
import { NSegmentSkeleton } from "../templates/n-segment-skeleton";
import { BOUNDARIES, SEGMENTS, TTS_DURATION } from "./blocks/<topic-slug>/scene-data";
export const TOTAL_FRAMES = 1228;
export const MyComp: React.FC = () => (
  <NSegmentSkeleton
    boundaries={BOUNDARIES} segments={SEGMENTS}
    titleLines={[{ text: "主标题", delay: 0 }]}
    audioSrc="audio/<topic>.mp3" totalTtsDuration={TTS_DURATION}
  />
);
```

### 4. `src/Root.tsx` 注册

`import` 后在 `<>` 内加 `<Composition id="..." component={...} durationInFrames={TOTAL_FRAMES} fps={30} width={1080} height={1920} />`。

## 音频 + 渲染流程

```bash
# TTS → 测时长 → 计算帧数 → 渲染 → cp 到项目目录
edge-tts --voice "zh-CN-XiaoxiaoNeural" --text "脚本" --write-media public/audio/<topic>.mp3
ffmpeg -i public/audio/<topic>.mp3 2>&1 | grep Duration
bunx remotion render src/index.ts <CompositionId> /tmp/<topic>.mp4 --concurrency=2 --log=error
cp /tmp/<topic>.mp4 <project_dir>/03_video/video_final.mp4
```

## 强制规则

- `segments[i].subtitles` 必须非空（P0-14 铁律）：空数组导致 `<SubtitleCard>` 渲染空白
- `.tsx` 扩展名（不是 `.ts`），Scene-based 老模式才用 `.ts` + `React.createElement()`
- 段间隙 15 帧（fade 过渡），间隙内不显示字幕
- 禁止 CSS `@keyframes`，全部用 `useCurrentFrame()` + `interpolate` 驱动

## 实测基准

~180 字中文 → edge-tts（XiaoxiaoNeural/YunxiNeural 均约 40.5-40.9s）→ ~4.4 chars/sec。
如需调慢：`ffmpeg -i input.mp3 -filter:a "atempo=0.85" output.mp3`。

## 与 Scene-based 模板的区别

| 维度 | Scene-based（老） | NSegmentSkeleton（当前） |
|------|-------------------|--------------------------|
| 文件数 | ~10 | 4 |
| 字幕 | 外部 SRT 烧录 | 内置 SCENE_SUBTITLES |
| 过渡 | TransitionSeries | 内部 15 帧间隙 |
| 背景 | 手写 CSS | 自动 hsb 渐变 |
| 适用 | 2026-05 及之前 | 2026-06-04 起所有新项目 |
