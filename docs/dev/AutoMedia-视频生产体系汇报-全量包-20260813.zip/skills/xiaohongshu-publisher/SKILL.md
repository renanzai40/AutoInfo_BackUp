---
name: xiaohongshu-publisher
description: "小红书内容创作与发布。必须先加载 yimuguanwei-persona skill，定义品牌人设后再开始文案创作。文案完成后通过 copy-review + brand-cta-review 双门控，再生成配图（封面图3:4 + 内容图2-10张），Vision QA通过后交付发布。 排除：不用于小红书图文内容创作本身（归 xhs-ops）；仅发布执行时加载。"
tags: [xiaohongshu, 小红书, 内容创作, 配图生成, AISpeed]
---

# 小红书 Publisher · 壹目贯维专项

## 强制加载顺序

> **每次执行本 skill，必须按顺序加载以下文件：**

1. **`yimuguanwei-persona`**（品牌人设）— 定义品牌身份、目标受众、账号人设、口癖禁止项
2. **`references/content-guide.md`**（本 skill 内，内容规范）— 定义标题/正文/配图/标签格式
3. **`image-prompt`**（生图规范）— 定义封面图和内容图的 prompt 规则 + Vision QA

不加载上一级，下一级不开始。

---

## 壹 · 品牌人设（必须先读）

**触发条件**：每次为小红书创作内容前。

详细规范见 `yimuguanwei-persona` skill。

### 品牌身份
壹目贯维 = **全球AI内容生产公司**，核心：热点追踪 + 文案生成 + 多平台发布 + AISpeed + 本地化精准

### 账号人设
有实战经验、敢说真话、不割韭菜、帮你省钱的AI内容老手。不是卖课的，不是咨询公司。

### 对谁说话
国内业务出海企业 / 海外入华企业 / 全球业务初创公司的老板、管理者或创业者
共同痛点：业务无法进入或融入当地市场或文化

### 禁止项
- 投资情报 / 金融分析 / 政策信号追踪
- 诱导话术（限时优惠/私信就送/评论区扣1领资料）
- 空洞词（AI赋能/高效内容生产）
- 品牌名不出现

---

## 贰 · 内容创作流程

```
Step 1  →  加载 yimuguanwei-persona（品牌人设）
Step 2  →  加载 references/content-guide.md（内容规范）
Step 3  →  生成文案（标题 + 开头 + 正文3-5段 + 结尾互动 + 标签5-10个）
Step 4  →  自检（标题≤20字？正文≤5段？有互动引导？有标签5-10个？）
Step 5  →  通过 copy-review（文案质量审查）
Step 6  →  通过 brand-cta-review（品牌CTA审查）
Step 7  →  生成封面图（1080×1440，3:4，image-prompt skill）
Step 8  →  生成内容图（2-10张，image-prompt skill）
Step 9  →  Vision QA（乱码/地图/Logo/人像）
Step 10 →  打包交付（用户确认）→ 发布
```

---

## 叁 · 标签规范（创作时参考）

标签组合策略（5-10个，必须全中文）：

```
2-3个宽泛标签：#AI内容生产 #出海 #海外市场 #内容生产
2-3个垂直标签：#本地化 #跨境电商 #品牌出海
2-3个场景标签：#内容营销 #社交媒体运营
1-2个人群标签：#企业主 #创业者 #出海品牌
必须包含：#壹目贯维（品牌标签）
```

---

## 肆 · 配图规范

### 数量标准

| 内容类型 | 图片数量 |
|---|---|
| 观点简单/单一主题 | 2-3张 |
| 中等复杂/行业资讯/教程类 | 4-6张 |
| 深度干货/多维度分析 | 7-10张 |

**第1张 = 封面图**（见伍·封面图）
**第2张起 = 内容图**（每张聚焦1个核心观点）
**最后1张 = 总结图**（金句收尾 + 行动号召 + 品牌露出）

### 内容图要求

- 尺寸：3:4 竖版（1080×1440）
- 大标题突出醒目，可用加粗/下划线/圈注强调关键词
- 格式：知识卡片 / 图文卡片 / 数据对比 / 表格
- 适量使用AI科技感图标、Emoji表情点缀
- 信息密度适中，读者3秒读完一个知识点
- **文案全用中文**

---

## 伍 · 封面图生成

### 规格

| 参数 | 值 |
|---|---|
| 尺寸 | 3:4 竖版（1080×1440） |
| 主色调 | 科技蓝紫（#1a1a2e + #4361ee） |
| 字体 | 中文手写风格，干净利落线条 |

### 内容要求

- 核心标题（大字，2-4字）
- 吸引点（数字/痛点/悬念三选一）
- 强视觉冲击

### 禁止项

- 地图/地球仪/大陆轮廓（飞书审核高危）
- 品牌Logo（YouTube/Google/OpenAI等）
- 有影响力人物清晰肖像
- 乱码文字/符号

### 生成命令

```bash
python3 <skill-dir>/scripts/gen_cover.py \
  --title "主标题" \
  --subtitle "副标题" \
  --tags "标签1,标签2,标签3" \
  --badge "壹目贯维" \
  --gradient purple \
  --output /path/to/cover_3x4.png
```

生成后 **必须 Vision QA**（乱码/地图/Logo/人像），通过后才用于发布。

---

## 陆 · 文案质量门控

### 门控顺序（强制）

```
生成文案 → humanizer → copy-review → brand-cta-review → 配图生成 → Vision QA → 发布
```

**copy-review** 检查：清晰度 / 语调一致 / So What利益 / 证据 / 具体性

**brand-cta-review** 检查：品牌身份锚定 / 功能具体 / 过渡同向 / 视频+文章同步 / 无禁止词

任一门控不通过 → 修正 → 重新过门控

---

## 柒 · 发布流程

### Step 1: 发送草稿给用户审核

```
📝 小红书草稿 — [主题]

标题：[标题]

[正文内容]

封面图：[path]
内容图：[N张]

请确认：
✅ 可以发布
✏️ 需要修改
❌ 不发
```

**Never auto-publish.** 始终等待用户明确批准。

### Step 2: 用户批准后发布

通过浏览器自动化发布（见 references/browser-publish.md），
或手动发布（将完整内容发送给用户 copy-paste）。

### Fallback: 手动发布

如浏览器自动化不可用，发送完整内容格式：

```
📋 小红书发帖内容（请手动发布）

【标题】标题文本

【正文】
完整正文内容...

【标签】#tag1 #tag2 ...

【封面图】/path/to/cover_3x4.png
【内容图】/path/to/image_2.png, /path/to/image_3.png, ...
```

---

## 捌 · 常见错误自查表

发布前逐项检查：

- [ ] 标题≤20字？有Emoji？有数字/疑问/痛点？
- [ ] 封面图强视觉冲击？包含核心标题？
- [ ] 封面图是3:4竖版？
- [ ] 正文≤5段？每段≤5行？
- [ ] 没有晦涩术语（或有通俗解释）？
- [ ] 语气口语化，专业但易懂？
- [ ] 结尾有互动引导（不是诱导话术）？
- [ ] 标签5-10个？全部中文？有#壹目贯维？
- [ ] 品牌名"壹目贯维"出现在正文？
- [ ] 配图数量符合内容类型（2-10张）？
- [ ] 每张配图聚焦1个核心观点？
- [ ] 无地图/Logo/人像/乱码？

有一项为❌ → 修正后再进行下一步。

---

## 附：旧版 Pillow 封面图脚本（已弃用）

> ⚠️ `scripts/gen_cover.py` 生成的是纯文字封面图，无法满足壹目贯维品牌视觉规范。
> **封面图和内容图统一使用 MiniMax image-01 生成**（见 image-prompt skill）。
> 本 skill 内的 Pillow 脚本保留仅用于临时调试，正式发布用的配图必须通过 AI 生图 + Vision QA。

---

## Known Limitations

### 🚫 No Content-Publishing API (confirmed 2026-06-10)

This is the single most important limitation to understand about publishing on Xiaohongshu:

| Platform | Has REST API for publishing? | Auth method | Reliability |
|----------|------------------------------|-------------|-------------|
| **微信公众号** | ✅ Yes — `draft/add`, `draft/delete`, `material/add_material` | AppID + AppSecret + IP whitelist | ✅ Reliable, script-only |
| **小红书** | ❌ **No** — open platform only provides e-commerce APIs (orders, logistics, SKU) and data-reading APIs (notes, comments, user info). **There is no `note/create` or `draft/publish` endpoint.** | OAuth (read-only) | ❌ Not available |

**Learn more**: full research notes in `references/xiaohongshu-api-limitations.md`.

**Viable publishing paths (only two)**:

1. **Browser automation** (Playwright/CDP) via `creator.xiaohongshu.com/publish` — see `references/browser-publish.md`
   - Requires logged-in session (QR scan, lasts days)
   - Fragile — page layout changes break element selectors
   - File upload (cover/image) may fail silently in some CDP configs
   
2. **Manual copy-paste** — deliver formatted content to the user
   - Most reliable fallback
   - Always available

**Decision tree**:

```
Content ready for Xiaohongshu
    ↓
[Q1] Is browser automation available? (Playwright + logged-in session)
    ├─ Yes → Try browser publish (references/browser-publish.md)
    │        如果 upload fails → fall back to manual
    └─ No  → Manual copy-paste (Step 1 format)
    ↓
[Q2] Did browser publish succeed?
    ├─ Yes → ✅ Done
    └─ No  → Fall back to manual copy-paste
```

- **Mac Chrome CDP**: Chrome launched via SSH/node may fail to bind `--remote-debugging-port` on macOS (GUI session required). If `browser start` fails, fall back to manual publishing.
- **Login state**: 小红书 creator portal requires login. If the session has expired, ask the user to re-login in their browser before proceeding.
- **Pillow emoji**: Pillow cannot render color emoji (NotoColorEmoji.ttf) — use text/icon alternatives in cover images.
- **Gen cover script**: 已弃用，正式封面图/内容图用 MiniMax image-01 生成。

## Cron Integration

本 skill 配合 cron job 使用：

```
Schedule: 0 8 * * * (Asia/Shanghai)
Session: isolated agentTurn
Delivery: announce to user's channel
```

Cron job 消息应引用本 skill 并包含当日内容计划/话题。