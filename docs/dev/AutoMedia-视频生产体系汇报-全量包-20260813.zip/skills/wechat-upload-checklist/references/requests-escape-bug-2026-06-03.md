# 2026-06-03 9 个草稿批量乱码事故 — 完整复现 + 修复脚本 + 9 个 content_id

## 事故症状
9 个项目公众号草稿箱显示成 `\u51fa\u54c1\uff1a\u58f9\u76ee\u8d2f\u7ef4 | 2026-05-08` 这种 Python repr 形式，每个汉字 4 位 hex 转义。

## 根因（100% 确认，session_search 追溯）
- **触发 session**：`20260602_103946_4ae413`（main-agent-2026-06-02）
- **触发 message**：message 2674 execute_code
- **触发代码**：`requests.post(url, json=payload, timeout=30)`
- **等价于**：`requests.post(url, data=json.dumps(payload, ensure_ascii=True).encode("utf-8"))`
- **requests 库 `json=` 参数默认 `ensure_ascii=True`** → 所有中文 escape 成 `\u` 形式 → 公众号原样显示

## 修复脚本（实测 9/9 成功，29.68s 跑完）

### 关键点
1. 删旧 content_id（`draft/delete` API）
2. 用 skill 自带 `upload_draft.py` 重传（**已 ensure_ascii=False**）
3. publish_log.json **双记录**（v1=deleted, v2=active）

### 9 个新 content_id（v2）

| # | 项目 | 新 content_id | 标题 |
|---|---|---|---|
| 1 | 0424_rare-earth-leak | `eYCpieqt-pkzK-tHTzKDMt8s-...` | 稀土泄密案的教训 |
| 2 | 0424_ai-translation | `eYCpieqt-pkzK-tHTzKDMvZZp-...` | AI翻译月省75% |
| 3 | 0507_ai-career-10jobs | `eYCpieqt-pkzK-tHTzKDMnC0o-...` | 10个职业AI抢饭碗 |
| 4 | 0508_ai-career-replacement | `eYCpieqt-pkzK-tHTzKDMhVRE-...` | AI时代职业安全 |
| 5 | 0508_ai-domestic | `eYCpieqt-pkzK-tHTzKDMtw4B-...` | 国产AI企业实战 |
| 6 | 0513_ai-model-usage | `eYCpieqt-pkzK-tHTzKDMs1NF-...` | Token成本怎么降 |
| 7 | 0513_trump-china-visit | `eYCpieqt-pkzK-tHTzKDMuddY-...` | 访华背后选题 |
| 8 | 0526_deepseek | `eYCpieqt-pkzK-tHTzKDMjTua-...` | DeepSeek 75折 |
| 9 | 0526_lorai-marketing | `eYCpieqt-pkzK-tHTzKDMv4v9-...` | 营销AI规模化 |

### 修复脚本核心 pattern

```python
# 1. 拿 access_token（urllib，不用 requests，避免 escape）
# 2. 删旧草稿（urllib + json.dumps ensure_ascii=False）
data = json.dumps({"media_id": media_id}).encode("utf-8")
req = urllib.request.Request(url, data=data, headers={...}, method="POST")

# 3. 传新草稿（subprocess 调 skill 自带 upload_draft.py）
result = subprocess.run(
    ["python3", SKILL_DIR / "scripts" / "upload_draft.py", ...],
    capture_output=True, text=True, timeout=60
)

# 4. 更新 publish_log.json 双记录
data["v1_drafts"].append({"status": "deleted", "content_id": old_cid, ...})
data["v2_drafts"].append({"status": "active", "content_id": new_cid, ...})
```

完整脚本在 `/tmp/fix_wechat_drafts.py`（一次性，未入库）。

## 9 个项目 HTML 源文件状态

全部 **干净 UTF-8 中文**（`grep -c '\\u[0-9a-fA-F]\{4\}' *.html` 返回 0）——**坏的是 API 收到的 JSON 字符串，不是源文件**。

## 备份位置

```
/tmp/wechat_fix_backup_20260603_130304/
  ├── 9 个 publish_log.json
  ├── 9 个 wechat_draft.wechat.html
  └── index.json
```

## 教训（固化进 SKILL.md Pitfall 11/12）

1. **永远不要 inline 写 `requests.post(json=...)`** —— requests 库 `json=` 默认 `ensure_ascii=True`
2. **写"修复 \u escape bug"脚本时不要在源码里再写 \u 字面量** —— Python 解析器会把 `\u escape` 当 Unicode escape 开始，期待 4 位 hex
3. **修复后用 `verify_published_content.py` 验证** —— 9/9 active 全部 OK，17 个 published 正常跳过
4. **未来 PR 改坏 `ensure_ascii=False` → `test_upload_draft_ensure_ascii.py` 立即 fail**
5. **agent 想绕 skill → `safe_upload_wechat.py` 是唯一安全入口**（4 步硬门控）
