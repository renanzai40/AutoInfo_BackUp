# 验证步骤

### 验证步骤

```bash
# 检查 review_log.json 是否存在
ls 项目/04_review/review_log.json

# 检查 Gate 状态
cat 项目/04_review/review_log.json | python3 -c "
import sys, json
d = json.load(sys.stdin)
gates = d.get('gates', {})
required = ['G1_humanizer', 'G2_copy_review', 'G3_brand_cta']
for g in required:
    status = '✅' if gates.get(g) else '❌'
    print(f'{status} {g}')
if all(gates.get(g) for g in required):
    print('✅ 所有 Gate 通过，可以上传')
else:
    print('❌ Gate 未通过，禁止上传')
"
```

---
