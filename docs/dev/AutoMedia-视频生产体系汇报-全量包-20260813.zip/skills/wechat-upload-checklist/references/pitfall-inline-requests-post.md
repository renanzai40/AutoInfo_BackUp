# ⚠️ 致命陷阱：inline 写 requests.post(json=payload) 会变 unicode escape 乱码（2026-06-02 实测）

## ⚠️ 致命陷阱：inline 写 requests.post(json=payload) 会变 unicode escape 乱码（2026-06-02 实测）

**症状**：公众号草稿箱看到的内容是 `\u51fa\u54c1\uff1a\u58f9\u76ee\u8d2f\u7ef4` 这种 Python repr 形式，不是中文。

**根因（100% 确认）**：`requests.post(url, json=payload)` 内部调 `json.dumps(payload, ensure_ascii=True)`——**`requests` 库 `json=` 参数默认 `ensure_ascii=True`**。所有中文被转义为 `\u` 形式，公众号原样显示。

**正确做法（4 选 1，按推荐度排序）**：
1. ✅ `python3 safe_upload_wechat.py --pid <id>`（**统一入口**，`automedia/hooks/safe_upload_wechat.py`）
2. ✅ `python3 upload_draft.py --html <file> --title ... --thumb-media-id ...`（skill 自带，**已 ensure_ascii=False**）
3. ✅ `data=json.dumps(payload, ensure_ascii=False).encode("utf-8")`（手工 urllib 时）
4. ❌ **`requests.post(url, json=payload)` 写法禁止**——任何变体（`json=...` / `json=dumps(...)`）都不行

**检测 hook**（3 个新加，**2026-06-03 落地**，实测挡下 9 个草稿乱码修复）：

| Hook | 路径 | 作用 | 实测 |
|---|---|---|---|
| `verify_published_content.py` | `automedia/hooks/verify_published_content.py` | post-verification：扫所有 `draft_uploaded` 项目，重建 payload，验证 bytes 无 unicode escape | 9/9 active 全 OK，17 个 published 正常跳过 |
| `test_upload_draft_ensure_ascii.py` | `automedia/hooks/test_upload_draft_ensure_ascii.py` | unit test：守住 4 个文件必须含 `ensure_ascii=False` 且禁止 `requests.post(json=...)` 写法 | 6/6 检查全过 |
| `safe_upload_wechat.py` | `automedia/hooks/safe_upload_wechat.py` | 4 步硬门控（pre_check + self_check + upload + log），agent 调一行就够 | 9/9 重传成功，274.1s 跑完 20 条 |

**Step 0.5 重传草稿流程（实测 9 个项目 6-03 跑通）**：
- 删除 9 个旧 content_id（`draft/delete` API errcode=0）
- 用 skill 自带 `upload_draft.py` 重传（**ensure_ascii=False 已写对**）
- publish_log.json **双记录结构**：
  ```json
  {
    "v1_drafts": [{"status": "deleted", "content_id": "旧", "deleted_at": "...", "delete_response": "errcode=0", "title": "...", "digest": "..."}],
    "v2_drafts": [{"status": "active", "content_id": "新", "uploaded_at": "...", "title": "...", "thumb_media_id": "..."}]
  }
  ```
- 备份位置：`/tmp/wechat_fix_backup_<ts>/`（9 个 publish_log + 9 个 HTML + index.json）

**修复脚本模板**：`scripts/fix_requests_json_escape.py`（9 个项目修复脚本）

**6-02 教训**：main-agent 当时 inline 写 `requests.post(..., json=payload, ...)` 绕开所有 skill/hook，导致 9 个项目全乱码。user 揭穿后明确说"微信公众号上传有 skill 可以用的"——**复用 skill 是 hard preference**。
