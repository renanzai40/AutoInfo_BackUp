# 微信公众号草稿质量审计实战 — 2026-05-26

## 背景

13篇草稿批量审计，发现：
- 10篇草稿内容与标题不符（文件放错项目）
- 4篇 HTML 排版损坏（公众号显示为纯文本）
- 1篇内容生成错误（10款AI视频 topic 不存在）

全量修复后 13/13 通过 Gate。

---

## 核心教训

### 1. 并行 Agent 项目内容错位的典型案例

**症状**：多 agent 生成同一批次草稿时，文件虽然放在了正确的项目目录里，但内容是错的。

| 草稿（预期） | 实际 h1 | 根因 |
|---|---|---|
| AI造谣被处罚 | 特朗普结束对中国的国事访问 | agent 把 trump-china-visit 的文件写进了 AI造谣项目 |
| 实测豆包 | 大模型免费时代终结 | doubao-yuyue-canlou ↔ doubao-shoufei-llm 内容互换 |
| 大模型免费时代 | 实测豆包预约餐厅 | 同上，互换 |
| 10款AI视频 | 中美元首会晤达成重要共识 | topic 不存在，错误文件被当作替代 |
| 阿里财报 | 中美元首会晤达成重要共识 | ali-ali-reports 目录内容未找到，用错误文件覆盖 |

**验证方法**：每次上传前提取 h1 标题，与 `project_info.json` 的 `topic` 字段做核心词匹配。

```python
import re
from pathlib import Path

def verify_html_topic_match(html_path, expected_topic_keywords):
    """验证 HTML h1 标题与预期 topic 匹配"""
    html = Path(html_path).read_text(encoding='utf-8')
    h1_m = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.DOTALL)
    if not h1_m:
        return False, "无 h1 标签"
    h1_text = re.sub(r'<[^>]+>', '', h1_m.group(1)).strip()
    
    # 核心词匹配
    match_count = sum(1 for kw in expected_topic_keywords if kw in h1_text)
    match_ratio = match_count / len(expected_topic_keywords)
    
    return match_ratio >= 0.5, f"匹配度 {match_ratio:.0%}: {h1_text}"
```

### 2. HTML 排版损坏的四种形态与处理

| 形态 | 特征 | 判别方法 | 处理 |
|---|---|---|---|
| **Markdown 当 HTML** | 含 `# ` `## ` 等原始 Markdown | `re.search(r'^#{1,6}\s+', content)` | `pandoc -f markdown -t html --wrap=none input.md > output.html` |
| **CSS 混入 body** | `<style>...</style>` 之后才是正文 | `html.find('*{ margin') > 0` 或 `html.find('box-sizing') > 0` | 找到 `</style>` 截断，提取后续纯文本用 pandoc 转 |
| **裸文字无结构** | 只有 `<h1>` + 裸行，无 `<p>/<h2>/<blockquote>` | `len(re.findall(r'<p', html)) == 0` | 提取纯文本，按行分割，用 pandoc 转，加 blockquote 样式 |
| **body 前有 CSS** | `body { font-family:` 在 h1 之前混入 | `<style>` 在 `<body>` 之前 | 同上，截取 `</style>` 之后内容 |

### 3. Gate 机制对公众号形同虚设的根因

`wechat_publisher.py` 本身**不做 Gate 检查**。上传流程：

```
wechat_publisher.py → create_draft() → WeChat API
                         ↑
                   没有调用任何 Gate 检查
```

**正确做法**：Gate 通过记录在 `04_review/review_log.json`，上传前必须验证：

```python
def enforce_gate_before_upload(project_dir):
    review_log = Path(project_dir) / "04_review" / "review_log.json"
    if not review_log.exists():
        raise Exception(f"Gate 未执行: {review_log} 不存在")
    
    import json
    gates = json.loads(review_log.read_text(encoding='utf-8')).get('gates', {})
    required = ['G1_humanizer', 'G2_copy_review', 'G3_brand_cta']
    failed = [g for g in required if not gates.get(g)]
    if failed:
        raise Exception(f"Gate 未通过: {failed}，禁止上传")
```

**架构问题**（需单独修复）：Gate 检查在 skill 文档里，但 `wechat_publisher.py` 没有调用它。这是 skill 与代码的割裂，不是 skill 的问题。

### 4. 公众号 Gate 检查的最小验证集（每篇草稿必过）

```python
def wechat_draft_gate_check(html_path):
    """公众号草稿上传前最低限度检查"""
    html = Path(html_path).read_text(encoding='utf-8')
    
    # 1. h1 存在且非空
    h1_m = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.DOTALL)
    h1 = re.sub(r'<[^>]+>', '', h1_m.group(1)).strip() if h1_m else ""
    if not h1:
        return False, "h1 为空"
    
    # 2. 中文字符数 ≤9
    chinese_count = len([c for c in h1 if '\u4e00' <= c <= '\u9fff'])
    if chinese_count > 9:
        return False, f"标题{chinese_count}字>9"
    
    # 3. 含壹目贯维品牌名
    text = re.sub(r'<[^>]+>', ' ', html)
    if '壹目贯维' not in text:
        return False, "无品牌名"
    
    # 4. 含 <p> 标签（非裸文字）
    if '<p' not in html:
        return False, "无<p>标签，裸文字"
    
    # 5. 无 content_id 已上传（检查 publish_log）
    # 6. 无 <html>/<head> 外层标签
    if '<html>' in html[:200] or '<!DOCTYPE' in html[:200]:
        return False, "含完整 HTML 文档结构，非 body 内容"
    
    return True, "通过"
```

---

## 已验证可用的修复工具链

| 工具 | 用途 |
|------|------|
| `pandoc -f markdown -t html --wrap=none` | Markdown → HTML body |
| `pandoc -f html -t html --wrap=none` | 损坏 HTML → 干净 HTML body |
| `ffmpeg` + `pillow` (pixel brightness) | 视频字幕质量验证（非本次场景） |
| `python3 -c "from pathlib import Path; ..."` | 批量验证 h1/品牌/p标签 |

---

## 修复后验证命令（批量执行）

```bash
# 验证所有草稿的 h1 标题
python3 -c "
from pathlib import Path
import re

base = Path('/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects')
drafts = {
    '反诈APP升级AI': '20260516_100010_anti-fraud-ai-detection/01_content/drafts/wechat/wechat_draft.html',
    '小米MiMo登顶全球': '20260514_xiaomi-car/01_content/drafts/wechat/wechat_draft.html',
    '618生图神器推荐': '20260525_085515_618-ai-tools-recommendation/01_content/drafts/wechat/wechat_draft.html',
    'AI内容工作流': '20260521_1435_ai-model-usage/01_content/drafts/wechat/wechat_draft.html',
    'AI配音提效': '20260520_133057_ai-voice-synthesis/01_content/drafts/wechat_draft.html',
    '闻泰安世对簿公堂': '20260525_085515_wentech-ansys-litigation/01_content/drafts/wechat/wechat_draft.html',
    'AI时代机会在哪': '20260517_094341_ai-era-opportunity/01_content/drafts/wechat/wechat_draft.html',
    '普京访华': '20260520_133057_putin-visit-china/01_content/drafts/wechat_draft.html',
    'AI造谣被处罚': '20260517_094341_trump-china-visit/01_content/drafts/wechat/wechat_draft.html',
    '实测豆包': '20260519_092124_dual-topics/doubao-shoufei-llm/01_content/drafts/wechat/wechat_draft.html',
    '大模型免费时代': '20260519_092124_dual-topics/doubao-yuyue-canlou/01_content/drafts/wechat/wechat_draft.html',
    '阿里财报': '20260516_100010_china-us-summit/01_content/wechat_draft.html',
    '10款AI视频': '20260516_100010_china-us-summit/01_content/drafts/wechat/wechat_draft.html',
}

def count_chinese(s):
    return len([c for c in s if '\u4e00' <= c <= '\u9fff'])

for name, rel in drafts.items():
    p = base / rel
    if not p.exists():
        print(f'❌ {name}: 文件不存在')
        continue
    html = p.read_text(encoding='utf-8')
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'\s+', ' ', text).strip()
    h1_m = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.DOTALL)
    h1 = re.sub(r'<[^>]+>', '', h1_m.group(1)).strip() if h1_m else ''
    chinese = count_chinese(h1)
    yimu = '壹目贯维' in text
    has_p = '<p' in html
    ok = chinese <= 9 and yimu and has_p
    print(f'{'✅' if ok else '⚠️'} {name}: h1={h1[:20]} {chinese}字 yimu={yimu} p={has_p}')
"
```

---

## 关键文件路径备忘

```
# 微信公众号凭证
/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/config/wechat_secrets.env

# wechat_publisher.py（需修复 Gate 调用）
~/.hermes/skills/wechat-official-account-publisher/wechat_publisher.py

# pre_upload_check.py（强制校验入口）
~/.hermes/skills/wechat-official-account-publisher/scripts/pre_upload_check.py

# Token 缓存（40001 时覆盖）
~/.hermes/skills/wechat-official-account-publisher/.token_cache.json
```

---

## 经验总结

1. **并行 agent 项目的内容验证必须在上传前做**，不能只靠"文件在正确的目录里"就假设内容正确
2. **HTML 排版损坏有四种形态**，处理方式不同（Markdown直接转 vs CSS清理 vs 裸文字pandoc重生成）
3. **Gate 机制写在 skill 里不够**，必须代码强制串联，`wechat_publisher.py` 需要在上传前调用 gate 检查
4. **blockquotes 不能只检查有没有**，还要验证内容不是正文重复（闻泰安世出现3次重复CTA文字）