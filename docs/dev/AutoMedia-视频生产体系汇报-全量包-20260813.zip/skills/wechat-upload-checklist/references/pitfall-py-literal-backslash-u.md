# ⚠️ Python 源文件字面 `\u` 触发 SyntaxError（实测 3 次踩坑）

## ⚠️ Python 源文件字面 `\u` 触发 SyntaxError（实测 3 次踩坑）

写中文注释/docstring/字符串时，**禁止写字面 `\u escape bug` 这种形式**——Python 解析器会把 `\u` 当 unicode escape 开始，期待后面跟 4 位十六进制（`\uXXXX`）。如果不是 4 位 hex（例如 `\u escape` 或 `\u 转义`）就报 `SyntaxError: (unicode error) 'unicodeescape' codec can't decode bytes ... truncated \uXXXX escape`。

**正确写法**：
- 中文语境 → "unicode escape 乱码" / "unicode 转义"（不用 `\u` 字面）
- 英文语境 → `r"\u escape"`（raw string）
- regex 模式 → `r'\\u[0-9a-fA-F]{4}'`（双反斜杠 + raw string）

实测案例：写 `verify_published_content.py` 时 3 次栽在同一坑——L10 docstring、L18 退出码说明、L108 errs.append()、L169 print() 各踩一次。每次都要 `patch` 才能继续。**写新脚本前先扫一遍**：`grep -n '\\\\u[^0-9a-fA-F]' <file>.py` 应返回空。
