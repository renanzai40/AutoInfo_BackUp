# 排版损坏的四种形态与处理（2026-05-26 新增）

### 排版损坏的四种形态与处理（2026-05-26 新增）

> **根因**：生成时写了 Markdown 文件当 HTML 上传，或 CSS 标签混入了 body，或裸文字无任何 HTML 标签。症状是公众号显示为纯文本、无样式。

**四种损坏形态及处理：**

| 形态 | 特征 | 处理 |
|---|---|---|
| Markdown 当 HTML | 文件含 `# ` `## ` 等原始 Markdown 标题 | 用 pandoc 转 HTML：`pandoc -f markdown -t html --wrap=none input.md > output.html` |
| CSS 混入 body | `<style>...</style>` 之后才是正文 | 找到 `</style>` 截止后的内容，提取纯文本再转 HTML |
| 裸文字无结构 | 只有 `<h1>` + 裸行，无 `<p>/<h2>/<blockquote>` | 提取纯文本，按段落用 pandoc 转 HTML，加 blockquote 样式 |
| body 前有 CSS 变量 | `body { font-family: ... }` 在 h1 之前混入 | 截取 `</style>` 之后内容，处理方式同上 |

**处理后必须验证**：输出文件含 `<h2>` 或 `<blockquote>`（至少一种）+ `<p>` 段落，否则重新检查。

**判定规则：**
- h1 提取失败（无 h1 或为空）→ FAIL，不上传
- h1 与 project_info.topic 核心词匹配度 < 50% → FAIL，不上传，文件放错项目了
- 通过 → 继续后续 Gate 检查

**注意**：这步验证的是"文件内容是否在正确的项目里"，与 copy-review 的内容质量检查独立。先过这关，再走 G1/G2/G3/G4。
