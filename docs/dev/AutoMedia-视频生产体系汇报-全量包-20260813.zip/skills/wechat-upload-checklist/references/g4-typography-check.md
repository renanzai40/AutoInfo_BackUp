# 公众号排版检查（G4）

### 公众号排版检查（G4）

公众号 HTML 需要包含基本样式，不能是纯裸文字：

- `<blockquote>` 样式（引用块）
- `<h2>/<h3>` 分级标题
- 数字/强调内容的 highlight 样式
- 段落 `<p>` 包装，不是裸文字行

**排版质量 Gate（G4）独立于 copy-review**：copy-review 审文字内容（叙事逻辑、术语一致性），G4 审 HTML 结构（排版样式）。两者都通过才能上传。

闻泰安世项目 `wechat/wechat_draft.html`（3,790 bytes）只有裸 `<h1>` + `<p>` 裸文字，copy-review 文字内容通过了，但 G4 未做。上传后公众号显示为"没有排版"的裸文字文章。
