# 🔥 9 个草稿批量乱码事故 + 修复（2026-06-03 落地）

### 🔥 9 个草稿批量乱码事故 + 修复（2026-06-03 落地）

**完整复现 + 修复脚本 + 9 个 content_id 列表**：`references/requests-escape-bug-2026-06-03.md`

**修复 9 个项目**（29.68s 跑完）：
- 0424_rare-earth-leak / 0424_ai-translation / 0507_ai-career-10jobs / 0508_ai-career-replacement / 0508_ai-domestic / 0513_ai-model-usage / 0513_trump-china-visit / 0526_deepseek / 0526_lorai-marketing
- 删旧 9 个 content_id（`draft/delete` API errcode=0）
- 重传 9 个新（用 skill 自带 `upload_draft.py`，**已 ensure_ascii=False**）
- publish_log.json **双记录**（v1=deleted, v2=active）
- 备份位置：`/tmp/wechat_fix_backup_20260603_130304/`

**3 个新落地 hook**（写进本 skill 工具链）：
- `automedia/hooks/verify_published_content.py`（post-verification，9/9 active 全 OK）
- `automedia/hooks/test_upload_draft_ensure_ascii.py`（unit test，6/6 检查全过）
- `automedia/hooks/safe_upload_wechat.py`（4 步硬门控唯一入口）

**未来 PR 改坏 `ensure_ascii=False` 立即 fail**（unit test 守住）；agent 想绕 skill → safe_upload 唯一入口。
