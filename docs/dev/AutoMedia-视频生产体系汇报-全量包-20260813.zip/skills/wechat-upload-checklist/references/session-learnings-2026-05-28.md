# WeChat Upload Session Learnings — 2026-05-28

## 项目：20260528_104457_dual-topics（TrapDoor 引流款 + Runway 业务款）

### 失败事件：上传草稿失败

**症状**：`get_token.py` 返回 `40164`（IP 不在白名单）

**根因**：WSL 出口 IP `112.41.58.21` 未加入微信公众号后台白名单

**处理**：用户需在微信公众平台 → 设置与开发 → 基本配置 → IP白名单，手动添加 `112.41.58.21`

### 并发问题：Gate 记录不存在

两个项目的 `04_review/review_log.json` 均不存在——说明生产链路跳过了 review step 直接到了 Remotion 渲染。

**教训**：review step 不能因为"内容已经是新生产的"就跳过。Gate 必须在上传说为之前完成。

**正确流程**：
```
内容生成 → copy-review → brand-cta → humanizer → review_log.json → 上传
```

### credential 路径修正

| 说法 | 正确路径 |
|------|---------|
| ❌ `get_token.py` 读 `~/.hermes/skills/wechat-official-account-publisher/config.json` | 已修正 |
| ✅ `get_token.py` 读 `wechat_secrets.env` | `/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/config/wechat_secrets.env` |

---

## 技术细节

### 40164 vs 40001 辨别

| 错误码 | 含义 | 鉴别方法 |
|--------|------|---------|
| 40001 | access_token 无效/过期 | JSON 返回 `{"errcode": 40001, ...}` |
| 40164 | IP 不在白名单 | JSON 返回 `{"errcode": 40164, "errmsg": "invalid ip X.X.X.X ... not in whitelist"}` |

两者都会导致 API 调用失败，但处理方式完全不同。

### 当前 WSL 出口 IP

```
112.41.58.21
```

如需重新查询：`curl -s ifconfig.me` 或 `curl -s api.ipify.org`
