# WeChat Upload Session Learnings — 2026-06-02

## 项目：20260601_201455_minimax-m3（m3 视频 A/V 同步修复后重传）

### 场景

用户报告 minimax-m3 视频"音画同步效果较差"（钩子→痛点过渡段 16-24s 字幕超前音频 4-5s）。原计划"算验收"（user_accepted_as_is_2026-06-02），但用户最终决定重开修复，原因是反模式 100% 复现 + 想给未来视频打底。

### 修复流程（视频侧）

1. 备份 v1 视频：`cp out/minimax-m3.mp4 out/minimax-m3_v1_known_audio_desync.mp4`
2. 重写 M3Composition.tsx：5 段帧边界 + 14 条 SCENE_SUBTITLES 全部按 SRT 真实时间戳重算（S1=0-425, S2=425-712, S3=712-1606, S4=1606-1969, S5=1969-2194 @ 30fps）
3. 重渲染：`bunx remotion render MiniMaxM3 out/minimax-m3.mp4 --concurrency=2`
4. 抽 10 帧 vision OCR QA（覆盖 5 段中点 + 5 段边界）→ 10/10 PASS
5. v2 视频 17.0MB，73.17s，1080×1920

### 重传草稿流程（公众号侧）

**关键发现**：公众号文章 body HTML **不含视频 URL**（用 thumb_media_id 在 feed 流里表现视频）。所以换视频 = 换封面 + 重传草稿，body HTML 100% 复用。

**完整操作**：

1. **备份 body HTML**（防 pre_upload_check.py 写入时改坏）：
   ```bash
   cp _body.html _body.html.v1_backup_1780369032
   ```

2. **删旧草稿**（API 调用）：
   ```python
   POST https://api.weixin.qq.com/cgi-bin/draft/delete?access_token={token}
   body: {"media_id": "eYCpieqt-pkzK-tHTzKDMj__ik_u0mEISZq9gekXiD82eNEdFmX8RkqHw7s6GSGN"}
   → {"errcode": 0, "errmsg": "ok"}  ✓
   ```

3. **重新上传新封面图**（v2 视频 0.5s 帧抽出来）：
   ```bash
   ffmpeg -y -ss 0.5 -i out/minimax-m3.mp4 -frames:v 1 -q:v 2 /tmp/cover_9x16.jpg
   python3 upload_thumb.py /tmp/cover_9x16.jpg
   → thumb_media_id: eYCpieqt-pkzK-tHTzKDMkYlEfYZYiTEy1wDrjY459zx8Otsp9IaN0dBWKVKMVgi
   ```

4. **重新传草稿**（同一份 body HTML）：
   ```bash
   python3 upload_draft.py \
     --title "M3内容工具升级" \
     --html "_body.html" \
     --thumb-media-id "$NEW_THUMB" \
     --digest "M3三大升级+1关键前提"
   → 新 content_id: eYCpieqt-pkzK-tHTzKDMhLcKrCvd5M3XN6vexYwqkD2tg6tOowJIGaxxPxm6ugz
   ```

5. **publish_log.json 双记录结构**：
   ```json
   {
     "v1_drafts": [{"status": "deleted", "content_id": "旧", "deleted_at": "...", "delete_response": "errcode=0", "reason_for_delete": "..."}],
     "v2_drafts": [{"status": "active", "content_id": "新", "uploaded_at": "...", "thumb_media_id": "新", "cover_image": "...", "video_attached": "v2 (fixed)"}],
     "video_av_sync_resolution": {...完整修复记录...}
   }
   ```

### 经验教训

| 教训 | 重要程度 |
|------|---------|
| 公众号视频不入 body HTML，feed 流用 thumb_media_id 表现 | ★★★（避免改 body 的无用工作） |
| 草稿 API 非幂等，add 前必先 delete | ★★★（铁律） |
| publish_log.json 必须保留 v1 完整追溯链 | ★★★（v1 是诊断+重开依据） |
| pre_upload_check.py 改文件 → 删草稿前备份 | ★★ |
| pre_upload_check.py 已含 title/digest/HTML 字符数校验 | ★★（不再需要手动重核） |

### 同期发生的工具 quirks（2026-06-02 沉淀）

- **vision_analyze** 在 content profile 当前 session 看不到图片（一直返回"对话中没有图片"），必须用 **mcp_minimax_understand_image** 替代
- **write_file** 检测到 sibling subagent 改过同文件时只警告不阻塞，read 确认后写入即可（无数据丢失）
- 已记入 memory tool quirks 段

### publish_log.json 已知缺陷的可重开性

m3 案例证明了"已知缺陷可重开"工作流的价值：

```
1. 初次 QA 发现缺陷
2. 用户说"算验收" → status=user_accepted_as_is_<date>
3. 后续反查缺陷详情 → publish_log.known_issues 含完整 root cause
4. 用户决定重开 → 修代码 + 重渲染 + 重传草稿
5. status 改 FIXED_<date> + resolution 完整记录
6. publish_log.json 是缺陷生命周期，user_accepted ↔ FIXED 可逆
```

**关键点**：第 2 步即使算验收，仍必须**完整记录 root cause**（不只是说"不修复"），否则第 3 步反查时无信息可参考。
