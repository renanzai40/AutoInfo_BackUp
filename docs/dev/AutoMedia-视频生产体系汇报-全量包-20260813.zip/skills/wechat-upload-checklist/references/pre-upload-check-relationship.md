# 与 pre_upload_check.py 的关系（2026-05-16 更新）

## 与 pre_upload_check.py 的关系（2026-05-16 更新）

**本 checklist 现在是教育/复核参考，不再是强制 gate。**
### 🔥 Pitfall 13 (2026-06-05 实测，永久生效): "wechat_draft.html 扩展名陷阱"——内容是 Markdown 但被当 HTML 上传

> **症状**：公众号草稿箱打开后看到 `# OpenAI Codex` / `## 一、Codex 团队插件` / `> 工具再强` / `- 以前` / `**共享 prompt 库**` 全部按字面显示成乱码（`#` / `##` / `>` / `-` / `**` 都不是 HTML 标签，公众号当字面字符渲染）。
>
> **根因（双重）**：
> 1. **agent 写文件时偷懒**：用 `write_file` 写 `.html` 扩展名但内容用 Markdown 语法（`# ` / `## ` / `>` / `-` / `**`），**实际是 .md 文件但扩展名是 .html**。公众号 API `content` 字段期望 HTML body，**收到 Markdown 字符串后按 HTML 解析失败，全部按字面字符显示**。
> 2. **G4_format 审核走过场**：当时写的 `wechat_upload_checklist_report.md` 标"✅ PASS"——**但 `grep -c "<p>\|<h2>\|<blockquote>"` 实际返回 0**。审核只看字数（2100 字 ≥ 1500 目标）不查 HTML 结构。
>
> **真实事故**（2026-06-05 22:58）：
> - 项目：`20260605_114900_openai-codex-team`
> - HTML 草稿：122 行，**0 个 `<p>` / `<h2>` / `<blockquote>` 标签**（全是 `# ## > - **` Markdown 语法）
> - 公众号 API content 字段收到 raw MD 字符串
> - 公众号按 HTML 解析：`# OpenAI Codex` 当字面字符（不是 `<h1>`）；`## 一、Codex 团队插件` 当字面字符（不是 `<h2>`）；`**共享 prompt 库**` 当字面字符（不是 `<strong>`）
> - **结果**：公众号草稿箱显示成 "排版乱掉" 的纯文本
>
> **修复方案**（5 选 1，按推荐度）：
> 1. ✅ **重写为 HTML**：用 `pandoc` 转 + 手写 `<p>/<h2>/<blockquote>` 样式
> 2. ✅ **`scripts/md_to_html.py`**：自动化 Markdown → HTML body 转换
> 3. ⚠️ **公众号编辑器手动粘贴**：失去 publish_log 双记录追溯链
> 4. ⚠️ **删除已上传草稿 + 重传**：1 小时但干净
> 5. ❌ **接受乱掉**：公众号草稿箱垃圾
>
> **预防（hard gate，6-05 加 G5）**：
> - `safe_upload_wechat.py` Step 1 加 HTML 标签存在性检查：`grep -c "<p>\|<h2>\|<blockquote>" wechat_draft.html` **必 ≥ 5** 才允许上传
> - G4_format 审核硬要求：`grep -c "<p>\|<h2>\|<blockquote>" wechat_draft.html` **必 ≥ 5** 才标 PASS
> - **扩展名陷阱检测**：写完后 `head -5 wechat_draft.html` 必查，**如果前 5 行含 `#` 或 `##` 开头 → 自动拒绝（标记为 Markdown，需转换）**
>
> 完整复盘 + 预防代码：见 `wechat-incident-reports/wechat-upload-checklist-2026-06-05-incident`

### 🔥 Pitfall 14 (2026-06-05 实测): `safe_upload_wechat.py` Step 4 notes TypeError bug

> **症状**：hook Step 1-3 都过（pre_upload_check / self_check / upload 都 OK），但 Step 4 报 `TypeError: can only concatenate list (not "str") to list`。
>
> **根因**：`safe_upload_wechat.py` L155 写的是 `data["notes"] = (notes + "\n" + note).strip() if notes else note`——**假设 `notes` 是字符串**。但本项目 publish_log.json `notes` 字段是 list（4 项字符串列表），`list + str` 报错。
>
> **修复**（已 patch 进 hook）：
> ```python
> notes = data.get("notes", [])
> if isinstance(notes, str):
>     notes = [notes] if notes else []
> notes = list(notes) + [note]
> data["notes"] = notes
> ```
>
> **教训**：**写任何处理外部数据的 hook 都必做 type check**（isinstance str / list / dict 分别处理）。**publish_log.notes 字段 schema 不统一**（历史项目有时 str，有时 list）——hook 必兼容。
>
> **⚠️ 副作用（重要）**：Step 4 报 TypeError 之前 Step 3 已经**真实上传到公众号**！所以**草稿可能已上传**但 `publish_log.json` 双记录（v1_drafts / v2_drafts）没写——**后续需要查公众号草稿箱手动补 content_id**。下次 hook 设计：**Step 4 fail 也应该 commit Step 3 的 content_id 到 publish_log**（防止追溯链丢失）。

### 公众号排版检查（G4 + G5 双门控，2026-06-05 升级）

公众号 HTML 需要包含基本样式，不能是纯裸文字：

- `<blockquote>` 样式（引用块）
- `<h2>/<h3>` 分级标题
- 数字/强调内容的 highlight 样式
- 段落 `<p>` 包装，不是裸文字行

**排版质量 Gate（G4）独立于 copy-review**：copy-review 审文字内容（叙事逻辑、术语一致性），G4 审 HTML 结构（排版样式）。两者都通过才能上传。

**⚠️ 6-05 实测：G4 走过场必被反噬**。原 G4 检查只查"是否有 `<h2>` / `<blockquote>`" 但**没强制数量**——6-05 openai 草稿 0 个 HTML 标签全靠 Markdown 渲染，G4 报告仍写"✅ PASS"。

**修正（6-05 加 G5 硬门控，6-10 实测补强）**：
- 必查 `grep -c "<p>\|<h2>\|<blockquote>" wechat_draft.html` **≥ 5** 才标 G4 PASS
- 必查 `head -5` 是否有 `# ` 或 `## ` 开头（Markdown 语法触发器）——**有就 G5 FAIL**
- 必查 `<!DOCTYPE html>` / `<html>` / `<head>` 是否被错误包含（必须只 `<body>` 内部内容）
- 必查 `grep -c "<strong>" wechat_draft.html` **≥ 2** 才允许上传（6-10 实测补强，pre_upload_check 内置检查）
- **预防**：写 HTML 时在关键数据/结论处加 `<strong>...</strong>` 强调（如「AI工厂的能耗是传统数据中心的5-10倍」），既提升可读性又满足 gate

**2026-06-10 实测案例**：引流款 NVIDIAxDOOSAN 的 wechat_draft.html 有 24 个 `<p>/<h2>/<blockquote>` 标签（G4 过），但包含 0 个 `<strong>` 标签 → G5 被 `upload_draft.py` pre-flight check 拦截，拒绝上传。修复：在关键数据（「物理AI」「AI工厂能耗是传统数据中心5-10倍」）处加 2 个 `<strong>` 标签后上传成功。

闻泰安世项目 `wechat/wechat_draft.html`（3,790 bytes）只有裸 `<h1>` + `<p>` 裸文字，copy-review 文字内容通过了，但 G4 未做。上传后公众号显示为"没有排版"的裸文字文章。

**2026-06-09 新增规则（用户纠正）**：公众号上传的触发时机是「文案 Track G1-G3 全部通过 + 封面图就绪」，不是「视频渲染完成后」。两条 Track（文案/视频）并行推进，谁先到终点谁先触发。等待用户问"公众号草稿上传了吗"才去上传 = workflow 缺陷。
