# WeChat 上传 pad_wordcount 工具坑 2026-06-07 实测

> 配套 Pitfall 15 实战案例。生成这份 reference 的目的：下次 `pad_wordcount` 工具跑前必查。

## 6-07 案例快速索引

**问题文件**：`projects/20260607_dual-topics/gemini-enterprise-agentic-rag/01_content/drafts/wechat/wechat_draft.html`

**症状**：
- 文件 line 49：`<h2>出海企业的本地化内容怎么接？</h2>` + 段
- line 50：空白
- line 51：`<p>（本文为第三方观察稿件，壹目贯维与 Google 无任何关联。）</p>`
- line 52：空白
- line 53：**`</body>`**
- line 54：**`</html>`**
- line 55-69：**3 个 H2 + 3 个 P 段**（被 rstrip() + "\n" + extra_content 追加在 `</body></html>` 之后）

**公众号渲染**：
- 浏览器/公众号按 HTML 解析 → `<body>` 内部到 `</body>` 为止
- line 55-69 全部被丢弃 = 3 段分析/CTA 消失
- 主 agent verify 脚本 `wc -l` 显示 84 行，<p>+<h2>+<blockquote> 标签数量 43+12+3 = 58 个（全部 ≥5 通过 G5）
- **G5 硬门控不检查 `</body></html>` 位置**——只检查标签数量，导致 HTML 结构破坏完全漏检

## 6-07 M3 修复

按 Pitfall 15 方案 1（regex 移到 `</body>` 之前）：

```python
import re
content = re.sub(
    r'(</body>\s*</html>)',
    extra_content + '\n\n' + r'\1',
    content, count=1, flags=re.IGNORECASE
)
```

**M3 修复结果**：
- 原文件无 `</body></html>`（subagent 写的 MD 风格 HTML 缺闭合）→ rstrip() + "\n" + extra_content 安全
- 修复后 `<p>=19 <h2>=9 <blockquote>=2` 全部在 body 内
- safe_upload_wechat.py 4 步全过

## 预防脚本（6-07 加 G6 硬门控）

```python
# 写完 wechat_draft.html 必跑
import re
f = "wechat_draft.html"
c = open(f, encoding='utf-8').read()
body_end = c.lower().find("</body>")
html_end = c.lower().find("</html>")
after = c[html_end:] if html_end != -1 else ""
has_content_after = bool(after.strip().rstrip("</html>").strip())
if has_content_after:
    print(f"❌ </body></html> 后仍有内容")
    exit(1)
print(f"✅ HTML 结构完整")
```

**触发条件**：所有 `pad_wordcount.py` / `fix_brand_cta_v3.py` / 任何"追加内容到 HTML 文件"的工具运行后必跑。

## 历史教训

- **6-02 G5 HTML 标签 ≥5 + 无 Markdown 触发器**——只检查数量不检查位置
- **6-07 Pitfall 15**——补上"位置"维度
- **6-07 Pitfall 16**——补上 digest 字符数计算方式

3 步加起来才是完整的 G4/G5/G6 排版门控。
