# 🔥 Pitfall 12 (Meta): 写"修复 \u escape bug"脚本时**不要在源代码里再写 \u 转义字符串**

## 🔥 Pitfall 12 (Meta): 写"修复 \u escape bug"脚本时**不要在源代码里再写 \u 转义字符串**

> 2026-06-03 自摆乌龙：写 fix 脚本时描述 `"uploading used requests.post(json=...) -> \u escape bug"`，Python 解释器把 `\u escape` 当 Unicode escape 解析 → `SyntaxError: (unicode error) 'unicodeescape' codec can't decode bytes in position 76-77: truncated \uXXXX escape`。脚本根本跑不起来。

### ❌ 禁用写法
```python
"delete_reason": "uploading used ... \u escape bug"   # SyntaxError
note = f"[fix] ... \u 转义 bug"                        # SyntaxError
```

### ✅ 正确写法（3 选 1）
```python
# 方案 1：raw string（r 前缀）—— 最稳
r"delete_reason: uploading used ... \u escape bug"

# 方案 2：双反斜杠
"delete_reason: uploading used ... \\u escape bug"

# 方案 3：描述时不用字面 \u
"delete_reason: uploading used ... unicode-escape bug"  # 首选，零风险
```

### 预防
- 写任何"修复 \u 转义类 bug"的脚本/字符串时，**描述里避免写 \u 字面量**
- 改用 ASCII 描述（"unicode-escape bug" / "non-ASCII escape" / "ensure_ascii=False needed"）
- 或者用 raw string `r"..."` 强制不解释
- lint check：写完 `python3 -c "import ast; ast.parse(open('fix.py').read())"` 必须通过
