# 典型上传案例（2026-05-26 实测）

## 典型上传案例（2026-05-26 实测）

### 案例1：618生图神器推荐（业务款，标题9字，摘要10字）

- 标题：`618生图神器推荐`（9字）→ 成功
- 摘要原始：`618大促内容产能告急？四款AI生图生视频神器横评，帮你选对搭档`（32字）→ 报错 45004
- 摘要修正后：`四款AI生图神器横评`（10字）→ 成功
- 上传命令：
  ```bash
  python3 scripts/upload_thumb.py 封面图路径  # → thumb_media_id
  python3 scripts/upload_draft.py \
    --title "618生图神器推荐" \
    --html 项目/01_content/drafts/wechat/wechat_draft.html \
    --thumb-media-id "$THUMB_MEDIA_ID" \
    --digest "四款AI生图神器横评"
  ```

### 案例2：闻泰安世对簿公堂（引流款，标题8字，摘要12字）

- 标题：`闻泰安世对簿公堂`（8字）→ 成功
- 摘要：`闻泰索赔80亿反击接管战`（12字）→ 成功
- 注意：摘要含 `！` 感叹号仍可通

---

### 🔥 Pitfall 15: `pad_wordcount` / 任何 `rstrip() + "\n" + content` 追加方式会破坏 HTML 结构（2026-06-07 实测）

> **症状**：公众号草稿箱看到正文到 `</body></html>` 之前是干净的，但**后面又出现一坨 H2 + P 内容**。渲染时浏览器/公众号把 `</body></html>` 后的内容直接丢弃 = 公众号看到的是截短的版本。

**根因**：subagent 生成 HTML 时用 Python 模板写完整文档（`<!DOCTYPE html><html>...<body>...</body></html>`）。主 agent 用脚本批量补字数/补品牌 CTA 时，常用模式：
```python
new_content = content.rstrip() + "\n" + extra_content
```
—— `rstrip()` 不识别 `</body></html>`，结果 `extra_content` 被追加到 `</html>` 之后，HTML 结构破坏。

**实测 6-07 案例**：
- Gemini 公众号 HTML：原始 51 行（line 49 `<h2>` × 4 + line 50 `</body>` + line 51 `</html>`）
- pad_wordcount.py 追加 3 个 H2 + 3 个 P（line 52-67 全部出现在 `</body></html>` 之后）
- `safe_upload_wechat.py` Step 1 pre_upload_check 的 HTML 标签数量检查 `<p>=43 <h2>=12 <blockquote>=3` 全部通过 ≥5（G5 不检查 `</body>` 位置）
- 公众号按 HTML 解析：`<body>` 内部到 `</body>` 为止，line 52-67 全部被丢弃 → **3 段 CTA / 分析被截断**！

**修复方案（按推荐度排序）**：

1. ✅ **写到 `</body>` 之前**（不追加 `</body></html>` 之后）
```python
import re
extra_content = "..."  # 要追加的 H2/P 块
content = re.sub(
    r'(</body>\s*</html>)',
    extra_content + '\n\n' + r'\1',
    content, count=1, flags=re.IGNORECASE
)
```

2. ✅ **如果原文件无 `</body></html>` 闭合**（如 Markdown 转出的 HTML），直接 rstrip() + "\n" + extra_content 是安全的

3. ⚠️ **pad_wordcount.py 这种工具**：写时**必须 check** 文件是否已含 `</body></html>` —— 含就改用方案 1；不含就走默认 rstrip 方案

**预防（hard check，6-07 加 G6）**：

```bash
# 写完 wechat_draft.html 必跑
python3 << 'EOF'
import re
f = "wechat_draft.html"
c = open(f, encoding='utf-8').read()
body_end = c.lower().find("</body>")
html_end = c.lower().find("</html>")
after = c[html_end:] if html_end != -1 else ""
has_content_after = bool(after.strip().rstrip("</html>").strip())
if has_content_after:
    print(f"❌ </body></html> 后仍有 {len(after)} 字符内容")
    print(f"   前 100 字: {after[:100]}")
    print(f"   → 必须修复（移到 </body> 之前）")
    exit(1)
print(f"✅ HTML 结构完整，</body></html> 在末尾")
EOF
```

**G6 新增**（与 G4/G5 并列的硬门控）：`safe_upload_wechat.py` Step 1 加 HTML 收尾位置检查，`</body></html>` 后内容 > 0 字节 → 拒绝上传。

详见：`references/session-learnings-2026-06-07.md`（计划在 6-07 复盘时落地）

---

### 🔥 Pitfall 16: digest 字数限制包含中英文 + 数字 + 空格（pre_upload_check 实测计数方式）

> **症状**：`safe_upload_wechat.py` Step 1 报 `摘要超限：23 字（上限 20 字）`，但 agent 觉得"明明只有 15 个中文字 + 8 个英文字符"。

**根因**：`pre_upload_check.py` 计数 = **所有非空字符**（含中文 / 英文 / 数字 / 空格 / 中文标点 / 全角符号）。M3 案例：
- `"国产大模型 MiniMax M3 集齐三项能力"` = 5(国产大模型) + 1(空格) + 6(MiniMax) + 1(空格) + 2(M3) + 1(空格) + 6(集齐三项能力) = **22 字符** → 报超限

**实测通过**（≤ 20 字符）：
- `"国产大模型 M3 三件套集齐"` = 5 + 1 + 1 + 2 + 1 + 6 = **16 字符** ✅
- `"AI Agent 自己决定何时检索。"` = 2 + 1 + 5 + 2 + 2 + 1 + 2 + 1 = **16 字符** ✅

**核心规则**：
- 中文/英文/数字 = 1 字符
- 空格 = 1 字符（**算**）
- 中文标点（，。） = 1 字符（**算**）
- 末尾标点（句号/感叹号）= 1 字符

**digest 编写 4 步法（保 ≤ 20 字符）**：
1. 先写中文 5-8 字核心信息
2. 加英文/数字 1-2 个（可选）
3. 加结尾 4-6 字补充
4. **必加标点收尾**（句号/感叹号，1 字符）——让结构完整

**实测超过的常见坑**：
- ❌ `"国产大模型 MiniMax M3 集齐三项能力"`（22 字符）→ 超 2
- ❌ `"壹目贯维 AI 内容生产公司·Gemini Enterprise"`（25 字符）→ 超 5
- ✅ `"国产大模型 M3 三件套集齐"`（16 字符）
- ✅ `"AI Agent 自己决定何时检索。"`（16 字符）

**修复方法**：
1. **去掉空格**："国产大模型 M3 集齐三项能力" = 5+1+1+2+1+6+1 = 17 字符
2. **改用 ASCII 分隔符**（更省字符）："国产大模型-M3 集齐" = 5+1+1+2+1+2+1 = 13 字符
3. **缩短英文部分**："M3" 比 "MiniMax" 短 4 字符

**预防**（hard check）：写完 publish_log 必跑
```python
digest = "你的摘要"
# pre_upload_check.py 实际算法
count = len([c for c in digest if c.strip() or c == ' '])
# 注意：空字符（\n \t）不计入，但空格算 1
print(f"digest 实际计数: {count}（上限 20）")
```

---

### 🔥 Pitfall 17: wechat_draft.html 纯文字、零图片（2026-06-12 实测 12/12 篇）

> **症状**：草稿 wechat_draft.html 全是文字，一张图都没有。发布版每篇加了 2-6 张配图。
>
> **根因**：公众号 HTML 模板默认不含图片占位。AI 生成时没有写入配图逻辑。
>
> **影响**：纯文字文章阅读体验差，读者在长段文字中找不到"呼吸点"。
>
> **修复方案**：
> 1. 生成 wechat_draft.html 时，每约 600-800 字插入 1 张图片占位 `<p><img src="__IMAGE_PLACEHOLDER_1__" alt="图片由AI辅助生成" style="width:100%"></p>`
> 2. 图片用 ComfyUI（SD 1.5）生成实际配图后替换占位符（scripts/gen_ui_images.py）
>
> **预防**（hard check，G7 新增）：
> ```bash
> grep -c "<img" wechat_draft.html  # 至少 ≥ 2 张图
> ```

### 🔥 Pitfall 19: `<blockquote>` 插入时搜索 `<h2>` 无法匹配带属性的 `<h2 class=...>`（2026-06-15 实测）

> **症状**：用 `content.find("<h2>")` 搜索插入 `<blockquote>` 返回 -1，blockquote 最终加到文件末尾而非首段之前——pre_upload_check 检查通过但上传后文章开头无导读引用块。

> **根因**：微信 HTML 中 `<h2>` 几乎永远带属性（`<h2 class="section-subtitle">` 或 `<h2 style="...">`），`"<h2>"` 精确搜索匹配不到 `"<h2 "`。Python `str.find("<h2>")` 返回 -1，代码走 fallback 或跳过插入。

**正确做法**：
```python
# 搜索带属性的 h2
idx = content.find("<h2 ")
if idx < 0:
    idx = content.find("<h2>")  # 纯 h2 标签（无属性）
# 如果 h2 全无，搜索 <section 或 <p>
if idx < 0:
    idx = content.find("<section")
if idx < 0:
    idx = content.find("<p id=")
```

**实测**（2026-06-15 Anthropic 项目）：
- HTML 使用 `<h2 class="section-subtitle">`（5 处），`"<h2>"` 搜索返回 -1
- `"<h2 "` 搜索在第 7080 个字符命中，blockquote 正确插入在首段之前
- 上传后 pre_upload_check 检查通过（blockquote=1）✅

**预防**：
- 写 blockquote 插入代码时**永远不会用 `find("<h2>")` 精确匹配**——HTML 中的 h2 几乎总是带属性
- 用 `re.search(r'<h2[\\s>]', content)` 同时匹配 `<h2>` 和 `<h2 ...>` 两种形式
- 如果既无 h2 也无 `<section>`，退回到 `<body>` 后首段位置

### 🔥 Pitfall 18: 品牌密度过高和尾部重复（2026-06-12 实测 10/12 篇）

> **症状**：
> - 品牌名 "壹目贯维" 在正文中出现 7-13 次
> - 尾部 `</body>` 后仍有内容（品牌/CTA 被追加到结构收尾之后）
> - 尾部段落重复 2-3 遍（生成 bug）
>
> **根因**：
> - 品牌密度：prompt 过度强调品牌露出，"壹目贯维"硬性堆砌
> - 尾部重复：`pad_wordcount` 等追加脚本将内容写在 `</body></html>` 之后（Pitfall 15 复发）
>
> **检查方法**：
> ```bash
> # 品牌密度
> BRAND_COUNT=$(grep -c "壹目贯维" wechat_draft.html)
> if [ "$BRAND_COUNT" -gt 5 ]; then echo "❌ 品牌过密 ($BRAND_COUNT 次)"; fi
>
> # 尾部重复（检查 </body> 后是否有内容）
> python3 -c "
> c=open('wechat_draft.html').read()
> i=c.lower().find('</body>')
> after=c[i+7:].strip() if i>0 else ''
> if after: print(f'❌ </body> 后仍有 {len(after)} 字符')
> "
>
> # 尾部品牌重复（检查尾部 200 字中品牌出现次数）
> python3 -c "
> c=open('wechat_draft.html').read()
> tail=c[-500:]
> count=tail.count('壹目贯维')
> if count>1: print(f'❌ 尾部品牌重复 ({count} 次)')
> "
> ```
>
> **预防**：
> - G5 硬门控增加品牌密度检查（正文 ≤ 3 次、尾部 ≤ 1 次）
> - G6 保留 `</body>` 后内容检查（Pitfall 15 规则不变）
> - 新增 G7：尾部品牌重复检查

---

### 🔥 Pitfall 11: `requests.post(json=payload)` 默认 `ensure_ascii=True` —— 中文被转义成 `\u`（2026-06-03 实测 9 草稿批量翻车）

> **这是本 skill 历史上最严重的可预防事故**。下面整章是 hard gate，**任何 `requests.post(..., json=...)` 写法直接拒绝 review**。

### 症状
HTML / markdown 源文件是干净中文（`grep -c '\\u[0-9a-f]\{4\}'` 返回 0），但公众号草稿箱显示成：
```
\u51fa\u54c1\uff1a\u58f9\u76ee\u8d2f\u7ef4 | 2026-05-08
\u6bcf\u6bcf\u79d1\u6280\u9769\u547d\uff0c\u90fd\u4f1a\u5f15\u53d1\u804c\u4e1a\u7126\u8651\u3002
```
每个汉字被 Python `json.dumps` 默认行为转义成 4 位 hex 形式。

### 根因
`requests` 库的 `json=` 参数**内部调用 `json.dumps(payload, ensure_ascii=True)`**（**requests 默认值**），把所有非 ASCII 字符 escape 成 `\uXXXX` 形式。

等价关系：
```python
# 这两行 100% 等价（都触发 bug）
requests.post(url, json=payload)
requests.post(url, data=json.dumps(payload, ensure_ascii=True).encode("utf-8"))
```

### ❌ 禁用写法（任何 `requests.post(..., json=...)` 形式）
```python
import requests
resp = requests.post(url, json=payload)                     # ❌ 默认 escape
resp = requests.post(url, json=payload, headers={...})        # ❌ 同样
resp = requests.post(url, json=payload, timeout=30)          # ❌ 同样
```

### ✅ 正确写法（3 选 1）
```python
# 方案 1（最推荐）：用本 skill 自带的 upload_draft.py —— 已 ensure_ascii=False
import subprocess
from pathlib import Path
SKILL = Path("/home/renanzai/.hermes/profiles/content/skills/wechat-official-account-publisher")
result = subprocess.run(
    ["python3", str(SKILL / "scripts" / "upload_draft.py"),
     "--title", title, "--html", str(html_path),
     "--thumb-media-id", thumb_id, "--digest", digest, "--author", ""],
    capture_output=True, text=True, timeout=60
)
new_cid = result.stdout.strip()  # 返回新 content_id

# 方案 2：urllib + 显式 ensure_ascii=False
import urllib.request, json
data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
req = urllib.request.Request(url, data=data,
                              headers={"Content-Type": "application/json; charset=utf-8"},
                              method="POST")
urllib.request.urlopen(req)

# 方案 3：requests + 显式 data= + ensure_ascii=False
import requests, json
data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
resp = requests.post(url, data=data,
                     headers={"Content-Type": "application/json; charset=utf-8"})
```

### 检测（写完脚本必跑）
```python
# 跑前 sanity check：payload 序列化为 bytes 后不应含字面 \u
import json
test = json.dumps({"t": "测试中文"}).encode("utf-8")
assert b"\\u" not in test, "BUG: payload 仍含 \\u escape，请改 ensure_ascii=False"
print("✅ payload 干净")
```

### 真实事故（2026-06-03，9 个草稿全坏）
- **触发者**：main-agent-2026-06-02，session `20260602_103946_4ae413` 的 message 2674 execute_code
- **影响**：9 个项目（rare-earth-leak / ai-translation-multiagent / ai-career-10jobs / ai-career-replacement / ai-domestic-breakthrough / ai-model-usage / trump-china-visit / deepseek-75-discount / lorai-marketing）全部草稿显示成 \u 转义乱码
- **修复**：删除 9 旧 content_id + 用 skill 自带 upload_draft.py 重传 9 个 + 双记录 publish_log.json（v1=deleted, v2=active）
- **耗时**：29.68s / 9 个（每个 2-3s）
- **修复脚本模板**：`scripts/fix_requests_json_escape.py`
- **备份位置**：`/tmp/wechat_fix_backup_<ts>/`
- **根因 session 追溯**：`session_search(query="AI时代职业安全 wechat draft 上传", sort=newest)` → session `20260602_103946_4ae413`

### 预防 checklist（写新上传脚本 / review 老脚本时）
- [ ] `grep -rn "requests.post.*json="` —— 任何匹配必须改 `data=json.dumps(..., ensure_ascii=False)`
- [ ] `grep -rn "json.dumps(payload)"` —— 必须改成 `json.dumps(payload, ensure_ascii=False)`
- [ ] 跑前用上面"检测"块的 assert 验证
- [ ] 上传后立即 `import json; print(json.dumps({"test": new_content_id}))` 确认 media_id 是真 ASCII（不应含 \u）

详见：`references/requests-escape-bug-2026-06-03.md`（完整复现 + 修复脚本 + 9 个 content_id 列表）

---
