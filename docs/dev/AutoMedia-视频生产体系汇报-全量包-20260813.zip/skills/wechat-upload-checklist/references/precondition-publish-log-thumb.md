# ⚠️ Pre-condition：`publish_log.json` 必含 `platforms.wechat.thumb_media_id`（2026-06-06 实战踩坑）

## ⚠️ Pre-condition：`publish_log.json` 必含 `platforms.wechat.thumb_media_id`（2026-06-06 实战踩坑）

> **症状**：跑 `safe_upload_wechat.py --project-dir <dir> --voice-id male-qn-qingse` 报：
> ```
> [V4 GATE OK] voice_id `male-qn-qingse` 在 APPROVED_VOICES
> [FAIL] publish_log.wechat 字段不全: title=True digest=True thumb=False
> ```
> 脚本 Step 1 fail 不上传。

> **根因**：`safe_upload_wechat.py` Step 1 读 `publish_log.platforms.wechat.thumb_media_id` 字段。如果缺，整个 Step 1 拒绝上传。**`safe_upload_wechat.py` 不会自动生成 cover**（必须 agent 先调 `upload_thumb.py` 拿 `media_id` 再填回 `publish_log`）。

### Pre-condition 必过 4 步（首次上传流程）

```
1. 写 publish_log.json v2.1 schema（详见 publish-log-schema skill）
2. 上传 cover 图拿 thumb_media_id
   python3 scripts/upload_thumb.py <cover_path>
   → 输出 thumb_media_id（stdout 单独一行）
3. 把 thumb_media_id 写回 publish_log.json
   platforms.wechat.thumb_media_id = "<返回的 id>"
   platforms.wechat.cover_path = "02_images/cover/cover_16x9.png"  // 相对路径记录
4. 跑 safe_upload_wechat.py
   python3 ~/.hermes/profiles/content/skills/productivity/automedia/hooks/safe_upload_wechat.py \
       --project-dir <project_dir> --voice-id male-qn-qingse
   → 4 步硬门控：pre_check / self_check / upload / update_log
   → 成功后 publish_log.json 标 status: "draft_uploaded" + 新 content_id
```

### Cover 图规格（必读，2026-06-06 实测）

| 用途 | 比例 | 推荐尺寸 | 适用 |
|------|------|----------|------|
| **thumb_media_id**（公众号列表封面） | **16:9** | **1280×720** | ✅ 唯一规格（首选） |
| 内文配图 | 4:3 | 800×600 起 | 公众号文章内嵌图（ComfyUI SD 1.5 生成） |
| 知乎/B站封面 | 16:9 | 1280×720 | 跨平台共用 |
| 抖音/小红书封面 | 9:16 / 3:4 | 1080×1920 / 864×1152 | 短视频/小红书 |

**thumb 必须 16:9 横版**（不是 3:4 竖版！）—— 微信公众号 thumb 显示在 feed 流和草稿箱是横版拉伸。3:4 竖版上传后会被微信自动裁剪，丢失关键文字。

**Prompt 模板**（生成 16:9 横版 thumb）：
```
Minimalist dark background, large bold Chinese text '<title>',
modern tech style, 16:9 horizontal aspect ratio
```

**验证尺寸**（上传前 PIL 检查）：
```python
from PIL import Image
img = Image.open('<cover_path>')
w, h = img.size
assert abs(w/h - 16/9) < 0.02, f"封面比例 {w}:{h} ({w/h:.2f}) 应为 16:9 ({16/9:.2f})"
print(f"✅ {w}x{h} 比例合规")
```

**ComfyUI SD 1.5 实测**（2026-06-25 切换，旧方案 MiniMax image-01 已停用）：
- `aspect_ratio="16:9"` → 生成 1280×720 (横版) ✅
- `aspect_ratio="3:4"` → 生成 864×1152 (竖版) —— **不要用于 thumb**

**反模式**：
- ❌ 用 3:4 竖版作 thumb → 微信裁剪后只看到中间一小条
- ❌ 用 9:16 竖版作 thumb → 微信强制旋转
- ❌ 不用 16:9 → 平台按默认 1:1 裁切，文字被切掉

### Pre-condition 必过 4 项 + Step 0 命名规范

```python
import json
from pathlib import Path

proj_dir = Path("<project_dir>")
log = json.load(open(proj_dir / "05_publish" / "publish_log.json"))

wechat = log.get("platforms", {}).get("wechat", {})
required = {
    "title": wechat.get("title", ""),
    "digest": wechat.get("digest", ""),
    "thumb_media_id": wechat.get("thumb_media_id", ""),
}
missing = [k for k, v in required.items() if not v]
if missing:
    raise Exception(
        f"❌ publish_log.wechat 缺字段: {missing}\n"
        f"   先调 upload_thumb.py 拿 thumb_media_id，再填到 publish_log.json"
    )
print(f"✅ Pre-condition 4 步全过 (title={len(required['title'])}字, digest={len(required['digest'])}字, thumb={required['thumb_media_id'][:20]}...)")
```

**实际 6-06 案例**：2 个新项目首次跑上传时都因缺 thumb_media_id 失败 → 修复后 4 步全过 → 2 个草稿成功上传。
