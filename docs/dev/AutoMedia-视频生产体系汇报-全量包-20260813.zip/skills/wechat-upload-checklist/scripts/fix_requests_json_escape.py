#!/usr/bin/env python3
"""
微信公众号乱码草稿修复脚本（requests.post(json=...) escape bug）

触发场景：
- 公众号草稿显示成 \\u51fa\\u54c1\\uff1a... 形式
- HTML/markdown 源文件本身是干净中文（grep 不到 \\u）
- 根因是上传代码用了 requests.post(json=payload) —— requests 默认 ensure_ascii=True

本脚本提供：
1. 备份 publish_log.json + HTML 到 /tmp/wechat_fix_backup_<ts>/
2. 删旧 content_id（POST draft/delete）
3. 用 skill 自带 upload_draft.py 重传（ensure_ascii=False）
4. 更新 publish_log.json 双记录（v1=deleted, v2=active）

Usage:
  1. 编辑下方 PROJECTS 列表（填入 9 个乱码项目的 (proj_id, old_cid, title, digest, thumb_id)）
  2. python3 scripts/fix_requests_json_escape.py
  3. 公众号草稿箱验证

关键防坑（详见 SKILL.md Pitfall 12）：
  - 本脚本内所有字符串都避免字面 \\u 转义（用 ASCII "unicode-escape" 描述）
  - 上传用 subprocess 调 skill 自带 upload_draft.py（不直接 requests.post）
"""
import json
import shutil
import subprocess
import sys
import urllib.request
import urllib.parse
from datetime import datetime
from pathlib import Path

# === 配置：填入你项目里 9 个乱码项目的信息 ===
# 从 publish_log.json 读 platforms.wechat.content_id / title / digest / thumb_media_id
PROJECTS = [
    # (proj_id, old_content_id, title, digest, thumb_media_id)
    ("20260424_1610_rare-earth-leak", "eYCpieqt-pkzK-...", "稀土泄密案的教训", "稀土企业出海失败的代价", "eYCpieqt-pkzK-..."),
    # ... 补全你的 9 个项目 ...
]

ROOT = Path("/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects")
SKILL_DIR = Path("/home/renanzai/.hermes/profiles/content/skills/wechat-official-account-publisher")

# === 1. 拿 access_token（用 skill 提供的 get_token.py，2h 缓存）===
def get_access_token():
    result = subprocess.run(
        ["python3", str(SKILL_DIR / "scripts" / "get_token.py")],
        capture_output=True, text=True, timeout=30,
    )
    if result.returncode != 0:
        sys.exit(f"get_token 失败: {result.stderr[:500]}")
    token = result.stdout.strip()
    if len(token) < 20:
        sys.exit(f"get_token 返回异常: {result.stdout[:200]}")
    return token

# === 2. 备份（任何修改前必做）===
def backup(proj_dir, pid, ts):
    bak = Path(f"/tmp/wechat_fix_backup_{ts}")
    bak.mkdir(parents=True, exist_ok=True)
    log = proj_dir / "05_publish" / "publish_log.json"
    if log.exists():
        shutil.copy2(log, bak / f"{pid}__publish_log.json")
    for fname in ("wechat_draft.wechat.html", "wechat_draft.html"):
        src = proj_dir / "01_content" / "drafts" / "wechat" / fname
        if src.exists():
            shutil.copy2(src, bak / f"{pid}__{fname}")
            break
    return bak

# === 3. 删旧草稿（用 urllib 不用 requests，避免再次踩坑）===
def delete_draft(token, media_id):
    url = f"https://api.weixin.qq.com/cgi-bin/draft/delete?access_token={urllib.parse.quote(token)}"
    payload = json.dumps({"media_id": media_id}).encode("utf-8")
    req = urllib.request.Request(
        url, data=payload,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
        return data.get("errcode") == 0, data
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

# === 4. 传新草稿（用 skill 的 upload_draft.py —— 已 ensure_ascii=False）===
def upload_new(html_path, title, digest, thumb_id):
    cmd = [
        "python3", str(SKILL_DIR / "scripts" / "upload_draft.py"),
        "--title", title,
        "--html", str(html_path),
        "--thumb-media-id", thumb_id,
        "--digest", digest,
        "--author", "",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    if result.returncode != 0:
        return None, f"upload_draft.py exit={result.returncode}, stderr={result.stderr[:300]}"
    new_cid = result.stdout.strip()
    if len(new_cid) < 20:
        return None, f"upload 返回异常: {result.stdout[:200]}"
    return new_cid, None

# === 5. 更新 publish_log.json（双记录 v1=deleted, v2=active）===
def update_log(proj_dir, old_cid, new_cid, title, digest, thumb_id):
    log = proj_dir / "05_publish" / "publish_log.json"
    if not log.exists():
        return False, "no log"
    data = json.loads(log.read_text(encoding="utf-8"))
    now = datetime.now().isoformat(timespec="seconds")
    data.setdefault("v1_drafts", []).append({
        "status": "deleted", "content_id": old_cid, "deleted_at": now,
        "delete_reason": "uploading used requests.post(json=...) default ensure_ascii=True -> unicode-escape bug",
    })
    data.setdefault("v2_drafts", []).append({
        "status": "active", "content_id": new_cid, "uploaded_at": now,
        "title": title, "digest": digest, "thumb_media_id": thumb_id,
        "uploaded_by": "fix-requests-json-escape-bug",
    })
    data["status"] = "draft_uploaded"
    data["content_id"] = new_cid
    data["title"] = title
    data["digest"] = digest
    data["thumb_media_id"] = thumb_id
    data["uploaded_at"] = now
    data["uploaded_by"] = "fix-requests-json-escape-bug"
    data.setdefault("platforms", {})["wechat"] = {
        "status": "draft_uploaded", "content_id": new_cid,
        "thumb_media_id": thumb_id, "title": title, "digest": digest,
        "uploaded_at": now, "uploaded_by": "fix-requests-json-escape-bug",
    }
    log.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return True, None

# === 主循环 ===
def find_html(proj_dir):
    for fname in ("wechat_draft.wechat.html", "wechat_draft.html"):
        p = proj_dir / "01_content" / "drafts" / "wechat" / fname
        if p.exists():
            return p
    return None

def main():
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    print(f"[{ts}] 微信公众号乱码修复开始")
    token = get_access_token()
    print(f"  token 长度 {len(token)} (前 6: {token[:6]}***)")
    for i, (pid, old_cid, title, digest, thumb_id) in enumerate(PROJECTS, 1):
        proj_dir = ROOT / pid
        if not proj_dir.exists():
            print(f"[{i}] {pid}: 跳过（项目目录不存在）")
            continue
        html = find_html(proj_dir)
        if not html:
            print(f"[{i}] {pid}: 跳过（找不到 HTML）")
            continue
        backup(proj_dir, pid, ts)
        ok, resp = delete_draft(token, old_cid)
        if not ok:
            print(f"[{i}] {pid}: delete 失败（继续）: {resp}")
        else:
            print(f"[{i}] {pid}: 旧草稿已删")
        new_cid, err = upload_new(html, title, digest, thumb_id)
        if err:
            print(f"[{i}] {pid}: upload 失败: {err[:200]}")
            continue
        print(f"[{i}] {pid}: 新草稿 {new_cid[:25]}...")
        update_log(proj_dir, old_cid, new_cid, title, digest, thumb_id)
        print(f"[{i}] {pid}: publish_log 双记录已写")
    print(f"\n[完成] 备份: /tmp/wechat_fix_backup_{ts}/")
    print(f"[下一步] 去公众号草稿箱验证中文是否正常")

if __name__ == "__main__":
    main()
