#!/usr/bin/env python3
"""
批量草稿质量验证脚本 — 2026-05-26

用途：上传微信草稿前，批量验证所有草稿的 h1 标题、品牌名、p标签
用法：python3 scripts/wechat_draft_batch_check.py [base_dir]

示例：
  python3 scripts/wechat_draft_batch_check.py /mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects
"""

import sys
import re
from pathlib import Path

# 标准草稿列表（项目名 → 相对路径）
DRAFT_MAP = {
    "反诈APP升级AI": "20260516_100010_anti-fraud-ai-detection/01_content/drafts/wechat/wechat_draft.html",
    "小米MiMo登顶全球": "20260514_xiaomi-car/01_content/drafts/wechat/wechat_draft.html",
    "618生图神器推荐": "20260525_085515_618-ai-tools-recommendation/01_content/drafts/wechat/wechat_draft.html",
    "AI内容工作流": "20260521_1435_ai-model-usage/01_content/drafts/wechat/wechat_draft.html",
    "AI配音提效": "20260520_133057_ai-voice-synthesis/01_content/drafts/wechat_draft.html",
    "闻泰安世对簿公堂": "20260525_085515_wentech-ansys-litigation/01_content/drafts/wechat/wechat_draft.html",
    "AI时代机会在哪": "20260517_094341_ai-era-opportunity/01_content/drafts/wechat/wechat_draft.html",
    "普京访华": "20260520_133057_putin-visit-china/01_content/drafts/wechat_draft.html",
    "AI造谣被处罚": "20260517_094341_trump-china-visit/01_content/drafts/wechat/wechat_draft.html",
    "实测豆包": "20260519_092124_dual-topics/doubao-shoufei-llm/01_content/drafts/wechat/wechat_draft.html",
    "大模型免费时代": "20260519_092124_dual-topics/doubao-yuyue-canlou/01_content/drafts/wechat/wechat_draft.html",
    "阿里财报": "20260516_100010_china-us-summit/01_content/wechat_draft.html",
    "10款AI视频": "20260516_100010_china-us-summit/01_content/drafts/wechat/wechat_draft.html",
}


def count_chinese(s):
    """统计中文字符数"""
    return len([c for c in s if '\u4e00' <= c <= '\u9fff'])


def extract_text(html):
    """清理 HTML 标签，提取纯文本"""
    t = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL | re.IGNORECASE)
    t = re.sub(r'<style[^>]*>.*?</style>', '', t, flags=re.DOTALL | re.IGNORECASE)
    t = re.sub(r'<[^>]+>', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()


def check_draft(name, path):
    """检查单个草稿，返回 (ok, message)"""
    p = Path(path)
    if not p.exists():
        return False, "文件不存在"

    html = p.read_text(encoding='utf-8')
    text = extract_text(html)
    size = p.stat().st_size

    # h1 检查
    h1_m = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.DOTALL)
    h1 = re.sub(r'<[^>]+>', '', h1_m.group(1)).strip() if h1_m else ""
    chinese = count_chinese(h1)

    # 品牌名
    yimu = '壹目贯维' in text

    # p标签
    has_p = '<p' in html

    # blockquote（可选，有则更好）
    has_bq = '<blockquote>' in html

    ok = chinese <= 9 and yimu and has_p
    return ok, {
        "h1": h1[:25] if h1 else "无",
        "chinese": chinese,
        "yimu": yimu,
        "has_p": has_p,
        "has_bq": has_bq,
        "size": size,
    }


def main():
    base = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/projects")

    print("=" * 75)
    print("  微信草稿批量质量验证")
    print("=" * 75)
    print(f"{'#':>2} {'草稿':<16} {'h1标题':<22} {'汉字':>4} {'品牌':>4} {'p':>3} {'bq':>3} {'size':>6}")
    print("-" * 75)

    total_ok = 0
    total_fail = 0

    for i, (name, rel) in enumerate(DRAFT_MAP.items(), 1):
        ok, result = check_draft(name, base / rel)
        if isinstance(result, str):
            print(f"❌ {i:>2} {name:<16} {result}")
            total_fail += 1
        else:
            status = "✅" if ok else "⚠️"
            print(f"{status} {i:>2} {name:<16} {result['h1']:<22} {result['chinese']:>4} "
                  f"{'✅' if result['yimu'] else '❌':>4} "
                  f"{'✅' if result['has_p'] else '❌':>3} "
                  f"{'✅' if result['has_bq'] else '⚠️':>3} "
                  f"{result['size']:>6}B")
            if ok:
                total_ok += 1
            else:
                total_fail += 1

    print("-" * 75)
    passed = total_ok
    failed = total_fail
    print(f"✅ {passed}/{passed+failed} 通过")
    if failed > 0:
        print(f"❌ {failed} 篇有问题，请修复后上传")

    return failed == 0


if __name__ == "__main__":
    ok = main()
    sys.exit(0 if ok else 1)