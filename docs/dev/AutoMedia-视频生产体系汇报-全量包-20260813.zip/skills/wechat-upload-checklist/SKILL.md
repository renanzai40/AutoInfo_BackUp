---
name: wechat-upload-checklist
description: '微信公众号上传安全检查清单 — 任何草稿上传前必须逐项通过，不存在"应该没问题"的假设。触发：发公众号、发微信、上传微信草稿、wechat draft、微信发布。 排除：不用于公众号内容写作；仅上传草稿前的安全检查时加载。'
category: productivity
---
## 上传前检查清单（8步，逐项通过才算合格）

> **Token过期40001处理（2026-05-20新增，2026-05-28修正）**：`get_token.py` 凭证来源是 `wechat_secrets.env`（AppID/AppSecret），不是 config.json。如果返回40001，说明 IP 不在白名单（errcode 40164 的情况也会报40001），需要先在微信后台添加 WSL 出口 IP。如果返回40164，在微信公众平台 → 基本配置 → IP白名单加入 `112.41.58.21`。

### Step 0：检查 publish_log.json — 已有草稿则禁止重复上传

读取 `<project>/05_publish/publish_log.json`。

如果 `status` 已经是 `draft_uploaded` 且存在有效的 `content_id`：
- **跳过上传说为**——草稿已在草稿箱
- 如果内容确实已更新需要重新上传，必须**先删旧草稿**再传新草稿
- **永远不要在未确认旧草稿状态的情况下直接上传**——每次 API 调用都会创建新草稿，即使内容完全相同

### Step 0.5：重传草稿流程（2026-06-02 首次落地）

**触发条件**：项目视频/封面/标题/摘要等内容发生更新，需要替换已上传的草稿。

**铁律**：微信公众号 draft API **非幂等**。先删旧草稿（`draft/delete`）再传新草稿（`draft/add`）。否则草稿箱会同时存在新旧两份，污染发布源。

**完整流程**：

```
1. 备份 body HTML（防 pre_upload_check.py 写入时改坏）
   cp $BODY_HTML $BODY_HTML.v1_backup_$(date +%s)

2. 备份 publish_log.json
   cp $LOG publish_log.json.v1_backup_$(date +%s)

3. 取 access_token（get_token.py，2h 缓存）

4. 删旧草稿
   POST https://api.weixin.qq.com/cgi-bin/draft/delete?access_token={token}
   body: {"media_id": "旧 content_id"}
   → 期望返回 {"errcode": 0, "errmsg": "ok"}

5. 重新上传新封面图（如有更新）
   python3 upload_thumb.py /path/to/new_cover.jpg
   → 新 thumb_media_id

6. 重新传草稿（同一份 body HTML 也行；视频替换只需换封面）
   python3 upload_draft.py --title "..." --html $BODY_HTML \
     --thumb-media-id "$NEW_THUMB_ID" --digest "..."
   → 新 content_id

7. 重写 publish_log.json（**双记录**结构）
   {
     "v1_drafts": [{"status": "deleted", "content_id": "旧", "deleted_at": "...", "delete_response": "errcode=0"}],
     "v2_drafts": [{"status": "active", "content_id": "新", "uploaded_at": "...", "thumb_media_id": "新", ...}],
     ...
   }
```

**常见误区**：
- ❌ 以为"内容差不多就直接重传"→ 草稿箱多出重复条目
- ❌ 用 `draft/update` 试图"修改"已有草稿 → **该接口不存在**（只能 add + delete 配对）
- ❌ 删草稿前忘了备份 body HTML → pre_upload_check.py 会改文件
- ❌ publish_log.json 只记 v2 不记 v1 → 失去追溯链（哪次改的、为什么改、删了哪个）

**视频替换的特殊简化**：
- 公众号文章 body HTML **不含视频 URL**（用 thumb_media_id 在 feed 流里表现视频）
- 视频替换 = **换封面图 + 重传草稿**，body HTML 不动
- 实测：m3 项目 v1→v2 重传只换了 thumb_media_id，body HTML 100% 复用，3 张正文图片 CDN URL 也不变

详见：`references/session-learnings-2026-06-02.md`

### Step 1：清理 MiniMax 思考标签

MiniMax 返回的所有内容在保存或上传前**必须**清理：

```python
import re

def clean_minimax_tags(content: str) -> str:
    """清除 MiniMax 思考过程标签"""
    cleaned = re.sub(r"<think>[\s\S]*?</think>", "", content)
    return cleaned

def remove_word_count_markers(content: str) -> str:
    """删除【约XXX字】标记"""
    return re.sub(r"【约\d+字】", "", content)
```

**验证**：保存后再读文件，确认文件中无 `<think>` 和 `</think>`。

---

### Step 2：确认文件与 topic 一一对应

草稿箱事故中，DeepSeek 的脏内容进了 Harness 的草稿——原因是**跨 topic 协作时共享了同一批文件操作**。

规则：
- 每个 topic 的 `01_content/drafts/` 下只放该 topic 的文件
- 从不混用不同 topic 的 md/html 文件
- 上传前确认：当前在操作的是哪个 topic，这些文件属于哪个 topic

---

### Step 3：公众号文章三安全规则（上传前必做）

> **任意一条不通过，不得上传，立即修复。**

| # | 规则 | 验证方法 |
|---|------|---------|
| ① | 文件中无 `<think>...</think>` 思考标签 | `grep -c "<think>" wechat.md` → 返回 0 |
| ② | 文件中无 `【约\d+字】` 标记 | `grep -c "【约" wechat.md` → 返回 0 |
| ③ | 文件内容已读、全文确认干净（非只检查结尾） | `wc -l wechat.md` + 抽查中间段落 |

---

### Step 4：HTML 文件质量验证 + draft/add 内容规范

微信公众号上传的是 HTML 文件，不是 Markdown。

**HTML 必须包含的结构**：
- `<meta charset="utf-8">` 或 `<meta http-equiv="Content-Type" content="text/html; charset=utf-8">`
- 文章标题在 `<title>` 和 `<h1>` 中一致
- 无残留的 Markdown 语法（`## `、`**` 等不应出现在 HTML 正文）
- 无乱码字符（`&lt;` `&gt;` 等字面量出现在正文中 = 问题）
- 图片使用 `https://` URL，不含相对路径

**`draft/add` 接口的 `content` 字段规范（2026-05-15 实测）：**

1. **只传 `<body>...</body>` 内部内容**，不要包含 `<html>/<head>/<title>` 外层标签
   - 如果 HTML 文件是完整文档（含 `<html><head>...`），用 `re.search(r'<body>(.*?)</body>', html, re.DOTALL)` 提取正文
   - 如果 HTML 文件是 Markdown 转出来的，标题行（`# xxx`）单独提取，正文转成段落 `<p>...</p>`

2. **smart quotes 必须转换**：`"` `"` `'`` → 普通 ASCII `"` `'`，否则 WeChat 显示乱码

3. **Markdown 转 HTML 正确做法**：
   ```python
   # 标题行单独提取，正文转段落
   md_body = re.sub(r'^# .+?\n', '', md, count=1, flags=re.MULTILINE)
   lines = md_body.split('\n')
   out = []
   for line in lines:
       m = re.match(r'^(#{1,6})\s+(.+)$', line.strip())
       if m:
           out.append(f'<h{len(m.group(1))}>{m.group(2)}</h{len(m.group(1))}>')
       elif line.strip().startswith('>'):
           out.append(f'<blockquote>{line.strip()[1:].strip()}</blockquote>')
       else:
           out.append(line)
   html = '\n'.join(out)
   # 处理 smart quotes
   html = html.replace('\u201c', '"').replace('\u201d', '"')
   html = html.replace('\u2018', "'").replace('\u2019', "'")
   # 段落包装（标题块不包装）
   html = re.sub(r'\n{3,}', '\n\n', html)
   paras = []
   for block in html.split('\n\n'):
       block = block.strip()
       if not block: continue
       if block.startswith('<h') or block.startswith('<blockquote') or block.startswith('<hr'):
           paras.append(block)
       else:
           paras.append(f'<p>{block.replace(chr(10), "<br>")}</p>')
   content = '\n'.join(paras)
   ```

**`draft/add` 接口规范**：
- 只传 `<body>...</body>` 内部内容，不要包含 `<html>/<head>/<title>` 外层标签
- 用 `re.search(r'<body>(.*?)</body>', html_content, re.DOTALL)` 提取正文

**标题、摘要、作者的字符数限制（实测 2026-05-15）：**

| 字段 | 硬性限制 | 超过报错 | 备注 |
|------|---------|---------|------|
| `title` | **≤9个中文字符** | 45003 | 禁用 `：` `、` `｜` 等全角符号；即使无特殊字符，超9字也报45003 |
| `digest`（摘要） | **≤20个纯文本字符** | 45004 | 禁用全角分隔符；pre_upload_check.py 强制执行此限制（不是120字） |
| `author` | **留空 `""`**，不要填品牌名 | 45110 | |

**`｜` 全角分隔符会触发 45003**：实测 "AI产业日报｜这周大事一览"（35B）报 45003；改成 ASCII `|` 的 "AI产业日报|这周大事一览"（33B）成功。
**结论**：不要用 `｜`(U+FF5C)、`—`(em-dash)、`·` 等全角/特殊符号；用 `-`、`:`、ASCII `|` 等 ASCII 分隔符。

**摘要 digest 也受同样规则约束**：实测 "缺的不是AI工具，是方法"（20B）可通过；"对大多数团队来说..."（64B）报 45004。

**作者 author 字段**：填 `""`（空字符串）或完全不填；填 "壹目贯维" 反而报 45110。

```python
# 正确示例（2026-05-15 验证通过）
draft_payload = {
    "articles": [{
        "thumb_media_id": thumb_media_id,
        "author": "",                        # 留空，不要填品牌名
        "title": "AI产业日报|这周大事一览",  # ASCII | 分隔，不用 ｜
        "content_source_url": "",
        "digest": "缺的不是AI工具，是方法",   # 尽量 ≤20B
        "content": body_inner_html,           # 只放 <body> 内部内容
        "need_open_comment": 0,
        "only_fans_can_comment": 0
    }]
}
```

**HTML 清理代码**：
```python
import re

def clean_html_for_wechat(html_content: str) -> str:
    """清理 HTML 中的常见问题"""
    # 移除注释
    html_content = re.sub(r"<!--[\s\S]*?-->", "", html_content)
    # 移除断行标签（通常由 MiniMax 思考标签产生）
    html_content = re.sub(r"<br\s*/?>", "\n", html_content)
    # 确保编码声明存在
    if 'charset=' not in html_content[:500]:
        html_content = '<meta charset="utf-8">\n' + html_content
    return html_content
```

---

### Step 5：封面图验证

- 必须上传封面图（`add_material` type=`thumb`）
- 图片尺寸验证（不在代码里猜测，手动用 `file` 命令确认）
- 图片格式：JPG/PNG，文件扩展名正确

---

### Step 6：凭证有效性（每次上传前检查）

微信公众号 API 需要有效的 `access_token`，有效期 2 小时。

**不要假设 token 有效**，每次上传前验证：
```python
import requests

def verify_access_token(appid, appsecret):
    url = f"https://api.weixin.qq.com/cgi-bin/token"
    params = {"grant_type": "client_credential", "appid": appid, "secret": appsecret}
    resp = requests.get(url, params=params, timeout=10)
    data = resp.json()
    if "access_token" not in data:
        raise Exception(f"获取 access_token 失败: {data}")
    return data["access_token"]
```

**IP 白名单**：WSL 出口 IP 必须在白名单内，否则报 `errcode: 40164`（不是 token 过期！）。当前白名单应包含 WSL 出口 IP。

---

### Step 7：上传后立即确认 media_id

`add_material` 返回 `media_id`，`draft/add` 返回 `content_id`。

**上传后必须记录**：
- `media_id`（封面图）
- `content_id`（草稿）
- topic 名称、上传时间
- 保存路径：`项目/05_publish/publish_log.json`

---

## 微信公众号 API 正确流程

```
access_token（有效期内）
    ↓
① 上传封面图 → media_id
    POST https://api.weixin.qq.com/cgi-bin/material/add_material
    Content-Type: multipart/form-data
    form: media=@cover.jpg, type=thumb
    → {"media_id": "xxx", ...}

② 上传正文HTML → media_id
    POST https://api.weixin.qq.com/cgi-bin/media/upload
    form: media=@wechat.html, type=news
    → {"media_id": "xxx", ...}

③ 创建草稿 → content_id
    POST https://api.weixin.qq.com/cgi-bin/draft/add
    body: { "articles": [{ "thumb_media_id": "封面media_id",
                           "author": "",                            ← 留空，不要填品牌名
                           "title": "标题（≤30B，禁用全角符号）",
                           "content_source_url": "",
                           "digest": "摘要（≤20B）",
                           "content": "<body>内部HTML（不含外层标签）",
                           "need_open_comment": 0,
                           "only_fans_can_comment": 0 }] }
    → {"media_id": "xxx"}  ← 这是 content_id
```

> ⚠️ `add_material`（永久素材）和 `media/upload`（临时素材）返回的 `media_id` 格式不同，不能混用。
>
> ⚠️ 封面图用 `add_material` type=`thumb`；正文图片用 `media/upload` type=`image`。

---

## credential 存储位置

```
/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/config/wechat_secrets.env
AppID:    wx40665d17fc4ed506
AppSecret: 26e3f56b6a1fa59cb46b1badc6c51f85
```

读取方式（每次上传前加载）：
```python
from pathlib import Path
env_path = Path("/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/config/wechat_secrets.env")
secrets = {}
for line in env_path.read_text().splitlines():
    if "=" in line and not line.strip().startswith("#"):
        k, v = line.split("=", 1)
        secrets[k.strip()] = v.strip().strip('"')
appid = secrets.get("WECHAT_APP_ID")
appsecret = secrets.get("WECHAT_APP_SECRET")
```

> ⚠️ 注意（2026-05-28 修正）：`get_token.py` 读取的是 `wechat_secrets.env`，不是 skill 目录下的 `config.json`。`config.json` 不存在或不包含 AppSecret 时，用 env 文件路径。

---

## 故障对照表

| 错误码 | 含义 | 处理 |
|--------|------|------|
| 40001 | access_token 无效/过期 | 重新获取 token |
| 40164 | IP 不在白名单 | 将 WSL 出口 IP 加入白名单 |
| 45003 | 标题超字节限制**或含全角分隔符** | 缩短标题，禁用 `｜``—``·` 等全角符号，改用 ASCII `-``:` `\|` |
| 45004 | 摘要 digest 超字节限制 | 缩短摘要至 ≤20 字节，不用全角符号 |
| 45110 | 作者名 author 超限 | 留空 `""`，不要填品牌名 |
| 40032 / 40033 | draft/delete 失败（旧 content_id 不存在或已删） | 重新查询 content_id 状态；可能本来就没传成功 |

---

## 上传前 Gate 检查（强制流程，2026-05-26 新增，6-05 升级到 G1-G5）

> **视频生产和公众号草稿上传有独立的 Gate 机制，两者都不得跳过。**

### Gate 流程

```
内容生成完成
    ↓
Step G1: copy-review — 文案结构性/清晰度/说服力审查
    ↓ 通过 → Step G2
    ↓ 不通过 → 修复文案，重新审查
Step G2: brand-cta-review — 品牌身份/CTA 话术检查
    ↓ 通过 → Step G3
    ↓ 不通过 → 修复 CTA
Step G3: Humanizer — 消除 AI 写作痕迹
    ↓ 通过 → Step G4
    ↓ 不通过 → 去 AI 味处理
Step G4: 公众号排版检查（公众号专属）— HTML 结构（blockquote / h2 / p）≥ 5 个
    ↓ 通过 → Step G5
    ↓ 不通过 → 修复 HTML 样式
Step G5: 硬门控（公众号专属，2026-06-05 新增，6-10 补强）— HTML 标签 ≥ 5 + `<strong>` ≥ 2 + 无 Markdown 触发器<br>必查：(1) `<p>/<h2>/<blockquote>` ≥ 5 (2) `<strong>` ≥ 2 (3) head -5 无 `# ` 或 `## ` 开头 (4) 无完整 `<html>` 外层
    ↓ 通过 → 可以上传
    ↓ 不通过 → 拒绝上传（防 Pitfall 13 复发）
```

### Gate 通过标准

每个 Gate 检查通过后，`04_review/review_log.json` 必须记录：

```json
{
  "gates": {
    "G1_humanizer": true,
    "G2_copy_review": true,
    "G3_brand_cta": true
  },
  "gate_checked_at": "2026-05-26T09:00:00+08:00"
}
```

**没有 `review_log.json` 或 Gate 未通过，禁止调用 `wechat_publisher.py` 上传。**

### 当 Gate 记录不存在时（2026-05-28 新增）

**触发**：项目目录下 `04_review/review_log.json` 不存在，或 Gate 有任意一项为 `false`。

**规则**：必须补完 Gate，不能绕过。执行顺序：

```
1. copy-review — 文字内容结构性/清晰度审查
2. brand-cta-review — CTA 话术检查
3. humanizer — 去 AI 味处理
4. G4 排版检查 — HTML 结构（blockquote / h2 / p）
```

**操作**：每个 Gate 通过后，向 `04_review/review_log.json` 写入：

```json
{
  "gates": {
    "G1_humanizer": true,
    "G2_copy_review": true,
    "G3_brand_cta": true,
    "G4_format": true
  },
  "gate_checked_at": "2026-05-28T18:00:00+08:00"
}
```

**禁止**：
- 跳过 Gate 直接调用 `upload_draft.py`
- 在 Gate 未完成时，用"内容是旧的所以应该没问题"为由绕过

**典型场景**：项目 `20260528_104457_dual-topics` 的 trapdoor 和 runway 都是引流款/业务款生产链路直接完成，没有经过 review step。这种情况下必须先补 Gate，再上传。**

## 黄金法则

> **任何文件在第一次用于任何用途前，必须经过 Step 3 的三安全规则验证。不存在"旧文件所以干净"的假设。**

> **Gate 检查必须在上传前完成，不是上传后补做。** `wechat_publisher.py` 本身不做 Gate 检查，调用者有责任确保 Gate 已通过。

---


---

## 章节导航（JiT Loading）

> 主文件保留核心流程。以下章节已移至 references/，按需加载：

| 章节 | Reference | 行数 |
|------|-----------|------|
| 典型上传案例（2026-05-26 实测） | `references/typical-upload-cases.md` | 304 |
| ⚠️ Pre-condition：`publish_log.json` 必含 `platforms.wechat.thumb_media_id`（2026-06-06 实战踩坑） | `references/precondition-publish-log-thumb.md` | 89 |
| 与 pre_upload_check.py 的关系（2026-05-16 更新） | `references/pre-upload-check-relationship.md` | 77 |
| ⚠️ 致命陷阱：inline 写 requests.post(json=payload) 会变 unicode escape 乱码（2026-06-02 实测） | `references/pitfall-inline-requests-post.md` | 36 |
| 🔥 Pitfall 12 (Meta): 写"修复 \u escape bug"脚本时**不要在源代码里再写 \u 转义字符串** | `references/pitfall-12-meta-backslash-u.md` | 28 |
| 新增：WeChat API 字段限制（2026-05-15 实测，永久生效） | `references/wechat-api-field-limits.md` | 25 |
| 验证步骤 | `references/verification-steps.md` | 24 |
| 排版损坏的四种形态与处理（2026-05-26 新增） | `references/four-typography-break-forms.md` | 22 |
| 🔥 9 个草稿批量乱码事故 + 修复（2026-06-03 落地） | `references/incident-9-drafts-mojibake.md` | 18 |
| h1 标题验证（防文件内容错位，2026-05-26 新增） | `references/h1-title-verification.md` | 17 |
| 公众号排版检查（G4） | `references/g4-typography-check.md` | 13 |
| ⚠️ Python 源文件字面 `\u` 触发 SyntaxError（实测 3 次踩坑） | `references/pitfall-py-literal-backslash-u.md` | 11 |
