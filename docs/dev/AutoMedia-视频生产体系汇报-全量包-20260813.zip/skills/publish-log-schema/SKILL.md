---
name: publish-log-schema
description: "AutoMedia publish_log.json 统一 schema v2.1 — per-platform 状态 + WeChat 特殊 3 重触发器 + 派生 status。每次新建/更新 publish_log.json 必须遵守。触发：上传公众号草稿、状态变化、视频替换。 排除：不用于发布操作本身；仅新建/更新 publish_log.json 时加载。"
version: 2.1
created: 2026-06-02
updated: 2026-06-02
---

# publish_log.json Schema v2.1 (per-platform 升级版)

> **v2.0 → v2.1 升级原因（2026-06-02）**：
> - v2.0 是单平台视角（只追踪 wechat），业务款 5 平台无法表达
> - v2.1 引入 `platforms: {}` map，每平台独立追踪状态
> - WeChat 特殊：唯一有"草稿箱"中间态（draft_uploaded），其他 4 平台无
> - top-level `status` 改为**派生字段**（从 platforms 算），不是 source of truth

## Scope 边界

**本 skill 只管 `05_publish/publish_log.json` 的字段和平台状态枚举。**

**不在本 skill 范围**：
- `00_project_info.json` 的 `status` 字段（仅 `selected` 显式存，其他派生）→ 见 `project-status-schema` skill（计划中）
- `pool.db` 的 `topics.status` 字段 → pool.db schema
- `04_review/review_log.json` 的 `gates` 字段 → 4 gate 各自的 skill
- `jobs.json` 的 `health` 字段 → cron watchdog

## v2.1 字段结构（per-platform model）

```json
{
  "project_id": "<项目目录名>",
  "platform": "wechat",  // legacy: 历史字段,保留兼容
  "_computed_status": "<derived>",  // 派生字段,每次读时从 platforms 重算
  "current": { ... 兼容 v2.0 字段 ... },
  "history": [ ... 兼容 v2.0 字段 ... ],
  "known_issues": [ ... 兼容 v2.0 字段 ... ],
  "platforms": {
    "wechat":      { "status": "draft_uploaded", "content_id": "eY...", "title": "...", "published_at": null },
    "douyin":      { "status": "pending",          "content_id": null,     "published_url": null },
    "xiaohongshu": { "status": "pending",          "content_id": null,     "published_url": null },
    "zhihu":       { "status": "pending",          "content_id": null,     "published_url": null },
    "bilibili":    { "status": "pending",          "content_id": null,     "published_url": null }
  },
  "created_at": "ISO 8601",
  "updated_at": "ISO 8601",
  "notes": "自由文本"
}
```

## 5 状态 + 4 平台状态

### project.status 5 个 canonical 状态

| 状态 | 存储 | 含义 |
|---|---|---|
| `selected` | **显式存** (00_project_info.json) | 刚选 topic, agent 未启动, 等于 08:30 推送后用户选 |
| `in_flight` | 派生 | 内容生产中, 无 platform 达到 content_ready |
| `awaiting_publish` | 派生 | 至少 1 platform 有动作, 但 required 未全 published |
| `published` | 派生 | 所有 required platform 都 published |
| `cancelled` | 显式存 | user 决定不做 |

### per-platform 4 状态

| 状态 | 含义 | 谁写 |
|---|---|---|
| `pending` | 未准备（默认）| 自动 |
| `content_ready` | 内容已生成但未上传/未发 | agent |
| `draft_uploaded` | ✓ **仅 WeChat 有效** — 已上传到草稿箱 | upload_draft.py hook |
| `published` | 已对外发布 | user 通知 / cron 检测 |

### required platforms（由 project.type 决定）

| project.type | required_platforms |
|---|---|
| `引流款` | `[wechat]` — 只 1 个, 其他 4 默认 pending |
| `业务款` | `[wechat, douyin, xiaohongshu, zhihu, bilibili]` — 5 个全要 |

## project.status 推算规则（来自 compute_project_status.py）

```python
def compute_status(proj_dir, platforms, project_type):
    required = get_required_platforms(project_type)

    if has_any_action(platforms):
        # 至少 1 个有动作
        all_required_done = all(
            platforms[p]["status"] == "published"
            for p in required
        )
        if all_required_done:
            return "published"
        return "awaiting_publish"

    # 没有 platform 有动作 → 看目录内容
    if has_no_content(proj_dir):
        return "selected"
    return "in_flight"
```

**关键 insight**：`compute_status()` 是**单一 source of truth**。所有读 publish_log 的脚本必须调用此函数，**不要自己算**（m3 案例证明双存不一致的代价）。

## WeChat 3 重触发器（2026-06-02 设计）

WeChat 是唯一自动化平台（upload_draft.py 写 publish_log），**特殊设计 3 重触发器**：

| # | 触发器 | 时机 | 写什么 | 谁执行 |
|---|---|---|---|---|
| **W1** | upload_draft.py hook | 即时（脚本结束前）| `platforms.wechat = {status: draft_uploaded, content_id: ...}` | upload_draft.py (改末尾加 status 写字段) |
| **W2** | cron `draft/get?media_id=...` 试探 | 每天 1 次 | 草稿消失 → 飞书提醒 user（不直接改 status）| cron (Phase 5a) |
| **W3** | `record_manual_publish.py wechat <project> <url>` | 手动 | `platforms.wechat = {status: published, published_url: ...}` | user 触发 |

**W2 为什么用 `draft/get?media_id` 而不用 `freepublish/get`**：
- `freepublish/get` 需要 `publish_id`（公众号在草稿→已发布时生成）
- 草稿阶段**还没有 publish_id**——草稿变成已发布才有
- 草稿阶段唯一能用的 API 是 `draft/get?media_id=<content_id>` 试探
- **微信官方行为**：草稿正常发表后**自动从草稿箱移除**（open-community 确认）
- W2 检测到草稿消失 = 可能已发表 → 飞书提醒 user，user 确认后用 W3 标记

**W2 不直接改 status**：
- 草稿消失可能是"已发表"（✓ published）也可能是"被手动删除"（✗ 不是 published）
- 只有 user 知道真相
- W2 只提醒，W3 才是真正的 published 转换

## 其他 4 平台 1 重触发器

| # | 触发器 | 时机 | 写什么 | 谁执行 |
|---|---|---|---|---|
| **O1** | `record_manual_publish.py <project> <platform> <url>` | 手动 | `platforms.{platform} = {status: published, published_url: ...}` | user 触发 |

**注意**：其他 4 平台**没有自动检测**——纯依赖 user 通知。
**stale 检测**（Phase 5b）：`awaiting_publish` > 30 天 → 飞书提醒 user "是否发了但忘了告诉我"

## 关键规则

1. **top-level `status` 是派生字段** —— 不直接写，每次读时从 `platforms` 算
2. **`platforms` 是 source of truth** —— 所有 status 变更走 platforms
3. **`current` 始终是活跃版本** —— `awaiting_publish` 时 current 是 v1/v2（最新）
4. **`history` 按 uploaded_at 倒序** —— v2 在 v1 之前
5. **`known_issues[].status` 三态**：`open` / `user_accepted` / `fixed`
6. **视频相关字段**（`video_path` / `video_av_sync_qa`）：如果项目无视频可省
7. **微信字段限制**：`title` ≤9 汉字，`digest` ≤20 纯中文
8. **per-platform 字段不要单独 archive**（INV-9）：wechat published 后素材仍留原项目目录

## compute_project_status.py 单一实现

**位置**：`/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts/compute_project_status.py`

**所有读 publish_log 的脚本必须**：

```python
import sys
sys.path.insert(0, '/mnt/d/Hermes-Workspace/01-Projects/AutoMedia/Scripts')
from compute_project_status import compute_status

status = compute_status(proj_dir, platforms, project_type)
# 不要自己写 status 推算逻辑!
```

**为何单一实现**：
- m3 案例已证明：双存或多份算法 → 必漂移
- 一个项目 28 个 status 字段全脏 = 多个地方各算一份的代价
- 单一函数 = 单一 source of truth, 唯一可信赖

## jsonschema 验证

schema 升级到 v2.1（`schema.json`）：

```bash
pip install jsonschema
python3 -c "
import json, jsonschema
jsonschema.validate(
    json.load(open('publish_log.json')),
    json.load(open('~/.hermes/profiles/content/skills/publish-log-schema/schema.json'))
)
"
```

**注意**：v2.1 schema 验 `platforms` map 必填，验 `status` 字段是**optional**（派生）。

## v2.0 → v2.1 迁移指南

对 v2.0 旧 publish_log.json：

1. 备份原文件到 `/tmp/audit_backup_<date>_task<v2.1>/`
2. 读 `current.content_id` —— 如果存在 → 迁移到 `platforms.wechat.content_id` + `status: draft_uploaded`
3. 读 `current.published_url` —— 如果存在 → `platforms.wechat.status: published`
4. 缺其他 4 平台 → 补 `platforms.{douyin,xiaohongshu,zhihu,bilibili}: {status: pending}`（**不要漏**——compute_status 按 type 推算时 4 平台缺字段会被算作 pending，但 5 平台业务款完整性会被低估）
5. 删除 top-level `status` 字段（或改 `_computed_status`）
6. 写 `_migrated_to: v2.1` 标记

**m3 迁移示例**（v2.0 publish_log.status=draft_v2_uploaded）：
```python
new_log = {
    "project_id": "20260601_201455_minimax-m3",
    "_computed_status": "awaiting_publish",  # 派生
    "platforms": {
        "wechat": {"status": "draft_uploaded", "content_id": "eY...ugz", "title": "M3内容工具升级", "thumb_media_id": "eY..."},
        "douyin":      {"status": "pending"},
        "xiaohongshu": {"status": "pending"},
        "zhihu":       {"status": "pending"},
        "bilibili":    {"status": "pending"}
    },
    "_migrated_to": "v2.1",
    "_migrated_at": "2026-06-02T..."
}
```

**hy 迁移**同 m3，content_id 用 v1 的。

### ⚠️ 迁移期一致性 Bug（2026-06-02 实测）

**症状**：user 标 wechat=published 时只改了 `platforms.wechat.status`，没改顶层 `status`，导致**两者冲突**：
- 顶层 `status: "draft_uploaded"`
- `platforms.wechat.status: "published"`

**compute_status 推算结果**：`awaiting_publish`（按顶层）——但业务含义是 wechat 已 published。

**修正**：迁移时**必须**：
1. 如果 `current.published_url` 存在 → 顶层 `status` 也改为 `"published"`（不是 `"draft_uploaded"`）
2. 写完两条一致性检测：
   ```python
   top = data.get("status")
   plat_wechat = data.get("platforms", {}).get("wechat", {}).get("status")
   if top == "draft_uploaded" and plat_wechat == "published":
       data["status"] = "published"  # 同步顶层
   ```

**教训**：v2.1 设计原则是"顶层 status 是派生字段"——但派生字段也要写！否则 compute_status 函数推算不出来。新 agent 接手时记得：v2.0/v2.1 项目的顶层 status **不能留空**（虽然 v2.1 spec 说"派生字段"，但 compute_status v2.1 实现实际**优先读顶层 status** 作为 source of truth，platforms map 是 fallback）。

## 案例

| 项目 | v2.0 状态 | v2.1 迁移后 |
|------|---------|-----------|
| m3 | `v1_drafts[]/v2_drafts[]` parallel + `status: draft_v2_uploaded` | `current{}` + `history[2 entries]` + `platforms.wechat.draft_uploaded` + `platforms.{其他4}.pending` |
| hy | `records[].known_issues[]` + `notes` | `platforms.wechat.draft_uploaded` (v1) + `platforms.{其他4}.pending` + `_computed_status: awaiting_publish` |
| 26 个旧项目 | 各种 ad-hoc status | `platforms.wechat.content_ready` (有视频但没 publish_log) + `platforms.{其他4}.pending` |

## 完整 5 状态 + 9 INV 设计记录

详细设计（含 5 状态详细定义、9 条 INV 完整说明、archive 双触发器规则、Phase 路线、历史教训）见 `references/project-status-5states-2026-06-02.md`。

**何时读这个 reference**：
- 任何 session 涉及"项目状态"判断时
- 任何 session 涉及"archive"操作时
- 任何 session 涉及 28 个旧项目状态分类时
- 任何"为什么这个项目在 archive/?"的疑惑

## ⚠️ 当前 v2.0 → v2.1 升级 Gap（2026-06-02 audit）

| Gap | 现状 | 修复方向 |
|-----|------|---------|
| `upload_draft.py` 不写 status 字段 | 实际只 append publish_log.json, status 是手工写的 | 改 upload_draft.py 末尾加 status 写字段逻辑 |
| `draft/get?media_id=...` 没实现 | 还没写 W2 cron 脚本 | Phase 5a 加 cron |
| `record_manual_publish.py` 没实现 | user 没工具通知其他 4 平台 | Phase 4b 写脚本 |
| `compute_project_status.py` 没实现 | 推算逻辑在各脚本里飘 | Phase 1a 写单一实现 |

## 反模式（避免）

- ❌ top-level `status` 字段手工写（必与 platforms 漂移）
- ❌ 双存（top-level status + platforms 都写）—— 必漂移
- ❌ 各脚本自己算 status 推算（5 份算法 5 份 bug）
- ❌ 草稿消失 = 直接改 status = "published"（错——可能是被手动删除）
- ❌ wechat published 后立刻 archive（违反 INV-8）