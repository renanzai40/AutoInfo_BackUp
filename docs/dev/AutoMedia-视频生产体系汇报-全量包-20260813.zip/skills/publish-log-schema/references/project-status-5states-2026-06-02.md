# 5 状态 + 9 INV 完整设计记录

> **作者**: Hermes Agent
> **创建**: 2026-06-02
> **触发**: 2026-06-02 m3 案例根因 + 28 项目 audit 暴露的 publish_log 假阳性问题
> **关联 skill**: publish-log-schema (skill_view)

---

## 1. 5 状态定义（canonical）

| 状态 | 存储位置 | 来源 | 含义 | 触发转换 |
|---|---|---|---|---|
| `selected` | `00_project_info.json.status` 显式存 | user 选 topic (08:30 push 后) | 刚选,目录已建, agent 未启动 | agent 首次动作 → in_flight |
| `in_flight` | 派生（compute_status） | agent 生产内容中 | 至少 1 platform 还未达 content_ready, 或目录空但 platforms 全 pending | content ready / 取消 |
| `awaiting_publish` | 派生 | agent 已完成内容, 至少 1 platform 有动作 | ≥1 platform 达 content_ready/draft_uploaded/published, 但 required 未全 published | 全部 required published → published |
| `published` | 派生 | 项目对外生命周期结束 | 所有 required platform 都 = published | (终态) |
| `cancelled` | `00_project_info.json.status` 显式存 | user 决定不做 | 用户主动放弃,不可被 platforms 推算覆盖 | (终态) |

**注意**: `selected` 和 `cancelled` **不参与 compute_status 推算**——是用户的"显式表态",必须从 `00_project_info.json` 读,不能从 platforms 推。

**`archived` 是派生状态**（不存字段）—— 项目目录在 `projects/archive/` 即"已归档",不参与推算。

---

## 2. 9 条 INV（不变量）

### INV-1: topic.status = "selected" ⇔ ∃ project

```
topic.status = "selected"  ⇔  ∃ project s.t.
    project.topic_id = topic.id
    AND project.status != "cancelled"
```

**违反时**: 必修复——topic 永久卡在 selected 但 project 已 done / 永远没 project,无法被 08:30 推送再次选中(因为状态非 pending)。

**修复脚本**: topic-archiver（把孤儿 selected topic 改成 archived）

### INV-2: project.topic_id 存在 OR `_orphan=true`

```
project.topic_id 存在  OR  project._orphan = true  (二者必居其一)
```

**含义**: 每个 project 必须**有 topic 来源**或**显式声明孤儿**。

**违反时**: 视为数据不完整,需补 `_orphan=true` 或补 topic_id。

### INV-3: project.status ∈ {cancelled, published} OR 在 archive/ ⇒ topic → archived

```
project.status ∈ {cancelled, published}  OR  项目目录在 archive/
    ⇒  对应 topic(s).status = "archived"
```

**注意**: "项目在 archive/" 也触发,即使 status 不是 cancelled/published。`archive/` 是终态信号,等同于"项目生命周期结束"。

**违反时**: INV-3 违反 = 数据有 zombie topic,影响 08:30 推送池纯净度。

### INV-4: project.status = "selected" ⇒ 必须有 topic_id 或 topics[]

```
project.status = "selected"  ⇒  project.topic_id 存在 OR project.topics[] 非空
```

**含义**: "selected" 是用户表态,必须有 topic 来源。"无 topic 的 selected 项目"是非法状态。

### INV-5: dual-topics N 个 topic 状态一致

```
dual-topics 项目:
    ∀ t ∈ project.topics[]:
        t.status 一致  (要么都 selected,要么都 archived)
```

**含义**: dual-topics 是"绑定的 2 个 topic 共用 1 个 project",不能"一个继续一个取消"——结构上不允许,状态必须一致。

### INV-6: publish_log 含 platforms map

```
publish_log.json 必须含 "platforms": {wechat: {...}, douyin: {...}, xiaohongshu: {...}, zhihu: {...}, bilibili: {...}}
```

**含义**: v2.1 schema 强制要求 platforms map,5 平台架构基础。

**违反时**: 视为 v2.0 旧数据,需迁移。

### INV-7: review_log.json 含 4 个 gate 字段

```
review_log.json 必须含:
    "gates": {humanizer, copy-review, brand-cta, format}  4 项
```

**含义**: 4 个 gate 缺一不可,否则 review 流程"假阳性"。

**违反时**: review_log 是空壳,需要补齐 4 个 gate 的 PASS/FAIL。

### INV-8: agent 不得 archive project, 除非 published (NEW 2026-06-02)

```
agent 不得执行 mv <project> → archive/
    除非: project.status == "published"  (由 compute_status 推算)
    强制: archive_project.py --force <id> --reason "..."  (user 显式绕过)
```

**根因**: 2026-06-02 之前的 session(包括我)多次"擅自归档"未 published 项目——m3/hy/deepseek/lorai 全是 awaiting_publish 状态被移到 archive/。

**违反后果**: 项目从草稿箱/视频丢失,用户无法继续发布。

**修复**: archive_project.py 强校验 + reason 必填,user 必须主动决策 2 次。

### INV-9: 任何 platform 素材不得单独归档 (NEW 2026-06-02)

```
∀ platform:
    platform 素材 (02_images/03_video/05_publish/...) 不得单独移到 archive/
    即: 即使 wechat published, wechat 素材仍留原项目目录
    只有项目整体 archive 时,所有素材一起搬
```

**根因**: 项目"全平台 published"前,任何平台素材单独归档 = 破坏项目完整性。

**违反后果**: 项目状态残缺,审计困难,无法判断"5 平台都发了没"。

---

## 3. 推算规则详解

### project.status 推算函数签名

```python
def compute_status(
    proj_dir: Path,         # 用于 has_any_content 判断
    platforms: dict,         # {"wechat": {...}, "douyin": {...}, ...}
    project_type: str,       # "引流款" / "业务款" / "其他"
) -> "in_flight" | "awaiting_publish" | "published"
```

### 推算伪代码

```python
def compute_status(proj_dir, platforms, project_type):
    # 1. 收集 platform 状态
    statuses = [platforms[p].get("status", "pending") for p in PLATFORMS]

    # 2. 没有任何 platform 有动作 → in_flight
    #    (selected 由调用方根据 proj_dir 目录空判断)
    if all(s == "pending" for s in statuses):
        return "in_flight"

    # 3. 至少 1 platform 有动作 → 检查 required
    required = get_required_platforms(project_type)
    all_required_published = all(
        platforms.get(p, {}).get("status") == "published"
        for p in required
    )
    if all_required_published:
        return "published"
    return "awaiting_publish"
```

### required platforms 决定

```python
REQUIRED_PLATFORMS = {
    "引流款":             ["wechat"],
    "业务款":             ["wechat", "douyin", "xiaohongshu", "zhihu", "bilibili"],
    "业务款（种草款）":   ["wechat", "douyin", "xiaohongshu", "zhihu", "bilibili"],  # 同业务款
    "业务款_3平台":       ["wechat", "douyin", "xiaohongshu"],  # 显式 opt-in 裁剪版
    "其他":               ["wechat"],  # 兜底
}
```

### 业务款"全平台未发"是常态

业务款 5 平台 required,任何 1 个平台还 pending → awaiting_publish。这意味着业务款**默认长期 awaiting_publish**,直到 user 用 `record_manual_publish.py` 通知 5 平台都发了。

stale 检测（>30 天）会提醒 user"是否发了但忘了告诉我"。

---

## 4. archive 双触发器规则

### 触发器 A: project.status 终态

```
project.status 变为 cancelled 或 published
    ⇒  topic.status = "archived" (原子)
```

**这是数据完整性触发器**——`compute_status` 推算到终态时,必须**同步**改 topic。

### 触发器 B: 项目目录移到 archive/

```
user 主动 mv <project> → archive/
    OR  archive_project.py --force <id> --reason "..."
    ⇒  topic.status = "archived" (原子)
```

**这是 user-driven 触发器**——user 主动操作,agent **永远不主动** mv。

### 两个触发器的关系

- **A 是"自动"**（agent 写 publish_log 时,自动 cascade 改 topic）—— 但**只在 user 告知 platforms 都 published 后**触发
- **B 是"手动"**（user 决定 archive,但也 cascade 改 topic）—— 即使 status 还没到终态

**最稳**: B 必须, A 可选。**B 不可省**——user 决定 lifecycle 结束。

### 强校验 (archive_project.py 2026-06-02 新增)

```python
# 默认: 拒绝执行
$ python3 archive_project.py <project_id>
❌ Project status = "awaiting_publish", not "published"
❌ Archive denied. Use --force to override.

# 强制: 询问 + reason 必填
$ python3 archive_project.py --force <id> --reason "草稿未发,业务策略调整"
⚠️ 强制归档会写 reason 到 publish_log,确认继续? [y/N]: y
✓ 归档完成
```

**`--force` 必填 reason**,写入 publish_log 永久留档,审计可查"为什么强制归档"。

---

## 5. 28 项目 audit 实录（2026-06-02）

### audit 前现状（before migration）

| 字段 | 数量 | 占比 |
|---|---|---|
| 顶层 projects/ | 24 | 100% |
| archive/ 旧 session 错误归档 | 4 (m3/hy/lorai/deepseek) | 待回滚 |
| delivery/ 旧 zip 打包 | 15 | 4-5 月份旧模式 |
| .cancelled/ 旧版取消 | 1 (puyin) | 隔离机制 |

### publish_log schema 分布（4 种）

| schema | 数量 | 例子 | 特征 |
|---|---|---|---|
| v2 (D 任务) | 2 | m3, hy | 顶层 status + current + history |
| v2_legacy (flat) | 14 | renda-speech 等 | 顶层 status + content_id + thumb_media_id |
| v1 (entries[]) | 5 | rare-earth-leak 等 | `{"created": ..., "entries": []}` |
| unknown (wechat[] array) | 1 | 20260519_dual-topics | `{"wechat": [{...}, {...}]}` |
| `<no_log>` | 6 | dual-topics 空, deepseek/lorai/0513 旧 | 没 publish_log.json |

### type 字段分布

| 值 | 数量 | 来源 |
|---|---|---|
| 引流款 | 14 | 中文 |
| 业务款 | 5 | 中文 |
| 业务款（种草款） | 1 | 中文带括号 |
| business (英文) | 1 | m3 (category 字段) |
| growth (英文) | 1 | hy (category 字段) |
| <missing> | 6 | dual-topics 空 + 0526 deepseek/lorai |

### audit 后教训（5 条）

1. **m3/hy 真 awaiting_publish**: 公众号有真草稿（content_id 有效）
2. **24 旧项目假 awaiting_publish**: publish_log 标 draft_uploaded 但 review_log 空壳, 4-gate 从未真跑,实际从未上传过公众号
3. **2 个英文 type (m3/hy)**: notes 数组里写明"type: 引流款" / "type: 业务款",但 project_info 没 type 字段,只能读 category
4. **3 个空 dual-topics 失败**: 0524 + 0528 + 0519 实际无内容,publish_log 标假状态
5. **archive/ 误归档**: 4 个项目从 active 移到 archive/,都是未 published 状态

---

## 6. migration 实战

### 迁移命令

```bash
# dry-run (推荐先跑,看计划)
python3 Scripts/migrate_publish_log_to_v21.py --dry-run

# 实际迁移
python3 Scripts/migrate_publish_log_to_v21.py

# 验证(已迁完后,看是否所有 publish_log 都符合 v2.1)
python3 Scripts/migrate_publish_log_to_v21.py --validate
```

### 5 种源 schema 迁移规则

| 源 schema | 迁移方法 | 关键数据来源 |
|---|---|---|
| A. v2 (D 任务) | 从 `current.content_id` 抽 → platforms.wechat | current.content_id + 顶层 status |
| B. v2_legacy | 从顶层 `content_id` 抽 → platforms.wechat | 顶层 content_id + status |
| C. v1 (entries[]) | entries 空 → content_ready; entries 有 → draft_uploaded | entries[].media_id |
| D. unknown (wechat[] array) | 解析 wechat[] 数组抽 | wechat[].media_id (dual-topics 共享) |
| E. <no_log> + 有内容 | 新建 publish_log, content_ready | 03_video/ 是否存在 |

### 5 步迁移流程

1. 备份到 `/tmp/audit_backup_<timestamp>_v21/`
2. dry-run 打印计划 (26 待迁移 + 2 跳过)
3. 用户 review 计划 (此案例 0 跳过 = 全 OK)
4. 实际执行
5. jsonschema 验证 26/26 通过

### type 字段修正（顺带做）

- 读 `project_info.notes` 找 `type: X` 行
- 写 `info["type"] = X` 删 `info["category_en"]`（英文）
- 写 `_type_normalized_at` + `_type_normalized_by` 留档

**结果**: m3→引流款, hy→业务款。

### migration 后状态推算结果

| 状态 | 数量 | 含义 |
|---|---|---|
| awaiting_publish | 25 | 24 旧项目 + m3 + hy |
| cancelled | 3 | 3 个空 dual-topics |
| selected | 0 | 28 项目都已过 selected 阶段 |
| in_flight | 0 | 无"内容生成中"项目 |
| published | 0 | 无项目真正全平台 published |

---

## 7. Phase 路线（后续）

| Phase | 内容 | 状态 |
|---|---|---|
| 1a | compute_project_status.py 单一实现 | ✅ 已完成 |
| 1b | project-status-schema skill (本 skill) | ✅ 已完成 |
| 2a | publish_log v2.1 schema 升级 | ✅ 已完成 |
| 2b | 28 项目迁移 (26 成功 + 2 跳过) | ✅ 已完成 |
| 3 | regen_project_registry.py 升级 (5 平台进度列) | 待做 |
| 4a | upload_draft.py hook 写 platforms.wechat | 待做 |
| 4b | record_manual_publish.py 写 O1 触发器 | 待做 |
| 5a | cron draft/get 试探 (W2) | 待做 |
| 5b | cron stale 检测 (>30 天) | 待做 |
| 5c | cron W2 失败告警 | 待做 |
| archive | archive_project.py 强校验 | 待做 |
| topic | topic → archived cascade 触发器 | 待做 |

---

## 8. 永久教训（嵌入 skill）

### 教训 1: **"归档"≠"移到 archive/ 目录"**

**错误理解**: "归档" = mv 到 archive/ 目录
**正确理解**: "归档" = 项目生命周期结束, 已被 published 或 confirmed cancelled

**目录位置是结果,不是触发**——archive/ 是终态标志,不是任何"项目做完了"的处理动作。

### 教训 2: **compute_status 必须是单一实现**

m3 案例 + 28 项目 audit 证明: **多份算法必漂移**。

任何读 publish_log 的脚本必须 `import compute_project_status`,**不要自己写**。原因:
- 一个项目 28 个 status 字段全脏 = 多个地方各算一份的代价
- 28 个项目被推算成"in_flight"但实际"awaiting_publish" = 误判
- 修了 1 个算法后,其他 4 份算法还是旧的 → 永远追不上

### 教训 3: **publish_log 假阳性是常态**

24 旧项目都有这问题: publish_log 标 draft_uploaded, **但实际从未真上传**(review_log 空壳, 4-gate 没跑)。

**修复方案不是"补 review"**——这些项目已交付,补 review 是过度劳动。
**正确处理**: 
1. compute_status 推算"事实"(内容在 03_video/ 就算 content_ready)
2. publish_log 假状态留在原文件作为"历史快照"
3. migration 脚本自动生成正确 platforms map

### 教训 4: **agent 不应主动 archive**

任何 session 自觉不主动 mv 项目到 archive/。理由:
- user 决定 lifecycle 结束,不是 agent
- INV-8 强校验: 必须 published 才能 archive, agent 不该伪造 published
- --force 是 user 工具, agent 不用

### 教训 5: **dual-topics 是结构约束**

2 topic 共用 1 project, INV-5 强制状态一致。

agent 不要尝试"拆 project"或"partial cancel"——结构不支持,会破坏数据。

---

## 9. 触发本 skill 的场景

1. 任何 session 涉及"项目状态"判断时（read publish_log.json）
2. 任何 session 涉及"archive"操作时（mv 项目到 archive/）
3. 任何 session 涉及 28 个旧项目状态分类时
4. 任何"为什么这个项目在 archive/?"的疑惑
5. 任何新项目要写 publish_log.json
6. 任何 upload_draft.py 调用
7. 任何 5 平台发布的项目
8. 任何项目迁移 (v2.0 → v2.1)
9. 任何 cron 要 cascade 改 topic.status
