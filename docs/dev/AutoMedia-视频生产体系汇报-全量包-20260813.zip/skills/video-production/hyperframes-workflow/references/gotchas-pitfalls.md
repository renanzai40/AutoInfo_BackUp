# 注意事项（踩坑记录）

## 注意事项（踩坑记录）

### V6 Gate 八项检查（2026-07-05 扩展至 8 项）

> 完整规范参见 `references/composition-qa-rules.md`。V6 Gate 自动检查由 `scripts/check_composition_qa.py` 执行。

| 编号 | 检查项 | 说明 |
|------|--------|------|
| V6-1 | 字号 ≥ 20px | `component-patterns.md` 中所有组件字号已更新，新增 composition 时遵守 |
| V6-2 | 前景元素距上边 ≥ 300px | 每场景第一个文本元素不得小于 300px，同场景其他元素同步偏移 |
| V6-3 | 前景元素距下边 ≥ 300px | 底部元素 `top: ≤ 1620px`（1920 - 300） |
| V6-4 | `class` 属性不重复 | 禁止 `class="clip" class="body-text"` 重复属性，必须合并为 `class="clip body-text"` |
| V6-5 | CSS 分隔符用 `:` | 禁止 `top=660px` 语法，必须用 `top:660px` |
| **V6-6** | 每个 `class="clip"` 必须有 `data-start` | **subagent 高频遗漏 → 全部元素同时出现堆叠** |
| **V6-7** | 每个 `class="clip"` 必须有 `data-duration` | 缺时长则 clip 无法按时消失 |
| **V6-8** | 每个 `class="clip"` 必须有 `data-track-index` | 缺分层索引则图层无法叠加/分离 |

**V6-6/7/8 的典型拦截场景**：subagent 写的 composition 中所有视觉 clip 元素都有 `class="clip"` 但缺少 `data-start`/`data-duration`/`data-track-index`（只给了 CSS 定位和字号），导致所有场景文字同时渲染堆叠。hyperframes lint 只对音频元素报 `media_missing_data_start`，对视觉 clip 静默通过。V6-6/7/8 补上了这个缺口。

**自动执行**：`pre_render_hook.sh` 在 render 前自动运行 `check_composition_qa.py`，通过后自动签名 V6。失败则阻止渲染。如果使用 shell 脚本绕过了 hook（见 §pre_render_hook 绕过方案），必须在 render 前手动跑 `python3 ~/.hermes/profiles/content/scripts/check_composition_qa.py <index.html>`。

### Composition HTML 格式 — 高频错误（2026-06-13 新增）

subagent 生成的 composition HTML 经常有以下格式错误，导致视频渲染后无文字/无效果：

| 错误 | 症状 | 正确写法 |
|------|------|---------|
| ❌ `<template id="hook-template">` 包裹 | 子 composition 不渲染，视频空白 | 完整 HTML 文档（`<!DOCTYPE html>`） |
| ❌ `<clip src="..." start="..." duration="...">` | lint 不报错但 clip 不渲染 | `<div class="clip" data-start="..." data-duration="..." data-track-index="..." data-composition-src="...">` |
| ❌ 元素缺少 `class="clip"` | 文字/图形不渲染，只有背景 | 每个可见元素必须有 `class="clip"` |
| ❌ 同一元素出现两个 `class` 属性（如 `class="clip"` 换行后又写 `class="body-text"`） | 浏览器忽略第二个 class，样式/字号不生效，文字回退到默认 ~16px | 合并到同一个 class 属性（`class="clip body-text"`），或用 inline `style="font-size:…"` 替代 |
| ❌ 元素缺少 `data-track-index` | lint error `clip_missing_track_index` | 每个 clip 元素必须有唯一且不重叠的 `data-track-index` |
| ❌ CSS `opacity: 0` + GSAP `from({opacity:0})` | 元素全程不可见 | 见下方 GSAP opacity 陷阱 |
| ❌ 相邻 clip 浮点重叠（如 19.99+10.75=29.990000000002） | lint error `overlapping_clips_same_track` | 计算完所有场景 duration 后统一减 0.01s：scene["duration"] = max(0.1, d - 0.01) |
| ❌ 根 div 缺 `data-composition-id` | lint error `root_missing_composition_id` | 根元素加 data-composition-id="main" |
| ❌ 根 div 缺 `data-width` / `data-height` | lint error `root_missing_dimensions`，视频分辨率异常 | `data-width="1080" data-height="1920"`（竖屏）或 `data-width="1920" data-height="1080"`（横屏） |
| ❌ 根 div 缺 `data-start="0"` | lint error `root_missing_start`，渲染阻塞 | 根 div 必须有 `data-start="0"`，不要用 `data-hf-version` 等非标准属性替代 |
| ❌ 根 div 上有 `data-hf-version` 等非标准属性 | lint 不报错但属性无实际作用，干扰格式一致性 | 根 div 标准属性仅：`data-composition-id` + `data-start="0"` + `data-width` + `data-height` + `data-duration` |
| ❌ GSAP timeline 未注册到 `window.__timelines` | lint error `missing_timeline_registry`，timeline 不执行，动画无效果 | 脚本末尾加 `window.__timelines = window.__timelines || {}; window.__timelines["main"] = tl;`，key 与 `data-composition-id` 一致 |
| ❌ CSS font-family 使用具名中文字体（`PingFang SC`, `Microsoft YaHei`）但无 `@font-face` | lint error `font_family_without_font_face`，headless Chrome fallback 到默认字体 | 用 `system-ui, sans-serif` 替代。headless Chrome 有内建 CJK fallback，排印可靠且无 lint error |
| ❌ `<audio>` 元素完全缺失 | 渲染日志 `hasAudio: false`，视频无声。subagent 委托编写时极易漏掉 | 根 composition 必须包含 `<audio class="clip" data-start="0" data-duration="..." data-track-index="0" src="assets/audio/narration.mp3" id="narration-audio">`。subagent 返回后必 grep `<audio` 确认存在 |
| ❌ 根 div 缺 `data-composition-id` | lint error `root_missing_composition_id`，渲染可能空白 | `{#root 或等价根元素} data-composition-id=&#34;main&#34;` — 必须与 `window.__timelines[&#34;main&#34;]` 的 key 一致 |
| ❌ 根 div 缺 `data-width` / `data-height` | lint error `root_missing_dimensions`，视频分辨率异常 | `data-width=&#34;1080&#34; data-height=&#34;1920&#34;`（竖屏）或 `data-width=&#34;1920&#34; data-height=&#34;1080&#34;`（横屏） |
| ❌ 根 div 缺 `data-start=&#34;0&#34;` | lint error `root_missing_start`，渲染阻塞 | 根 div 必须有 `data-start=&#34;0&#34;`（不要用自定义非标准属性如 `data-hf-version` 替代） |
| ❌ 根 div 上有 `data-hf-version` 等非标准属性 | lint 不报错但属性无实际作用 | 根 div 的标准属性是 `data-composition-id` + `data-start=&#34;0&#34;` + `data-width` + `data-height` + `data-duration`，去掉其他自定义属性 |
| ❌ GSAP timeline 未注册到 `window.__timelines` | lint error `missing_timeline_registry`，timeline 不执行，动画无效果 | 脚本末尾加 `window.__timelines = window.__timelines || {}; window.__timelines[&#34;main&#34;] = tl;`，key 必须与 `data-composition-id` 一致 |
| ❌ CSS font-family 使用具名字体（`PingFang SC`, `Microsoft YaHei`）但无 `@font-face` | lint error `font_family_without_font_face`，headless Chrome fallback 到默认字体 | 用 `system-ui, sans-serif` 替代具名中文字体。headless Chrome 有内建 CJK fallback，排印可靠且无 lint error |
| ❌ `<audio>` 元素完全缺失 | `hasAudio: false`（渲染日志可见），视频无声。subagent 委托编写时极高频遗漏 | 根 composition 必须包含 `<audio class="clip" data-start="0" data-duration="..." data-track-index="0" src="assets/audio/narration.mp3" id="narration-audio">`。subagent 返回后必 grep `<audio` 确认存在 |
| ❌ 所有视觉 clip 同时缺少 `data-start`、`data-duration` 和 `data-track-index` | 所有场景元素同时渲染堆叠，画面混乱。hyperframes lint 不报错，V6-6/7/8 前的 `check_composition_qa.py` 也查不出来（仅 2026-07-05 加入检查） | 每个带 `class="clip"` 的元素必须有这三属性。推荐场景容器布局：外层场景 div 带 class="clip" + 三属性，内层文字元素不带 class="clip" |

**自检方法**：渲染前快速扫描 composition HTML：
```bash
grep -c '<template' compositions/*.html  # 应为 0
grep -c '<clip ' index.html              # 应为 0（<clip> 标签禁止）
grep -c 'class="clip"' index.html compositions/*.html  # 每个文件应 ≥ 1
```

### 渲染后视觉 QA：像素亮度检查

当视频渲染完成但不确定文字是否可见时，用像素亮度法快速验证：

```bash
ffmpeg -y -ss 5 -i out/video.mp4 -frames:v 1 -q:v 2 /tmp/qa_frame.jpg
python3 -c "
from PIL import Image
img = Image.open('/tmp/qa_frame.jpg')
pixels = list(img.getdata())
bright = sum(1 for p in pixels if sum(p) > 200)
total = len(pixels)
ratio = bright/total*100
print(f'Bright pixels: {ratio:.1f}%')
print('PASS' if ratio > 0.5 else 'FAIL — 可能空白视频')
"
```

- **有文字视频**：bright ratio > 0.5%（测试 1.3-2.3%）
- **纯背后视频**：bright ratio ≈ 0.0%（仅 JPEG 压缩噪声）
- **阈值**：< 0.5% → 视频可能无内容，需要检查 composition 格式

### Browser
- HyperFrames 需要 `chrome-headless-shell`，版本 131+
- WSL 上可以从 Playwright 的缓存 symlink（`scripts/fix-chrome.sh`）
- WSL 低内存（<8GB）下 **用 `bun x` 代替 `npx`**，后者内存管理差
- 渲染超时/崩溃时加 `--quality draft` 减少编码压力

### Tracks
- 同一 track-index 的 clips 不能有时间重叠（否则 lint error）
- 根 composition 的 timeline 是空的（场景由子 composition 的 timeline 控制）
- 根 composition 只控制子场景的 `data-start` 和 `data-duration`

### Composition ID 匹配（关键）
- **根 composition 的 `data-composition-id`** 必须和子 composition 的 `data-composition-id` + `window.__timelines["id"]` 完全一致
- 否则子场景 timeline 不会注册（poll 超时 45s），动画不播放
- 例：根 `data-composition-id="hook"` → 子 composition 也必须 `data-composition-id="hook"` → timeline 注册 `window.__timelines["hook"]`
- lint 不检查 ID 匹配，只能通过 render 日志确认：`pollSubCompositionTimelines complete (180ms)` 为正常，45s 超时为不匹配

### Inline Clip 模式：多 clip 场景的 track-index 分配（2026-06-22 更新）

**🔥 核心规则**：同一 `data-track-index` 上的 clip **不能有时间重叠**。这条规则决定了 track-index 的分配策略。

#### 场景 A：每场景只有 1 个 clip（简单视频）

所有场景共用同一 `data-track-index`，时间不重叠即可：

```html
<!-- ✅ 简单场景：每场景 1 个 clip，共用 track-index="1" -->
<div id="s1" class="clip" data-start="0" data-duration="5.5" data-track-index="1">...</div>
<div id="s2" class="clip" data-start="5.5" data-duration="6.0" data-track-index="1">...</div>
```

#### 场景 B：每场景有多个 clip（常见——背景+文字+数据卡片）

**每个 clip 元素需要自己的 `data-track-index`**。同一场景内的多个视觉元素（背景、标题、数据卡片等）有相同的 `data-start`/`data-duration`，如果共用同一 track-index 会触发 `overlapping_clips_same_track`。

```html
<!-- ✅ 正确：同一场景的每个视觉元素有独立的 track-index -->
<!-- 场景 1（0-5.5s） -->
<div id="s1-bg" class="clip" data-start="0" data-duration="5.5" data-track-index="1">...</div>
<div id="s1-title" class="clip" data-start="0" data-duration="5.5" data-track-index="2">...</div>
<div id="s1-desc" class="clip" data-start="0" data-duration="5.5" data-track-index="3">...</div>

<!-- 场景 2（5.5-11.5s）—— track-index 继续递增，不重复 -->
<div id="s2-bg" class="clip" data-start="5.5" data-duration="6.0" data-track-index="4">...</div>
<div id="s2-data" class="clip" data-start="5.5" data-duration="6.0" data-track-index="5">...</div>
```

**关键**：track-index 在整个文件中必须**全局唯一且不重叠**。不要在不同场景复用同一索引——它们是叠加图层，不是时间槽位。

**自检**：grep `data-track-index` 确认每个 clip 有唯一值：
```bash
grep -oP 'data-track-index="\K\d+' index.html | sort -n
# 检查是否有重复数字
```

**原理**：不同 track-index 的 clip 视为可叠加图层。同一 track 的 clip 独占时间窗口。浮点重叠（19.98 结束 + 19.98 开始）时 lint 报 `overlapping_clips_same_track`。**安全间距**：前 clip data-duration 减 0.01s。

### GSAP 选择器陷阱：嵌套布局时不用 `:first-child`/`:last-child`（2026-06-17 实测）

当场景元素嵌套在布局 wrapper（如 `.layout-2`）内时，GSAP 目标不能用 `:first-child` 或 `:last-child`。wrapper 内的混合子元素（卡片、badge、说明 div）改变 `:last-child` 匹配目标，GSAP 报 `target not found`。

```javascript
// ✅ 正确：类选择器 + stagger
tl.from("#s3 .compare-card", { opacity: 0, y: 20, duration: 0.5, stagger: 0.3 }, 19.98);
// ❌ 错误：在嵌套布局中不可靠
tl.from("#s3 .compare-card:first-child", { ... }, 19.98);
```

**安全做法**：一律用类选择器 + stagger。精确控制时用 `:nth-child(n)` 代替 `:first-child`。

### 字幕烧录：drawtext 中 `%` 需三级转义（2026-06-17 实测）

ffmpeg drawtext 中 `%` 是特殊字符（触发表达式扩展），SRT 含 `%`（如"30-40%"）时静默失败（exit code=0 但字幕不可见）。

**转义链**：`\\\\%`(文件) → `\\%`(字符串) → `\%`(滤镜) → `%`(输出)

```python
# burn_subtitles.py 中修正
txt = txt.replace('%', '\\\\%')
```

**自检**：烧录后 `%` 字幕不可见 → 查 ffmpeg 日志 `Stray % near`。

### GSAP - opacity 陷阱（易踩）—— 高频 #1 lint error

**铁律**：`gsap.from({opacity: 0})` 配合 CSS 不能有 `opacity: 0`

```css
/* ❌ 错误：CSS 设 opacity: 0 + GSAP from({opacity:0}) → 全程不可见 */
.tag { opacity: 0; }
```
```js
tl.from(".tag", { opacity: 0, y: 10, duration: 0.4 }, 0); // from(0)→CSS(0) = 不动
```

```css
/* ✅ 正确：CSS 不设 opacity，让 GSAP 控制进入 */
.tag { }
```
```js
tl.from(".tag", { opacity: 0, y: 10, duration: 0.4 }, 0); // from(0)→CSS(1) = 淡入
```

**原理**：`gsap.from()` 从指定值动画到 CSS 计算值。如果 CSS 也是 0，动画就是 0→0，元素永远不可见。

**修复方法（逐文件）**：
1. 移除 CSS 的 `opacity: 0`
2. 如需提示浏览器优化 opacity 动画，用 `will-change: opacity, transform` 替代
3. `gsap.from()` 会从 opacity:0 动画到 CSS 默认值 (1)

```css
/* ✅ 正确 */
.tag { will-change: opacity, transform; }
```
```js
tl.from(".tag", { opacity: 0, y: 10, ... }, 0); // from(0)→CSS(1) = 淡入
```

#### 🔥 批量修复配方（subagent 生成后 lint 报 30+ 个 `gsap_from_opacity_noop` 时用）

当 subagent 生成的 5-scene compositions 有大量 opacity 冲突（实测一个视频可出 33+ 个 error），逐个文件手动修太慢。用 Python re.sub 批量扫所有 composition 文件：

```python
import re, os

comp_dir = "compositions/"
for fname in sorted(os.listdir(comp_dir)):
    if not fname.endswith('.html'):
        continue
    path = os.path.join(comp_dir, fname)
    orig = open(path, encoding='utf-8').read()
    content = orig
    
    # 修复1：从 CSS class 定义中移除 opacity: 0
    content = re.sub(r'(\.\w[\w-]*\s*\{[^}]*?)opacity:\s*0\s*;?\s*', r'\1', content)
    
    # 修复2：从 inline style 中移除 opacity: 0
    content = re.sub(r'style="[^"]*?opacity:\s*0\s*;?\s*[^"]*?"', 
        lambda m: 'style="' + re.sub(r'opacity:\s*0\s*;?\s*', '', m.group(0)[7:-1]).strip().strip(';').strip() + '"', 
        content)
    # 清理空的 style=""
    content = re.sub(r'\s+style=""', '', content)
    
    if content != orig:
        open(path, 'w', encoding='utf-8').write(content)
        print(f"✅ {fname}: fixed")

# 修完后必重新 lint 确认 0 error
```

⚠️ 这个 regex 是激进修剪——它会移除 CSS 块和 inline style 中所有 `opacity: 0`，包括那些不是 GSAP 冲突的部分。修完后**必须重新 lint** 确认 error 降到 0。如果误伤了需要 persistent opacity: 0 的元素（如 ghost text），手动恢复。

**检查方法**：HyperFrames lint 会报 `gsap_from_opacity_noop`。可靠的自我检查：`grep -rn "opacity: 0" compositions/` 确认 CSS 中没有 opacity: 0。

### 中文排版
- 使用系统字体族（`system-ui`）或显式 `@import` Google Fonts
- Noto Serif SC 等中文 Google Fonts 在 headless Chrome 中可能未自动加载
- 安全选择：系统字体 + 显式 `@font-face` / 内联字体样式

### 渲染时间参考（WSL, 1080×1920, draft quality）

| 视频时长 | 场景复杂度 | 渲染耗时 | 文件大小 |
|---------|-----------|---------|---------|
| 56s | 简单（大字+数据块） | ~2min | ~1.3MB |
| 56s | 复杂（多元素+渐变+对比卡） | ~5min | ~3.0MB |
| 30s | 简单 | ~1min | ~0.7MB |

50-60s 的中等复杂度视频，draft quality 渲染约 2-5 分钟。standard quality 约 2-3x 更慢。

### 音视频时长匹配验证（post-render 必跑）

渲染完成后验证视频时长 ≈ 音频时长。差值 < 0.1s 为合格，否则音画不同步：

```bash
VIDEO_DUR=$(ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 out/video.mp4)
AUDIO_DUR=$(ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 assets/audio/narration.mp3)
DIFF=$(echo "$VIDEO_DUR - $AUDIO_DUR" | bc | tr -d '-')
echo "diff: ${DIFF}s"
if (( $(echo "$DIFF > 0.1" | bc -l) )); then echo "❌ 音画时长差 > 0.1s"; else echo "✅ 时长匹配"; fi
```

### Subagent 委托 Composition 编写（AutoMedia 集成模式）

在 AutoMedia 双话题生产流水线中，HyperFrames composition 编写可以委托给 subagent 并行执行：

**委托模式**：
```
1. 主 agent 计算 scene_times.json（TTS 时长 → 按字符比例分配场景时长）
2. 主 agent 创建项目骨架（package.json / meta.json / hyperframes.json）
3. 并行委托 subagent：每个话题一个 subagent，负责写所有 composition HTML
4. subagent 返回后做 verify + 批量修复 opacity 冲突 + re-lint → render
```

**注意**：
- 5 个场景（含复杂 CSS+GSAP）的 composition 编写在 subagent 中可能接近 600s 超时。subagent timeout 后**先 verify 文件落地状态**（文件通常已写完），不要立即重试。
- **🔥 subagent 经常遗漏 `<audio>` 元素**——subagent 编写 index.html 时几乎总是只写视觉场景 clip，完全跳过音频轨道。主 agent 必须在 subagent 返回后 grep 确认 `<audio` 存在。缺失时手动添加：`<audio class="clip" data-start="0" data-duration="...total_sec..." data-track-index="0" src="assets/audio/narration.mp3" id="narration-audio">`
- **子 agent 编写 composition 必须遵守的硬约束（2026-06-25 新增）**：
  1. 所有视觉元素使用**单一** `class="clip className"` 属性，禁止两个 `class=` 属性
  2. CSS `style` 属性中属性值用 `:` 分隔，禁止用 `=`（如 `top:660px` 不是 `top=660px`）
  3. 前景元素的 `top:` 值必须 ≥ 300px，同场景中后续元素相对间距保持一致
  4. `font-size:` 值必须 ≥ 20px
  5. **每个 `class="clip"` 元素必须有 `data-start` + `data-duration` + `data-track-index`**（V6-6/7/8，2026-07-05 新增，缺失则 render 被 V6 Gate 阻止）
  6. **垂直分布规则（2026-07-05 新增，防内容挤堆）**：每个场景的内容应均匀利用画布（1080×1920）垂直空间：
     - 首元素 `top:` **≥ 350px**（距顶留白）
     - 相邻元素之间的**垂直间距 ≥ 120px**（计算：`next.top − (prev.top + prev.font-size)`）
     - 末元素底部 `top + font-size` **≥ 768px**（画布高 1920 的 40%），防止全部挤在顶部
  7. 完成后主 agent 必跑 `python3 scripts/check_composition_qa.py index.html` 确认

> **推荐场景容器模式**（2026-07-05 总结）：每场景用一个外层 div 带 `class="clip" data-start="..." data-duration="..." data-track-index="..."` 做背景容器，内层文字元素**不带** `class="clip"`（只做普通定位）。这样外层的 clip 元数据驱动整个场景的显示/隐藏，内层元素随容器自动出现消失，GSAP 只控制入场动画。比起每个文字元素都单独带 clip 属性，容器模式更简洁、track-index 消耗更低、且不易漏属性。
- 主 agent 必须负责 lint → 修复 → re-lint → render 的 QA 循环，subagent 不跑 render。
- 字体警告（`font_family_without_font_face`）可以通过用 `system-ui,sans-serif` 替代具名中文字体来消除，但即使保留警告也不阻塞渲染。

### 性能
- 单 composition 最大 60s / 30fps（推荐）
- 子 composition 推荐 5-15s 每个
- 复杂动画（多元素同时运动）使用独立的 track-index
