# Composition QA Rules (V6 Gate)

All rules are enforced by `scripts/check_composition_qa.py` via Gate V6.
The pre-render hook auto-runs the check and blocks render on failure.

---

## V6-1: Font-size ≥ 20px (absolute minimum)

| Tier | Minimum | Purpose | Example |
|------|---------|---------|---------|
| Main content | **≥ 34px** | Body text, descriptions, value props | "商用无限制 · 本地离线部署" (34px) |
| Badge / tag / label | **≥ 28px** | Section headers, category markers, footnotes | `⚡ IPO 前哨` (28px) |
| Component patterns | **≥ 20px** | Labels, stat badges, card footers, VS badges | `.kicker`, `.tag`, `.stat-label` |

---

## V6-2: Foreground element top ≥ 300px

- Every non-background `position:absolute` element with a `top:` value must be ≥ 300px.
- When adjusting the topmost element in a scene, all other elements in that scene **shift together** (same offset).
- **Background exclusion**: elements with `top:0; left:0; width:1080px; height:1920px` (or 1920×1080) are treated as full-screen backgrounds and skipped.

---

## V6-3: Foreground element top ≤ 1620px (bottom margin ≥ 300px)

- Same background-exclusion logic as V6-2.
- 1620px = 1920 - 300 (safe from notch/cutout).

---

## V6-4: No duplicate HTML attributes

```html
<!-- ❌ WRONG: second class= is silently ignored -->
<div class="clip" class="body-text">...</div>
<!-- ✅ CORRECT: merge into single class attribute -->
<div class="clip body-text">...</div>
```

Also checked for duplicate `id`, `style`, `data-start`, `data-duration`, `data-track-index`.

---

## V6-5: No CSS syntax errors (`=` instead of `:`)

```html
<!-- ❌ WRONG: top=660px is invalid CSS -->
<div style="position:absolute;top=660px;left:80px;">
<!-- ✅ CORRECT -->
<div style="position:absolute;top:660px;left:80px;">
```

---

## V6-6 / V6-7 / V6-8: Clip metadata attributes (2026-07-05 新增)

**V6-6**: Every element with `class="clip"` must have `data-start=""`.
**V6-7**: Every element with `class="clip"` must have `data-duration=""`.
**V6-8**: Every element with `class="clip"` must have `data-track-index=""`.

**Why**: Subagent-written compositions consistently add `class="clip"` to visual elements but omit the three HyperFrames-required timing attributes. Without these, all clips render simultaneously at t=0 and stay visible for the full duration, causing all scene content to stack. HyperFrames' own `lint` catches `media_missing_data_start` for audio clips but is silent on visual clips missing these attributes.

**Recommended fix — scene container pattern**: wrap each scene in an outer `<div class="clip" data-start="..." data-duration="..." data-track-index="...">` that holds inner text elements (which don't need `class="clip"`). The outer clip drives show/hide for the entire scene.

**History**: 2026-07-05 — both zuckerberg and shengshu compositions had all visual clips missing data-start/duration/track-index. Vidu S1 rendered with all scenes stacked.

---

## Vertical Distribution Rule (2026-07-05 新增，subagent 委托约束)

Not a V6 Gate check (hard thresholds false-positive on different scene types), but a hard constraint in subagent delegation context.

**Three rules per scene**:
1. First element `top:` **≥ 350px**
2. Adjacent elements' vertical gap **≥ 120px** (computed: `next.top - (prev.top + prev.font-size)`)
3. Last element's bottom edge `top + font-size` **≥ 768px** (40% of 1920 canvas height) — prevents clustering at the top

**Why not a code gate**: Scene types vary — a data-display scene centering "$1450亿" at 400px is valid, while a list scene should stretch further down. A hard 40% threshold would false-positive on valid layouts.

**History**: 2026-07-05 — zuckerberg S5 tag/title/subtitle clustered in a 298px band. Fixed by spreading from 420/520/680 to 360/520/780.

---

## Subagent Composition Checklist

Include ALL of these when delegating composition writing:

1. Single `class="clip className"` — never two `class=`
2. CSS uses `:`, never `=`
3. Foreground `top:` ≥ 300px; shift siblings together
4. All `font-size:` ≥ 20px
5. **Each `class="clip"` MUST have `data-start` + `data-duration` + `data-track-index`** (V6-6/7/8)
6. **Vertical distribution**: first top ≥ 350px, adjacent gap ≥ 120px, last bottom ≥ 768px
7. After subagent returns: `python3 check_composition_qa.py index.html`
