# QA 检核

### QA 检核

#### 渲染前确认（lint 不检查的）

- [ ] 根 composition 有 `window.__timelines["main"]` 注册（即使空的）
- [ ] `<audio>` 有 `id` 属性（eg: `id="narration-audio"`），否则渲染无声
- [ ] 每个子场景 host `<div>` 的 `data-composition-id` 与子 composition 的 `data-composition-id` 完全一致
- [ ] 子场景的 `window.__timelines["id"]` 与该场景的 `data-composition-id` 一致
- [ ] `gsap.from()` 的参数不与 CSS 初始值相同（否则动画不动）
- [ ] **所有场景使用同一套 `:root` CSS 变量**（没有某个场景混入不同设计系统的色值/字体/间距）
- [ ] **font-family 用 `system-ui, sans-serif`** 而非具名中文字体（`PingFang SC` 等会触发 `font_family_without_font_face` lint error）
- [ ] **每个 `class="clip"` 元素都有 `data-start` + `data-duration` + `data-track-index`**——V6 Gate 自动检查，但如果在 shell 脚本绕过模式下手动渲染，需主动跑 `python3 ~/.hermes/profiles/content/scripts/check_composition_qa.py index.html` 确认

#### 渲染日志确认

| 日志模式 | 意义 |
|---------|------|
| `pollSubCompositionTimelines complete (180ms)` | ✅ 正常，ID 匹配 |
| `pollSubCompositionTimelines complete after 45000ms` | ❌ ID 不匹配，动画不播放 |
| `hasAudio: false` | ❌ `<audio>` 元素缺失或配置错误，视频无声。高频隐患：subagent 委托编写 composition 时几乎总是漏掉音频轨道。修复：`grep '<audio' index.html` 确认存在，缺失时手动添加 |

#### 终版检查

- [ ] 视频时长与预期一致（±5s）
- [ ] 分辨率 1920×1080 或 1080×1920
- [ ] 字幕完整显示（无截断、无乱码）
- [ ] 动画正常播放（无卡顿、无白屏）
- [ ] 数字/数据正确显示
- [ ] 音频与画面同步（无超前/滞后）
- [ ] CTA 是否出现
- [ ] **场景-旁白覆盖**：每个场景的视觉元素覆盖了对应 narration 的全部关键点（逐句对照检查）
- [ ] **视觉布局多样性**：相邻场景布局不同，5 段视频 ≥ 4 种布局（对照 `references/visual-layouts.md` 的类型编号检查）

**反 AI 视觉指纹检核**（一票否决）：
- [ ] ❌ 紫粉/蓝紫对角渐变背景 + 白色文字
- [ ] ❌ 圆角卡片 + 彩色左边框 + 渐变按钮
- [ ] ❌ emoji 当图标（缺素材用 placeholder card 标注尺寸）
- [ ] ❌ 所有场景同一种入场动画
- [ ] ❌ 引用不存在的数据/Logo/"X 百万用户"

---
