# 预设计：布局序列校验（写 composition 前必跑）

### 预设计：布局序列校验（写 composition 前必跑）

选完主题和布局类型后，在写 HTML 前做序列校验：

```python
layout_seq = [6, 4, 2, 1, 5]  # 替换为你的 5 个布局类型编号
unique = set(layout_seq)
assert len(unique) >= 4, f"❌ 只有 {len(unique)} 种不同布局，需要 ≥4"
for i in range(len(layout_seq) - 1):
    assert layout_seq[i] != layout_seq[i+1], f"❌ S{i+1} 和 S{i+2} 布局重复"
print(f"✅ 布局序列通过: {len(unique)} 种, 相邻无重复")
```

每种布局类型的 CSS 骨架从 `references/visual-layouts.md` 复制。
