# Phase 3b：写 compositions

### Phase 3b：写 compositions

> **场景视觉多样性规则**：一段视频中相邻场景不得使用同一种视觉布局。5 段视频至少使用 4 种不同布局。详见 `references/visual-layouts.md`（6 种布局类型 + CSS 骨架 + 动画风格）。
>
> 具体分配方案见 `references/5-scene-layout-assignment.md`（引流款/业务款/教程的默认布局顺序 + 校验代码）。
>
> 在 outline 阶段就要为每个场景指定视觉布局类型，写 composition 时按布局类型对应的骨架写，而不是每次都用同一个模板改文字。
