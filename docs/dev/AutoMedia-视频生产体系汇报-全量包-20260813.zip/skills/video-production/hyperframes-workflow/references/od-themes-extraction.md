# Open Design 设计系统 → HyperFrames 主题提取工作流

**来源**：2026-06-13 HyperFrames 美学增强（OpenCode Go 推广视频）

## ⚠️ 实用性评估

本工作流存在两个问题：

1. **启动成本高**：需要启动 Node daemon（占用 ~300MB RAM）+ 依赖 Node 24 编译产物。若 daemon 挂了，提取工作流直接用不了。
2. **回报有限**：OD 的 150 个设计系统本质是 Web 设计系统——按钮/输入框/hover 状态等视频不需要的能力占 80%。真正对视频有用的部分（色值+字体+间距规则），手动写 HTML CSS 也能达到同等效果。

**结论**：OD 主题是有用的配色参考源，但不值得维护常驻 daemon 和 MCP 连接。需要新配色时，开一次 daemon 取一批就行，用完关掉。

现有 8 个 OD 主题（`references/od-themes.json`）已足够覆盖大部分视频类型。如确需新主题，按以下流程。

## 提取流程

### 1. 启动 Open Design daemon

```bash
curl -s http://127.0.0.1:40257/api/health
# 期望 {"ok":true,"version":"0.7.0"}

# 如果没跑，后台启动
cd /mnt/d/Hermes-Workspace/99-Tools/open-design && \
OD_PORT=40257 OD_RESOURCE_ROOT=/mnt/d/Hermes-Workspace/99-Tools/open-design \
/home/renanzai/.local/node/node-v24.15.0-linux-x64/bin/node \
apps/daemon/dist/cli.js &
```

### 2. 列出可用设计系统

```bash
curl -s http://127.0.0.1:40257/api/design-systems | python3 -c "
import json, sys; data = json.load(sys.stdin)
for ds in data['designSystems']:
    print(f\"{ds['id']:30s} | {ds['title'][:30]:30s}\")"
```

### 3. 查看单个设计系统的完整描述

```bash
curl -s http://127.0.0.1:40257/api/design-systems/<id> | python3 -m json.tool
```

body 字段包含完整文档（色彩用法、排版规则、组件风格）。

### 4. 提取 CSS 变量 → HyperFrames 主题

| 设计系统字段 | → CSS 变量 | 提取策略 |
|-------------|-----------|---------|
| Background | `--bg` | body 或 swatches[0] |
| Surface | `--surface` | body 或 swatches[1] |
| Foreground | `--text-1` | body 或 swatches[2] |
| Muted | `--text-2` | body |
| Accent (primary) | `--accent` | body 或 swatches[3] |
| Accent (secondary) | `--accent-2` | body 或派生 |
| Display/heading font | `--font-display` | 排版规则段 |
| Body font | `--font-sans` | 排版规则段 |
| Scale/radius | `--radius/sm/lg` | 组件规则段 |

### 5. 输出格式

写入 `references/od-themes.json`，与 `theme-palettes.json` 格式一致：

```json
{
  "od-linear": {
    "name": "Linear — Open Design",
    "dark": true,
    "mood": ["dark", "tech", "clean"],
    "description": "深蓝暗色，干净利落。适合开发者工具/技术产品视频",
    "variables": { "--bg": "#1C1C24", "--surface": "#23252A", ... }
  }
}
```

### 6. 命名规则

前缀 `od-` 表示来源为 Open Design，ID 用设计系统 id（小写、连字符），如 `od-stripe`、`od-linear`、`od-claude`。

## 组件级设计系统集成（参考）

> OD 的设计语言可以指导视频组件风格，但不是必须的。以下是从 Warm Editorial 系统提取的可复用组件模式，供参考。

### 映射表

| OD 系统定义 | scene composition 对应 | 示例（warm-editorial） |
|-------------|----------------------|----------------------|
| **Color palette** | `:root` CSS 变量 | 已提取到 `od-themes.json` |
| **Typography scale** | 标题/正文/标签 fontSize | 标题 56px serif / 正文 20px sans / 标签 14px |
| **Display font** | 大标题 font-family | `font-family: var(--font-serif)` |
| **Body font** | 说明文字 font-family | `font-family: var(--font-sans)` |
| **Card styling** | 价格/数据卡片 | 白底 + 16px radius + 森林绿 8% 描边 + 32px padding |
| **Tag styling** | 模型/标签/分类 | 圆角 + 森林绿边框 |
| **Accent usage** | 核心数字/CTA | 陶土红衬线数字 40px，一字一强调 |
| **Whitespace** | 场景内边距 | 80px 四周 padding + 48px 章节间距 |

### 关键词法（快速检索 OD body 中的可用信息）

```python
search_terms = [
    "Scale", "px", "font-family", "typography",
    "card", "label", "tag", "badge",
    "background", "accent", "surface",
    "padding", "margin", "spacing", "gap",
    "radius", "border", "shadow",
]
```

### 经验教训

- 只换色值的 OD 主题用户几乎感知不到变化（OpenCode Go 实测）
- 让 OD 的美学生效需要使用完整设计语言（字阶+间距+组件风格），但这部分手动写 CSS 也能达到同等效果
- OD 对视频工作流是"不错的设计参考源"，不是核武器
