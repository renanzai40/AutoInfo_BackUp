# G0 — Checkpoint Plan（6 项对齐）

### G0 — Checkpoint Plan（6 项对齐）

| # | 对齐项 | 说明 |
|---|--------|------|
| 1 | **脚本**（`script.md`） | 内容方向、信息保留度、去 AI 味检核通过 |
| 2 | **脚本版本** | **确认用哪个文件**。不要假设最新修改时间就是目标版本——问用户。例：`script_45s.md` vs `script_v2_humanized.md` |
| 3 | **Outline**（`outline.md`） | 场景分割、信息池、素材清单 |
| 4 | **主题风格** | 从 36 个 html-ppt 主题 + **8 个 Open Design 品牌主题**（`references/od-themes.json`）中选。也可以混搭或自创——主题是工具，不是枷锁。 |
| 5 | **素材准备** | TTS 音频、图片、logo 是否就位。TTS 时长校准见 `references/tts-duration-calibration.md` |
| 6 | **开发模式** | A（逐场景确认）或 B（Ch1 确认后全量开发） |

---
