# HyperFrames Composition 编写指南

**来源**：HyperFrames 官方文档 + 今晚实测 + web-video-presentation

## 项目结构

```
my-video/
├── index.html                 ← 根 composition（音频 + 场景编排）
├── compositions/              ← 子 composition（每场景一个）
│   ├── 01-intro.html
│   ├── 02-pain.html
│   └── ...
├── assets/
│   ├── audio/
│   │   └── narration.mp3
│   └── images/
├── meta.json
├── hyperframes.json
└── package.json
```

## 根 composition 模板

```html
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=1920, height=1080" />
  <script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { margin: 0; width: 1920px; height: 1080px; overflow: hidden; background: #030a04; }
  </style>
</head>
<body>
  <div id="root" data-composition-id="main"
       data-start="0" data-duration="50"
       data-width="1920" data-height="1080">

    <!-- 音频 — 必须 id 属性 -->
    <audio class="clip" data-start="0" data-duration="50"
           data-track-index="0" src="assets/audio/narration.mp3" id="narration-audio"></audio>

    <!-- 场景加载 — 每个 host 需要 data-composition-id 匹配子 composition 的 id -->
    <div class="clip" data-start="0" data-duration="8" data-track-index="1"
         data-composition-src="compositions/01-intro.html"
         data-composition-id="intro" id="s1-intro"></div>
  </div>

  <!-- 根 timeline 即使空也要注册 -->
  <script>
    window.__timelines = window.__timelines || {};
    window.__timelines["main"] = gsap.timeline({ paused: true });
  </script>
</body>
</html>
```

## 子 composition 模板

```html
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=1920, height=1080" />
  <script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { margin: 0; width: 1920px; height: 1080px; overflow: hidden; }
    body { background: #1a1714; color: #f5f0e5; font-family: system-ui, sans-serif; }
    /* 主题 token */
    :root { --accent: #ff4a2b; --text: #f5f0e5; --surface: #1a1714; }
  </style>
</head>
<body>
  <div id="scene" data-composition-id="intro"
       data-start="0" data-duration="8"
       data-width="1920" data-height="1080">

    <div id="title" class="clip" data-start="0" data-duration="8" data-track-index="0"
         style="position: absolute; top: 300px; left: 140px; font-size: 80px; font-weight: 700;">
      OpenCode Go
    </div>
  </div>

  <script>
    window.__timelines = window.__timelines || {};
    const tl = gsap.timeline({ paused: true });
    tl.from("#title", { opacity: 0, y: -60, duration: 0.8, ease: "power3.out" }, 0);
    window.__timelines["intro"] = tl;
  </script>
</body>
</html>
```

## 关键约束

| 规则 | 说明 |
|------|------|
| `data-duration` | 根 composition 的时长 = 音频总时长（秒） |
| `data-start` | 子 composition 的开始时间 = TTS 场景起始秒数 |
| `data-track-index` | 同一场景内每个 clip 独占一个 track（不能重叠） |
| GSAP timeline | 必须 `{ paused: true }`，注册到 `window.__timelines[id]` |
| CSS | 必须定义终态。`tl.from()` 从某状态动画到 CSS 状态 |
| 字体 | 使用 `system-ui` 或显式 @import Google Fonts |

## TTS 时长 → data-duration 计算

```python
fps = 30
total_chars = sum(len(scene.text) for scene in scenes)
total_sec = ffprobe_duration  # 从 TTS mp3 测量

for scene in scenes:
    start = cumsum / total_chars * total_sec
    end = (cumsum + len(scene.text)) / total_chars * total_sec
    scene.start_sec = start
    scene.duration_sec = end - start
    # → data-start="{start:.1f}" data-duration="{duration:.1f}"
    cumsum += len(scene.text)
```

## QA 清单

- [ ] 所有 `data-*` 属性正确（composition-id, start, duration, width, height）
- [ ] `class="clip"` 标记了所有 timed 元素
- [ ] `data-track-index` 在同一场景内不重复（时间不重叠）
- [ ] GSAP timeline 有 `{ paused: true }`
- [ ] Timeline 注册到 `window.__timelines[id]`
- [ ] CSS 定义了所有 clip 的终态样式
- [ ] `tl.from()` 的参数不 = CSS 终态值
- [ ] 音频文件路径正确（相对 `assets/audio/`）
- [ ] 子 composition 的 `data-composition-src` 路径正确
- [ ] **`<audio>` 有 `id` 属性**（e.g. `id="narration-audio"`），否则渲染无声
- [ ] **根 `data-composition-id`** 与子 composition 的 `data-composition-id` + `window.__timelines["id"]` 完全一致
- [ ] **根 composition 有 `window.__timelines["main"]`**注册（即使空 timeline）
