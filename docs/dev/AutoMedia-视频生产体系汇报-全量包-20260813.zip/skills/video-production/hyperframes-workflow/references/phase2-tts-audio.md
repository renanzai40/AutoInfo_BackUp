# TTS 音频

### TTS 音频

```bash
# edge-tts（默认）
edge-tts --voice zh-CN-YunxiNeural --text "$(cat script.txt)" --write-media assets/audio/narration.mp3

# 测量总时长
ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 assets/audio/narration.mp3
```

#### 🔥 音频文件位置（2026-06-13 强制规则）

**`<audio>` 的 `src` 必须指向 hyperframes 项目目录内的文件**。使用 `../` 引用项目外的文件会触发 lint error `audio_src_not_found` 并导致渲染后视频静音。

```bash
# ❌ 错误：用相对路径引用项目外
# src="../audio_voiceover.mp3"  → linter 报 audio_src_not_found

# ✅ 正确：音频放在 assets/audio/ 内
mkdir -p assets/audio
cp ../audio_voiceover.mp3 assets/audio/narration.mp3
# index.html 写: src="assets/audio/narration.mp3"
```

**标准设置流程**：
1. TTS 生成到 `03_video/audio_voiceover.mp3`（项目目录，auto_media 标准路径）
2. 复制到 hyperframes 项目：`cp 03_video/audio_voiceover.mp3 hyperframes/assets/audio/narration.mp3`
3. 在 index.html 中用 `src="assets/audio/narration.mp3"`

#### 🔥 edge-tts voice 不可用时的重试策略（2026-06-13 记录）

`zh-CN-YunxiNeural`（业务款默认男声）有时返回 `NoAudioReceived: No audio was received.`。这是 edge-tts 服务端临时问题，非参数错误。

遇到此错误时按顺序尝试：

1. **换同性别备用 voice**：`zh-CN-YunjianNeural`（男声备选，同等级可用性）
2. **再换女声**：`zh-CN-XiaoxiaoNeural`
3. **重试原 voice**：等 30 秒后重试 `zh-CN-YunxiNeural`（临时服务端问题通常自行恢复）

注意：edge-tts 的 `--voice` 参数是**大小写敏感**的。有效格式：`zh-CN-YunxiNeural`（不是 `zh-cn-yunxineural`）。
