# 3. Tracks = 时间图层

### 3. Tracks = 时间图层

- 同一 `data-track-index` 的 clips 不能重叠
- 不同 track-index 的 clips 可以重叠（用于图层叠加）
- 每个元素的入场/展示/退场在 timeline 里控制
