# 1. CSS = 终态，GSAP = 从哪来

### 1. CSS = 终态，GSAP = 从哪来

```html
<!-- CSS 描述 hero frame（最终位置/样式） -->
<div id="title" class="clip" data-start="0" data-duration="5" data-track-index="0"
     style="position: absolute; top: 300px; font-size: 80px; color: #fff; opacity: 1;">
  Title
</div>

<script>
  // GSAP 描述"从哪来"（动画开始前的状态）
  const tl = gsap.timeline({ paused: true });
  tl.from("#title", { opacity: 0, y: -60, duration: 0.8 }, 0);
  window.__timelines["main"] = tl;
</script>
```

> 和 P0-5「Layout Before Animation」完全一致。先写终态 CSS，再加 GSAP 入场。
