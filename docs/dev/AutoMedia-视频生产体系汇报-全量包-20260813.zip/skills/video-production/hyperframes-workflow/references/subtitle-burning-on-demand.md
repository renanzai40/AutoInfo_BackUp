# 🔥 字幕烧录（按需步骤，2026-06-19 更新）

### 🔥 字幕烧录（按需步骤，2026-06-19 更新）

**默认策略：不烧字幕。** HyperFrames 视频的场景文字特效已覆盖 TTS 的完整信息，底部字幕重复且遮挡画面。渲染完成后直接交付原始无字幕文件。

需要烧录字幕的场景（纯口播无视觉文字等）：

```bash
# Step 1: 确认中文字体存在
ls -la /usr/share/fonts/truetype/wqy/wqy-zenhei.ttc 2>/dev/null \
  || echo "缺少 wqy-zenhei.ttc，用 sudo apt install fonts-wqy-zenhei 安装"

# Step 2: 从 clean 源烧录（禁止从已烧录版再次烧录——2026-06-19 双层字幕事故）
clean_src="out/video.mp4"
python3 ~/.hermes/profiles/content/skills/archived/scripts/burn_subtitles.py \
  /path/to/subtitle.srt \
  "${clean_src}" \
  out/video_subbed.mp4

# Step 3: 烧录后验证
ffmpeg -y -ss 5 -i out/video_subbed.mp4 -frames:v 1 -q:v 2 /tmp/vqa_subbed.jpg
python3 -c "from PIL import Image; img=Image.open('/tmp/vqa_subbed.jpg'); W,H=img.size; region=img.crop((0,int(H*5/6),W,H)); bright=sum(1 for r,g,b in region.getdata() if max(r,g,b)>100); print(f'bright={bright}')"
```

**核心原则**：
- 2026-06-19 确认：HyperFrames 竖屏视频默认无字幕，场景文字即字幕
- 必须从 clean 源烧录，禁止从已烧录版再次烧录（双层字幕 bug）
- `burn_subtitles.py` 已归档至 `archived/scripts/`，保留备用
