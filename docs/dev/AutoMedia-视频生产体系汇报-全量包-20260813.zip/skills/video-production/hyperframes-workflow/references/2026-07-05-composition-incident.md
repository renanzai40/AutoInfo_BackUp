# 2026-07-05 Composition Incident: Clip Stacking & Vertical Cramping

## Symptom A: All visual elements stacked on top of each other

**Reported by user**: "素材都堆叠到一起去了"

**Root cause**: subagent wrote inline-clip composition HTML without `data-start`, `data-duration`, `data-track-index` on any `class="clip"` element. HyperFrames treated all clips as static elements visible throughout the full composition duration.

**Buggy pattern** (what subagent produced):
```html
<div class="clip s1-tag" style="top:300px;font-size:36px;">🚀 标题</div>
<div class="clip s1-title" style="top:400px;font-size:72px;">副标题</div>
<!-- no data-start, no data-duration, no data-track-index on any element -->
<audio id="narration-audio" src="..."></audio>
<!-- audio also missing data-start/data-duration -->
```

**Fix applied**: `check_composition_qa.py` V6-6/7/8 (2026-07-05) — every `class="clip"` element must have all three attributes. Pre-render hook blocks render if missing.

**Affected projects**: `20260705_095659_shengshu-vidu-s1-realtime` (full stacking) and `20260705_095657_zuckerberg-ai-agent-slow` (same bug, partially hidden by GSAP visibility management)

## Symptom B: Scene content cramped in top portion of canvas

**Reported by user**: "最后一幕的排布有点问题，挤在一起了"

**Root cause**: Three elements in S5 were concentrated within a ~300px vertical band. With 1920px canvas height, >1200px empty below.

**Buggy S5 before fix**: tag top=420 (28px), title top=520 (76px), subtitle top=680 (38px), last bottom=718px, unused space=1202px

**Fixed S5 after redistribution**: tag top=360 (32px), title top=520 (76px), subtitle top=780 (40px), last bottom=820px. Gaps: 128px and 184px.

**Fix applied**: Vertical distribution rules in SKILL.md subagent hard constraints §6:
- First element ≥350px
- Adjacent spacing ≥120px
- Last element bottom ≥768px

## Why existing QA didn't catch these

V6-1 (font-size), V6-2 (top≥300), V6-3 (top≤1620), V6-4/5 (syntax), and hyperframes lint all pass despite the stacking/layout issues.

New checks that now catch them: V6-6/7/8 (metadata attributes) + subagent rule §6 (vertical spacing)

## Prevention protocol

User says "stacking/overlapping/everything on top":
→ Check composition for missing data-start/duration/track-index on clip elements
→ Rewrite with scene container pattern if subagent bug

User says "crowded/cramped/squeezed/not enough spacing":
→ Check last scene vertical distribution
→ Verify first ≥350px, spacing ≥120px, bottom ≥768px
