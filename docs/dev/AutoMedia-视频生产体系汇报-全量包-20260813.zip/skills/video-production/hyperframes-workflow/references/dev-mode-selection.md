# 开发模式选择（2026-06-13 新增）

### 开发模式选择（2026-06-13 新增）

HyperFrames 支持两种 composition 组织模式。**默认用模式 A（inline clip）**，模式 B（sub-composition）只在需要场景隔离时使用。

#### 模式 A（推荐）：Inline Clip — 单文件

所有场景的视觉元素直接写在 `index.html` 里，用不同的 `data-start`/`data-duration` 控制出场时间。不需要 `compositions/` 目录。

**优点**：无 ID 匹配问题、lint 通过率高、渲染可靠、适合竖屏短视频。subagent 生成更少出格式问题。
**缺点**：单文件较大（50-60 秒视频约 100-150 行 HTML）。

```html
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=1080, height=1920" />
  <script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { margin: 0; width: 1080px; height: 1920px; overflow: hidden; background: #0f172a; }
    body { font-family: system-ui, sans-serif; color: #f8fafc; }
  </style>
</head>
<body>
  <div id="root" data-composition-id="main" data-start="0" data-duration="55.8" data-width="1080" data-height="1920">
    <audio class="clip" data-start="0" data-duration="55.8" data-track-index="0"
           src="assets/audio/narration.mp3" id="narration-audio"></audio>

    <!-- 场景 1：所有元素共用 data-start/data-duration -->
    <div id="title" class="clip" data-start="0" data-duration="6.4" data-track-index="1"
         style="position: absolute; top: 400px; left: 80px; font-size: 72px; color: var(--accent);">
      标题文字
    </div>
    <!-- 场景 2：不同 data-start -->
    <div id="detail" class="clip" data-start="6.4" data-duration="12.8" data-track-index="2"
         style="position: absolute; top: 350px; left: 80px; font-size: 48px;">
      第二场文字
    </div>
  </div>
  <script>
    window.__timelines = window.__timelines || {};
    const tl = gsap.timeline({ paused: true });
    tl.from("#title", { opacity: 0, y: -30, duration: 0.8 }, 0);
    tl.from("#detail", { opacity: 0, y: 20, duration: 0.6 }, 6.4);
    window.__timelines["main"] = tl;
  </script>
</body>
</html>
```

**GSAP timeline 的 time key 必须用场景绝对 start 时间**，不是 0。例如场景 2 的动画在 `6.4` 秒触发。

#### 模式 B（备选）：Sub-composition — 多文件

每个场景一个独立 HTML 文件，根 `index.html` 用 `data-composition-src` 引用。

```
my-video/
├── index.html                 ← 根 composition（音频 + 场景编排）
├── compositions/
│   ├── 01-intro.html          ← 单个场景
│   ├── 02-pain.html
│   └── ...其他场景
├── assets/
│   ├── audio/
│   │   └── narration.mp3      ← TTS 音频
│   └── images/                ← 图片素材
├── meta.json
├── hyperframes.json
└── package.json

> **项目配置模板**：`templates/package.json`、`templates/meta.json`、`templates/hyperframes.json` 提供标准化项目配置，直接复制到新项目根目录使用。
> **HTML 模板**：`templates/index-template.html`（根 composition）、`templates/scene-template.html`（子场景），复制后修改即可。**注意：所有 composition 用 1920×1080**；如需 1080×1920（抖音竖版），修改 `data-width=1080 data-height=1920` 并调整布局。
> **组件模式库**：选好主题后，参考 `references/component-patterns.md` 应用对应设计系统的组件级 CSS（卡片/标签/数据块/对比块的排版和风格）。不只是换色。
