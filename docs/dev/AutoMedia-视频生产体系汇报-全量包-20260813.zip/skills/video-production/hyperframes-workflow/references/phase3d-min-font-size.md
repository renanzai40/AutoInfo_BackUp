# Phase 3d：字号最小基准（2026-06-25 新增）

### Phase 3d：字号最小基准（2026-06-25 新增）

> 以视频中「商用无限制 · 本地离线部署」文字为参考（34px），**所有承担信息传递功能的文本字号不得低于此基准**。

| 层级 | 最小字号 | 说明 |
|------|---------|------|
| 主标题/大数字 | 48px~80px | 依布局自行决定 |
| 正文/说明文字 | **≥ 34px** | 参考基准：`商用无限制 · 本地离线部署` |
| 品牌标语/次要行 | **≥ 28px** | 如 `AI 内容生产 · 关注开源落地` |
| 标签/badge/图标文字 | **≥ 20px** | 参考 `references/component-patterns.md` |

**踩坑记录**：同一元素不要写两个 `class` 属性（如 `class="clip"` 后又写 `class="body-text"`），第二个 class 被浏览器忽略，文字回退到默认 16px。用 `class="clip body-text"` 合并到同一个属性。

| 效果 | GSAP 写法 | 适用场景 |
|------|-----------|---------|
| 淡入 + 上移 | `tl.from(el, { opacity: 0, y: -40, duration: 0.8 }, 0)` | 标题、副标题 |
| 弹入放大 | `tl.from(el, { scale: 0.5, opacity: 0, duration: 0.7, ease: "back.out(1.7)" }, 0)` | 价格、品牌名 |
| 从下浮入 | `tl.from(el, { opacity: 0, y: 40, duration: 0.6 }, 0)` | 说明文字、标签 |
| 逐个淡入 | `tl.from(el.children, { opacity: 0, stagger: 0.2, duration: 0.4 }, 0)` | 列表项 |
| 保持可见 | 不写 to() | 展示到场景结束 |

> **铁律**：`tl.from()` = 从某状态动画到 CSS 定义的状态。CSS 即终态。

---
