# 4. TTS 时长驱动场景时长

### 4. TTS 时长驱动场景时长

TTS → ffprobe 测总时长 → 按字符比例分配每场景 duration → `data-duration` + `data-start`
