# HyperFrames GSAP 动画模式参考

**来源**：HyperFrames 官方 skill + 今晚实测

## 核心认知

- CSS 是**终态**（hero frame），GSAP 描述"从哪来"
- 所有动画通过 `tl.from()` 实现：从某个状态 → CSS 定义的状态
- 不需要 `tl.to()`——保持终态到 clip 的 `data-duration` 结束
- 如果需要退场：用 `tl.to()` 在 timeline 末尾让元素离开

## clip 生命周期

```
data-start                   data-start + data-duration
   │                               │
   ▼                               ▼
   ├──── tl.from() ────┬──── stay ─┤
   │  入场动画          │  保持可见  │
   │  (0.5-1.5s)       │           │
                       └── tl.to() ─┤  (退场，可选)
```

## 常用动画模式

### 1. 淡入 + 上移（标题、副标题）

```js
tl.from("#title", { opacity: 0, y: -40, duration: 0.8, ease: "power3.out" }, 0);
```

| 参数 | 推荐值 | 效果 |
|------|--------|------|
| duration | 0.6-1.0 | 越慢越优雅 |
| y | -30 到 -60 | 位移越大越有冲劲 |
| ease | "power3.out" | 自然减速 |
| ease | "back.out(1.7)" | 轻微过冲，更活泼 |

### 2. 弹入放大（价格、品牌名）

```js
tl.from("#price", { scale: 0.3, opacity: 0, duration: 0.7, ease: "back.out(1.7)" }, 0);
```

| 参数 | 推荐值 | 效果 |
|------|--------|------|
| scale | 0.3-0.8 | 越小弹入感越强 |
| ease | "back.out(1.7)" | 标准弹跳 |
| ease | "elastic.out(1, 0.3)" | 更 Q 弹 |

### 3. 从下浮入（说明文字、标签）

```js
tl.from("#tag", { opacity: 0, y: 40, duration: 0.6, ease: "power3.out" }, 0.3);
```

和上移相反方向——更适合于"结果"类内容。

### 4. 逐个浮现（列表、模型标签）

```html
<div id="list">
  <div class="item">Item 1</div>
  <div class="item">Item 2</div>
  <div class="item">Item 3</div>
</div>
```

```js
tl.from(".item", { opacity: 0, y: 20, stagger: 0.2, duration: 0.4 }, 0);
```

`stagger: 0.2` = 每个元素延迟 0.2s 依次入场。

### 5. 交叉淡出（场景过渡）

两个元素同时一出一入：

```js
tl.to("#old", { opacity: 0, duration: 0.3 }, 3.5);
tl.from("#new", { opacity: 0, y: -20, duration: 0.5 }, 3.7);
```

### 6. 脉冲辉光（CTA、价格强调）

GSAP 不擅长持续循环动画。用 clip-path 或 CSS 动画做持续呼吸效果：

```css
@keyframes pulse {
  0%, 100% { filter: brightness(1); }
  50% { filter: brightness(1.3); }
}
#cta { animation: pulse 2s ease-in-out infinite; }
```

## 内容类型 → GSAP 模式

| 内容类型 | GSAP 模式 | 参考代码 |
|---------|-----------|---------|
| 标题/品牌名 | fade-in + 上移 + ease back.out | `tl.from("#t", {opacity:0,y:-40,duration:0.8,ease:"back.out(1.7)"},0)` |
| 价格/数字 | scale-in + ease back.out | `tl.from("#p", {scale:0.5,opacity:0,duration:0.7,ease:"back.out(1.7)"},0)` |
| 列表/模型标签 | stagger 逐个 | `tl.from(".tag", {opacity:0,y:20,stagger:0.2,duration:0.4},0)` |
| 比较/对比 | 左右同时入场 | `tl.from("#left", {x:-40,opacity:0,duration:0.6},0) + tl.from("#right",{x:40,opacity:0,duration:0.6},0)` |
| CTA/号召 | 放大 + 辉光 | scale-in + CSS pulse animation |
| 数据/统计 | 从下浮现 + 突出强调 | fade-in-up + color accent |
| 纯说明文字 | 简单淡入 | `tl.from("#t", {opacity:0,duration:0.5},0)` |

## 禁止

- ❌ `gsap.from()` 的参数和 CSS 初始值相同（元素不动）
- ❌ 无 `{paused: true}` 的 timeline
- ❌ 不注册到 `window.__timelines`
- ❌ `Math.random()` 或 `Date.now()` 在 timeline 中（非确定性）
- ❌ 同一个 track 上有时间重叠的 clips
