# 视觉布局类型库（Visual Layout Patterns）

> **解决视频单调的根因。** 每个场景必须有不同于其他场景的视觉布局。
> 5 段视频 = 至少 4 种不同布局，禁止全场用一种。

---

## 类型 1：居中大字型（Centered Hero）

**特征**：单一元素居中，大字/大标题，极简背景。
**适合**：开场钩子、结尾 CTA、关键断言。
**动画风格**：缓入 + 缩放（power3.out + back.out），递进式文字转场。

```
┌──────────────────────────────────┐
│                                  │
│                                  │
│         做AI开发的人              │  ← 先出，然后变暗
│         模型账单越滚越大          │
│                                  │
│      有没有更划算的方式？         │  ← 后出，缩放弹入
│              ▊                   │  ← 闪烁光标
│                                  │
└──────────────────────────────────┘
```

```css
/* 骨架 */
.scene { display: flex; align-items: center; justify-content: center; }
.hero { text-align: center; max-width: 1600px; }
.hero-line1 { font-size: 38px; color: var(--text-2); }
.hero-line2 { font-size: 52px; font-weight: 600; color: var(--text-1); font-family: var(--font-display); }
```

**OpenCode Go 用例**：Scene 1（Hook）

---

## 类型 2：水平分栏型（Split Screen）

**特征**：左右两列，各占一半，视觉对比。
**适合**：对比、Before/After、方案 vs 问题、选 A 还是 B。
**动画风格**：左右同时或交错滑入（power3.out），中间分隔符弹出。

```
┌──────────────────────────────────┐
│  ┌───────────┐  ┌───────────┐   │
│  │  Flash    │  │  Go       │   │
│  │  $0.14    │  │  $10      │   │
│  │  官方API  │  │  包含14个  │   │
│  └───────────┘  └───────────┘   │
│       =           包含          │
│  ┌───────────┐  ┌───────────┐   │
│  │  V4 Pro   │+ │  Max      │   │
│  │  $1.74    │  │  $2.50    │   │
│  └───────────┘  └───────────┘   │
└──────────────────────────────────┘
```

```css
/* 骨架 */
.compare-row { display: flex; align-items: center; justify-content: center; gap: 32px; }
.compare-item { flex: 1; max-width: 480px; background: var(--surface); border-radius: var(--radius-lg); padding: 28px 32px; text-align: center; }
```

**OpenCode Go 用例**：Scene 4（Compare）

---

## 类型 3：卡片网格型（Card Grid）

**特征**：多个同等权重的卡片/面板排列成行或网格。
**适合**：展示多个模型/功能/价格/选项。
**动画风格**：卡片逐个错位滑入（stagger + x/y 偏移，power2.out）。

```
┌──────────────────────────────────┐
│  直接 API 价格                    │
│                                  │
│  ┌──────┐  ┌──────┐  ┌──────┐  │
│  │V4 Pro│  │ Max  │  │ Plus │  │
│  │$1.74 │  │$2.50 │  │$1.60 │  │
│  └──────┘  └──────┘  └──────┘  │
│                                  │
│     每月几百美金                  │  ← 底部痛点亮出
└──────────────────────────────────┘
```

```css
/* 骨架 */
.card-row { display: flex; gap: 28px; justify-content: center; }
.card { background: var(--surface); border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 36px 44px; width: 320px; text-align: center; }
```

**OpenCode Go 用例**：Scene 2（Pain）

---

## 类型 4：数据面板型（Data Dashboard）

**特征**：大号数字/统计 + 标签 + 次要辅助信息，展现量化内容。
**适合**：定价方案、使用量数据、效果报告。
**动画风格**：数字先出，标签跟上，错落有致。数据行从左侧逐条滑入。

```
┌──────────────────────────────────┐
│  OpenCode Go                     │
│  ────────────────                 │
│  $10/月 · 十四款精选模型         │
│                                  │
│  ┌─────────┐  ┌─────────┐      │
│  │  $10    │  │ 158,150 │      │
│  │  每月   │  │ Flash/月│      │
│  │  14模型  │  │ 150,400 │      │
│  │         │  │ MIMO/月 │      │
│  └─────────┘  │  9,600  │      │
│               │ M3/5h   │      │
│               └─────────┘      │
└──────────────────────────────────┘
```

```css
/* 骨架 */
.main-content { display: flex; gap: 48px; }
.price-card { background: var(--surface); border-radius: 16px; padding: 36px 40px; flex-shrink: 0; width: 400px; }
.stat-row { display: flex; align-items: baseline; gap: 12px; }
.stat-number { font-family: var(--font-display); font-size: 40px; font-weight: 700; color: var(--accent); }
```

**OpenCode Go 用例**：Scene 3（Solution）

---

## 类型 5：流程步骤型（Timeline / Flow）

**特征**：自上而下或自左而右的步骤序列，箭头或连线连接。
**适合**：操作流程、how-to、工作流展示。
**动画风格**：步骤逐个出现，箭头/连线同步绘制（scaleX 动画）。

```
┌──────────────────────────────────┐
│  开通很简单：                     │
│                                  │
│  ┌ $ /connect ───────────┐      │
│  │ → 选择 Go 方案         │      │
│  │ → 粘贴 API 密钥        │      │
│  │ → ✓ 已连接             │      │
│  └────────────────────────┘      │
│                                  │
│  多得 $5 额度                     │
└──────────────────────────────────┘
```

```css
/* 骨架 */
.step-list { display: flex; flex-direction: column; gap: 16px; }
.step-item { display: flex; align-items: center; gap: 16px; padding: 16px 24px; background: var(--surface); border-radius: var(--radius); }
.step-number { width: 36px; height: 36px; border-radius: 50%; background: var(--accent); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 600; }
```

> **终端模拟型**是流程步骤型的变体——用 monospace 字体+窗口装饰替代圆角卡片。CSS 骨架见 `references/component-patterns.md` 模式 7。

**OpenCode Go 用例**：Scene 5（CTA）

---

## 类型 6：全屏叙事型（Full-screen Narrative）

**特征**：占据整个画面，大字/大图 + 极简标注。视觉冲击强。
**适合**：关键转折点、震撼数据、品牌宣言。
**动画风格**：大字从下方升起（y: 200 → 0），或者从模糊到清晰（blur + opacity）。

```
┌──────────────────────────────────┐
│                                  │
│                                  │
│                                  │
│         10 美金                   │
│      =  全 包 打                  │
│                                  │
│      外面单买轻松几百             │
│                                  │
└──────────────────────────────────┘
```

```css
/* 骨架 */
.scene { display: flex; align-items: center; justify-content: center; background: var(--bg); }
.big-claim { font-family: var(--font-display); font-size: 80px; font-weight: 700; letter-spacing: -0.03em; line-height: 1.2; }
.sub-claim { font-size: 24px; color: var(--text-2); margin-top: 16px; }
```

---

## 选择建议

| 视频段落 | 推荐布局 | 为什么 |
|---------|---------|--------|
| Hook / 开场 | 居中大字型 | 注意力集中，0 干扰 |
| 痛点 / 问题放大 | 卡片网格型 或 分栏型 | 多数据点冲击感 |
| 方案 / 产品介绍 | 数据面板型 或 流程步骤型 | 结构清晰，信息层次 |
| 对比 / 价值证明 | 水平分栏型 或 全屏叙事型 | 左右对照一目了然 |
| 引导 / CTA | 流程步骤型 或 居中大字型 | 简单直接，不留疑问 |

## ⚠️ 硬要求

> **一段视频中，相邻场景不得使用同一种视觉布局。5 段视频至少使用 4 种不同布局。**
>
> 重复使用同一种布局 = 观众产生「又来了」的疲劳感。宁可一个场景丑得有特点，也不要五个场景漂亮得一模一样。
