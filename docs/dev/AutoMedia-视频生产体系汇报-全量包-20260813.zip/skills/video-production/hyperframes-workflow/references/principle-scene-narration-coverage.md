# 7. 场景-旁白覆盖原则

### 7. 场景-旁白覆盖原则

每个 scene composition 的视觉元素必须覆盖对应 narration 的全部关键点。编写时做逐句 check。读完一句脚本，看一眼对应 scene 的 HTML 是否有视觉匹配。

---
