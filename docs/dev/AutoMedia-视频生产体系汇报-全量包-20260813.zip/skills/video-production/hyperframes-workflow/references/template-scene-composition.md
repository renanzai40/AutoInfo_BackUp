# 场景 composition 模板

### 场景 composition 模板

```html
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=1920, height=1080" />
  <script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
  <style>
    /* 复述根 composition 的主题 token */
    :root { --accent: #ff4a2b; --text: #f5f0e5; --surface: #1a1714; }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { margin: 0; width: 1920px; height: 1080px; overflow: hidden; background: var(--surface); }
    body { font-family: system-ui, sans-serif; color: var(--text); }
  </style>
</head>
<body>
  <div id="scene" data-composition-id="intro"
       data-start="0" data-duration="8"
       data-width="1920" data-height="1080">

    <div id="title" class="clip" data-start="0" data-duration="8" data-track-index="0"
         style="position: absolute; top: 300px; left: 140px; font-size: 80px;">
      你的标题
    </div>
  </div>

  <script>
    window.__timelines = window.__timelines || {};
    const tl = gsap.timeline({ paused: true });
    tl.from("#title", { opacity: 0, y: -60, duration: 0.8 }, 0);
    window.__timelines["intro"] = tl;
  </script>
</body>
</html>
```
