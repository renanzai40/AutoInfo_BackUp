# 2. 每个场景是一个子 composition

### 2. 每个场景是一个子 composition

```
compositions/
├── 01-intro.html       ← data-composition-src="compositions/01-intro.html"
├── 02-pain.html
└── 03-cta.html
```

每个子 composition 有自己的 timeline 和 clips。根 composition 只负责音频 + 按顺序加载场景。
