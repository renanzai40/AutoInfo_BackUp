# 两阶段渲染（Draft → Standard，2026-06-30 强制门控）

### 两阶段渲染（Draft → Standard，2026-06-30 强制门控）

> Draft 给用户验收画质和内容，验收通过后必须重推 Standard 终版。

```bash
# Phase 1: Draft（首次渲染，快速出片给用户验收）
bun x hyperframes render --output out/video.mp4 --quality draft
# → cp out/video.mp4 ../03_video/video_final.mp4
# → 发 draft 给用户验收

# [用户验收通过后]

# Phase 2: Standard（终版，码率更高画质更精细）
# ⚠️ bun 缓存可能污染，渲染前清理重装：
rm -rf node_modules bun.lock 2>/dev/null; bun install --no-cache
bun x hyperframes render --output out/video_standard.mp4 --quality standard
# → cp out/video_standard.mp4 ../03_video/video_final.mp4

# WSL 低内存（<8GB）一律用 bun x，不要用 npx
```

**publish_log 质量记录**（Gate G6）：每次渲染后更新 `05_publish/publish_log.json`：
```json
{"video": {"render_quality": "standard", "duration_sec": 64.5, "file_size_mb": 3.9, "render_method": "hyperframes"}}
```
Phase 1 记 `draft`，Phase 2 更新为 `standard`。跳过此字段 = audit 无法区分质量版本。

**bun 缓存污染修复**：`--quality standard` 可能因缓存冲突报 `EEXIST` / `FileNotFound`。修复：
```bash
rm -rf node_modules bun.lock
bun install --no-cache   # 空项目输出 "No packages! Deleted empty lockfile" — 正常
bun x hyperframes render --output out/video_standard.mp4 --quality standard
```

**渲染后交付规范**：
- `out/video.mp4`（draft）或 `out/video_standard.mp4`（standard）= 交付件
- 最终版始终复制到 `03_video/video_final.mp4`（覆盖旧版）
