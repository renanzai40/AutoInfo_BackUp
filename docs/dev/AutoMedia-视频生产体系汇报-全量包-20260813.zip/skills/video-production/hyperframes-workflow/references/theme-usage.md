# 主题使用指南（HyperFrames 工作流）

**来源**：`html-ppt-skill` 36 主题 → `references/theme-palettes.json`

## 快速使用

1. 打开 `references/theme-palettes.json`
2. 根据 mood 筛选（dark/light/tech/editorial/playful/clean）
3. 将选中主题的 CSS 变量复制到 composition 的 `<style>:root { ... }</style>` 中
4. 在 HTML 元素中使用 `var(--accent)`、`var(--text-1)` 等引用

## 推荐主题（按视频类型）

| 视频类型 | 推荐主题 | 来源 | mood |
|---------|---------|------|------|
|| AI/工具评测/开发者教程 | `cyberpunk-neon` | html-ppt | dark, tech |
|| **AI 编码/开发者产品推广** | **`od-opencode`** | **Open Design** | **dark, developer** |
|| CLI/终端/代码演示 | `terminal-green` | html-ppt | dark, tech |
| **开发者工具/高端B2B** | **`od-linear`** | **Open Design** | **dark, tech, premium** |
| **深度分析/长内容** | **`od-warm-editorial`** | **Open Design** | **warm, editorial** |
| **金融/高端产品推广** | **`od-stripe`** | **Open Design** | **dark, premium** |
| **观点向/人文内容** | **`od-claude`** | **Open Design** | **warm, human** |
| **纯内容驱动/极简** | **`od-minimal`** | **Open Design** | **clean, editorial** |
| **通用现代/白底** | **`od-vercel`** | **Open Design** | **modern, clean** |
| 深度分析/对比测评 | `editorial-serif` | html-ppt | light, editorial |
| 产品发布/品牌展示 | `bauhaus` | html-ppt | light, clean |
| B2B 产品/企业服务 | `corporate-clean` | html-ppt | light, clean |
| 数据展示/技术报告 | `swiss-grid` | html-ppt | light, clean |
| 科普/知识分享 | `academic-paper` | html-ppt | light, editorial |
| 新闻/资讯 | `news-broadcast` | html-ppt | light, editorial |

> **Open Design 主题 vs html-ppt 主题**：OD 主题来自品牌级设计系统，html-ppt 主题来自通用幻灯片模板。各有用处——OD 主题排版更讲究，html-ppt 主题色值更丰富。选哪个取决于视频气质，没有绝对的优劣。**也可以混搭：从 OD 取排版思路，从 html-ppt 取色值。**
>
> **组件级设计**：选好 OD 主题后可以翻 `references/component-patterns.md` 看对应的组件 CSS 模式。但不是必须的——有时候纯色+大字就够了。

## 在 composition 中使用

```html
<head>
  <style>
    :root {
      --bg: #000000;
      --surface: #0f0f1a;
      --text-1: #f5f7ff;
      --text-2: #b4b8d4;
      --accent: #ff2bd6;
      --accent-2: #00e5ff;
      --radius: 6px;
      --font-sans: 'Inter', 'Noto Sans SC', sans-serif;
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { margin: 0; width: 1920px; height: 1080px; overflow: hidden; }
    body { background: var(--bg); color: var(--text-1); font-family: var(--font-sans); }
  </style>
</head>
<body>
  <div id="scene" data-composition-id="intro" data-start="0" data-duration="8"
       data-width="1920" data-height="1080"
       style="background: var(--surface);">

    <div id="title" class="clip" data-start="0" data-duration="8" data-track-index="0"
         style="position: absolute; top: 300px; left: 140px; font-size: 80px; color: var(--accent);">
      OpenCode Go
    </div>
  </div>
</body>
```

## 手动作色（无现成主题时）

从 json 里找一个基础配色接近的，手动调 `--accent` 和 `--bg` 即可。
