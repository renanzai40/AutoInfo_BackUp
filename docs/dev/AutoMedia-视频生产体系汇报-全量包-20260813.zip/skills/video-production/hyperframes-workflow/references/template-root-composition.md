# 根 composition 模板（index.html）

### 根 composition 模板（index.html）

```html
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=1920, height=1080" />
  <script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { margin: 0; width: 1920px; height: 1080px; overflow: hidden; }
    :root {
      --bg: #030a04;
      --surface: #0a1b10;
      --text-1: #8cff9a;
      --accent: #00ff88;
    }
    body { background: var(--bg); color: var(--text-1); font-family: system-ui, sans-serif; }
  </style>
</head>
<body>
  <!-- 根 composition -->
  <div id="root" data-composition-id="main"
       data-start="0" data-duration="50"
       data-width="1920" data-height="1080">

    <!-- 音频轨道 — 必须 id 属性，否则渲染无声 -->
    <audio class="clip" data-start="0" data-duration="50" data-track-index="0"
           src="assets/audio/narration.mp3" id="narration-audio"></audio>

    <!-- 子场景 — 必须 data-composition-id 匹配子 composition 的 id -->
    <!-- 且需要 id 属性（lint 要求） -->
    <div class="clip" data-start="0" data-duration="6" data-track-index="1"
         data-composition-src="compositions/01-hook.html"
         data-composition-id="hook" id="s1-hook"></div>
    <div class="clip" data-start="6" data-duration="10" data-track-index="2"
         data-composition-src="compositions/02-pain.html"
         data-composition-id="pain" id="s2-pain"></div>
  </div>

  <!-- 根 timeline 即使空也要注册，否则 lint error -->
  <script>
    window.__timelines = window.__timelines || {};
    window.__timelines["main"] = gsap.timeline({ paused: true });
  </script>
</body>
</html>
```
