# 渲染前检查

### 渲染前检查

```bash
cd my-video
bun x hyperframes lint           # 静态检查（关键：0 error 再渲染）
```
