# 组件级设计（使用 OD 主题时）

### 组件级设计（使用 OD 主题时）

如果选择了 OD 主题（`references/od-themes.json`），在写 scene composition 时可以参考该设计系统的设计语言。但 OD 主题可以只用色值，html-ppt 主题也可以自己补组件风格——取决于视频需要什么。

> **OD 在工作流中的定位**：配色参考源之一。和 `theme-palettes.json` 平级，无优先级。需要新配色时启动一次 daemon 批量提取，用完关闭即可。**不常驻 daemon，不做深度集成。**
