# 5. 无构建步骤

### 5. 无构建步骤

不需要 `npm run dev` 或 bundler。改 HTML → 直接 `bun x hyperframes render`。
