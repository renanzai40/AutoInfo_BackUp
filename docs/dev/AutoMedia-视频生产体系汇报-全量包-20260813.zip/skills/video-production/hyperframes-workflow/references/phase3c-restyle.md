# Phase 3c：换装（换设计语言）

### Phase 3c：换装（换设计语言）

用户说"换一套设计语言" → 意味着：

1. 从 `references/od-themes.json` 或 `theme-palettes.json` 选新主题
2. 把新主题的 `:root { --bg, --accent, ... }` CSS 变量复制到**所有**场景文件和 index.html
3. 如果新主题的明暗/气质与旧主题差异大（如 light→dark），可能需要调整布局参数（间距、字号、卡片样式）
4. lint → render

**HTML 结构、动画 timing、内容文字都无需动**——只换 `:root` 块。这是 CSS 变量体系的核心优势。

- 字号层次：标题用 display font（serif），正文用 sans，标签用小号——但也可以全部统一字体
- 卡片风格：圆角/描边/内边距按 OD 规范（或者完全不用卡片）
- 间距让内容呼吸——但紧凑排版在某些场景下效果更好
