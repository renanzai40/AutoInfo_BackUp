# 视频组件模式库

从 Open Design 设计系统中提取的 CSS 组件模式，可直接用于 HyperFrames scene composition。

## 用法

1. 在 `references/od-themes.json` 或 `references/theme-palettes.json` 中选主题
2. 在场景 composition 的 `<style>` 中引入本模式库的对应模式（或部分模式）
3. 将主题色变量映射到组件 CSS

> ⚠️ **组件模式是工具箱，不是装修图纸**。不需要每个场景都用全所有模式。有时候一张大字就够，不需要卡片+标签+数据块全套。**少即是多**——堆积组件比只用色值更容易产生审美疲劳。

---

## 模式 1：标题块（Masthead / Headline）

```css
/* 杂志风标题 */
.masthead { margin-bottom: 48px; }
.kicker {
  font-size: 20px; text-transform: uppercase; letter-spacing: 2px;
  color: var(--text-2); margin-bottom: 12px;
}
.headline {
  font-family: var(--font-display, serif);
  font-size: 56px; font-weight: 700;
  letter-spacing: -0.02em; line-height: 1.2;
  color: var(--text-1);
}
.dek {
  font-size: 20px; color: var(--text-2); margin-top: 12px; line-height: 1.5;
}
```

| 变量 | 用途 | warm-editorial 值 |
|------|------|------------------|
| `--font-display` | 标题字体 | `'Times New Roman', serif` |
| `--font-sans` | 正文字体 | `system-ui, sans-serif` |
| `--text-2` | 副标题/元数据 | `#8A817A` |

---

## 模式 2：卡片（Card / Price Card）

```css
.card {
  background: var(--surface, #ffffff);
  border: 1px solid var(--card-border, rgba(47,91,79,0.08));
  border-radius: var(--radius-lg, 16px);
  padding: 32px 40px;
  display: inline-block;
}
.card-number {
  font-family: var(--font-display, serif);
  font-size: 72px; font-weight: 700;
  line-height: 1; letter-spacing: -0.03em;
  color: var(--text-1);
}
.card-label { font-size: 20px; color: var(--text-2); margin-top: 4px; }
.card-footer {
  font-size: 20px; color: var(--text-3); margin-top: 16px;
  padding-top: 16px; border-top: 1px solid var(--card-border, rgba(47,91,79,0.08));
}
```

| 变量 | 用途 | warm-editorial | stripe | linear |
|------|------|---------------|--------|--------|
| `--surface` | 卡片背景 | `#FFFFFF` | `#0F2440` | `#23252A` |
| `--radius-lg` | 圆角 | `16px` | `12px` | `10px` |
| `--card-border` | 描边 | `rgba(47,91,79,0.08)` | `rgba(255,255,255,0.06)` | `rgba(255,255,255,0.06)` |

---

## 模式 3：标签云（Tag Cloud）

```css
.tag {
  display: inline-block;
  padding: 8px 20px; margin: 4px 6px 4px 0;
  font-size: 20px;
  border-radius: var(--radius, 8px);
  border: 1px solid var(--tag-border, rgba(47,91,79,0.15));
  color: var(--text-2, #8A817A);
}
.tag-highlight {
  border-color: var(--accent);
  color: var(--accent);
  background: var(--tag-highlight-bg, rgba(192,81,47,0.04));
  font-weight: 600;
}
```

| 变量 | warm-editorial | stripe | od-opencode |
|------|---------------|--------|-------------|
| `--tag-border` | `rgba(47,91,79,0.15)` | `rgba(255,255,255,0.10)` | `rgba(255,255,255,0.10)` |
| 标签底色 | 透明 | 透明 | 透明 |
| 高亮标签色 | 陶土红 | 紫色 | 蓝色 |

---

## 模式 4：数据统计块（Stat Callout）

```css
.callout { display: flex; gap: 40px; margin-top: 48px; }
.stat-number {
  font-family: var(--font-display, serif);
  font-size: 40px; font-weight: 700;
  line-height: 1.2;
  color: var(--accent);
}
.stat-label { font-size: 20px; color: var(--text-3); margin-top: 4px; }
.stat-good .stat-number {
  color: var(--accent-2); /* secondary accent for positive values */
}
```

---

## 模式 5：对比块（Comparison / Before-After）

```css
.compare-wrap {
  display: flex; align-items: center; gap: 40px;
}
.column {
  flex: 1;
  padding: 36px 32px;
  border-radius: var(--radius-lg, 12px);
  text-align: center;
}
.column-bad {
  background: rgba(192,81,47,0.04);
  border: 1px solid rgba(192,81,47,0.2);
}
.column-good {
  background: rgba(47,91,79,0.04);
  border: 1px solid rgba(47,91,79,0.2);
}
.vs-badge {
  width: 56px; height: 56px;
  border-radius: 50%;
  border: 2px solid var(--text-3);
  display: flex; align-items: center; justify-content: center;
  font-size: 20px; font-weight: 700; color: var(--text-2);
}
```

---

## 模式 6：分隔线（Divider）

```css
.divider {
  width: 48px; height: 1px;
  background: var(--accent-2, #2F5B4F);
  margin: 0 0 12px 0;
  opacity: 0.4;
}
```

---

## 模式 7：终端模拟（Terminal Block）

```css
.terminal {
  border-radius: var(--radius, 8px);
  overflow: hidden;
  border: 1px solid var(--card-border, rgba(255,255,255,0.1));
  background: var(--bg, #1C1C24);
}
.terminal-bar {
  height: 34px;
  background: rgba(255,255,255,0.04);
  display: flex; align-items: center; padding: 0 16px; gap: 8px;
}
.terminal-body {
  padding: 24px;
  font-size: 20px; line-height: 2;
  font-family: 'JetBrains Mono', monospace;
}
```

---

## 整合示例

以下是一个 scene composition 按 warm-editorial 规范写的完整头部：

```html
<style>
  :root {
    /* 从 od-themes.json 复制 */
    --bg: #FAF7F2; --surface: #FFFFFF;
    --text-1: #1C1A17; --text-2: #8A817A; --text-3: #B0A8A0;
    --accent: #C0512F; --accent-2: #2F5B4F;
    --radius: 8px; --radius-lg: 16px;
    --font-serif: 'Times New Roman', serif;
    --font-sans: system-ui, sans-serif;
    --card-border: rgba(47,91,79,0.08);
    --tag-border: rgba(47,91,79,0.15);
  }
  /* 然后引用上面的组件模式 */
  .headline { font-family: var(--font-serif); ... }
  .card { background: var(--surface); border: 1px solid var(--card-border); ... }
</style>
```

## 注意事项

- **字体选择**：WSL headless Chrome 没有 GT Sectra / Söhne / Inter 等商业字体。使用 `system-ui` 和内置 serif 作为回退。
- **不要过度组件化**：视频是线性媒介，不需要按钮状态、hover、响应式。只提取对线性展示有用的组件（标题、卡片、标签、数据块）。
- **一致性第一**：同一个设计系统的所有场景应该用同一套 `--card-border` 和 `--radius-lg` 值，不要每场景独立设。
