# HyperFrames Draft → Standard Audit

## 背景

HyperFrames 从 6/13 开始使用。早期项目只跑了 `--quality draft` 给用户验收，但验收通过后没有补推 `--quality standard`。2026-06-30 首次全量扫描发现此问题。

## 全量 HyperFrames 项目清单（共 8 个）

| # | 项目 ID | 日期 | 管线位置 | 视频大小 | 画质 |
|---|---------|------|---------|---------|------|
| 1 | doubao-ai-misguide | 6/13 | project内嵌 | 2.3M | ⚠️ draft |
| 2 | perplexity-harvard-ai-agent | 6/13 | project内嵌 | 2.1M | ⚠️ draft |
| 3 | Confucius4-TTS-有道开源 | 6/25 | ~/automedia/ | 2.3M | ⚠️ draft |
| 4 | OpenAI-IPO-招揽双雄 | 6/25 | ~/automedia/ | 2.9M | ⚠️ draft |
| 5 | deepseek-dspark | 6/29 | ~/HyperFrames-Projects/ | 2.4M | ⚠️ draft |
| 6 | runway-ad-localization | 6/29 | ~/HyperFrames-Projects/ | 2.4M | ⚠️ draft |
| 7 | ai-model-profit-test | 6/30 | ~/HyperFrames-Projects/ | 3.9M | ✅ standard |
| 8 | deepseek-ai-bill-crisis | 6/30 | ~/HyperFrames-Projects/ | 4.3M | ✅ standard |

## Standard 重做步骤

对每个 draft-only 项目：

```bash
# 1. 找到 HyperFrames 项目位置
# 项目内嵌:   project/03_video/hyperframes/
# HyperFrames-Projects: ~/HyperFrames-Projects/<slug>/
# automedia:  ~/automedia/<name>/03_video/hyperframes/

# 2. 清理 bun 缓存
cd <hyperframes_project_dir>
rm -rf node_modules bun.lock
bun install --no-cache

# 3. 推 Standard
bun x hyperframes render --output out/video_standard.mp4 --quality standard

# 4. 复制到项目目录
cp out/video_standard.mp4 <project>/03_video/video_final.mp4

# 5. 更新 publish_log.json
# set video.render_quality = "standard"
```

## 判断标准

| 视频大小 | 画质判断 |
|---------|---------|
| < 3.0M | 极大概率是 draft |
| 3.0M - 5.0M | standard |
| > 5.0M | Remotion（旧管线，一版成型） |
