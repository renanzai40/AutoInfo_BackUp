---
name: hyperframes-workflow
description: >
  HyperFrames 视频生产完整工作流 — HTML + GSAP → MP4。
  替代 Remotion 工作流成为 AutoMedia 产线默认视频生产方案。
  从话题确认到视频交付的全链路 gate+步骤。
  HyperFrames 是渲染核心，web-video-presentation 提供内容方法论，
  html-ppt-skill 提供主题系统，frontend-slides 提供风格发现。
category: video-production
---
## HyperFrames 视频生产完整链路

```bash
# 第零步：环境检查（新项目/新环境必跑）
bash scripts/env-check.sh
```

```
话题确认（用户选择）
    ↓
automedia 文案链路
  short-video-script → humanizer → copy-review → brand-cta
    ↓
outline.md（内容规划 + Info Pool）→ 参考 `templates/outline-template.md`
    ↓
[Checkpoint Plan] — 脚本/outline/主题/素材/开发模式 6 项对齐
    ↓
选主题（`references/theme-palettes.json` 36 主题 或 `references/od-themes.json` 8 品牌主题）<br>如需从 Open Design 提取新主题：见 `references/od-themes-extraction.md`
    ↓
TTS音频 (edge-tts / minimax / openai)
    ↓
TTS 时长测量 → 确定场景帧边界
    ↓
选场景模式（`references/scene-patterns.md`）→ 匹配视频类型
    ↓
手动创建项目文件：
  模板 `templates/package.json` + `templates/meta.json` + `templates/hyperframes.json`
  模板 `templates/index-template.html` → 修改为你的根 composition
  模板 `templates/scene-template.html` → 复制为每个子场景
    ↓
写 index.html（根 composition，音频轨道）
    ↓
写 compositions/scene-*.html（每场景一个子 composition）
    ↓
[用户接受 Ch1] ← 第一个场景效果必须用户确认
    ↓
bun x hyperframes lint（静态检查）
    ↓
bun x hyperframes render --quality draft → MP4（首次用 draft 防 OOM）
    ↓
post-render QA（时长验证 + 视觉审查 + 反 AI 指纹检核 + 场景-旁白覆盖）
    ↓
delivery（发送文件给用户）
```

## Gate 链（顺序强制）

| # | Gate | 失败后果 |
|---|------|---------|
| G0 | Checkpoint Plan（6 项对齐） | Pipeline STOP，不得推进到 TTS/开发 |
| G1 | 文案三阶 gate | Pipeline STOP |
| G2 | 用户接受 Ch1 | Pipeline STOP，不渲染剩余场景 |
| G3 | hyperframes lint/validate 通过 | Pipeline STOP，不渲染 |
| G4 | post-render QA | Pipeline STOP，不交付 |
| G5 | delivery | Pipeline STOP，不发送 |

**任何 gate 失败 → 修复 → 回到该 gate 重走 → 通过后才能推进**

## HyperFrames 项目位置（多地点扫描）

HyperFrames 项目可能存在于 **3 个位置**，扫描已有项目时必须全部检查：

| 位置 | 路径 | 使用时期 |
|------|------|---------|
| 1. 独立项目目录 | `~/HyperFrames-Projects/<slug>/` | 6/29 起（深色主题：dspark、runway） |
| 2. 项目内嵌 | `<project>/03_video/hyperframes/` | 6/13 起早期（豆包AI误导、Perplexity哈佛等） |
| 3. automedia 目录 | `~/automedia/<项目名>/03_video/hyperframes/` | 6/25 前后（孔子TTS、OpenAI IPO等） |

**扫描命令**：
```bash
# 全量发现所有 HyperFrames 项目
find /home/renanzai -maxdepth 6 -name "hyperframes.json" 2>/dev/null

# 检查指定项目是哪种管线
test -f <project>/03_video/hyperframes/index.html && echo "HyperFrames内嵌"
test -d ~/HyperFrames-Projects/<slug> && echo "HyperFrames独立目录"
```

## 管线变迁时间线

| 时间 | 事件 |
|------|------|
| 5/11 → 6/9 | Remotion 为主力视频管线 |
| 6/10 | Remotion skill 归档（不再推荐使用） |
| 6/13 | HyperFrames 开始使用（首个项目：豆包AI误导、Perplexity哈佛） |
| 6/13 → 6/28 | HyperFrames 项目内嵌在 project/03_video/hyperframes/ |
| 6/29 | 独立项目目录 ~/HyperFrames-Projects/ 启用 |
| 6/30 | 两阶段渲染（Draft→Standard）门控固化 |

**audit 时注意**：6/13-6/28 有 10 个项目用 HyperFrames 但视频偏小（1.7M-2.9M = draft only），需补 standard 渲染。

## Phase 1：内容生产（同 AutoMedia 文案链路）

使用现有的 `short-video-script` → `humanizer` → `copy-review` → `brand-cta` 链路。
产出 `script.md` 和 `outline.md`（参考 `templates/outline-template.md`）。

脚本定稿后、TTS 前，根据视频类型选择场景模式（`references/scene-patterns.md`）：

| 视频类型 | 推荐模式 | 说明 |
|---------|---------|------|
| 产品推广/业务款 | 模式 A（5段） | 钩子→痛点→方案→对比→CTA |
| 热点评论/引流款 | 模式 B（3段） | 钩子→分析→洞察 |
| 教程/工作流 | 模式 C（3段） | 问题→步骤→结果 |
| 对比/测评 | 模式 D（4段） | 双方→维度→结论 |

场景模式确定后再按模式规划每段的视觉元素。

如果涉及产品数据（价格/用量/模型名称），先做 **数据增补**（`references/data-enrichment.md`）：
- P0 产品推广 → 查官方文档 → 提取真实数值 → 修订脚本
- P1 新闻评论/引流款 → 查新闻原文 → 核实数据来源 → 标注引用

---

## Phase 2：Assets 准备

> TTS 音频生成与时长测量 → `references/phase2-tts-audio.md`；场景时长分配 → 见下方"场景帧边界计算"。

## 🔥 场景帧边界计算 + float 精度陷阱

```python
# 字符数等比分配
total_chars = sum(len(e) for e in scenes)
total_sec = ffprobe_duration
cumsum = 0
for scene in scenes:
    start = cumsum / total_chars * total_sec
    end = (cumsum + len(scene)) / total_chars * total_sec
    # → scene.duration = end - start
    cumsum += len(scene)
```

**🔥 float 精度陷阱**：计算出的 `data-duration` 直接用浮点等式会导致相邻 clip 在 lint 时报 `overlapping_clips_same_track`（如 19.990000000000002 > 19.99）。**修复**：计算完所有场景的 duration 后，对每个 duration 减 0.01 秒（值很小，人耳不可感知），制造安全间距：

```python
# post-calculation: 浮点精度安全修正
for scene in scenes:
    scene["duration"] = max(0.1, scene["duration"] - 0.01)  # 减 0.01s 防浮点重叠
```

---

## ⚠️ 前置警告：禁止自动生成 Composition（2026-06-15 硬门控）

> **🔥 P0 铁律**：视频是设计产物，不是脚本的视觉转译。**禁止用脚本/工具自动生成 composition HTML。**
>
> **事故**：2026-06-15 用 `create_hf_project.py` 自动生成 composition，5 段全部同一布局、同一动画、无主题——用户直接反馈「视频标准大幅下降」。
>
> **正确做法**：每个场景的布局、动画、视觉元素必须手动设计。自动脚本只允许做项目骨架（创建 package.json/meta.json/hyperframes.json + 复制音频），**不允许生成任何视觉 clip 元素**。
>
> **Gate 关联**：写 composition 前必须先过 `productivity/automedia-production-guard` 的 **Gate VQ (Design Quality)**——选主题、定布局序列、校验多样性（5 段 ≥ 4 种不同布局、相邻不得重复、动画 easing ≥ 2 种）。
>
> **自检**：如果 `index.html` 中所有 scene clip 的 `data-track-index` 从 1 连续到 5 且每个 clip 结构高度相似（同样的 class、同样的动画参数、同样的内部元素数量）→ 大概率是自动生成，必须重写。

## Phase 3：Composition 编写

> 开发模式 A/B 选择 → `references/dev-mode-selection.md`；布局多样性校验 → `references/layout-sequence-validation.md`；根 composition 模板 → `references/template-root-composition.md`；场景模板 → `references/template-scene-composition.md`；字号基准 → `references/phase3d-min-font-size.md`。

## Phase 4：渲染与交付

> 渲染前检查 → `references/phase4-pre-render-check.md`；pre_render_hook 绕过 → `references/pre-render-hook-bypass.md`；两阶段渲染 → `references/two-stage-rendering.md`；字幕烧录 → `references/subtitle-burning-on-demand.md`；QA 检核 → `references/phase4-qa-checklist.md`。

---

## 章节导航（JiT Loading）

> 主文件保留核心流程。以下章节已移至 references/，按需加载：

| 章节 | Reference | 行数 |
|------|-----------|------|
| 注意事项（踩坑记录） | `references/gotchas-pitfalls.md` | 296 |
| 开发模式选择（2026-06-13 新增） | `references/dev-mode-selection.md` | 76 |
| 根 composition 模板（index.html） | `references/template-root-composition.md` | 50 |
| QA 检核 | `references/phase4-qa-checklist.md` | 42 |
| TTS 音频 | `references/phase2-tts-audio.md` | 41 |
| 场景 composition 模板 | `references/template-scene-composition.md` | 38 |
| 两阶段渲染（Draft → Standard，2026-06-30 强制门控） | `references/two-stage-rendering.md` | 38 |
| 🔥 pre_render_hook 拦截渲染的绕过方案（2026-07-05 新增） | `references/pre-render-hook-bypass.md` | 30 |
| 🔥 字幕烧录（按需步骤，2026-06-19 更新） | `references/subtitle-burning-on-demand.md` | 28 |
| Phase 3d：字号最小基准（2026-06-25 新增） | `references/phase3d-min-font-size.md` | 25 |
| 1. CSS = 终态，GSAP = 从哪来 | `references/principle-css-terminal-state.md` | 19 |
| 预设计：布局序列校验（写 composition 前必跑） | `references/layout-sequence-validation.md` | 15 |
| Phase 3c：换装（换设计语言） | `references/phase3c-restyle.md` | 15 |
| G0 — Checkpoint Plan（6 项对齐） | `references/gate-g0-checkpoint-plan.md` | 13 |
| 2. 每个场景是一个子 composition | `references/principle-sub-composition.md` | 11 |
| Phase 3a：提取设计语言 | `references/phase3a-design-language.md` | 10 |
| 6. 数据来源：用真实数字，不编造 | `references/principle-real-data.md` | 9 |
| Phase 3b：写 compositions | `references/phase3b-write-compositions.md` | 8 |
| 渲染前检查 | `references/phase4-pre-render-check.md` | 7 |
| 3. Tracks = 时间图层 | `references/principle-tracks.md` | 6 |
| 7. 场景-旁白覆盖原则 | `references/principle-scene-narration-coverage.md` | 6 |
| 组件级设计（使用 OD 主题时） | `references/od-theme-component-design.md` | 6 |
| 4. TTS 时长驱动场景时长 | `references/principle-tts-duration.md` | 4 |
| 5. 无构建步骤 | `references/principle-no-build.md` | 4 |
