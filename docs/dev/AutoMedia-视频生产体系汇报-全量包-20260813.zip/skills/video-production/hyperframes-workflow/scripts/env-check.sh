#!/bin/bash
# env-check.sh — 检查 HyperFrames 工作流所需依赖
# 在新项目/新环境首次使用前运行

echo "=== 环境检查 ==="

check() {
  if command -v "$1" &>/dev/null; then
    echo "  ✅ $1 — $(which $1)"
  else
    echo "  ❌ $1 — 未安装"
    MISSING=1
  fi
}

MISSING=0

echo ""
echo "--- 核心工具 ---"
check bun
check ffprobe
check edge-tts

echo ""
echo "--- HyperFrames ---"
if bun x hyperframes --version &>/dev/null 2>&1; then
  echo "  ✅ hyperframes — 可用"
else
  echo "  ❌ hyperframes — bun x 安装失败"
  MISSING=1
fi

echo ""
echo "--- Chrome ---"
CHROME=$(ls ~/.cache/hyperframes/chrome/*/chrome-linux64/chrome 2>/dev/null | head -1)
if [ -n "$CHROME" ]; then
  echo "  ✅ Chrome — $CHROME"
else
  echo "  ⚠️  Chrome 缓存未找到，运行 scripts/fix-chrome.sh"
  MISSING=1
fi

echo ""
if [ "$MISSING" -eq 0 ]; then
  echo "✅ 全部就绪"
else
  echo "⚠️ 有缺失，请按提示安装后重试"
fi
