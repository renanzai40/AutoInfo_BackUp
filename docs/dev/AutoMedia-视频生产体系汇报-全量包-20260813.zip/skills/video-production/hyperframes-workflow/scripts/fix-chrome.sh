#!/usr/bin/env bash
# fix-chrome.sh — Symlink Playwright's Chromium headless shell to HyperFrames cache
# 解决 WSL 上 HyperFrames 找不到 Chrome 的问题
set -euo pipefail

PLAYWRIGHT_HS="$HOME/.cache/ms-playwright/chromium_headless_shell-1217/chrome-headless-shell-linux64/chrome-headless-shell"
HF_CACHE_DIR="$HOME/.cache/hyperframes/chrome/chrome-headless-shell"

if [ ! -f "$PLAYWRIGHT_HS" ]; then
  echo "Playwright headless shell not found at: $PLAYWRIGHT_HS"
  echo "Trying to locate it..."
  FOUND=$(find "$HOME/.cache/ms-playwright" -name "chromium_headless_shell-*" -type d 2>/dev/null | sort -r | head -1)
  if [ -n "$FOUND" ]; then
    PLAYWRIGHT_HS="$FOUND/chrome-headless-shell-linux64/chrome-headless-shell"
    echo "Found: $PLAYWRIGHT_HS"
  else
    echo "Not found either. Install Playwright first:"
    echo "  cd <your-project> && npx playwright install chromium"
    echo "  or: npx playwright install --with-deps chromium"
    exit 1
  fi
fi

# Find the HF browser version
HF_VERSION_DIRS=$(ls -d "$HF_CACHE_DIR"/linux-* 2>/dev/null || true)
if [ -z "$HF_VERSION_DIRS" ]; then
  echo "HyperFrames cache empty. Run 'npx hyperframes render' once to trigger download,"
  echo "cancel after it creates the version directory, then re-run this script."
  echo "Or manually create the expected version directory:"
  echo "  mkdir -p $HF_CACHE_DIR/linux-131.0.6778.85/chrome-headless-shell-linux64"
  exit 1
fi

for DIR in $HF_VERSION_DIRS; do
  TARGET="$DIR/chrome-headless-shell-linux64/chrome-headless-shell"
  mkdir -p "$(dirname "$TARGET")"
  # Check existing symlink: must exist AND point to a valid executable
  if [ -f "$TARGET" ] && [ -x "$TARGET" ]; then
    echo "✓ Already valid: $TARGET"
  elif [ -L "$TARGET" ]; then
    # Broken symlink — replace
    REAL_TARGET=$(readlink "$TARGET")
    if [ ! -f "$REAL_TARGET" ]; then
      echo "⚠ Broken symlink: $TARGET → $REAL_TARGET (missing). Re-linking..."
      rm -f "$TARGET"
      ln -sf "$PLAYWRIGHT_HS" "$TARGET"
      echo "✓ Re-linked: $TARGET → $PLAYWRIGHT_HS"
    else
      echo "✓ Already linked (valid): $TARGET"
    fi
  else
    ln -sf "$PLAYWRIGHT_HS" "$TARGET"
    echo "✓ Linked: $TARGET → $PLAYWRIGHT_HS"
  fi
done

echo ""
echo "Done. Verify with: npx hyperframes render --output /tmp/test.mp4"
