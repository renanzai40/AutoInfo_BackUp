---
name: whisper-postprocess
description: "用当前 LLM provider（DeepSeek-v4-flash）对 Whisper 转写结果进行后处理——断句、加标点、分段、修正术语。支持纯文本修正和 SRT 文本修正（保留时间轴）。2026-06-09 更新：已从 MiniMax 迁移到 DeepSeek-v4-flash。 触发：Whisper 转写结果需要断句/加标点/修正术语时加载；不用于 SRT 时间轴生成（归 subtitle-srt-generation）。"
category: data-science
related_skills: ["subtitle-srt-generation", "video-production/hyperframes-workflow"]
---

# Whisper Postprocess

用当前 LLM provider 对 Whisper 输出的中文文本进行后处理，生成可读的带标点、分段字幕。

**2026-06-09 更新**：已从 MiniMax M2.7 迁移到 DeepSeek-v4-flash。MiniMax 订阅到期，所有 API 引用已移除。

## 适用场景

- Whisper 转写中文结果有识别错误（术语错拼、同音字错）
- 需要将 continuous text 恢复为带标点的分段文本
- Remotion 场景：Whisper tiny 模型输出的 SRT 需校正文本但保留时间戳
- 需要保留口语风格、不要过度书面化

## 两种工作模式

| 模式 | 输入 | 输出 | 适用场景 |
|------|------|------|---------|
| **纯文本修正** | Whisper 转写出的无标点字符串 | 带标点、分段的中文文本 | B站长视频字幕 |
| **SRT 文本修正** | Whisper 输出的 .srt 文件（含时间轴但误识别） | 文本修正后的 .srt 文件（时间轴不变） | Remotion 短视频 |

## 工作流

### 模式 A：纯文本修正（B站/长视频字幕）

```python
# 用当前 provider 做 LLM 校正
prompt = f"""你是专业的字幕整理助手。请对以下 Whisper 转写文本进行优化：
1. 断句加标点
2. 合理分段（按话题/步骤）
3. 修正识别错误（特别是品牌名、术语、数字）
4. 保持口语风格，不要过度书面化

直接输出纯文本，不要其他解释。

原文：
{raw_text}"""

# 通过 execute_code + hermes_tools 的 web_search/terminal 等方式调用当前 LLM
# 不要用 curl | python3 管道——terminal 60s 超时会挂起
```

### 模式 B：SRT 文本修正（Remotion 视频字幕，2026-06-09 实战验证）

两步法，先精确替换再 LLM 兜底：

**Step 1：基于原始脚本做精确替换校正**

```python
# 用原始脚本文本直接替换 SRT 中的误识别文本
corrections = {
    "ChFGPT要大变身了": "ChatGPT 要大变身了",
    "一目惯为": "壹目贯维",
    "一目貫為": "壹目贯维",
    "持续更近": "持续跟进",
    # ... 按实际误识别模式追加
}

def fix_srt(srt_path, corrections):
    with open(srt_path, 'r', encoding='utf-8') as f:
        content = f.read()
    for old, new in corrections.items():
        content = content.replace(old, new)
    with open(srt_path, 'w', encoding='utf-8') as f:
        f.write(content)
```

**Step 2：对剩余模糊条目用 LLM 逐条校正**

有原始脚本时，36 条 SRT 条目中 35 条可精确替换，仅需 LLM 处理 1-2 条模糊条目。

## 已知 Whisper tiny 中文误识别模式

| 类型 | 错误 → 正确 |
|------|------------|
| 英文品牌/术语 | ChFGPT→ChatGPT, AZENT→Agent, 雖然→Qwen |
| 中文同音字 | 一目惯为→壹目贯维, 更近→跟进, 出搞→出稿 |
| 数字/百分比 | 長了83.3%→涨了83%, T1→Q1 |
| 虚词混淆 | 內部内→累不累, 脚→叫, 相待→像带 |
| 分词错误 | 逃套好几轮→折腾好几轮, 常常常先→尝尝鲜 |
| **简繁混用（高频）** | **營收→营收, 對手→对手, 發現→发现, 聲音→声音, 體驗→体验, 雲端→云端, 訊息→信息, 相關→相关, 網路→网络, 數位→数字/数码** |

## SRT 文本校正两步法（2026-06-15 实战修正）

**Step 0：简繁转换（在精确替换之前跑）**

```python
import re

# 简体→繁体常见映射表（补充你遇到的缺失条目）
SIMPLE_MAP = {
    "營收": "营收", "對手": "对手", "發現": "发现", "聲音": "声音",
    "體驗": "体验", "雲端": "云端", "訊息": "信息", "相關": "相关",
    "網路": "网络", "數位": "数字", "關注": "关注", "樣": "样",
    "體": "体", "團": "团", "對": "对", "機": "机",
    "劃": "划", "問": "问题", "題": "题", "稱": "称",
    "從": "从", "個": "个", "會": "会", "說": "说",
    "後": "后", "發": "发", "開": "开", "現": "现",
    "時": "时", "間": "间", "爾": "尔", "維": "维",
    "維度": "维度", "轉型": "转型", "領域": "领域",
    "騰訊": "腾讯", "百度": "百度", "運算": "运算",
    "階段": "阶段", "願意": "愿意", "費用": "费用",
    # 以下仅繁体单字→简体，在整词匹配失败时做 fallback
}
def srt_simplify(text):
    """SRT 文本全网简繁转换 + 保留时间轴"""
    for trad, simp in SIMPLE_MAP.items():
        text = text.replace(trad, simp)
    return text
```

**⚠️ 关键教训（2026-06-15）**：Whisper tiny 繁体输出 + 手动替换漏了一定数量繁体 → 渲染后字幕不可见（DejaVuSans 无中文字形）或混杂繁体 → **先逐条全量简繁替换 + 再逐条视觉确认**。

## 模式选择决策

有原始脚本（script_final.txt）→ 模式 B Step 1 精确替换（最可靠）
无参考文本 → 模式 A（纯 LLM 校正）
Whisper tiny（误识别率 30-40%）→ 必须 LLM 校正
Whisper medium（误识别率 ~10%）→ 简单替换即可

## 验证

1. SRT 时间轴完整（首条 00:00:00,000 → 末条 ≤ 音频时长）
2. 文本无明显识别错误（品牌名、数字、术语正确）
3. 品牌名「壹目贯维」字节级正确
4. 文件已写回目标目录

## 2026-06-09 实战教训

1. **Whisper tiny 中文误识别率 30-40%**，不要依赖 tiny 的文本准确性。时间轴精度足够（±0.5s），但文本必须校正。
2. **有原始脚本时，先精确替换再 LLM 校正**。36 条 SRT 中 35 条可精确替换，仅 1 条需 LLM。
3. **替换后必须通读验证**，发现漏网立即追加替换规则。
4. **MiniMax API 已不可用（订阅到期）**。只用当前 provider（DeepSeek-v4-flash）。
